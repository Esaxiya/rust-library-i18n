//! Muuqaal si firfircoon u qiyaasan oo isku xigxiga, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Jeexjeexyo ayaa ah aragti xusuusta u taagan oo tilmaamaya dherer ahaan.
//!
//! ```
//! // jarista Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ku qasbaya gabal gabal
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Kala jajabku waa la beddeli karaa ama la wadaagi karaa.
//! Nooca jeex la wadaago waa `&[T]`, halka nooca jeex mutable waa `&mut [T]`, halkaas oo `T` ka dhigan tahay nooca element ah.
//! Tusaale ahaan, waxaad isku beddeli kartaa qaybta xasuusta ee jeex la beddelo ay tilmaamayso:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Waa kuwan qaar ka mid ah waxyaabaha module this ka kooban tahay:
//!
//! ## Structs
//!
//! Waxaa jira dhowr jaangooyooyin waxtar u leh xaleefyada, sida [`Iter`], oo mataleysa soo noqnoqoshada jeex.
//!
//! ## Hirgelinta Trait
//!
//! Waxaa jira dhowr fulin oo ah traits caadi ah oo loogu talagalay xaleefyada.Tusaalooyinka qaarkood waxaa ka mid ah:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], loogu talagalay xaleefyada nooca curiyuhu yahay [`Eq`] ama [`Ord`].
//! * [`Hash`] - loogu talagalay xaleefyada nooca curiyuhu yahay [`Hash`].
//!
//! ## Iteration
//!
//! Xaleefyadu waxay hirgeliyaan `IntoIterator`.Tilmaamuhu wuxuu soo saaraa tixraacyada qaybaha cad.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Jeex jeexan wuxuu soo saarayaa tixraacyo la beddeli karo oo ku saabsan canaasiirta:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Tilmaame-barahaani wuxuu soo saaraa tixraacyo la beddeli karo oo ku saabsan cunsurka, sidaas darteed halka nooca curiyaha uu yahay `i32`, nooca cunsuriyaha ayaa ah `&mut i32`.
//!
//!
//! * [`.iter`] iyo [`.iter_mut`] waa hababka cad ee lagu soo celinayo iterators-ka caadiga ah.
//! * Hababka dheeraadka ah ee soo celiya dib-u-habeyaasha waa [`.split`], [`.splitn`], [`.chunks`], [`.windows`] iyo in ka badan.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Qaar badan oo ka mid ah adeegsiga ku jira qaybtaan ayaa kaliya loo isticmaalaa qaabeynta imtixaanka.
// Waa ka nadiifsan tahay kaliya in la damiyo digniinta aan la isticmaalin_imboortiga halkii laga hagaajin lahaa.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Hababka fidinta aasaasiga ah
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) loo baahan yahay hirgelinta `vec!` macro inta lagu jiro baaritaanka NB, fiiri qaybta `hack` ee feylkan wixii faahfaahin dheeraad ah.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) loo baahan yahay hirgelinta `Vec::clone` inta lagu guda jiro tijaabada NB, fiiri qaybta `hack` ee faylkan wixii faahfaahin dheeraad ah.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Iyadoo cfg(test) `impl [T]` aan la heli karin, seddexdan shaqaba dhab ahaantii waa habab ku jira `impl [T]` laakiin aan kujirin `core::slice::SliceExt`, waxaan u baahanahay inaan u siino shaqooyinkan tijaabada `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Waa in aynaan ku darin astaamaha khadka toosan tan tan maxaa yeelay tan waxaa loo isticmaalaa `vec!` macro badanaa waxayna keentaa dib u noqosho cadar.
    // Ka eeg #71204 doodda iyo natiijooyinka cadarka.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // walxaha waxaa lagu calaamadeeyay in lagu bilaabay wareegga hoose
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ayaa lagama maarmaan u ah LLVM inay ka saarto jeegagga soohdinta isla markaana ay leedahay codegen ka fiican ka zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ayaa loo qoondeeyay oo laga bilaabay kor si ugu yaraan dhererkan.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // loo qoondeeyay korka iyadoo la adeegsanayo awoodda `s`, lana bilaabi karo `s.len()` gudaha ptr::copy_to_non_overlapping ee hoose.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Jeex jeex.
    ///
    /// Noocani waa mid xasilloon (ie, dib uma amrayo walxo isku mid ah) iyo *O*(*n*\*log(* n*))-kii ugu xumaa.
    ///
    /// Marka ay khuseyso, kala soocida aan xasillooneyn ayaa la door bidaa maxaa yeelay guud ahaan way ka dheereysaa kala soocista xasilloon mana u qoondeyso xusuusta caawinta ah.
    /// Fiiri [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Hirgelinta hadda
    ///
    /// Algorithm-ka hadda jira waa mid la jaanqaadaya, iskudhafid isku-dhafan oo dhiirrigelinaya [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Waxaa loogu talagalay inay ahaato mid aad u dhakhsaha badan marka kiisaska jeexitaanku ku dhowaad kala-sooco, ama ka kooban yahay laba ama in ka badan oo isku xigxigsan oo taxane ah oo la isku raacay midba midka kale.
    ///
    ///
    /// Sidoo kale, waxay u qoondeysaa keyd ku meel gaar ah nuska cabbirka `self`, laakiin jeexitaannada gaaban nooc ka mid ah gelinta aan qoondayn ayaa loo adeegsadaa halkii.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Jeex jeex leh isbarbardhiga shaqada.
    ///
    /// Noocani waa mid xasilloon (ie, dib uma amrayo walxo isku mid ah) iyo *O*(*n*\*log(* n*))-kii ugu xumaa.
    ///
    /// Shaqada isbarbardhigaha waa inuu qeexaa wadarta dalab ee qaybaha ku jira jeex.Haddii amarku aanu ahayn wadar ahaan, amarka canaasiirta lama cayimin.
    /// Amarku waa amar guud haddii uu yahay (dhammaan `a`, `b` iyo `c`):
    ///
    /// * wadarta iyo antisymmetric: sida saxda ah mid ka mid ah `a < b`, `a == b` ama `a > b` waa run, iyo
    /// * Transitive, `a < b` iyo `b < c` tilmaamaysaa `a < c`.Waa in ay qabataa isku mid ah labada `==` iyo `>`.
    ///
    /// Tusaale ahaan, halka [`f64`] uusan hirgelin [`Ord`] sababta oo ah `NaN != NaN`, waxaan u isticmaali karnaa `partial_cmp` shaqadeena nooceeda ah markaan ogaano in jeexku uusan kujirin `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Marka ay khuseyso, kala soocida aan xasillooneyn ayaa la door bidaa maxaa yeelay guud ahaan way ka dheereysaa kala soocista xasilloon mana u qoondeyso xusuusta caawinta ah.
    /// Fiiri [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Hirgelinta hadda
    ///
    /// Algorithm-ka hadda jira waa mid la jaanqaadaya, iskudhafid isku-dhafan oo dhiirrigelinaya [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Waxaa loogu talagalay inay ahaato mid aad u dhakhsaha badan marka kiisaska jeexitaanku ku dhowaad kala-sooco, ama ka kooban yahay laba ama in ka badan oo isku xigxigsan oo taxane ah oo la isku raacay midba midka kale.
    ///
    /// Sidoo kale, waxay u qoondeysaa keyd ku meel gaar ah nuska cabbirka `self`, laakiin jeexitaannada gaaban nooc ka mid ah gelinta aan qoondayn ayaa loo adeegsadaa halkii.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // kala soocida gadaal
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ku kala sooc jeex jeexjeex ah fure fure.
    ///
    /// Noocani waa mid xasilloon (yacni, dib uma amrayo walxo isku mid ah) iyo *O*(*m*\* * n *\* log(*n*))-kiis kii ugu xumaa, halkaasoo fure u yahay *O*(*m*).
    ///
    /// Hawlaha muhiimka ah ee muhiimka ah (tusaale
    /// shaqooyinka aan fududeyn helitaanka hantida ama howlaha aasaasiga ah), [`sort_by_cached_key`](slice::sort_by_cached_key) waxay u egtahay inay si dhakhso leh u dhaqso badan tahay, maadaama aysan dib u soo celinaynin furayaasha walxaha.
    ///
    ///
    /// Marka ay khuseyso, kala soocida aan xasillooneyn ayaa la door bidaa maxaa yeelay guud ahaan way ka dheereysaa kala soocista xasilloon mana u qoondeyso xusuusta caawinta ah.
    /// Fiiri [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Hirgelinta hadda
    ///
    /// Algorithm-ka hadda jira waa mid la jaanqaadaya, iskudhafid isku-dhafan oo dhiirrigelinaya [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Waxaa loogu talagalay inay ahaato mid aad u dhakhsaha badan marka kiisaska jeexitaanku ku dhowaad kala-sooco, ama ka kooban yahay laba ama in ka badan oo isku xigxigsan oo taxane ah oo la isku raacay midba midka kale.
    ///
    /// Sidoo kale, waxay u qoondeysaa keyd ku meel gaar ah nuska cabbirka `self`, laakiin jeexitaannada gaaban nooc ka mid ah gelinta aan qoondayn ayaa loo adeegsadaa halkii.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ku kala sooc jeex jeexjeex ah fure fure.
    ///
    /// Inta lagu guda jiro kala-soocida, shaqada muhiimka ah waxaa loogu yeeraa hal mar halkii cunsur.
    ///
    /// sort Tani waa mid deggan (ie, ma xubno ka siman ma reorder) iyo *O*(*m*\* * n *+* n *\* log(*n*)) ugu xun ee, halkaas oo shaqada muhiimka ah waa *O*(*m*) .
    ///
    /// Hawlaha furaha fudud (tusaale ahaan, shaqooyinka ah helitaanka hantida ama howlaha aasaasiga ah), [`sort_by_key`](slice::sort_by_key) waxay u egtahay inay dhakhso badan tahay.
    ///
    /// # Hirgelinta hadda
    ///
    /// Algorithm-ka hadda jira wuxuu ku saleysan yahay [pattern-defeating quicksort][pdqsort] oo uu qoray Orson Peters, kaas oo isku daraya kiiska celceliska degdegga ah ee kala-sooc la'aanta ah ee loo yaqaan 'randoms quicksort' oo leh kiiskii ugu xumaa ee loo yaqaan 'heapsort', halka lagu gaarayo waqti toosan oo lagu gooyo qaabab gaar ah.
    /// Waxay isticmaashaa xoogaa kala soocid ah si looga fogaado kiisaska xumaada, laakiin leh seed go'an si had iyo jeer loo bixiyo dabeecad go'aamin ah.
    ///
    /// Xaaladda ugu xun, algorithm waxay u qoondeysaa keyd ku meel gaar ah `Vec<(K, usize)>` dhererka jeex.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Caawiyaha dhaqaatiirta si loogu muujiyo nooca 'vector' nooca ugu yar ee suuragalka ah, si loo yareeyo qoondaynta.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Cunsurrada `indices` waa mid gaar ah, maaddaama ay jaangooyaan yihiin, sidaa darteed nooc kasta oo ka mid ahi wuu xasilloon yahay marka loo eego jajabka asalka ah.
                // Waxaan halkan ku isticmaalnaa `sort_unstable` maxaa yeelay waxay u baahan tahay qoondeyn yar oo xusuusta ah.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Nuqulada `self` oo loo rogay `Vec` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Halkan, `s` iyo `x` si madaxbannaan ayaa loo beddeli karaa.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Nuqulada `self` oo loo rogay `Vec` cusub oo leh qaybiyaha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Halkan, `s` iyo `x` si madaxbannaan ayaa loo beddeli karaa.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // FG, fiiri moduleka `hack` ee faylkan ku jira si aad u hesho faahfaahin dheeraad ah.
        hack::to_vec(self, alloc)
    }

    /// U rogaa `self` a vector iyada oo aan lahayn clones ama qoondayn.
    ///
    /// Natiijada vector dib ayaa loogu rogi karaa sanduuq iyada oo loo marayo 'Vec<T>` 'S habka `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` aan la dambe loo isticmaali karaa, sababtoo ah waxaa la beddelay `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // FG, fiiri moduleka `hack` ee faylkan ku jira si aad u hesho faahfaahin dheeraad ah.
        hack::into_vec(self)
    }

    /// Waxay abuurtaa vector adoo ku celcelinaya goos goos ah `n` jeer.
    ///
    /// # Panics
    ///
    /// Shaqadani waa panic haddii awooddu buuxin lahayd.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic oo buux dhaafiyay:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Haddii `n` uu ka weyn yahay eber, waxaa loo kala qaybin karaa sidii `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` waa nambarka ay mataleyso dhanka bidix ee ugu yar ee '1' ee `n`, `rem`-na waa qeybta hartay ee `n`.
        //
        //

        // Adeegsiga `Vec` si aad uhesho `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ku celcelinta waxaa lagu sameeyaa iyadoo la labalaabaayo `buf` ``expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Hadday tahay `m > 0`, waxaa jira xoogaa harsan oo illaa bidix ugu hooseeya '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` wuxuu leeyahay awoodda `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 'expn`) ku celcelinta waxaa lagu sameeyaa iyadoo laga koobiyeeynayo soo noqnoqoshada ugu horeysa ee `rem` ee laga helayo `buf` lafteeda.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Tani waa isweydaarsi la'aan tan iyo `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` waxay lamid tahay `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens jeex ah `T` galay hal qiime ah `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens jeex ah `T` galay hal qiimaha `Self::Output`, gelinaya SEPARATOR siiyey mid kasta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens jeex ah `T` galay hal qiimaha `Self::Output`, gelinaya SEPARATOR siiyey mid kasta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Waxay soo celisaa vector oo ay kujirto nuqul jeex ah oo halbeeg walba lagu sawirayo kiiskiisa sare ee ASCII ee u dhigma.
    ///
    ///
    /// Waraaqaha ASCII 'a' ilaa 'z' waxaa lagu sawiray 'A' ilaa 'Z', laakiin waraaqaha aan ahayn ASCII isma beddelin.
    ///
    /// Si aad u weyneyso qiimaha meesha, isticmaal [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Waxay soo celisaa vector ay kujirto nuqul jeex ah oo halbeeg walba lagu sawirayo kiiskiisa ASCII ee u dhigma.
    ///
    ///
    /// warqado ASCII 'A' in 'Z' waxaa baa'bin in 'a' in 'z', laakiin waraaqaha non-ASCII waa iska beddelin.
    ///
    /// Si loo yareeyo qiimaha meesha ku yaal, isticmaal [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kordhinta traits ee kalagoynta noocyada xogta gaarka ah
////////////////////////////////////////////////////////////////////////////////

/// Caawiyaha trait loogu talagalay [`[T]: : concat`]](jeexjeex::concat).
///
/// Note: `Item` nooca dhimaya ka in aan loo isticmaalin trait this, laakiin waxay u saamaxdaa impls inay u badan generic.
/// La'aanteed, waxaan helnaa qaladkan:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Tani waa sababta oo ah waxaa jiri kara noocyada `V` oo leh waxyaabo badan oo `Borrow<[_]>` ah, sida noocyo badan oo `T` ah ayaa lagu dabaqi doonaa:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nooca ka dhashay isku dhafka kadib
    type Output;

    /// Fulinta [`[T]: : concat`](jeexjeexan::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Gargaare trait for [`[T]: : join`](jeex::biiro)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nooca ka dhashay isku dhafka kadib
    type Output;

    /// Hirgelinta [`[T]: : ku biiro]](gooye::ku biir)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Fulinta Heerarka trait ee xaleefyada
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ku rid wax kasta oo bartilmaameedka ah oo aan dib loo qori doonin
        target.truncate(self.len());

        // target.len <= self.len sababtuna tahay truncate-ka kor ku xusan, markaa googo'yada halkan ku yaal ayaa had iyo jeer xaddidan.
        //
        let (init, tail) = self.split_at(target.len());

        // dib u isticmaal qiimaha allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Geli `v[0]` taxane horay loo kala saaray `v[1..]` si markaa dhammaan `v[..]` u kala soocnaato.
///
/// Tani waa subroutine muhiim u ah nooca gelinta.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Waxaa jira seddex qaab oo loo hirgaliyo galinta halkan:
            //
            // 1. Isweydaarso walxaha ku dhow ilaa midka ugu horreeya uu gaadho meeshii u dambaysay.
            //    Si kastaba ha noqotee, qaabkan waxaan u guurineynaa xogta inta ka badan inta lagama maarmaanka u ah.
            //    Haddii cunsurradu yihiin qaabdhismeedyo waaweyn (kharashna lagu koobiyo), habkani waa gaabinayaa.
            //
            // 2. Kicin ilaa meesha saxda ah ee curiyaha koowaad laga helo.
            // Kadib u wareeji canaasiirta ku guuleysata si ay boos ugu helaan ugu dambeyntiina u dhig godka haray.
            // Tani waa hab wanaagsan.
            //
            // 3. Nuqul curiyaha koowaad ku beddel doorsoome ku meelgaar ah.Ilmee illaa meesha saxda ah ee laga helayo.
            // Markaan sii soconno, nuqul walxo kasta oo la soo maray ku soo guuri booska ka horreeya.
            // Ugu dambeyn, nuqul ka soo qaad doorsoomaha ku meel gaarka ah godka haray.
            // Habkani waa mid aad u wanaagsan.
            // Benchmarks waxay muujiyeen waxqabad waxoogaa kafiican qaabkii 2aad.
            //
            // Dhammaan hababka ayaa loo calaamadeeyay, kii 3aadna wuxuu muujiyay natiijooyinka ugu fiican.Marka waxaan dooranay midkaas.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Xaaladda dhexe ee habka gelinta waxaa had iyo jeer la socda `hole`, oo u adeegta laba ujeedo:
            // 1. Wuxuu ka ilaaliyaa sharafta `v` panics gudaha `is_less`.
            // 2. Buuxi godka haray ee `v` dhamaadka.
            //
            // Amniga Panic:
            //
            // Haddii `is_less` panics meel kasta oo hawshu socoto, `hole` ayaa hoos u dhici doonta oo buuxin doonta godka `v` oo leh `tmp`, sidaas awgeed waxay hubinaysaa in `v` ay wali haysato shay kasta oo ay markii hore si sax ah u qabtay hal jeer.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` hoos ayuu u dhacaa sidaas awgeedna wuxuu nuquliyaa `tmp` godka haray ee `v`.
        }
    }

    // Marka hoos, nuqul ka `src` galay `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Isku darsamida hoos udhaca waxay maamushaa `v[..mid]` iyo `v[mid..]` iyadoo la adeegsanayo `buf` sidii keyd ku meel gaar ah, waxayna ku keydineysaa natiijada `v[..]`.
///
/// # Safety
///
/// Labada jeex waa inay ahaadaan kuwa aan faaruq ahayn oo `mid` waa inay ahaadaan xudduud.
/// Kaydka `buf` waa inuu ahaado mid dheer oo ku filan inuu haysto nuqul jeexa gaagaaban.
/// Sidoo kale, `T` waa inuusan aheyn nooc eber cabbirkiisu dhan yahay.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Nidaamka isku-darka ayaa marka hore nuqul ka dhigaya socodka gaaban illaa `buf`.
    // Kadibna waxay raad raacaysaa orodkii dhowaan la soo guuriyay iyo kii sii dheeraa ee horay u sii soconaya (ama gadaal), iyagoo isbarbardhigaya astaamahooda soo socda ee aan la cabiraynin oo nuqul ka yar (ama ka weyn) ku galinaya `v`.
    //
    // Isla marka socodka gaaban uu si buuxda u dhammaado, hawsha ayaa la qabtaa.Haddii orodka dheeraa marka hore la cuno, markaa waa inaan nuqul ka dhignaa wax kasta oo ka dhiman orodka gaaban godka haray ee `v`.
    //
    // Xaaladda dhexe ee hawsha waxaa had iyo jeer la socda `hole`, oo u adeegta laba ujeedo:
    // 1. Wuxuu ka ilaaliyaa sharafta `v` panics gudaha `is_less`.
    // 2. Buuxiyo daloolka haray `v` haddii baxsad dheer uu marka hore wada baabbi'iyey.
    //
    // Amniga Panic:
    //
    // Haddii `is_less` panics meel kasta oo ay hawshu marayso, `hole` ayaa hoos u dhici doonta oo buuxin doonta godka `v` oo leh xadka aan la qaadan karin ee `buf`, sidaas awgeedna la hubinayo in `v` ay wali hayso shay kasta oo ay markii hore si sax ah u qabtay hal jeer.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Socodka bidix ayaa ka gaaban.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Marka hore, tilmaamayaashaani waxay tilmaamayaan bilowga qaababkooda.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Isticmaal dhinaca yar.
            // Haddii ay siman tahay, doorbid bidixda bidix si aad u ilaaliso xasilloonida.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Orodka saxda ah ayaa ka gaaban.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Markii hore, kuwaas oo tilmaamo ka tilmaansataan ee la soo dhaafay darafyadiisa Arrays ay.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Isticmaal dhinaca weyn.
            // Haddii ay siman tahay, doorbid orodka saxda ah si loo ilaaliyo xasilloonida.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Ugu dambeyntiina, `hole` ayaa hoos u dhacay.
    // Haddii orodka gaaban aan si buuxda loo wada cunin, wax kasta oo ka hadha ayaa hadda loo guurin doonaa godka `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Markii lagaa tuuro, nuqulo xaddiga `start..end` illaa `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ma aha nooc eber ah, markaa waa caadi in loo qaybiyo cabbirkiisa.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Isugeynta noocaan ah waxay amaahataa fikrado qaar (laakiin dhammaantood) fikradaha laga helo TimSort, oo si faahfaahsan loogu sharaxay [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algorithm wuxuu tilmaamayaa xigashooyin si adag u soo degaya iyo kuwa aan soo dhaadhacayn, kuwaas oo loogu yeedho orod dabiici ah.Waxaa jira xirmooyin sugitaanno aan wali la mideynin.
/// Orod kasta oo cusub oo la helo waxaa lagu riixayaa xargaha, ka dibna qaar ka mid ah labada orod ee isku dhow ayaa la isku darayaa illaa labadan is beddel la'aan ay ku qanacsan yihiin:
///
/// 1. wixii `i` kasta ah ee ku jira `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. wixii `i` kasta ah ee ku jira `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Iskuduwayaashu waxay hubiyaan in wadarta waqtiga socodku yahay *O*(*n*\*log(* n*))-kii ugu xumaa.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Xaleef ilaa karaa dhererka this soocaa isticmaalaya sort galinta.
    const MAX_INSERTION: usize = 20;
    // Socod aad u gaaban ayaa lagu dheereeyaa iyadoo la adeegsanayo nooca gelinta si loo qiyaaso uguyaraan cunsurradan badan.
    const MIN_RUN: usize = 10;

    // Kala soocidu malahan dabeecad macno leh noocyada qiyaasta eber-ka ah.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Nidaamyada gaagaaban ayaa lagu kala soocayaa iyada oo loo marayo nooc gelinta si looga fogaado qoondaynta.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // U qoondee bakhaar si aad ugu isticmaasho xusuusta xoqida.Waxaan ilaalineynaa dhererka 0 si aan ugu sii heysano nuqulada gacmeed ee waxyaabaha ku jira `v` anaga oo aan qatar u gelinaynin in doriyeyaasha ay ku sii socdaan nuqulo hadii `is_less` panics.
    //
    // Markaad iskudareyso labo orod oo kaladuwan, keydkaan wuxuu hayaa nuqul kayar oo gaagaaban, kaasoo had iyo jeer yeelan doona dherer ugu badnaan `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Si loo aqoonsado orodka dabiiciga ee `v`, gadaal ayaan gadaal ugu laabaneynaa.
    // Taasi waxay umuuqataa inay tahay go'aan qariib ah, laakiin tixgaliso xaqiiqda ah in iskudhafka badanaa uu aado dhanka kasoo horjeedka (forwards).
    // Marka loo eego jaangooyooyinku, ku biiritaanka xagga hore ayaa xoogaa ka dheereeya ku biirista gadaal.
    // Gebogebo, aqoonsiga socodsiinta gadaal u socodka gadaal ayaa hagaajineysa waxqabadka.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Raadi orodka xiga ee dabiiciga ah, oo dib u rog haddii uu si adag u soo degayo.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Gali waxyaabo kale oo dheeri ah orodka haddii ay gaaban tahay.
        // Nooca gelinta ayaa ka dhakhso badan midowga isku xigxiga taxanaha gaagaaban, marka tani waxay si weyn kor ugu qaadeysaa waxqabadka.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Ku riix orodkan dusha sare.
        runs.push(Run { start, len: end - start });
        end = start;

        // Isku darsamaan qaar ka mid ah tartannada ku dhow si aad u qanciso kuwa aan is beddelin.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Ugu dambeyntiina, dhab ahaan hal orod waa inuu ku sii jiraa xayndaabka.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Baadhitaanka isku-darka orodka oo tilmaamaya labada lamaane ee soo socda ee isku-biirista.
    // Si gaar ah si gaar ah, haddii `Some(r)` la soo celiyo, taasi macnaheedu waa `runs[r]` iyo `runs[r + 1]` waa in la isku daraa marka xigta.
    // Haddii algorithm ay tahay inuu sii wado dhismaha socod cusub, `None` waa la soo celiyey.
    //
    // TimSort wuxuu caan ku yahay fulintiisa buggy, sida halkan lagu sharaxay:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Dulucda sheekadu waa: waa inaan ku qasabnaa kuwa aan wax iska bedelin ee afarta ugu sareysa ee is dul saaran.
    // Ku qasbintooda sedexda ugu sareysa kuma filna in la hubiyo in isbadallayaashu ay wali sii heyn doonaan *dhamaan* orodka safka.
    //
    // Shaqadani waxay si sax ah u hubisaa isbeddellada afarta orod ee ugu sareysa.
    // Intaa waxaa sii dheer, haddii orodka ugu sarreeya uu ka bilowdo tusmada 0, waxay had iyo jeer dalban doontaa hawlgal isku-dhafan illaa inta duubku si buuxda u burburayo, si loo dhammaystiro nooca.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}