//! Tilmaamayaasha tirinta tixraaca tixraaca ee hal-dunta ah.'Rc' wuxuu u taagan yahay 'Tixraac
//! Counted'.
//!
//! Nooca [`Rc<T>`][`Rc`] wuxuu bixiyaa lahaansho wadaag ah qiimaha nooca `T`, oo loogu qoondeeyay taalada.
//! U yeedhista [`clone`][clone] ee [`Rc`] waxay soo saartaa tilmaame cusub oo isla qoondaynta ku jira.
//! Marka tilmaamaha ugu dambeeya ee [`Rc`] ee qoondaynta la baabi'iyo, qiimaha ku kaydsan qoondayntaas (oo badanaa loo yaqaan "inner value") ayaa sidoo kale hoos u dhacaya.
//!
//! Tixraacyada la wadaago ee Rust uma oggolaanayaan isku beddelid asal ahaan, iyo [`Rc`] ma aha mid ka reeban: guud ahaan ma heli kartid tixraac isbeddel ah oo ku saabsan wax gudaha [`Rc`] ah.
//! Haddii aad u baahan tahay is-beddelid, geli [`Cell`] ama [`RefCell`] gudaha [`Rc`];fiiri [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] wuxuu adeegsadaa tirinta tixraaca non-atomiga.
//! Tani waxay ka dhigan tahay in dusha sare uu aad u hooseeyo, laakiin [`Rc`] lama soo diri karo inta udhaxeysa dunta, sidaas darteedna [`Rc`] ma hirgaliyo [`Send`][send].
//! Natiija ahaan, isku-duwaha 'Rust' wuxuu hubin doonaa *waqtiga la soo uruurinayo* inaadan diri doonin ['Rc`] s inta u dhexeysa dunta.
//! Haddii aad u baahan tahay tirinta badan, tirinta tixraaca atomiga, isticmaal [`sync::Arc`][arc].
//!
//! Habka [`downgrade`][downgrade] waxaa loo isticmaali karaa in lagu abuuro tilmaame [`Weak`] aan lahayn.
//! Tilmaamaha [`Weak`] wuxuu noqon karaa ['casriyayn'][casriyayn] d d ah [`Rc`], laakiin kani wuxuu kusoo laaban doonaa [`None`] haddii qiimaha ku keydsanaanta qoondaynta horay loo daadiyay.
//! Si kale haddii loo dhigo, tilmaamayaasha `Weak` ma sii hayaan qiimaha ku jira qoondaynta;si kastaba ha noqotee, iyagu *way* ilaaliyaan qoondaynta (dukaanka taakulaynta ee gudaha).
//!
//! Wareeg u dhexeeya tilmaamayaasha [`Rc`] waligood lama kala bixin doono.
//! Sababtaas awgeed, [`Weak`] waxaa loo isticmaalaa in lagu jebiyo wareegyada.
//! Tusaale ahaan, geedku wuxuu yeelan karaa tilmaamayaal xoog leh oo ah [`Rc`] oo laga helo nodeodeyaasha waalidka ilaa carruurta, iyo tilmaamaha [`Weak`] ee carruurta dib loogu celiyo waalidkood.
//!
//! `Rc<T>` si otomaatig ah uga gaabinta `T` (iyada oo loo marayo [`Deref`] trait), markaa waad wici kartaa 'hababka T` ee qiimaha nooca [`Rc<T>`][`Rc`].
//! Si looga fogaado isku dhaca magacyada hababka T`, hababka [`Rc<T>`][`Rc`] lafteeda waa shaqooyin la xiriira, oo loo yaqaan [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>Fulinteeda 'traits' sida `Clone` sidoo kale waxaa loogu yeeri karaa iyadoo la adeegsanayo jumlo aqoon buuxda u leh.
//! Dadka qaarkiis waxay doorbidaan inay adeegsadaan adeegsi buuxda oo aqoon u leh, halka qaar kalena doorbidaan adeegsiga habka loo yaqaan 'Syntax'.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Qaaciddada habka loo yaqaan 'Method-call'
//! let rc2 = rc.clone();
//! // Qaamuus buuxa oo aqoon leh
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] si otomaatig ah ugama dhigeyso `T`, maxaa yeelay qiimaha gudaha ayaa laga yaabaa in mar horeba hoos loo dhigay.
//!
//! # Tixraacyada dharka
//!
//! Abuuritaanka tixraac cusub oo la mid ah qoondaynta tixraaca jira ee tilmaanta ayaa la sameeyaa iyadoo la adeegsanayo `Clone` trait oo loo hirgaliyay [`Rc<T>`][`Rc`] iyo [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Labada qoraal ee hoose waxay u dhigmaan.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a iyo b labaduba waxay tilmaamayaan isla goobta xusuusta sida foo.
//! ```
//!
//! Qaabka loo yaqaan `Rc::clone(&from)` syntax waa kan ugu sarbeebta sarreysa maxaa yeelay wuxuu si cad u gudbinayaa macnaha lambarka.
//! Tusaalaha kor ku xusan, Saan taas oo ka dhigaysa in ay u fududahay in ay arkaan in code this abuuraya tixraaca cusub halkii ay kaga dayanayaan content oo dhan foo.
//!
//! # Examples
//!
//! Tixgeli dhacdo halka aaladda 'Gadget`s' ay leedahay `Owner` la siiyay.
//! Waxaan rabnaa in aan leenahay `dhibic Gadget`s ay `Owner`.Tan kuma samayn karno lahaansho gaar ah, maxaa yeelay in ka badan hal qalab ayaa laga yaabaa inay ka tirsan yihiin isla `Owner`.
//! [`Rc`] wuxuu noo ogolaanayaa inaan wadaagno `Owner` inta udhaxeysa ``Gadget`s '' badan, oo `Owner` ay wali sii qoondeysay ilaa iyo inta dhibco `Gadget` ah ay ku jiraan.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... beeraha kale
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... beeraha kale
//! }
//!
//! fn main() {
//!     // Abuur tixraac tixraac ah `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Abuur `` Qalabka '' lahaanshaha `gadget_owner`.
//!     // Cloning `Rc<Owner>` noo siinayaa pointer cusub u qoondeynta `Owner` isla, incrementing count tixraaca ee geedi socodka ah.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Tuur beddelkeenna deegaanka ee `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // In kasta oo aan ka tagnay `gadget_owner`, weli waxaan awoodnaa inaan daabacno magaca `Owner` ee 'Qalabka' Qalabka.
//!     // Tani waa sababta oo ah waxaan kaliya hoos u dhignay hal `Rc<Owner>`, ma ahan `Owner` ay tilmaamayso.
//!     // Ilaa iyo inta ay jiraan `Rc<Owner>` kale oo tilmaamaya isla qoondada `Owner`, way sii noolaan doontaa.
//!     // Saadaasha goobta `gadget1.owner.name` way shaqeysaa maxaa yeelay `Rc<Owner>` si otomaatig ah ayuu uga gaabiyaa `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Dhamaadka shaqada, `gadget1` iyo `gadget2` waa la baabi'iyay, iyagaana leh tixraacyadii ugu dambeeyay ee la tiriyey ee ku saabsan `Owner`-keena.
//!     // Ninka Gadget hadda waa la baabi'iyaa sidoo kale.
//!     //
//! }
//! ```
//!
//! Haddii shuruudahayagu isbeddelaan, oo aan sidoo kale u baahanahay inaan awoodno inaan ka gudubno `Owner` illaa `Gadget`, waxaan la kulmi doonnaa dhibaatooyin.
//! Tilmaamaha [`Rc`] ee ka socda `Owner` illaa `Gadget` wuxuu soo bandhigayaa meerto.
//! Tani waxay ka dhigan tahay in tixraacyadooda tixraaca aysan weligood gaari karin 0, qoondayntuna weligeed lama baabi'in doono:
//! xusuus daadatay.Si tan looga gudbo, waxaan adeegsan karnaa tilmaamayaasha [`Weak`].
//!
//! Rust dhab ka dhigayaa xoogaa adag tahay in la soo saaro loop this in meesha ugu horeysa.Si loo soo afjaro la laba qiyamka in dhibic kasta oo kale, mid ka mid ah uu u baahan yahay in uu noqdo mutable.
//! Tani way adagtahay maxaa yeelay [`Rc`] waxay xoojisaa nabadgelyada xusuusta iyadoo la siinayo kaliya tixraacyo la wadaago oo ku saabsan qiimaha ay duuban tahay, kuwanna ma oggola isbeddel toos ah.
//! Waxaan u baahanahay inaan ku soo koobno qayb ka mid ah qiimaha aan dooneyno inaan isku beddelno [`RefCell`], kaas oo bixiya * isbeddel gudaha ah: hab lagu gaaro isbadal ku yimaada tixraaca la wadaago.
//! [`RefCell`] waxay fulisaa xeerarka amaahda ee Rust waqtiga shaqada.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... beeraha kale
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... beeraha kale
//! }
//!
//! fn main() {
//!     // Abuur tixraac tixraac ah `Owner`.
//!     // Xusuusnow in aan dhignay 'vector' Milkiilaha 'Gadget`s gudaha `RefCell` si aan ugu badalno tixraac wadaag ah.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Abuur `` Qalabka '' ka tirsan `gadget_owner`, sidii hore.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Kudar `` Qalabka '' x00X-kooda.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` amaah firfircoon halkan ayuu ku egyahay.
//!     }
//!
//!     // Iterate badan our `Gadget`s, ka soo daabicidda faahfaahintooda.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` waa `Weak<Gadget>`.
//!         // Maaddaama tilmaamayaasha `Weak` aysan damaanad qaadi karin qoondaynta wali way jirtaa, waxaan u baahan nahay inaan wacno `upgrade`, oo soo celiya `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Xaaladdan oo kale waan ognahay in qoondayntu wali jirto, sidaa darteed waxaan si fudud u `unwrap` ee `Option` ah.
//!         // Barnaamij aad u dhib badan, waxaad u baahan kartaa wax ka qabashada qaladka nimcada leh ee natiijada `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Dhamaadka shaqada, `gadget_owner`, `gadget1`, iyo `gadget2` waa la baabi'iyay.
//!     // Hadda ma jiraan tilmaamayaal xoog leh oo ah (`Rc`) qalabka, sidaas darteed waa la baabi'iyay.
//!     // Tani waxay eber ka dhigaysaa tixraaca ku saabsan Gadget Man, sidaa darteed isagana waa la baabi'inayaa sidoo kale.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Tani waa repr(C) illaa future-caddeyn ka dhan ah dib-u-soo-noqoshada berrinka, taas oo faragelinaysa haddii kale [into|from]_raw() oo ammaan ah oo noocyada gudaha ah ee la gudbi karo.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Tilmaame tixraac tirinta hal-dun ah.'Rc' wuxuu u taagan yahay 'Tixraac
/// Counted'.
///
/// Ka eeg [module-level documentation](./index.html) wixii faahfaahin dheeraad ah.
///
/// Hababka soo jireenka ah ee `Rc` dhammaantood waa hawlo la xidhiidha, taas oo macnaheedu yahay inaad u yeedhayso iyaga tusaale ahaan, [`Rc::get_mut(&mut value)`][get_mut] halkii laga odhan lahaa `value.get_mut()`.
/// Tani waxay ka hortageysaa isku dhacyada qaababka nooca gudaha ee `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // unsafety Tani waa ok maxaa yeelay, halka RC this waa nool yahay waxaana loo ballan qaaday in tilmaamaha hoose waa ansax ah.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Wuxuu dhisaa `Rc<T>` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Waxaa jira tilmaam liita oo daciif ah oo ay leeyihiin dhammaan tilmaamayaasha xoogga leh, taas oo hubineysa in burburiyaha daciifka ahi uusan waligiis ka sii deyn doonin qoondaynta inta uu burburiyuhu xoogsan yahay, xitaa haddii tilmaamaha daciifka ah lagu keydiyo gudaha midka adag.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Wuxuu dhisaa `Rc<T>` cusub adoo adeegsanaya tixraac daciif ah oo naftiisa ah.
    /// Isku dayga inaad cusboonaysiiso tixraaca daciifka ah ka hor intaanay hawshani soo laaban waxay keenaysaa qiime `None` ah.
    ///
    /// Si kastaba ha noqotee, tixraaca daciifka ah waxaa laga yaabaa in si xor ah loo duubay oo loo kaydiyo si loo isticmaalo wakhti dambe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... beero badan
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Gudaha ku dhis gobolka "uninitialized" adigoo tixraacaya hal daciif.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Waa muhiim inaanaan ka tanaasulin lahaanshaha tilmaamaha daciifka ah, haddii kale xusuusta waxaa laga yaabaa inay xoroobaan waqtiga `data_fn` soo laabanayo.
        // Haddii aan runtii dooneynay inaan ka gudubno lahaanshaha, waxaan abuuri karnaa tilmaame daciif ah oo dheeri ah nafteena, laakiin tani waxay sababi doontaa cusbooneysiin dheeri ah oo ku saabsan tirinta tixraaca daciifka ah ee laga yaabo inaan loo baahnayn haddii kale.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Tixraacyada adag waa inay si wada jir ah u yeeshaan tixraac daciif ah oo la wadaago, marka ha u horseedin burburiyaha tixraackeenna daciifka ah ee hore.
        //
        mem::forget(weak);
        strong
    }

    /// Wuxuu ku dhisaa `Rc` cusub waxyaalaha aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Wuxuu dhisaa `Rc` cusub oo leh waxyaalo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo bayooyinka `0`.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Waxay dhistaa `Rc<T>` cusub, oo soo celisa qalad haddii qoondayntu guul darreysato
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Waxaa jira tilmaam liita oo daciif ah oo ay leeyihiin dhammaan tilmaamayaasha xoogga leh, taas oo hubineysa in burburiyaha daciifka ahi uusan waligiis ka sii deyn doonin qoondaynta inta uu burburiyuhu xoogsan yahay, xitaa haddii tilmaamaha daciifka ah lagu keydiyo gudaha midka adag.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Wuxuu dhisaa `Rc` cusub oo leh waxyaabo aan la ogeyn, isagoo soo celinaya qalad haddii qoondaynta ay ku guuldareysato
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Waxay dhistaa `Rc` cusub oo leh waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes, oo soo celinaysa qalad haddii qoondayntu ay ku fashilanto
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Wuxuu dhisaa `Pin<Rc<T>>` cusub.
    /// Haddii `T` uusan hirgelin `Unpin`, markaa `value` waxaa lagu dhejin doonaa xusuusta oo aan la dhaqaajin karin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Soocelinta qiimaha gudaha, haddii `Rc` uu leeyahay hal tixraac adag.
    ///
    /// Haddii kale, [`Err`] waxaa lagu soo celiyaa isla `Rc` ee lagu gudbiyay.
    ///
    ///
    /// Tani way guuleysan doontaa xitaa haddii ay jiraan tixraacyo daciif ah oo muuqda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // nuqul shayga ku jira

                // U muuji Weaks in aan lagu dallacin karin hoos u dhigista tirinta xoogga leh, ka dibna ka saar tilmaamaha muuqda ee "strong weak" iyadoo sidoo kale la maareynayo caqliga hoos u dhaca iyada oo la farsameynayo been abuur Weak.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Waxay dhistaa jeex cusub oo tixraac lagu tiriyay oo ay ku jiraan waxyaabo aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Waxay dhistaa jeex cusub oo tixraac lagu tiriyay oo ay ku jiraan waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Ku beddelaya `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo waca inuu dammaanad qaado in qiimaha gudaha uu dhab ahaantii ku jiro xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Ku beddelaya `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo waca inuu dammaanad qaado in qiimaha gudaha uu dhab ahaantii ku jiro xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Wuxuu adeegsadaa `Rc`, isagoo soo celinaya tilmaamaha duuban.
    ///
    /// Si looga fogaado xusuusta daadata tilmaameha waa in dib loogu celiyaa `Rc` iyadoo la adeegsanayo [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Waxay siisaa tilmaame cayriin xogta.
    ///
    /// Tirinta wax saameyn ah kuma lahan oo `Rc` lama cunin.
    /// Tilmaameyuhu wuxuu shaqeynayaa ilaa iyo inta ay jiraan xisaab celin xoog leh oo ku jirta `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // BADBAADADA: Tani ma mari karto Deref::deref ama Rc::inner maxaa yeelay
        // Tan waxaa looga baahan yahay inay sii haysato xaqiijinta raw/mut sida tusaale
        // `get_mut` ku qori karaa tilmaamaha ka dib marka Rc-ka laga soo kabsado illaa `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Wuxuu ka dhisaa `Rc<T>` tilmaame cayriin.
    ///
    /// Tilmaamaha cayriin waa inuu horey ugu soo celiyey wicitaan [`Rc<U>::into_raw`][into_raw] halkaasoo `U` ay tahay inuu lahaado cabir iyo isleeg sida `T`.
    /// Tani waa wax aan run ahayn haddii `U` ay tahay `T`.
    /// Xusuusnow haddii `U` uusan ahayn `T` laakiin uu isku cabir iyo is waafajin yahay, tani asal ahaan waa sida gudbinta tixraacyada noocyada kala duwan.
    /// Eeg [`mem::transmute`][transmute] si aad u hesho macluumaad dheeraad ah oo ku saabsan waxa xaddidaadda khuseeya kiiskan.
    ///
    /// Isticmaalaha `from_raw` waa inuu hubiyaa in qiimo gaar ah oo ah `T` hal mar oo keliya hoos loo dhigay.
    ///
    /// Shaqadani waa mid aan amaan ahayn sababta oo ah adeegsiga aan habooneyn wuxuu u horseedi karaa xusuusta amaan la'aan, xitaa haddii `Rc<T>` soo laabtay aan waligiis la helin.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Dib ugu noqo `Rc` si looga hortago daadashada.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Wicitaano dheeri ah oo loo diro `Rc::from_raw(x_ptr)` waxay noqon doonaan kuwo aan aamin ahayn.
    /// }
    ///
    /// // Xusuusta ayaa la fasaxay markii `x` uu ka baxay baaxadda kor ku xusan, markaa `x_ptr` hadda wuu sii fiiqmayaa!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Dib uga noqo dejinta si aad u hesho RcBox asalka ah.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Waxay u sameysaa tilmaame cusub [`Weak`] qeybintaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Hubi in annaga oo aan abuuro tabar soo laadlaada
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Wuxuu helayaa tirada tilmaamayaasha [`Weak`] ee qoondayntan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Waxay helaysaa tirada tilmaamayaasha (`Rc`) ee xoogan qoondayntan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Sooceliyaa `true` haddii aysan jirin tilmaamayaal kale oo ah `Rc` ama [`Weak`] qoondayntaan.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Ku soo celiyaa tixraac la beddeli karo `Rc` la siiyay, haddii aysan jirin tilmaamayaal kale oo ah `Rc` ama [`Weak`] isla qoondayntaas.
    ///
    ///
    /// Soocelinta [`None`] haddii kale, maxaa yeelay ammaan ma ahan in la beddelo qiimaha la wadaago.
    ///
    /// Sidoo kale eeg [`make_mut`][make_mut], kaas oo [`clone`][clone] ka dhigi doona qiimaha gudaha marka ay jiraan tilmaamayaal kale.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Ku soo celiyaa tixraac la beddeli karo `Rc` la siiyay, iyada oo aan la hubin.
    ///
    /// Sidoo kale eeg [`get_mut`], oo amaan ah oo sameeya jeegag haboon.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Tilmaamayaal kasta oo kale oo ah `Rc` ama [`Weak`] isla qoondayntaas waa inaan laga gudbin muddada muddada amaahda la soo celiyey.
    ///
    /// Tani waa wax aan macquul ahayn haddii aysan jirin tilmaamahan oo kale, tusaale ahaan isla markiiba ka dib `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Waxaan ka taxaddarnaa inaan * * abuurin tixraac daboolaya meelaha "count", maxaa yeelay taasi waxay khilaafsan tahay marin u helka tirooyinka tixraaca (tusaale.
        // by `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Soocelinayaa `true` haddii labada ``Rc`s ay tilmaamayaan isla qoondaynta (xidid lamid ah [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Waxay ka dhigaysaa tixraac la beddeli karo `Rc` la siiyay.
    ///
    /// Haddii ay jiraan tilmaamo kale `Rc` in qoondaynta isla, ka dibna `make_mut` [`clone`] doonaa qiimaha hoose si qoondaynta cusub si loo hubiyo lahaanshaha gaar ah.
    /// Tan waxaa sidoo kale loo yaqaan 'clone-on-write'.
    ///
    /// Haddii aysan jirin tilmaamayaal kale oo `Rc` ah qoondayntaan, markaa tilmaamayaasha [`Weak`] ee qoondayntani waa la kala saari doonaa.
    ///
    /// Sidoo kale eeg [`get_mut`], oo fashilmi doona halkii aad ka ahaan lahayd cloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Wax isku darsan doonin
    /// let mut other_data = Rc::clone(&data);    // Ma isku dhejin doonaan xogta gudaha
    /// *Rc::make_mut(&mut data) += 1;        // Clones xogta gudaha
    /// *Rc::make_mut(&mut data) += 1;        // Wax isku darsan doonin
    /// *Rc::make_mut(&mut other_data) *= 2;  // Wax isku darsan doonin
    ///
    /// // Hadda `data` iyo `other_data` ayaa tilmaamaya qoondaynno kala duwan.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] tilmaamayaasha ayaa lakala saari doonaa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta xogta, waxaa jira Rcs kale.
            // Sii-u-qoondee xusuusta si aad ugu oggolaato qorista qiimaha cufan si toos ah.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kaliya waa xadi karaa xogta, waxa kaliya ee haray waa Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ka saar ficil xoog leh oo daciif ah (looma baahna in lagu farsameeyo been abuur Weak ah-waxaan ognahay in Weaks kale ay nadiif noo ahaan karaan)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Amni darradan waa ok maxaa yeelay waxaa naloo ballan qaaday in tilmaamaha la soo celiyey uu yahay tilmaamaha *kaliya* ee weligiis lagu soo celin doono T.
        // Tixraac tixraaceena waa la damaanad qaaday inuu yahay 1 markan, waxaana ubaahanay `Rc<T>` lafteeda inay noqoto `mut`, marka waxaan soo celinaynaa tixraaca kaliya ee suuragalka ah ee qoondaynta.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Isku dayga inaad hoos u dhigto `Rc<dyn Any>` nooca shubka ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Wuxuu u qoondeeyaa `RcBox<T>` oo leh boos ku filan qiime gudaha ah oo suuragal ah in aan la qiyaasi karin halkaasoo qiimaha uu ku yaal qaabka loo bixiyay.
    ///
    /// Shaqada `mem_to_rcbox` waxaa lagu magacaabaa la pointer xogta iyo waa in dib u noqon a (kara baruurta)-pointer for `RcBox<T>` ah.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Xisaabi khariidad adoo isticmaalaya qaabeynta qiimaha la siiyay.
        // Markii hore, qaabeynta waxaa lagu xisaabin jiray muujinta `&*(ptr as* const RcBox<T>)`, laakiin tani waxay abuurtay tixraac qaldan (eeg #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Qoondaysaa `RcBox<T>` la meel ku filan qiimaha a suurto gal-unsized hoose halkaas oo qiimaha uu leeyahay qaabka bixiyo, soo laabtay qalad haddii qoondaynta guuldareysto.
    ///
    ///
    /// Shaqada `mem_to_rcbox` waxaa lagu magacaabaa la pointer xogta iyo waa in dib u noqon a (kara baruurta)-pointer for `RcBox<T>` ah.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Xisaabi khariidad adoo isticmaalaya qaabeynta qiimaha la siiyay.
        // Markii hore, qaabeynta waxaa lagu xisaabin jiray muujinta `&*(ptr as* const RcBox<T>)`, laakiin tani waxay abuurtay tixraac qaldan (eeg #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // U qoondee qaabeynta.
        let ptr = allocate(layout)?;

        // Bilow RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Wuxuu u qoondeeyaa `RcBox<T>` oo leh boos ku filan qiime gudaha ah oo aan la qiyaasi karin
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // U qoondee `RcBox<T>` adoo isticmaalaya qiimaha la siiyay.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nuqul ku qiimee sida bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Xoreyso qoondaynta adigoon hoos u dhigin waxyaabaha ku jira
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Wuxuu u qoondeeyay `RcBox<[T]>` dhererka la siiyay.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Nuqul ka soo jeex jeex jeexi qayb cusub oo loo qoondeeyay Rc <\[T\]>
    ///
    /// Amaan maleh maxaa yeelay qofka soo wacaya waa inuu ama lahaadaa lahaanshaha ama xiraa `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Wuxuu ka dhisayaa `Rc<[T]>` qalabka wax soosaara ee lagu yaqaan inuu cabbirkiisu le'eg yahay.
    ///
    /// Dabeecadda lama qeexin haddii cabbirka uu qaldan yahay.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic ilaali inta lagu gudajiraayo walxaha T.
        // Haddii ay dhacdo panic, canaasiirta lagu qoray RcBox-ka cusub waa la tuurayaa, ka dibna xusuusta ayaa la sii daynayaa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tilmaame-baraha koowaad
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Dhamaan way cadahay.Iska ilow waardiyaha si uusan u sii daynin RcBox cusub.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Takhasuska trait waxaa loo adeegsaday `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Dhibcaha `Rc`.
    ///
    /// Tani waxay yareyn doontaa tirinta tixraaca adag.
    /// Haddii tirinta tixraaca adag ay gaarto eber markaa tixraacyada kale ee kaliya (haddii ay jiraan) waa [`Weak`], sidaas darteed waxaan `drop` u nahay qiimaha gudaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Waxba ma daabacdo
    /// drop(foo2);   // Daabacaadda "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // burburi shayga ku jira
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ka saar tilmaamaha muuqaalka "strong weak" hadda markaan burburinay waxyaabaha ku jira.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Ka dhigayaa Gadzhiyev oo ka mid ah tilmaamaha `Rc` ah.
    ///
    /// Tani waxay ku abuureysaa tilmaame kale isla qoondaynta, kordhinta tirinta tixraaca adag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Waxay abuurtaa `Rc<T>` cusub, oo leh qiimaha `Default` ee `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Burcad si aad ugu oggolaato takhasuska `Eq` inkasta oo `Eq` uu leeyahay qaab.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Waxaan halkaan ku sameyneynaa takhasuskaan, mana ahan sida ugu wanaagsan ee wax looga qaban karo `&T`, maxaa yeelay waxay si kale ugu darsan laheyd kharash dhamaan baaritaanada sinnaanta ee ku saabsan refs.
/// Waxaan u qaadaneynaa in ``Rc`s '' loo adeegsado in lagu keydiyo qiimayaal waaweyn, oo gaabis ku ah isku dheelitirnaanta, laakiin sidoo kale culus in la hubiyo sinnaanta, taas oo keeneysa in qarashkan uu si fudud ku bixiyo.
///
/// Waxay sidoo kale u badan tahay inay yeelato laba dhejis oo `Rc` ah, oo tilmaamaya isla qiime, in ka badan laba&T`s.
///
/// Waxaan tan sameyn karnaa oo keliya markii `T: Eq` uu yahay `PartialEq` laga yaabo inuu si ula kac ah u noqnoqon karin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Sinnaanta laba ``Rc`s.
    ///
    /// Laba ``Rc`s '' waa u siman yihiin haddii qiimayaashooda gudaha ay siman yihiin, xitaa haddii ay ku keydsan yihiin qoondayn kala duwan.
    ///
    /// Hadday `T` sidoo kale fuliso `Eq` (tilmaamaysa falcelin la'aanta sinnaanta), laba `` Rc '' oo tilmaamaya isla qoondayntu marwalba way siman yihiin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Sinnaan la'aanta laba ``Rc`s.
    ///
    /// Laba `` Rc '' waa sinnaan haddii qiyamkooda gudaha uusan sinnayn.
    ///
    /// Haddii `T` sidoo kale fuliyo `Eq` (oo muujinaysa falcelin la'aanta sinnaanta), laba `` Rc '' oo tilmaamaya isla qoondayntu marna sinnaan ma aha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Isbarbardhig qayb ahaan ah laba ``Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `partial_cmp()` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ka yar-barbardhigga laba ``Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `<` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'In ka yar ama u dhiganta' isbarbardhigga laba 'Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `<=` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Isbarbardhig ka weyn-labo 'Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `>` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Ka weyn ama u dhigma' isbarbardhigga laba 'Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `>=` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Isbarbardhigga laba ``Rc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `cmp()` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// U qoondee jeex tixraac lagu tiriyay oo ku buuxi alaabada 'v`
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// U qoondee jeex tixraac lagu tiriyay oo ku duub `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// U qoondee jeex tixraac lagu tiriyay oo ku duub `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// U dhaqaaji shay sanduuq leh mid cusub, tixraac la tiriyay, qoondayn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// U qoondee jeex tixraac la tiriyay oo guur waxyaabaha `` v ''.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // U ogolow VEC in ay lacag la'aan ah oo ay xasuusta, laakiin uma ay baabbi'in ku jira
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Waxay ku qaadataa cunsur kasta `Iterator` wuxuuna ku ururiyaa `Rc<[T]>`.
    ///
    /// # Sifooyinka waxqabadka
    ///
    /// ## Kiiska guud
    ///
    /// Xaalada guud, aruurinta `Rc<[T]>` waxaa lagu sameeyaa marka hore aruurinta `Vec<T>`.Taasi waa, marka la qorayo waxyaabaha soo socda:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tani waxay u dhaqantaa sidii inaan u qornay:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Qaybta ugu horreysa ee qoondaynta ayaa halkan ka dhacaysa.
    ///     .into(); // qoondaynta A labaad ee `Rc<[T]>` halkan dhacaya.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tani waxay u qoondeyn doontaa inta jeer ee loo baahdo dhismaha `Vec<T>` ka dibna waxay u qoondeyn doontaa hal mar si loogu beddelo `Vec<T>` `Rc<[T]>`.
    ///
    ///
    /// ## Kiciyayaal dherer la yaqaan ah
    ///
    /// Markuu `Iterator`-kaaga fuliyo `TrustedLen` oo uu cabirkiisu sax yahay, hal qoondeyn ayaa loo sameyn doonaa `Rc<[T]>`.Tusaale ahaan:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Just hal qoondaynta halkan dhacaya.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Takhasuska trait loo adeegsaday aruurinta `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Tani waa kiiska loogu talagalay soosaaraha `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BADBAADADA: Waxaan u baahanahay inaan hubino in soo-jeediyaha uu leeyahay dherer sax ah oo aan leenahay.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Ku noqo hirgelinta caadiga ah.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` waa nooc ka mid ah [`Rc`] oo haya tixraac aan lahayn lahaanshaha qoondaynta la maareeyay.Qoondaynta waxaa lagu helayaa iyada oo wacaya [`upgrade`] tilmaamaha `Weak`, kaas oo soo celinaya [``Xulasho ']' '<`[' 'Rc`]' '<T>>``.
///
/// Tan iyo tixraaca `Weak` a ma tirin xagga lahaanshaha, ma ka hortagi doontaa qiimaha ku kaydsan qoondaynta ka hoos, iyo `Weak` laftiisa ka dhigaa jirin damaanado ku saabsan qiimaha weli joogo.
/// Markaa waxay soo celin kartaa [`None`] markii [`` upgrade '] d.
/// Xusuusnow si kastaba ha noqotee in tixraaca `Weak`*uusan* ka hortageynin qoondaynta lafteeda (dukaanka taakuleynta) in aan la kala bixin.
///
/// Tilmaame-tilmaameedka `Weak` wuxuu faa'iido u leeyahay inuu hayo tixraac ku-meel-gaar ah oo ku saabsan qoondaynta ay maamusho [`Rc`] iyada oo aan laga horjoogsanaynin qiimaha gudaha ee hoos u dhaca.
/// Waxaa sidoo kale loo isticmaalaa in looga hortago tixraacyada wareegsan ee udhaxeeya tilmaamayaasha [`Rc`], maadaama tixraacyada wadaagga ah aysan waligood ogolaan doonin in [`Rc`] la tuuro.
/// Tusaale ahaan, geedku wuxuu yeelan karaa tilmaamayaal xoog leh oo ah [`Rc`] oo laga helo nodeodeyaasha waalidka ilaa carruurta, iyo tilmaamaha `Weak` ee carruurta dib loogu celiyo waalidkood.
///
/// Habka caadiga ah ee lagu helo tilmaamaha `Weak` waa in la waco [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Kani waa `NonNull` si loogu oggolaado in leysku habeeyo nooca noocan oo kale ah, laakiin maahan tilmaame sax ah.
    //
    // `Weak::new` Tani waxay u dejineysaa `usize::MAX` si aysan ugu baahnayn inay meel ugu qoondo taallo.
    // Taasi maahan qiime tilmaame dhab ah uu waligiis yeelan doono maxaa yeelay RcBox wuxuu leeyahay iswaafajin ugu yaraan 2.
    // Tani waxay suurtagal tahay oo keliya marka `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Waxay dhistaa `Weak<T>` cusub, iyadoon loo qoondeyn wax xusuus ah.
    /// Wicitaanka [`upgrade`] qiimaha soo celinta had iyo jeer wuxuu siiyaa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Nooca Caawiyaha si uu ugu oggolaado helitaanka tixraaca tirinta adigoon wax caddeyn ah ka sameynin goobta xogta.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Kucelinaya tilmaame cayriin shayga `T` ee uu tilmaamay `Weak<T>`.
    ///
    /// pointer waa ansax ah oo keliya haddii ay jiraan qaar ka mid ah tixraac xoog leh.
    /// Tilmaamuhu waxaa laga yaabaa inuu lumayo, oo aan la jaanqaadin ama xitaa haddii kale uu yahay [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Labaduba waxay tilmaamayaan isla shay
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Kuwa halkan ku xoog badan ayaa sii nooleeya, markaa wali waanu heli karnaa shayga.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Laakiin intaa ka badan maahan.
    /// // Waan sameyn karnaa weak.as_ptr(), laakiin helitaanka tilmaanta waxay u horseedi doontaa dabeecad aan la qeexin.
    /// // assert_eq! ("hello", amaan ma aha {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Haddii tilmaamuhu liqay, waxaan toos ugu soo celinayna waardiyaha.
            // Tani ma noqon karto cinwaan xaddidan oo lacag bixin ah, maadaama mushahar bixinta ugu yaraan ay la jaanqaadayso RcBox (usize).
            ptr as *const T
        } else {
            // BADBAADADA: haddii qatarta khaldan ay ku soo noqoto been, markaa tilmaame waa la diidi karaa.
            // Mushaharka ayaa hoos loo dhigi karaa xilligan, waana inaan ilaalino caddaynta, markaa isticmaal tilmaam tilmaame cayriin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Waxay isticmaashaa `Weak<T>` waxayna u rogtaa tilmaame cayriin.
    ///
    /// Tani waxay u beddeleysaa tilmaame daciif ah tilmaame ceyriin ah, iyadoo weli la ilaalinayo lahaanshaha hal tixraac daciif ah (tirada daciifka ah wax kama beddelayso hawlgalkan).
    /// Dib ayaa loogu celin karaa `Weak<T>` iyadoo la socota [`from_raw`].
    ///
    /// Xayiraadaha isku midka ah ee marin u helista bartilmaameedka tilmaame sida [`as_ptr`] ayaa lagu dabaqayaa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Waxay u rogeysaa tilmaame ceyriin oo ay horey u sameysay [`into_raw`] dib ugu laabo `Weak<T>`.
    ///
    /// Tan waxaa loo isticmaali karaa in si badbaado leh loogu helo tixraac xoog leh (adoo wacaya [`upgrade`] goor dambe) ama in lagu wareejiyo tirinta daciifka ah iyadoo la dhigayo `Weak<T>`.
    ///
    /// Waxay qaadataa lahaanshaha hal tixraac daciif ah (marka laga reebo tilmaamayaasha ay abuureen [`new`], maadaama kuwani aysan waxba iska lahayn; habka wali wuu ku shaqeeyaa iyaga).
    ///
    /// # Safety
    ///
    /// Tilmaameyuhu waa inuu ka yimid [`into_raw`] waana inuu weli lahaadaa tixraackiisa daciifka ah.
    ///
    /// Waa loo oggol yahay tirinta xoogga leh inay ahaato 0 waqtiga wicitaanka tan.
    /// Si kastaba ha noqotee, tani waxay la wareegeysaa lahaanshaha hal tixraac daciif ah oo hadda matalaya tilmaame cayriin ah (tirada daciifka ah waxba kama beddeli karto hawlgalkan) sidaas darteedna waa in lagu lamaaniyaa wicitaankii hore ee [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hoos u dhaca tirada ugu dambeysa ee daciifka ah.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Ka eeg Weak::as_ptr macnaha guud ee ku saabsan sida tilmaamaha tilmaamaha loo soo qaatay.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tani waa liicliic liidata.
            ptr as *mut RcBox<T>
        } else {
            // Haddii kale, waxaan u damaanad qaaday tilmaamaha ka tabar yar nondangling yimid.
            // BADBAADADA: data_offset waa badbaado in la waco, maadaama tixraacayaasha ptr ay yihiin dhab (suurtagal ah in hoos loo dhigo) T.
            let offset = unsafe { data_offset(ptr) };
            // Sidaa awgeed, waxaan dib uga laabaneynaa dejinta si aan u helno dhammaan RcBox.
            // BADBAADADA: tilmaamuhu wuxuu asal ahaan ka yimid Weak, marka isweydaarsigani waa aamin.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BADBAADADA: hadda waxaan soo ceshanay tilmaamihi daciifka ahaa ee asalka ahaa, markaa abuuri kara kuwa liita.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Isku dayga lagu hagaajinayo tilmaamaha `Weak` ilaa [`Rc`], dib u dhigista hoos udhaca qiimaha gudaha hadii lagu guuleysto.
    ///
    ///
    /// Soocelinayaa [`None`] haddii sicirka gudaha tan iyo markaas la daadiyey.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Baabi'i dhammaan tilmaamayaasha xoogga leh.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Wuxuu helayaa tirada tilmaamayaasha (`Rc`) ee xoogan ee tilmaamaya qoondaynta.
    ///
    /// Haddii `self` la abuuray iyadoo la adeegsanayo [`Weak::new`], tani waxay soo celin doontaa 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Wuxuu helayaa tirada tilmaamayaasha `Weak` ee tilmaamaya qoondaynta.
    ///
    /// Haddii aysan jirin tilmaameyaal adag, kani wuxuu ku noqonayaa eber.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // kala goyso ptr daciif ah
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Sooceliyaa `None` marka tilmaamuhu lulayo oo aysan jirin `RcBox` loo qoondeeyay, (ie, markii `Weak` kan la abuuray `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Waxaan ka taxaddarnaa in *aan* abuurin tixraac daboolaya aagga "data", maaddaama aagga isku beddeli karo isla mar ahaantaana (tusaale ahaan, haddii `Rc`-kii ugu dambeeyay la tuuray, aagga xogta ayaa lagu ridi doonaa goobta).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Soocelinayaa `true` haddii labada ``Weak`s ay tilmaamayaan isla qoondaynta (oo lamid ah [`ptr::eq`]), ama haddii labaduba aysan tilmaamin wax qoondayn ah (maxaa yeelay waxaa lagu abuuray `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Maaddaama tan la isbarbar dhigayo tilmaamayaasha waxay ka dhigan tahay in `Weak::new()` ay isbarbar dhigi doonaan, in kasta oo aysan tilmaamayn wax qoondeyn ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Isbarbardhiga `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dhibcaha tilmaamaha `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Waxba ma daabacdo
    /// drop(foo);        // Daabacaadda "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // tirinta daciifka ahi waxay ka bilaabmaysaa 1, waxayna kaliya u gudbi doontaa eber haddii tilmaamayaasha oo dhan la waayey.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Waxay ka kooban tahay tilmaame tilmaame `Weak` ah oo tilmaamaya isla qoondaynta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Waxay dhistaa `Weak<T>` cusub, u qoondaynta xusuusta `T` iyadoon la bilaabin.
    /// Wicitaanka [`upgrade`] qiimaha soo celinta had iyo jeer wuxuu siiyaa [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Waxaan hubinay halkaan inaan mem::forget si aamin ah ula macaamilno.Khaas ahaan
// haddii aad tahay mem::forget Rcs (ama Weaks), tirinta tirinta ayaa buuxin karta, ka dibna waad xoreyn kartaa qoondaynta inta Rcs (ama Weaks) wali taagan.
//
// Waan iska soo ridi karnaa maxaa yeelay tani waa xaalad aad u liidata oo aanaan dan ka lahayn waxa dhaca-ma jiro barnaamij dhab ah oo weligiis sidan lagu arko.
//
// Tani waa inay lahaato korka dayacan maxaa yeelay dhab ahaantii uma baahnid inaad waxbadan isku koobto Rust iyada oo ay ugu wacan tahay lahaanshaha iyo dhaqdhaqaaqa-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Waxaan dooneynaa inaan iska dhicino qulqulka halkii aan ka daadin laheyn qiimaha.
        // Tirakoobka tixraaca weligiis eber noqon maayo markii tan la yiraahdo;
        // si kastaba ha noqotee, waxaan soo gelineynaa soo ridid halkan si aan u muujino LLVM oo ah qaab kale oo seegay.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Waxaan dooneynaa inaan iska dhicino qulqulka halkii aan ka daadin laheyn qiimaha.
        // Tirakoobka tixraaca weligiis eber noqon maayo markii tan la yiraahdo;
        // si kastaba ha noqotee, waxaan soo gelineynaa soo ridid halkan si aan u muujino LLVM oo ah qaab kale oo seegay.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Ka hel isugeynta gudaha `RcBox` ee lacag bixinta inta ka dambaysa tilmaame.
///
/// # Safety
///
/// Tilmaamuhu waa inuu tilmaamaa (oo uu hayaa metadata sax ah) tusaale ahaan hore oo ansax ah oo ah T, laakiin T-ga waa la oggol yahay in la tuuro.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Isku hagaaji qiimaha aan la qiyaasi karin ilaa dhamaadka RcBox.
    // Sababtoo ah RcBox waa repr(C), had iyo jeer waxay noqon doontaa berrinkii ugu dambeeyay ee xusuusta.
    // BADBAADADA: maaddaama noocyada kaliya ee aan la qiyaasi karin ay yihiin xaleefyo, walxaha trait,
    // iyo noocyada bannaanka, shuruudda amniga gelinta ayaa hadda ku filan in lagu qanciyo shuruudaha align_of_val_raw;kani waa faahfaahinta fulinta ee luuqada oo aan lagu tiirsanaan karin wixii ka baxsan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}