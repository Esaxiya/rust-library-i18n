//! Nooc tilmaame ah oo loogu talagalay qoondaynta taallo.
//!
//! [`Box<T>`], si caadi ah loogu yeero 'box', waxay bixisaa qaabka ugu fudud ee qoondaynta taakulaynta ee Rust.Khaanadaha ayaa bixiya lahaanshaha qoondaynta, oo waxay daadiyaan waxyaabaha ku jira markay ka baxayaan baaxadda.Sanduuqyadu sidoo kale waxay hubiyaan inaysan waligood qoondayn wax ka badan `isize::MAX` bytes.
//!
//! # Examples
//!
//! Ka wareeji qiimaha ka soo baxa guntiga adoo abuuraya [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Qiime ka soo qaado [`Box`] dib ugu soo celi [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Abuuritaanka qaabdhismeed xog dib u noqosho leh:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Tani waxay daabici doontaa `` Cons (1, Cons(2, Nil))`.
//!
//! Qaab dhismeedka soo noqnoqoshada waa in la garaacaa, maxaa yeelay haddii qeexidda `Cons` ay sidan u ekayd:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Ma shaqeyn laheyd.Tani waa sababta oo ah cabirka `List` wuxuu kuxiran yahay inta walxaha kujira liiska, sidaa darteedna ma naqaano inta xasuusta loo qoondeeyo `Cons`.Soo bandhigida [`Box<T>`], oo leh cabir qeexan, waxaan ognahay sida weyn ee loo baahan yahay inuu noqdo `Cons`.
//!
//! # Qaab dhismeedka xusuusta
//!
//! Qiyamyada aan eber lahayn, [`Box`] wuxuu u adeegsan doonaa qoondeynta [`Global`].Waa ansax in la beddelo labada waddo ee u dhexeeya [`Box`] iyo tilmaamaha ceyriinka ah ee loo qoondeeyey qoondada [`Global`], iyada oo la og yahay in [`Layout`] loo adeegsaday qoondeeye ay ku habboon tahay nooca.
//!
//! Si ka sii saxan, `value:*mut T` oo loo qoondeeyay qoondeeyaha [`Global`] oo leh `Layout::for_value(&* value)` waxaa loo rogi karaa sanduuq iyadoo la adeegsanayo [`Box::<T>::from_raw(value)`].
//! Taa bedelkeeda, xusuusta taageerta `value:*mut T` laga helay [`Box::<T>::into_raw`] waxaa lagu kala wareejin karaa iyadoo la adeegsanayo qoondeynta [`Global`] oo leh [`Layout::for_value(&* value)`].
//!
//! Qiyamka qiyaasta eber-ka ah, tilmaame `Box` wali waa inuu ahaadaa [valid] akhriska iyo qorista oo si ku habboon u waafaqsan.
//! Gaar ahaan, ku tuurista tilmaam kasta oo aan eber ehel u ahayn tilmaam ceeriin ah waxay soo saartaa tilmaame sax ah, laakiin tilmaame tilmaamaya xusuus hore loo qoondeeyay oo tan iyo markii la sii daayay sax ahayn.
//! Habka lagu taliyay ee loo dhiso Sanduuq ilaa ZST ah haddii aan la isticmaali karin `Box::new` waa in la isticmaalo [`ptr::NonNull::dangling`].
//!
//! Ilaa iyo inta `T: Sized`, `Box<T>` waa la damaanad qaadayaa in lagu metelo hal tilmaam sidoo kale ABI wuxuu la jaan qaadayaa tilmaamayaasha C (ie C nooca `T*`).
//! Tani waxay ka dhigan tahay in haddii aad leedahay hawlaha extern "C" Rust in lagu odhan doonaa ka C, aad u qeexi karaan kuwa hawlaha Rust isticmaalaya noocyada `Box<T>`, iyo isticmaali `T*` sida u dhiganta nooca dhinaca C ah.
//! Tusaale ahaan, tixgeli cinwaankan C ee cadeynaya shaqooyinka abuuraya isla markaana baabi'inaya nooc ka mid ah qiimaha `Foo`:
//!
//! ```c
//! /* C madax */
//!
//! /* Kucelin lahaanshaha qofka soo waca */
//! struct Foo* foo_new(void);
//!
//! /* Waxay ka qaadanaysaa lahaanshaha qofka soo wacaya;maya-diid marka lagugu dhawaaqo NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Labadan shaqo waxaa laga yaabaa in lagu hirgeliyo Rust sida soo socota.Halkan, nooca `struct Foo*` ee ka socda C waxaa loo tarjumay `Box<Foo>`, oo qabta caqabadaha lahaanshaha.
//! Xusuusnow sidoo kale in muranka aan la dabooli karin ee `foo_delete` uu matalayo Rust sida `Option<Box<Foo>>`, maadaama `Box<Foo>` uusan noqon karin wax aan jirin.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! In kasta oo `Box<T>` uu leeyahay matalaad isku mid ah iyo C ABI oo ah tilmaame C, tani macnaheedu maahan inaad u beddeli karto `T*` aan caqli-gal ahayn `Box<T>` oo aad filayso inay wax shaqeeyaan.
//! `Box<T>` qiyamka markasta si buuxda ayaa loo waafajin doonaa, tilmaamayaasha aan waxba ka jirin.Intaa waxaa sii dheer, burburiyaha `Box<T>` wuxuu isku dayi doonaa inuu ku sii daayo qiimaha qaybiyaha adduunka.Guud ahaan, dhaqanka ugu fiican ayaa ah in kaliya loo isticmaalo `Box<T>` tilmaamayaasha ka soo jeeda qoondeynta adduunka.
//!
//! **Muhiim ah.** Ugu yaraan waqtigan xaadirka ah, waa inaad iska ilaalisaa inaad u isticmaasho noocyada `Box<T>` shaqooyinka lagu qeexay C laakiin laga soo qaatay Rust.Xaaladahaas, waa inaad si toos ah u muraayad gelisaa noocyada C sida ugu dhow ee suurtogalka ah.
//! Isticmaalka noocyada sida `Box<T>` halkaasoo qeexitaanka C uu kaliya adeegsanayo `T*` waxay u horseedi kartaa dabeecad aan la qeexin, sida lagu sharraxay [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Nooc tilmaame ah oo loogu talagalay qoondaynta taallo.
///
/// Ka eeg [module-level documentation](../../std/boxed/index.html) wixii intaa ka badan.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Xusuusta ayuu u qoondeeya tuulada ka dibna wuxuu dhigaa `x`.
    ///
    /// Tani runti ma qoondeynayso haddii `T` uu yahay eber.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Wuxuu dhisaa sanduuq cusub oo ay ku jiraan waxyaabaha aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Wuxuu dhisaa `Box` cusub oo leh waxyaalo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo bayooyinka `0`.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Wuxuu dhisaa `Pin<Box<T>>` cusub.
    /// Haddii `T` uusan hirgelin `Unpin`, markaa `x` waxaa lagu dhejin doonaa xusuusta oo aan la dhaqaajin karin.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Xusuusta ayuu u qoondeeya tuulada ka dibna wuxuu dhigaa `x`, isagoo soo celiya qalad haddii qoondayntu ay dhacdo
    ///
    ///
    /// Tani runti ma qoondeynayso haddii `T` uu yahay eber.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Wuxuu dhisayaa sanduuq cusub oo ay ku jiraan waxyaalo aan la ogeyn oo ku saabsan taallada, isagoo soo celinaya qalad haddii qoondayntu ay ku guuldareysato
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Wuxuu dhisaa `Box` cusub oo leh waxyaabo aan la ogeyn, iyadoo xusuusta lagu buuxinayo `0` bytes dusha taal
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Qoondaynta xusuusta wuxuu u qoondeeyaa qoondeeyaha la siiyay ka dibna wuxuu dhigaa `x`.
    ///
    /// Tani runti ma qoondeynayso haddii `T` uu yahay eber.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Qoondaynta xusuusta ayuu u qoondeeyaa qoondeeyaha la siiyay ka dib wuxuu dhigayaa `x`, isagoo soo celinaya qalad haddii qoondayntu ay guul darreysato
    ///
    ///
    /// Tani runti ma qoondeynayso haddii `T` uu yahay eber.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Waxay ku dhisaysaa sanduuq cusub oo ay ku jiraan waxyaabaha aan la ogeyn ee qoondada la siiyay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Waxaan ka doorbidayaa ciyaarta in ka badan unwrap_or_else tan iyo markii la xirayo mararka qaarkood ma ahan wax layn karo
        // Taasi way ka sii weynaan laheyd cabirka koodhka.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Wuxuu dhisaa sanduuq cusub oo ay ku jiraan waxyaabaha aan la ogeyn ee qoondada la siiyay, isagoo soo celinaya qalad haddii qoondaynta ay ku guuldareysato
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Wuxuu dhisaa `Box` cusub oo leh waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes qeybiyaha la siiyay.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Waxaan ka doorbidayaa ciyaarta in ka badan unwrap_or_else tan iyo markii la xirayo mararka qaarkood ma ahan wax layn karo
        // Taasi way ka sii weynaan laheyd cabirka koodhka.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Waxay dhistaa `Box` cusub oo leh waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes ee qoondada la siiyay, iyadoo la soo celinayo qalad haddii qoondayntu ay guul darreysato,
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Wuxuu dhisaa `Pin<Box<T, A>>` cusub.
    /// Haddii `T` uusan hirgelin `Unpin`, markaa `x` waxaa lagu dhejin doonaa xusuusta oo aan la dhaqaajin karin.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// U rogaa `Box<T>` una beddelaa `Box<[T]>`
    ///
    /// diinta Tani ma qoondeeyo on taallo iyo dhacaya meel.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Wuxuu cunaa `Box`, isagoo soo celinaya qiimaha la duubay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Waxay dhistaa jeex sanduuq cusub leh oo ay ku jiraan waxyaabaha aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Waxay dhistaa jeex cusub oo sanduuq leh oo ay ku jiraan waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Wuxuu dhisaa jeex cusub oo sanduuq leh oo leh waxyaabo aan la ogeyn oo ku jira qoondada la siiyay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Wuxuu dhisaa jeex cusub oo sanduuq leh oo leh waxyaabo aan la ogeyn oo ku jira qoondada la siiyay, iyadoo xusuusta lagu buuxinayo `0` bytes.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Ku beddelaya `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo waca inuu dammaanad qaado in qiimaha runti uu ku jiro xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Ku beddelaya `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo wacaya inuu damaanad qaado in qiimayaashu runtii ku jiraan xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Wuxuu ka sameeyaa sanduuq tilmaame cayriin.
    ///
    /// Kadib markuu wacay shaqadan, tilmaamaha ceyriinka waxaa iska leh natiijada soo baxday ee `Box`.
    /// Gaar ahaan, baabi'iyaha `Box` wuxuu wici doonaa burburiyaha `T` oo wuxuu xoreyn doonaa xusuusta loo qoondeeyay.
    /// Si tan ay u noqoto mid amaan ah, xusuusta waa in loo qoondeeyay iyadoo la raacayo [memory layout] oo ay adeegsadeen `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn maxaa yeelay adeegsiga aan habooneyn wuxuu u horseedi karaa dhibaatooyin xagga xusuusta ah.
    /// Tusaale ahaan, laba-laab-la`aan ayaa dhici karta haddii shaqada loogu yeero labo jeer isla tilmaanta ceyriinka.
    ///
    /// Xaaladaha nabadgelyada waxaa lagu sharaxay qaybta [memory layout].
    ///
    /// # Examples
    ///
    /// Ku soo celi `Box` kaas oo hore loogu beddelay tilmaam cayriin iyadoo la adeegsanayo [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Adigu gacan ku sameysid `Box` xoq adoo isticmaalaya qoondaynta adduunka:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Guud ahaan .write ayaa looga baahan yahay in laga fogaado isku dayga ah in la burburiyo (uninitialized) waxyaabihii hore ee `ptr`, in kastoo tusaalahan fudud `*ptr = 5` uu sidoo kale shaqeyn lahaa.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Wuxuu ka dhisaa sanduuq tilmaame cayriin oo loo qoondeeyey.
    ///
    /// Kadib markuu wacay shaqadan, tilmaamaha ceyriinka waxaa iska leh natiijada soo baxday ee `Box`.
    /// Gaar ahaan, baabi'iyaha `Box` wuxuu wici doonaa burburiyaha `T` oo wuxuu xoreyn doonaa xusuusta loo qoondeeyay.
    /// Si tan ay u noqoto mid amaan ah, xusuusta waa in loo qoondeeyay iyadoo la raacayo [memory layout] oo ay adeegsadeen `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn maxaa yeelay adeegsiga aan habooneyn wuxuu u horseedi karaa dhibaatooyin xagga xusuusta ah.
    /// Tusaale ahaan, laba-laab-la`aan ayaa dhici karta haddii shaqada loogu yeero labo jeer isla tilmaanta ceyriinka.
    ///
    /// # Examples
    ///
    /// Ku soo celi `Box` kaas oo hore loogu beddelay tilmaam cayriin iyadoo la adeegsanayo [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Adigu gacan ku sameysid `Box` xoq adoo isticmaalaya qoondeynta nidaamka:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Guud ahaan .write ayaa looga baahan yahay in laga fogaado isku dayga ah in la burburiyo (uninitialized) waxyaabihii hore ee `ptr`, in kastoo tusaalahan fudud `*ptr = 5` uu sidoo kale shaqeyn lahaa.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Wuxuu cunaa `Box`, isagoo soo celinaya tilmaam cayriin oo duudduuban.
    ///
    /// Tilmaamuhu wuxuu si sax ah u waafajinayaa oo aan waxba ka jirin.
    ///
    /// Kadib markuu wacay shaqadan, soo wacaha ayaa mas'uul ka ah xasuusta uu horey u maamuli jiray `Box`.
    /// Gaar ahaan, qofka soo wacaya waa inuu si sax ah u baabi'iyaa `T` oo uu sii daayaa xusuusta, iyadoo la tixgelinayo [memory layout] ee uu adeegsaday `Box`.
    /// Habka ugu fudud ee tan lagu sameyn karo ayaa ah in tilmaamaha ceyriinka ah dib loogu beddelo `Box` oo leh howsha [`Box::from_raw`], taasoo u oggolaaneysa baabi'iyaha `Box` inuu sameeyo nadiifinta.
    ///
    ///
    /// Note: tani waa shaqo la xiriirta, taas oo macnaheedu yahay inaad ugu yeerto `Box::into_raw(b)` halkii aad ka dhihi lahayd `b.into_raw()`.
    /// Tani waa si aysan u jirin wax khilaaf ah qaab ku saabsan nooca gudaha.
    ///
    /// # Examples
    /// U beddelashada tilmaamaha ceyriinka dib ugu noqoshada `Box` leh [`Box::from_raw`] nadiifinta otomaatiga ah:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Nadiifinta Buugga adigoo si cad u shaqeynaya burburiyeha isla markaana ku wareejinaya xusuusta:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Gubtay `Box` ah, soo laabtay tilmaamaha ku duudduuban oo ceeriin iyo allocator ah.
    ///
    /// Tilmaamuhu wuxuu si sax ah u waafajinayaa oo aan waxba ka jirin.
    ///
    /// Kadib markuu wacay shaqadan, soo wacaha ayaa mas'uul ka ah xasuusta uu horey u maamuli jiray `Box`.
    /// Gaar ahaan, qofka soo wacaya waa inuu si sax ah u baabi'iyaa `T` oo uu sii daayaa xusuusta, iyadoo la tixgelinayo [memory layout] ee uu adeegsaday `Box`.
    /// Habka ugu fudud ee tan lagu sameyn karo ayaa ah in tilmaamaha ceyriinka ah dib loogu beddelo `Box` oo leh howsha [`Box::from_raw_in`], taasoo u oggolaaneysa baabi'iyaha `Box` inuu sameeyo nadiifinta.
    ///
    ///
    /// Note: tani waa shaqo la xiriirta, taas oo macnaheedu yahay inaad ugu yeerto `Box::into_raw_with_allocator(b)` halkii aad ka dhihi lahayd `b.into_raw_with_allocator()`.
    /// Tani waa si aysan u jirin wax khilaaf ah qaab ku saabsan nooca gudaha.
    ///
    /// # Examples
    /// U beddelashada tilmaamaha ceyriinka dib ugu noqoshada `Box` leh [`Box::from_raw_in`] nadiifinta otomaatiga ah:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Nadiifinta Buugga adigoo si cad u shaqeynaya burburiyeha isla markaana ku wareejinaya xusuusta:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Sanduuqa waxaa loo aqoonsan yahay inuu yahay "unique pointer" oo ay leedahay 'Stacked Borrows', laakiin gudaha gudaheeda waa tilmaam ceeriin u ah nooca nooca.
        // Si toos ah ugu rogida tilmaame cayriin looma aqoonsan doono inuu yahay "releasing" tilmaamaha gaarka ah ee u oggolaanaya marinnada ceeriin ee loo yaqaan 'aliased', markaa dhammaan hababka tilmaamaha cayriin waa inay maraan `Box::leak`.
        //
        // U rogida *taas* tilmaame cayriin wuxuu u dhaqmaa si sax ah.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Sooceliyaa inay marjic u allocator sababaya.
    ///
    /// Note: tani waa shaqo la xiriirta, taas oo macnaheedu yahay inaad ugu yeerto `Box::allocator(&b)` halkii aad ka dhihi lahayd `b.allocator()`.
    /// Tani waa si aysan u jirin wax khilaaf ah qaab ku saabsan nooca gudaha.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Gubtaa oo daadinaysaa `Box`, oo soo celinaysa tixraac la beddeli karo, `&'a mut T`.
    /// Xusuusnow in nooca `T` ay tahay inuu ka cimri dheeraado nolosha la doortay ee `'a`.
    /// Haddii nooca uu leeyahay oo keliya tixraacyo ma guurto ah, ama midkoodna uusan jirin, markaa tan waxaa loo dooran karaa inuu noqdo `'static`.
    ///
    /// Shaqadani waxay inta badan waxtar u leedahay xogta nooshahay inta ka dhiman nolosha barnaamijka.
    /// Joojinta tixraaca la soo celiyey ayaa sababi doona xusuus daadasho.
    /// Haddii tan aan la aqbali karin, tixraaca waa in marka hore lagu duuduubo shaqada [`Box::from_raw`] oo soo saarta `Box`.
    ///
    /// `Box`-kan ayaa markaa la tuuri karaa kaas oo si sax ah u baabi'in doona `T` oo sii deyn doona xusuusta loo qoondeeyay.
    ///
    /// Note: tani waa shaqo la xiriirta, taas oo macnaheedu yahay inaad ugu yeerto `Box::leak(b)` halkii aad ka dhihi lahayd `b.leak()`.
    /// Tani waa si aysan u jirin wax khilaaf ah qaab ku saabsan nooca gudaha.
    ///
    /// # Examples
    ///
    /// Isticmaal fudud:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Xog aan la qiyaasi karin:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// U rogaa `Box<T>` una beddelaa `Pin<Box<T>>`
    ///
    /// diinta Tani ma qoondeeyo on taallo iyo dhacaya meel.
    ///
    /// Tani sidoo kale waxaa laga heli karaa iyada oo loo marayo [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Suurtagal ma aha in la dhaqaajiyo ama la beddelo gudaha gudaha `Pin<Box<T>>` markii `T: !Unpin`, markaa waa ammaan in si toos ah loogu dhejiyo iyada oo aan loo baahnayn shuruudo dheeri ah.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Waxba ha qaban, hoos u dhaca waxaa hadda sameeya isku duwe.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Waxay abuurtaa `Box<T>`, oo leh qiimaha `Default` ee T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Sooceliyaa sanduuq cusub oo leh `clone()` sanduuqan waxyaabaha kujira.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Qiimuhu waa isku mid
    /// assert_eq!(x, y);
    ///
    /// // Laakiin waa shay gaar ah
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Sii-u-qoondee xusuusta si aad ugu oggolaato qorista qiimaha cufan si toos ah.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Nuqulada 'isha' waxyaabaha kujira `self` iyadoon la abuurin qoondeyn cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Qiimuhu waa isku mid
    /// assert_eq!(x, y);
    ///
    /// // Mana jirin qoondayn
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // kan ayaa nuqul ka dhigaya xogta
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// U rogaa nooc guud `T` una roga `Box<T>`
    ///
    /// Beddelaadda ayaa loo qoondeeyay taalada oo ka dhaqaaqaysa `t` xidhmooyinkeeda.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// U rogaa `Box<T>` una beddelaa `Pin<Box<T>>`
    ///
    /// diinta Tani ma qoondeeyo on taallo iyo dhacaya meel.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// U rogaa `&[T]` una beddelaa `Box<[T]>`
    ///
    /// Beddelaadani waxay u qoondaynaysaa taallada waxayna samaynaysaa nuqul ka mid ah `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // samee a&[u8] kaas oo loo isticmaali doono in lagu abuuro Sanduuq <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// U rogaa `&str` una beddelaa `Box<str>`
    ///
    /// Beddelaadani waxay u qoondaynaysaa taallada waxayna samaynaysaa nuqul ka mid ah `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// U rogaa `Box<str>` una beddelaa `Box<[u8]>`
    /// diinta Tani ma qoondeeyo on taallo iyo dhacaya meel.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // abuur Sanduuq<str>taas oo loo isticmaali doonaa si ay u abuuraan Box a <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // samee a&[u8] kaas oo loo isticmaali doono in lagu abuuro Sanduuq <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// U rogaa `[T; N]` una beddelaa `Box<[T]>`
    /// Beddelaadani waxay u wareejineysaa isku xirka xusuusta cusub ee loo qoondeeyey.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Isku day inaad hoos ugu dhigto sanduuqa nooca shubka ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Isku day inaad hoos ugu dhigto sanduuqa nooca shubka ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Isku day inaad hoos ugu dhigto sanduuqa nooca shubka ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Suura gal maaha in si toos ah looga soo saaro Uniq-ga gudaha Sanduuqa, halkii aan ku tuuri lahayn * const oo ku magacaaban Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Takhasus u leh cabbirka ``I`s '' ee adeegsada ``I`s hirgelinta `last()` halkii laga isticmaali lahaa.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}