//! Qoondaynta xusuusta APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Kuwani waa astaamaha sixirka si loogu yeedho qoondeeyaha adduunka.rustc waxay soo saartaa iyaga inay wacaan `__rg_alloc` iwm.
    // haddii uu jiro sifo `#[global_allocator]` ah (koodh ballaadhinaya sifo macro ah ayaa abuuraya shaqooyinkaas), ama loogu yeedho hirgelinta aasaasiga ah ee libstd (`__rdl_alloc` iwm)
    //
    // `library/std/src/alloc.rs`) haddii kale.
    // rustc fork ee LLVM sidoo kale kiisaska khaaska ah magacyadan shaqaynta si ay awood ugu yeeshaan inay u hagaajiyaan sida `malloc`, `realloc`, iyo `free`, siday u kala horreeyaan.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Qoondeeyaha xasuusta adduunka.
///
/// Noocaan wuxuu hirgeliyaa [`Allocator`] trait adoo wicitaano u diraya qoondeeyaha ka diiwaangashan astaamaha `#[global_allocator]` haddii uu jiro mid, ama xaddiga `std` crate.
///
///
/// Note: halka noocan aanu xasilloonayn, shaqeynta ay bixiso waxaa laga heli karaa iyada oo loo marayo [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// U qoondee xusuusta qoondeeyaha adduunka.
///
/// Shaqadani waxay horey ugu sii socotaa habka [`GlobalAlloc::alloc`] ee qoondeeyaha ka diiwaangashan astaamaha `#[global_allocator]` haddii uu jiro mid, ama xaddiga `std` crate.
///
///
/// Hawshan ayaa la filayaa in hoos loo dhigo iyada oo loo rogayo habka `alloc` ee nooca [`Global`] marka ay iyo [`Allocator`] trait ay noqdaan kuwo deggan.
///
/// # Safety
///
/// Fiiri [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Dib ugula wadaag xusuusta qoondeeyaha adduunka.
///
/// Shaqadani waxay horey ugu sii socotaa habka [`GlobalAlloc::dealloc`] ee qoondeeyaha ka diiwaangashan astaamaha `#[global_allocator]` haddii uu jiro mid, ama xaddiga `std` crate.
///
///
/// Hawshan ayaa la filayaa in hoos loo dhigo iyada oo loo rogayo habka `dealloc` ee nooca [`Global`] marka ay iyo [`Allocator`] trait ay noqdaan kuwo deggan.
///
/// # Safety
///
/// Fiiri [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Dib ugulaaxee xusuusta qoondeeyaha adduunka.
///
/// Shaqadani waxay horey ugu sii socotaa habka [`GlobalAlloc::realloc`] ee qoondeeyaha ka diiwaangashan astaamaha `#[global_allocator]` haddii uu jiro mid, ama xaddiga `std` crate.
///
///
/// Hawshan ayaa la filayaa in hoos loo dhigo iyada oo loo rogayo habka `realloc` ee nooca [`Global`] marka ay iyo [`Allocator`] trait ay noqdaan kuwo deggan.
///
/// # Safety
///
/// Fiiri [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// U qoondee qoondada adduunka ee xasuusta eber-bilowga ah.
///
/// Shaqadani waxay horey ugu sii socotaa habka [`GlobalAlloc::alloc_zeroed`] ee qoondeeyaha ka diiwaangashan astaamaha `#[global_allocator]` haddii uu jiro mid, ama xaddiga `std` crate.
///
///
/// Hawshan ayaa la filayaa in hoos loo dhigo iyada oo loo rogayo habka `alloc_zeroed` ee nooca [`Global`] marka ay iyo [`Allocator`] trait ay noqdaan kuwo deggan.
///
/// # Safety
///
/// Fiiri [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // BADBAADADA: `layout` cabbir ahaan ma lahayn eber,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // BADBAADADA: Waxay la mid tahay `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // BADBAADADA: `new_size` waa eber la'aan maadaama `old_size` uu ka weyn yahay ama la siman yahay `new_size`
            // sida looga baahan yahay xaaladaha nabadgelyada.Shuruudaha kale waa inuu ilaaliyaa qofka soo wacaya
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` laga yaabee inuu hubiyo `new_size >= old_layout.size()` ama wax la mid ah.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BADBAADADA: maxaa yeelay `new_layout.size()` waa inuu ka weynaadaa ama la mid yahay `old_size`,
            // qoondaynta xusuusta hore iyo tan cusub labaduba waxay ansax u yihiin akhrinta iyo wax u qorida `old_size` bytes.
            // Sidoo kale, maxaa yeelay qoondayntii hore weli lama kala saarin, kama wareejin karto `new_ptr`.
            // Marka, wicitaanka `copy_nonoverlapping` waa aamin.
            // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // BADBAADADA: `layout` cabbir ahaan ma lahayn eber,
            // shuruudaha kale waa inuu ilaaliyaa qofka soo wacaya
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BADBAADADA: dhammaan shuruudaha waa inuu ilaaliyaa qofka soo wacaya
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BADBAADADA: dhammaan shuruudaha waa inuu ilaaliyaa qofka soo wacaya
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // BADBAADADA: shuruudaha waa inuu ilaaliyaa qofka soo wacaya
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // BADBAADADA: `new_size` waa eber.Shuruudaha kale waa inuu ilaaliyaa qofka soo wacaya
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` laga yaabee inuu hubiyo `new_size <= old_layout.size()` ama wax la mid ah.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BADBAADADA: maxaa yeelay `new_size` waa inuu ka yaryahay ama u dhigmaa `old_layout.size()`,
            // qoondaynta xusuusta hore iyo tan cusub labaduba waxay ansax u yihiin akhrinta iyo wax u qorida `new_size` bytes.
            // Sidoo kale, maxaa yeelay qoondayntii hore weli lama kala saarin, kama wareejin karto `new_ptr`.
            // Marka, wicitaanka `copy_nonoverlapping` waa aamin.
            // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// U qoondeeyaha tilmaamayaasha gaarka ah.
// Shaqadani waa inaysan kala bixin.Hadday taasi dhacdo, MIR codegen wuu fashilmi doonaa.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Saxeexan waa inuu la mid ahaadaa `Box`, haddii kale ICE ayaa dhici doonta.
// Marka xaddiga dheeraadka ah ee `Box` lagu daro (sida `A: Allocator`), tan waa in lagu daro halkan sidoo kale.
// Tusaale ahaan haddii `Box` loo beddelay `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, shaqadan waa in loo beddelaa `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` sidoo kale.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Maamulaha qaladka qoondaynta

extern "Rust" {
    // Tani waa astaanta sixirka ee loogu yeero kaaliyaha qaladka qoondaynta caalamiga ah.
    // rustc wuxuu u sameeyaa inuu waco `__rg_oom` haddii uu jiro `#[alloc_error_handler]`, ama inuu waco ku-meel-gaadhka aasaasiga ah ee ka hooseeya (`__rdl_oom`) haddii kale.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abort ku saabsan qaladka qoondaynta xusuusta ama guuldarada.
///
/// Kuwa soo wacaya qoondaynta qoondaynta APIs ee raba inay tirtiraan xisaabinta iyaga oo ka jawaabaya qaladka qoondaynta ayaa lagu dhiirigelinayaa inay wacaan shaqadan, halkii ay si toos ah ugu yeeri lahaayeen `panic!` ama wax la mid ah.
///
///
/// Dabeecadda asalka ah ee shaqadan ayaa ah in la daabaco fariin khalad caadi ah lana joojiyo nidaamka.
/// Waxaa lagu beddeli karaa [`set_alloc_error_hook`] iyo [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Imtixaanka qoondaynta `std::alloc::handle_alloc_error` si toos ah ayaa loo isticmaali karaa.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // waxaa loogu yeeraa iyadoo la soo saaray `__rust_alloc_error_handler`

    // haddii aanu jirin `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // haddii uu jiro `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Ku takhasus clones-ka loo qoondeeyay, xusuusta aan la ogeyn.
/// Waxaa adeegsaday `Box::clone` iyo `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Markaad qoondeysay *marka hore* waxay u oggolaan kartaa kaamiroole inuu ku abuuro qiimaha isku dhegan, ka boodi kara deegaanka una dhaqaaqa.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Had iyo jeer waan nuqulan karnaa goobta, annaga oo aan waligeen ku lug laheyn qiime maxalli ah.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}