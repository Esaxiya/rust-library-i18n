#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Waxyaabaha ku jira xusuusta cusub lama oga.
    Uninitialized,
    /// Xusuusta cusub ayaa la hubaa inay eber tahay.
    Zeroed,
}

/// Aalad heer-hoose ah oo si khaldan u qoondaynta, dib-u-qoondaynta, iyo kala-beddelka kaydka xusuusta ee taallada iyada oo aan laga walwalin dhammaan kiisaska geeska ee ku lug leh.
///
/// Noocaan ayaa ah mid aad u fiican dhisida qaab dhismeedka xogtaada sida Vec iyo VecDeque.
/// Khaas ahaan:
///
/// * Waxay soo saartaa `Unique::dangling()` noocyada cabbirka eber.
/// * Waxay ku soo saartaa `Unique::dangling()` qoondeyn dherer eber ah.
/// * Iska ilaali xoreynta `Unique::dangling()`.
/// * Waxay qabataa dhammaan qulqulka kumbuyuutarrada xisaabinta (waxay u dallacsiisaa "capacity overflow" panics).
/// * Ilaalada ka soo horjeeda nidaamyada 32-bit ee u qoondeeya in ka badan isize::MAX bytes.
/// * Waxay ka celinayaan dhererkaaga.
/// * Wuxuu ugu yeeraa `handle_alloc_error` qoondeynta dhaca.
/// * Waxay ka koobantahay `ptr::Unique` oo sidaasna ku siineysa adeegsadaha dhammaan faa'iidooyinka la xiriira.
/// * Waxay u isticmaashaa xad-dhaafka laga soo celiyey qoondeeyaha si loo isticmaalo awoodda ugu weyn ee la heli karo.
///
/// Noocani si kastaba ha noqotee ma baaro xusuusta ay maamusho.Markii la tuuro *waxay xoreyn doontaa* xusuustiisa, laakiin ma * isku deyi doonto inay dajiso waxyaabaha ku jira.
/// Waxay ku xiran tahay isticmaalaha `RawVec` inuu maareeyo waxyaabaha dhabta ah *lagu keydiyey* gudaha `RawVec`.
///
/// Xusuusnow in xad-dhaafka noocyada eber-cabbirkoodu had iyo jeer aan la koobi karayn, sidaa darteed `capacity()` had iyo jeer wuxuu soo celiyaa `usize::MAX`.
/// Tani waxay ka dhigan tahay inaad u baahan tahay inaad taxaddar sameyso markaad wareegga noocan oo kale ah la socoto `Box<[T]>`, maxaa yeelay `capacity()` ma bixin doono dhererka.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Tani waxay jirtaa maxaa yeelay `#[unstable]` 'const fn`s uma baahna inay waafaqaan `min_const_fn` sidaas darteedna looguma wici karo' min_const_fn`s sidoo kale.
    ///
    /// Haddii aad beddesho `RawVec<T>::new` ama ku-tiirsanaanta, fadlan ka taxaddar inaadan soo bandhigin wax run ahaantii ku xadgudbaya `min_const_fn`.
    ///
    /// NOTE: Waan ka fogaan karnaa jabsigan oo waxaan ku hubin karnaa qaab-dhismeedka `#[rustc_force_min_const_fn]` astaamo u baahan is-waafajinta `min_const_fn` laakiin qasab maahan in loogu yeero `stable(...) const fn`/lambarka isticmaalaha oo aan awood u siinaynin `foo` marka `#[rustc_const_unstable(feature = "foo", issue = "01234")]` la joogo.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Waxay abuurtaa `RawVec` ugu weyn ee suurtogalka ah (on the system heap) iyadoon loo qoondayn.
    /// Haddii `T` uu leeyahay cabir togan, markaa tani waxay ka dhigaysaa `RawVec` lehna awood `0`.
    /// Haddii `T` uu yahay mid eber ah, markaa wuxuu sameeyaa `RawVec` lehna awood `usize::MAX`.
    /// Faa'iido u leh hirgelinta qoondaynta dib u dhigista.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Waxay abuurtaa `RawVec` (on the system heap) oo si sax ah u leh awooda iyo isku xirnaanta shuruudaha `[T; capacity]`.
    /// Tani waxay u dhigantaa wicitaanka `RawVec::new` marka `capacity` uu yahay `0` ama `T` uu yahay eber.
    /// Xusuusnow haddii `T` uu yahay eber cabbir ahaan tani waxay ka dhigan tahay inaadan * * ka heli doonin `RawVec` oo leh awoodda la codsaday.
    ///
    /// # Panics
    ///
    /// Panics haddii kartida la codsaday ay dhaafto `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Ilmo soo dhicinta on OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Sida `with_capacity`, laakiin dammaanad qaadaya keydku waa eber.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Dib-u-cusbooneysiiyaa `RawVec` tilmaame iyo karti.
    ///
    /// # Safety
    ///
    /// `ptr` waa in loo qoondeeyaa (on the system heap), iyo iyadoo la siiyay `capacity`.
    /// `capacity` kama badnaan karo `isize::MAX` noocyada cabbirka leh.(kaliya walaac ku saabsan nidaamyada 32-bit).
    /// ZST vectors wuxuu yeelan karaa awood ilaa `usize::MAX` ah.
    /// Haddii `ptr` iyo `capacity` ay ka yimaadaan `RawVec`, markaa tan waa la damaanad qaadayaa.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs waa carrab la '.U gudub:
    // - 8 haddii cabirka curiyuhu yahay 1, maxaa yeelay qolal kasta oo wax qoondeeya waxay u badan tahay inay soo koobaan codsi ka yar 8 baayt illaa ugu yaraan 8 bayt.
    //
    // - 4 haddii walxo dhexdhexaad ah (<=1 KiB).
    // - 1 haddii kale, si looga fogaado luminta boos aad u fara badan oo Vecs ah.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Sida `new`, laakiin lagu cabbiray xulashada qoondeeyaha `RawVec` soo laabtay.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` waxaa loola jeedaa "unallocated".noocyada qiyaasta eber waa la iska indhatiray.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Sida `with_capacity`, laakiin lagu cabbiray xulashada qoondeeyaha `RawVec` soo laabtay.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Sida `with_capacity_zeroed`, laakiin lagu cabbiray xulashada qoondeeyaha `RawVec` soo laabtay.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// U rogaa `Box<[T]>` una beddelaa `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Bedelashada keydka oo dhan waxay u beddeleysaa `Box<[MaybeUninit<T>]>` oo leh `len` cayiman.
    ///
    /// Xusuusnow in tani si sax ah dib ugu dhisi doonto wixii isbeddel ah ee `cap` ee laga yaabo in la qabtay.(Faahfaahinta ka eeg nooca.)
    ///
    /// # Safety
    ///
    /// * `len` waa inuu ka weynaadaa ama la sinnaadaa awoodda dhowaan la codsaday, iyo
    /// * `len` waa inuu kayaryahay ama la egyahay `self.capacity()`.
    ///
    /// Xusuusnow, in awooda la codsaday iyo `self.capacity()` ay ku kala duwanaan karaan, maadaama qoondeeyuhu uu meelayn karo isla markaana soo celin karo xusuus weyn oo ka badan inta la codsaday.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Hubi in nus ka mid ah shuruudaha amniga (ma hubin karno qeybta kale).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Waxaan ka fogaaneynaa `unwrap_or_else` halkan maxaa yeelay waxay xaddidaysaa xaddiga LLVM IR ee la soo saaray.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Dib-u-cusbooneysiiyaa `RawVec` tilmaame, karti, iyo qoondeeye.
    ///
    /// # Safety
    ///
    /// `ptr` waa in loo qoondeeyaa (iyada oo loo marayo qoondada la siiyay `alloc`), iyo iyada oo la siiyay `capacity`.
    /// `capacity` kama badnaan karo `isize::MAX` noocyada cabbirka leh.
    /// (kaliya walaac ku saabsan nidaamyada 32-bit).
    /// ZST vectors wuxuu yeelan karaa awood ilaa `usize::MAX` ah.
    /// Haddii `ptr` iyo `capacity` ka yimaadaan `RawVec` lagu abuuray `alloc`, markaa tan waa la damaanad qaadayaa.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Wuxuu helayaa tilmaam cayriin ah bilowga qoondaynta.
    /// Ogsoonow in kani yahay `Unique::dangling()` haddii `capacity == 0` ama `T` uu yahay eber.
    /// Xaaladda hore, waa inaad ka taxaddartaa.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Hesho awoodda qoondaynta.
    ///
    /// Tani had iyo jeer waxay noqon doontaa `usize::MAX` haddii `T` uu yahay mid eber leh.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Sooceliyaa tixraac wadaag ah qoondada taageerta `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Waxaan haynaa qayb xusuus ah oo loo qoondeeyay, sidaa darteed waan iska dhaafi karnaa jeegaga waqtiyada si aan u helno qaabkeena hadda.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Waxay xaqiijineysaa in keydku uu kakooban yahay ugu yaraan meel ku filan oo lagu hayo walxaha `len + additional`.
    /// Haddii aysan awalba lahayn awood ku filan, waxay dib u qoondeyn doontaa boos ku filan oo lagu daray boos jilicsan oo lagu raaxeysto *O*(1) dabeecad.
    ///
    /// Waxay xaddidi doontaa habdhaqankan haddii ay si aan macquul ahayn ugu sababi lahayd panic.
    ///
    /// Haddii `len` uu ka sarreeyo `self.capacity()`, tani waxay ku dhici kartaa inay dhab ahaan u qoondeeyaan booska la codsaday.
    /// Tani runti maahan mid aan ammaan ahayn, laakiin nambarka aaminka ah ee *aad* qorto ee ku tiirsan habdhaqanka shaqadan ayaa jabi kara.
    ///
    /// Tani waxay ku habboon tahay hirgelinta hawlgal bulk-riix ah sida `extend`.
    ///
    /// # Panics
    ///
    /// Panics hadii awooda cusubi ka badato `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Ilmo soo dhicinta on OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // keydku wuu iska soo ridi lahaa ama wuu argagixi lahaa haddii amaahdu ka badato `isize::MAX` sidaa darteed taasi waa ammaan in la iska hubiyo hadda.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// La mid ah `reserve`, laakiin wuxuu ku soo noqdaa khaladaadka halkii uu ka argagixi lahaa ama ka soo ridi lahaa.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Waxay xaqiijineysaa in keydku uu kakooban yahay ugu yaraan meel ku filan oo lagu hayo walxaha `len + additional`.
    /// Haddii aysan horey u sameynin, waxay dib u qoondeyn doontaa xaddiga ugu yar ee suurtogalka ah ee xusuusta lagama maarmaanka ah.
    /// Guud ahaan tani waxay noqon doontaa inta ay le'eg tahay xusuusta lagama maarmaanka ah, laakiin mabda 'ahaan qoondeeyuhu wuxuu xor u yahay inuu soo celiyo wax ka badan wixii aan dalbannay.
    ///
    ///
    /// Haddii `len` uu ka sarreeyo `self.capacity()`, tani waxay ku dhici kartaa inay dhab ahaan u qoondeeyaan booska la codsaday.
    /// Tani runti maahan mid aan ammaan ahayn, laakiin nambarka aaminka ah ee *aad* qorto ee ku tiirsan habdhaqanka shaqadan ayaa jabi kara.
    ///
    /// # Panics
    ///
    /// Panics hadii awooda cusubi ka badato `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Ilmo soo dhicinta on OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// La mid ah `reserve_exact`, laakiin wuxuu ku soo noqdaa khaladaadka halkii uu ka argagixi lahaa ama ka soo ridi lahaa.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Waxay hoos u dhigeysaa qoondaynta ilaa inta la cayimay.
    /// Haddii qadarka la siiyay uu yahay 0, dhab ahaantii gebi ahaanba waa la wareegaa.
    ///
    /// # Panics
    ///
    /// Panics haddii qaddarka la siiyay uu *ka ballaaran yahay* awoodda hadda jirta.
    ///
    /// # Aborts
    ///
    /// Ilmo soo dhicinta on OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Soo noqoshada haddii keydku u baahan yahay inuu koro si uu u buuxiyo awoodda dheeriga ah ee loo baahan yahay.
    /// Ugu badnaan waxaa loo isticmaalaa in lagu sameeyo soo-wicitaanka-wicitaannada suurtogalka ah iyada oo aan la soo qorin `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Habkani badanaa waa la dhaqaajiyaa marar badan.Marka waxaan rabnaa inay ahaato sida ugu yar ee suurtogalka ah, si loo hagaajiyo waqtiyada la isku soo uruurinayo.
    // Laakiin waxaan sidoo kale dooneynaa in inta badan ee ka kooban ay ahaato mid si xisaabtan leh loo xisaabtami karo sida ugu macquulsan, si loo sameeyo koodhka la sameeyay si dhakhso leh u socdo.
    // Sidaa darteed, qaabkani si taxaddar leh ayaa loo qoray si dhammaan koodhka ku tiirsan `T` uu ku dhex jiro, halka in badan oo koodh ah oo aan ku tiirsanayn `T` intii suurtagal ah ay ku jiraan shaqooyin aan guud ahayn oo ka sarreeya `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tan waxaa lagu xaqiijiyaa xaaladaha wicitaanka.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Tan iyo markii aan soo celinayno awoodda `usize::MAX` markay tahay `elem_size`
            // 0, helitaanka halkan daruuri waxay ka dhigan tahay in `RawVec` uu buux dhaafsan yahay.
            return Err(CapacityOverflow);
        }

        // Waxba kama qaban karno baaritaanadan, nasiib daro.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Tani waxay damaanad qaadeysaa koritaanka jibbaaranaha.
        // Labadaba lama buuxin karo maxaa yeelay `cap <= isize::MAX` iyo nooca `cap` waa `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` waa generic guud ahaan `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // caqabadaha The on habkan badan la mid yihiin kuwa on `grow_amortized`, laakiin habkan waxaa inta badan instantiated inta badan ka yar sidaas darteed waa muhiim in ka yar.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Tan iyo markii aan soo celinayno awoodda `usize::MAX` marka cabirka nooca uu yahay
            // 0, helitaanka halkan daruuri waxay ka dhigan tahay in `RawVec` uu buux dhaafsan yahay.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` waa generic guud ahaan `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Shaqadani waxay ka baxsan tahay `RawVec` si loo yareeyo isku-dubbaridka waqtiyada.Eeg faallada kor ku xusan `RawVec::grow_amortized` wixii faahfaahin ah.
// (`A` cabirka ma ahan mid muhiim ah, maxaa yeelay tirada noocyada kala duwan ee `A` ee lagu arko ficil ahaan aad ayey uga yar yihiin tirada noocyada `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Hubi khaladka halkan si loo yareeyo cabbirka `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Qeybiyaha ayaa hubinaya sinnaanta isku dheelitirka
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Waxay furaysaa xasuusta uu lahaa `RawVec`*iyadoon* la isku deyin in la tuuro waxyaabaha ku jira.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Hawlaha dhexe ee maaraynta qaladka keydka.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Waxaan u baahanahay inaan dammaanad qaadno waxyaabaha soo socda:
// * Waligeen uma qoondeynayno walxo cabbirkoodu yahay `> isize::MAX`.
// * Kama buuxinayno `usize::MAX` oo runtii wax aad u yar ayaanu qoondaynay.
//
// On 64-bit waxaan kaliya u baahan si uu u hubiyo faafi tan iyo isku dayaya in ay qoondeeyo `> isize::MAX` bytes hubaal gabi doono.
// 32-bit iyo 16-bit waxaan u baahanahay inaan ku darno waardiye dheeri ah tan haddii aan ku shaqeyno barxad isticmaali karta 4GB oo dhan goobta isticmaale, tusaale, PAE ama x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Mid ka mid ah howlaha dhexe ee mas'uulka ka ah soo gudbinta awooda ayaa buux dhaafiyay.
// Tani waxay xaqiijin doontaa in jiilka koodhka ee la xiriira panics uu yahay mid aad u yar maadaama ay jirto hal meel oo keliya oo panics halkii ay ka ahaan lahayd farabadan inta moduleka ku jirta oo dhan.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}