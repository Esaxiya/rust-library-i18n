//! Kala bixida bartilmaameedka *emscripten*.
//!
//! Halka hirgelinta furitaanka Rust ee loogu talagalay barnaamijyada Unix ay si toos ah ugu yeeraan libunwind API-yada, Emscripten waxaan beddelkeeda ugu yeernaa C++ furashada API-yada.
//! Tani waa uun faa iido maadaama Emscripten waqtigiisa uu had iyo jeer fuliyo API-yadaas isla markaana uusan hirgelin libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Tani waxay ku habboon tahay qaabka std::type_info ee C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // The byte `\x01` halkan keentay run ahaantii waa signal a sixir si LLVM si *aan* codsan wax mangling kale sida prefixing leh qof `_` ah.
    //
    //
    // Astaantan ayaa ah vtable-ka uu isticmaalo C++ 's `std::type_info`.
    // Waxyaabaha nooca `std::type_info`, muujiyayaasha nooca, waxay leeyihiin tilmaamaha a miiska this.
    // Noocyada sharraxayaasha waxaa tixraaca qaab-dhismeedka C++ EH ee kor lagu sharaxay iyo in aan hoos ku dhisno.
    //
    // Ogow in size dhabta ah waa weyn oo ka badan 3 usize, laakiin waxaan kaliya u baahan si aan u vtable dhibic inay element saddexaad.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info fasalka rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Caadi ahaan waxaan isticmaali lahayn .as_ptr().add(2) laakiin tani kuma shaqeyneyso qaab macno leh.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Tani si ula kac ah uma isticmaasho magaca mangering ee caadiga ah maxaa yeelay ma dooneyno C++ inuu awood u yeesho soo saarista ama qabashada Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Tani waa lagama maarmaan, maxaa yeelay, C++ code qabsan kartaa execption la std::exception_ptr iyo waxa rethrow marar badan, in xitaa in thread kale.
    //
    //
    caught: AtomicBool,

    // Tani waxay u baahan yihiin in ay Xulashada ah sababtoo ah ee Meyeydaan wax ee soo socota C++ kelmedo: marka catch_unwind guuro Box ka soo marka laga reebo waa in ay weli ka tago wax laga reebo gobolka oo sax ah, sababtoo ah ay destructor waxaa weli in loogu yeedho by __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try runti wuxuu ina siinayaa tilmaame qaab-dhismeedkan.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Tan iyo cleanup() looma ogola in panic, waxaan kaliya soo rido waa halkii.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}