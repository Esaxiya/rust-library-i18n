//! Kala qaadida panics ee Miri.
use alloc::boxed::Box;
use core::any::Any;

// Nooca xamuulka ee mishiinka Miri ku faafiyo iyada oo la inaga furey.
// Waa in uu pointer yimaa-.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Hawlaha banaanka ee Miri-bixinta si loo bilaabo furida.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // payload aan noqotay in `miri_start_panic` noqon doonto wax xuja ah aan helno ee `cleanup` hoos.
    // Markaa hal mar ayaanu sanduuq ka dhigeynaa oo keliya, si aan u helno wax tilmaam ahaan le'eg.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Dib u soo celi `Box` hoosta
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}