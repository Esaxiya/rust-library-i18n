//! Hirgelinta panics iyada oo la adeegsanayo xargaha kala furfurida
//!
//! crate-kan ayaa ah hirgelinta panics ee Rust iyadoo la adeegsanayo farsamaynta kala-furista "most native" ee barxadda tan loo diyaarinayo.
//! Tan asal ahaan waxaa loo kala saaraa saddex baaldi hadda:
//!
//! 1. bartilmaameedyada MSVC isticmaali SEH in file `seh.rs` ah.
//! 2. Emscripten wuxuu ku isticmaalaa waxyaabo kale C++ faylka `emcc.rs`.
//! 3. All bartilmaameed kale u isticmaali libunwind/libgcc in file `gcc.rs` ah.
//!
//! waraaqo badan oo ku saabsan hirgelinta kasta laga heli karaa module ka soo jeedaan.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` waa la isticmaalin la Tintin, sidaas digniin aamusnaan.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // waxyaabaha xawaaladaha Runtime ee Rust ku xiran tahay calaamadaha oo dhan, sidaas darteed iyaga dadweynaha.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Bartilmaameedyada aan taageerin kala bixidda.
        // - arch=wasm32
        // - os=midna (bartilmaameedyada "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Isticmaal waqtiga Miri-ga.
        // Weli waxaan ubaahanahay inaan sidoo kale rarno waqtiga caadiga ah ee kor ku xusan, maadaama rustc ay fileyso in waxyaabo gaar ah oo meeshaas ka mid ah lagu qeexo.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Isticmaal Runtime dhabta ah.
        use real_imp as imp;
    }
}

extern "C" {
    /// Maamule ku jira libstd ayaa loo yaqaan markii walax panic ah lagu tuuro meel ka baxsan `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler ee libstd ayaa wacay marka laga reebo kuwa shisheeye.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// dhibic Entry oo kor Ioogu qaadayo marka laga reebo an, ergooyinka oo kaliya in ay fulinta madal-gaarka ah.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}