# `rustc-std-workspace-core` crate

crate-kani waa shimbir iyo madhan crate kaas oo si fudud ugu tiirsan `libcore` oo dib u daabacaya dhammaan waxyaabaha ku jira.
crate waa aasaaska xoojinta maktabada caadiga ah si ay ugu tiirsanaato crates laga bilaabo crates.io

Crates on crates.io in maktabadda caadiga ahi ku tiirsan tahay baahida loo qabo inay ku tiirsanaato `rustc-std-workspace-core` crate laga bilaabo crates.io, oo madhan.

Waxaan u adeegsaneynaa `[patch]` inaan uga dulqaadno crate keydkaan.
Natiija ahaan, crates ee crates.io wuxuu sawiri doonaa ku tiirsanaanta edge illaa `libcore`, oo ah nooca lagu qeexay bakhaarkan.
Taasi waa dhaansato oo dhan geesaha ku tiirsanaanta si loo hubiyo in Cargo dhistaa crates si guul leh!

Ogsoonow in crates ee crates.io ay u baahan tahay inay ku tiirsanaato crate kan oo leh magaca `core` si wax walboo ay u shaqeeyaan si sax ah.Si taas loo sameeyo waxay isticmaali karaan:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Adeegsiga furaha `package` crate waxaa loogu magac daray `core`, taasoo la micno ah inay u egtahay

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

marka Cargo baryi compiler ah, dherginaya ah dardaarankaaga awaamiir `extern crate core` by compiler ka mudaa.




