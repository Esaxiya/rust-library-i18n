#![feature(no_core)]
#![no_core]

// Eeg rustc-std-meesha lagu shaqeeysto-saldhiga u ah sababta crate this loo baahan yahay.

// Dib u magacaw crate si aad iskaga ilaaliso isku dhaca qeybta loo qoondeeyay ee liballoc.
extern crate alloc as foo;

pub use foo::*;