// rsbegin.o iyo rsend.o waa sidaas loo yaqaan "compiler runtime startup objects" ah.
// Waxay ka kooban yihiin koodh loo baahan yahay in si sax ah loo bilaabo hawsha ururinteeda.
//
// Marka sawirka la fulin karo ama dylib la isku xidho, dhammaan koodhka isticmaalaha iyo maktabadaha ayaa ah "sandwiched" inta udhaxeysa labadan feylood ee shay, marka koodh ama xog laga helo rsbegin.o ayaa noqda kan ugu horreeya qaybaha sawirku ka kooban yahay, halka koodhka iyo xogta rsend.o ay noqonayaan kuwa ugu dambeeya.
// Saameyntan waxaa loo isticmaali karaa in lagu dhigo astaamaha bilowga ama dhamaadka qeyb, iyo sidoo kale in la galiyo wixii madax ama lugeeye loo baahan yahay.
//
// Fiiro gaar ah in meesha mudniinka module dhabta ah waxa uu ku yaalaa shayga Runtime C xawaaladaha (sida caadiga ah loo yaqaan `crtX.o`), taas oo ka dibna baryi initialization callbacks qaybaha Runtime kale (diiwaan via weli qaybta kale image gaar ah).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Calaamadaha bilowga meertada xargaha ayaa kala bixiya qaybta macluumaadka
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // U xoq booska qaboojiyaha buugga gudaha.
    // Tan waxaa lagu qeexay `struct object` in $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // info Unwind joogtada registration/deregistration.
    // Eeg DoCS ee libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // diiwaan info unwind on xawaaladaha module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // iska diiwaangelinta joojinta
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Diiwaangelinta joogtada ah ee MinGW-gaar ah init/uninit
    pub mod mingw_init {
        // Waxyaabaha bilowga ah ee MinGW (crt0.o/dllcrt0.o) waxay ugu yeeri doonaan dhisayaasha caalamiga ah qaybaha .ctors iyo .dtors bilowga iyo bixitaanka.
        // Xaalada DLLs, tan waxaa la sameeyaa marka DLL la raro oo la soo dejiyo.
        //
        // Xiriiriyaha ayaa kala soocaya qaybaha, taas oo hubineysa in dib u soo celintayada ay ku yaalliin dhamaadka liiska.
        // Tan iyo constructors waxaa maamula si cagsi ah, ayaa hubineysa in callbacks our waa kuwa hore iyo toogasho.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors *: . callbacks initialization C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . callbacks joojinta C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}