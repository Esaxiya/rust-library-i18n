# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Maktabad maktabadda loogu talagalay raadinta dhabarka loogu talagalay Rust.
Maktabaddani waxay ujeedadeedu tahay inay kor u qaaddo taageerada maktabadda caadiga ah iyada oo la siinayo barnaamij barnaamij oo ay ku shaqayso, laakiin sidoo kale waxay taageertaa si fudud u daabacaadda dhabarka hadda jira sida libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Si aad si fudud u qabsadaan backtrace iyo raagin oo lagula tacaalo tan iyo muddo ka dib, waxaad isticmaali kartaa heer-sare ah nooca `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Haddii, si kastaba ha ahaatee, aad jeceshahay dheeraad ah si ay u shaqeynayaan Raadinta dhabta ah helitaanka cayriin, oo aad si toos ah u isticmaali kartaa hawlaha `trace` iyo `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Xalliyaan tilmaamaha tilmaamaha magaca calaamadda
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // u sii soco jihada soo socota
    });
}
```

# License

Mashruucani wuxuu shati ka haystaa midkoodna

 * Shatiga Apache, Nooca 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ama http://www.apache.org/licenses/LICENSE-2.0)
 * MIT liisanka ([LICENSE-MIT](LICENSE-MIT) ama http://opensource.org/licenses/MIT)

ikhtiyaarkaaga ah.

### Contribution

Ilaa aad si cad u sheegtid mooyee, wixii tabarucaad ah oo si ula kac ah loo soo gudbiyey si loogu daro ka mid noqoshadaada-adigu, sida lagu qeexay liisanka Apache-2.0, wuxuu noqon doonaa laba shati sida kor ku xusan, iyadoon lahayn shuruudo ama shuruudo dheeraad ah.







