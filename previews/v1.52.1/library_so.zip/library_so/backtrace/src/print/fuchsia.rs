use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr waxay qaadataa dib u soo celin wicitaan ah oo heli doonta tilmaanta dl_phdr_info ee DSO kasta oo lala xiriiriyay howsha.
    // dl_iterate_phdr sidoo kale hubiyaan in linker firfircoon ku xiran yahay min biloow ilaa dhamaad ee siyaalaha ka.
    // Haddii callback ka soo noqdo oo aan eber-qiimaha siyaalaha la joojiyo hore.
    // 'data' waxaa loo gudbin doonaa sida dooda saddexaad wicitaan kasta oo wicitaan ah.
    // 'size' wuxuu siinayaa cabbirka dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Waxaan u baahanahay inaan kala shaandheeyno Aqoonsiga dhismaha iyo qaar ka mid ah macluumaadka aasaasiga ah ee barnaamijka madaxa taas oo macnaheedu yahay inaan uga baahanahay xoogaa shey ah ELF spec sidoo kale.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Haatan waa inaan u sii wadaan, waxoogaa waayo yara, qaabka nooca dl_phdr_info loo isticmaalo by linker firfircoon fuchsia ee hadda.
// Chromium sidoo kale wuxuu leeyahay soohdintaan ABI iyo sidoo kale shikad.
// Dhab ahaan waxaan jeclaan laheyn inaan u wareejino kiisaskan si aan u isticmaalno raadinta elf laakiin waxaan u baahanahay inaan ku siino taas SDK taasna wali lama sameyn.
//
// Sidaa awgeed annaga (iyo iyagaba) waxaan ku dhegannahay inaan adeegsanno qaabkan oo ku keenaya isku xirnaan adag fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ma lihin hab aan ku ogaan karno hubinta haddii e_phoff iyo e_phnum ay ansax yihiin.
    // libc waa inuu tan noo hubiyaa si kastaba ha noqotee waa amaan in la sameeyo jeex halkan.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr wuxuu u taagan yahay 64-bit cinwaanka barnaamijka ELF ee ku aaddan dhismeedka bartilmaameedka.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr waxay u taagan tahay madax barnaamijka ELF oo ansax ah iyo waxyaabaha ku jira.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ma lihin hab aan ku hubino haddii p_addr ama p_memsz ay ansax yihiin.
    // libc fuchsia ee parses qoraalada ugu horeysay si kastaba ha ahaatee si Seeska u dhigay Aasaaskii halkan madax waa ansax u noqdo.
    //
    // NoteIter uma baahna xogta ku lammaan in ay ansax ahaato, laakiin waxa aanu u baahan soohdin ah in ay ansax ahaato.
    // Waxaan ku kalsoonahay in libc ay hubisay in tani ay tahay kiiska halkan.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Nooca qoraalka ee aqoonsiga dhismaha.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr wuxuu u taagan yahay madaxa qoraalka ELF ee ku wajahan ciribtirka bartilmaameedka.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Ogeysiisku wuxuu u taagan yahay qoraal ELF ah (cinwaanka cinwaanka + waxyaabaha ku jira).
// Magaca ayaa loo daayay inuu yahay u8 jeex maxaa yeelay marwalba null ma aha in la joojiyo oo rust ayaa sahleysa in si fudud loo hubiyo in baaydhadu isku mid yihiin.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter kuu ogolaanaysaa inaad si ammaan ah iterate badan qeybta note ah.
// Waxay joojisaa isla marka qalad dhaco ama ma jiraan qoraallo dheeraad ah.
// Haddii aad ku mashquuliso xog aan ansax ahayn waxay u shaqeyn doontaa sidii iyadoo aan wax qoraal ah la helin.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Waa invariant ah function in pointer iyo size siiyey yeero kala duwan oo sax ah bytes in dhammaan loo akhrin karaa.
    // Waxyaabaha ay ka kooban yihiin baaytyadan ayaa noqon kara wax kasta laakiin baaxadda waa inay ansax u ahaataa tan si ay ammaan u noqoto.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to muqararka 'x' si 'to'-byte lays loo maleeyo 'to' waa awood a of 2.
// Tani waxay raacaysaa qaab caadi ah oo ku jira C/C ++ ELF code baaritaanka halkaasoo (x + to, 1)&-to loo adeegsaday.
// Rust kuu oggolaan mayso inaad diiddo inaad isticmaasho sidaas ayaan u adeegsadaa
// 2-buuxinta-dhammaystirka si loo abuuro taas.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 gubtay Tirintii bytes ka jeex (haddii la joogo) iyo wixii intaa hubisaa in jeex kama dambays ah la properlly waafaqsan.
// Haddii mid ka mid ah tirada baaytka la codsaday ay aad u badan yihiin ama jeexan aan dib loo qori karin ka dib sababo la xiriira iyada oo aaney ku filneyn bytes-ka jira, Midna lama soo celiyo oo jeexan lama beddelin.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// shaqo waxa uu leeyahay ma invariants dhabta wacaha waa in ay ilaaliyaan kale oo aan ahayn laga yaabaa in 'bytes' waa in la toosiyaa-qabadka (iyo naqshadaba qaar ka mid sax).
// Qiyamyada ku jira aagagga Elf_Nhdr waxay noqon karaan wax aan micno lahayn laakiin shaqadani ma xaqiijinayso waxaas oo kale.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Tani waa amaan ilaa iyo inta ay jirto meel ku filan oo aan kaliya ku xaqiijinay in haddii bayaanka kor ku xusan markaa tani aysan noqon doonin mid aan amaan ahayn.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Ogow sice_of: :<Elf_Nhdr>() Had iyo jeer waa 4-byte waafaqsan.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Hubi haddii aan soo gaadhay dhamaadka.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Waxaan ku beddeleynaa nhdr laakiin waxaan si taxaddar leh uga fiirsaneynaa qaab dhismeedka ka dhashay.
        // Waxaan ha isku hallaynina namesz ama descsz oo waxaan ka dhigi jirin go'aanada ammaan ahayn oo ku salaysan nooca.
        //
        // Sidaas xitaa haddii aan bax dhamaystiran qashinka waa in weli aan ammaan ah.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Waxay muujineysaa in qeyb la fulin karo.
const PERM_X: u32 = 0b00000001;
/// Waxay muujinaysaa in qayb la qori karo.
const PERM_W: u32 = 0b00000010;
/// Waxay muujineysaa in qeyb la aqrin karo.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Waxay u taagan tahay qaybta ELF waqtiga shaqada.
struct Segment {
    /// Siinayaa cinwaanka Runtime dalwaddii ku jira qeybta this ee.
    addr: usize,
    /// Waxay bixisaa cabirka xusuusta ee qaybtan ka kooban.
    size: usize,
    /// Waxay ku siinaysaa cinwaanka qaab-dhismeedka qaybtan qaybtiisa faylka ELF.
    mod_rel_addr: usize,
    /// Waxay bixisaa rukhsadaha laga helo faylka ELF.
    /// Oggolaanshahaani daruuri maahan rukhsaddaha la heli karo xilliyada ay socdaan.
    flags: Perm,
}

/// Waxay ka dhigeysaa mid ka mid ah qaybaha 'DSO'.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Waxay u taagan tahay ELF DSO (Ujeeddo Wadaag Dynamic).
/// Noocani wuxuu tixraacayaa xogta ku kaydsan DSO-ga dhabta ah halkii uu ka samayn lahaa nuqul u gaar ah.
struct Dso<'a> {
    /// Isku xiraha firfircoon wuxuu markasta na siiyaa magac, xitaa haddii magaca uu madhan yahay.
    /// Marka laga hadlayo kan ugu weyn ee la fulin karo magacan ayaa madhan.
    /// Xaaladda walax la wadaago waxay noqon doontaa magaca wiilka (eeg DT_SONAME).
    name: &'a str,
    /// Fuchsia gebi ahaanba binariyadaha waxay leeyihiin aqoonsiyo aqoonsi laakiin tani maahan dalbasho adag.
    /// Ma jirto wado lagu iswaafajin karo macluumaadka DSO iyo feylka dhabta ah ee ELF kadib hadii aysan jirin wax dhisid ah sidaa darteed waxaan ubaahanahay in DSO kasta mid ku yeesho halkan.
    ///
    /// DSO-yada bilaa dhisme_waa la iska indhatiray.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ku soo celiyaa ku celcelin qaybaha 'DSO'.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Khaladaadkan ayaa qiraya arrimaha soo ifbaxa inta ay ka baarayaan macluumaadka ku saabsan DSO kasta.
///
enum Error {
    /// NameError waxaa loola jeedaa in qalad dhacay markii loo badalayo xariga 'St style string' xariga rust.
    ///
    NameError(core::str::Utf8Error),
    /// Dhismaha qaladku wuxuu ka dhigan yahay inaynaan helin aqoonsi dhismo.
    /// Tani waxay noqon kartaa sababtoo ah DSO ma lahayn aqoonsi dhisme ama sababtoo ah qeybta ay ka kooban tahay Aqoonsiga dhismaha ayaa cilladaysan.
    ///
    BuildIDError,
}

/// Wicitaano midkood ah 'dso' ama 'error' oo loo yaqaan 'DSO' kasta oo ku xira nidaamka hawsha isku xiraha firfircoonida.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter oo yeelan doona mid ka mid ah hababka wax loo cuno ee loo yaqaan 'foreach DSO'.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr wuxuu hubiyaa in info.name ay tilmaami doonto meel sax ah.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Shaqadani waxay daabacaysaa calaamadda calaamadaha Fuchsia ee dhammaan macluumaadka ku jira DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}