//! Taageerada Backtrace iyadoo la adeegsanayo libunwind/gcc_s/etc APIs.
//!
//! Qaybtani waxay ka kooban tahay awoodda lagu kala furfurayo xargaha iyadoo la isticmaalayo API-yada libunwind-style.
//! Fiiro gaar ah in ay jirto farabadan oo fulintii of libunwind-sida API, kanna waa uun isku dayaya in ay la jaan ugu dhammaantood mar halkii isagoo picky.
//!
//!
//! Libunwind API waxaa ku shaqeeya `_Unwind_Backtrace` waana ficil ahaan aad loogu kalsoonaan karo abuurista gadaal.
//! Ma ahan gebi ahaanba cad sida ay u qabato (tilmaamayaasha qaabka? Eh_frame info? Labadaba?) Laakiin waxay umuuqataa inay shaqeyneyso!
//!
//! Inta badan kakanaanta qaybtani waxay wax kaqabaneysaa kala duwanaanta kaladuwanaanta ee ka jirta fulinta libunwind.
//! Haddii kale tani waa Rust si toos ah oo toosan ugu xidhan libunwind APIs.
//!
//! Kani waa API-ga caadiga ah ee la furayo ee loogu talagalay dhammaan barnaamijyada aan-Windows-ka ahayn ee hadda jira.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Iyada oo tilmaame libunwind ceeriin ah waa inuu waligiis ku soo galayaa qaab aqrinta kaliya 'threadsafe', markaa waa `Sync`.
// Markaad u diraysid mawduucyo kale `Clone` waxaan had iyo jeer u leexannaa nooc aan haynin tilmaamayaasha gudaha, sidaas darteed waa inaan sidoo kale noqonnaa `Send`.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Waxa ay u muuqataa in on OSX `_Unwind_FindEnclosingFunction` laabtay pointer ah in ... wax cadda.
        // Xaqiiqdii marwalba maahan wax soo xirida sabab kasta ha noqotee.
        // Gabi ahaan aniga igama cada waxa halkaan ka socda, markaa ka fikir tan hadda oo mar walba soo celi ip.
        //
        // Xusuusnow imtixaanka `skip_inner_frames.rs` waxaa looga booday OSX qodobkan awgiis, haddii taasna la xalliyo imtixaanka aragti ahaan waxaa lagu wadi karaa OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Iskuxidhka iskudhafka maktabadda oo loo isticmaalo gadaal
///
/// Ogsoonow in koodhka dhintay loo oggol yahay maadaama halkan ay yihiin uun isku xirnaanta macruufka ah ee iOS uusan isticmaalin dhammaantood laakiin ku darista qaabab badan oo gaar u leh qaababka ayaa si aad ah u nijaaseynaya lambarka
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // waxaa isticmaalay oo kaliya ARM EABI
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Maya dhalashada_Unwind_Backtrace on macruufka
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // la heli karo ilaa GCC 4.2.0, waa inuu fiicnaadaa ujeedkeenna
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Hawshani waa si khaldan: halkii laga heli lahaa cinwaankan 'Canonical Frame Address' (oo ah magaca wicitaanka 'SP') wuxuu soo celinayaa qaab dhismeedka 'SP'.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x isticmaalaa a qiimaha CFA u janjeedhaan, sidaas darteed waxaan u baahan nahay in ay isticmaalaan_Unwind_GetGR si aad u hesho tilmaamaha xidhmooyin soo diiwaan (%r15) halkii ku tiirsan_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android iyo gacanta, shaqada `_Unwind_GetIP` iyo farabadan oo kuwa kale ah waa macros, sidaa darteed waxaan qeexeynaa shaqooyinka ay kujiraan balaarinta macros.
    //
    //
    // TODO: ku xir faylka cinwaanka ee qeexaya macros, haddii aad heli karto.
    // (I, fitzgen, ma heli karo feylka cinwaanka ee qaar ka mid ah balaadhinta makro-ka markii hore laga soo amaahday.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 waa tilmaamaha is dulsaaran ee gacanta.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Shaqadani sidoo kale kuma jirto Android ama ARM/Linux, markaa ka dhig wax aan ikhtiyaar lahayn.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}