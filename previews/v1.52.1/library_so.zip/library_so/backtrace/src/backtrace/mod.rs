use core::ffi::c_void;
use core::fmt;

/// Wuxuu kormeeraa isku-darka wicitaanka ee hadda jira, isagoo u marinaya dhammaan meertada firfircoon xiritaanka loo bixiyay si loo xisaabiyo raadadka xirmooyinka.
///
/// Shaqadani waa shaqada maktabaddan marka la xisaabinayo raadadka isku-darka barnaamijka.`cb` xiritaanka la bixiyay waxaa tusaale u ah `Frame` oo matalaya macluumaadka ku saabsan qaabka wicitaanka ee xariijinta.
/// Xiritaanku waa looxyo muqadas ah oo moodada kor-hoos ah (tii ugu dambeysay ee loogu yeero shaqooyinka marka hore).
///
/// Qiimaha soo noqoshada xiritaanka ayaa ah calaamad muujinaysa in gadaalku sii socon doono iyo inkale.Qiimaha soo celinta ee `false` ayaa joojineysa dib-u-soo-celinta oo isla markiiba soo noqdaa.
///
/// Mar haddii la helo `Frame` waxaad u baahan tahay inaad wacdo `backtrace::resolve` si aad ugu beddesho `ip` (tilmaamaha tilmaamaha) ama cinwaanka astaamaha `Symbol` oo magaca iyo/ama filename/lambarka lambarka lagu baran karo.
///
///
/// Ogsoonow in tani ay tahay hawl heerkeedu hooseeyo oo haddii aad jeclaan lahayd, tusaale ahaan, soo qabso gadaal gadaal si loo baaro mar dambe, markaa nooca `Backtrace` ayaa laga yaabaa inuu ku habboon yahay.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
/// # Panics
///
/// Hawshani waxay ku dadaalaysaa in aan waligeed panic, laakiin haddii `cb` uu bixiyo panics markaa barnaamijyada qaarkood waxay ku qasbi doonaan panic labalaab ah si ay u soo ridaan hawsha.
/// Nidaamyada qaar waxay adeegsadaan maktabadda C oo gudaha ku dhex adeegsata soo-celinta wicitaannada oo aan lagu soo koobi karin, sidaa darteed argagaxa ka imanaya `cb` wuxuu kicin karaa geedi socodka soo rididda.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // gadaal ka sii wad
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// La mid ah `trace`, kaliya aan amaan ahayn maadaama aysan isku xirnayn.
///
/// Hawshani ma lahan waxqabadyo walaalo laakiin waa la heli karaa marka muuqaalka `std` ee crate aan la soo ururin.
/// Ka eeg shaqooyinka `trace` wixii dukumiinti iyo tusaalooyin dheeri ah.
///
/// # Panics
///
/// Ka eeg macluumaadka `trace` wixii ku saabsan digniinta `cb` oo argagaxsan.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait oo meteleysa hal qaab oo gadaal ah, ayaa u hibeysay waxqabadka `trace` ee crate.
///
/// Xiritaanka hawsha baafinta ayaa la soo saari doonaa looxyo, qaabkana waa la diri karaa maadaama hirgelinta aasaasiga ah aan had iyo jeer la aqoon ilaa waqtiga shaqada.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Sooceliyaa tilmaamaha tilmaamaha hadda.
    ///
    /// Tani caadi ahaan waa tilmaamaha soo socda ee lagu fulinayo qaabka, laakiin ma aha in dhammaan waxqabadyada lagu qoro tan 100% saxsan (laakiin guud ahaan way dhowdahay).
    ///
    ///
    /// Waxaa lagugula talinayaa inaad u gudbiso qiimahan `backtrace::resolve` si loogu beddelo magac calaamadeysan.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Sooceliyaa tilmaamaha isdaba jooga ah ee qaabkan.
    ///
    /// Xaaladda oo ah in gadaal-gadaal uusan ka soo kaban karin tilmaamaha xargaha ee qaabkan, tilmaame aan waxba ka jirin ayaa la soo celiyay.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Sooceliyaa cinwaanka astaamaha bilowga ee qaabka shaqadan.
    ///
    /// Tani waxay isku dayi doontaa inay dib u rogto tilmaamaha tilmaamaha ee ay soo celisay `ip` bilowga shaqada, iyadoo soo celinaysa qiimahaas.
    ///
    /// Xaaladaha qaarkood, si kastaba ha noqotee, gadaal-celinta ayaa ka soo celin doonta `ip` shaqadan.
    ///
    /// Qiimaha la soo celiyay mararka qaarkood waa la isticmaali karaa haddii `backtrace::resolve` uu ku guuldareysto `ip` ee kor ku xusan.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Soocelisaa cinwaanka saldhigga moduleka jirku ka tirsan yahay.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Tani waxay ubaahantahay inay marka hore timaado, si loo hubiyo in Miri ay mudnaan ka siiso barnaamijka martida loo yahay
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // kaliya loo isticmaalay dbghelp astaan
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}