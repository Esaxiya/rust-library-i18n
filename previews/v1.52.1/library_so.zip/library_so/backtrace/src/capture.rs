use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Wakiil ka noqoshada milkiilaha milkiilaha iyo iskiis u shaqeynaya.
///
/// Qaab dhismeedkan waxaa loo isticmaali karaa in lagu soo qabto dib u dhac meelo kala duwan oo barnaamijka ah markii dambena loo adeegsado in lagu baaro waxa gadaal ay ahayd xilligaas.
///
///
/// `Backtrace` waxay taageertaa daabacaadda quruxda badan ee gadaal iyada oo loo marayo hirgelinteeda `Debug`.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Frames halkan waxaa ku qoran kor-ilaa-hoose ee xidhmooyin ah
    frames: Vec<BacktraceFrame>,
    // Tusaha aan aaminsanahay inuu yahay bilowga dhabta ah ee gadaal, kana tagaya looxyada sida `Backtrace::new` iyo `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Nooca la qabtay ee qaab jir gadaal ah.
///
/// Noocaan waxaa lagu soo celiyey liistada `Backtrace::frames` wuxuuna u taagan yahay hal qaab dhismeedka gadaal la qabtay.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Nooca la qabtay ee astaanta gadaal.
///
/// Noocaan waxaa laga soo celiyey liis ahaan `BacktraceFrame::symbols` wuxuuna metelaa metadata calaamadda gadaal.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Waxay qabaneysaa gadaal goobta wicitaanka shaqadan, iyadoo soo celinaysa matalaad ay laheyd.
    ///
    /// Shaqadani waxay faa'iido u leedahay matalaad dhabarka shey ahaan u jirta Rust.Qiimahaan la soo celiyey waxaa loo diri karaa xargaha oo lagu daabici karaa meelo kale, ujeedka qiimahani waa inuu gebi ahaanba iskiis u ahaado.
    ///
    /// Ogsoonow in meheradaha qaarkood helitaan dhab ah oo buuxa iyo xallintiisa ay noqon karaan kuwo aad qaali u ah.
    /// Haddii kharashku aad ugu badan yahay dalabkaaga waxaa lagugula talinayaa inaad beddesho `Backtrace::new_unresolved()` taas oo ka hortageysa tallaabada xallinta calaamadaha (taas oo sida caadiga ah qaadata tan ugu dheer) waxayna u oggolaaneysaa in taas dib loogu dhigo taariikh dambe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // rabto in aad u hubiso in ay jiraan in meesha laga saaro ay jir ah halkan
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Si la mid ah `new` marka laga reebo in tani aysan xallinaynin wax calaamado ah, tani waxay si fudud ugu soo qaadanaysaa gadaal dambe liiska cinwaanada.
    ///
    /// Waqti dambe ayaa la soo wici karaa shaqada `resolve` si loogu xaliyo astaamaha gadaal gadaashiisa magacyada la akhrin karo.
    /// Shaqadani way jirtaa sababtoo ah habka xallintu mararka qaarkood waxay qaadan kartaa waqti aad u fara badan halka mid kastoo gadaal laga yaabo in dhif ah la daabaco.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // magacyo astaan ma leh
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // magacyada calaamadaha hadda jira
    /// ```
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    ///
    #[inline(never)] // rabto in aad u hubiso in ay jiraan in meesha laga saaro ay jir ah halkan
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Sooceliyaa loox ka markii backtrace this la qabtay.
    ///
    /// Soo galitaankii ugu horreeyay ee jeexan waxay u egtahay inuu yahay shaqada `Backtrace::new`, iyo qaabka ugu dambeeya waxay u badan tahay inuu yahay wax ku saabsan sida xariggan ama howsha ugu weyni u bilaabantay.
    ///
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Haddii backtrace this waxaa la abuuray ka `new_unresolved` ka dibna shaqo this xalin doonaa dhammaan cinwaanada ee backtrace ah magacyadooda calaamad.
    ///
    ///
    /// Haddii gadaal hore loo xaliyay ama lagu abuuray `new`, shaqadani waxba ma qabanayso.
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// La mid ah `Frame::ip`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// La mid ah `Frame::symbol_address`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// La mid ah `Frame::module_base_address`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Sooceliyaa liiska astaamaha uu qaabkani u dhigmo.
    ///
    /// Caadi ahaan hal jir ayaa kaliya leh hal astaan, laakiin mararka qaarkood haddii tiro shaqooyin ah lagu sharraxay hal jir markaa calaamado badan ayaa la soo celin doonaa.
    /// Calaamadda ugu horreysa ee la taxay waa "innermost function", halka astaamaha ugu dambeeya ay yihiin kan ugu dambeeya (wicitaankii ugu dambeeyay).
    ///
    /// Ogsoonow in haddii qaabkani ka yimid dib-u-raadin aan la xallin markaa taasi waxay soo celin doontaa liis madhan.
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// La mid ah `Symbol::name`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// La mid ah `Symbol::addr`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// La mid ah `Symbol::filename`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// La mid ah `Symbol::lineno`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// La mid ah `Symbol::colno`
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Marka daabacaadda Waddooyinkiisa waxaan isku dayi inay dharka cwd haddii ay jirto, haddii kale waxaan kaliya ku qor Jidka as-waa.
        // Ogsoonow inaan sidoo kale tan u qabanno qaabka gaaban, maxaa yeelay haddii ay buuxdo waxaan u maleyneynaa inaan dooneyno inaan daabacno wax walba.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}