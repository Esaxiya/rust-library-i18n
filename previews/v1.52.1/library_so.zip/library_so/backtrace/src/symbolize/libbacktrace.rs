//! Istaraatiijiyadda astaamaha iyadoo la adeegsanayo lambarka baaritaanka DWARF ee libbacktrace.
//!
//! Maktabadda libbacktrace C, oo sida caadiga ah loogu qaybiyo gcc, waxay taageertaa oo keliya soo saarista gadaal (oo aynaan runti isticmaalin) laakiin sidoo kale waxay muujineysaa dib-u-soo-celinta iyo maaraynta macluumaadka qashin-qubka ee ku saabsan waxyaabaha sida looxyada tilmaamaya iyo waxa aan ahayn.
//!
//!
//! Tani way iska yara adag tahay sababo la xiriira walaacyo badan oo halkan ka jira, laakiin fikradda aasaasiga ahi waa:
//!
//! * Marka hore waxaan wacnaa `backtrace_syminfo`.Tani waxay kaheleysaa macluumaadka calaamadaha miiska astaamaha firfircoon haddii aan awoodno.
//! * Next aynu u qayshanno `backtrace_pcinfo`.Tani waxay kala shaandheyn doontaa miisaska 'debuginfo' haddii la heli karo waxayna noo oggolaaneysaa inaan ka soo kabanno macluumaadka ku saabsan looxyada hoose, filenames, lambarrada khadka, iwm.
//!
//! Waxaa jira badan oo xagga dulanka ku saabsan helitaanka miisaskii cilin galay libbacktrace, laakiin waxaan rajeynayaa ma ahan dhamaadka dunida iyo waa ku filan cad marka akhriska ka hooseeya.
//!
//! Tani waa istiraatiijiyadda astaanta asalka u ah barnaamijyada non-MSVC iyo non-OSX.In libstd in kastoo tani ay tahay istiraatiijiyaddii loogu talagalay OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Haddii ay suurtagal tahay door bidaan magaca `function` ah oo ka debuginfo yimaado oo caadi ahaan noqon karaa mid sax ah, waayo, mab Wabka tusaale ahaan.
                // Haddii taasi aysan joogin inkasta oo aad dib ugu laabanto magaca miiska astaanta ee ku qeexan `symname`.
                //
                // Xusuusnow in mararka qaar `function` ay dareemi karto xoogaa waxoogaa sax ah, tusaale ahaan in lagu qoro `try<i32,closure>` isntead of `std::panicking::try::do_call`.
                //
                // Waxaa run ahaantii ma cadda sababta, laakiin guud ahaan magaca `function` u muuqataa in badan oo sax ah.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // waxba ha qaban hada
}

/// Nooca of tilmaamaha `data` galay `syminfo_cb` maray
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Marka soo wicitaankan laga soo waco `backtrace_syminfo` markaan bilowno xalinta waxaan sii wadeynaa inaan wacno `backtrace_pcinfo`.
    // Waxqabadka `backtrace_pcinfo` wuxuu la tashan doonaa macluumaadka khaladka ah wuxuuna isku dayi doonaa inuu sameeyo waxyaabo sida soo kabashada macluumaadka file/line iyo sidoo kale looxyada tilmaamaya.
    // Xusuusnow in `backtrace_pcinfo` uu ku guuldareysan karo ama uusan wax badan qaban karin haddii uusan jirin wax qashin qodis ah, markaa haddii taasi dhacdo waxaan hubineynaa inaan ugu yeerno soo-celinta ugu yaraan hal astaan `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Nooca tilmaamaha `data` ayaa loo gudbiyay `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// The taageero API libbacktrace abuurista dawlad, laakiin waxa aanu taageero ku baabbi'iyo gobolka.
// Anigu shakhsi ahaan u qaadan si ay u dhigan tahay in gobolka waxaa loogu tala galay in la abuuray oo ku nool weligiis markaas.
//
// Waxaan jeclaan lahaa inaan diiwaangeliyo ilaaliyaha at_exit() oo nadiifiya gobolkan, laakiin libbacktrace ma bixiso waddo sidaas lagu sameeyo.
//
// Iyadoo caqabadaha kuwaas oo, shaqo this waxay leedahay dawlad jiidasho kaydin doono in loo xisaabiyaa markii ugu horeysay tan la codsaday.
//
// Xusuusnow in dib-u-socodsiinta dhammaan ay u dhacaan si taxaddar leh (hal quful caalami ah).
//
// Fiiro gaar ah la'aanta ah ee .Wadashaqayntaas halkan waxaa sabab u ah looga baahan yahay in `resolve` waxaa dibadda beehsa.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ha ku jimicsiin awoodaha sirta ah ee libbacktrace maxaa yeelay marwalba waxaan ugu yeernaa qaab isku duuban.
        //
        0,
        error_cb,
        ptr::null_mut(), // xog dheeri ah majiraan
    );

    return STATE;

    // Ogsoonow in dib u soo kabashada si ay u shaqeyso dhammaantood waxay u baahan tahay inay hesho macluumaadka khaaska ah ee DWARF ee hadda la fulin karo.Waxay caadi ahaan ku sameysaa taas iyada oo loo marayo dhowr farsamooyin ay ka mid yihiin, laakiin aan ku xaddidnayn:
    //
    // * /proc/self/exe on dhufto ee ay taageerayaan
    // * Magaca faylka ayaa si cad loo gudbiyay markii la abuurayay xaalad
    //
    // Maktabada maktabadda dib-u-soo-celinta waa waddo weyn oo ka kooban C code.Tani macnaheedu waa dabiici ahaan inay leedahay nuglaanta amniga xusuusta, gaar ahaan marka la xallinayo cillad khaldan.
    // Libstd waxay soo martay waxyaabo badan oo taariikhi ah.
    //
    // Haddii /proc/self/exe la isticmaalo markaa caadi ahaan waan iska indha tiri karnaa kuwan sida aan u maleyneyno in dib-u-soo-celinta ay tahay "mostly correct" oo haddii kale aysan ku dhicin waxyaabo yaab leh oo leh "attempted to be correct" faahfaahin qashin-qubka.
    //
    //
    // Haddii aan noqotay filename ah, si kastaba ha ahaatee, ka dibna waxaa suurtagal ah ku dhufto ee qaar ka mid ah (sida BSDs) halkaas oo actor ah xaasidnimo ah waxay keeni kartaa file ah aan sabab lahayn in lagu rakibaa meesha in.
    // Tani waxay ka dhigan tahay in haddii aan sheegi libbacktrace ku saabsan filename ah waxaa laga yaabaa in la isticmaalayo file ah loo aabo yeelin, ee ay keentay segfaults.
    // Haddii aan u sheegin wax libbacktrace kastoo ka dibna waxa ay wax ku dhufto ee aan taageero Waddooyinkiisa sida /proc/self/exe ma samayn doonaa!
    //
    // Marka la eego waxa aan isku dayeyno sida ugu macquulsan inaan * ku dhaafin magaca faylka, laakiin waa inaan dul saarnaa aagagga aan taageerin /proc/self/exe gabi ahaanba.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Ogsoonow in si fiican aan u isticmaali lahayn `std::env::current_exe`, laakiin uma baahnid halkan `std`.
            //
            // U adeegso `_NSGetExecutablePath` inaad ku shubto dariiqa hadda la fulin karo ee aagga taagan (oo haddii uu aad u yar yahay iska daa).
            //
            //
            // Fiiro gaar ah in aan si dhab ah isku halleeyaa libbacktrace halkan si aanay u dhiman on executables musuqmaasuqa, laakiin waxa hubaal ma ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows wuxuu leeyahay qaab feylasha lagu furo marka la furo ka dib lama tirtiri karo.
            // Taasi waa guud ahaan waxa aan halkaan ka dooneyno maxaa yeelay waxaan dooneynaa inaan hubino in fulinteena aan isbeddeleynin hoostayada ka dib markaan u dhiibno dib u soo celinta, waxaan rajeyneynaa yareynta awooda gudbinta xogta aan macquul ahayn ee dib u noqoshada (oo laga yaabo in si qaldan loo maamulo).
            //
            //
            // Marka la eego in aan halkan waxoogaa ka ciyaarno qoob ka ciyaarka halkan si aan isugu dayno in aan u helno nooc ka mid ah qufulka sawirkeenna:
            //
            // * Hel xamili ah in geeddi-socodka hadda, shuban ay filename.
            // * Fayl ku furo magacaas oo wata calammada saxda ah.
            // * Dib u cusbooneysii magaca faylka nidaamka socda, hubi inuu isku mid yahay
            //
            // Haddii in dhamaan waxaan ag maraaba in aragti dhab furay file our nidaamka iyo waxaan u damaanad qaaday ma beddeli doono.FWIW farabadan of this waxaa soo guuriyeen ka libstd taariikh ahaan, si fasirkii waa kan ugu fiican ee aan ka mid ah waxa dhacaya.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Tani waxay ku nool xusuusta guurto ah si aan u soo noqon karaa ..
                static mut BUF: [i8; N] = [0; N];
                // ... tanina waxay ku sii nooshahay xayndaabka tan iyo markii ay ku meelgaarka tahay
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // si ula kac ah u daadin halkan `handle` sababta oo ah furitaankaas waa inuu ilaaliyaa qufulkeenna magaca faylkan.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Waxaan dooneynaa inaan soo celino jeex nul-joojineysa, markaa haddii wax walba la buuxiyo oo ay u dhigmaan wadarta dhererka markaa waxay u dhigantaa in fashilka.
                //
                //
                // Haddii kale markaad soo noqoshada guusha hubso in nul byte lagu daro jeex.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // khaladaadka dib udhaca ayaa hada lagu xaaqay sagxada hoostiisa
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Wac `backtrace_syminfo` API kaas oo (laga bilaabo akhrinta koodhka) uu waco `syminfo_cb` si sax ah hal mar (ama uu ku guuldareysto qalad loo maleynayo).
    // Waxaan markaa wax badan ka qabaneynaa gudaha `syminfo_cb`.
    //
    // Ogsoonow inaan tan sameyno tan iyo markii `syminfo` ay la tashan doonto miiska astaamaha, helitaanka magacyada astaamaha xitaa haddii aysan jirin wax macluumaad khalad ah oo ku saabsan binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}