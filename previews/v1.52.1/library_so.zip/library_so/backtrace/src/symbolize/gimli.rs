//! Taageerada astaanta iyadoo la adeegsanayo `gimli` crate ee crates.io
//!
//! Tani waa hirgelinta astaanta asalka ah ee Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Noolaa ma guurto ah waa been in hack ku wareegsan tahay taageero la'aanta structs is-referential.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Diinta si 'nool guurto ah tan iyo calaamadaha waa in amaahan kaliya `map` iyo `stash` oo aan iyaga ilaalinteedu hoos.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Si aad ugu shubto maktabadaha hooyo Windows, eeg xoogaa dood ah oo ku saabsan rust-lang/rust#71060 xeeladaha kala duwan halkan.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW hadda maktabadaha ma taageersani ASLR (rust-lang/rust#16514), laakiin DLLs wali waa la raray kartaa in meel cinwaanka.
            // Waxay u muuqataa in cinwaanada ee info Debug jira oo dhan sida haddii maktabadda this waxaa ku raran ay "image base", taas oo ah beer in madax ay file COFF.
            // Maaddaama ay tani tahay waxa debuginfo u muuqda inaan liis garaynayno waxaannu kala shaandheynaynaa miiska astaamaha iyo cinwaannada kaydinta sida haddii maktabadda lagu raray "image base" sidoo kale.
            //
            // Maktabadda waxaa laga yaabaa inaan la rarin at "image base", si kastaba ha ahaatee.
            // (waxaa macquul ah in wax kale halkaas lagu rakibo?) Tani waa halka garoonka `bias` ka soo galayo, waxaana u baahanahay inaan ku ogaanno qiimaha `bias` halkan.Nasiib darrose inkasta oo aysan caddeyn sida looga helo tan moduleka la rakibey.
            // Waxa aan hayno, si kastaba ha noqotee, waa cinwaanka culeyska dhabta ah ee (`modBaseAddr`).
            //
            // In yar oo ka mid ah nuqul-soo-saarista ayaan hadda hagaajineynaa feylka, akhri macluumaadka cinwaanka faylka, ka dibna hoos u dhig mmap.Tani waa qashin maxaa yeelay waxay u badan tahay inaan dib u fureyno mmap goor dambe, laakiin tani waa inay sifiican ugu shaqeysaa hada.
            //
            // Mar alla markii aan helno `image_base` (meesha xamuulka la doonayo) iyo `base_addr` (goobta xamuulka dhabta ah) waxaan buuxin karnaa `bias` (farqiga u dhexeeya kan dhabta ah iyo kan la doonayo) ka dibna cinwaanka la sheegay ee qayb kasta waa `image_base` maadaama taasi ay tahay waxa faylkaas dhahayo.
            //
            //
            // Waqtigaan la joogo waxay umuuqataa in aan ka duwanahay ELF/MachO aan ku sameyn karno hal qeyb halkii maktabad, innagoo adeegsaneyna `modBaseSize` sida cabirka oo dhan.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS wuxuu adeegsadaa qaabka feylka 'Mach-O' wuxuuna adeegsadaa 'DYLD-specific APIs' si uu ugu raro liiska maktabadaha u gaarka ah ee ka tirsan arjiga.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Soo qaado magaca maktabaddan oo u dhiganta jidka meesha loo rarayo sidoo kale.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Shuban madax image maktabadda iyo Ergay this si `object` in quburada dhan amarrada load si aan u fahmi karaa dhammaan qeybaha halkan ku lug.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ku ficil qeybaha oo diiwaangeli gobollada la yaqaan ee qaybaha aan ka helno.
            // Intaa waxaa sii dheer in la qoro qaybo qoraal ah oo macluumaad ah si loogu shaqeeyo ka dib, fiiri faallooyinka hoose.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Go'aaminta "slide" ee maktabadda oo kor u dhamaado isagoo eexda ah aan u isticmaalno si ay tiradaasi meesha in waxyaabaha xasuusta waxaa ku raran yihiin.
            // Tani waa wax yar xisaabinta cajiibka ah inkasta oo ay tahay natiijada isku dayga waxyaabo yar oo duurka ah oo aad aragto waxa ku dheggan.
            //
            // Fikradda guud waa in `bias` oo lagu daray qeybta ah ee `stated_virtual_memory_address` waxa uu noqon doonaa meesha cinwaanka meesha bannaan ee dhabta ah degan qeybta.
            // Waxyaabaha kale ee aan ku tiirsannahay inkasta oo cinwaanka dhabta ah laga jaray `bias` waa tusmada si loo eego miiska calaamadda iyo debuginfo.
            //
            // Waxaa soo baxday, in kastoo, in maktabadaha nidaamka raran xisaabaha kuwani waa sax ahayn.Si kastaba ha noqotee, kuwa fuliya dhalashada, waxay u muuqataa inay sax yihiin.
            // Qaadayso qaar ka macquulka ah ka il LLDB ayaa waxa ay qaar ka mid ah oo gaar ah-sanduuqa battariga ee qaybta ugu horeysay `__TEXT` ka file raran mowjadda 0 leh size nonzero ah.
            // Waayo, wax alla sabab markii this joogo waxa ay u muuqataa in ay ka dhigan tahay in miiska calaamad u yahay qof qaraabo ah in ay kaliya slide vmaddr for maktabadda ah.
            // Haddii ay *aan* joogo ka dibna miiska calaamad u yahay qof qaraabo ah u slide vmaddr oo lagu daray cinwaanka qeybta ayaa sheegatey.
            //
            // Si aan ula tacaalno xaaladdan haddii aynaan * ka helin qayb qoraal ah feyl-ka jaangooyada eber ka dib waxaan ku sii kordhin doonnaa eexashada qaybaha qoraalka ugu horreeya cinwaanka la sheegay oo waxaan ku yareyneynaa cinwaanada la sheegay oo dhan sidoo kale.
            //
            // Qaabkaas miiska calaamaddu had iyo jeer wuxuu umuuqdaa qaddarka eexashada maktabadda.
            // Tani waxay u muuqataa in ay leeyihiin natiijada saxda ah ee turjumaya via miiska astaanta.
            //
            // Daacadii si buuxda uma hubo inay tani sax tahay ama inay jiraan wax kale oo tilmaamaya sida loo sameeyo tan.
            // Hada inkasta oo tani ay umuuqato inay sifiican ushaqeyneyso (?) waana inaan marwalba awoodnaa inaan kadhigno tan waqti kabadan hadii loo baahdo.
            //
            // Wixii macluumaad dheeraad ah eeg #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix kale (tusaale
        // Linux) barnaamijyadu waxay u adeegsadaan ELF qaab feylal shay ah waxayna si caadi ah u hirgeliyaan API la yiraahdo `dl_iterate_phdr` si ay u rartaan maktabadaha u dhashay.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` waa in ay a tilmaamo ansax ah.
        // `vec` waa in ay ahaataa pointer sax ah si `std::Vec` ah.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 asal ahaan ma taageerayo faahfaahinta khaladka, laakiin nidaamka dhismuhu wuxuu dhigayaa macluumaadka khaladka jidka `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Wax kasta oo kale waa inay isticmaalaan ELF, laakiin ma garanayaan sida loo raro maktabadaha hooyo.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Dhamaan maktabadaha yaqaan wadaago in la rartay.
    libraries: Vec<Library>,

    /// Kaydka khariidadaha halkaas oo aan ku haysanno macluumaad duug ah oo la yaabay.
    ///
    /// Liiskani wuxuu leeyahay awood go'an oo wiishkiisa oo dhan aan weligiis kordhin.
    /// element `usize` ee labada nin kasta waa index galay `libraries` kor ku xusan meesha `usize::max_value()` ka dhigan eedeysanuhu hadda.
    ///
    /// `Mapping` wuxuu u dhigmaa macluumaadka cufan ee cufan.
    ///
    /// Fiiro gaar ah in tani ay asal ahaan waa kayd LRU ah oo aan doonaa la wareegaayo wax agagaarka halkan sida aan summad cinwaanada.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Qaybaha maktabadani waxay ku raran yihiin xusuusta, iyo halka ay ku raran yihiin.
    segments: Vec<LibrarySegment>,
    /// The "bias" maktabadda this, sida caadiga ah halkaas oo uu ku raran galay xasuusta.
    /// Qiimahaan waxaa lagu darayaa cinwaan kasta oo cinwaankiisa la sheegay si loo helo cinwaanka dhabta ah ee cinwaanka xusuusta ee qeybta lagu shubay.
    /// Intaa waxaa sii dheer eexdan waxaa laga jarayaa cinwaanada xusuusta ee dalwaddii dhabta ah si loogu muujiyo debuginfo iyo miiska astaamaha.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Cinwaanka lagu sheegay qaybtaan ku jirta feylka sheyga.
    /// Tani runti maahan meesha qeybta lagu shubay, laakiin waa cinwaankan oo lagu daray maktabadda ay ku jirto ee `bias` waa halka laga helo.
    ///
    stated_virtual_memory_address: usize,
    /// Cabirka qaybta ths ee xusuusta.
    len: usize,
}

// ammaan ahayn sababta oo ah waxaa loo baahan yahay in la dibadda beehsa
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ammaan ahayn sababta oo ah waxaa loo baahan yahay in la dibadda beehsa
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // A, kayd LRU mid aad u fudud oo aad u yar for khariidado info Debug.
        //
        // Heerka hit waa in uu noqdo mid aad u sarreeya, tan iyo xidhmooyin caadiga ah ma goyn maktabado badan la wadaago.
        //
        // Qaab-dhismeedka `addr2line::Context` waa qaali in la abuuro.
        // Qiimaheeda waxaa lafilayaa in lagu qoro su'aalaha xiga ee `locate`, kuwaas oo ka faa'iideysanaya dhismooyinka la dhisay markii la dhisayay 'addr2line: : Context`s si loo helo xawaare fiican.
        //
        // Haddaanan haysan kaydkan, amortiation-ka weligiis ma dhici doono, oo calaamadaha dib u noqoshada waxay noqon doonaan ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Marka hore, tijaabi haddii `lib` ani uu leeyahay qayb kasta oo ka kooban `addr` (maaraynta dib u dejinta).Haddii jeeggan uu dhaafo markaa waan sii wadi karnaa hoosta oo runtii waan tarjumi karnaa cinwaanka.
                //
                // Fiiro gaar ah in aan la isticmaalayo `wrapping_add` halkan si looga fogaado in la faafi jeegaga.Waxaa lagu arkay duurjoogta in xisaabinta SVMA + eexdu ay buuxsamayso.
                // Waxay umuuqataa xoogaa qariib ah inay dhici laheyd laakiin ma jiraan qaddar aad u badan oo aan ka qaban karno marka laga reebo inay u badan tahay inaan iska indhatirno qaybahaas maadaama ay u badan tahay inay tilmaamayaan meel bannaan.
                //
                // Tani waxay asal ahaan wuxuu u soo baxay in rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Hadda oo aan ognahay in `lib` ay ku jirto `addr`, waxaan ku dheellitiri karnaa eexda si aan u helno cinwaanka xusuusta akhlaaqda leh.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: ka dib markii this Gabagabeysey shuruud la'aan hore soo laabtay
        // ka baadi ah, entry kayd waddo this yahay index 0.

        if let Some(idx) = idx {
            // Markay khariidaduhu horeyba ugu jirtay keydka, u dhaqaaq xagga hore.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Markay khariidaduhu ku jirin kaydka, samee khariidad cusub, geli qeybta hore ee keydka, oo ka saar meesha ugu da'da weyn ee laga soo galo haddii loo baahdo.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // Ha daadin nolosha `'static`, intaad nooshahay iska hubi
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Kordhi cimrigaaga `sym` illaa `'static` maadaama nasiib daro halkan nalaga doonayo, laakiin marwalba marwalba tixraac ahaan bey u baxaysaa sidaa darteed tixraac malahan in lagu sii adkeysto wixii ka dambeeya qaabkan.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Ugu dambeyntiina, hel khariidad kayd ah ama u samee khariidad cusub faylkan, oo qiimee macluumaadka DWARF si aad u hesho file/line/name cinwaankan.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Waxaan awoodnay inaan helno macluumaadka qaabdhismeedka astaantan, iyo 'addr2line' qaabkeeda gudaha waxay leedahay dhammaan faahfaahinta xasaasiga ah.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Waan heli kari waayey macluumaad khalad ah, laakiin waxaan ka helnay jadwalka astaamaha elf la fulin karo.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}