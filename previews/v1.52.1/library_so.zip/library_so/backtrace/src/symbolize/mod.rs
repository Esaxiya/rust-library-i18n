use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// U xalliso cinwaan astaan, adigoo u sii gudbinaya calaamadda xiritaanka cayiman.
///
/// Shaqadani waxay eegi doontaa cinwaanka la siiyay meelaha sida miiska astaamaha maxalliga ah, miiska astaamaha firfircoon, ama macluumaadka khaaska ah ee DWARF (waxay kuxirantahay hirgelinta firfircoon) si loo helo astaamo lagu soo saaro.
///
///
/// Xiritaanka waxaa laga yaabaa in aan la soo wicin haddii aan xal la sameyn karin, waxaana sidoo kale loo yeeri karaa in ka badan hal mar marka laga hadlayo howlaha la tilmaamay.
///
/// Calaamadaha la soo saaray waxay ka dhigan yihiin fulinta `addr`, iyadoo lagu soo celinayo lambarada file/line cinwaankaas (haddii la heli karo).
///
/// Xusuusnow haddii aad haysato `Frame` markaa waxaa lagugula talinayaa inaad adeegsato shaqada `resolve_frame` halkii aad ka isticmaali lahayd tan.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
/// # Panics
///
/// Hawshani waxay ku dadaalaysaa in aan waligeed panic, laakiin haddii `cb` uu bixiyo panics markaa barnaamijyada qaarkood waxay ku qasbi doonaan panic labalaab ah si ay u soo ridaan hawsha.
/// Nidaamyada qaar waxay adeegsadaan maktabadda C oo gudaha ku dhex adeegsata soo-celinta wicitaannada oo aan lagu soo koobi karin, sidaa darteed argagaxa ka imanaya `cb` wuxuu kicin karaa geedi socodka soo rididda.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // kaliya fiiri qaabka sare
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Xalliyaan qaab hore u qabasho astaan, adigoo u gudbinaya calaamadda xiritaanka cayiman.
///
/// Functin-kani wuxuu sameeyaa isla shaqada `resolve` marka laga reebo inay qaadanayso `Frame` dood ahaan halkii cinwaan laga siin lahaa.
/// Tani waxay u oggolaan kartaa qaar ka mid ah hirgelinta barnaamijyada dib-u-socod si ay u bixiso macluumaad calaamado sax ah ama macluumaad ku saabsan meerayaasha laydhka tusaale ahaan.
///
/// Waxaa lagugula talinayaa inaad tan isticmaasho haddii aad awoodid.
///
/// # Tilmaamaha loo baahan yahay
///
/// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
///
/// # Panics
///
/// Hawshani waxay ku dadaalaysaa in aan waligeed panic, laakiin haddii `cb` uu bixiyo panics markaa barnaamijyada qaarkood waxay ku qasbi doonaan panic labalaab ah si ay u soo ridaan hawsha.
/// Nidaamyada qaar waxay adeegsadaan maktabadda C oo gudaha ku dhex adeegsata soo-celinta wicitaannada oo aan lagu soo koobi karin, sidaa darteed argagaxa ka imanaya `cb` wuxuu kicin karaa geedi socodka soo rididda.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // kaliya fiiri qaabka sare
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// qiimaha IP ka loox xidhmooyin caadi ahaan waa (always?) edbinta * * ka dib markii call in ay raad ku xidhmooyin dhabta ah.
// Turjumaya this on sababaha tirada filename/line in ay ka mid noqon ka hor iyo laga yaabee galay booska haddii ay ku dhow dhamaadka shaqada.
//
// Tani waxay u muuqataa inay asal ahaan had iyo jeer tahay kiisaska dhammaan meeraha, sidaa darteed waxaan had iyo jeer ka goynaa mid ka mid ah ip xalliyay si aan ugu xallino tilmaamtii wicitaankii hore halkii tilmaanta lagu celin lahaa.
//
//
// Fikrad ahaan sidan ma aanan sameyn doonin.
// Fikrad ahaan waxaan ubaahanahay dadka soo waca `resolve` APIs halkan inay gacanta ku qabtaan -1 oo ay ku xisaabtamaan inay rabaan macluumaadka goobta loogu talagalay * tilmaamihii hore, ee aan ahayn kan hada socda.
// Sida habboon in aan sidoo kale soo bandhigaan lahaa on `Frame` haddii aynu nahay cinwaanka edbinta ee soo socda ama hadda.
//
// Hadda inkasta oo tani ay tahay walaac qurxoon oo qurux badan sidaa darteed gudaha uun ayaan had iyo jeer uga goynaa mid.
// Macaamiisha waa inay sii wadaan shaqada oo ay helaan natiijooyin wanaagsan, sidaa darteed waa inaan fiicnaano.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// La mid ah `resolve`, kaliya aan amaan ahayn maadaama aysan isku xirnayn.
///
/// Hawshani ma lahan waxqabadyo walaalo laakiin waa la heli karaa marka muuqaalka `std` ee crate aan la soo ururin.
/// Ka eeg shaqooyinka `resolve` wixii dukumiinti iyo tusaalooyin dheeri ah.
///
/// # Panics
///
/// Ka eeg macluumaadka `resolve` wixii ku saabsan digniinta `cb` oo argagaxsan.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// La mid ah `resolve_frame`, kaliya aan amaan ahayn maadaama aysan isku xirnayn.
///
/// Hawshani ma lahan waxqabadyo walaalo laakiin waa la heli karaa marka muuqaalka `std` ee crate aan la soo ururin.
/// Ka eeg shaqooyinka `resolve_frame` wixii dukumiinti iyo tusaalooyin dheeri ah.
///
/// # Panics
///
/// Ka eeg macluumaadka `resolve_frame` wixii ku saabsan digniinta `cb` oo argagaxsan.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait oo mataleysa xallinta astaamaha feyl ku jira.
///
/// trait-kan waxaa loo siiyay shey ahaan 'trait' xiritaanka la siiyay shaqada `backtrace::resolve`, waana la diri karaa iyadoo aan la ogeyn hirgelinta ka dambeysa.
///
///
/// Astaantu waxay ku siin kartaa macluumaad macno leh oo ku saabsan hawl, tusaale ahaan magaca, faylka, nambarka khadka, cinwaanka saxda ah, iwm.
/// Macluumaadka oo dhan had iyo jeer laguma heli karo astaan, si kastaba ha noqotee, sidaas darteed dhammaan hababka waxay soo celiyaan `Option`.
///
///
pub struct Symbol {
    // TODO: noloshiisa oo dhan waxay u baahan tahay in lagu adkeysto ugu dambeyn `Symbol`,
    // laakiin taasi hadda waa isbeddel jabinaya.
    // Waayo, hadda taasi waa ammaan tan iyo `Symbol` waa kaliya wareejiyay baxay by tixraac oo aan la gjærceler karo.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Wuxuu soo celiyaa magaca shaqadan.
    ///
    /// Qaab dhismeedka la soo celiyey waxaa loo isticmaali karaa in lagu waydiiyo waxyaabo kala duwan oo ku saabsan magaca calaamadda:
    ///
    ///
    /// * Hirgelinta `Display` ayaa daabacan doonta calaamadda xardhan.
    /// * Qiimaha ceyriinka `str` ee calaamadda waa la heli karaa (haddii ay ansax tahay utf-8).
    /// * Baytiyada ceyrsan ee magaca astaamaha waa la heli karaa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Sooceliyaa cinwaanka bilowga ah ee shaqadan.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Sooceliyaa filename xumu sida jeex ah.
    /// Tani badanaa waxay waxtar u leedahay deegaanka `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Sooceliyaa nambarka safka halka calaamaddan hadda lagu fulinayo.
    ///
    /// Kaliya gimli hadda qiimaha halkan iyo xataa markaas oo keliya haddii `filename` laabtay `Some`, oo sidaasuu ka dibna ku xiran yahay digniinahaa la mid ah awgeed.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Waxay soo celisaa tirada line ee meesha calaamad this ayaa hadda dileen.
    ///
    /// Qiimaha soo laabtay Tani caadi ahaan waa `Some` haddii `filename` laabtay `Some`, oo sidaas awgeed uu ku xiran yahay digniinahaa la mid ah.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Sooceliyaa magaca feylka halka shaqadan lagu qeexay.
    ///
    /// Tani hadda waxaa la heli karaa oo keliya marka dib-u-celinta ama gimli la isticmaalayo (tusaale
    /// unix dhulalka kale) iyo marka binary lagu soo ururiyo debuginfo.
    /// Haddii labadaas xaaladood midkoodna la buuxin waayo markaa waxay u badan tahay inay soo noqon doonto `None`.
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Waxaa laga yaabaa in a C parsed++ calaamad, haddii parsing astaanta Careeyey sida Rust ku guuldareystay.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Hubso inaad haysato cabbirkan eber ah, si muuqaalka `cpp_demangle` uusan wax kharash ah ku bixin marka aad naafo tahay.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Duub ku wareegsan magaca astaanta si loo siiyo marin-u-qaadeyaasha ergonomic ee magaca la gooyey, bytes-ka ceyriinka ah, xarigga ceyriinka, iwm.
///
// U oggolow koodhka dhinta marka muuqaalka `cpp_demangle` uusan shaqeynin.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Waxay ka abuurtaa magac calaamadeysan meertada hoose ee ceeriin.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Sooceliyaa magaca cayriin (mangled) calaamad sida `str` haddii uu calaamad u yahay ansax utf-8.
    ///
    /// Adeegso hirgelinta `Display` haddii aad rabto nooca isdifaacay.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Sooceliyaa magaca calaamad cayriin sida liiska bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Tani waa laga yaabaa in la daabaco haddii calaamadda xagjirka ah aysan run ahaantii ansax ahayn, markaa khaladka halkan si quruxsan ugu qabso adigoon dibedda ku faafin.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Isku day inaad dib u soo ceshato xusuusta xafidan ee loo isticmaalay in lagu muujiyo cinwaanada.
///
/// Qaabkani wuxuu isku dayi doonaa inuu sii daayo wixii qaab dhismeedka xogta caalamiga ah ah ee haddii kale lagu kaydiyey adduunka ama dunta taas oo sida caadiga ah matalaysa xogta DWARF ee la baaray ama wixii la mid ah.
///
///
/// # Caveats
///
/// Inkastoo shaqo tani had iyo jeer waxaa laga heli karaa waxa aanu si dhab ah wax ku fulintii ugu sameeyo.
/// Maktabadaha sida dbghelp ama libbacktrace ma bixiyaan tas-hiilaad si loogu kala qeybiyo gobolka loona maareeyo xusuusta loo qoondeeyey.
/// Haatan muuqaalka `gimli-symbolize` ee crate ayaa ah muuqaalka kaliya ee shaqadan ay saameyn ku leedahay.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}