// kaliya loo isticmaalo on Linux hadda, sidaas ogolaan code dhintay meelo kale
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Aag fududeeye qoondeeye ah oo loogu talagalay keydka
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// U qoondeeyaa bakhaar cabirka la cayimay oo u soo celiyaa tixraac la beddeli karo.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // BADBAADADA: Kani waa shaqada kaliya ee abid dhista wax la beddelo
        // tixraac `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // AMMAANKA: waligeen kama saari karno walxaha `self.buffers`, marka tixraac
        // xogta ku jirta keyd kasta ayaa noolaan doonta illaa inta `self` uu jiro.
        &mut buffers[i]
    }
}