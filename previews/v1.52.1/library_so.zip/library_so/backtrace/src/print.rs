#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Qaabeeye loogu talagalay gadaal gadaal
///
/// Noocaan ayaa loo isticmaali karaa in lagu daabaco gadaal gadaal iyada oo aan loo eegin meesha ay lafteeda ka soo jeedo.
/// Haddii aad qabto nooca `Backtrace` ah ka dibna ay fulinta `Debug` hore u adeegsanayaa qaab daabacaad this.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Noocyada daabacaadda ee aan daabacan karno
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Daabacayaa backtrace terser oo fikir keliya ku jira macluumaad khuseeya a
    Short,
    /// Waxay daabacdaa gadaal gadaal oo ay ku jiraan dhammaan macluumaadka suurtogalka ah
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Abuur `BacktraceFmt` cusub kaas oo wax ku qori doona wax soo saarka `fmt` ee la siiyay.
    ///
    /// Doodda `format` ayaa xakamayn doonta qaabka gadaal loo daabaco, doodda `print_path` ayaa loo isticmaali doonaa in lagu daabaco dhacdooyinka `BytesOrWideString` ee faylasha.
    /// Noocaani laftiisa ma sameeyo daabacaadda magacyada faylka, laakiin dib u soo wicitaankan waxaa looga baahan yahay inuu sidaas sameeyo.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Daabacaa horudhac loogu talagalay gadaasha dambe ee la daabacayo.
    ///
    /// Tan waxaa looga baahan yahay barmaamijyada qaar ee gadaal u noqoshada si buuxda astaamaha loogu muujiyo hadhow, haddii kale tani waa inay noqotaa habka ugu horreeya ee aad wacdo ka dib abuurista `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Waxay kudareysaa qaab soosaarka gadaal
    ///
    /// Ballanqaadkani wuxuu soo celinayaa tusaale RAII ah `BacktraceFrameFmt` kaas oo loo isticmaali karo in si dhab ah loo daabaco jir, burburka ayayna kordhin doontaa miiska dhismaha.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Dhameystiraya soosaarka gadaal
    ///
    /// Tani waxay hadda waa no-op laakiin loogu dari waafaqsan future la qaabab backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Waqtigan xaadirka ah 'no-op'-oo ay kujirto tan hook si loogu oggolaado kudarista future.
        Ok(())
    }
}

/// Qaabeeye kaliya hal qaab oo gadaal ah.
///
/// Noocaan waxaa abuuray by function `BacktraceFmt::frame` ah.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Wuxuu ku daabacaa `BacktraceFrame` qaabeynta qaab-dhismeedka.
    ///
    /// Tani recursively daabacan doonaa dhammaan xaaladaha `BacktraceSymbol` gudahood `BacktraceFrame` ah.
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Daabacayaa `BacktraceSymbol` gudahood `BacktraceFrame` ah.
    ///
    /// # Tilmaamaha loo baahan yahay
    ///
    /// Shaqadani waxay u baahan tahay muuqaalka `std` ee `backtrace` crate in la kartiyeeyo, muuqaalka `std`-na waxaa loogu shaqeysiiyay si caadi ah.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: tani ma ahan wax weyn in aanaan aakhirka waxba daabicin
            // oo ay ku qoran yihiin magacyadooda aan utf8 ahayn.
            // Nasiib wanaagse wax walba waa utf8 marka tani ma aha inay aad u xun tahay.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Waxay daabacdaa raadin cayriin ah `Frame` iyo `Symbol`, oo sida caadiga ah laga soo qaado dib-u-soo-celinta cayriin ee crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Waxay kudareysaa shax ceyriin ah soo-saarista gadaal.
    ///
    /// Habkani, oo ka duwan kii hore, wuxuu qaataa doodaha cayriin haddii ay ilo ka yimaadaan meelo kala duwan.
    /// Ogsoonow in tan loogu yeeri karo dhowr jeer hal qaab.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Darayaa jir ah ceeriin in ay wax soo saarka backtrace ah, oo ay ku jiraan macluumaad column.
    ///
    /// Habkani, sida kii hore, wuxuu qaataa doodaha cayriin haddii ay ilo ka yimaadaan meelo kala duwan.
    /// Ogsoonow in tan loogu yeeri karo dhowr jeer hal qaab.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ma awoodo inay astaan ku dhex sameyso geedi socod sidaa darteed waxay leedahay qaab gaar ah oo loo isticmaali karo in lagu calaamadeeyo hadhow.
        // Ku daabac halkii aad cinwaannada ku daabici lahayd qaabkeenna halkan.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Looma baahna in la daabaco looxyada "null", asal ahaan waxay kaliya ka dhigan tahay in nidaamka gadaal uu xoogaa xiisaynayay inuu dib u raadiyo meel fog.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Si loo yareeyo cabbirka TCB ee Sgx enclave, ma dooneyno inaan ku hirgalino shaqeynta xalinta calaamadaha.
        // Taabadalkeed, waxaan ku daabacan karnaa cinwaanka cinwaanka halkan, oo hadhow la khariidayn karo si loo saxo shaqada.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Daabac tusmada qaabka iyo sidoo kale tilmaamaha ikhtiyaariga ah ee tilmaamaha qaabka.
        // Haddii aan ka gudubnay astaantii ugu horreysay ee qaabkan inkasta oo aan daabacno meel bannaan oo ku habboon.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Marka xigta qor magaca astaamaha, adoo adeegsanaya qaabab kale oo aad ku heli karto macluumaad dheeri ah haddii aan nahay dib-u-socod buuxa.
        // Halkan waxaan sidoo kale ku qabannaa astaamo aan magac lahayn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Iyo socon ilaa, ku qor lambarka filename/line haddii ay tahay heli karo.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line waxaa lagu daabacaa xariiqyada hoosta magaca calaamadda, markaa ku daabac meelaha bannaan ee ku habboon si aad u kala soocdo annaga oo midigna isu toosinno.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Igmashada callback gudaha daabacayo filename ka dibna ku qor lambarka khadka.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Kudar lambarka tiirka, haddii la heli karo.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Waxaan kaliya dan ka leenahay astaamaha ugu horreeya ee jir
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}