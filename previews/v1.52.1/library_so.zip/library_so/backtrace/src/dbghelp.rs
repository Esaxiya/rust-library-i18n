//! module A si ay u caawiyaan in maaraynta bindings dbghelp on Windows
//!
//! Backtraces on Windows (ugu yaraan MSVC) waxaa inta badan ku shaqeeya iyada oo loo marayo `dbghelp.dll` iyo hawlaha kala duwan ee uu ka kooban yahay.
//! Hawlahan ayaa hadda lagu dhejiyaa *firfircoon* halkii ay ku xirnaan lahaayeen `dbghelp.dll` qaab ahaan.
//! Tan waxaa hadda sameeya maktabadda caadiga ah (waana aragti ahaan looga baahan yahay halkaas), laakiin waa dadaal lagu doonayo in lagu caawiyo yareynta ku tiirsanaanta dll ee maktabadda maaddaama dib-u-soo-noqoshada ay caadi ahaan ikhtiyaar u tahay.
//!
//! Taas ayaa la dhahay, `dbghelp.dll` waxay had iyo jeer si guul leh ugu rartaa Windows.
//!
//! Xusuusnow inkasta oo tan iyo markii aan ku dhejineyno dhammaan taageeradan si firfircoon u adeegsan karno dhab ahaan ma isticmaali karno qeexitaannada cayriin ee `winapi`, laakiin waxaan u baahanahay inaan qeexno noocyada tilmaanta shaqadeena annaga oo adeegsanno taas.
//! Ma dhab ahaan doonayaan in ay ganacsi ee duplicating winapi, sidaasi darteed waa inaan feature Cargo a `verify-winapi` oo uu tilmaamayaa in dhammaan bindings dhigma kuwa winapi iyo habkaani waa karti on CI.
//!
//! Ugu dambayntii, aad halkan la soco doonaa in dll ee `dbghelp.dll` marna ku mashquulsanayeen, iyo in ay haatan ula kac ah.
//! Fikirka ayaa ah inaan caalami ahaan ku keydin karno oo aan u adeegsan karno inta udhaxeysa wicitaanada API, anagoo iska ilaalinayna qaali loads/unloads.
//! Haddii ay taasi waa dhibaato waayo qalabka dillaac ama wax u eg in aan gudbi karo buundada marka aynu halkaa gaadhno.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Work agagaarka `SymGetOptions` iyo `SymSetOptions` isagoo aan ahayn joogo winapi in laftiisa.
// Haddii kale tan waxaa loo isticmaalaa oo keliya markaan labalaab ka hubineyno noocyada kala duwan ee winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi laguma qeexin weli
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tan waxaa lagu qeexay winapi, laakiin waa khalad (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi laguma qeexin weli
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Macro waxaa loo isticmaalaa in lagu qeexo qaabdhismeedka `Dbghelp` kaas oo gudaha ku jira dhammaan tilmaamayaasha shaqada ee aan ku rarno.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL-ga la raray ee `dbghelp.dll`
            dll: HMODULE,

            // pointer shaqo kasta oo shaqo kasta oo aan u isticmaalno waxaa laga yaabaa
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Markii hore maanu raran DLL-ka
            dll: 0 as *mut _,
            // Initiall hawlaha oo dhan ayaa lagu wadaa inay eber in la yidhaahdo waxay u baahan yihiin in la dynamically raran.
            //
            $($name: 0,)*
        };

        // Nooc kasta oo shaqo ku habboon.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Isku dayga furitaanka `dbghelp.dll`.
            /// Waxay soo celisaa guusha haddii ay shaqeyso ama qalad haddii `LoadLibraryW` guuldareysto.
            ///
            /// Panics haddii maktabaddu horay u rakibnayd.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Waxqabadka qaab kasta oo aan jeclaan lahayn inaan u adeegsanno.
            // Markii loo yeero waxay aqrin doontaa tilmaamaha shaqada keydka ah ama wey shubi doontaa waxayna soo celin doontaa qiimaha la rakibey.
            // Xamuulka ayaa la xaqiijiyay inuu guuleysto.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // wakiil sahlanaato in ay isticmaalaan handarraabbadeedii nadiifinta in hawlaha dbghelp tixraaca.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize oo dhan taageero lagama maarmaanka u ah hawlaha API helaan `dbghelp` ka crate this.
///
///
/// Ogsoonow in shaqadani ay tahay **amaan**, gudaha waxay leedahay iswaafajin u gaar ah.
/// Sidoo kale ogsoonow inay nabdoon tahay in loo waco shaqadan dhowr jeer si isdaba-joog ah.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Waxa ugu horeeya ee aan ubaahanahay inaan sameyno waa inaan waafajino shaqadan.Tan waxaa loogu yeeri karaa si isku mid ah mawduucyo kale ama dib ugu soo noqnoqoshada hal thread.
        // Xusuusnow inay ka khiyaano badan tahay inkasta oo maxaa yeelay waxa aan halkan ku isticmaaleyno, `dbghelp`,*sidoo kale* waxay u baahan yihiin in lala waafajiyo dhammaan dadka kale ee wacaya `dbghelp` hawshan.
        //
        // Caadi ahaan ma jiraan wicitaano badan oo loo soo diro `dbghelp` isla hawsha isla markaana waxaan u maleyneynaa inaan si aamin ah u qaadan karno inaan nahay kuwa kaliya ee marin u hela.
        // Si kastaba ha noqotee, waxaa jira hal isticmaale kale oo aasaasi ah oo aan ka walwalsanahay kaas oo si macquul ah nafteena u ah, laakiin maktabadda caadiga ah.
        // Maktabada caadiga ah ee 'Rust' waxay kuxirantahay tan crate taageerada gadaal, crate-kan sidoo kale wuxuu kujiraa crates.io.
        // Tani waxay ka dhigan tahay in haddii maktabadda caadiga ah waxaa daabacaadda backtrace panic ah waxaa laga yaabaa in la crate ka crates.io soo socda, taasoo keenta segfaults jinsi.
        //
        // Si looga caawiyo xallinta dhibaatadan is-waafajinta waxaan ka shaqeyneynaa khiyaano Windows-gaar ah halkan (waa, ka dib oo dhan, xannibaad Windows-gaar ah oo ku saabsan iswaafajinta).
        // Waxaan abuuraynaa *fadhiga-maxaliga ah* magacaaban mutex si loo ilaaliyo wicitaankan.
        // Ujeedada halkan ayaa ah in maktabada caadiga ah iyo tan crate aysan aheyn inay wadaagaan heerka Rust APIs si ay halkan ugala wada shaqeeyaan laakiin taa badalkeeda waxay ka shaqeyn karaan daaha gadaashiisa si loo hubiyo inay iswaafajinayaan midba midka kale.
        //
        // Sidaas marka function tani waxaa la yiraahdaa dhex maktabadda caadiga ah ama iyada oo loo marayo crates.io aan u hubino in mutex isla la helay.
        //
        // Marka intaas oo dhami waa in la dhaho waxa ugu horeeya ee aan halkaan ku sameyno waa inaan si toos ah u abuurno `HANDLE` oo ah magac mutex ah oo ku yaal Windows.
        // Waxaan waxoogaa iskudhafaneynaa mawduucyo kale oo sifiican ula wadaagaya shaqadan si gaar ah waxaanna hubineynaa in kaliya hal gacan lagu sameeyo tusaale ahaan shaqadan.
        // Xusuusnow in gacan ku haynta marna la xirin mar haddii lagu keydiyo adduunka.
        //
        // Ka dib markaan dhab ahaan u tagno qufulka waxaan si fudud u helnaa, oo xamaaladeena `Init` ee aan dhiibno ayaa mas'uul ka noqon doona inaan ugu dambeyntii iska dhigno.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Waayahay, sheeg!Hadda oo aan dhammaanteen si nabadgelyo ah u wada shaqeyneyno, aan dhab ahaantii bilowno wax walba oo aan shaqeyno.
        // Marka hore waxaan ubaahanahay inaan hubino in `dbghelp.dll` dhab ahaantii lagu shubay hawshan.
        // Waxaan tan u sameynaa si firfircoon si aan uga fogaanno ku tiirsanaanta joogtada ah.
        // Tan waxaa taariikh ahaan loo sameeyay si looga shaqeeyo hareeraha arrimaha isku xirka qariibka ah waxaana loogu talagalay samaynta binaries xoogaa la qaadi karo maaddaama tani ay tahay uun koronto-siinta.
        //
        //
        // Mar alla markii aan furnay `dbghelp.dll` waxaan u baahannahay inaan ugu yeerno qaar ka mid ah waxqabadyada bilowga ah, taas ayaana ka faahfaahsan hoos.
        // Tan waxaan sameynaa hal mar, in kastoo, markaa waxaan haysannaa boolean caalami ah oo tilmaamaya inaan weli dhammeynay iyo in kale.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Hubi in calanka `SYMOPT_DEFERRED_LOADS` ayaa lagu wadaa, maxaa yeelay, sida ay DoCS gaar MSVC ee ku saabsan this: "This is the fastest, most efficient way to use the symbol handler.", si aynu u samayn in!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Dhab ahaantii ku bilaw calaamadaha MSVC.Ogsoonow in tani ay fashilmi karto, laakiin waan iska indhatirnaa.
        // Ma jiraan hal tan oo farshaxan hore ah tan, laakiin LLVM gudaha ayaa u muuqda mid iska indha tiraya qiimaha soo noqoshada halkan mid ka mid ah maktabadaha fayadhowrka ee LLVM ayaa daabacaya digniin cabsi leh haddii tani ay ku fashilanto laakiin asal ahaan way iska indhatirtaa muddada dheer.
        //
        //
        // Hal kiis oo tani wax badan ugu soo kordheyso Rust ayaa ah maktabadda caadiga ah iyo tan crate ee crates.io labaduba waxay rabaan inay u tartamaan `SymInitializeW`.
        // Maktabadda caadiga ahi taariikh ahaan waxay rabtay inay bilowdo markaas nadiifinta inta badan, laakiin hadda markay isticmaalayso crate waxay ka dhigan tahay in qof uu helayo bilowga marka hore kan kalena uu soo qaadan doono bilowgaas.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}