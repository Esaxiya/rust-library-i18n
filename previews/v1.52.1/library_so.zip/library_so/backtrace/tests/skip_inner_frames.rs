use backtrace::Backtrace;

// Baaritaankaan waxaa kaliya ka shaqeeya on dhufto kaas oo ay leeyihiin a shaqeeya shaqo `symbol_address` for Click here to kaas oo sheegay in cinwaanka laga bilaabo of calaamad.
// Natiijo ahaan waxaa kaliya lagu shaqeysiiyaa dhowr meelood.
//
const ENABLED: bool = cfg!(all(
    // Windows ayaa run ahaantii aan la tijaabiyey, iyo OSX ma run ahaantii ay taageeraan helo jir lifaqaya ah, sidaas wuxuu curyaamin
    //
    target_os = "linux",
    // Marka laga hadlayo ARM helitaanka hawsha lifaaqa waxay si fudud ugu soo celinaysaa ip laftiisa.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}