# De `rustc-std-workspace-core` crate

Dizze crate is in lege en lege crate dy't gewoan hinget fan `libcore` en al syn ynhâld opnij eksporteart.
De crate is de kearn fan it befoarderjen fan de standertbibleteek om ôfhinklik te wêzen fan crates fan crates.io

Crates op crates.io dat de standert bibleteek ôfhinklik is fan, moat ôfhingje fan 'e `rustc-std-workspace-core` crate fan crates.io, dy't leech is.

Wy brûke `[patch]` om it te oerskriuwen nei dizze crate yn dizze repository.
As resultaat sil crates op crates.io in ôfhinklikheid edge nei `libcore` tekenje, de ferzje definieare yn dizze repository.
Dat soe alle ôfhinklikheidsrânen moatte tekenje om te soargjen dat Cargo crates mei sukses bout!

Tink derom dat crates op crates.io ôfhinklik wêze moat fan dizze crate mei de namme `core` foar alles om goed te wurkjen.Om dat te dwaan kinne se gebrûk meitsje:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Troch it brûken fan de `package`-kaai wurdt de crate omneamd ta `core`, wat betsjut dat it derút sil sjen

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

as Cargo de kompilear opropt, foldogge oan de ymplisite `extern crate core`-rjochtline dy't wurdt ynjekteare troch de kompilearder.




