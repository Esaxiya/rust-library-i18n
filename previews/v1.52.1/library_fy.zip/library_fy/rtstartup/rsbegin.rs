// rsbegin.o en rsend.o binne de saneamde "compiler runtime startup objects".
// Se befetsje koade nedich om de runtime fan 'e kompilear korrekt te initialisearjen.
//
// As in útfierbere of dylibôfbylding keppele is, binne alle brûkerskoade en biblioteken "sandwiched" tusken dizze twa objektbestannen, sadat koade of gegevens fan rsbegin.o earst wurde yn 'e respektivelike seksjes fan' e ôfbylding, wylst koade en gegevens fan rsend.o de lêste wurde.
// Dit effekt kin brûkt wurde om symboalen oan it begjin of oan 'e ein fan in seksje te pleatsen, lykas om alle fereaske kopteksten as foetteksten yn te foegjen.
//
// Tink derom dat it eigentlike yngongspunt fan 'e module leit yn it C-opstartobjekt foar runtime (meast `crtX.o` neamd), dat dan inisjalisaasje-callbacks fan oare runtime-ûnderdielen opropt (registrearre fia noch in spesjale ôfbyldingsseksje).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Merkt it begjin fan 'e stapelframe oan om seksje te ûntspannen
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kras romte foar ynterne boekhâlding fan unwinder.
    // Dit wurdt definieare as `struct object` yn $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Untwikkelje ynfo registration/deregistration-routines.
    // Sjoch de dokuminten fan libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrearje unwind info by opstarten fan 'e module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // registrearje by ôfsluting
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spesifike init/uninit routine registraasje
    pub mod mingw_init {
        // Start-objekten fan MinGW (crt0.o/dllcrt0.o) sille globale konstrukteurs oproppe yn 'e seksjes .ctors en .dtors by opstarten en útgong.
        // Yn it gefal fan DLL's wurdt dit dien as de DLL wurdt laden en laden.
        //
        // De linker sil de seksjes sortearje, wat derfoar soarget dat ús callbacks oan 'e ein fan' e list sitte.
        // Sûnt konstrukteurs wurde yn omkearde folchoarder útfierd, soarget dit derfoar dat ús callbacks de earste en lêste wurde útfierd.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C-inisjalisaasje callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Callbacks foar beëindiging fan C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}