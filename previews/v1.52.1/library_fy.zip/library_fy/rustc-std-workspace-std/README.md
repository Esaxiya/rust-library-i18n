# De `rustc-std-workspace-std` crate

Sjoch dokumintaasje foar de `rustc-std-workspace-core` crate.