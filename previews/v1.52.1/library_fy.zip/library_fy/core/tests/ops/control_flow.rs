use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dit is net stabyl oerflak, mar helpt `?` goedkeap tusken har te hâlden, ek as LLVM it no net altyd kin foardielje.
    //
    // (Spitigernôch binne Resultaat en Option inkonsekwint, dus ControlFlow kin net beiden oerienkomme.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}