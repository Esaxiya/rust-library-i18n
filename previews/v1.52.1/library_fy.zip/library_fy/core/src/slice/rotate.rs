// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Roteart it berik `[mid-left, mid+right)` sadat it elemint by `mid` it earste elemint wurdt.Lykweardich draait it berik `left`-eleminten nei lofts of `right`-eleminten nei rjochts.
///
/// # Safety
///
/// It oantsjutte berik moat jildich wêze foar lêzen en skriuwen.
///
/// # Algorithm
///
/// Algoritme 1 wurdt brûkt foar lytse wearden fan `left + right` of foar grutte `T`.
/// De eleminten wurde ien nei ien ferpleatst nei har definitive posysjes, begjinnend by `mid - left` en foarútgong troch `right`-stappen modulo `left + right`, sadat mar ien tydlik nedich is.
/// Uteinlik komme wy werom by `mid - left`.
/// As `gcd(left + right, right)` lykwols net 1 is, binne de boppesteande stappen oerslein oer eleminten.
/// Bygelyks:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Gelokkich is it oantal oersleine eleminten tusken finalisearre eleminten altyd gelyk, dus kinne wy gewoan ús startposysje kompensearje en mear rûntsjes dwaan (it totale oantal rûnten is de `gcd(left + right, right)` value).
///
/// It einresultaat is dat alle eleminten ienris en mar ien kear wurde finalisearre.
///
/// Algoritme 2 wurdt brûkt as `left + right` grut is, mar `min(left, right)` lyts genôch is om te passen op in stapelpuffer.
/// De `min(left, right)`-eleminten wurde kopieare op 'e buffer, `memmove` wurdt tapast op' e oaren, en dejingen op 'e buffer wurde werom ferpleatst yn it gat oan' e tsjinoerstelde kant fan wêr't se binne ûntstien.
///
/// Algoritmen dy't kinne wurde fektorisearre, prestearje boppe it boppesteande as `left + right` grut genôch wurdt.
/// Algoritme 1 kin wurde fektorisearre troch chunking en in protte rûntsjes tagelyk útfiere, mar d'r binne gemiddeld te min rûnten oant `left + right` enoarm is, en it minste gefal fan ien ronde is der altyd.
/// Ynstee brûkt algoritme 3 werhelle ruiljen fan `min(left, right)`-eleminten oant in lytser draaiprobleem is oerbleaun.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// doe't `left < right` bart it ruiljen ynstee fan links.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. de hjirûnder algoritmen kinne mislearje as dizze gefallen net wurde kontrolearre
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks jouwe oan dat de gemiddelde prestaasje foar willekeurige ferskowingen oant en mei `left + right == 32` better is, mar de minste prestaasjes brekke sels om 16 hinne.
            // 24 waard keazen as middelgrûn.
            // As de grutte fan `T` grutter is dan 4 `usize`s, presteart dit algoritme ek better as oare algoritmen.
            //
            //
            let x = unsafe { mid.sub(left) };
            // begjin fan earste omloop
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kin foar de hân wurde fûn troch `gcd(left + right, right)` te berekkenjen, mar it is rapper om ien loop te dwaan dy't de gcd as byeffekt berekkenet, dan de rest fan it stik te dwaan
            //
            //
            let mut gcd = right;
            // peilmerken litte sjen dat it flugger is tydlike heulendal te ruiljen ynstee fan ien tydlik ien kear te lêzen, efterút te kopiearjen, en dan oan it heule ein dat tydlike te skriuwen.
            // Dit komt mooglik troch it feit dat it wikseljen of ferfangen fan tydlike mar ien ûnthâldadres yn 'e loop brûkt ynstee fan twa te behearjen.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // yn plak fan `i` te ferheegjen en dan te kontrolearjen as it bûten de grinzen leit, kontrolearje wy as `i` by de folgjende ferheging bûten de grinzen giet.
                // Dit foarkomt alle ynpakken fan pointers of `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ein fan earste omloop
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // dizze betingst moat hjir wêze as `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // einigje it brok mei mear rûntsjes
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` is gjin type fan nulgrutte, dus it is goed om te dielen troch syn grutte.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 De `[T; 0]` is hjir om te soargjen dat dit passend is rjochte op T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 D'r is in alternative manier fan ruiljen dy't befettet finen wêr't de lêste swap fan dit algoritme wêze soe, en ruilje mei dat lêste stik ynstee fan neistlizzende brokken te ruiljen lykas dit algoritme docht, mar dizze manier is noch rapper.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}