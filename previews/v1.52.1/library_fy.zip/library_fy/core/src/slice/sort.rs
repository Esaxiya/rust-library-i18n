//! Snitsortearjen
//!
//! Dizze module befettet in sortearingsalgoritme basearre op Orson Peters 'patroan-ferslaan quicksort, publisearre op: <https://github.com/orlp/pdqsort>
//!
//!
//! Ynstabile sortearjen is kompatibel mei libcore, om't it ûnthâld net alloceart, yn tsjinstelling ta ús stabile sortear-ymplemintaasje.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// As se falle, kopyen fan `src` nei `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is in helperklasse.
        //          Ferwize asjebleaft har gebrûk foar korrektheid.
        //          Men moat nammentlik der wis fan wêze dat `src` en `dst` net oerlaapje lykas ferplicht troch `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ferpleatst it earste elemint nei rjochts oant it in grutter as gelyk elemint tsjinkomt.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: De hjirûnder ûnfeilige operaasjes omfetsje yndeksearjen sûnder in beheinde kontrôle (`get_unchecked` en `get_unchecked_mut`)
    // en kopiearje ûnthâld (`ptr::copy_nonoverlapping`).
    //
    // in.Yndeksearje:
    //  1. Wy hawwe de grutte fan 'e array kontroleare nei>=2.
    //  2. Alle yndeksearingen dy't wy sille dwaan is altyd maksimaal tusken {0 <= index < len}.
    //
    // b.Memory copy
    //  1. Wy krije oanwizings foar referinsjes dy't garandearre binne jildich.
    //  2. Se kinne net oerlaapje, om't wy oanwizings krije foar ferskilindices fan 'e slice.
    //     Nammentlik `i` en `i-1`.
    //  3. As it stik goed is rjochte, dan binne de eleminten goed oanpast.
    //     It is de ferantwurdlikens fan 'e beller om derfoar te soargjen dat it plak goed is rjochte.
    //
    // Sjoch hjirûnder kommentaar foar fierdere details.
    unsafe {
        // As de earste twa eleminten bûten oarder binne ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lês it earste elemint yn in stack-tawiisde fariabele.
            // As in folgjende fergeliking operaasje panics, wurdt `hole` ferdwûn en skriuwt it elemint automatysk werom yn it stik.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Ferpleats 'i'-th elemint ien plak nei lofts, en ferskoot dus it gat nei rjochts.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wurdt sakke en kopieart dus `tmp` yn it oerbleaune gat yn `v`.
        }
    }
}

/// Ferpleatst it lêste elemint nei links oant it in lytser of gelyk elemint tsjinkomt.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: De hjirûnder ûnfeilige operaasjes omfetsje yndeksearjen sûnder in beheinde kontrôle (`get_unchecked` en `get_unchecked_mut`)
    // en kopiearje ûnthâld (`ptr::copy_nonoverlapping`).
    //
    // in.Yndeksearje:
    //  1. Wy hawwe de grutte fan 'e array kontroleare nei>=2.
    //  2. Alle yndeksearingen dy't wy sille dwaan is altyd maksimaal tusken `0 <= index < len-1`.
    //
    // b.Memory copy
    //  1. Wy krije oanwizings foar referinsjes dy't garandearre binne jildich.
    //  2. Se kinne net oerlaapje, om't wy oanwizings krije foar ferskilindices fan 'e slice.
    //     Nammentlik `i` en `i+1`.
    //  3. As it stik goed is rjochte, dan binne de eleminten goed oanpast.
    //     It is de ferantwurdlikens fan 'e beller om derfoar te soargjen dat it plak goed is rjochte.
    //
    // Sjoch hjirûnder kommentaar foar fierdere details.
    unsafe {
        // As de lêste twa eleminten bûten oarder binne ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lês it lêste elemint yn in stack-tawiisde fariabele.
            // As in folgjende fergeliking operaasje panics, wurdt `hole` ferdwûn en skriuwt it elemint automatysk werom yn it stik.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Ferpleats 'i`-elemint ien plak nei rjochts, ferskowe it gat dus nei lofts.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wurdt sakke en kopieart dus `tmp` yn it oerbleaune gat yn `v`.
        }
    }
}

/// Sels in diel te sortearjen troch ferskate out-of-order-eleminten om te ferskowen.
///
/// Jout `true` werom as it stik oan 'e ein wurdt sorteare.Dizze funksje is *O*(*n*) minste gefal.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimum oantal neistlizzende pearen bûten de oarder dy't ferskood wurde.
    const MAX_STEPS: usize = 5;
    // As it stik koarter is dan dit, ferskow gjin eleminten.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // VEILIGHEID: Wy hawwe de eksplisite kontrôle al eksplisyt mei `i < len` dien.
        // Al ús folgjende yndeksearingen binne allinich yn it berik `0 <= index < len`
        unsafe {
            // Fyn it folgjende pear neistlizzende eleminten út 'e oarder.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Binne wy klear?
        if i == len {
            return true;
        }

        // Ferpleats gjin eleminten op koarte arrays, dat hat in prestaasjekosten.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ruilje it fûn pear eleminten yn.Dit set se yn 'e krekte folchoarder.
        v.swap(i - 1, i);

        // Ferpleats it lytsere elemint nei lofts.
        shift_tail(&mut v[..i], is_less);
        // Ferpleats it gruttere elemint nei rjochts.
        shift_head(&mut v[i..], is_less);
    }

    // Hat it slach net slagge yn it beheinde oantal stappen te sortearjen.
    false
}

/// Sorteert in plak mei ynsettsoarte, dat is *O*(*n*^ 2) minste gefal.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorteert `v` mei heapsort, dat garandeart *O*(*n*\*log(* n*)) minste gefal.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dizze binêre heap respekteart de invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Bern fan `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Kies it gruttere bern.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stopje as de invariant `node` hâldt.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ruilje `node` mei it gruttere bern, ferpleatse ien stap omleech en bliuw siftjen.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bouwe de heap yn lineêre tiid.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimale eleminten fan 'e heap.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partysjes `v` yn eleminten lytser dan `pivot`, folge troch eleminten grutter as of gelyk oan `pivot`.
///
///
/// Jout it oantal eleminten lytser dan `pivot`.
///
/// Partitionearje wurdt blok-by-blok útfierd om de kosten fan fertakkingsaksjes te minimalisearjen.
/// Dit idee wurdt presintearre yn it [BlockQuicksort][pdf]-papier.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Oantal eleminten yn in typysk blok.
    const BLOCK: usize = 128;

    // It partysjealgoritme herhellet de folgjende stappen oant foltôgjen:
    //
    // 1. Folgje in blok fan 'e linker kant om eleminten te identifisearjen grutter as of gelyk oan de draaipunt.
    // 2. Folgje in blok fan 'e rjochterkant om eleminten te identifisearjen lytser dan de draaipunt.
    // 3. Wizigje de identifisearre eleminten tusken de linker en rjochterkant.
    //
    // Wy hâlde de folgjende fariabelen foar in blok eleminten:
    //
    // 1. `block` - Oantal eleminten yn it blok.
    // 2. `start` - Start oanwizer yn 'e `offsets`-array.
    // 3. `end` - Ein pointer yn 'e `offsets`-array.
    // 4. `offsets, Yndeksen fan out-of-order eleminten binnen it blok.

    // It hjoeddeistige blok oan 'e lofterkant (fan `l` nei `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // It hjoeddeistige blok oan 'e rjochterkant (fan `r.sub(block_r)` to `r`).
    // VEILIGHEID: De dokumintaasje foar .add() neamt spesifyk dat `vec.as_ptr().add(vec.len())` altyd feilich is '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: As wy VLA's krije, besykje earder ien array mei lingte `min(v.len(), 2 * BLOCK) te meitsjen
    // dan twa arranzjeminten fan fêste grutte fan lingte `BLOCK`.VLA's kinne cache-effisjinter wêze.

    // Jout it oantal eleminten werom tusken oanwizers `l` (inclusive) en `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Wy binne dien mei partitionearjen blok-by-blok as `l` en `r` heul tichtby komme.
        // Dan dogge wy wat patch-upwurk om de oerbleaune eleminten tusken te dielen.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Oantal oerbleaune eleminten (noch altyd net fergelike mei de pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Pas blokgrutte oan sadat it linker-en rjochterblok net oerlaapje, mar perfekt oanpast wurde om de hiele oerbleaune gat te dekken.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trace `block_l`-eleminten fan 'e lofterkant.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // VEILIGHEID: De hjirûnder ûnfeilige operaasjes omfetsje it gebrûk fan 'e `offset`.
                //         Neffens de betingsten nedich troch de funksje, foldogge wy se oan om't:
                //         1. `offsets_l` wurdt stack-tawiisd, en dus beskôge as apart tawiisd objekt.
                //         2. De funksje `is_less` jout in `bool` werom.
                //            In `bool` castje sil `isize` nea oerstreamje.
                //         3. Wy hawwe garandearre dat `block_l` `<= BLOCK` sil wêze.
                //            Plus, `end_l` waard yn earste ynstânsje ynsteld op de begjinpointer fan `offsets_` dy't waard ferklearre op 'e stapel.
                //            Sa wite wy dat wy sels yn it slimste gefal (alle oanroppen fan `is_less` falsk weromjaan) wy op syn meast mar 1 byte oan 'e ein sille wêze.
                //        In oare ûnfeilichheidsaksje hjir is dereferencing `elem`.
                //        `elem` wie lykwols yn earste ynstânsje de begjinpointer nei it stik dat altyd jildich is.
                unsafe {
                    // Takleaze ferliking.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trace `block_r`-eleminten fan 'e rjochterkant.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // VEILIGHEID: De hjirûnder ûnfeilige operaasjes omfetsje it gebrûk fan 'e `offset`.
                //         Neffens de betingsten nedich troch de funksje, foldogge wy se oan om't:
                //         1. `offsets_r` wurdt stack-tawiisd, en dus beskôge as apart tawiisd objekt.
                //         2. De funksje `is_less` jout in `bool` werom.
                //            In `bool` castje sil `isize` nea oerstreamje.
                //         3. Wy hawwe garandearre dat `block_r` `<= BLOCK` sil wêze.
                //            Plus, `end_r` waard yn earste ynstânsje ynsteld op de begjinpointer fan `offsets_` dy't waard ferklearre op 'e stapel.
                //            Sa wite wy dat wy sels yn it slimste gefal (alle ynroppen fan `is_less` wier weromkomme) wy op syn meast mar 1 byte oan it ein sille wêze.
                //        In oare ûnfeilichheidsaksje hjir is dereferencing `elem`.
                //        `elem` wie lykwols yn earste ynstânsje `1 *sizeof(T)` foarby it ein en wy ferleegje it troch `1* sizeof(T)` foardat wy tagong krije ta it.
                //        Plus, `block_r` waard beweard dat se minder dan `BLOCK` wie, en `elem` sil dêrom op syn heechst wiist op it begjin fan 'e slice.
                unsafe {
                    // Takleaze ferliking.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Oantal eleminten dy't net yn oarder binne om te wikseljen tusken de linker en rjochterkant.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ynstee fan ien pear tagelyk te ruiljen, is it effisjinter om in fytsende permutaasje út te fieren.
            // Dit is net strikt lykweardich oan wikseljen, mar produseart in ferlykber resultaat mei minder ûnthâldbedriuwen.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle bûten-oarder eleminten yn it linkerblok waarden ferpleatst.Gean nei it folgjende blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle bûten-oarder-eleminten yn it juste blok waarden ferpleatst.Gean nei it foarige blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Alles wat no oerbliuwt is op syn meast ien blok (lofts as rjochts) mei bûten-oarder eleminten dy't moatte wurde ferpleatst.
    // Sokke oerbleaune eleminten kinne gewoan wurde ferpleatst nei it ein yn har blok.
    //

    if start_l < end_l {
        // It linkerblok bliuwt.
        // Ferpleats de oerbleaune bûten-oarder-eleminten nei heul rjochts.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // It juste blok bliuwt.
        // Ferpleats de oerbleaune eleminten bûten oarder nei lofts.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Neat oars te dwaan, wy binne klear.
        width(v.as_mut_ptr(), l)
    }
}

/// Partysjes `v` yn eleminten lytser dan `v[pivot]`, folge troch eleminten grutter as of gelyk oan `v[pivot]`.
///
///
/// Jout in tuple fan:
///
/// 1. Oantal eleminten lytser dan `v[pivot]`.
/// 2. Wier as `v` al dielde wie.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pleats de pivot oan it begjin fan 'e slice.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lês de pivot yn in stack-tawiisde fariabele foar effisjinsje.
        // As in folgjende fergeliking operaasje panics, dan wurdt de pivot automatysk werom skreaun yn 'e slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Fyn it earste pear bûten-oarder-eleminten.
        let mut l = 0;
        let mut r = v.len();

        // VEILIGHEID: De hjirûnder ûnfeiligens befettet in yndeksearje fan in array.
        // Foar de earste: Wy kontrolearje hjir al de grinzen mei `l < r`.
        // Foar de twadde: Wy hawwe yn earste ynstânsje `l == 0` en `r == v.len()` en wy kontroleare dat `l < r` by elke yndeksearjende operaasje.
        //                     Fanôf hjir wite wy dat `r` teminsten `r == l` wêze moat, dat waard oantoand as jildich fanôf de earste.
        unsafe {
            // Fyn it earste elemint dat grutter is as of gelyk oan 'e pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Fyn it lêste elemint dat lytser is dan it pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` giet bûten it berik en skriuwt de pivot (dat is in stack-tawiisde fariabele) werom yn 'e slach wêr't it oarspronklik wie.
        // Dizze stap is kritysk by it garandearjen fan feiligens!
        //
    };

    // Plak de draaipunt tusken de twa partysjes.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partysjes `v` yn eleminten gelyk oan `v[pivot]` folge troch eleminten grutter dan `v[pivot]`.
///
/// Jout it oantal eleminten gelyk oan 'e draaipunt.
/// Oannomd wurdt dat `v` gjin eleminten befettet dy't lytser binne dan de draaipunt.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pleats de pivot oan it begjin fan 'e slice.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lês de pivot yn in stack-tawiisde fariabele foar effisjinsje.
    // As in folgjende fergeliking operaasje panics, dan wurdt de pivot automatysk werom skreaun yn 'e slice.
    // VEILIGHEID: De oanwizer is jildich, om't dizze wurdt krigen fan in ferwizing nei in stik.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Partitionearje no it stik.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // VEILIGHEID: De hjirûnder ûnfeiligens befettet in yndeksearje fan in array.
        // Foar de earste: Wy kontrolearje hjir al de grinzen mei `l < r`.
        // Foar de twadde: Wy hawwe yn earste ynstânsje `l == 0` en `r == v.len()` en wy kontroleare dat `l < r` by elke yndeksearjende operaasje.
        //                     Fanôf hjir wite wy dat `r` teminsten `r == l` wêze moat, dat waard oantoand as jildich fanôf de earste.
        unsafe {
            // Fyn it earste elemint dat grutter is dan it pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Sykje it lêste elemint dat gelyk is oan it pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Binne wy klear?
            if l >= r {
                break;
            }

            // Ruilje it fûn pear bûten-oarder-eleminten yn.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Wy fûnen `l`-eleminten gelyk oan it pivot.Foegje 1 ta oan akkount foar de pivot sels.
    l + 1

    // `_pivot_guard` giet bûten it berik en skriuwt de pivot (dat is in stack-tawiisde fariabele) werom yn 'e slach wêr't it oarspronklik wie.
    // Dizze stap is kritysk by it garandearjen fan feiligens!
}

/// Ferstruit guon eleminten rûnom yn in besykjen om patroanen te brekken dy't unbalanseare partysjes kinne feroarsaakje yn kwiksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nûmergenerator út it "Xorshift RNGs"-papier fan George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Nim willekeurige getallen modulo dit getal.
        // It getal past yn `usize` om't `len` net grutter is dan `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Guon draaikandidaten sille yn 'e buert fan dizze yndeks wêze.Litte wy se randomisearje.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generearje in willekeurich getal modulo `len`.
            // Om lykwols djoere operaasjes te foarkommen nimme wy it earst modulo in krêft fan twa, en ferminderje dan mei `len` oant it past yn it berik `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` wurdt garandearre minder dan `2 * len` te wêzen.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Kiest in draaipunt yn `v` en jout de yndeks en `true` werom as it stik wierskynlik al sorteare is.
///
/// Eleminten yn `v` kinne yn it proses opnij oardere wurde.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimale lingte om de metoade mediaan-fan-mediaan te kiezen.
    // Koartere plakjes brûke de ienfâldige metoade-fan-trije-metoade.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimum oantal swaps dat kin wurde útfierd yn dizze funksje.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trije yndeksen wêrby't wy in draaiknop sille kieze.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Telt it totale oantal swaps dat wy op it punt binne om te fieren by it sortearjen fan yndeksen.
    let mut swaps = 0;

    if len >= 8 {
        // Ruilje yndeksen sadat `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ruilje yndeksen sadat `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Fynt de mediaan fan `v[a - 1], v[a], v[a + 1]` en bewarret de yndeks yn `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Fyn medianen yn 'e omkriten fan `a`, `b` en `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Sykje de mediaan ûnder `a`, `b` en `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // It maksimale oantal swaps waard útfierd.
        // De kâns is grut dat it stikje delkomt of meast delkomt, dus omkearing sil wierskynlik helpe om it rapper te sortearjen.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorteert `v` rekursyf.
///
/// As it stik in foargonger hie yn 'e orizjinele array, wurdt it oantsjutte as `pred`.
///
/// `limit` is it oantal tastiene ûnbalanseare partysjes foardat jo oerstappe op `heapsort`.
/// As nul, sil dizze funksje direkt oergean op heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Plakken fan oant dizze lingte wurde sorteare mei ynsettingssoarte.
    const MAX_INSERTION: usize = 20;

    // Wier as de lêste partysje ridlik balansearre wie.
    let mut was_balanced = true;
    // Wier as de lêste dieling eleminten net skodde (it stik wie al partitioned).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Hiel koarte plakken wurde sorteare mei ynsetsoarte.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // As der te min minne karren waarden makke, falt gewoan werom nei heapsort om `O(n * log(n))` minste gefal te garandearjen.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // As de lêste partysje ûnbalâns wie, besykje patroanen yn 'e slach te brekken troch guon eleminten rûn te skodzjen.
        // Hooplik kieze wy dizze kear in bettere draaipunt.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Kies in draaipunt en besykje te rieden oft it stik al is sorteare.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // As de lêste partysje fatsoenlik yn lykwicht wie en eleminten net skode, en as pivot-seleksje foarseit, is it stik wierskynlik al sorteare ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Besykje ferskate out-of-order-eleminten te identifisearjen en te ferpleatsen nei korrekte posysjes.
            // As it stikje einlings folslein sorteare wurdt, binne wy klear.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // As de keazen draaipunt gelyk is oan de foargonger, dan is it it lytste elemint yn 'e stik.
        // Partitionearje de slice yn eleminten gelyk oan en eleminten grutter dan de pivot.
        // Dit gefal wurdt normaal rekke as it stik in soad duplikaat-eleminten befettet.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Trochgean mei it sortearjen fan eleminten dy't grutter binne dan de pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partysje it stik.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Split it stikje yn `left`, `pivot`, en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Ferpleats allinich yn 'e koartere kant om it totale oantal rekursive petearen te minimalisearjen en minder stackromte te konsumearjen.
        // Gean dan gewoan troch mei de langere kant (dit is besibbe oan sturtrekursje).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorteert `v` mei gebrûk fan patroan-ferslaan quicksort, dat is *O*(*n*\*log(* n*)) minste gefal.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortearje hat gjin betsjuttend gedrach op nulgrutte typen.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Behein it oantal unbalanseare partysjes oant `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Foar plakken oant dizze lingte is it wierskynlik rapper om se gewoan te sortearjen.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kies in draaipunt
        let (pivot, _) = choose_pivot(v, is_less);

        // As de keazen draaipunt gelyk is oan de foargonger, dan is it it lytste elemint yn 'e stik.
        // Partitionearje de slice yn eleminten gelyk oan en eleminten grutter dan de pivot.
        // Dit gefal wurdt normaal rekke as it stik in soad duplikaat-eleminten befettet.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // As wy ús yndeks hawwe trochjûn, dan binne wy goed.
                if mid > index {
                    return;
                }

                // Oars, trochgean mei it sortearjen fan eleminten dy't grutter binne dan de pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Split it stikje yn `left`, `pivot`, en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // As mid==index, dan binne wy dien, om't partition() garandeart dat alle eleminten nei mid grutter binne as of lyk oan mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortearje hat gjin betsjuttend gedrach op nulgrutte typen.Neat dwaan.
    } else if index == v.len() - 1 {
        // Sykje maksimaal elemint en pleats it yn 'e lêste posysje fan' e array.
        // Wy binne hjir frij om `unwrap()` te brûken, om't wy witte dat v net leech moat wêze.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Sykje min elemint en pleats it yn 'e earste posysje fan' e array.
        // Wy binne hjir frij om `unwrap()` te brûken, om't wy witte dat v net leech moat wêze.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}