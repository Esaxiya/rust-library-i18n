//! Operaasjes op ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrolearret oft alle bytes yn dizze slice binnen it ASCII-berik binne.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontroleart dat twa plakjes in ASCII-saakgefoelige wedstriid binne.
    ///
    /// Itselde as `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mar sûnder tydlike tawizen en kopiearjen.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konverteart dit stikje nei syn ASCII-haadlokaal ekwivalint te plak.
    ///
    /// ASCII-letters 'a' nei 'z' wurde yn kaart brocht oan 'A' nei 'Z', mar net-ASCII-letters binne net feroare.
    ///
    /// Om in nije haadletterwearde werom te jaan sûnder de besteande te feroarjen, brûk [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konverteart dit stik nei syn ASCII-lytse ekwivalint yn plak.
    ///
    /// ASCII-letters 'A' nei 'Z' wurde yn kaart brocht oan 'a' nei 'z', mar net-ASCII-letters binne net feroare.
    ///
    /// Om in nije wearde mei lege wearde werom te jaan sûnder de besteande te feroarjen, brûk [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Jout `true` werom as ien byte yn it wurd `v` nonascii is (>=128).
/// Snarfed fan `../str/mod.rs`, wat wat ferlykber docht foar utf8-validaasje.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimalisearre ASCII-test dy't usize-at-a-time operaasjes sil brûke ynstee fan byte-at-a-time operaasjes (as it mooglik is).
///
/// It algoritme dat wy hjir brûke is frij ienfâldich.As `s` te koart is, kontrolearje wy gewoan elke byte en binne der klear mei.Oars:
///
/// - Lês it earste wurd mei in net-rjochte lading.
/// - Rjochtsje de oanwizer út, lês folgjende wurden oant ein mei rjochte lesten.
/// - Lês de lêste `usize` fan `s` mei in unjildige lading.
///
/// As ien fan dizze lesten iets produseart wêrfoar `contains_nonascii` (above) wier weromkomt, dan wite wy dat it antwurd falsk is.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // As wy neat winne fan 'e wurd-op-in-tiid-ymplemintaasje, falle dan werom nei in skalêre loop.
    //
    // Wy dogge dit ek foar arsjitektuer wêr't `size_of::<usize>()` net genôch ôfstimming is foar `usize`, om't it in frjemde edge-saak is.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Wy lêze altyd it earste wurd unjildich, wat betsjut dat `align_offset` is
    // 0, wy soene deselde wearde nochris lêze foar it útrjochte lêzen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // VEILIGHEID: Wy ferifiearje `len < USIZE_SIZE` hjirboppe.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Wy hawwe dit hjirboppe kontroleare, wat ymplisyt.
    // Tink derom dat `offset_to_aligned` `align_offset` as `USIZE_SIZE` is, beide wurde hjirboppe eksplisyt kontroleare.
    //
    debug_assert!(offset_to_aligned <= len);

    // VEILIGHEID: word_ptr is de (goed útrjochte) usize ptr dy't wy brûke om de te lêzen
    // middelste brok fan it stik.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` is de byte-yndeks fan `word_ptr`, brûkt foar loopkontrôles.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontroleart oer ôfstimming, om't wy in bulte unjustere lesten dogge.
    // Yn 'e praktyk soe dit lykwols ûnmooglik wêze moatte om in bug yn `align_offset` te beheinen.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lês folgjende wurden oant it lêst útrjochte wurd, útsein it lêst útrjochte wurd op himsels dat letter yn 'e sturtkontrôle moat wurde dien, om derfoar te soargjen dat de sturt altyd maksimaal ien `usize` is oant ekstra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity kontrolearje dat it lêzen yn grinzen is
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // En dat ús oannames oer `byte_pos` hâlde.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // VEILIGHEID: Wy witte dat `word_ptr` goed is ôfstimd (fanwegen
        // 'align_offset'), en wy witte dat wy genôch bytes hawwe tusken `word_ptr` en it ein
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // VEILIGHEID: Wy witte dat `byte_pos <= len - USIZE_SIZE`, dat betsjut dat
        // nei dizze `add` sil `word_ptr` op syn meast ien-foar-de-ein wêze.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanitaasjekontrôle om te soargjen dat d'r mar ien `usize` oer is.
    // Dit moat wurde garandearre troch ús loop-betingst.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // VEILIGHEID: Dit fertrout op `len >= USIZE_SIZE`, dy't wy oan it begjin kontrolearje.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}