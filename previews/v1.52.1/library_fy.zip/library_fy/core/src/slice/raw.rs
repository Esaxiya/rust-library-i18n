//! Fergese funksjes om `&[T]` en `&mut [T]` te meitsjen.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Foarmet in stik fan in oanwizer en in lingte.
///
/// It `len`-argumint is it oantal **eleminten**, net it oantal bytes.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `data` moat [valid] wêze foar lêzen foar `len * mem::size_of::<T>()` in protte bytes, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
///
///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.Sjoch [below](#incorrect-usage) foar in foarbyld dat dit ferkeard net yn rekken hâldt.
///     * `data` moat net-nul wêze en sels ôfstimd wurde foar plakjes mei nul-lingte.
///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
///
/// * `data` moatte wize op `len` opienfolgjende goed inisjalisearre wearden fan type `T`.
///
/// * It ûnthâld dat wurdt ferwiisd troch it weromkommen plak moat net mutearre wurde foar de doer fan it libben `'a`, útsein binnen in `UnsafeCell`.
///
/// * De totale grutte `len * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
///
/// # Caveat
///
/// It libben foar it weromkommen plak wurdt ôflaat fan har gebrûk.
/// Om ûngeduldich misbrûk te foarkommen, wurdt suggereare de libbensdoer te binen oan hokker boarne libbensjier feilich is yn 'e kontekst, lykas troch in helpfunksje te leverjen dy't de libbensdoer nimt fan in hostwearde foar it stik, of troch eksplisite annotaasje.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestearje in stikje foar ien elemint
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Ferkeard gebrûk
///
/// De folgjende `join_slices`-funksje is **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // De bewearing hjirboppe soarget derfoar dat `fst` en `snd` oaniensletten binne, mar se kinne noch yn _different allocated objects_ befette, yn hokker gefal it oanmeitsjen fan dizze slach net definieare gedrach is.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` en `b` binne ferskillende tawiisde objekten ...
///     let a = 42;
///     let b = 27;
///     // ... dy't lykwols oanienslútend yn it ûnthâld kin wurde útlein: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: de beller moat it feiligenskontrakt foar `from_raw_parts` hanthavenje.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Fiert deselde funksjonaliteit as [`from_raw_parts`], útsein dat in feroarbere stik wurdt weromjûn.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `data` moat [valid] wêze foar sawol lêzen as skriuwen foar `len * mem::size_of::<T>()` in protte bytes, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
///
///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.
///     * `data` moat net-nul wêze en sels ôfstimd wurde foar plakjes mei nul-lingte.
///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
///
///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
///
/// * `data` moatte wize op `len` opienfolgjende goed inisjalisearre wearden fan type `T`.
///
/// * It ûnthâld dat wurdt ferwiisd troch it weromkommen plak moat net tagong wurde fia in oare oanwizer (net ôflaat fan 'e weromwearde) foar de doer fan it libben `'a`.
///   Sawol lês-as skriuwtoegang is ferbean.
///
/// * De totale grutte `len * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: de beller moat it feiligenskontrakt foar `from_raw_parts_mut` hanthavenje.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konverteart in ferwizing nei T yn in stik lingte 1 (sûnder kopiearjen).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konverteart in ferwizing nei T yn in stik lingte 1 (sûnder kopiearjen).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}