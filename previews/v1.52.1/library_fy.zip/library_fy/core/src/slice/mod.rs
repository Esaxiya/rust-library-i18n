// ignore-tidy-filelength

//! Slice behear en manipulaasje.
//!
//! Sjoch [`std::slice`] foar mear details.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Suvere ymplemintaasje fan rust memchr, oernommen út rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Dizze funksje is allinich iepenbier om't d'r gjin oare manier is om heapsort te testen.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Jout it oantal eleminten yn it stik werom.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // VEILIGHEID: const lûd om't wy it lingtefjild transmutearje as in usize (wat it moat wêze)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // VEILIGHEID: dit is feilich, om't `&[T]` en `FatPtr<T>` deselde opmaak hawwe.
            // Allinich `std` kin dizze garânsje meitsje.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ferfange troch `crate::ptr::metadata(self)` as dat konststabyl is.
            // Fanôf dit skriuwen feroarsaket dit in "Const-stable functions can only call other const-stable functions"-flater.
            //

            // VEILIGHEID: Tagong ta de wearde fan 'e `PtrRepr`-uny is feilich sûnt * konst T
            // en PtrComponents<T>hawwe deselde ûnthâldlay-outs.
            // Allinich std kin dizze garânsje meitsje.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Jout `true` werom as it stik in lingte hat fan 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Jout it earste elemint fan it stik, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Jout in feroarbere oanwizer nei it earste elemint fan it stik, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Jout de earste en alle rest fan 'e eleminten fan' e skyf, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Jout de earste en alle rest fan 'e eleminten fan' e skyf, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Jout de lêste en alle rest fan 'e eleminten fan' e slice, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Jout de lêste en alle rest fan 'e eleminten fan' e slice, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Jout it lêste elemint fan it stik, of `None` as it leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Jout in feroarbere oanwizer nei it lêste item yn 'e snij.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Jout in ferwizing nei in elemint of subslice ôfhinklik fan it type yndeks.
    ///
    /// - As in posysje wurdt jûn, jout in referinsje werom nei it elemint op dy posysje of `None` as bûten de grinzen.
    ///
    /// - As in berik wurdt jûn, retourneert it dielstik dat oerienkomt mei dat berik, of `None` as bûten de grinzen.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Jout in feroarbere ferwizing nei in elemint of dielstik ôfhinklik fan it type yndeks (sjoch [`get`]) of `None` as de yndeks bûten de grinzen is.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Jout in ferwizing nei in elemint as subslice, sûnder grinzen te kontrolearjen.
    ///
    /// Sjoch [`get`] foar in feilich alternatyf.
    ///
    /// # Safety
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen is *[undefined behavior]*, sels as de resultearjende referinsje net wurdt brûkt.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // VEILIGHEID: de beller moat de measte feiligenseasken foar `get_unchecked` hanthavenje;
        // it stik is ôf te sluten, om't `self` in feilige referinsje is.
        // De weromwizende oanwizer is feilich, om't ymplen fan `SliceIndex` garandearje moatte dat it is.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Jout in feroarbere ferwizing nei in elemint of subslice, sûnder grinzen te kontrolearjen.
    ///
    /// Sjoch [`get_mut`] foar in feilich alternatyf.
    ///
    /// # Safety
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen is *[undefined behavior]*, sels as de resultearjende referinsje net wurdt brûkt.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // VEILIGHEID: de beller moat de feiligenseasken foar `get_unchecked_mut` hanthavenje;
        // it stik is ôf te sluten, om't `self` in feilige referinsje is.
        // De weromwizende oanwizer is feilich, om't ymplen fan `SliceIndex` garandearje moatte dat it is.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Jout in rauwe oanwizer nei de buffer fan it stik.
    ///
    /// De beller moat derfoar soargje dat it stik de oanwizer oerlibbet wer't dizze funksje weromkomt, oars sil it op it jiskefet wize.
    ///
    /// De beller moat ek soargje dat it ûnthâld wêr't de oanwizer (non-transitively) wiist nei nea wurdt skreaun (útsein yn in `UnsafeCell`) mei dizze oanwizer of in ofwizer dy't derút ûntliend is.
    /// As jo de ynhâld fan it stik mutearje moatte, brûk dan [`as_mut_ptr`].
    ///
    /// It wizigjen fan 'e kontener dy't troch dit stik wurdt ferwiisd kin feroarsaakje dat de buffer opnij tawiisd wurdt, wat ek alle oanwizings dêrop unjildich makket.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Jout in ûnfeilige feroarbere oanwizer nei de buffer fan it stik.
    ///
    /// De beller moat derfoar soargje dat it stik de oanwizer oerlibbet wer't dizze funksje weromkomt, oars sil it op it jiskefet wize.
    ///
    /// It wizigjen fan 'e kontener dy't troch dit stik wurdt ferwiisd kin feroarsaakje dat de buffer opnij tawiisd wurdt, wat ek alle oanwizings dêrop unjildich makket.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Jout de twa rauwe oanwizers oer it stik.
    ///
    /// It weromkommen berik is heal iepen, wat betsjut dat de einpointer *ien foarby* it lêste elemint fan 'e sleat wiist.
    /// Op dizze manier wurdt in leech stik fertsjintwurdige troch twa gelikense oanwizers, en it ferskil tusken de twa oanwizings fertsjintwurdiget de grutte fan 'e slach.
    ///
    /// Sjoch [`as_ptr`] foar warskôgingen oer it brûken fan dizze oanwizings.De einpointer freget ekstra foarsichtigens, om't it net wiist op in jildich elemint yn 'e slice.
    ///
    /// Dizze funksje is nuttich foar ynteraksje mei bûtenlânske ynterfaces dy't twa oanwizings brûke om te ferwizen nei in berik eleminten yn it ûnthâld, lykas gewoanlik is yn C++ .
    ///
    ///
    /// It kin ek nuttich wêze om te kontrolearjen as in oanwizer nei in elemint ferwiist nei in elemint fan dit stik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // VEILIGHEID: De `add` hjir is feilich, om't:
        //
        //   - Beide oanwizings binne diel fan itselde objekt, om't tellen direkt foarby it objekt ek telt.
        //
        //   - De grutte fan it stik is nea grutter dan isize::MAX bytes, lykas hjir opmurken:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - D'r is gjin ferpakking belutsen, om't plakken net oan 'e ein fan' e adresromte wikkelje.
        //
        // Sjoch de dokumintaasje fan pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Jout de twa ûnfeilige feroarbere oanwizings oer it stik.
    ///
    /// It weromkommen berik is heal iepen, wat betsjut dat de einpointer *ien foarby* it lêste elemint fan 'e sleat wiist.
    /// Op dizze manier wurdt in leech stik fertsjintwurdige troch twa gelikense oanwizers, en it ferskil tusken de twa oanwizings fertsjintwurdiget de grutte fan 'e slach.
    ///
    /// Sjoch [`as_mut_ptr`] foar warskôgingen oer it brûken fan dizze oanwizings.
    /// De einpointer freget ekstra foarsichtigens, om't it net wiist op in jildich elemint yn 'e slice.
    ///
    /// Dizze funksje is nuttich foar ynteraksje mei bûtenlânske ynterfaces dy't twa oanwizings brûke om te ferwizen nei in berik eleminten yn it ûnthâld, lykas gewoanlik is yn C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // VEILIGHEID: Sjoch as_ptr_range() hjirboppe foar wêrom `add` hjir feilich is.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ruilje twa eleminten yn it stik.
    ///
    /// # Arguments
    ///
    /// * a, De yndeks fan it earste elemint
    /// * b, De yndeks fan it twadde elemint
    ///
    /// # Panics
    ///
    /// Panics as `a` of `b` bûten de grinzen binne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kin gjin twa feroarbere lieningen nimme fan ien vector, brûk ynstee rauwe oanwizers.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // VEILIGHEID: `pa` en `pb` binne makke fan feilige mutabele referinsjes en ferwize
        // oan eleminten yn 'e slach en wurde dêrom garandearre jildich en ôfstimd.
        // Tink derom dat tagong ta de eleminten efter `a` en `b` wurdt kontroleare en sil panic as bûten de grinzen.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Fertelt de folchoarder fan eleminten yn 'e slach, op syn plak.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Foar heul lytse soarten prestearje alle yndividuen yn it normale paad min.
        // Wy kinne better dwaan, jûn effisjinte unalignearre load/store, troch in gruttere broek te laden en in register te kearen.
        //

        // Ideaal soe LLVM dit foar ús dwaan, om't it better wit as wy dogge oft unjildige lêzingen effisjint binne (om't dat feroaret tusken bygelyks ferskillende ARM-ferzjes) en wat de bêste brokgrutte soe wêze.
        // Spitigernôch rint it fanôf LLVM 4.0 (2017-05) allinich de loop út, dat wy moatte dit sels dwaan.
        // (Hypotese: reverse is lestich, om't de kanten oars kinne wurde útrjochte-sil wêze, as de lingte ûneven is-dus is d'r gjin manier om foar-en útslúten út te stjoeren om SIMD yn it midden folslein út te lizzen.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Brûk de yntrinsike llvm.bswap om u8's yn in grutte te kearen
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // VEILIGHEID: D'r binne hjir ferskate dingen te kontrolearjen:
                //
                // - Tink derom dat `chunk` 4 of 8 is fanwegen de hjirboppe cfg-kontrôle.Dat `chunk - 1` is posityf.
                // - Yndeksearje mei yndeks `i` is prima, om't de loopkontrôle garandeart
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Yndeksearje mei yndeks `ln - i - chunk = ln - (i + chunk)` is prima:
                //   - `i + chunk > 0` is triviaal wier.
                //   - De loopkontrôle garandeart:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, subtraksje ûnderstreamt dus net.
                // - De `read_unaligned`-en `write_unaligned`-oproppen binne prima:
                //   - `pa` wiist op yndeks `i` wêr `i < ln / 2 - (chunk - 1)` (sjoch hjirboppe) en `pb` wiist op yndeks `ln - i - chunk`, dus beide binne teminsten `chunk` in protte bytes fuort fan 'e ein fan `self`.
                //
                //   - Elk inisjalisearre ûnthâld is jildich `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Brûk rotearje-by-16 om u16's yn in u32 te kearen
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // VEILIGHEID: In unaligned u32 kin lêzen wurde fan `i` as `i + 1 < ln`
                // (en fansels `i < ln`), om't elk elemint 2 bytes is en wy 4 lêze.
                //
                // `i + chunk - 1 < ln / 2` # wylst tastân
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Om't it minder is dan de lingte dield troch 2, dan moat it yn grinzen wêze.
                //
                // Dit betsjut ek dat de betingst `0 < i + chunk <= ln` altyd wurdt respekteare, en soarget derfoar dat de `pb`-oanwizer feilich kin wurde brûkt.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // VEILIGHEID: `i` is ynferieur oan de helte fan 'e lingte fan' e sleat dus
            // tagong ta `i` en `ln - i - 1` is feilich (`i` begjint om 0 en sil net fierder gean dan `ln / 2 - 1`).
            // De resultearjende oanwizings `pa` en `pb` binne dêrom jildich en ôfstimd, en kinne wurde lêzen fan en skreaun oan.
            //
            //
            unsafe {
                // Unfeilich wikseljen om de grinzen te kontrolearjen yn feilige swap.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Jout in iterator oer it stik.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Jout in iterator wêrmei elke wearde kin wizige wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Jout in iterator oer alle oaniensletten windows fan lingte `size`.
    /// De windows oerlaapje.
    /// As it stik koarter is dan `size`, jout de iterator gjin wearden werom.
    ///
    /// # Panics
    ///
    /// Panics as `size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// As it stik koarter is dan `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Jout in iterator oer `chunk_size`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne plakjes en oerlaapje net.As `chunk_size` de lingte fan it stik net dielt, dan hat it lêste stik gjin lingte `chunk_size`.
    ///
    /// Sjoch [`chunks_exact`] foar in fariant fan dizze iterator dy't brokken fan altyd presys `chunk_size`-eleminten werombringt, en [`rchunks`] foar deselde iterator, mar begjinne oan 'e ein fan' e snij.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Jout in iterator oer `chunk_size`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne feroarbere plakken, en oerlaapje net.As `chunk_size` de lingte fan it stik net dielt, dan hat it lêste stik gjin lingte `chunk_size`.
    ///
    /// Sjoch [`chunks_exact_mut`] foar in fariant fan dizze iterator dy't brokken fan altyd presys `chunk_size`-eleminten werombringt, en [`rchunks_mut`] foar deselde iterator, mar begjinne oan 'e ein fan' e snij.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Jout in iterator oer `chunk_size`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne plakjes en oerlaapje net.
    /// As `chunk_size` de lingte fan it stik net dielt, dan wurde de lêste oant `chunk_size-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `remainder`-funksje fan' e iterator.
    ///
    ///
    /// Trochdat elk stik presys `chunk_size`-eleminten hat, kin de gearstaller de resultearjende koade faaks better optimalisearje dan yn it gefal fan [`chunks`].
    ///
    /// Sjoch [`chunks`] foar in fariant fan dizze iterator dy't ek de rest werombringt as in lytsere brok, en [`rchunks_exact`] foar deselde iterator, mar begjint oan 'e ein fan' e snij.
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Jout in iterator oer `chunk_size`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne feroarbere plakken, en oerlaapje net.
    /// As `chunk_size` de lingte fan it stik net dielt, dan wurde de lêste oant `chunk_size-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `into_remainder`-funksje fan' e iterator.
    ///
    ///
    /// Trochdat elk stik presys `chunk_size`-eleminten hat, kin de gearstaller de resultearjende koade faaks better optimalisearje dan yn it gefal fan [`chunks_mut`].
    ///
    /// Sjoch [`chunks_mut`] foar in fariant fan dizze iterator dy't ek de rest werombringt as in lytsere brok, en [`rchunks_exact_mut`] foar deselde iterator, mar begjint oan 'e ein fan' e snij.
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Spalt it stikje yn in stikje 'N`-elemint arrays, oannommen dat d'r gjin rest is.
    ///
    ///
    /// # Safety
    ///
    /// Dit kin allinich wurde neamd as
    /// - It stik splitst krekt yn 'N'-elemint brokken (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // VEILIGHEID: brokken fan 1-elemint hawwe nea rest
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // VEILIGHEID: De snylengte (6) is in mearfâld fan 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Dizze soene net sûn wêze:
    /// // lit brokken: &[[_;5]]= slice.as_chunks_unchecked()//De snylange is net in mearfâld fan 5 lit brokken:&[[_;0]]= slice.as_chunks_unchecked()//Brokken mei nul-lingte binne nea tastien
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // VEILIGHEID: Us foarwearde is presys wat nedich is om dit te neamen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // VEILIGHEID: Wy smite in stikje `new_len * N`-eleminten yn
        // in stikje `new_len` in protte `N`-eleminten brokken.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Splitset it stik yn in stik fan 'N`-elemintarrays, begjinnend oan it begjin fan' e slice, en in restskyf mei lingte strikt minder dan `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // VEILIGHEID: Wy rekke al yn panyk foar nul, en soargen foar konstruksje
        // dat de lingte fan 'e dielstreek in mearfâld is fan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Splitset it stik yn in stik fan 'N`-elemintarrays, begjinnend oan' e ein fan 'e slice, en in resterskyf mei lingte strikt minder dan `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // VEILIGHEID: Wy rekke al yn panyk foar nul, en soargen foar konstruksje
        // dat de lingte fan 'e dielstreek in mearfâld is fan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Jout in iterator oer `N`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne arrayreferinsjes en oerlaapje net.
    /// As `N` de lingte fan it stik net dielt, dan wurde de lêste oant `N-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `remainder`-funksje fan' e iterator.
    ///
    ///
    /// Dizze metoade is it const generike ekwivalint fan [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Spalt it stikje yn in stikje 'N`-elemint arrays, oannommen dat d'r gjin rest is.
    ///
    ///
    /// # Safety
    ///
    /// Dit kin allinich wurde neamd as
    /// - It stik splitst krekt yn 'N'-elemint brokken (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // VEILIGHEID: brokken fan 1-elemint hawwe nea rest
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // VEILIGHEID: De snylengte (6) is in mearfâld fan 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Dizze soene net sûn wêze:
    /// // lit brokken: &[[_;5]]= slice.as_chunks_unchecked_mut()//De snylange is net in mearfâld fan 5 let brokken:&[[_;0]]= slice.as_chunks_unchecked_mut()//Brokken mei nul-lingte binne nea tastien
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // VEILIGHEID: Us foarwearde is presys wat nedich is om dit te neamen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // VEILIGHEID: Wy smite in stikje `new_len * N`-eleminten yn
        // in stikje `new_len` in protte `N`-eleminten brokken.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Splitset it stik yn in stik fan 'N`-elemintarrays, begjinnend oan it begjin fan' e slice, en in restskyf mei lingte strikt minder dan `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // VEILIGHEID: Wy rekke al yn panyk foar nul, en soargen foar konstruksje
        // dat de lingte fan 'e dielstreek in mearfâld is fan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Splitset it stik yn in stik fan 'N`-elemintarrays, begjinnend oan' e ein fan 'e slice, en in resterskyf mei lingte strikt minder dan `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // VEILIGHEID: Wy rekke al yn panyk foar nul, en soargen foar konstruksje
        // dat de lingte fan 'e dielstreek in mearfâld is fan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Jout in iterator oer `N`-eleminten fan 'e slach tagelyk, begjinnend oan it begjin fan' e slice.
    ///
    /// De brokken binne mutabele arrayreferinsjes en oerlaapje net.
    /// As `N` de lingte fan it stik net dielt, dan wurde de lêste oant `N-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `into_remainder`-funksje fan' e iterator.
    ///
    ///
    /// Dizze metoade is it const generike ekwivalint fan [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics as `N` is 0. Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade stabilisearre wurdt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Jout in iterator oer oerlaapjende windows fan `N`-eleminten fan in stik, begjinnend oan it begjin fan it stik.
    ///
    ///
    /// Dit is it const-generike ekwivalint fan [`windows`].
    ///
    /// As `N` grutter is dan de grutte fan it stik, sil it gjin windows werombringe.
    ///
    /// # Panics
    ///
    /// Panics as `N` 0 is.
    /// Dizze kontrôle sil nei alle gedachten feroare wurde yn in kompilearjende tiidflater foardat dizze metoade wurdt stabilisearre.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Jout in iterator tagelyk oer `chunk_size`-eleminten fan 'e slice, begjinnend oan' e ein fan 'e slice.
    ///
    /// De brokken binne plakjes en oerlaapje net.As `chunk_size` de lingte fan it stik net dielt, dan hat it lêste stik gjin lingte `chunk_size`.
    ///
    /// Sjoch [`rchunks_exact`] foar in fariant fan dizze iterator dy't brokken fan altyd presys `chunk_size`-eleminten retourneert, en [`chunks`] foar deselde iterator, mar begjinne oan it begjin fan 'e snij.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Jout in iterator tagelyk oer `chunk_size`-eleminten fan 'e slice, begjinnend oan' e ein fan 'e slice.
    ///
    /// De brokken binne feroarbere plakken, en oerlaapje net.As `chunk_size` de lingte fan it stik net dielt, dan hat it lêste stik gjin lingte `chunk_size`.
    ///
    /// Sjoch [`rchunks_exact_mut`] foar in fariant fan dizze iterator dy't brokken fan altyd presys `chunk_size`-eleminten retourneert, en [`chunks_mut`] foar deselde iterator, mar begjinne oan it begjin fan 'e snij.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Jout in iterator tagelyk oer `chunk_size`-eleminten fan 'e slice, begjinnend oan' e ein fan 'e slice.
    ///
    /// De brokken binne plakjes en oerlaapje net.
    /// As `chunk_size` de lingte fan it stik net dielt, dan wurde de lêste oant `chunk_size-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `remainder`-funksje fan' e iterator.
    ///
    /// Trochdat elk stik presys `chunk_size`-eleminten hat, kin de gearstaller de resultearjende koade faaks better optimalisearje dan yn it gefal fan [`chunks`].
    ///
    /// Sjoch [`rchunks`] foar in fariant fan dizze iterator dy't de rest ek werombringt as in lytsere brok, en [`chunks_exact`] foar deselde iterator, mar begjint oan it begjin fan 'e slach.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Jout in iterator tagelyk oer `chunk_size`-eleminten fan 'e slice, begjinnend oan' e ein fan 'e slice.
    ///
    /// De brokken binne feroarbere plakken, en oerlaapje net.
    /// As `chunk_size` de lingte fan it stik net dielt, dan wurde de lêste oant `chunk_size-1`-eleminten weilitten en kinne se weromfûn wurde fan 'e `into_remainder`-funksje fan' e iterator.
    ///
    /// Trochdat elk stik presys `chunk_size`-eleminten hat, kin de gearstaller de resultearjende koade faaks better optimalisearje dan yn it gefal fan [`chunks_mut`].
    ///
    /// Sjoch [`rchunks_mut`] foar in fariant fan dizze iterator dy't de rest ek werombringt as in lytsere brok, en [`chunks_exact_mut`] foar deselde iterator, mar begjint oan it begjin fan 'e slach.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `chunk_size` 0 is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Jout in iterator oer it plak dat produseart net-oerlappende rinnen fan eleminten mei it predikaat om se te skieden.
    ///
    /// It predikaat wurdt neamd op twa eleminten dy't harsels folgje, it betsjuttet dat it predikaat wurdt neamd op `slice[0]` en `slice[1]` dan op `slice[1]` en `slice[2]` ensafuorthinne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dizze metoade kin brûkt wurde om de sorteare sublices te ekstraheren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Jout in iterator oer it stik dat net-oerlappende mutabele rinnen fan eleminten produseart mei it predikaat om se te skieden.
    ///
    /// It predikaat wurdt neamd op twa eleminten dy't harsels folgje, it betsjuttet dat it predikaat wurdt neamd op `slice[0]` en `slice[1]` dan op `slice[1]` en `slice[2]` ensafuorthinne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dizze metoade kin brûkt wurde om de sorteare sublices te ekstraheren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Dielt ien stik yn twa by in yndeks.
    ///
    /// De earste sil alle yndeksen fan `[0, mid)` befetsje (eksklusyf de yndeks `mid` sels) en de twadde sil alle yndeksen fan `[mid, len)` befetsje (eksklusyf de yndeks `len` sels).
    ///
    ///
    /// # Panics
    ///
    /// Panics as `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // VEILIGHEID: `[ptr; mid]` en `[mid; len]` binne yn `self`, wat
        // foldocht oan de easken fan `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Dielt ien mutabele skyfke yn twaen op in yndeks.
    ///
    /// De earste sil alle yndeksen fan `[0, mid)` befetsje (eksklusyf de yndeks `mid` sels) en de twadde sil alle yndeksen fan `[mid, len)` befetsje (eksklusyf de yndeks `len` sels).
    ///
    ///
    /// # Panics
    ///
    /// Panics as `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // VEILIGHEID: `[ptr; mid]` en `[mid; len]` binne yn `self`, wat
        // foldocht oan de easken fan `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Dielt ien stik yn twaen by in yndeks, sûnder grinzen te kontrolearjen.
    ///
    /// De earste sil alle yndeksen fan `[0, mid)` befetsje (eksklusyf de yndeks `mid` sels) en de twadde sil alle yndeksen fan `[mid, len)` befetsje (eksklusyf de yndeks `len` sels).
    ///
    ///
    /// Sjoch [`split_at`] foar in feilich alternatyf.
    ///
    /// # Safety
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen is *[undefined behavior]* sels as de resultearjende referinsje net wurdt brûkt.De beller moat derfoar soargje dat `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // VEILIGHEID: Beller moat dy `0 <= mid <= self.len()` kontrolearje
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Dielt ien mutabele skyfke yn twaen op in yndeks, sûnder grinzen te kontrolearjen.
    ///
    /// De earste sil alle yndeksen fan `[0, mid)` befetsje (eksklusyf de yndeks `mid` sels) en de twadde sil alle yndeksen fan `[mid, len)` befetsje (eksklusyf de yndeks `len` sels).
    ///
    ///
    /// Sjoch [`split_at_mut`] foar in feilich alternatyf.
    ///
    /// # Safety
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen is *[undefined behavior]* sels as de resultearjende referinsje net wurdt brûkt.De beller moat derfoar soargje dat `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // VEILIGHEID: Beller moat dy `0 <= mid <= self.len()` kontrolearje.
        //
        // `[ptr; mid]` en `[mid; len]` oerlaapje net, dus it werombringen fan in feroarbere referinsje is prima.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Jout in iterator oer subsydzjes skieden troch eleminten dy't oerienkomme mei `pred`.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// As it earste elemint oanpast wurdt, sil in lege plak it earste item wêze dat troch de iterator weromkomt.
    /// Lykas, as it lêste elemint yn 'e slach oerienkomt, sil in lege plak it lêste item wêze dat troch de iterator werom is:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// As twa oerienkommende eleminten direkt neistinoar lizze, sil der in leech plak tusken wêze:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Jout in iterator oer feroarbere sublices skieden troch eleminten dy't oerienkomme mei `pred`.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Jout in iterator oer subsydzjes skieden troch eleminten dy't oerienkomme mei `pred`.
    /// It oerienkommende elemint is befette oan 'e ein fan' e foarige subslice as terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// As it lêste elemint fan 'e slach oerienkomt, wurdt dat elemint beskôge as de terminator fan' e foargeande skyf.
    ///
    /// Dat stik sil it lêste item wêze dat troch de iterator werom is.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Jout in iterator oer feroarbere sublices skieden troch eleminten dy't oerienkomme mei `pred`.
    /// It oerienkommende elemint is opnommen yn 'e foarige subslice as terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Jout in iterator oer subslices skieden troch eleminten dy't oerienkomme mei `pred`, begjinnend oan 'e ein fan' e slice en efterút wurkje.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lykas by `split()`, as it earste as lêste elemint oerienkomt, sil in lege plak it earste (as lêste) item wêze dat troch de iterator werom is.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Jout in iterator oer mutabele subslices skieden troch eleminten dy't oerienkomme mei `pred`, begjinnend oan 'e ein fan' e slice en efterút wurkje.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Jout in iterator oer subslices skieden troch eleminten dy't oerienkomme mei `pred`, beheind ta it werombringen fan maksimaal `n` items.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// It lêste weromkommen elemint, as der is, sil de rest fan 'e slach befetsje.
    ///
    /// # Examples
    ///
    /// Printsje de slice ien kear splitst troch getallen dield mei 3 (ie `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Jout in iterator oer subslices skieden troch eleminten dy't oerienkomme mei `pred`, beheind ta it werombringen fan maksimaal `n` items.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// It lêste weromkommen elemint, as der is, sil de rest fan 'e slach befetsje.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Jout in iterator oer subsydzjes skieden troch eleminten dy't oerienkomme mei `pred` beheind ta it werombringen fan maksimaal `n`-items.
    /// Dit begjint oan 'e ein fan' e slice en wurket efterút.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// It lêste weromkommen elemint, as der is, sil de rest fan 'e slach befetsje.
    ///
    /// # Examples
    ///
    /// Printsje de slice ien kear splitst, begjinnend fan it ein, troch getallen te dielen mei 3 (ie `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Jout in iterator oer subsydzjes skieden troch eleminten dy't oerienkomme mei `pred` beheind ta it werombringen fan maksimaal `n`-items.
    /// Dit begjint oan 'e ein fan' e slice en wurket efterút.
    /// It oerienkommende elemint is net opnommen yn 'e sublizen.
    ///
    /// It lêste weromkommen elemint, as der is, sil de rest fan 'e slach befetsje.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Jout `true` werom as it stik in elemint befettet mei de opjûne wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// As jo gjin `&T` hawwe, mar gewoan in `&U`, sadat `T: Borrow<U>` (bgl
    /// `String: liene<str>`), kinne jo `iter().any` brûke:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // stikje `String`
    /// assert!(v.iter().any(|e| e == "hello")); // sykje mei `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Jout `true` werom as `needle` in foarheaksel fan it stik is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Jout `true` altyd werom as `needle` in leech plak is:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Jout `true` werom as `needle` in efterheaksel fan it stik is.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Jout `true` altyd werom as `needle` in leech plak is:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Jout in subsydzje werom mei it foarheaksel fuorthelle.
    ///
    /// As it stik begjint mei `prefix`, retourneert it dielstik nei it foarheaksel, ferpakt yn `Some`.
    /// As `prefix` leech is, retourneert gewoan it orizjinele plak.
    ///
    /// As it stik net begjint mei `prefix`, jout `None` werom.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Dizze funksje sil herskriuwe moatte as en wannear SlicePattern ferfine wurdt.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Jout in subslice werom mei it efterheaksel fuorthelle.
    ///
    /// As it stik einiget mei `suffix`, retourneert it dielstik foar it efterheaksel, ferpakt yn `Some`.
    /// As `suffix` leech is, retourneert gewoan it orizjinele plak.
    ///
    /// As it stik net einiget mei `suffix`, jout `None` werom.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Dizze funksje sil herskriuwe moatte as en wannear SlicePattern ferfine wurdt.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binêr siket dit sorteare plak nei in bepaald elemint.
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.
    /// As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    ///
    /// Sjoch ek [`binary_search_by`], [`binary_search_by_key`], en [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op.
    /// De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// As jo in item wolle ynfoegje yn in sorteare vector, mei behâld fan de folchoarder:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binêr siket dit sorteare plak mei in komparatorfunksje.
    ///
    /// De komparatorfunksje moat in oarder ymplementearje yn oerienstimming mei de sortearfolchoarder fan it ûnderlizzende plak, en in oardekoade weromjaan dy't oanjout as it argumint `Less`, `Equal` of `Greater` it winske doel is.
    ///
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    /// Sjoch ek [`binary_search`], [`binary_search_by_key`], en [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op.De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // VEILIGHEID: de oprop wurdt feilich makke troch de folgjende invarianten:
            // - `mid >= 0`
            // - `mid < size`: `mid` wurdt beheind troch `[left; right)` bûn.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // De reden wêrom't wy if/else-kontrôlefloed brûke yn stee fan oerienkomst is omdat de wedstriid fergeliking operaasjes opnij oardere, wat perf gefoelich is.
            //
            // Dit is x86 asm foar u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binêr siket dit sorteare plak mei in kaai-ekstraksjefunksje.
    ///
    /// Giet derfan út dat it plak wurdt sorteare op 'e kaai, bygelyks mei [`sort_by_key`] mei deselde ekstraksjefunksje foar kaaien.
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.
    /// As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    ///
    /// Sjoch ek [`binary_search`], [`binary_search_by`], en [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op yn in stik pearen sorteare op har twadde eleminten.
    /// De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links is tastien as `slice::sort_by_key` yn crate `alloc` is, en bestiet as sadanich noch net by it bouwen fan `core`.
    //
    // keppelings nei streamôfwerts crate: #74481.Sûnt primitiven wurde allinich dokuminteare yn libstd (#73423), liedt dit yn 'e praktyk nea ta brutsen keppelings.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorteert it stik, mar bewarret miskien net de folchoarder fan gelikense eleminten.
    ///
    /// Dit soarte is ynstabyl (dat kin gelikense eleminten opnij oarderje), yn plak (dus, alloceart net), en *O*(*n*\*log(* n*)) minste gefal.
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op [pattern-defeating quicksort][pdqsort] fan Orson Peters, dy't it rappe gemiddelde gefal fan randomisearre kwiksort kombineart mei it rapste minste gefal fan heapsort, wylst it lineêre tiid berikke op plakken mei bepaalde patroanen.
    /// It brûkt wat randomisaasje om degenerearre gefallen te foarkommen, mar mei in fêste seed om altyd deterministysk gedrach te leverjen.
    ///
    /// It is typysk flugger dan stabile sortearjen, útsein yn in pear bysûndere gefallen, bgl. As it stik bestiet út ferskate gearfoegde sorteare sekwinsjes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorteert it stik mei in komparatorfunksje, mar behâldt miskien net de folchoarder fan gelikense eleminten.
    ///
    /// Dit soarte is ynstabyl (dat kin gelikense eleminten opnij oarderje), yn plak (dus, alloceart net), en *O*(*n*\*log(* n*)) minste gefal.
    ///
    /// De komparatorfunksje moat in totale folchoarder definiearje foar de eleminten yn 'e snij.As de oardering net totaal is, is de oarder fan 'e eleminten net oantsjutte.In oarder is in totale oarder as it is (foar alle `a`, `b` en `c`):
    ///
    /// * totaal en antisymmetrysk: presys ien fan `a < b`, `a == b` of `a > b` is wier, en
    /// * transitive, `a < b` en `b < c` ymplisyt `a < c`.Itselde moat hâlde foar sawol `==` as `>`.
    ///
    /// Wylst bygelyks [`f64`] [`Ord`] net ymplementeart om't `NaN != NaN`, kinne wy `partial_cmp` brûke as ús sortfunksje as wy witte dat it stik gjin `NaN` befettet.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op [pattern-defeating quicksort][pdqsort] fan Orson Peters, dy't it rappe gemiddelde gefal fan randomisearre kwiksort kombineart mei it rapste minste gefal fan heapsort, wylst it lineêre tiid berikke op plakken mei bepaalde patroanen.
    /// It brûkt wat randomisaasje om degenerearre gefallen te foarkommen, mar mei in fêste seed om altyd deterministysk gedrach te leverjen.
    ///
    /// It is typysk flugger dan stabile sortearjen, útsein yn in pear bysûndere gefallen, bgl. As it stik bestiet út ferskate gearfoegde sorteare sekwinsjes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omkearde sortearring
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorteert it stik mei in kaai-ekstraksjefunksje, mar behâldt miskien de folchoarder fan gelikense eleminten net.
    ///
    /// Dit soarte is ynstabyl (dus kin gelikense eleminten opnij oarderje), yn plak (dus, alloceart net), en *O*(m\* * n *\* log(*n*)) minste gefal, wêr't de kaaifunksje *O* is (*m*).
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op [pattern-defeating quicksort][pdqsort] fan Orson Peters, dy't it rappe gemiddelde gefal fan randomisearre kwiksort kombineart mei it rapste minste gefal fan heapsort, wylst it lineêre tiid berikke op plakken mei bepaalde patroanen.
    /// It brûkt wat randomisaasje om degenerearre gefallen te foarkommen, mar mei in fêste seed om altyd deterministysk gedrach te leverjen.
    ///
    /// Fanwegen har kaaiopropstrategy is [`sort_unstable_by_key`](#method.sort_unstable_by_key) wierskynlik stadiger dan [`sort_by_cached_key`](#method.sort_by_cached_key) yn gefallen wêr't de kaaifunksje djoer is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Bestel it plak wer sa dat it elemint by `index` op syn definitive sorteare posysje is.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Bestel it plak opnij mei in komparatorfunksje sadat it elemint by `index` op syn definitive sorteare posysje is.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Bestel it plak opnij mei in funksje foar kaai-ekstraksje, sadat it elemint by `index` op syn definitive sorteare posysje is.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Bestel it plak wer sa dat it elemint by `index` op syn definitive sorteare posysje is.
    ///
    /// Dizze weryndieling hat it ekstra eigendom dat elke wearde op posysje `i < index` minder dan of gelyk is oan elke wearde op in posysje `j > index`.
    /// Derneist is dizze weryndieling ynstabyl (ie
    /// elk oantal gelikense eleminten kin einigje op posysje `index`), yn plak (ie
    /// alloceart net), en *O*(*n*) minste gefal.
    /// Dizze funksje is ek bekend as "kth element" yn oare biblioteken.
    /// It jout in triplet fan 'e folgjende wearden: alle eleminten minder dan de ien by de opjûne yndeks, de wearde by de opjûne yndeks, en alle eleminten dy't grutter binne dan de ien by de opjûne yndeks.
    ///
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op it kwikselekt diel fan itselde kwiksortalgoritme dat wurdt brûkt foar [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics as `index >= len()`, dat betsjut dat it altyd panics op lege plakjes is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Sykje de mediaan
    /// v.select_nth_unstable(2);
    ///
    /// // Wy wurde allinich garandearre dat it plak ien fan 'e folgjende sil wêze, basearre op' e manier wêrop wy sorteare oer de oantsjutte yndeks.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bestel it plak opnij mei in komparatorfunksje sadat it elemint by `index` op syn definitive sorteare posysje is.
    ///
    /// Dizze opnij oardering hat de ekstra eigenskip dat elke wearde op posysje `i < index` minder dan of gelyk is oan elke wearde op in posysje `j > index` mei de komparatorfunksje.
    /// Derneist is dizze oardering ynstabyl (dus elk oantal gelikense eleminten kin einigje op posysje `index`), te plak (dws alloceart net), en *O*(*n*) minste gefal.
    /// Dizze funksje wurdt ek wol "kth element" neamd yn oare biblioteken.
    /// It jout in triplet werom fan 'e folgjende wearden: alle eleminten minder dan de iene by de opjûne yndeks, de wearde by de opjûne yndeks, en alle eleminten dy't grutter binne dan de iene by de opjûne yndeks, mei help fan' e levere komparatorfunksje.
    ///
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op it kwikselekt diel fan itselde kwiksortalgoritme dat wurdt brûkt foar [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics as `index >= len()`, dat betsjut dat it altyd panics op lege plakjes is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Sykje de mediaan as soe it plak yn ôfnimmende folchoarder wurde sorteare.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Wy wurde allinich garandearre dat it plak ien fan 'e folgjende sil wêze, basearre op' e manier wêrop wy sorteare oer de oantsjutte yndeks.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bestel it plak opnij mei in funksje foar kaai-ekstraksje, sadat it elemint by `index` op syn definitive sorteare posysje is.
    ///
    /// Dizze opnij oardering hat it ekstra eigendom dat elke wearde op posysje `i < index` minder dan of lyk is oan elke wearde op in posysje `j > index` mei de funksje fan kaai-ekstraksje.
    /// Derneist is dizze oardering ynstabyl (dus elk oantal gelikense eleminten kin einigje op posysje `index`), te plak (dws alloceart net), en *O*(*n*) minste gefal.
    /// Dizze funksje wurdt ek wol "kth element" neamd yn oare biblioteken.
    /// It jout in trijetal werom fan 'e folgjende wearden: alle eleminten minder dan de iene by de opjûne yndeks, de wearde by de opjûne yndeks, en alle eleminten dy't grutter binne dan de iene by de opjûne yndeks, mei de foarsjoen fan de funksje foar ekstraksje fan kaaien.
    ///
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op it kwikselekt diel fan itselde kwiksortalgoritme dat wurdt brûkt foar [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics as `index >= len()`, dat betsjut dat it altyd panics op lege plakjes is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Jou de mediaan werom as soe de array sorteare wurde neffens absolute wearde.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Wy wurde allinich garandearre dat it plak ien fan 'e folgjende sil wêze, basearre op' e manier wêrop wy sorteare oer de oantsjutte yndeks.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Ferpleatst alle opienfolgjende werhelle eleminten nei it ein fan 'e slice neffens de [`PartialEq`] trait-ymplemintaasje.
    ///
    ///
    /// Jout twa plakjes werom.De earste befettet gjin opienfolgjende werhelle eleminten.
    /// De twadde befettet alle duplikaten yn gjin oantsjutte folchoarder.
    ///
    /// As it stik wurdt sorteare, befettet it earste weromkommen plak gjin duplikaat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Ferpleatst allegear mar de earste opienfolgjende eleminten nei it ein fan 'e slach dy't foldogge oan in opjûne gelikensrelaasje.
    ///
    /// Jout twa plakjes werom.De earste befettet gjin opienfolgjende werhelle eleminten.
    /// De twadde befettet alle duplikaten yn gjin oantsjutte folchoarder.
    ///
    /// De `same_bucket`-funksje wurdt referinsjes trochjûn nei twa eleminten fan 'e slice en moat bepale as de eleminten gelyk binne.
    /// De eleminten wurde yn tsjinoerstelde folchoarder trochjûn fan har oarder yn 'e snij, dus as `same_bucket(a, b)` `true` weromkomt, wurdt `a` ferpleatst oan' e ein fan 'e snij.
    ///
    ///
    /// As it stik wurdt sorteare, befettet it earste weromkommen plak gjin duplikaat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Hoewol wy in mutabele ferwizing hawwe nei `self`, kinne wy gjin *willekeurige* wizigingen meitsje.De `same_bucket`-oproppen kinne panic wêze, dat wy moatte derfoar soargje dat it stik altyd yn in jildige steat is.
        //
        // De manier wêrop wy dit omgeane is troch swaps te brûken;wy iterearje oer alle eleminten, wikselje as wy geane, sadat oan 'e ein de eleminten dy't wy wolle behâlde foaroan binne, en dejingen dy't wy wolle ôfwize binne oan' e efterkant.
        // Wy kinne it diel dan diele.
        // Dizze operaasje is noch altyd `O(n)`.
        //
        // Foarbyld: Wy begjinne yn dizze tastân, wêr't `r` "folgjende" fertsjintwurdiget
        // lês "en `w` fertsjintwurdiget" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Fergelykje self[r] tsjin sels [w-1], dit is gjin duplikaat, dus wy ruilje self[r] en self[w] (gjin effekt as r==w) en ferhegje dan sawol r as w, en litte ús mei:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Fergelykje self[r] tsjin sels [w-1], dizze wearde is in duplikaat, dat wy `r` ferheegje, mar litte al it oare net feroarje:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Fergelykje self[r] tsjin sels [w-1], dit is gjin duplikaat, dus ruilje self[r] en self[w] om en r en w foarút:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Net in duplikaat, werhelje:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplisearje, advance r. End fan plak.Spjalte by w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // VEILIGHEID: de betingst `while` garandeart `next_read` en `next_write`
        // binne minder dan `len`, dus binne se yn `self`.
        // `prev_ptr_write` wiist op ien elemint foar `ptr_write`, mar `next_write` begjint by 1, dus `prev_ptr_write` is noait minder dan 0 en is binnen it stik.
        // Dit foldocht oan de easken foar ferwidering fan `ptr_read`, `prev_ptr_write` en `ptr_write`, en foar gebrûk fan `ptr.add(next_read)`, `ptr.add(next_write - 1)` en `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` wurdt op syn meast ek ien kear per loop ferhege, dat betsjuttet dat gjin elemint wurdt oerslein as it kin wiksele wurde moatte.
        //
        // `ptr_read` en `prev_ptr_write` wiist noait op itselde elemint.Dit is nedich foar `&mut *ptr_read`, `&mut* prev_ptr_write` om feilich te wêzen.
        // De útlis is gewoan dat `next_read >= next_write` altyd wier is, dus `next_read > next_write - 1` ek.
        //
        //
        //
        //
        //
        unsafe {
            // Mije grinzen kontrolearje troch rauwe oanwizers te brûken.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ferpleatst allegear mar de earste opienfolgjende eleminten nei it ein fan 'e slúf dy't op deselde kaai oplost.
    ///
    ///
    /// Jout twa plakjes werom.De earste befettet gjin opienfolgjende werhelle eleminten.
    /// De twadde befettet alle duplikaten yn gjin oantsjutte folchoarder.
    ///
    /// As it stik wurdt sorteare, befettet it earste weromkommen plak gjin duplikaat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Draait it plak yn plak sadat de earste `mid`-eleminten fan 'e slice nei it ein ferpleatse, wylst de lêste `self.len() - mid`-eleminten nei de foarkant ferpleatse.
    /// Nei it oproppen fan `rotate_left` sil it elemint earder by yndeks `mid` it earste elemint wurde yn 'e slach.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as `mid` grutter is dan de lingte fan it stik.Tink derom dat `mid == self.len()` _not_ panic docht en in no-op-rotaasje is.
    ///
    /// # Complexity
    ///
    /// Nimt linich (yn `self.len()`) tiid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// In subslice rotearje:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // VEILIGHEID: It berik `[p.add(mid) - mid, p.add(mid) + k)` is triviaal
        // jildich foar lêzen en skriuwen, lykas ferplicht troch `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Draait it plak yn plak sadat de earste `self.len() - k`-eleminten fan 'e slice nei it ein ferpleatse, wylst de lêste `k`-eleminten nei de foarkant ferpleatse.
    /// Nei it oproppen fan `rotate_right` sil it elemint earder by yndeks `self.len() - k` it earste elemint wurde yn 'e slach.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as `k` grutter is dan de lingte fan it stik.Tink derom dat `k == self.len()` _not_ panic docht en in no-op-rotaasje is.
    ///
    /// # Complexity
    ///
    /// Nimt linich (yn `self.len()`) tiid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// In subslice draaie:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // VEILIGHEID: It berik `[p.add(mid) - mid, p.add(mid) + k)` is triviaal
        // jildich foar lêzen en skriuwen, lykas ferplicht troch `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Folt `self` mei eleminten troch `value` te klonearjen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Folt `self` mei eleminten werom troch meardere kearen in sluting te skiljen.
    ///
    /// Dizze metoade brûkt in sluting om nije wearden te meitsjen.As jo leaver [`Clone`] in opjûne wearde hawwe, brûk dan [`fill`].
    /// As jo de [`Default`] trait wolle brûke om wearden te generearjen, kinne jo [`Default::default`] trochjaan as argumint.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopieart de eleminten fan `src` nei `self`.
    ///
    /// De lingte fan `src` moat itselde wêze as `self`.
    ///
    /// As `T` `Copy` ymplementeart, kin it prestearder wêze om [`copy_from_slice`] te brûken.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de twa plakjes ferskillende lingtes hawwe.
    ///
    /// # Examples
    ///
    /// Kloning fan twa eleminten fan in plak yn in oar:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Om't de plakken deselde lingte moatte hawwe, snije wy de boarne-stik fan fjouwer eleminten nei twa.
    /// // It sil panic as wy dit net dogge.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust twingt dat der mar ien feroarbere referinsje kin wêze sûnder unferoarlike ferwizings nei in bepaald stik gegevens yn in bepaalde omfang.
    /// Hjirtroch sil it besykjen om `clone_from_slice` op ien stik te brûken resultearje yn in kompilearingsflater:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Om dit om te wurkjen kinne wy [`split_at_mut`] brûke om twa ûnderskate subplakken te meitsjen fan in stik:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopieart alle eleminten fan `src` nei `self`, mei in memcpy.
    ///
    /// De lingte fan `src` moat itselde wêze as `self`.
    ///
    /// As `T` `Copy` net ymplementeart, brûk dan [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de twa plakjes ferskillende lingtes hawwe.
    ///
    /// # Examples
    ///
    /// Twa eleminten fan in stik nei in oare kopiearje:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Om't de plakken deselde lingte moatte hawwe, snije wy de boarne-stik fan fjouwer eleminten nei twa.
    /// // It sil panic as wy dit net dogge.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust twingt dat der mar ien feroarbere referinsje kin wêze sûnder unferoarlike ferwizings nei in bepaald stik gegevens yn in bepaalde omfang.
    /// Hjirtroch sil it besykjen om `copy_from_slice` op ien stik te brûken resultearje yn in kompilearingsflater:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Om dit om te wurkjen kinne wy [`split_at_mut`] brûke om twa ûnderskate subplakken te meitsjen fan in stik:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // It koadepaad panic waard yn in kâlde funksje set om de opropside net op te blazen.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // VEILIGHEID: `self` is per definysje jildich foar `self.len()`-eleminten, en `src` wie
        // kontrolearre om deselde lingte te hawwen.
        // De plakjes kinne net oerlaapje, om't mutabele referinsjes eksklusyf binne.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopieart eleminten fan it iene diel fan 'e slice nei it oare diel fan himsels, mei in memmove.
    ///
    /// `src` is it berik binnen `self` om fan te kopiearjen.
    /// `dest` is de startyndeks fan it berik binnen `self` om nei te kopiearjen, dat deselde lingte hat as `src`.
    /// De twa berikken kinne oerlaapje.
    /// De einen fan 'e twa berikken moatte minder wêze as of lyk oan `self.len()`.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as elk berik it ein fan 'e slach grutter is, of as it ein fan `src` foar it begjin is.
    ///
    ///
    /// # Examples
    ///
    /// Fjouwer bytes kopiearje binnen in stik:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // VEILIGHEID: de betingsten foar `ptr::copy` binne hjirboppe kontroleare,
        // lykas dy foar `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ruilje alle eleminten yn `self` mei dy yn `other`.
    ///
    /// De lingte fan `other` moat itselde wêze as `self`.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de twa plakjes ferskillende lingtes hawwe.
    ///
    /// # Example
    ///
    /// Wikselje twa eleminten oer plakken:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust twingt dat der mar ien feroarbere ferwizing kin wêze nei in bepaald stik gegevens yn in bepaalde omfang.
    ///
    /// Hjirtroch sil it besykjen om `swap_with_slice` op ien stik te brûken resultearje yn in kompilearingsflater:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Om dit om te wurkjen kinne wy [`split_at_mut`] brûke om twa ûnderskate mutabele sub-plakken te meitsjen fan in stik:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // VEILIGHEID: `self` is per definysje jildich foar `self.len()`-eleminten, en `src` wie
        // kontrolearre om deselde lingte te hawwen.
        // De plakjes kinne net oerlaapje, om't mutabele referinsjes eksklusyf binne.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funksje om lingten fan 'e middelste en efterlizzende slach foar `align_to{,_mut}` te berekkenjen.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Wat wy oer `rest` sille dwaan is útfine hokker meardere fan 'U's wy yn in leechste oantal' T's kinne sette.
        //
        // En hoefolle `T`s wy nedich binne foar elke sokke "multiple".
        //
        // Tink bygelyks oan T=u8 U=u16.Dan kinne wy 1 U yn 2 Ts sette.Ienfâldich.
        // Besjoch no bygelyks in saak wêr't size_of: :<T>=16, grutte_fan::<U>=24.</u>
        // Wy kinne 2 Us op it plak fan elke 3 Ts yn 'e `rest`-plak sette.
        // In bytsje yngewikkelder.
        //
        // Formule om dit te berekkenjen is:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Utwreide en ferienfâldige:
        //
        // Us=grutte_fan: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=grutte_fan::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Gelokkich om't dit alles konstant wurdt evalueare ... prestaasje hjir is net wichtich!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein's algoritme Wy moatte dizze `const fn` noch altyd meitsje (en weromgean nei rekursyf algoritme as wy dat dogge), want fertrouwe op llvm om dit alles te bestean is ... no, it makket my ûngemaklik.
            //
            //

            // VEILIGHEID: `a` en `b` wurde kontroleare as wearden dy't net nul binne.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ferwiderje alle faktoaren fan 2 fan b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // VEILIGHEID: `b` wurdt kontroleare as net-nul.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bewapene mei dizze kennis kinne wy fine hoefolle `U`s wy kinne passe!
        let us_len = self.len() / ts * us;
        // En hoefolle `T`'s sille wêze yn 'e efterlizzende slice!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute de slice nei in slice fan in oar type, soargje derfoar dat de ôfstimming fan 'e typen wurdt hanthavene.
    ///
    /// Dizze metoade splitst it stikje yn trije ûnderskate plakken: foarheaksel, goed rjochte middelste plak fan in nij type, en it efterheaksel plak.
    /// De metoade kin de middelste slach de grutste lingte mooglik meitsje foar in bepaald type en ynfierplak, mar allinich de prestaasjes fan jo algoritme moatte dêrfan ôfhingje, net de justeheid.
    ///
    /// It is tastien dat alle ynfiergegevens wurde weromjûn as it foar-of efterheaksel.
    ///
    /// Dizze metoade hat gjin doel as beide ynfiereleminten `T` as útfiereleminten `U` nulgrutte binne en it orizjinele plak werombringe sûnder wat te splitsen.
    ///
    /// # Safety
    ///
    /// Dizze metoade is yn essinsje in `transmute` oangeande de eleminten yn 'e weromkearde middelste skyf, dus alle normale warskôgingen oangeande `transmute::<T, U>` jilde hjir ek.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Tink derom dat de measte fan dizze funksje konstant wurde evaluearre,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // behannelje ZST's spesjaal, dat is-behannelje se hielendal net.
            return (self, &[], &[]);
        }

        // Fyn earst op hokker punt wy ferdiele tusken it earste en it twadde plak.
        // Maklik mei ptr.align_offset.
        let ptr = self.as_ptr();
        // VEILIGHEID: Sjoch de `align_to_mut`-metoade foar it detaillearre kommentaar oer feiligens.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // VEILIGHEID: no is `rest` definityf oanpast, dus `from_raw_parts` hjirûnder is goed,
            // sûnt de beller garandeart dat wy `T` feilich nei `U` kinne transmutearje.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute de slice nei in slice fan in oar type, soargje derfoar dat de ôfstimming fan 'e typen wurdt hanthavene.
    ///
    /// Dizze metoade splitst it stikje yn trije ûnderskate plakken: foarheaksel, goed rjochte middelste plak fan in nij type, en it efterheaksel plak.
    /// De metoade kin de middelste slach de grutste lingte mooglik meitsje foar in bepaald type en ynfierplak, mar allinich de prestaasjes fan jo algoritme moatte dêrfan ôfhingje, net de justeheid.
    ///
    /// It is tastien dat alle ynfiergegevens wurde weromjûn as it foar-of efterheaksel.
    ///
    /// Dizze metoade hat gjin doel as beide ynfiereleminten `T` as útfiereleminten `U` nulgrutte binne en it orizjinele plak werombringe sûnder wat te splitsen.
    ///
    /// # Safety
    ///
    /// Dizze metoade is yn essinsje in `transmute` oangeande de eleminten yn 'e weromkearde middelste skyf, dus alle normale warskôgingen oangeande `transmute::<T, U>` jilde hjir ek.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Tink derom dat de measte fan dizze funksje konstant wurde evaluearre,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // behannelje ZST's spesjaal, dat is-behannelje se hielendal net.
            return (self, &mut [], &mut []);
        }

        // Fyn earst op hokker punt wy ferdiele tusken it earste en it twadde plak.
        // Maklik mei ptr.align_offset.
        let ptr = self.as_ptr();
        // VEILIGHEID: Hjir soargje wy derfoar dat wy rjochte oanwizings sille brûke foar U foar de
        // rest fan 'e metoade.Dit wurdt dien troch in oanwizer nei&[T] troch te jaan mei in op U rjochte opstelling.
        // `crate::ptr::align_offset` wurdt neamd mei in korrekt rjochte en jildige oanwizer `ptr` (it komt fan in ferwizing nei `self`) en mei in grutte dy't in krêft fan twa is (om't it komt fan 'e ôfstimming foar U), en foldocht oan syn feiligensbeheiningen.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Wy kinne `rest` hjirnei net wer brûke, dat sil de alias `mut_ptr` unjildich meitsje!VEILIGHEID: sjoch opmerkingen foar `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontroleart as de eleminten fan dit stik sorteare binne.
    ///
    /// Dat is, foar elk elemint `a` en it folgjende elemint `b` moat `a <= b` hâlde.As it stik presys nul as ien elemint oplevert, wurdt `true` weromjûn.
    ///
    /// Tink derom dat as `Self::Item` allinich `PartialOrd` is, mar net `Ord`, de boppesteande definysje ympliseart dat dizze funksje `false` werombringt as twa opienfolgjende items net te fergelykjen binne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontroleart as de eleminten fan dit stik wurde sorteare mei de opjûne komparatorfunksje.
    ///
    /// Ynstee fan `PartialOrd::partial_cmp` te brûken, brûkt dizze funksje de opjûne `compare`-funksje om de oardering fan twa eleminten te bepalen.
    /// Ofsjoen fan dat, is it ekwivalint mei [`is_sorted`];sjoch de dokumintaasje foar mear ynformaasje.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontroleart as de eleminten fan dit stik wurde sorteare mei de opjûne funksje foar ekstraksje fan kaaien.
    ///
    /// Ynstee fan 'e eleminten fan it stik direkt te fergelykjen, fergeliket dizze funksje de kaaien fan' e eleminten, lykas bepaald troch `f`.
    /// Ofsjoen fan dat, is it ekwivalint mei [`is_sorted`];sjoch de dokumintaasje foar mear ynformaasje.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Jout de yndeks fan it dielingspunt neffens it opjûne predikaat (de yndeks fan it earste elemint fan 'e twadde dieling).
    ///
    /// It plak wurdt oannommen dat er ferdield is neffens it opjûne predikaat.
    /// Dit betsjuttet dat alle eleminten wêr't it predikaat wier werom is oan it begjin fan 'e slice binne en alle eleminten wêrfoar't it predikaat falsk jout, oan' e ein binne.
    ///
    /// Bygelyks, [7, 15, 3, 5, 4, 12, 6] is in dieling ûnder it predikaat x% 2!=0 (alle ûneven getallen binne oan it begjin, allegear sels oan 'e ein).
    ///
    /// As dit stikje net ferdield is, is it weromkommen resultaat net oantsjutte en sinleas, om't dizze metoade in soarte fan binêre sykopdracht útfiert.
    ///
    /// Sjoch ek [`binary_search`], [`binary_search_by`], en [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // VEILIGHEID: As `left < right`, `left <= mid < right`.
            // Dêrom nimt `left` altyd ta en `right` nimt altyd ôf, en ien fan har wurdt selekteare.Yn beide gefallen is `left <= right` tefreden.Dêrom as `left < right` yn in stap is, is `left <= right` tefreden oer de folgjende stap.
            //
            // Dêrom salang't `left != right`, `0 <= left < right <= len` tefreden is en as dit gefal `0 <= mid < len` ek tefreden is.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Wy moatte se eksplisyt op deselde lingte snije
        // om it foar de optimizer makliker te meitsjen om grinzen te kontrolearjen.
        // Mar om't it net kin wurde fertroud, hawwe wy ek in eksplisite spesjalisaasje foar T: Kopiearje.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Makket in lege plak.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Makket in feroarbere lege plak.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patroanen yn plakjes, op it stuit, allinich brûkt troch `strip_prefix` en `strip_suffix`.
/// Op in future-punt hoopje wy `core::str::Pattern` (dy't op it stuit fan dit skriuwen is beheind ta `str`) te generalisearjen nei plakjes, en dan sil dizze trait wurde ferfongen of ôfskaft.
///
pub trait SlicePattern {
    /// It elemtype fan 'e slach wêrop't wurdt oanpast.
    type Item;

    /// Op it stuit hawwe de konsuminten fan `SlicePattern` in stikje nedich.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}