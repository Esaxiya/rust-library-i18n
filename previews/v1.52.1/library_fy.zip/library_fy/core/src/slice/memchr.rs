// Oarspronklike ymplemintaasje nommen út rust-memchr.
// Auteursrjocht 2015 Andrew Gallant, bluss en Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Brûk trunkaasje.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Jout `true` werom as `x` in nulbyte befettet.
///
/// Fan *Matters Computational*, J. Arndt:
///
/// "It idee is ien fan elk fan 'e bytes te lûken en dan te sykjen nei bytes wêr't de liening hielendal fuortplant nei de meast wichtige
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Jout de earste yndeks oerien mei de byte `x` yn `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Fluch paad foar lytse plakjes
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan foar ien bytewearde troch twa `usize`-wurden tagelyk te lêzen.
    //
    // Split `text` yn trije dielen
    // - net-rjochte earste diel, foardat it earste wurd rjochte adres yn tekst is
    // - lichem, scan mei 2 wurden tagelyk
    // - it lêste oerbleaune diel, <2 wurdgrutte

    // sykje oant in rjochte grins
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // sykje it lichem fan 'e tekst
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // VEILIGHEID: it predikaat fan 'e skoft garandeart in ôfstân fan teminsten 2 * usize_bytes
        // tusken de offset en it ein fan 'e slice.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // brek as der in bypassende byte is
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Fyn de byte nei it punt dat de lichemslus stopte.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Jout de lêste yndeks oerien mei de byte `x` yn `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan foar ien bytewearde troch twa `usize`-wurden tagelyk te lêzen.
    //
    // Split `text` yn trije dielen:
    // - net-rjochte sturt, nei it lêste wurd rjochte adres yn tekst,
    // - lichem, scand troch twa wurden tagelyk,
    // - de earste oerbleaune bytes, <2 wurdgrutte.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Wy neame dit gewoan om de lingte fan it foar-en efterheaksel te krijen.
        // Yn it midden ferwurkje wy altyd twa brokken tagelyk.
        // VEILIGHEID: transmutearjen fan `[u8]` nei `[usize]` is feilich, útsein grutte ferskillen dy't wurde behannele troch `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Sykje yn it lichem fan 'e tekst, soargje derfoar dat wy min_aligned_offset net oerstekke.
    // offset is altyd ôfstimd, dus gewoan testen fan `>` is genôch en foarkomt mooglike oerstreaming.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // VEILIGHEID: offset begjint by len, suffix.len(), salang't it grutter is dan
        // min_aligned_offset (prefix.len()) de oerbleaune ôfstân is teminsten 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Brek as d'r in bypassende byte is.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Sykje de byte foar it punt dat de lichemslus stoppe.
    text[..offset].iter().rposition(|elt| *elt == x)
}