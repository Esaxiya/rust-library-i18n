//! Makro's brûkt troch iterators fan plak.

// Ynlining is_empty en len makket in enoarm prestaasjeferskil
macro_rules! is_empty {
    // De manier wêrop wy de lingte fan in ZST-iterator kodearje, dit wurket sawol foar ZST as net-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Om wat grinzen kontrôle te ferwiderjen (sjoch `position`), berekkenje wy de lingte op in wat ûnferwachte manier.
// (Getest troch 'codegen/slice-position-bounds-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // wy wurde soms brûkt yn in ûnfeilich blok

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Dizze _cannot_ brûkt `unchecked_sub` om't wy ôfhinklik binne fan ynpakken om de lingte fan lange ZST-slach iterators foar te stellen.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Wy witte dat `start <= end`, dus better kin dan `offset_from`, dy't ûndertekene moat omgean.
            // Troch hjir passende flaggen yn te stellen, kinne wy LLVM dit fertelle, wat it helpt om grinzen kontrôle te ferwiderjen.
            // VEILIGHEID: Troch it type invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Troch ek LLVM te fertellen dat de oanwizers apart binne troch in krekte meartal fan 'e type grutte, kin it `len() == 0` nei `start == end` ynstee fan `(end - start) < size` optimalisearje.
            //
            // VEILIGHEID: Troch it type invariant wurde de oanwizers rjochte sadat de
            //         ôfstân tusken har moat in meardere wêze fan pointee-grutte
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// De dielde definysje fan 'e `Iter`-en `IterMut`-iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Jout it earste elemint werom en beweecht it begjin fan 'e iterator mei 1 foarút.
        // Ferbetert de prestaasjes sterk yn fergeliking mei in ynline-funksje.
        // De iterator mei net leech wêze.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Jout it lêste elemint werom en beweecht it ein fan 'e iterator mei 1 efterút.
        // Ferbetert de prestaasjes sterk yn fergeliking mei in ynline-funksje.
        // De iterator mei net leech wêze.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krimp de iterator as T in ZST is, troch it ein fan 'e iterator mei `n` efterút te ferpleatsen.
        // `n` moat `self.len()` net heger wêze.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helperfunksje foar it meitsjen fan in stik út 'e iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // VEILIGHEID: de iterator is makke út in stikje mei oanwizer
                // `self.ptr` en lingte `len!(self)`.
                // Dit garandeart dat alle betingsten foar `from_raw_parts` binne foldien.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helperfunksje foar it ferpleatsen fan it begjin fan 'e iterator troch `offset`-eleminten, wêrtroch de âlde start weromkomt.
            //
            // Unfeilich omdat de offset `self.len()` net hoecht te wêzen.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // VEILIGHEID: de beller garandeart dat `offset` `self.len()` net grutter is,
                    // dat dizze nije oanwizer is yn `self` en garandeart dus net-nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helperfunksje om it ein fan 'e iterator efterút te ferpleatsen troch `offset`-eleminten, it nije ein werom te jaan.
            //
            // Unfeilich omdat de offset `self.len()` net hoecht te wêzen.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // VEILIGHEID: de beller garandeart dat `offset` `self.len()` net grutter is,
                    // dy't garandearre is dat in `isize` net oerstreamt.
                    // De resultearjende oanwizer is ek yn grinzen fan `slice`, dy't foldocht oan de oare easken foar `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // koe wurde útfierd mei plakjes, mar dit foarkomt grinzen fan kontrôles

                // VEILIGHEID: `assume`-petearen binne feilich sûnt de startpointer fan in stik
                // moat net-nul wêze, en plakken oer net-ZST's moatte ek in net-nul-einwizer hawwe.
                // De oprop nei `next_unchecked!` is feilich, om't wy earst kontrolearje as de iterator leech is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dizze iterator is no leech.
                    if mem::size_of::<T>() == 0 {
                        // Wy moatte it op dizze manier dwaan, om't `ptr` noait 0 kin wêze, mar `end` kin wêze (fanwegen ferpakking).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // VEILIGHEID: ein kin net 0 wêze as T net ZST is omdat ptr net 0 is en ein>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // VEILIGHEID: Wy binne yn grinzen.`post_inc_start` docht it goede sels foar ZST's.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            // Ek de `assume` foarkomt in grinskontrôle.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // VEILIGHEID: wy wurde garandearre yn grinzen te wêzen troch de lus-invariant:
                        // doe't `i >= n`, `self.next()` werom `None` en de loop brekt.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Wy oerskriuwe de standertútfiering, dy't `try_fold` brûkt, om't dizze ienfâldige ymplemintaasje minder LLVM IR genereart en rapper is te kompilearjen.
            // Ek de `assume` foarkomt in grinskontrôle.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // VEILIGHEID: `i` moat leger wêze dan `n`, om't it begjint by `n`
                        // en nimt allinich ôf.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // VEILIGHEID: de beller moat garandearje dat `i` yn grinzen is fan
                // de ûnderlizzende slice, sadat `i` in `isize` net kin oerspuie, en de weromferwizingen wurde garandearre om te ferwizen nei in elemint fan 'e slice en dus garandearre dat se jildich binne.
                //
                // Tink derom ek dat de beller ek garandeart dat wy noait wer mei deselde yndeks wurde neamd, en dat gjin oare metoaden wurde neamd dy't tagong krije ta dizze subslice, dus it is jildich dat de weromferwizende feroaring kin wêze yn 't gefal fan
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // koe wurde útfierd mei plakjes, mar dit foarkomt grinzen fan kontrôles

                // VEILIGHEID: `assume`-oproppen binne feilich, om't de startwizer fan in stik net-nul moat wêze,
                // en plakken oer net-ZST's moatte ek in net-nul-oanwizer hawwe.
                // De oprop nei `next_back_unchecked!` is feilich, om't wy earst kontrolearje as de iterator leech is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dizze iterator is no leech.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // VEILIGHEID: Wy binne yn grinzen.`pre_dec_end` docht it goede sels foar ZST's.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}