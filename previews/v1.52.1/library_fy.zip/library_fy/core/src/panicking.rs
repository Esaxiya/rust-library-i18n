//! Panic-stipe foar libcore
//!
//! De kearnbibleteek kin gjin panyk definiearje, mar it *ferklearret* panyk.
//! Dit betsjuttet dat de funksjes binnen fan libcore binne tastien oan panic, mar om nuttich te wêzen, moat in streamop crate panik definieare foar libcore om te brûken.
//! De hjoeddeistige ynterface foar panyk is:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Dizze definysje makket panik mei elk algemien berjocht, mar it makket it net mooglik om te mislearjen mei in `Box<Any>`-wearde.
//! (`PanicInfo` befettet gewoan in `&(dyn Any + Send)`, wêrfoar't wy in dummywearde ynfiere yn 'PanicInfo: : internal_constructor'.) De reden hjirfoar is dat libcore net tawiisd is.
//!
//!
//! Dizze module befettet in pear oare panikfunksjes, mar dit binne gewoan de nedige langitems foar de kompilearder.Alle panics wurde troch dizze iene funksje treaun.
//! It eigentlike symboal wurdt ferklearre fia it `#[panic_handler]`-attribút.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// De ûnderlizzende ymplemintaasje fan de `panic!`-makro fan libcore as gjin opmaak wurdt brûkt.
#[cold]
// nea ynline, útsein panic_immediate_abort om koade op 'e opropsites safolle mooglik te foarkommen
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nedich troch codegen foar panic op oerrin en oare `Assert` MIR-terminators
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Brûk Arguments::new_v1 ynstee fan format_args! ("{}", Expr) om de grutte fan overhead mooglik te ferminderjen.
    // De format_args!makro brûkt str's Display trait om expr te skriuwen, dy't Formatter::pad neamt, dy't stringferkutting en padding moatte befetsje (hoewol hjir gjin ien wurdt brûkt).
    //
    // Mei Arguments::new_v1 kin de kompilator Formatter::pad fan 'e útfierbinaire weglitte, en kin oant in pear kilobyte besparje.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nedich foar con-evaluearre panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nedich troch codegen foar panic op OOB array/slice tagong
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// De ûnderlizzende ymplemintaasje fan de `panic!`-makro fan libcore as opmaak wurdt brûkt.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OPMERKING Dizze funksje giet de FFI-grins noait oer;it is in Rust-to-Rust-oprop dy't wurdt oplost nei de `#[panic_handler]`-funksje.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // VEILIGHEID: `panic_impl` wurdt definieare yn feilige Rust-koade en is dus feilich te skiljen.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Ynterne funksje foar `assert_eq!`-en `assert_ne!`-makro's
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}