//! De `Clone` trait foar typen dy't net 'ymplisyt wurde kopieare'.
//!
//! Yn Rust binne inkele ienfâldige typen "implicitly copyable" en as jo se tawize of as arguminten trochjaan, sil de ûntfanger in kopy krije, wêrtroch de orizjinele wearde te plak is.
//! Dizze typen binne gjin tawizing nedich om te kopiearjen en hawwe gjin finalisearders (dat wol sizze dat se gjin fakjes befetsje of [`Drop`] ymplementearje), dus beskôget de gearstaller se goedkeap en feilich te kopiearjen.
//!
//! Foar oare soarten moatte kopyen eksplisyt wurde makke, troch konvinsje de [`Clone`] trait te ymplementearjen en de [`clone`]-metoade te neamen.
//!
//! [`clone`]: Clone::clone
//!
//! Basis gebrûk foarbyld:
//!
//! ```
//! let s = String::new(); // String type ymplementeart Clone
//! let copy = s.clone(); // sadat wy it kinne klone
//! ```
//!
//! Om de Clone trait maklik te ymplementearjen, kinne jo ek `#[derive(Clone)]` brûke.Foarbyld:
//!
//! ```
//! #[derive(Clone)] // wy foegje de Clone trait ta oan Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // en no kinne wy it klone!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// In mienskiplike trait foar de mooglikheid om in objekt eksplisyt te duplisearjen.
///
/// Ferskilt fan [`Copy`] yn dy [`Copy`] is ymplisyt en ekstreem goedkeap, wylst `Clone` altyd eksplisyt is en wol of net djoer kin wêze.
/// Om dizze skaaimerken te hanthavenjen, lit Rust jo net ta om [`Copy`] opnij te ymplementearjen, mar jo kinne `Clone` opnij ymplementearje en willekeurige koade útfiere.
///
/// Om't `Clone` algemiener is dan [`Copy`], kinne jo automatysk alles [`Copy`] ek `Clone` meitsje.
///
/// ## Derivable
///
/// Dizze trait kin brûkt wurde mei `#[derive]` as alle fjilden `Clone` binne.De útfiering fan 'derive`d fan [`Clone`] neamt [`clone`] op elk fjild.
///
/// [`clone`]: Clone::clone
///
/// Foar in generike struktuer ymplementeart `#[derive]` `Clone` betingst troch tafoegjen fan bûn `Clone` op generike parameters.
///
/// ```
/// // `derive` ymplementeart Clone for Reading<T>as T Klon is.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hoe kin ik `Clone` útfiere?
///
/// Soarten dy't [`Copy`] binne, moatte in triviale ymplemintaasje fan `Clone` hawwe.Mear formeel:
/// as `T: Copy`, `x: T` en `y: &T`, dan is `let x = y.clone();` ekwivalint mei `let x = *y;`.
/// Hânlieding ymplementaasjes moatte foarsichtich wêze om dizze invariant te hanthavenjen;ûnfeilige koade moat der lykwols net op fertrouwe om feiligens foar ûnthâld te garandearjen.
///
/// In foarbyld is in generike struktuer dy't in funksjewizer hat.Yn dit gefal kin de ymplemintaasje fan `Clone` net `derive`d wurde, mar kin wurde ymplementeare as:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Oanfoljende implementeurs
///
/// Neist de [implementors listed below][impls] ymplementearje de folgjende soarten ek `Clone`:
///
/// * Funksje-artikeltypen (dus de ûnderskate typen definieare foar elke funksje)
/// * Funksje oanwizer typen (bgl. `fn() -> i32`)
/// * Arraytypes, foar alle maten, as it artikeltype ek `Clone` ymplementeart (bgl. `[i32; 123456]`)
/// * Tupeltypen, as elke komponint ek `Clone` ymplementeart (bgl. `()`, `(i32, bool)`)
/// * Ofslutingstypes, as se gjin wearde fange út 'e omjouwing of as al sokke opnommen wearden `Clone` sels ymplementearje.
///   Tink derom dat fariabelen opnommen troch dielde referinsje altyd `Clone` ymplementearje (sels as de referent net), wylst fariabelen dy't wurde fêstlein troch mutabele referinsje `Clone` nea ymplementearje.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Jout in kopy fan 'e wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ympleminteart Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Fiert kopieartaken út `source`.
    ///
    /// `a.clone_from(&b)` is lykweardich oan `a = b.clone()` yn funksjonaliteit, mar kin oerskreaun wurde om de boarnen fan `a` opnij te brûken om ûnnedige allocaasjes te foarkommen.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): dizze structs wurde allinich brûkt troch#[ûntliene] om te bewearjen dat elke komponint fan in type Clone of Copy ymplementeart.
//
//
// Dizze structs moatte nea ferskine yn brûkerskoade.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ymplemintaasjes fan `Clone` foar primitive typen.
///
/// Ymplemintaasjes dy't net kinne wurde beskreaun yn Rust wurde ymplementeare yn `traits::SelectionContext::copy_clone_conditions()` yn `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Diele referinsjes kinne wurde kloneare, mar feroarbere referinsjes *kinne net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Diele referinsjes kinne wurde kloneare, mar feroarbere referinsjes *kinne net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}