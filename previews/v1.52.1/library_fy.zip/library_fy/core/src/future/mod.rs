#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchrone wearden.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Dit type is nedich om't:
///
/// a) Generators kinne `for<'a, 'b> Generator<&'a mut Context<'b>>` net ymplementearje, dat wy moatte in rauwe oanwizer trochjaan (sjoch <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw pointers en `NonNull` binne net `Send` of `Sync`, dus dat soe elke future non-Send/Sync ek meitsje, en wy wolle dat net.
///
/// It ferienfâldiget ek de HIR-ferleging fan `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Wrap in generator yn in future.
///
/// Dizze funksje jout in `GenFuture` derûnder werom, mar ferberget dizze yn `impl Trait` om bettere flaterberjochten te jaan (`impl Future` ynstee fan `GenFuture<[closure.....]>`).
///
// Dit is `const` om ekstra flaters te foarkommen neidat wy binne hersteld fan `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Wy fertrouwe op it feit dat async/await futures ûnbeweechlik binne om selsferwizende lieningen te meitsjen yn 'e ûnderlizzende generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // VEILIGHEID: Feilich om't wy !Unpin + !Drop binne, en dit is gewoan in fjildprojeksje.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ferfetsje de generator, feroarje de `&mut Context` yn in `NonNull` rauwe oanwizer.
            // De `.await` ferleegjen sil dat feilich werjaan nei in `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // VEILIGHEID: de beller moat garandearje dat `cx.0` in jildige oanwizer is
    // dat foldocht oan alle easken foar in feroarbere referinsje.
    unsafe { &mut *cx.0.as_ptr().cast() }
}