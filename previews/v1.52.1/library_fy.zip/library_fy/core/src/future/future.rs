#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// In future fertsjintwurdiget in asynchrone berekkening.
///
/// In future is in wearde dy't miskien noch net klear is mei berekkenjen.
/// Dit soarte "asynchronous value" makket it mooglik foar in tried om nuttich wurk te dwaan, wylst it wachtet op 'e wearde om beskikber te wurden.
///
///
/// # De `poll`-metoade
///
/// De kearnmetoade fan future, `poll`,*besiket* de future op te lossen yn in definitive wearde.
/// Dizze metoade blokkeart net as de wearde net klear is.
/// Ynstee dêrfan is de hjoeddeiske taak pland om wekker te wurden as it mooglik is om fierdere foarútgong te meitsjen troch 'opnij' te pollen.
/// De `context` oerdroegen oan 'e `poll`-metoade kin in [`Waker`] leverje, wat in hantel is foar it wekker fan' e hjoeddeistige taak.
///
/// As jo in future brûke, skilje jo `poll` yn it algemien net direkt, mar ynstee `.await` de wearde.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// It type wearde produsearre by foltôging.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Besykje de future op te lossen nei in definitive wearde, registrearje de hjoeddeistige taak foar wakeup as de wearde noch net beskikber is.
    ///
    /// # Weromwearde
    ///
    /// Dizze funksje jout:
    ///
    /// - [`Poll::Pending`] as de future noch net klear is
    /// - [`Poll::Ready(val)`] mei it resultaat `val` fan dizze future as it mei súkses einige.
    ///
    /// Ienris in future is klear, moatte kliïnten it net `poll` opnij.
    ///
    /// As in future noch net klear is, retourneert `poll` `Poll::Pending` en bewarret in kloon fan 'e [`Waker`] dy't is kopieare fan' e hjoeddeistige [`Context`].
    /// Dizze [`Waker`] wurdt dan wekker as de future foarútgong kin meitsje.
    /// Bygelyks, in future wachtsjend op in socket om lêsber te wurden soe `.clone()` op 'e [`Waker`] skilje en opslaan.
    /// As in sinjaal earne oars oankomt dat oanjout dat de socket lêsber is, wurdt [`Waker::wake`] neamd en wurdt de taak fan future wekker.
    /// As ienris in taak wekker is, moat it besykje de future opnij `poll` te meitsjen, wat al dan net in definitive wearde kin produsearje.
    ///
    /// Tink derom dat by meardere petearen nei `poll` allinich de [`Waker`] fan 'e [`Context`] trochjûn nei de lêste oprop moat wurde pland om in wake-up te ûntfangen.
    ///
    /// # Runtime-skaaimerken
    ///
    /// Futures allinich binne *inert*;se moatte *aktyf*'polled' wurde om foarútgong te meitsjen, wat betsjut dat elke kear as de hjoeddeiske taak wekker wurdt, it aktyf opnij moat 'pollen' yn ôfwachting fan futures wêr't it noch belang by hat.
    ///
    /// De funksje `poll` wurdt net werhelle yn in strakke loop neamd-yn plak dêrfan soe it allinich moatte wurde neamd as de future oanjout dat it ree is om foarútgong te meitsjen (troch `wake()`) te skiljen.
    /// As jo fertroud binne mei de `poll(2)`-of `select(2)`-syscalls op Unix, is it de muoite wurdich op te merken dat futures typysk *net* deselde problemen hawwe fan "all wakeups must poll all events";se binne mear as `epoll(4)`.
    ///
    /// In ymplemintaasje fan `poll` moat stribje om fluch werom te kommen, en moat net blokkearje.Fluch weromkomme foarkomt ûnnedich ferstopjen fan triedden as barrens.
    /// As fan tefoaren bekend is dat in oprop nei `poll` in eintsje duorje kin, moat it wurk wurde ôfladen nei in threadpool (of sokssawat) om te soargjen dat `poll` fluch werom kin.
    ///
    /// # Panics
    ///
    /// As in future ienris is foltôge (`Ready` weromkomt fan `poll`), kin de oprop fan syn `poll`-metoade opnij panic, foar ivich blokkearje, of oare soarten problemen feroarsaakje;de `Future` trait stelt gjin easken foar de effekten fan sa'n oprop.
    /// Om't de `poll`-metoade lykwols net `unsafe` is markearre, jilde de normale regels fan Rust: oproppen moatte nea net definieare gedrach feroarsaakje (geheugenkorrupsje, ferkeard gebrûk fan `unsafe`-funksjes, of sokssawat), ûnôfhinklik fan 'e steat fan future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}