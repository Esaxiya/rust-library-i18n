//! Primitive traits en typen dy't basiseigenskippen fan soarten fertsjintwurdigje.
//!
//! Rust-typen kinne wurde klassifisearre op ferskate nuttige manieren neffens har yntrinsike eigenskippen.
//! Dizze klassifikaasjes wurde fertsjintwurdige as traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Soarten dy't kinne wurde oerbrocht oer triedgrinzen.
///
/// Dizze trait wurdt automatysk ymplementeare as de gearstaller bepaalt dat it passend is.
///
/// In foarbyld fan in net-type 'Stjoere' is de referinsjetellingwizer [`rc::Rc`][`Rc`].
/// As twa triedden besykje [[Rc`] te klonearjen dy't op deselde referinsjetelde wearde wize, dan kinne se besykje de referinsjetelling tagelyk te aktualisearjen, dat is [undefined behavior][ub] om't [`Rc`] gjin atoombedriuwen brûkt.
///
/// Syn neef [`sync::Arc`][arc] brûkt atomyske operaasjes (wat oerhearsket) en is dus `Send`.
///
/// Sjoch [the Nomicon](../../nomicon/send-and-sync.html) foar mear details.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Soarten mei in konstante grutte dy't bekend is by kompileartiid.
///
/// Alle type parameters hawwe in ymplisite bân fan `Sized`.De spesjale syntaksis `?Sized` kin brûkt wurde om dizze binde te ferwiderjen as it net passend is.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//flater: Grutte wurdt net ymplementearre foar [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// De iene útsûndering is it ymplisite `Self`-type fan in trait.
/// In trait hat gjin ymplisite `Sized` bûn, om't dit net kompatibel is mei [trait-objekt], wêr't de trait per definysje wurkje moat mei alle mooglike ymplemintearders, en dus elke grutte kin wêze.
///
///
/// Hoewol Rust jo `Sized` oan in trait bine lit, kinne jo it letter net brûke om in trait-objekt te foarmjen:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // lit y: &dyn Bar= &Impl;//flater: de trait `Bar` kin net wurde makke yn in objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // foar Standert, bygelyks, wat fereasket dat `[T]: !Default` evaluearber is
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Soarten dy't "unsized" kinne wêze foar in type fan dynamysk grutte.
///
/// Bygelyks, it grutte arraytype `[i8; 2]` ymplementeart `Unsize<[i8]>` en `Unsize<dyn fmt::Debug>`.
///
/// Alle ymplementaasjes fan `Unsize` wurde automatysk levere troch de gearstaller.
///
/// `Unsize` wurdt ymplementearre foar:
///
/// - `[T; N]` is `Unsize<[T]>`
/// - `T` is `Unsize<dyn Trait>` as `T: Trait`
/// - `Foo<..., T, ...>` is `Unsize<Foo<..., U, ...>>` as:
///   - `T: Unsize<U>`
///   - Foo is in struktuer
///   - Allinich it lêste fjild fan `Foo` hat in type mei `T`
///   - `T` makket gjin diel út fan it type fan oare fjilden
///   - `Bar<T>: Unsize<Bar<U>>`, as it lêste fjild fan `Foo` type `Bar<T>` hat
///
/// `Unsize` wurdt tegearre mei [`ops::CoerceUnsized`] brûkt om "user-defined"-konteners lykas [`Rc`] dynamyske grutte typen te befetsjen.
/// Sjoch de [DST coercion RFC][RFC982] en [the nomicon entry on coercion][nomicon-coerce] foar mear details.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ferplichte trait foar konstanten brûkt yn patroanwedstriden.
///
/// Elk type dat `PartialEq` ûntlient, implementeart dizze trait automatysk,*nettsjinsteande* oft de type-parameters `Eq` ymplementearje.
///
/// As in `const`-artikel wat type befettet dat dizze trait net ymplementeart, ymplementeart dat type (1.) `PartialEq` net (wat betsjut dat de konstante de fergelikingsmetoade net sil leverje, hokker kodegeneraasje oannimt dat beskikber is), of (2.) ymplementeart it *syn eigen* ferzje fan `PartialEq` (dy't wy oannimme net oerienkomt mei in ferliking struktureel-gelikens).
///
///
/// Yn ien fan 'e twa hjirboppe senario's wegerje wy gebrûk fan sa'n konstant yn in patroanwedstryd.
///
/// Sjoch ek de [structural match RFC][RFC1445] en [issue 63438] dy't motiveare om te migrearjen fan attribútbasearre ûntwerp nei dizze trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ferplichte trait foar konstanten brûkt yn patroanwedstriden.
///
/// Elk type dat `Eq` ûntlient, ymplementeart dizze trait automatysk, * ûnôfhinklik of de type-parameters `Eq` ymplementearje.
///
/// Dit is in hack om in beheining yn ús type systeem te wurkjen.
///
/// # Background
///
/// Wy wolle easkje dat soarten consts dy't brûkt wurde yn patroanwedstriden it attribút `#[derive(PartialEq, Eq)]` hawwe.
///
/// Yn in mear ideale wrâld kinne wy dizze eask kontrolearje troch gewoan te kontrolearjen dat it opjûne type sawol de `StructuralPartialEq` trait *as* de `Eq` trait ymplementeart.
/// Jo kinne lykwols ADT's hawwe dy't *`derive(PartialEq, Eq)`* dogge, en in saak wêze dat wy wolle dat de kompilearder aksepteart, en dochs fielt it type fan 'e konstante `Eq` net.
///
/// In saak as dizze:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (It probleem yn 'e boppesteande koade is dat `Wrap<fn(&())>` gjin `PartialEq`, noch `Eq` ymplementeart, om't `foar <' a> fn(&'a _)` does not implement those traits.)
///
/// Dêrom kinne wy net fertrouwe op naïve kontrôle foar `StructuralPartialEq` en gewoan `Eq`.
///
/// As hack om dit om te wurkjen, brûke wy twa aparte traits ynjekteare troch elk fan 'e twa ôfliedingen (`#[derive(PartialEq)]` en `#[derive(Eq)]`) en kontrolearje dat beide oanwêzich binne as ûnderdiel fan kontrôle fan struktureel-match.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Soarten wêrfan de wearden gewoan duplisearje kinne troch bits te kopiearjen.
///
/// Standert hawwe fariabele biningen 'semantyk ferpleatse'.Mei oare wurden:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` is ferpleatst nei `y`, en kin dus net brûkt wurde
///
/// // println! ("{: ?}", x);//flater: gebrûk fan ferpleatste wearde
/// ```
///
/// As in type lykwols `Copy` ymplementeart, hat it ynstee 'semantyk kopiearje':
///
/// ```
/// // Wy kinne in `Copy`-ymplemintaasje ôfliede.
/// // `Clone` is ek ferplicht, om't it in supertrait is fan `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` is in kopy fan `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// It is wichtich om te notearjen dat yn dizze twa foarbylden it iennichste ferskil is oft jo tagong hawwe ta `x` nei de opdracht.
/// Under de motorkap kinne sawol in kopy as in beweging resultearje yn dat bits wurde kopieare yn it ûnthâld, hoewol dit soms fuort is optimalisearre.
///
/// ## Hoe kin ik `Copy` útfiere?
///
/// D'r binne twa manieren om `Copy` út te fieren op jo type.It ienfâldichste is `derive` te brûken:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Jo kinne ek `Copy` en `Clone` mei de hân ymplementearje:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// D'r is in lyts ferskil tusken de twa: de `derive`-strategy sil ek in `Copy` pleatse op type-parameters, wat net altyd winske is.
///
/// ## Wat is it ferskil tusken `Copy` en `Clone`?
///
/// Kopyen barre ymplisyt, bygelyks as ûnderdiel fan in opdracht `y = x`.It gedrach fan `Copy` is net te laden;it is altyd in ienfâldige bitwize kopy.
///
/// Kloning is in eksplisite aksje, `x.clone()`.De ymplemintaasje fan [`Clone`] kin elk type-spesifyk gedrach leverje dat nedich is om wearden feilich te duplisearjen.
/// Bygelyks, de ymplemintaasje fan [`Clone`] foar [`String`] moat de oanwiisde tekenrige buffer kopiearje yn 'e heap.
/// In ienfâldige bitwize kopy fan [`String`]-wearden soe de oanwizer allinich kopiearje, wat liedt ta in dûbele frije line.
/// Om dizze reden is [`String`] [`Clone`], mar net `Copy`.
///
/// [`Clone`] is in supertrait fan `Copy`, dus alles wat `Copy` is, moat [`Clone`] ek ymplementearje.
/// As in type `Copy` is, hoecht de [`Clone`]-ymplemintaasje allinich `*self` werom te jaan (sjoch it boppesteande foarbyld).
///
/// ## Wannear kin myn type `Copy` wêze?
///
/// In type kin `Copy` ymplementearje as al syn ûnderdielen `Copy` ymplementearje.Dizze struktuer kin bygelyks `Copy` wêze:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// In struktuer kin `Copy` wêze, en [`i32`] is `Copy`, dêrom komt `Point` yn oanmerking foar `Copy`.
/// Kontrast, beskôgje
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// De struktuer `PointList` kin `Copy` net ymplementearje, om't [`Vec<T>`] gjin `Copy` is.As wy besykje in `Copy`-ymplemintaasje te ûntfangen, krije wy in flater:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Dielde referinsjes (`&T`) binne ek `Copy`, dus in type kin `Copy` wêze, sels as it dielde referinsjes hat fan typen `T` dy't *net*`Copy` binne.
/// Tink oan de folgjende struktuer, dy't `Copy` kin ymplementearje, om't it allinich in *dielde referinsje* hat fan ús net-'Kopie 'type `PointList` fan boppen:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Wannear * kin myn type net `Copy` wêze?
///
/// Guon soarten kinne net feilich wurde kopieare.Bygelyks it kopiearjen fan `&mut T` soe in alias feroare referinsje oanmeitsje.
/// [`String`] kopiearje soe de ferantwurdlikens duplisearje foar it behearen fan de buffer fan 'e [' String '], wat liedt ta in dûbele fergees.
///
/// Generalisearjen fan it lêste gefal kin elk type dat [`Drop`] ymplementeart net `Copy` wêze, om't it wat boarne beheart neist syn eigen [`size_of::<T>`]-bytes.
///
/// As jo besykje `Copy` te ymplementearjen op in struct of enum mei gegevens dy't net 'Kopie' befetsje, krije jo de flater [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Wannear *moat* myn type `Copy` wêze?
///
/// Oer it algemien, as jo type _can_ `Copy` ymplementeart, dan moat it.
/// Hâld lykwols yn gedachten dat it ymplementearjen fan `Copy` diel is fan 'e publike API fan jo type.
/// As it type miskien net 'Kopie' wurdt yn 'e future, kin it ferstannich wêze om de `Copy`-ymplemintaasje no fuort te litten, om in brekende API-feroaring te foarkommen.
///
/// ## Oanfoljende implementeurs
///
/// Neist de [implementors listed below][impls] ymplementearje de folgjende soarten ek `Copy`:
///
/// * Funksje-artikeltypen (dus de ûnderskate typen definieare foar elke funksje)
/// * Funksje oanwizer typen (bgl. `fn() -> i32`)
/// * Arraytypes, foar alle maten, as it artikeltype ek `Copy` ymplementeart (bgl. `[i32; 123456]`)
/// * Tupeltypen, as elke komponint ek `Copy` ymplementeart (bgl. `()`, `(i32, bool)`)
/// * Ofslutingstypes, as se gjin wearde fange út 'e omjouwing of as al sokke opnommen wearden `Copy` sels ymplementearje.
///   Tink derom dat fariabelen opnommen troch dielde referinsje altyd `Copy` ymplementearje (sels as de referent net), wylst fariabelen dy't wurde fêstlein troch mutabele referinsje `Copy` nea ymplementearje.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hjirmei kinne jo in type kopiearje dat `Copy` net ymplementeart fanwegen ûnfoldwaande libbensgrinzen (kopiearje `A<'_>` as allinich `A<'static>: Copy` en `A<'_>: Clone`).
// Wy hawwe dit attribút hjir no allinich om't d'r in heule pear besteande spesjalisaasjes binne op `Copy` dy't al besteane yn 'e standertbibleteek, en d'r is gjin manier om dit gedrach no feilich te hawwen.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Soarten wêrfoar it feilich is om referinsjes te dielen tusken triedden.
///
/// Dizze trait wurdt automatysk ymplementeare as de gearstaller bepaalt dat it passend is.
///
/// De krekte definysje is: in type `T` is [`Sync`] as en allinich as `&T` [`Send`] is.
/// Mei oare wurden, as d'r gjin mooglikheid is fan [undefined behavior][ub] (ynklusyf gegevensraces) as `&T`-referinsjes trochjûn wurde tusken threads.
///
/// Lykas men soe ferwachtsje, binne primitive typen lykas [`u8`] en [`f64`] allegear [`Sync`], en sa binne ek ienfâldige aggregattypen dy't se befetsje, lykas tuples, structs en enums.
/// Mear foarbylden fan basale [`Sync`]-typen omfetsje "immutable"-typen lykas `&T`, en dy mei ienfâldige erflike mutabiliteit, lykas [`Box<T>`][box], [`Vec<T>`][vec] en de measte oare samlingstypen.
///
/// (Generike parameters moatte [`Sync`] wêze foar't har kontener ['Sync'] is.)
///
/// In wat ferrassende konsekwinsje fan 'e definysje is dat `&mut T` `Sync` is (as `T` `Sync` is), hoewol it liket dat dat net-syngronisearre mutaasje kin leverje.
/// De trúk is dat in feroarbere referinsje efter in dielde referinsje (dat is `& &mut T`) allinnich-lêze wurdt, as soe it in `& &T` wêze.
/// Hjirtroch is d'r gjin risiko fan in gegevensras.
///
/// Soarten dy't net `Sync` binne, binne dyjingen dy't "interior mutability" hawwe yn in net-thread-feilige foarm, lykas [`Cell`][cell] en [`RefCell`][refcell].
/// Dizze soarten soargje foar mutaasje fan har ynhâld sels fia in ûnferoarlike, dielde referinsje.
/// Bygelyks nimt de `set`-metoade op [`Cell<T>`][cell] `&self`, sadat it allinich in dielde referinsje [`&Cell<T>`][cell] fereasket.
/// De metoade fiert gjin syngronisaasje út, dus [`Cell`][cell] kin net `Sync` wêze.
///
/// In oar foarbyld fan in net-type "Sync" is de referinsjetellingwizer [`Rc`][rc].
/// Mei it each op elke referinsje [`&Rc<T>`][rc], kinne jo in nije [`Rc<T>`][rc] klone, troch de referinsjetellingen op in net-atomyske manier te feroarjen.
///
/// Foar gefallen as men threadfeilige ynterieurmutabiliteit nedich is, leveret Rust [atomic data types], lykas eksplisite beskoatteljen fia [`sync::Mutex`][mutex] en [`sync::RwLock`][rwlock].
/// Dizze soarten soargje derfoar dat elke mutaasje gjin gegevensraces kin feroarsaakje, dêrom binne de typen `Sync`.
/// Likegoed biedt [`sync::Arc`][arc] in threadfeilige analooch fan [`Rc`][rc].
///
/// Elke typen mei ynterieurmutabiliteit moatte ek de [`cell::UnsafeCell`][unsafecell]-wrapper om de value(s) brûke, dy't kin wurde muteare fia in dielde referinsje.
/// Net slagget dit is [undefined behavior][ub].
/// Bygelyks, [`transmute`][transmute]-ing fan `&T` nei `&mut T` is unjildich.
///
/// Sjoch [the Nomicon][nomicon-send-and-sync] foar mear details oer `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ienris stipe om notysjes yn `rustc_on_unimplemented` ta te foegjen komt yn beta, en it is útwreide om te kontrolearjen oft in sluting oeral yn 'e easkketen is, wreidzje it as sadanich (#48534) út:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulgrutte type wurdt brûkt om dingen te markearjen dat "act like" se in `T` hawwe.
///
/// Tafoegjen fan in `PhantomData<T>`-fjild oan jo type fertelt de gearstaller dat jo type fungeart as soe it in wearde fan type `T` opslaan, hoewol it net echt is.
/// Dizze ynformaasje wurdt brûkt by it berekkenjen fan bepaalde feiligenseigenskippen.
///
/// Sjoch asjebleaft [the Nomicon](../../nomicon/phantom-data.html) foar in mear yngeande útlis oer hoe't jo `PhantomData<T>` brûke.
///
/// # In ferskriklike noat 👻👻👻
///
/// Hoewol se beide eng nammen hawwe, binne `PhantomData` en 'fantoomtypen' besibbe, mar net identyk.In parameter fan phantom-type is gewoan in type-parameter dy't noait wurdt brûkt.
/// Yn Rust feroarsaket dit faak dat de gearstaller klaget, en de oplossing is it tafoegjen fan in "dummy"-gebrûk fia `PhantomData`.
///
/// # Examples
///
/// ## Net brûkte libbensparameters
///
/// Faaks is it meast foarkommende gebrûk foar `PhantomData` in struktuer dy't in net brûkte libbensparameter hat, typysk as ûnderdiel fan guon ûnfeilige koade.
/// Hjir is bygelyks in struktuer `Slice` dy't twa oanwizings hat fan it type `*const T`, wierskynlik wiist yn in array earne:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// De bedoeling is dat de ûnderlizzende gegevens allinich jildich binne foar it libben `'a`, dus `Slice` moat `'a` net oerlibje.
/// Dizze bedoeling wurdt lykwols net útdrukt yn 'e koade, om't d'r gjin gebrûk is fan' e libbensdoer `'a` en dêrom is it net dúdlik op hokker gegevens it jildt.
/// Wy kinne dit ferbetterje troch de kompiler te fertellen te hanneljen *as soe* de `Slice`-struktuer in referinsje `&'a T` befette:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dit fereasket op syn beurt ek de oantekening `T: 'a`, wat oanjout dat alle referinsjes yn `T` jildich binne oer it libben `'a`.
///
/// By it inisjalisearjen fan in `Slice` leverje jo gewoan de wearde `PhantomData` op foar it fjild `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Net brûkte parameterparameters
///
/// It komt somtiden foar dat jo net brûkte type-parameters hawwe dy't oanjouwe hokker type gegevens in struct "tied" is, hoewol dizze gegevens eins net wurde fûn yn 'e struktuer sels.
/// Hjir is in foarbyld wêr't dit ûntstiet mei [FFI].
/// De bûtenlânske ynterface brûkt hânsels fan it type `*mut ()` om te ferwizen nei Rust-wearden fan ferskillende soarten.
/// Wy folgje it type Rust mei in parameter fan phantom type op 'e struct `ExternalResource` dy't in hantel wikkelt.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eigendom en de drop check
///
/// Tafoegjen fan in fjild fan type `PhantomData<T>` jout oan dat jo type gegevens hat fan type `T`.Dit betsjuttet op 'e beurt dat as jo type falt, kin it ien of mear gefallen fan it type `T` falle.
/// Dit hat ynfloed op 'e [drop check]-analyse fan' e Rust-kompilator.
///
/// As jo struct de gegevens fan type `T` eins net *besit*, is it better om in referinsjetype te brûken, lykas `PhantomData<&'a T>` (ideally) of `PhantomData<*const T>` (as gjin libbensdoer jildt), om eigendom net oan te jaan.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompiler-ynterne trait waard brûkt om it type enum-diskriminanten oan te jaan.
///
/// Dizze trait wurdt automatysk ymplementeare foar elk type en foeget gjin garânsjes ta oan [`mem::Discriminant`].
/// It is **undefined gedrach** om te transmutearjen tusken `DiscriminantKind::Discriminant` en `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// It type fan 'e diskriminant, dat moat foldwaan oan de trait bounds dy't ferplicht is troch `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-ynterne trait brûkt om te bepalen oft in type yntern `UnsafeCell` befettet, mar net fia in yndireksje.
///
/// Dit beynfloedet bygelyks as in `static` fan dat type wurdt pleatst yn allinich lêzen statysk ûnthâld as skriuwber statysk ûnthâld.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Soarten dy't nei ferpleatsing feilich kinne wurde ferpleatst.
///
/// Rust sels hat gjin begryp fan ûnbeweechbere soarten, en beskôget bewegingen (bgl. Fia opdracht as [`mem::replace`]) altyd feilich.
///
/// It [`Pin`][Pin]-type wurdt ynstee brûkt om bewegingen troch it typesysteem te foarkommen.Oanwizers `P<T>` ferpakt yn 'e [`Pin<P<T>>`][Pin] wrapper kinne net út ferpleatst wurde.
/// Sjoch de [`pin` module]-dokumintaasje foar mear ynformaasje oer pinning.
///
/// It ymplementearjen fan 'e `Unpin` trait foar `T` tilt de beheiningen op fan it pinnen fan it type, wêrtroch `T` dan kin wurde ferpleatst út [`Pin<P<T>>`][Pin] mei funksjes lykas [`mem::replace`].
///
///
/// `Unpin` hat hielendal gjin konsekwinsje foar net-pinned gegevens.
/// Benammen ferpleatst [`mem::replace`] lokkich `!Unpin`-gegevens (it wurket foar elke `&mut T`, net allinich as `T: Unpin`).
/// Jo kinne [`mem::replace`] lykwols net brûke op gegevens ferpakt yn in [`Pin<P<T>>`][Pin] om't jo de `&mut T` dy't jo dêrfoar nedich binne net kinne krije, en *dat* is wat dit systeem wurket.
///
/// Dat dit kin bygelyks allinich dien wurde op typen dy't `Unpin` ymplementearje:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Wy hawwe in feroarbere referinsje nedich om `mem::replace` te neamen.
/// // Wy kinne sa'n referinsje krije troch (implicitly) op `Pin::deref_mut` oan te roppen, mar dat is allinich mooglik om't `String` `Unpin` ymplementeart.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Dizze trait wurdt automatysk ymplementearre foar hast elk type.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// In merktype dat `Unpin` net ymplementeart.
///
/// As in type in `PhantomPinned` befettet, sil it `Unpin` standert net ymplementearje.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ymplemintaasjes fan `Copy` foar primitive typen.
///
/// Ymplemintaasjes dy't net kinne wurde beskreaun yn Rust wurde ymplementeare yn `traits::SelectionContext::copy_clone_conditions()` yn `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Diele referinsjes kinne wurde kopieare, mar feroarbere referinsjes *kinne net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}