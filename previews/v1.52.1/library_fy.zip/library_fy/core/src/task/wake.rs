#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// In `RawWaker` lit de ymplemintator fan in taakútfierder in [`Waker`] meitsje dy't oanpast wekkergedrach leveret.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// It bestiet út in gegevenspointer en in [virtual function pointer table (vtable)][vtable] dy't it gedrach fan 'e `RawWaker` oanpast.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// In gegevenspointer, dy't kin wurde brûkt om willekeurige gegevens op te slaan lykas fereaske troch de útfierder.
    /// Dit kin bgl
    /// in type-wiske oanwizer nei in `Arc` dy't assosjeare is mei de taak.
    /// De wearde fan dit fjild wurdt trochjûn oan alle funksjes dy't diel útmeitsje fan 'e vtable as de earste parameter.
    ///
    data: *const (),
    /// Pointertabel foar firtuele funksjes dy't it gedrach fan dizze waker oanpast.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Makket in nije `RawWaker` oan fan 'e levere `data`-oanwizer en `vtable`.
    ///
    /// De `data`-oanwizer kin brûkt wurde om willekeurige gegevens op te slaan lykas ferplicht troch de útfierder.Dit kin bgl
    /// in type-wiske oanwizer nei in `Arc` dy't assosjeare is mei de taak.
    /// De wearde fan dizze oanwizer wurdt trochjûn oan alle funksjes dy't diel útmeitsje fan 'e `vtable` as earste parameter.
    ///
    /// De `vtable` past it gedrach fan in `Waker` oan dat wurdt oanmakke út in `RawWaker`.
    /// Foar elke operaasje op 'e `Waker` wurdt de byhearrende funksje yn' e `vtable` fan 'e ûnderlizzende `RawWaker` neamd.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// In firtuele funksje-oanwizer tafel (vtable) dy't it gedrach fan in [`RawWaker`] oantsjutte.
///
/// De oanwizer dy't trochjûn wurdt oan alle funksjes yn 'e vtable is de `data`-oanwizer fan it omslutende [`RawWaker`]-objekt.
///
/// De funksjes yn dizze struktuer binne allinich bedoeld om te wurde neamd op 'e `data`-oanwizer fan in goed konstruearre [`RawWaker`]-objekt fanút de [`RawWaker`]-ymplemintaasje.
/// Ien fan 'e befette funksjes skilje mei in oare `data`-oanwizer sil undefined gedrach feroarsaakje.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Dizze funksje wurdt neamd as de [`RawWaker`] wurdt klone, bgl as de [`Waker`] wêryn de [`RawWaker`] wurdt opslein wurdt kloneare.
    ///
    /// De ymplemintaasje fan dizze funksje moat alle boarnen behâlde dy't nedich binne foar dit ekstra eksimplaar fan in [`RawWaker`] en byhearrende taak.
    /// `wake` skilje op de resultearjende [`RawWaker`] moat resultearje yn in wekker fan deselde taak dy't wekker wêze soe troch de orizjinele [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Dizze funksje wurdt neamd as `wake` wurdt neamd op 'e [`Waker`].
    /// It moat de taak wekker meitsje dy't ferbûn is mei dizze [`RawWaker`].
    ///
    /// De ymplemintaasje fan dizze funksje moat derfoar soargje dat alle boarnen frijkomme dy't assosjeare binne mei dit eksimplaar fan in [`RawWaker`] en byhearrende taak.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Dizze funksje wurdt neamd as `wake_by_ref` wurdt neamd op 'e [`Waker`].
    /// It moat de taak wekker meitsje dy't ferbûn is mei dizze [`RawWaker`].
    ///
    /// Dizze funksje liket op `wake`, mar moat de opjûne gegevenswizer net ferbrûke.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Dizze funksje wurdt neamd as in [`RawWaker`] falt.
    ///
    /// De ymplemintaasje fan dizze funksje moat derfoar soargje dat alle boarnen frijkomme dy't assosjeare binne mei dit eksimplaar fan in [`RawWaker`] en byhearrende taak.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Makket in nije `RawWakerVTable` oan fan 'e levere `clone`-, `wake`-, `wake_by_ref`-en `drop`-funksjes.
    ///
    /// # `clone`
    ///
    /// Dizze funksje wurdt neamd as de [`RawWaker`] wurdt klone, bgl as de [`Waker`] wêryn de [`RawWaker`] wurdt opslein wurdt kloneare.
    ///
    /// De ymplemintaasje fan dizze funksje moat alle boarnen behâlde dy't nedich binne foar dit ekstra eksimplaar fan in [`RawWaker`] en byhearrende taak.
    /// `wake` skilje op de resultearjende [`RawWaker`] moat resultearje yn in wekker fan deselde taak dy't wekker wêze soe troch de orizjinele [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Dizze funksje wurdt neamd as `wake` wurdt neamd op 'e [`Waker`].
    /// It moat de taak wekker meitsje dy't ferbûn is mei dizze [`RawWaker`].
    ///
    /// De ymplemintaasje fan dizze funksje moat derfoar soargje dat alle boarnen frijkomme dy't assosjeare binne mei dit eksimplaar fan in [`RawWaker`] en byhearrende taak.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Dizze funksje wurdt neamd as `wake_by_ref` wurdt neamd op 'e [`Waker`].
    /// It moat de taak wekker meitsje dy't ferbûn is mei dizze [`RawWaker`].
    ///
    /// Dizze funksje liket op `wake`, mar moat de opjûne gegevenswizer net ferbrûke.
    ///
    /// # `drop`
    ///
    /// Dizze funksje wurdt neamd as in [`RawWaker`] falt.
    ///
    /// De ymplemintaasje fan dizze funksje moat derfoar soargje dat alle boarnen frijkomme dy't assosjeare binne mei dit eksimplaar fan in [`RawWaker`] en byhearrende taak.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// De `Context` fan in asynchrone taak.
///
/// Op it stuit tsjinnet `Context` allinich om tagong te bieden ta in `&Waker` dy't kin wurde brûkt om de hjoeddeistige taak wekker te meitsjen.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Soargje derfoar dat wy future-proof binne tsjin feroaringen yn fariânsje troch it libben te twingen invariant te wêzen (libbensdagen foar argumintposysje binne kontravariant, wylst libbensdagen foar weromposysje kovariant binne).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Meitsje in nije `Context` fanút in `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Jout in ferwizing nei de `Waker` foar de hjoeddeistige taak.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// In `Waker` is in hantlieding foar it wekker fan in taak troch har eksekuteur te melden dat it ree is om te rinnen.
///
/// Dit hannel omfettet in [`RawWaker`]-eksimplaar, dat it eksekuteur-spesifike wekkergedrach definieart.
///
///
/// Ymplementeart [`Clone`], [`Send`] en [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Wekker de taak wekker wurde ferbûn mei dizze `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // De eigentlike wakeup-oprop wurdt delegearre fia in firtuele funksje-oprop nei de ymplemintaasje dy't wurdt definieare troch de útfierder.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Net `drop` skilje-de wekker wurdt konsumeare troch `wake`.
        crate::mem::forget(self);

        // VEILIGHEID: Dit is feilich, om't `Waker::from_raw` de ienige manier is
        // om `wake` en `data` te inisjalisearjen wêrtroch de brûker moat erkenne dat it kontrakt fan `RawWaker` wurdt hanthavene.
        //
        unsafe { (wake)(data) };
    }

    /// Wekker de taak wekker wurde ferbûn mei dizze `Waker` sûnder de `Waker` te konsumearjen.
    ///
    /// Dit is fergelykber mei `wake`, mar kin wat minder effisjint wêze yn it gefal wêr't in eigendom `Waker` beskikber is.
    /// Dizze metoade moat foarkar krije boppe `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // De eigentlike wakeup-oprop wurdt delegearre fia in firtuele funksje-oprop nei de ymplemintaasje dy't wurdt definieare troch de útfierder.
        //

        // VEILIGHEID: sjoch `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Jout `true` werom as dizze `Waker` en in oare `Waker` deselde taak hawwe wekker.
    ///
    /// Dizze funksje wurket op basis fan bêste ynspanning, en kin falsk weromkomme, sels as de 'Waker`s deselde taak wekker soene meitsje.
    /// As dizze funksje `true` lykwols weromkomt, is it garandearre dat de 'Waker`s deselde taak wekker meitsje.
    ///
    /// Dizze funksje wurdt foaral brûkt foar optimalisearingsdoelen.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Makket in nije `Waker` fan [`RawWaker`] oan.
    ///
    /// It gedrach fan 'e werom `Waker` is net definieare as de kontrakt definieare yn [' RawWaker ']' s en ['RawWakerVTable'] 's dokumintaasje net wurdt bewarre.
    ///
    /// Dêrom is dizze metoade ûnfeilich.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // VEILIGHEID: Dit is feilich, om't `Waker::from_raw` de ienige manier is
            // om `clone` en `data` te inisjalisearjen wêrtroch de brûker fereasket dat it kontrakt fan [`RawWaker`] wurdt hanthavene.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // VEILIGHEID: Dit is feilich, om't `Waker::from_raw` de ienige manier is
        // om `drop` en `data` te inisjalisearjen wêrtroch de brûker fereasket dat it kontrakt fan `RawWaker` wurdt hanthavene.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}