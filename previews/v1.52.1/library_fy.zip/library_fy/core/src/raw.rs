#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Befettet struktuer definysjes foar de opmaak fan ynboude typen fan kompilearder.
//!
//! Se kinne wurde brûkt as doelen fan transmutes yn ûnfeilige koade foar direkte manipulaasje fan de rauwe foarstellings.
//!
//!
//! Har definysje moat altyd oerienkomme mei de ABI definieare yn `rustc_middle::ty::layout`.
//!

/// De foarstelling fan in trait-objekt lykas `&dyn SomeTrait`.
///
/// Dizze struktuer hat deselde opmaak as soarten lykas `&dyn SomeTrait` en `Box<dyn AnotherTrait>`.
///
/// `TraitObject` is garandearre dat se mei layouts passe, mar it is net it type trait-objekten (bgl. de fjilden binne net direkt tagonklik op in `&dyn SomeTrait`), en it regeart ek net dat layout (feroaring fan 'e definysje feroaret de layout fan in `&dyn SomeTrait` net).
///
/// It is allinich ûntworpen om te brûken troch ûnfeilige koade dy't de details op leech nivo moatte manipulearje.
///
/// D'r is gjin manier om generyk te ferwizen nei alle trait-objekten, dus de iennige manier om wearden fan dit type te meitsjen is mei funksjes lykas [`std::mem::transmute`][transmute].
/// Lykwols is de ienige manier om in wier trait-objekt te meitsjen fan in `TraitObject`-wearde mei `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntetisearjen fan in trait-objekt mei net oerienkommende typen-ien wêr't de vtabel net oerienkomt mei it type fan 'e wearde wêrop de gegevenswizer wiist-liedt wierskynlik ta undefined gedrach.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // in foarbyld trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lit de gearstaller in trait-objekt meitsje
/// let object: &dyn Foo = &value;
///
/// // sjoch nei de rauwe fertsjintwurdiging
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // de gegevenswizer is it adres fan `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruearje in nij objekt, wizend nei in oare `i32`, wês foarsichtich de `i32` vtable fan `object` te brûken
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // it soe moatte wurkje krekt as hienen wy in trait-objekt direkt út `other_value` konstruearre
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}