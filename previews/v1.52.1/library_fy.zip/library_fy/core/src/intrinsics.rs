//! Kompilatorintrinsyk.
//!
//! De oerienkommende definysjes binne yn `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! De oerienkommende const-ymplementaasjes binne yn `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const yntrinsyk
//!
//! Note: alle feroarings oan 'e konstânsje fan yntrinsika moatte wurde besprutsen mei it taalteam.
//! Dit omfettet feroaringen yn 'e stabiliteit fan' e konstânsje.
//!
//! Om in yntrinsike brûkber te meitsjen by kompilaasjetiid, moat men de ymplemintaasje kopiearje fan <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> nei `compiler/rustc_mir/src/interpret/intrinsics.rs` en in `#[rustc_const_unstable(feature = "foo", issue = "01234")]` tafoegje oan it yntrinsike.
//!
//!
//! As in yntrinsike moat wurde brûkt fan in `const fn` mei in `rustc_const_stable`-attribút, moat it attribút fan it yntrinsike ek `rustc_const_stable` wêze.
//! Sa'n feroaring moat net wurde dien sûnder T-lang-oerlis, om't it in funksje bakt yn 'e taal dy't net kin wurde replikearre yn brûkerskoade sûnder kompilearstipe.
//!
//! # Volatiles
//!
//! De fluchtige yntrinsika leveret operaasjes dy't bedoeld binne om te hanneljen op I/O-ûnthâld, dy't garandearre binne net opnij oardere te wurden troch de kompilator oer oare flechtige yntrinsiken.Sjoch de LLVM-dokumintaasje op [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! De atoomyntrinsika leverje mienskiplike atoombedriuwen op masinewurden, mei meardere mooglike geheugenoarders.Se folgje deselde semantyk as C++ 11.Sjoch de LLVM-dokumintaasje op [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! In flugge ferfarsking by it bestellen fan ûnthâld:
//!
//! * Oernimme, in barriêre foar it krijen fan in slot.Folgjende lêzen en skriuwen fine plak nei de barriêre.
//! * Loslitte, in barriêre foar it frijjaan fan in slot.Foargeande lêzen en skriuwen fynt plak foar de barriêre.
//! * Opienfolgjende konsekwint, opienfolgjende konsistinte operaasjes wurde garandearre yn oarder te barren.Dit is de standert modus foar wurkjen mei atoomtypen en is lykweardich oan `volatile` fan Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Dizze ymporten wurde brûkt foar ferienfâldigjen fan intra-doc-keppelings
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // VEILIGHEID: sjoch `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, dizze intrinsics nimme rauwe oanwizings om't se alias ûnthâld mutearje, wat net jildich is foar `&` as `&mut`.
    //

    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::SeqCst`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::Acquire`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::Release`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::AcqRel`] troch te jaan as de `success` en [`Ordering::Acquire`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::Relaxed`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::SeqCst`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::SeqCst`] troch te jaan as de `success` en [`Ordering::Acquire`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::Acquire`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange`-metoade troch [`Ordering::AcqRel`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::SeqCst`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::Acquire`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::Release`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::AcqRel`] troch te jaan as de `success` en [`Ordering::Acquire`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::Relaxed`] troch te jaan as sawol de `success`-as `failure`-parameters.
    ///
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::SeqCst`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::SeqCst`] troch te jaan as de `success` en [`Ordering::Acquire`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::Acquire`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stelt in wearde op as de hjoeddeiske wearde itselde is as de `old`-wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `compare_exchange_weak`-metoade troch [`Ordering::AcqRel`] troch te jaan as de `success` en [`Ordering::Relaxed`] as de `failure`-parameters.
    /// Bygelyks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Laadt de hjoeddeiske wearde fan 'e oanwizer.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `load`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Laadt de hjoeddeiske wearde fan 'e oanwizer.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `load`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Laadt de hjoeddeiske wearde fan 'e oanwizer.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `load`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `store`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `store`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `store`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje, weromsette de âlde wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `swap`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje, weromsette de âlde wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `swap`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje, weromsette de âlde wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `swap`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje, weromsette de âlde wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `swap`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bewarret de wearde op 'e oantsjutte ûnthâldlokaasje, weromsette de âlde wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `swap`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Foeget ta oan de hjoeddeiske wearde, jout de foarige wearde werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_add`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Foeget ta oan de hjoeddeiske wearde, jout de foarige wearde werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_add`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Foeget ta oan de hjoeddeiske wearde, jout de foarige wearde werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_add`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Foeget ta oan de hjoeddeiske wearde, jout de foarige wearde werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_add`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Foeget ta oan de hjoeddeiske wearde, jout de foarige wearde werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_add`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lûke fan 'e hjoeddeistige wearde, werom de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_sub`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lûke fan 'e hjoeddeistige wearde, werom de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_sub`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lûke fan 'e hjoeddeistige wearde, werom de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_sub`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lûke fan 'e hjoeddeistige wearde, werom de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_sub`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lûke fan 'e hjoeddeistige wearde, werom de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_sub`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwize en mei de hjoeddeiske wearde, weromgean fan 'e foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_and`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize en mei de hjoeddeiske wearde, weromgean fan 'e foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_and`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize en mei de hjoeddeiske wearde, weromgean fan 'e foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_and`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize en mei de hjoeddeiske wearde, weromgean fan 'e foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_and`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize en mei de hjoeddeiske wearde, weromgean fan 'e foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_and`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwize nand mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op it [`AtomicBool`]-type fia de `fetch_nand`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize nand mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op it [`AtomicBool`]-type fia de `fetch_nand`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize nand mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op it [`AtomicBool`]-type fia de `fetch_nand`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize nand mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op it [`AtomicBool`]-type fia de `fetch_nand`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize nand mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op it [`AtomicBool`]-type fia de `fetch_nand`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwize of mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_or`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize of mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_or`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize of mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_or`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize of mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_or`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize of mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_or`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwize xor mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_xor`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize xor mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_xor`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize xor mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_xor`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize xor mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_xor`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwize xor mei de hjoeddeiske wearde, weromsette de foarige wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`]-soarten fia de `fetch_xor`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum mei de hjoeddeiske wearde mei in ûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in ûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in ûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op 'e [`atomic`] ûndertekene heulgetaaltypen fia de `fetch_max`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in ûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mei de hjoeddeistige wearde mei in ûndertekene fergeliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeistige wearde mei in ûndertekene fergeliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeistige wearde mei in ûndertekene fergeliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeistige wearde mei in ûndertekene fergeliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeistige wearde mei in ûndertekene fergeliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen op de [`atomic`] ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_min`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::SeqCst`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::Acquire`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::Release`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::AcqRel`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum mei de hjoeddeiske wearde mei in unûndertekene ferliking.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is beskikber op 'e [`atomic`] net-ûndertekene gehielstypen fia de `fetch_max`-metoade troch [`Ordering::Relaxed`] as `order` troch te jaan.
    /// Bygelyks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// De yntrinsike `prefetch` is in hint foar de kodegenerator om in prefetch-ynstruksje yn te foegjen as stipe;oars is it in no-op.
    /// Prefetches hawwe gjin effekt op it gedrach fan it programma, mar kinne de prestaasjeskenmerken derfan feroarje.
    ///
    /// It `locality`-argumint moat in konstant hiel getal wêze en is in tydlike lokaliteitsspesifikaasje, fariearjend fan (0), gjin lokaasje, oant (3), ekstreem lokaal yn cache bewarje.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// De yntrinsike `prefetch` is in hint foar de kodegenerator om in prefetch-ynstruksje yn te foegjen as stipe;oars is it in no-op.
    /// Prefetches hawwe gjin effekt op it gedrach fan it programma, mar kinne de prestaasjeskenmerken derfan feroarje.
    ///
    /// It `locality`-argumint moat in konstant hiel getal wêze en is in tydlike lokaliteitsspesifikaasje, fariearjend fan (0), gjin lokaasje, oant (3), ekstreem lokaal yn cache bewarje.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// De yntrinsike `prefetch` is in hint foar de kodegenerator om in prefetch-ynstruksje yn te foegjen as stipe;oars is it in no-op.
    /// Prefetches hawwe gjin effekt op it gedrach fan it programma, mar kinne de prestaasjeskenmerken derfan feroarje.
    ///
    /// It `locality`-argumint moat in konstant hiel getal wêze en is in tydlike lokaliteitsspesifikaasje, fariearjend fan (0), gjin lokaasje, oant (3), ekstreem lokaal yn cache bewarje.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// De yntrinsike `prefetch` is in hint foar de kodegenerator om in prefetch-ynstruksje yn te foegjen as stipe;oars is it in no-op.
    /// Prefetches hawwe gjin effekt op it gedrach fan it programma, mar kinne de prestaasjeskenmerken derfan feroarje.
    ///
    /// It `locality`-argumint moat in konstant hiel getal wêze en is in tydlike lokaliteitsspesifikaasje, fariearjend fan (0), gjin lokaasje, oant (3), ekstreem lokaal yn cache bewarje.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// In atoomomheining.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::fence`] troch [`Ordering::SeqCst`] troch te jaan as de `order`.
    ///
    ///
    pub fn atomic_fence();
    /// In atoomomheining.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::fence`] troch [`Ordering::Acquire`] troch te jaan as de `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// In atoomomheining.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::fence`] troch [`Ordering::Release`] troch te jaan as de `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// In atoomomheining.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::fence`] troch [`Ordering::AcqRel`] troch te jaan as de `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// In ûnthâld-barriêre allinich foar kompiler.
    ///
    /// Tagonklik tagongsrjochten sille nea wurde oardere oer dizze barriêre troch de kompilearder, mar d'r sille gjin ynstruksjes foar útstjoerd wurde.
    /// Dit is passend foar operaasjes op deselde thread dy't foarkommen wurde kinne, lykas by ynteraksje mei sinjaalhannelers.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::compiler_fence`] troch [`Ordering::SeqCst`] troch te jaan as de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// In ûnthâld-barriêre allinich foar kompiler.
    ///
    /// Tagonklik tagongsrjochten sille nea wurde oardere oer dizze barriêre troch de kompilearder, mar d'r sille gjin ynstruksjes foar útstjoerd wurde.
    /// Dit is passend foar operaasjes op deselde thread dy't foarkommen wurde kinne, lykas by ynteraksje mei sinjaalhannelers.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::compiler_fence`] troch [`Ordering::Acquire`] troch te jaan as de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// In ûnthâld-barriêre allinich foar kompiler.
    ///
    /// Tagonklik tagongsrjochten sille nea wurde oardere oer dizze barriêre troch de kompilearder, mar d'r sille gjin ynstruksjes foar útstjoerd wurde.
    /// Dit is passend foar operaasjes op deselde thread dy't foarkommen wurde kinne, lykas by ynteraksje mei sinjaalhannelers.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::compiler_fence`] troch [`Ordering::Release`] troch te jaan as de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// In ûnthâld-barriêre allinich foar kompiler.
    ///
    /// Tagonklik tagongsrjochten sille nea wurde oardere oer dizze barriêre troch de kompilearder, mar d'r sille gjin ynstruksjes foar útstjoerd wurde.
    /// Dit is passend foar operaasjes op deselde thread dy't foarkommen wurde kinne, lykas by ynteraksje mei sinjaalhannelers.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is te krijen yn [`atomic::compiler_fence`] troch [`Ordering::AcqRel`] troch te jaan as de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magysk yntrinsyk dat syn betsjutting ûntlient oan attributen dy't oan 'e funksje binne.
    ///
    /// Dataflow brûkt bygelyks dit om statyske bewearingen te ynjeksje, sadat `rustc_peek(potentially_uninitialized)` eins kontrolearje soe dat datafloed yndie berekkene dat it op dat punt yn 'e kontrôlefloed uninitialisearre is.
    ///
    ///
    /// Dizze yntrinsike moat net brûkt wurde bûten de kompilearder.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Stort de útfiering fan it proses ôf.
    ///
    /// In mear brûkerfreonlike en stabile ferzje fan dizze operaasje is [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ynformeart de optimizer dat dit punt yn 'e koade net te berikken is, wêrtroch fierdere optimisaasjes mooglik binne.
    ///
    /// NB, dit is heul oars as de `unreachable!()`-makro: Oars as de makro, dy't panics as dizze wurdt útfierd, is it *undefined gedrach* om koade te berikken markearre mei dizze funksje.
    ///
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ynformeart de optimizer dat in betingst altyd wier is.
    /// As de tastân falsk is, is it gedrach net definieare.
    ///
    /// D'r wurdt gjin koade generearre foar dizze yntrinsike, mar de optimizer sil besykje (en har tastân) te bewarjen tusken passen, wat kin ynterferearje mei optimisaasje fan omlizzende koade en de prestaasjes ferminderje.
    /// It moat net brûkt wurde as de invariant allinich troch de optimizer kin wurde ûntdutsen, of as it gjin wichtige optimisaasjes ynskeakelt.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tips foar de gearstaller dat de betingst fan branch wierskynlik wier is.
    /// Jout de wearde dy't dêrop is trochjûn.
    ///
    /// Elk gebrûk oars dan mei `if`-útspraken sil wierskynlik gjin effekt hawwe.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tips foar de gearstaller dat de betingst fan branch wierskynlik falsk is.
    /// Jout de wearde dy't dêrop is trochjûn.
    ///
    /// Elk gebrûk oars dan mei `if`-útspraken sil wierskynlik gjin effekt hawwe.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Fiert in brekpuntfal út, foar ynspeksje troch in debugger.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn breakpoint();

    /// De grutte fan in type yn bytes.
    ///
    /// Mear spesifyk is dit de kompensaasje yn bytes tusken opienfolgjende items fan itselde type, ynklusyf alignment padding.
    ///
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// De minimale ôfstimming fan in type.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// De foarkar oanpassing fan in type.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// De grutte fan de referearre wearde yn bytes.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// De fereaske ôfstimming fan de referearre wearde.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Krijt in styske tekenrige mei de namme fan in type.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Krijt in identifier dy't wrâldwiid unyk is foar it oantsjutte type.
    /// Dizze funksje sil deselde wearde weromjaan foar in type, ûnôfhinklik fan hokker crate it wurdt oproppen.
    ///
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// In wacht foar ûnfeilige funksjes dy't net ea kinne wurde útfierd as `T` ûnbewenne is:
    /// Dit sil statysk of panic, of neat dwaan.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// In wacht foar ûnfeilige funksjes dy't noait kinne wurde útfierd as `T` gjin nul-inisjalisaasje tastiet: Dit sil statysk of panic, of neat dwaan.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn assert_zero_valid<T>();

    /// In wacht foar ûnfeilige funksjes dy't noait kinne wurde útfierd as `T` ûnjildige bitpatroanen hat: Dit sil statysk of panic, of neat dwaan.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn assert_uninit_valid<T>();

    /// Krijt in ferwizing nei in statyske `Location` dy't oanjout wêr't it waard neamd.
    ///
    /// Betink ynstee [`core::panic::Location::caller`](crate::panic::Location::caller) te brûken.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Ferpleatst in wearde bûten it berik sûnder driplijm te rinnen.
    ///
    /// Dit bestiet allinich foar [`mem::forget_unsized`];normale `forget` brûkt `ManuallyDrop` ynstee.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Ynterinterpreteert de bits fan in wearde fan ien type as in oar type.
    ///
    /// Beide soarten moatte deselde grutte hawwe.
    /// Noch it orizjineel, noch it resultaat, kin in [invalid value](../../nomicon/what-unsafe-does.html) wêze.
    ///
    /// `transmute` is semantysk gelyk oan in bitwize beweging fan it iene type nei it oare.It kopieart de bits fan 'e boarne wearde yn' e bestimmingswearde, en ferjit dan it orizjineel.
    /// It is lykweardich oan C's `memcpy` ûnder de motorkap, krekt as `transmute_copy`.
    ///
    /// Om't `transmute` in bywearde-operaasje is, is ôfstimming fan 'e *transmuteare wearden sels* gjin soargen.
    /// Lykas by elke oare funksje soarget de kompiler al foar dat sawol `T` as `U` goed oanpast binne.
    /// By it transmutearjen fan wearden dy't *earne oars* oanwize (lykas oanwizings, referinsjes, fakjes ...), moat de beller soargje foar in goede ôfstimming fan 'e oanwiisde wearden.
    ///
    /// `transmute` is **ongelooflijk** ûnfeilich.D'r binne in heule oantal manieren om [undefined behavior][ub] te feroarjen mei dizze funksje.`transmute` moat de absolute lêste rêdmiddel wêze.
    ///
    /// De [nomicon](../../nomicon/transmutes.html) hat ekstra dokumintaasje.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// D'r binne in pear dingen wêr't `transmute` echt nuttich foar is.
    ///
    /// In oanwizer feroarje yn in funksjewizer.Dit is *net* draachber foar masines wêr't funksjewizers en gegevenswizers ferskillende maten hawwe.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// In libben lang ferlingje, as in invariant libben ynkoartsje.Dit is avansearre, heul ûnfeilich Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ferwivelje net: in protte gebrûk fan `transmute` kinne wurde berikt op oare manieren.
    /// Hjirûnder steane algemiene tapassingen fan `transmute` dy't kinne wurde ferfongen troch feiliger konstruksjes.
    ///
    /// Rauwe bytes(`&[u8]`) draaie nei `u32`, `f64`, ensfh .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // brûk ynstee `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // of brûk `u32::from_le_bytes` of `u32::from_be_bytes` om de einigens op te jaan
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// In oanwizer feroarje yn in `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Brûk ynstee in `as`-cast
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// In `*mut T` feroarje yn in `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Brûk ynstee in reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// In `&mut T` feroarje yn in `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // No, `as` tegearre en opnij lienje, tink derom dat de keatling fan `as` `as` net trochgeand is
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// In `&str` feroarje yn in `&[u8]`:
    ///
    /// ```
    /// // dit is gjin goede manier om dit te dwaan.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Jo kinne `str::as_bytes` brûke
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Of brûk gewoan in byte-tekenrige as jo kontrôle hawwe oer de tekenrige letterlik
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// In `Vec<&T>` feroarje yn in `Vec<Option<&T>>`.
    ///
    /// Om it ynderlike type fan 'e ynhâld fan in kontener te transmutearjen, moatte jo derfoar soargje dat jo gjin ynbreuk meitsje op ien fan' e invarianten fan 'e kontener.
    /// Foar `Vec` betsjuttet dit dat sawol de grutte *as de oanpassing* fan 'e binnenste typen moatte oerienkomme.
    /// Oare konteners kinne fertrouwe op 'e grutte fan it type, ôfstimming, of sels de `TypeId`, yn hokker gefal transmutearjen hielendal net mooglik wêze soe sûnder de kontainer-invarianten te oertrêdzjen.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // kloon de vector, om't wy se letter opnij brûke
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmit brûke: dit fertrout op 'e net oantsjutte gegevensopmaak fan `Vec`, wat in min idee is en Untefine gedrach kin feroarsaakje.
    /////
    /// // It is lykwols gjin kopy.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is de suggereare, feilige manier.
    /// // It kopieart de heule vector lykwols yn in nije array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is de juste kopieare, ûnfeilige manier fan "transmuting" in `Vec`, sûnder te fertrouwen op de gegevensopmaak.
    /// // Yn stee fan letterlik `transmute` te skiljen, fiere wy in oanwizer út, mar yn termen fan it konvertearjen fan it orizjinele ynderlike type (`&i32`) nei it nije (`Option<&i32>`), hat dit deselde behertigingen.
    /////
    /// // Neist de hjirboppe levere ynformaasje, rieplachtsje ek de [`from_raw_parts`] dokumintaasje.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Update dit as vec_into_raw_parts wurdt stabilisearre.
    ///     // Soargje derfoar dat de orizjinele vector net falt.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ymplementearje:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // D'r binne meardere manieren om dit te dwaan, en d'r binne meardere problemen mei de folgjende (transmute)-manier.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // earst: transmute is net type feilich;alles wat it kontroleart is dat T en
    ///         // Jo binne fan deselde grutte.
    ///         // Twad, hjir hawwe jo twa feroarbere referinsjes dy't op itselde ûnthâld wize.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit krijt it type feiligensproblemen kwyt;`&mut *` sil* allinich *jo in `&mut T` jaan fan in `&mut T` of `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // jo hawwe lykwols noch twa feroarbere referinsjes dy't op itselde ûnthâld wize.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit is hoe't de standertbibleteek it docht.
    /// // Dit is de bêste metoade, as jo soks dwaan moatte
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dit hat no trije feroarbere referinsjes dy't op itselde ûnthâld wize.`slice`, de rwearde ret.0, en de rwearde ret.1.
    ///         // `slice` wurdt noait brûkt nei `let ptr = ...`, en dus kin men it as "dead" behannelje, en dêrom hawwe jo mar twa echte feroarbere plakjes.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Wylst dit de yntrinsike const stabyl makket, hawwe wy wat oanpaste koade yn const fn
    // kontrôles dy't it gebrûk binnen `const fn` foarkomme.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Jout `true` werom as it eigentlike type dat wurdt jûn as `T` droplijm fereasket;retourneert `false` as it eigentlike type dat wurdt levere foar `T` `Copy` ymplementeart.
    ///
    ///
    /// As it eigentlike type gjin droplijm fereasket noch `Copy` ymplementeart, dan is de weromwearde fan dizze funksje net oantsjutte.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Berekkent de offset fan in oanwizer.
    ///
    /// Dit wurdt ymplementeare as in yntrinsyk om te foarkommen dat it konvertearjen fan en fan in heule getal is, om't de konverzje aliasing-ynformaasje soe smite.
    ///
    /// # Safety
    ///
    /// Sawol de begjinnende as de resultearjende oanwizer moatte yn grinzen wêze as ien byte foarby it ein fan in tawiisd objekt.
    /// As ien fan 'e oanwizers bûten de grinzen is as rekenkundige oerstreaming foarkomt, sil elk fierdere gebrûk fan' e weromkommende wearde resultearje yn undefined gedrach.
    ///
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berekkent de kompensaasje fanút in oanwizer, mooglik ferpakking.
    ///
    /// Dit wurdt ymplementeare as in yntrinsyk om konvertearjen fan en fan in hiel getal te foarkommen, om't de konverzje bepaalde optimisaasjes remt.
    ///
    /// # Safety
    ///
    /// Oars as de `offset`-yntrinsike, beheint dizze yntrinsike de resultearjende oanwizer net om nei it ein fan in tawiisd foarwerp yn of ien byte te wizen, en it wikkelt mei twa's komplementearitmetyk.
    /// De resultearjende wearde is net needsaaklik jildich om te brûken om tagong te krijen ta ûnthâld.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekwivalint mei it passende yntrinsike `llvm.memcpy.p0i8.0i8.*`, mei in grutte fan `count`*`size_of::<T>()` en in opstelling fan
    ///
    /// `min_align_of::<T>()`
    ///
    /// De fluchtige parameter is ynsteld op `true`, dus wurdt dizze net optimalisearre útsein as de grutte gelyk is oan nul.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalint mei it passende yntrinsike `llvm.memmove.p0i8.0i8.*`, mei in grutte fan `count* size_of::<T>()` en in opstelling fan
    ///
    /// `min_align_of::<T>()`
    ///
    /// De fluchtige parameter is ynsteld op `true`, dus wurdt dizze net optimalisearre útsein as de grutte gelyk is oan nul.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalint mei it passende `llvm.memset.p0i8.*`-intrinsike, mei in grutte fan `count* size_of::<T>()` en in ôfstimming fan `min_align_of::<T>()`.
    ///
    ///
    /// De fluchtige parameter is ynsteld op `true`, dus wurdt dizze net optimalisearre útsein as de grutte gelyk is oan nul.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Fiert in flechtige lading út fan 'e `src`-oanwizer.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Docht in flechtige winkel nei de `dst`-oanwizer.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Fiert in flechtige lading út fan de `src`-oanwizer. De oanwizer is net ferplichte om út te lizzen.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Docht in flechtige winkel nei de `dst`-oanwizer.
    /// De oanwizer is net ferplichte om út te lizzen.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Jout de fjouwerkantswoartel fan in `f32`
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Jout de fjouwerkantswoartel fan in `f64`
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ferheget in `f32` nei in heule getal macht.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ferheget in `f64` nei in heule getal macht.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Jout de sinus werom fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Jout de sinus werom fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Jout de kosinus fan in `f32` werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Jout de kosinus fan in `f64` werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ferheget in `f32` nei in `f32`-krêft.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ferheget in `f64` nei in `f64`-krêft.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Jout de eksponential fan in `f32` werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Jout de eksponential fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returns 2 opheft nei de krêft fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returns 2 opheft nei de krêft fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Jout de natuerlike logaritme fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Jout de natuerlike logaritme fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Jout de basis 10 logaritme fan in `f32` werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Jout de basis 10 logaritme fan in `f64` werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Jout de basis 2 logaritme fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Jout de basis 2 logaritme fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Jout `a * b + c` foar `f32`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Jout `a * b + c` foar `f64`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Jout de absolute wearde fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Jout de absolute wearde fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Jout it minimum fan twa `f32`-wearden werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Jout it minimum fan twa `f64`-wearden werom.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Jout it maksimum fan twa `f32`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Jout it maksimum fan twa `f64`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopieart it teken fan `y` nei `x` foar `f32`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopieart it teken fan `y` nei `x` foar `f64`-wearden.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Jout it grutste gehiel minder dan of gelyk oan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Jout it grutste gehiel minder dan of gelyk oan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Jout it lytste heule getal grutter as of gelyk oan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Jout it lytste heule getal grutter as of gelyk oan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Jout it heule diel fan in `f32`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Jout it heule diel fan in `f64`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Jout it tichtste heule getal werom nei in `f32`.
    /// Mei in unjildige útsûndering mei driuwend punt opbringe as it argumint gjin hiel getal is.
    pub fn rintf32(x: f32) -> f32;
    /// Jout it tichtste heule getal werom nei in `f64`.
    /// Mei in unjildige útsûndering mei driuwend punt opbringe as it argumint gjin hiel getal is.
    pub fn rintf64(x: f64) -> f64;

    /// Jout it tichtste heule getal werom nei in `f32`.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Jout it tichtste heule getal werom nei in `f64`.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Jout it tichtste heule getal werom nei in `f32`.Rûnt healwei gefallen fan nul ôf.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Jout it tichtste heule getal werom nei in `f64`.Omkeart healwei gefallen fuort fan nul.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float tafoeging wêrtroch optimisaasjes mooglik binne basearre op algebraïske regels.
    /// Mei oannimme dat yngongen einich binne.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-subtraksje wêrtroch optimisaasjes mooglik binne basearre op algebraike regels.
    /// Mei oannimme dat yngongen einich binne.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Floatmultiplikaasje wêrtroch optimisaasjes mooglik binne basearre op algebraike regels.
    /// Mei oannimme dat yngongen einich binne.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Floatdieling dy't optimalisaasjes mooglik makket op basis fan algebraïske regels.
    /// Mei oannimme dat yngongen einich binne.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Floatreste dy't optimisaasjes mooglik makket op basis fan algebraike regels.
    /// Mei oannimme dat yngongen einich binne.
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertearje mei LLVM's fptoui/fptosi, dy't undef kin weromjaan foar wearden bûten it berik
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilisearre as [`f32::to_int_unchecked`] en [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Jout it oantal bits ynsteld yn in hiel getal `T`
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `count_ones`-metoade.
    /// Bygelyks,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Jout it oantal foaroansteande unset bits (zeroes) yn in hiel getal type `T`.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `leading_zeros`-metoade.
    /// Bygelyks,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// In `x` mei wearde `0` sil de bitbreedte fan `T` werombringe.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Lykas `ctlz`, mar ekstra ûnfeilich as it `undef` weromjout as in `x` wurdt jûn mei wearde `0`.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Jout it oantal efterbliuwende unset bits (zeroes) yn in hiel getal `T`.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `trailing_zeros`-metoade.
    /// Bygelyks,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// In `x` mei wearde `0` sil de bitbreedte fan `T` werombringe:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Lykas `cttz`, mar ekstra ûnfeilich as it `undef` weromjout as in `x` wurdt jûn mei wearde `0`.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Fertelt de bytes yn in heule getal `T`.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `swap_bytes`-metoade.
    /// Bygelyks,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Fertelt de bits yn in heule getal `T`.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `reverse_bits`-metoade.
    /// Bygelyks,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Fiert kontrolearre gehielde tafoeging út.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `overflowing_add`-metoade.
    /// Bygelyks,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fiert kontrolearre heule getal-subtraksje út
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `overflowing_sub`-metoade.
    /// Bygelyks,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fiert kontrolearre heulgetalfermannigens út
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `overflowing_mul`-metoade.
    /// Bygelyks,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fiert in krekte ferdieling út, wat resulteart yn undefined gedrach wêr `x % y != 0` of `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Fiert in net-hifke divyzje út, wat resulteart yn undefined gedrach wêr `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Feilige wrappers foar dizze yntrinsike binne te krijen op 'e heule getallen primitiven fia de `checked_div`-metoade.
    /// Bygelyks,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Jout de rest fan in net-kontroleare divyzje werom, wat resulteart yn undefined gedrach as `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Feilige wrappers foar dizze yntrinsike binne te krijen op 'e heule getallen primitiven fia de `checked_rem`-metoade.
    /// Bygelyks,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Fiert in net-kontroleare loftskift út, wat resulteart yn undefined gedrach as `y < 0` of `y >= N`, wêrby N de breedte fan T is yn bits.
    ///
    ///
    /// Feilige wrappers foar dizze yntrinsike binne te krijen op 'e heule getallen primitiven fia de `checked_shl`-metoade.
    /// Bygelyks,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Fiert in net-kontroleare rjochter ferskowing út, wat resulteart yn undefined gedrach as `y < 0` of `y >= N`, wêrby N de breedte fan T is yn bits.
    ///
    ///
    /// Feilige wrappers foar dizze yntrinsike binne te krijen op 'e heule getallen primitiven fia de `checked_shr`-metoade.
    /// Bygelyks,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Jout it resultaat fan in net-selekteare tafoeging, wat resulteart yn undefined gedrach as `x + y > T::MAX` of `x + y < T::MIN`.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Jout it resultaat fan in net-kontroleare subtraksje, wat resulteart yn undefined gedrach as `x - y > T::MAX` of `x - y < T::MIN`.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Jout it resultaat fan in net-kontrolearre fermannichfâldigjen, wat resulteart yn undefined gedrach as `x *y > T::MAX` of `x* y < T::MIN`.
    ///
    ///
    /// Dizze yntrinsike hat gjin stabile tsjinhinger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Fiert lofts draaie.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `rotate_left`-metoade.
    /// Bygelyks,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Utfiere draaie rjochts.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `rotate_right`-metoade.
    /// Bygelyks,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Jout (a + b) mod 2 <sup>N</sup>, wêrby N de breedte fan T is yn bits.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `wrapping_add`-metoade.
    /// Bygelyks,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Jout (a, b) mod 2 <sup>N</sup>, wêrby N de breedte fan T is yn bits.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `wrapping_sub`-metoade.
    /// Bygelyks,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Jout (a * b) mod 2 <sup>N</sup>, wêrby N de breedte fan T is yn bits.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `wrapping_mul`-metoade.
    /// Bygelyks,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Berekent `a + b`, verzadigt mei numerike grinzen.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `saturating_add`-metoade.
    /// Bygelyks,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Berekent `a - b`, verzadigt mei numerike grinzen.
    ///
    /// De stabilisearre ferzjes fan dizze yntrinsike binne beskikber op 'e heule getallen primitiven fia de `saturating_sub`-metoade.
    /// Bygelyks,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Jout de wearde fan 'e diskriminant foar de fariant yn 'v';
    /// as `T` gjin diskriminant hat, retourneert `0`.
    ///
    /// De stabilisearre ferzje fan dizze yntrinsike is [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Jout it oantal farianten fan it type `T` cast nei in `usize`;
    /// as `T` gjin farianten hat, jout `0` werom.Unbewenne farianten sille wurde teld.
    ///
    /// De te stabilisearjen ferzje fan dizze yntrinsike is [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch"-konstruksje dy't de funksjewizer `try_fn` opropt mei de gegevenspointer `data`.
    ///
    /// It tredde argumint is in funksje neamd as in panic optreedt.
    /// Dizze funksje bringt de gegevenswizer en in oanwizer nei it doel-spesifike útsûnderingsobjekt dat is fongen.
    ///
    /// Sjoch foar mear ynformaasje de boarne fan 'e kompilear en ek de ymplemintaasje fan std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Stjoert in `!nontemporal`-winkel út neffens LLVM (sjoch har dokuminten).
    /// Wierskynlik sil noait stabyl wurde.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Sjoch dokumintaasje fan `<*const T>::offset_from` foar details.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Sjoch dokumintaasje fan `<*const T>::guaranteed_eq` foar details.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Sjoch dokumintaasje fan `<*const T>::guaranteed_ne` foar details.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tawize op kompilearjende tiid.Moat net neamd wurde by runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Guon funksjes wurde hjir definieare om't se per ongelok beskikber steld binne yn dizze module op stabyl.
// Sjoch <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` falt ek yn dizze kategory, mar it kin net ynpakt wurde fanwegen de kontrôle dat `T` en `U` deselde grutte hawwe.)
//

/// Kontroleart oft `ptr` goed is ôfstimd ten opsichte fan `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopieart `count *size_of::<T>()` bytes fan `src` nei `dst`.De boarne en bestimming moatte* net * oerlaapje.
///
/// Foar regio's fan ûnthâld dy't oerlaapje kinne, brûke jo [`copy`] ynstee.
///
/// `copy_nonoverlapping` is semantysk gelyk oan C's [`memcpy`], mar mei de argumintoarder wiksele.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `src` moat [valid] wêze foar lêzen fan `count * size_of::<T>()` bytes.
///
/// * `dst` moat [valid] wêze foar skriuwen fan `count * size_of::<T>()`-bytes.
///
/// * Sawol `src` as `dst` moatte goed oanpast wurde.
///
/// * De regio fan ûnthâld begjint by `src` mei in grutte fan `count *
///   size_of: :<T>() `bytes moatte *net* oerlaapje mei de regio ûnthâld dy't begjint by `dst` mei deselde grutte.
///
/// Lykas [`read`] makket `copy_nonoverlapping` in bitwize kopy fan `T`, likefolle oft `T` [`Copy`] is.
/// As `T` net [`Copy`] is, kin *beide* de wearden yn 'e regio dy't begjinne by `*src` en de regio dy't begjint by `* dst` [violate memory safety][read-ownership] brûke.
///
///
/// Tink derom dat sels as de effektyf kopieare grutte (`count * size_of: :<T>()`) is `0`, de oanwizers moatte net-NULL wêze en goed rjochte wêze.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] mei de hân ymplementearje:
///
/// ```
/// use std::ptr;
///
/// /// Ferpleatst alle eleminten fan `src` nei `dst`, wêrtroch `src` leech is.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Soargje derfoar dat `dst` genôch kapasiteit hat om alle `src` te hâlden.
///     dst.reserve(src_len);
///
///     unsafe {
///         // De oprop om te kompensearjen is altyd feilich, om't `Vec` noait mear dan `isize::MAX` bytes tawiist.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` sûnder de ynhâld derfan te litten.
///         // Wy dogge dit earst, om problemen te foarkommen yn gefal wat fierderop panics.
///         src.set_len(0);
///
///         // De twa regio's kinne net oerlaapje om't mutabele referinsjes gjin alias binne, en twa ferskillende vectors kinne net itselde ûnthâld hawwe.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Fertel `dst` dat it no de ynhâld fan `src` hâldt.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fier dizze kontrôles allinich út op runtime
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Gjin panyk om codegen-ynfloed lytser te hâlden.
        abort();
    }*/

    // VEILIGHEID: it feiligenskontrakt foar `copy_nonoverlapping` moat wêze
    // befêstige troch de beller.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopieart `count * size_of::<T>()` bytes fan `src` nei `dst`.De boarne en bestimming kinne oerlaapje.
///
/// As de boarne en bestimming *noait* oerlaapje, kin [`copy_nonoverlapping`] ynstee brûkt wurde.
///
/// `copy` is semantysk ekwivalint mei C's [`memmove`], mar mei de argumintoarder wiksele.
/// Kopiearje fynt plak as waarden de bytes kopieare fan `src` nei in tydlike array en dan kopieare fan 'e array nei `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `src` moat [valid] wêze foar lêzen fan `count * size_of::<T>()` bytes.
///
/// * `dst` moat [valid] wêze foar skriuwen fan `count * size_of::<T>()`-bytes.
///
/// * Sawol `src` as `dst` moatte goed oanpast wurde.
///
/// Lykas [`read`] makket `copy` in bitwize kopy fan `T`, likefolle oft `T` [`Copy`] is.
/// As `T` net [`Copy`] is, kin sawol de wearden yn 'e regio begjinne by `*src` as de regio dy't begjint by `* dst` [violate memory safety][read-ownership].
///
///
/// Tink derom dat sels as de effektyf kopieare grutte (`count * size_of: :<T>()`) is `0`, de oanwizers moatte net-NULL wêze en goed rjochte wêze.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Effektyf in Rust vector meitsje fan in ûnfeilige buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` moat korrekt wurde ôfstimd op syn type en net-nul.
/// /// * `ptr` moat jildich wêze foar lêzen fan `elts` oangrinzjende eleminten fan type `T`.
/// /// * Dy eleminten moatte net brûkt wurde nei't dizze funksje neamd is, útsein as `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // VEILIGHEID: Us foarwearde soarget derfoar dat de boarne ôfstimd en jildich is,
///     // en `Vec::with_capacity` soarget derfoar dat wy brûkbere romte hawwe om se te skriuwen.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // VEILIGHEID: Wy hawwe it earder mei dizze folle kapasiteit makke,
///     // en de foarige `copy` hat dizze eleminten inisjalisearre.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fier dizze kontrôles allinich út op runtime
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Gjin panyk om codegen-ynfloed lytser te hâlden.
        abort();
    }*/

    // VEILIGHEID: it feiligenskontrakt foar `copy` moat wurde yn stân hâlden troch de beller.
    unsafe { copy(src, dst, count) }
}

/// Stelt `count * size_of::<T>()` bytes ûnthâld yn begjinnend by `dst` nei `val`.
///
/// `write_bytes` is gelyk oan C's [`memset`], mar stelt `count * size_of::<T>()` bytes op `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `dst` moat [valid] wêze foar skriuwen fan `count * size_of::<T>()`-bytes.
///
/// * `dst` moat goed oanpast wurde.
///
/// Derneist moat de beller derfoar soargje dat it skriuwen fan `count * size_of::<T>()`-bytes nei de opjûne regio fan ûnthâld resulteart yn in jildige wearde fan `T`.
/// It brûken fan in regio fan ûnthâld typt as `T` dat in unjildige wearde fan `T` befettet, is net definieare gedrach.
///
/// Tink derom dat sels as de effektyf kopieare grutte (`count * size_of: :<T>()`) is `0`, de oanwizer moat net-NULL wêze en goed rjochte wêze.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// In unjildige wearde oanmeitsje:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lek de earder bewarre wearde troch de `Box<T>` te oerskriuwen mei in nulwizer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Op dit punt resulteart gebrûk of drop fan `v` yn undefined gedrach.
/// // drop(v); // ERROR
///
/// // Sels lekkende `v` "uses" it, en dêrtroch is undefined gedrach.
/// // mem::forget(v); // ERROR
///
/// // Eins is `v` ûnjildich neffens invarianten fan basistype-opmaak, dus *elke* operaasje dy't it oanrekket is undefined gedrach.
/////
/// // lit v2 =v;//FOUT
///
/// unsafe {
///     // Lit ús ynstee in jildige wearde ynfiere
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // No is it fakje prima
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // VEILIGHEID: it feiligenskontrakt foar `write_bytes` moat wurde yn stân hâlden troch de beller.
    unsafe { write_bytes(dst, val, count) }
}