/// In iterator dy't de krekte lingte wit.
///
/// In protte [`Iterator`] s witte net hoefolle kearen se itere sille, mar guon dogge it.
/// As in iterator wit hoefolle kearen it iteraasje kin, kin tagong ta dizze ynformaasje nuttich wêze.
/// As jo bygelyks efterút itearje wolle, is in goed begjin om te witten wêr't it ein is.
///
/// By it ymplementearjen fan in `ExactSizeIterator` moatte jo ek [`Iterator`] ymplementearje.
/// As jo dit dogge, moat de ymplemintaasje fan [`Iterator::size_hint`]*de krekte grutte fan 'e iterator* werombringe.
///
/// De [`len`]-metoade hat in standert ymplemintaasje, dus jo moatte it normaal net útfiere.
/// Jo kinne lykwols in mear performante ymplemintaasje leverje dan de standert, dus it oerskriuwen is yn dit gefal logysk.
///
///
/// Tink derom dat dizze trait in feilige trait is en as sadanich *net* en *net* kin garandearje dat de weromkommende lingte just is.
/// Dit betsjut dat `unsafe`-koade **net** moat fertrouwe op 'e justigens fan [`Iterator::size_hint`].
/// De ynstabile en ûnfeilige [`TrustedLen`](super::marker::TrustedLen) trait jout dizze ekstra garânsje.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// // in einich berik wit presys hoefolle kearen it iteraasje sil
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Yn 'e [module-level docs] hawwe wy in [`Iterator`] ymplementeare, `Counter`.
/// Litte wy `ExactSizeIterator` der ek foar útfiere:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Wy kinne it oerbleaune oantal iteraasjes maklik berekkenje.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // En no kinne wy it brûke!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Jout de krekte lingte fan 'e iterator.
    ///
    /// De ymplemintaasje soarget derfoar dat de iterator presys `len()` mear kearen in [`Some(T)`]-wearde werombringt, foardat [`None`] weromkomt.
    ///
    /// Dizze metoade hat in standert ymplemintaasje, dus jo moatte it normaal net direkt ymplementearje.
    /// As jo lykwols in effisjintere ymplemintaasje kinne leverje, kinne jo dat dwaan.
    /// Sjoch de [trait-level]-dokuminten foar in foarbyld.
    ///
    /// Dizze funksje hat deselde feiligensgarânsjes as de [`Iterator::size_hint`]-funksje.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // in einich berik wit presys hoefolle kearen it iteraasje sil
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Dizze bewearing is te ferdigenjend, mar it kontroleart de invariant
        // garandearre troch de trait.
        // As dizze trait rust-yntern wie, kinne wy debug_assert brûke !;assert_eq!sil ek alle ymplementaasjes fan brûkers fan Rust kontrolearje.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Jout `true` werom as de iterator leech is.
    ///
    /// Dizze metoade hat in standert ymplemintaasje mei [`ExactSizeIterator::len()`], dus jo hoege it net sels te ymplementearjen.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}