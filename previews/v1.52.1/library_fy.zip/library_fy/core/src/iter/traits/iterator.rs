// negearje-tidy-filelength Dit bestân bestiet hast allinich út 'e definysje fan `Iterator`.
// Wy kinne dat net ferdiele yn meardere bestannen.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// In interface foar omgean mei iterators.
///
/// Dit is de wichtichste iterator trait.
/// Sjoch asjebleaft de [module-level documentation] foar mear oer it konsept fan iterators.
/// Yn it bysûnder wolle jo miskien witte hoe't jo [implement `Iterator`][impl] moatte.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// It type fan 'e eleminten dy't itereare binne.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Rint de iterator foarút en jout de folgjende wearde werom.
    ///
    /// Jout [`None`] werom as iteraasje klear is.
    /// Yndividuele iterator-ymplemintaasjes kinne der foar kieze om iteraasje te hervatten, en sa kin `next()` opnij belje, miskien wol of net op in stuit begjinne mei [`Some(Item)`] werom te jaan.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // In oprop nei next() jout de folgjende wearde werom ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... en dan ienris ienris is it foarby.
    /// assert_eq!(None, iter.next());
    ///
    /// // Mear oproppen kinne `None` al of net werom.Hjir sille se altyd wol.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Jout de grinzen werom op 'e oerbleaune lingte fan' e iterator.
    ///
    /// Spesifyk jout `size_hint()` in tupel werom wêr't it earste elemint de ûndergrins is, en it twadde elemint de boppegrins is.
    ///
    /// De twadde helte fan 'e tuple dy't weromkomt is in [`Option`]`<`[`usize`] `>`.
    /// In [`None`] hjir betsjut dat d'r gjin bekende boppegrins is, of dat de boppegrins grutter is dan [`usize`].
    ///
    /// # Ymplementaasjenota's
    ///
    /// It wurdt net ôftwongen dat in ymplemintaasje iterator it ferklearre oantal eleminten oplevert.In buggy-iterator kin minder leverje dan de ûndergrins as mear as de boppegrins fan eleminten.
    ///
    /// `size_hint()` is foaral bedoeld om te brûken foar optimalisaasjes lykas romte reservearje foar de eleminten fan 'e iterator, mar moat net fertrouwe wurde op bgl., beheining fan grinzen yn ûnfeilige koade.
    /// In ferkearde ymplemintaasje fan `size_hint()` moat net liede ta oertredings fan ûnthâldfeiligens.
    ///
    /// Dat sei, de ymplemintaasje moat in krekte skatting leverje, want oars soe it in ynbreuk wêze op it protokol fan 'e trait.
    ///
    /// De standert ymplemintaasje jout '(0, `[` Gjin'] ') `dat is korrekt foar elke iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// In komplekser foarbyld:
    ///
    /// ```
    /// // De even nûmers fan nul oant tsien.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Wy kinne itere fan nul oant tsien kear.
    /// // Wittend dat it krekt fiif binne soe net mooglik wêze sûnder filter() út te fieren.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Litte wy noch fiif nûmers tafoegje mei chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // no wurde beide grinzen mei fiif ferhege
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` werombringe foar in boppegrins:
    ///
    /// ```
    /// // in ûneinige iterator hat gjin boppegrins en de maksimaal mooglike ûndergrins
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Ferbrûkt de iterator, telt it oantal iteraasjes en retourneert it.
    ///
    /// Dizze metoade sil [`next`] werhelje oant [`None`] is oantroffen, en it oantal kearen werom dat [`Some`] seach.
    /// Tink derom dat [`next`] teminsten ien kear neamd wurde moat, sels as de iterator gjin eleminten hat.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Oerstreamingsgedrach
    ///
    /// De metoade hoecht net te beskermjen tsjin oerstreamingen, dus tellen eleminten fan in iterator mei mear as [`usize::MAX`]-eleminten produsearje it ferkearde resultaat as panics.
    ///
    /// As debug-asserts ynskeakele binne, is in panic garandearre.
    ///
    /// # Panics
    ///
    /// Dizze funksje kin panic as de iterator mear dan [`usize::MAX`]-eleminten hat.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Ferbrûkt de iterator, werom it lêste elemint.
    ///
    /// Dizze metoade sil de iterator evaluearje oant it [`None`] weromkomt.
    /// Wylst soks docht, hâldt it it hjoeddeistige elemint by.
    /// Neidat [`None`] werom is, sil `last()` dan it lêste elemint weromjaan dat it seach.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Befoarderet de iterator troch `n`-eleminten.
    ///
    /// Dizze metoade sil `n`-eleminten graach oerslaan troch [`next`] oant `n` kear te roppen oant [`None`] wurdt oantroffen.
    ///
    /// `advance_by(n)` sil [`Ok(())`][Ok] werombringe as de iterator mei súkses foarútgiet troch `n`-eleminten, of [`Err(k)`][Err] as [`None`] wurdt tsjinkaam, wêr't `k` it oantal eleminten is dat de iterator foarút wurdt foardat de eleminten op binne (ie
    /// de lingte fan 'e iterator).
    /// Tink derom dat `k` altyd minder is dan `n`.
    ///
    /// `advance_by(0)` skilje ferbrûkt gjin eleminten en retourneert altyd [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // allinnich `&4` waard oerslein
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Jout it `n`e elemint fan 'e iterator werom.
    ///
    /// Lykas de measte yndeksearjende operaasjes begjint de telling fan nul, dus `nth(0)` jout de earste wearde werom, `nth(1)` de twadde, ensafuorthinne.
    ///
    /// Tink derom dat alle foargeande eleminten, lykas it weromkommen elemint, sille wurde konsumeare fan 'e iterator.
    /// Dat betsjuttet dat de foargeande eleminten wurde ferwidere, en ek dat `nth(0)` meardere kearen op deselde iterator belje sil ferskate eleminten werombringe.
    ///
    ///
    /// `nth()` sil [`None`] werombringe as `n` grutter is as of gelyk oan 'e lingte fan' e iterator.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` meardere kearen skilje spielt de iterator net werom:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None` werombringe as d'r minder dan `n + 1`-eleminten binne:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Makket in iterator oan dat begjint op itselde punt, mar stapt troch it opjûne bedrach by elke iteraasje.
    ///
    /// Opmerking 1: It earste elemint fan 'e iterator sil altyd wurde weromjûn, ûnôfhinklik fan' e jûn stap.
    ///
    /// Opmerking 2: De tiid wêrop negeare eleminten wurde lutsen is net fêst.
    /// `StepBy` gedraacht him as de folchoarder `next(), nth(step-1), nth(step-1),…`, mar is ek frij om har te gedragen lykas de folchoarder
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Hokker manier wurdt brûkt kin feroarje foar guon iterators om prestaasjesredenen.
    /// De twadde manier sil de iterator earder foardwaan en kin mear items konsumearje.
    ///
    /// `advance_n_and_return_first` is it ekwivalint fan:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// De metoade sil panic as de opjûne stap `0` is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Nimt twa iterators en makket in nije iterator oer beide yn folchoarder.
    ///
    /// `chain()` sil in nije iterator weromjaan dy't earst itereart oer wearden fan 'e earste iterator en dan oer wearden fan' e twadde iterator.
    ///
    /// Mei oare wurden, it ferbynt twa iterators mei-inoar, yn in keatling.🔗
    ///
    /// [`once`] wurdt faak brûkt om ien wearde oan te passen yn in keatling fan oare soarten iteraasje.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sûnt it argumint foar `chain()` [`IntoIterator`] brûkt, kinne wy alles trochjaan dat kin wurde omboud ta in [`Iterator`], net allinich in [`Iterator`] sels.
    /// Slices (`&[T]`) ymplementearje bygelyks [`IntoIterator`], en kinne sa direkt nei `chain()` wurde trochjûn:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As jo mei Windows API wurkje, kinne jo [`OsStr`] nei `Vec<u16>` konvertearje:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Ritst' twa iterators op yn ien iterator fan pearen.
    ///
    /// `zip()` retourneert in nije iterator dy't itereart oer twa oare iterators, en jout in tuple werom wêr't it earste elemint komt fan 'e earste iterator, en it twadde elemint komt fan it twadde iterator.
    ///
    ///
    /// Mei oare wurden, it ritset twa iterators tegearre, yn ien.
    ///
    /// As ien fan 'e iterator [`None`] weromkomt, sil [`next`] fan' e zip-iterator [`None`] weromjaan.
    /// As de earste iterator [`None`] weromkomt, sil `zip` kortslute en `next` wurdt net neamd op 'e twadde iterator.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sûnt it argumint foar `zip()` [`IntoIterator`] brûkt, kinne wy alles trochjaan dat kin wurde omboud ta in [`Iterator`], net allinich in [`Iterator`] sels.
    /// Slices (`&[T]`) ymplementearje bygelyks [`IntoIterator`], en kinne sa direkt nei `zip()` wurde trochjûn:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` wurdt faak brûkt om in einleaze iterator nei in einige te zip.
    /// Dit wurket om't de einige iterator úteinlik [`None`] sil werombringe, en de rits beëindiget.Ritsen mei `(0..)` kin in soad op [`enumerate`] lykje:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Makket in nije iterator oan dy't in kopy fan `separator` pleatst tusken neistlizzende items fan 'e orizjinele iterator.
    ///
    /// As `separator` [`Clone`] net ymplementeart of elke kear berekkene wurde moat, brûk dan [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // It earste elemint fan `a`.
    /// assert_eq!(a.next(), Some(&100)); // De skieding.
    /// assert_eq!(a.next(), Some(&1));   // It folgjende elemint fan `a`.
    /// assert_eq!(a.next(), Some(&100)); // De skieding.
    /// assert_eq!(a.next(), Some(&2));   // It lêste elemint fan `a`.
    /// assert_eq!(a.next(), None);       // De iterator is klear.
    /// ```
    ///
    /// `intersperse` kin heul nuttich wêze om mei te dwaan oan items fan in iterator mei in mienskiplik elemint:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Makket in nije iterator oan dy't in item genereart troch `separator` pleatst tusken neistlizzende items fan 'e orizjinele iterator.
    ///
    /// De sluting sil elke kear presys ien kear wurde neamd as in artikel wurdt pleatst tusken twa neistlizzende items fan 'e ûnderlizzende iterator;
    /// spesifyk wurdt de sluting net neamd as de ûnderlizzende iterator minder dan twa items oplevert en nei it lêste item wurdt levere.
    ///
    ///
    /// As it item fan iterator [`Clone`] ymplementeart, kin it makliker wêze om [`intersperse`] te brûken.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // It earste elemint fan `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De skieding.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // It folgjende elemint fan `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De skieding.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // It lêste elemint fanôf `v`.
    /// assert_eq!(it.next(), None);               // De iterator is klear.
    /// ```
    ///
    /// `intersperse_with` kin brûkt wurde yn situaasjes wêr't de skieding berekkene wurde moat:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // De sluting lient syn kontekst mutabel om in item te generearjen.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nimt in sluting en makket in iterator dy't dizze sluting op elk elemint neamt.
    ///
    /// `map()` transformeart de iene iterator yn 'e oare, troch syn argumint:
    /// eat dat [`FnMut`] ymplementeart.It produseart in nije iterator dy't dizze sluting neamt op elk elemint fan 'e orizjinele iterator.
    ///
    /// As jo goed binne yn typen te tinken, kinne jo `map()` sa tinke:
    /// As jo in iterator hawwe dy't jo eleminten fan wat type `A` jout, en jo wolle in iterator fan in oar type `B`, dan kinne jo `map()` brûke, troch in sluting passearje dy't in `A` nimt en in `B` werombringe.
    ///
    ///
    /// `map()` is konseptueel gelyk oan in [`for`]-loop.Om't `map()` lykwols lui is, wurdt it it bêste brûkt as jo al wurkje mei oare iterators.
    /// As jo in soarte fan looping dogge foar in side-effekt, wurdt it as idiomatysk beskôge om [`for`] te brûken dan `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As jo in soarte fan side-effekt dogge, foarkar [`for`] dan `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // doch dit net:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // it sil net iens útfiere, om't it lui is.Rust sil jo warskôgje oer dit.
    ///
    /// // Brûk ynstee foar:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Ropt in sluting op elk elemint fan in iterator.
    ///
    /// Dit is lykweardich oan it brûken fan in [`for`]-loop op 'e iterator, hoewol `break` en `continue` net mooglik binne fan in sluting.
    /// It is oer it algemien idiomatysker om in `for`-loop te brûken, mar `for_each` kin mear lêsber wêze by it ferwurkjen fan items oan 'e ein fan langere iteratorketens.
    ///
    /// Yn guon gefallen kin `for_each` ek rapper wêze as in loop, om't it ynterne iteraasje sil brûke op adapters lykas `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Foar sa'n lyts foarbyld kin in `for`-loop skjinner wêze, mar `for_each` kin foarkar wêze om in funksjonele styl te hâlden mei langere iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Makket in iterator dy't in sluting brûkt om te bepalen oft in elemint moat wurde levere.
    ///
    /// Mei it each op in elemint moat de sluting `true` as `false` werombringe.De weromkearde iterator sil allinich de eleminten opleverje wêrfoar't de sluting wier is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om't de sluting trochjûn nei `filter()` in referinsje nimt, en in protte iterators iterearje oer referinsjes, liedt dit ta in mooglik betiizjende situaasje, wêr't it type fan 'e sluting in dûbele referinsje is:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // twa * s nedich!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// It is gewoan om ynstee destruktuerjen te brûken op it argumint om ien te ferwiderjen:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // sawol&as *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// of beide:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // twa &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// fan dizze lagen.
    ///
    /// Tink derom dat `iter.filter(f).next()` ekwivalint is mei `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Makket in iterator oan dy't sawol filtert as kaarten.
    ///
    /// De weromkommende iterator leveret allinich de `wearde`s werop de levere sluting `Some(value)` werom jout.
    ///
    /// `filter_map` kin brûkt wurde om keatlingen fan [`filter`] en [`map`] beknetter te meitsjen.
    /// It foarbyld hjirûnder lit sjen hoe't in `map().filter().map()` kin wurde ynkoarte ta ien oprop nei `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hjir is itselde foarbyld, mar mei [`filter`] en [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Makket in iterator dy't de hjoeddeistige iteraasje telt, lykas de folgjende wearde.
    ///
    /// De weromkommende iterator leveret pearen `(i, val)` op, wêrby't `i` de hjoeddeiske yndeks fan iteraasje is en `val` de wearde is dy't weromkomt troch de iterator.
    ///
    ///
    /// `enumerate()` hâldt syn telling as in [`usize`].
    /// As jo wolle telle troch in heul getal fan oare grutte, biedt de [`zip`]-funksje ferlykbere funksjonaliteit.
    ///
    /// # Oerstreamingsgedrach
    ///
    /// De metoade hoecht net te beskermjen tsjin oerstreamingen, sadat mear as [`usize::MAX`]-eleminten opnimme, ferkeart it ferkearde resultaat as panics.
    /// As debug-asserts ynskeakele binne, is in panic garandearre.
    ///
    /// # Panics
    ///
    /// De weromkearde iterator kin panic as de yndeks dy't werom moat in [`usize`] oerstreamje.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Makket in iterator dy't [`peek`] kin brûke om nei it folgjende elemint fan 'e iterator te sjen sûnder it te konsumearjen.
    ///
    /// Foeget in [`peek`]-metoade ta oan in iterator.Sjoch de dokumintaasje foar mear ynformaasje.
    ///
    /// Tink derom dat de ûnderlizzende iterator noch foarút is as [`peek`] foar it earst wurdt oproppen: Om it folgjende elemint te heljen, wurdt [`next`] neamd op 'e ûnderlizzende iterator, dus alle bywurkingen (ie
    ///
    /// alles oars dan it opheljen fan 'e folgjende wearde) fan' e [`next`]-metoade sil foarkomme.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lit ús sjen yn 'e future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // wy kinne meardere kearen peek(), de iterator sil net foarútgean
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // neidat de iterator klear is, is peek() dat ek
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Makket in iterator oan dy't ['oerslaan'] eleminten basearre op in predikaat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` nimt in sluting as argumint.It sil dizze sluting op elk elemint fan 'e iterator neame, en eleminten negearje oant it `false` weromkomt.
    ///
    /// Neidat `false` werom is, is `skip_while()`'s-taak foarby, en de rest fan 'e eleminten wurde levere.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om't de sluting trochjûn nei `skip_while()` in referinsje nimt, en in protte iterators iterearje oer referinsjes, liedt dit ta in mooglik betiizjende situaasje, wêr't it type fan it slutingsargumint in dûbele referinsje is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // twa * s nedich!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopje nei in earste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Wylst dit falsk wêze soe, om't wy al in falsk hawwe, wurdt skip_while() net mear brûkt
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Makket in iterator dy't eleminten oplevert op basis fan in predikaat.
    ///
    /// `take_while()` nimt in sluting as argumint.It sil dizze sluting op elk elemint fan 'e iterator neame, en eleminten leverje wylst it `true` weromkomt.
    ///
    /// Neidat `false` werom is, is `take_while()`'s-taak oer, en de rest fan 'e eleminten wurde negeare.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om't de sluting trochjûn nei `take_while()` in referinsje nimt, en in protte iterators iterearje oer referinsjes, liedt dit ta in mooglik betiizjende situaasje, wêr't it type fan 'e sluting in dûbele referinsje is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // twa * s nedich!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopje nei in earste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Wy hawwe mear eleminten dy't minder dan nul binne, mar om't wy al in falsk hawwe, wurdt take_while() net mear brûkt
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Om't `take_while()` nei de wearde moat sjen om te sjen as it al of net moat wurde opnommen, sille konsumearende iterators sjen dat it is fuorthelle:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// De `3` is der net mear, om't it waard konsumeare om te sjen oft de iteraasje stopje moast, mar waard net werom pleatst yn 'e iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Makket in iterator dy't beide eleminten oplevert basearre op in predikaat en kaarten.
    ///
    /// `map_while()` nimt in sluting as argumint.
    /// It sil dizze sluting op elk elemint fan 'e iterator neame, en eleminten opleverje wylst it [`Some(_)`][`Some`] weromkomt.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hjir is itselde foarbyld, mar mei [`take_while`] en [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopje nei in earste [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Wy hawwe mear eleminten dy't passe kinne yn u32 (4, 5), mar `map_while` joech `None` werom foar `-3` (lykas de `predicate` `None` weromkaam) en `collect` stopet by de earste `None` dy't er tsjinkaam.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Om't `map_while()` nei de wearde moat sjen om te sjen as it al of net moat wurde opnommen, sille konsumearende iterators sjen dat it is fuorthelle:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// De `-3` is der net mear, om't it waard konsumeare om te sjen oft de iteraasje stopje moast, mar waard net werom pleatst yn 'e iterator.
    ///
    /// Tink derom dat dizze iterator yn tsjinstelling ta [`take_while`]**net** fusearre is.
    /// It is ek net oantsjutte wat dizze iterator weromkomt nei't de earste [`None`] werom is.
    /// As jo fuseare iterator nedich binne, brûk dan [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Makket in iterator dy't de earste `n`-eleminten oerslaat.
    ///
    /// Nei't se konsumeare binne, wurde de rest fan 'e eleminten oplevere.
    /// Yn stee fan dizze metoade direkt te oerskriuwen, ynstee fan 'e `nth`-metoade oerskriuwe.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Makket in iterator dy't syn earste `n`-eleminten oplevert.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` wurdt faak brûkt mei in ûneinige iterator, om it einich te meitsjen:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As minder dan `n`-eleminten beskikber binne, sil `take` him beheine ta de grutte fan 'e ûnderlizzende iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// In iteratoradapter lykas [`fold`] dy't ynterne steat hâldt en in nije iterator produseart.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` nimt twa arguminten: in begjinwearde dy't de ynterne steat siedt, en in sluting mei twa arguminten, de earste is in feroarbere ferwizing nei de ynterne steat en de twadde in iterator-elemint.
    ///
    /// De sluting kin tawize oan 'e ynterne steat om steat te dielen tusken werhellingen.
    ///
    /// By iteraasje sil de sluting tapast wurde op elk elemint fan 'e iterator en wurdt de weromwearde fan' e sluting, in [`Option`], levere troch de iterator.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // elke iteraasje sille wy de steat fermannichfâldigje mei it elemint
    ///     *state = *state * x;
    ///
    ///     // dan sille wy de negaasje fan 'e steat opleverje
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Makket in iterator dy't wurket as map, mar nestele struktuer flak makket.
    ///
    /// De [`map`]-adapter is heul nuttich, mar allinich as it slutingsargumint wearden produseart.
    /// As it ynstee in iterator produseart, is d'r in ekstra laach fan yndireksje.
    /// `flat_map()` sil dizze ekstra laach op himsels fuortsmite.
    ///
    /// Jo kinne `flat_map(f)` tinke as it semantyske ekwivalint fan [`map`] ping, en dan ['flakke'] ing lykas yn `map(f).flatten()`.
    ///
    /// In oare manier om nei te tinken oer `flat_map()`: de ôfsluting fan [`map`] jout ien item foar elk elemint, en `flat_map()`'s-sluting jout in iterator foar elk elemint.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() jout in iterator werom
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Makket in iterator dy't nestele struktuer flak makket.
    ///
    /// Dit is handich as jo in iterator hawwe fan iterators as in iterator fan dingen dy't kinne wurde feroare yn iterators en jo wolle ien nivo fan yndireksje fuortsmite.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapping en dan flakke:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() jout in iterator werom
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Jo kinne dit ek herskriuwe yn termen fan [`flat_map()`], wat foarkar is yn dit gefal, om't it de bedoeling dúdliker oerbringe:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() jout in iterator werom
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening fuortsmyt mar ien nivo nêst tagelyk:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hjir sjogge wy dat `flatten()` gjin "deep"-flak útfiere.
    /// Ynstee wurdt mar ien nivo fan nestjen fuortsmiten.Dat is, as jo `flatten()` in trijediminsjonale array hawwe, sil it resultaat twadiminsjonaal wêze en net ien-dimensjoneel.
    /// Om in iendiminsjonale struktuer te krijen, moatte jo opnij `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Makket in iterator dy't einiget nei de earste [`None`].
    ///
    /// Nei't in iterator [`None`] werombringt, kinne future-oproppen [`Some(T)`] al of net wer opleverje.
    /// `fuse()` past in iterator oan, en soarget derfoar dat nei't [`None`] wurdt jûn, altyd [`None`] foar altyd weromkomt.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // in iterator dy't wikselt tusken Guon en Gjin
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // as it sels is, Some(i32), oars Gjin
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // wy kinne sjen dat ús iterator hinne en wer giet
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ienris fusearje wy it lykwols ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // it sil `None` altyd weromjaan nei de earste kear.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Docht wat mei elk elemint fan in iterator, de wearde trochjaan.
    ///
    /// As jo iterators brûke, sille jo faaks ferskate fan har tegearre keatelje.
    /// Wylst jo oan sa'n koade wurkje, wolle jo miskien kontrolearje wat der bart op ferskate ûnderdielen yn 'e pipeline.Om dat te dwaan, ynfoegje in oprop nei `inspect()`.
    ///
    /// It komt faker foar dat `inspect()` wurdt brûkt as debuggen ark dan te bestean yn jo definitive koade, mar applikaasjes kinne it nuttich fine yn bepaalde situaasjes as flaters moatte wurde oanmeld foardat se wurde wegere.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // dizze iteratorsekwinsje is kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // litte wy wat inspect()-oproppen tafoegje om te ûndersiikjen wat der bart
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dit sil ôfdrukke:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Fouten by it oanmelden foardat se fuortgean:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dit sil ôfdrukke:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Leint in iterator, ynstee fan it te konsumearjen.
    ///
    /// Dit is nuttich om iteratoradapters ta te passen, wylst it eigendom fan 'e orizjinele iterator noch behâldt.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // as wy iter opnij besykje te brûken, sil it net wurkje.
    /// // De folgjende regel jout "flater: gebrûk fan ferpleatste wearde: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // litte wy dat nochris besykje
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ynstee foegje wy in .by_ref() ta
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // no is dit gewoan goed:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Feroaret in iterator yn in samling.
    ///
    /// `collect()` kin alles iterabel nimme, en it yn in relevante kolleksje feroarje.
    /// Dit is ien fan 'e machtiger metoaden yn' e standertbibleteek, brûkt yn in ferskaat oan konteksten.
    ///
    /// It meast basale patroan wêryn `collect()` wurdt brûkt is om de iene kolleksje yn 'e oare te feroarjen.
    /// Jo nimme in samling, skilje [`iter`] derop, dogge in bosk transformaasjes, en dan `collect()` oan 'e ein.
    ///
    /// `collect()` kin ek eksemplaren oanmeitsje fan soarten dy't gjin typyske kolleksjes binne.
    /// In [`String`] kin bygelyks wurde boud út [`char`] s, en in iterator fan [`Result<T, E>`][`Result`]-artikels kin wurde sammele yn `Result<Collection<T>, E>`.
    ///
    /// Sjoch de hjirûnder foarbylden foar mear.
    ///
    /// Om't `collect()` sa algemien is, kin it problemen feroarsaakje mei type konklúzje.
    /// As sadanich is `collect()` ien fan 'e pear kear dat jo de syntaksis sjen dy't leafdefol bekend wurdt as de 'turbofish': `::<>`.
    /// Dit helpt it konklúzjesalgoritme spesifyk te begripen yn hokker samling jo besykje te sammeljen.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tink derom dat wy de `: Vec<i32>` oan 'e lofterkant nedich wiene.Dit komt om't wy yn plak fan bygelyks in [`VecDeque<T>`] kinne sammelje:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// De 'turbofish' brûke ynstee fan `doubled` te annotearjen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Om't `collect()` allinich soarget foar wat jo sammelje, kinne jo noch altyd in dielde hint, `_`, brûke mei de turbofisk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` brûke om in [`String`] te meitsjen:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// As jo in list hawwe mei [`Resultaat<T, E>`][`Resultaat`] s, jo kinne `collect()` brûke om te sjen as ien fan har mislearre:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // jout ús de earste flater
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // jout ús de list mei antwurden
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Ferbrûkt in iterator, makket der twa kolleksjes út.
    ///
    /// It predikaat dat wurdt oerdroegen oan `partition()` kin `true` as `false` werombringe.
    /// `partition()` jout in pear werom, alle eleminten wêr't it `true` foar weromjoech, en alle eleminten wêrfoar't it `false` weromjûn hat.
    ///
    ///
    /// Sjoch ek [`is_partitioned()`] en [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Bestelt de eleminten fan dizze iterator *op 'e nij* op neffens it opjûne predikaat, sadat al dyjingen dy't `true` werombringe al foargean dy't `false` werombringe.
    ///
    /// Jout it oantal fûn `true`-eleminten werom.
    ///
    /// De relative oarder fan partitioneare items wurdt net hanthavene.
    ///
    /// Sjoch ek [`is_partitioned()`] en [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition op plak tusken evenen en kânsen
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: moatte wy ús soargen meitsje oer de telling fan oerstreaming?De ienige manier om mear te hawwen as
        // `usize::MAX` mutabele referinsjes binne mei ZST's, dy't net nuttich binne foar partysje ...

        // Dizze sluting "factory"-funksjes besteane om generisiteit yn `Self` te foarkommen.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Fyn de earste `false` hieltyd wer en wikselje it mei de lêste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontroleart oft de eleminten fan dizze iterator binne ferdield neffens it opjûne predikaat, sadat al dyjingen dy't `true` werombringe foarôfgeane foar al dyjingen dy't `false` werombringe.
    ///
    ///
    /// Sjoch ek [`partition()`] en [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Of alle items test `true`, of de earste klaus stopet by `false`, en wy kontrolearje dat d'r gjin `true`-items mear binne.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// In iteratormetoade dy't in funksje tapast salang't se mei súkses weromkomt, en ien definitive wearde produseart.
    ///
    /// `try_fold()` nimt twa arguminten: in earste wearde, en in sluting mei twa arguminten: in 'accumulator', en in elemint.
    /// De sluting komt mei súkses werom, mei de wearde dy't de akkumulator moat hawwe foar de folgjende iteraasje, of it jout mislearring, mei in flaterwearde dy't fuortendaliks (short-circuiting) nei de beller wurdt propagearre.
    ///
    ///
    /// De earste wearde is de wearde dy't de akkumulator sil hawwe by de earste oprop.As it tapassen fan de sluting slagge is tsjin elk elemint fan 'e iterator, retourneert `try_fold()` de definitive akkumulator as sukses.
    ///
    /// Folding is handich as jo in samling fan wat hawwe, en der ien wearde fan produsearje wolle.
    ///
    /// # Opmerking foar ymplementators
    ///
    /// Ferskate fan 'e oare (forward)-metoaden hawwe standert ymplementaasjes yn termen fan dizze, dus besykje dit eksplisyt te ymplemintearjen as it wat better kin dan de ymplemintaasje fan `for`-loop.
    ///
    /// Besykje yn it bysûnder dizze oprop `try_fold()` te hawwen op 'e ynterne dielen wêrfan dizze iterator is gearstald.
    /// As meardere oproppen nedich binne, kin de `?`-operator handich wêze om de akkumulatorwearde mei-inoar te keppeljen, mar pas op foar invarianten dy't moatte wurde bewarre foardat dy betide weromkomt.
    /// Dit is in `&mut self`-metoade, dus iteraasje moat opnij wêze kinne nei't hjir in flater rekke is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de kontroleare som fan alle eleminten fan 'e array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Dizze som giet oer as it 100-elemint tafoege wurdt
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Om't it koartslacht, binne de oerbleaune eleminten noch te krijen fia de iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// In iteratormetoade dy't in feilbere funksje tapast op elk item yn 'e iterator, stoppet by de earste flater en retourneert dizze flater.
    ///
    ///
    /// Dit kin ek beskôge wurde as de feilbere foarm fan [`for_each()`] as as de steatleaze ferzje fan [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // It koartslutte, dus de oerbleaune items binne noch yn 'e iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Falt elk elemint yn in accumulator troch in operaasje ta te passen, it definitive resultaat werom te jaan.
    ///
    /// `fold()` nimt twa arguminten: in earste wearde, en in sluting mei twa arguminten: in 'accumulator', en in elemint.
    /// De sluting jout de wearde werom dy't de akkumulator moat hawwe foar de folgjende iteraasje.
    ///
    /// De earste wearde is de wearde dy't de akkumulator sil hawwe by de earste oprop.
    ///
    /// Nei it tapassen fan dizze sluting op elk elemint fan 'e iterator, jout `fold()` de akkumulator werom.
    ///
    /// Dizze operaasje wurdt soms 'reduce' as 'inject' neamd.
    ///
    /// Folding is handich as jo in samling fan wat hawwe, en der ien wearde fan produsearje wolle.
    ///
    /// Note: `fold()`, en ferlykbere metoaden dy't de heule iterator trochkringe, meie net einigje foar ûneinige iterators, sels net op traits wêrfoar in resultaat yn einige tiid te bepalen is.
    ///
    /// Note: [`reduce()`] kin brûkt wurde om it earste elemint te brûken as de earste wearde, as it akkumulatortype en artikeltype itselde is.
    ///
    /// # Opmerking foar ymplementators
    ///
    /// Ferskate fan 'e oare (forward)-metoaden hawwe standert ymplementaasjes yn termen fan dizze, dus besykje dit eksplisyt te ymplemintearjen as it wat better kin dan de ymplemintaasje fan `for`-loop.
    ///
    ///
    /// Besykje yn it bysûnder dizze oprop `fold()` te hawwen op 'e ynterne dielen wêrfan dizze iterator is gearstald.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de som fan alle eleminten fan 'e array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Litte wy hjir troch elke stap fan iteraasje rinne:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// En dus, ús definitive resultaat, `6`.
    ///
    /// It is gewoan foar minsken dy't iterators net in soad hawwe brûkt in `for`-loop te brûken mei in list mei dingen om in resultaat op te bouwen.Dy kinne wurde omset yn `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // foar loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // se binne itselde
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ferleget de eleminten ta ien, troch herhaaldelijk in ferminderende operaasje ta te passen.
    ///
    /// As de iterator leech is, jout [`None`] werom;oars jout it resultaat fan 'e reduksje werom.
    ///
    /// Foar iterators mei op syn minst ien elemint is dit itselde as [`fold()`] mei it earste elemint fan 'e iterator as de earste wearde, en elke folgjende elemint deryn falt.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Sykje de maksimale wearde:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testet as elk elemint fan 'e iterator oerienkomt mei in predikaat.
    ///
    /// `all()` nimt in sluting dy't `true` as `false` weromkomt.It jildt dizze sluting op elk elemint fan 'e iterator, en as se allegear `true` werombringe, dan docht `all()` dat ek.
    /// As ien fan harren `false` werombringt, jout it `false` werom.
    ///
    /// `all()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau't it in `false` fynt, jûn dat wat der ek bart, it resultaat ek `false` sil wêze.
    ///
    ///
    /// In lege iterator jout `true` werom.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stopje by de earste `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testet as elemint fan 'e iterator oerienkomt mei in predikaat.
    ///
    /// `any()` nimt in sluting dy't `true` as `false` weromkomt.It jildt dizze sluting op elk elemint fan 'e iterator, en as ien fan har `true` weromkomt, dan docht `any()` dat ek.
    /// As se allegear `false` werombringe, jout it `false` werom.
    ///
    /// `any()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau't it in `true` fynt, jûn dat wat der ek bart, it resultaat ek `true` sil wêze.
    ///
    ///
    /// In lege iterator jout `false` werom.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stopje by de earste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Sykje nei in elemint fan in iterator dat foldocht oan in predikaat.
    ///
    /// `find()` nimt in sluting dy't `true` of `false` weromkomt.
    /// It jildt dizze sluting op elk elemint fan 'e iterator, en as ien fan har `true` weromkomt, dan jout `find()` [`Some(element)`] werom.
    /// As se allegear `false` werombringe, jout it [`None`] werom.
    ///
    /// `find()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau as de sluting `true` weromkomt.
    ///
    /// Om't `find()` in referinsje nimt, en in protte iterators iterearje oer referinsjes, liedt dit ta in mooglik betiizjende situaasje wêr't it argumint in dûbele referinsje is.
    ///
    /// Jo kinne dit effekt sjen yn 'e foarbylden hjirûnder, mei `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopje by de earste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Tink derom dat `iter.find(f)` ekwivalint is mei `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Jildt funksje op de eleminten fan iterator en jout it earste net-gjin resultaat werom.
    ///
    ///
    /// `iter.find_map(f)` is lykweardich oan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Jildt funksje op 'e eleminten fan iterator en jout it earste wirklike resultaat as de earste flater.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Siket nei in elemint yn in iterator, wêrtroch de yndeks weromkomt.
    ///
    /// `position()` nimt in sluting dy't `true` of `false` weromkomt.
    /// It jildt dizze sluting op elk elemint fan 'e iterator, en as ien fan har `true` weromkomt, dan jout `position()` [`Some(index)`] werom.
    /// As se allegear `false` werombringe, jout it [`None`] werom.
    ///
    /// `position()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau as it in `true` fynt.
    ///
    /// # Oerstreamingsgedrach
    ///
    /// De metoade hoecht net te beskermjen tsjin oerstreamingen, dus as d'r mear dan [`usize::MAX`] net-oerienkommende eleminten binne, produseart it of it ferkearde resultaat as panics.
    ///
    /// As debug-asserts ynskeakele binne, is in panic garandearre.
    ///
    /// # Panics
    ///
    /// Dizze funksje kin panic as de iterator mear dan `usize::MAX`-eleminten hat dy't net oerienkomme.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stopje by de earste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // De weromkommende yndeks is ôfhinklik fan iteratorstatus
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Siket nei in elemint yn in iterator fanôf rjochts, en jout syn yndeks werom.
    ///
    /// `rposition()` nimt in sluting dy't `true` of `false` weromkomt.
    /// It jildt dizze sluting op elk elemint fan 'e iterator, begjinnend fan' e ein, en as ien fan har `true` weromkomt, dan jout `rposition()` [`Some(index)`] werom.
    ///
    /// As se allegear `false` werombringe, jout it [`None`] werom.
    ///
    /// `rposition()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau as it in `true` fynt.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stopje by de earste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Gjin ferlet fan in oerstreamingskontrôle hjir, om't `ExactSizeIterator` ympliseart dat it oantal eleminten past yn in `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Jout it maksimale elemint fan in iterator.
    ///
    /// As ferskate eleminten gelyk maksimaal binne, wurdt it lêste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Jout it minimale elemint fan in iterator werom.
    ///
    /// As ferskate eleminten like minimaal binne, wurdt it earste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Jout it elemint werom dat de maksimale wearde jout fan 'e oantsjutte funksje.
    ///
    ///
    /// As ferskate eleminten gelyk maksimaal binne, wurdt it lêste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Jout it elemint dat de maksimale wearde jout oangeande de oantsjutte ferlikingsfunksje.
    ///
    ///
    /// As ferskate eleminten gelyk maksimaal binne, wurdt it lêste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Jout it elemint werom dat de minimale wearde jout fan 'e oantsjutte funksje.
    ///
    ///
    /// As ferskate eleminten like minimaal binne, wurdt it earste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Jout it elemint werom dat de minimale wearde jout oangeande de oantsjutte ferlikingsfunksje.
    ///
    ///
    /// As ferskate eleminten like minimaal binne, wurdt it earste elemint weromjûn.
    /// As de iterator leech is, wurdt [`None`] weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Omkeart de rjochting fan in iterator.
    ///
    /// Meastentiids iterators iterearje fan links nei rjochts.
    /// Nei it brûken fan `rev()` sil in iterator ynstee iterearje fan rjochts nei lofts.
    ///
    /// Dit is allinich mooglik as de iterator in ein hat, dus `rev()` wurket allinich op [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konverteart in iterator fan pearen yn in pear konteners.
    ///
    /// `unzip()` ferbrûkt in heule iterator fan pearen, produsearret twa kolleksjes: ien fan 'e lofter eleminten fan' e pearen, en ien fan 'e rjochter eleminten.
    ///
    ///
    /// Dizze funksje is, yn wat sin, it tsjinoerstelde fan [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Makket in iterator dy't al har eleminten kopieart.
    ///
    /// Dit is nuttich as jo in iterator hawwe oer `&T`, mar jo hawwe in iterator oer `T` nedich.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopieare is itselde as .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Makket in iterator oan dy't [`kloon`] al syn eleminten is.
    ///
    /// Dit is nuttich as jo in iterator hawwe oer `&T`, mar jo hawwe in iterator oer `T` nedich.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // kloneare is itselde as .map(|&x| x), foar heule getallen
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Herhellet einleas in iterator.
    ///
    /// Ynstee fan stopjen by [`None`] sil de iterator ynstee opnij begjinne, fanôf it begjin.Nei iterearjen sil it opnij begjinne by it begjin.En op 'e nij.
    /// En op 'e nij.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Somt de eleminten fan in iterator op.
    ///
    /// Nimt elk elemint, foeget se byinoar, en jout it resultaat werom.
    ///
    /// In lege iterator jout de nulwearde fan it type werom.
    ///
    /// # Panics
    ///
    /// As jo `sum()` skilje en in primityf gehielstype wurdt weromjûn, sil dizze metoade panic as de berekkening oerrint en debug-asserts ynskeakele binne.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itereart oer de heule iterator, fermannichfâldigend alle eleminten
    ///
    /// In lege iterator jout de iene wearde fan it type werom.
    ///
    /// # Panics
    ///
    /// By it oproppen fan `product()` en in primityf gehielstype wurdt weromjûn, sil metoade panic wurde as de berekkening oerrint en debugbehearen binne ynskeakele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) fergeliket de eleminten fan dizze [`Iterator`] mei dy fan in oare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) fergeliket de eleminten fan dizze [`Iterator`] mei dy fan in oar oangeande de oantsjutte ferlikingsfunksje.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) fergeliket de eleminten fan dizze [`Iterator`] mei dy fan in oare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) fergeliket de eleminten fan dizze [`Iterator`] mei dy fan in oar oangeande de oantsjutte ferlikingsfunksje.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] gelyk binne oan dy fan in oar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] gelyk binne oan dy fan in oar oangeande de oantsjutte gelikensfunksje.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] ûngelikens binne mei dy fan in oar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) minder binne as dy fan in oare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) minder binne as gelyk oan dy fan in oar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) grutter binne as dy fan in oare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bepaalt as de eleminten fan dizze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) grutter binne as of gelyk oan dy fan in oar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontroleart as de eleminten fan dizze iterator binne sorteare.
    ///
    /// Dat is, foar elk elemint `a` en it folgjende elemint `b` moat `a <= b` hâlde.As de iterator presys nul as ien elemint oplevert, wurdt `true` weromjûn.
    ///
    /// Tink derom dat as `Self::Item` allinich `PartialOrd` is, mar net `Ord`, de boppesteande definysje ympliseart dat dizze funksje `false` werombringt as twa opienfolgjende items net te fergelykjen binne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontroleart as de eleminten fan dizze iterator binne sorteare mei de opjûne komparatorfunksje.
    ///
    /// Ynstee fan `PartialOrd::partial_cmp` te brûken, brûkt dizze funksje de opjûne `compare`-funksje om de oardering fan twa eleminten te bepalen.
    /// Ofsjoen fan dat, is it ekwivalint mei [`is_sorted`];sjoch de dokumintaasje foar mear ynformaasje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontroleart oft de eleminten fan dizze iterator binne sorteare mei de opjûne funksje foar ekstraksje fan kaaien.
    ///
    /// Ynstee fan 'e eleminten fan iterator direkt te fergelykjen, fergeliket dizze funksje de kaaien fan' e eleminten, lykas bepaald troch `f`.
    /// Ofsjoen fan dat, is it ekwivalint mei [`is_sorted`];sjoch de dokumintaasje foar mear ynformaasje.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Sjoch [TrustedRandomAccess]
    // De ûngewoane namme is om botsingen fan nammen yn metoadeferliening te foarkommen sjoch #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}