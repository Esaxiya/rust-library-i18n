/// In iterator dy't altyd bliuwt `None` opleverje as se útput binne.
///
/// Folgjende skilje op in fuseare iterator dy't `None` ien kear werom hat, is garandearre dat [`None`] wer weromkomt.
/// Dizze trait moat wurde ymplementeare troch alle iterators dy't har sa gedrage, om't it [`Iterator::fuse()`] kin optimisearje.
///
///
/// Note: Yn 't algemien moatte jo `FusedIterator` net yn generike grinzen brûke as jo in fuseare iterator nedich binne.
/// Ynstee moatte jo gewoan [`Iterator::fuse()`] skilje op 'e iterator.
/// As de iterator al fusearre is, sil de ekstra [`Fuse`]-wrapper in no-op wêze sûnder prestaasjestraf.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// In iterator dy't in krekte lingte rapporteart mei help fan size_hint.
///
/// De iterator rapporteart in grutte hint wêr't it of krekt is (legere grins is gelyk oan boppegrins), of de boppegrins is [`None`].
///
/// De boppegrins moat allinich [`None`] wêze as de werklike iteratorlange grutter is dan [`usize::MAX`].
/// Yn dat gefal moat de ûndergrins [`usize::MAX`] wêze, wat resulteart yn in [`Iterator::size_hint()`] fan `(usize::MAX, None)`.
///
/// De iterator moat krekt it oantal eleminten produsearje dat it rapporteart of ferskilt foardat it ein berikt.
///
/// # Safety
///
/// Dizze trait moat allinich wurde ymplementeare as it kontrakt wurdt befêstige.
/// Konsuminten fan dizze trait moatte [`Iterator::size_hint()`]’s boppegrins ynspektearje.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// In iterator dy't by it leverjen fan in artikel teminsten ien elemint sil hawwe nommen út 'e ûnderlizzende [`SourceIter`].
///
/// Belje elke metoade dy't de iterator foarút hellet, bgl
/// [`next()`] of [`try_fold()`], garandeart dat foar elke stap teminsten ien wearde fan 'e ûnderlizzende boarne fan' e iterator is ferpleatst en it resultaat fan 'e iteratorketen op syn plak koe wurde ynfoege, útgeande fan strukturele beheiningen fan' e boarne kinne sa'n ynfoeging ta.
///
/// Mei oare wurden jout dizze trait oan dat in iteratorpipeline te plak kin wurde sammele.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}