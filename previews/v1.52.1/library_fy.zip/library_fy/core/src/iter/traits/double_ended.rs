use crate::ops::{ControlFlow, Try};

/// In iterator dy't eleminten fan beide einen kin opleverje.
///
/// Iets dat `DoubleEndedIterator` ymplementeart hat ien ekstra mooglikheid oer iets dat [`Iterator`] ymplementeart: de mooglikheid om ek `Item`s fan efteren te nimmen, lykas de foarkant.
///
///
/// It is wichtich om te notearjen dat sawol hinne en wer wurkje op itselde berik, en net oerstekke: iteraasje is foarby as se yn 't midden moetsje.
///
/// Op in fergelykbere manier as it [`Iterator`]-protokol, as ien kear in `DoubleEndedIterator` [`None`] weromkomt fan in [`next_back()`], kin it opnij neamd wurde [`Some`] wer werom jaan.
/// [`next()`] en [`next_back()`] binne útwikselber foar dit doel.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Ferwideret en retourneert in elemint fan 'e ein fan' e iterator.
    ///
    /// Jout `None` werom as d'r gjin eleminten mear binne.
    ///
    /// De [trait-level]-dokuminten befetsje mear details.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// De eleminten levere troch de metoaden fan 'DoubleEndedIterator' kinne ferskille fan 'e metoaden dy't wurde levere troch [' Iterator ']' metoaden:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Befoarderet de iterator fan efteren troch `n`-eleminten.
    ///
    /// `advance_back_by` is de omkearde ferzje fan [`advance_by`].Dizze metoade sil `n`-eleminten begeare oerslaan fanôf de efterkant troch [`next_back`] oant `n` kear op te roppen oant [`None`] wurdt oantroffen.
    ///
    /// `advance_back_by(n)` sil [`Ok(())`] werombringe as de iterator mei súkses foarútgiet troch `n`-eleminten, of [`Err(k)`] as [`None`] wurdt tsjinkaam, wêr't `k` it oantal eleminten is dat de iterator foarút wurdt foardat de eleminten op binne (ie
    /// de lingte fan 'e iterator).
    /// Tink derom dat `k` altyd minder is dan `n`.
    ///
    /// `advance_back_by(0)` skilje ferbrûkt gjin eleminten en retourneert altyd [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // allinnich `&3` waard oerslein
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Jout it `n`e elemint werom fan 'e ein fan' e iterator.
    ///
    /// Dit is yn essinsje de omkearde ferzje fan [`Iterator::nth()`].
    /// Hoewol lykas de measte yndeksearjende operaasjes, begjint de telling fan nul, sadat `nth_back(0)` de earste wearde fan 'e ein weromkomt, `nth_back(1)` de twadde, ensafuorthinne.
    ///
    ///
    /// Tink derom dat alle eleminten tusken it ein en it weromkommen elemint wurde konsumeare, ynklusyf it weromkommen elemint.
    /// Dit betsjut ek dat `nth_back(0)` meardere kearen op deselde iterator skilje sil ferskate eleminten werombringe.
    ///
    /// `nth_back()` sil [`None`] werombringe as `n` grutter is as of gelyk oan 'e lingte fan' e iterator.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` meardere kearen skilje spielt de iterator net werom:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` werombringe as d'r minder dan `n + 1`-eleminten binne:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dit is de omkearde ferzje fan [`Iterator::try_fold()`]: it nimt eleminten dy't begjinne fan 'e efterkant fan' e iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Om't it koartslacht, binne de oerbleaune eleminten noch te krijen fia de iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// In iteratormetoade dy't de eleminten fan 'e iterator fermindert nei ien, definitive wearde, begjinnend fan efteren.
    ///
    /// Dit is de omkearde ferzje fan [`Iterator::fold()`]: it nimt eleminten dy't begjinne fan 'e efterkant fan' e iterator.
    ///
    /// `rfold()` nimt twa arguminten: in earste wearde, en in sluting mei twa arguminten: in 'accumulator', en in elemint.
    /// De sluting jout de wearde werom dy't de akkumulator moat hawwe foar de folgjende iteraasje.
    ///
    /// De earste wearde is de wearde dy't de akkumulator sil hawwe by de earste oprop.
    ///
    /// Nei it tapassen fan dizze sluting op elk elemint fan 'e iterator, jout `rfold()` de akkumulator werom.
    ///
    /// Dizze operaasje wurdt soms 'reduce' as 'inject' neamd.
    ///
    /// Folding is handich as jo in samling fan wat hawwe, en der ien wearde fan produsearje wolle.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de som fan alle eleminten fan in
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Dit foarbyld bout in tekenrige, begjinnend mei in begjinwearde en giet troch mei elk elemint fan 'e efterkant oant de foarkant:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Sykje nei in elemint fan in iterator fan 'e efterkant dat foldocht oan in predikaat.
    ///
    /// `rfind()` nimt in sluting dy't `true` of `false` weromkomt.
    /// It jildt dizze sluting op elk elemint fan 'e iterator, begjinnend oan' e ein, en as ien fan har `true` weromkomt, dan jout `rfind()` [`Some(element)`] werom.
    /// As se allegear `false` werombringe, jout it [`None`] werom.
    ///
    /// `rfind()` is koartsluting;mei oare wurden, it sil stopje mei ferwurkjen sa gau as de sluting `true` weromkomt.
    ///
    /// Om't `rfind()` in referinsje nimt, en in protte iterators iterearje oer referinsjes, liedt dit ta in mooglik betiizjende situaasje wêr't it argumint in dûbele referinsje is.
    ///
    /// Jo kinne dit effekt sjen yn 'e foarbylden hjirûnder, mei `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopje by de earste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // wy kinne `iter` noch brûke, om't d'r mear eleminten binne.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}