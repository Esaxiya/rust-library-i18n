/// Konverzje fan in [`Iterator`].
///
/// Troch `FromIterator` foar in type te ymplementearjen, definiearje jo hoe't it sil wurde makke fanút in iterator.
/// Dit is faak foar soarten dy't in samling fan ien of oare soarte beskriuwe.
///
/// [`FromIterator::from_iter()`] wurdt selden eksplisyt neamd, en wurdt ynstee brûkt fia [`Iterator::collect()`]-metoade.
///
/// Sjoch [`Iterator::collect()`]'s dokumintaasje foar mear foarbylden.
///
/// Sjoch ek: [`IntoIterator`].
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] brûke om `FromIterator` ymplisyt te brûken:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ymplementearje foar jo type:
///
/// ```
/// use std::iter::FromIterator;
///
/// // In foarbyldkolleksje, dat is gewoan in wrapper oer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Litte wy it wat metoaden jaan, sadat wy ien kinne oanmeitsje en der dingen oan tafoegje.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en wy sille FromIterator ymplementearje
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // No kinne wy in nije iterator meitsje ...
/// let iter = (0..5).into_iter();
///
/// // ... en meitsje der in MyCollection fan
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // sammelje ek wurken!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Makket in wearde oan fan in iterator.
    ///
    /// Sjoch de [module-level documentation] foar mear.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konverzje yn in [`Iterator`].
///
/// Troch `IntoIterator` foar in type te ymplementearjen, definiearje jo hoe't it sil wurde konvertearre nei in iterator.
/// Dit is faak foar soarten dy't in samling fan ien of oare soarte beskriuwe.
///
/// Ien foardiel fan it ymplementearjen fan `IntoIterator` is dat jo type [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) sil.
///
///
/// Sjoch ek: [`FromIterator`].
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator` ymplementearje foar jo type:
///
/// ```
/// // In foarbyldkolleksje, dat is gewoan in wrapper oer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Litte wy it wat metoaden jaan, sadat wy ien kinne oanmeitsje en der dingen oan tafoegje.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en wy sille IntoIterator ymplementearje
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // No kinne wy in nije kolleksje meitsje ...
/// let mut c = MyCollection::new();
///
/// // ... foegje der wat guod by ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... en meitsje it dan yn in Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// It is gewoan om `IntoIterator` te brûken as trait bound.Hjirmei kin it type ynfierkolleksje feroarje, salang't it noch in iterator is.
/// Oanfoljende grinzen kinne wurde oantsjutte troch te beheinen op
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// It type fan 'e eleminten dy't itereare binne.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Hokker soarte fan iterator feroarje wy dit yn?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Makket in iterator fanút in wearde.
    ///
    /// Sjoch de [module-level documentation] foar mear.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Wreidzje in samling út mei de ynhâld fan in iterator.
///
/// Iterators produsearje in searje wearden, en kolleksjes kinne ek beskôge wurde as in searje wearden.
/// De `Extend` trait brûkt dizze kleau, sadat jo in samling útwreidzje kinne troch de ynhâld fan dy iterator op te nimmen.
/// By it útwreidzjen fan in samling mei in al besteande kaai wurdt dy yngong bywurke of, yn it gefal fan kolleksjes dy't meardere yngongen tasteane mei gelikense toetsen, wurdt dizze yngong ynfoege.
///
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// // Jo kinne in tekenrige útwreidzje mei wat tekens:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ymplementearje:
///
/// ```
/// // In foarbyldkolleksje, dat is gewoan in wrapper oer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Litte wy it wat metoaden jaan, sadat wy ien kinne oanmeitsje en der dingen oan tafoegje.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // om't MyCollection in list fan i32's hat, ymplementearje wy Extend foar i32
/// impl Extend<i32> for MyCollection {
///
///     // Dit is wat ienfâldiger mei de handtekening fan it konkrete type: wy kinne útwreidzje oer alles wat kin wurde feroare yn in Iterator dy't ús i32's jout.
///     // Om't wy i32's nedich binne om yn MyCollection te setten.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // De ymplemintaasje is heul ienfâldich: loop troch de iterator, en add() elk elemint nei ússels.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // litte wy ús kolleksje útwreidzje mei noch trije nûmers
/// c.extend(vec![1, 2, 3]);
///
/// // wy hawwe dizze eleminten oan 'e ein tafoege
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Wreidet in samling út mei de ynhâld fan in iterator.
    ///
    /// Om't dit de ienige fereaske metoade is foar dizze trait, befetsje de [trait-level]-dokuminten mear details.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // Jo kinne in tekenrige útwreidzje mei wat tekens:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Wreidet in samling út mei presys ien elemint.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserveart kapasiteit yn in kolleksje foar it opjûne oantal ekstra eleminten.
    ///
    /// De standert ymplemintaasje docht neat.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}