use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objekten dy't in begryp hawwe fan *opfolger* en *foargonger* operaasjes.
///
/// De operaasje *opfolger* beweecht nei wearden dy't grutter fergelykje.
/// De operaasje *foargonger* beweecht nei wearden dy't minder fergelykje.
///
/// # Safety
///
/// Dizze trait is `unsafe` om't har ymplemintaasje korrekt moat wêze foar de feiligens fan `unsafe trait TrustedLen`-ymplementaasjes, en de resultaten fan it brûken fan dizze trait kinne oars wurde fertroud troch `unsafe`-koade om korrekt te wêzen en de neamde ferplichtingen te ferfoljen.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Jout it oantal *opfolger* stappen nedich om fan `start` nei `end` te kommen.
    ///
    /// Jout `None` werom as it oantal stappen `usize` oerfloedzje soe (of ûneinich is, of as `end` noait berikt wurde soe).
    ///
    ///
    /// # Invariants
    ///
    /// Foar elke `a`, `b` en `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` as en allinich as `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` as en allinich as `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` allinich as `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` as en allinich as `a == b`
    ///   * Tink derom dat `a <= b` _not_ betsjuttet `steps_between(&a, &b) != None`;
    ///     dit is it gefal as it mear dan `usize::MAX`-stappen nedich is om nei `b` te kommen
    /// * `steps_between(&a, &b) == None` as `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Jout de wearde werom dy't soe wurde krigen troch de *opfolger* fan `self` `count` kear te nimmen.
    ///
    /// As dit it berik wearden stipet troch `Self`, jout `None` werom.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`, `n` en `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Foar alle `a`, `n` en `m` wêr't `n + m` net oerrint:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Foar elke `a` en `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Jout de wearde werom dy't soe wurde krigen troch de *opfolger* fan `self` `count` kear te nimmen.
    ///
    /// As dit it berik wearden stipet dat wurdt stipe troch `Self`, is dizze funksje tastien panic, wrap of verzadigje.
    ///
    /// It foarstelde gedrach is oan panic as bewearingen foar debuggen ynskeakele binne, en oars ynpakke of verzadigje.
    ///
    /// Unfeilige koade moat net fertrouwe op 'e justigens fan gedrach nei oerrin.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`, `n` en `m`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Foar elke `a` en `n`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Jout de wearde werom dy't soe wurde krigen troch de *opfolger* fan `self` `count` kear te nimmen.
    ///
    /// # Safety
    ///
    /// It is net definieare gedrach foar dizze operaasje om it berik wearden te streamen dat wurdt stipe troch `Self`.
    /// As jo net kinne garandearje dat dit net oerrint, brûk dan `forward` of `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`:
    ///
    /// * as d'r `b` bestiet lykas `b > a`, is it feilich `Step::forward_unchecked(a, 1)` te skiljen
    /// * as d'r `b`, `n` bestiet sa dat `steps_between(&a, &b) == Some(n)`, is it feilich om `Step::forward_unchecked(a, m)` te skiljen foar elke `m <= n`.
    ///
    ///
    /// Foar elke `a` en `n`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::forward_unchecked(a, n)` komt oerien mei `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Jout de wearde werom dy't soe wurde krigen troch de *foargonger* fan `self` `count` kear te nimmen.
    ///
    /// As dit it berik wearden stipet troch `Self`, jout `None` werom.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`, `n` en `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Foar elke `a` en `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Jout de wearde werom dy't soe wurde krigen troch de *foargonger* fan `self` `count` kear te nimmen.
    ///
    /// As dit it berik wearden stipet dat wurdt stipe troch `Self`, is dizze funksje tastien panic, wrap of verzadigje.
    ///
    /// It foarstelde gedrach is oan panic as bewearingen foar debuggen ynskeakele binne, en oars ynpakke of verzadigje.
    ///
    /// Unfeilige koade moat net fertrouwe op 'e justigens fan gedrach nei oerrin.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`, `n` en `m`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Foar elke `a` en `n`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Jout de wearde werom dy't soe wurde krigen troch de *foargonger* fan `self` `count` kear te nimmen.
    ///
    /// # Safety
    ///
    /// It is net definieare gedrach foar dizze operaasje om it berik wearden te streamen dat wurdt stipe troch `Self`.
    /// As jo net garandearje kinne dat dit net oerrint, brûk dan `backward` of `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Foar elke `a`:
    ///
    /// * as d'r `b` bestiet lykas `b < a`, is it feilich `Step::backward_unchecked(a, 1)` te skiljen
    /// * as d'r `b`, `n` bestiet sa dat `steps_between(&b, &a) == Some(n)`, is it feilich om `Step::backward_unchecked(a, m)` te skiljen foar elke `m <= n`.
    ///
    ///
    /// Foar elke `a` en `n`, wêr't gjin oerstreaming foarkomt:
    ///
    /// * `Step::backward_unchecked(a, n)` is lykweardich oan `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Dizze wurde noch makro-generearre, om't de heule getallen letterkes oplosse nei ferskillende soarten.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // VEILIGHEID: de beller moat garandearje dat `start + n` net oerrint.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // VEILIGHEID: de beller moat garandearje dat `start - n` net oerrint.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Aktivearje in panic by oerstreaming yn debug-builds.
            // Dit moat folslein optimalisearje yn release builds.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Wiskunde dwaan wikkelje om bgl `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Aktivearje in panic by oerstreaming yn debug-builds.
            // Dit moat folslein optimalisearje yn release builds.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Wiskunde dwaan wikkelje om bgl `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dit fertrout op $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // as n bûten it berik is, is `unsigned_start + n` ek
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // as n bûten it berik is, is `unsigned_start - n` ek
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dit fertrout op $i_narrower <=usize
                        //
                        // Gieten nei isize wreidet de breedte út, mar behâldt it teken.
                        // Brûk wrapping_sub yn isize romte en cast om gebrûk te meitsjen om it ferskil te berekkenjen dat miskien net past binnen it berik fan isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Ynpakken behannelet gefallen lykas `Step::forward(-120_i8, 200) == Some(80_i8)`, hoewol 200 bûten it berik is foar i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Tafoeging oerstreamd
                            }
                        }
                        // As n bûten it berik is fan bg
                        // u8, dan is it grutter dan it heule berik foar i8 breed is, sadat `any_i8 + n` needsaaklikerwize i8 oerrint.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Ynpakken behannelet gefallen lykas `Step::forward(-120_i8, 200) == Some(80_i8)`, hoewol 200 bûten it berik is foar i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Subtraksje oerstreamd
                            }
                        }
                        // As n bûten it berik is fan bg
                        // u8, dan is it grutter dan it heule berik foar i8 breed is, sadat `any_i8 - n` needsaaklikerwize i8 oerrint.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // As it ferskil te grut is foar bg
                            // i128, it sil ek te grut wêze foar gebrûk mei minder bits.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // VEILIGHEID: res is in jildige skalaar foar unicode
            // (ûnder 0x110000 en net yn 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // VEILIGHEID: res is in jildige skalaar foar unicode
        // (ûnder 0x110000 en net yn 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VEILIGHEID: de beller moat garandearje dat dit net oerrint
        // it berik wearden foar in kar.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // VEILIGHEID: de beller moat garandearje dat dit net oerrint
            // it berik wearden foar in kar.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // VEILIGHEID: fanwegen it foarige kontrakt is dit garandearre
        // troch de beller in jildich kar te wêzen.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VEILIGHEID: de beller moat garandearje dat dit net oerrint
        // it berik wearden foar in kar.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // VEILIGHEID: de beller moat garandearje dat dit net oerrint
            // it berik wearden foar in kar.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // VEILIGHEID: fanwegen it foarige kontrakt is dit garandearre
        // troch de beller in jildich kar te wêzen.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // VEILIGHEID: krekt kontroleare foarwearde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // VEILIGHEID: krekt kontroleare foarwearde
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Dizze makro's generearje `ExactSizeIterator`-impls foar ferskate beriksoarten.
//
// * `ExactSizeIterator::len` is ferplichte om altyd in krekte `usize` werom te jaan, sadat gjin berik langer kin wêze dan `usize::MAX`.
//
// * Foar gehielstypen yn `Range<_>` is dit it gefal foar typen smeller dan of sa breed as `usize`.
//   Foar gehielstypen yn `RangeInclusive<_>` is dit it gefal foar typen *strikt smeller* dan `usize` sûnt bgl
//   `(0..=u64::MAX).len()` soe `u64::MAX + 1` wêze.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Dizze binne ûnkorrekt neffens de hjirboppe redenen, mar se fuortsmite soe in brekende feroaring wêze as se waarden stabilisearre yn Rust 1.0.0.
    // Dus bgl
    // `(0..66_000_u32).len()` sil bygelyks sûnder flater of warskôgingen kompilearje op 16-bit platfoarms, mar trochgean in ferkeard resultaat te jaan.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Dizze binne ûnkorrekt neffens de hjirboppe redenen, mar se fuortsmite soe in brekende feroaring wêze as se waarden stabilisearre yn Rust 1.26.0.
    // Dus bgl
    // `(0..=u16::MAX).len()` sil bygelyks sûnder flater of warskôgingen kompilearje op 16-bit platfoarms, mar trochgean in ferkeard resultaat te jaan.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // VEILIGHEID: krekt kontroleare foarwearde
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // VEILIGHEID: krekt kontroleare foarwearde
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VEILIGHEID: krekt kontroleare foarwearde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VEILIGHEID: krekt kontroleare foarwearde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VEILIGHEID: krekt kontroleare foarwearde
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VEILIGHEID: krekt kontroleare foarwearde
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}