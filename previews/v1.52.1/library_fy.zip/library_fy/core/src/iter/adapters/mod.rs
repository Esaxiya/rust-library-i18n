use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Dizze trait biedt transitive tagong ta boarne-poadium yn in interator-adapter pipeline ûnder de betingsten dy't
/// * de iteratorboarne `S` sels ymplementeart `SourceIter<Source = S>`
/// * d'r is in delegearjende ymplemintaasje fan dizze trait foar elke adapter yn 'e pipeline tusken de boarne en de pipeline-konsumint.
///
/// As de boarne in iterator-struktuer is (faaks `IntoIter` neamd), dan kin dit nuttich wêze foar spesjalisaasje fan [`FromIterator`]-ymplementaasjes of de oerbleaune eleminten weromhelje nei't in iterator foar in part útput is.
///
///
/// Tink derom dat ymplementaasjes net needsaaklik tagong hawwe moatte ta de binnenste boarne fan in pipeline.In stateful tuskentiidse adapter kin in diel fan 'e pipeline graach iverje en de ynterne opslach as boarne bleatstelle.
///
/// De trait is ûnfeilich om't ymplementearders ekstra befeiligingseigenskippen moatte hanthavenje.
/// Sjoch [`as_inner`] foar details.
///
/// # Examples
///
/// In diels konsumearre boarne ophelje:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// In boarnestadium yn in iterator-pipeline.
    type Source: Iterator;

    /// Untfange de boarne fan in iterator-pipeline.
    ///
    /// # Safety
    ///
    /// Ymplementaasjes fan moatte deselde mutabele referinsje foar har libben weromjaan, útsein as se wurde ferfongen troch in beller.
    /// Bellers meie de referinsje allinich ferfange as se iteraasje stopten en de iterator-pipeline falle nei it útpakke fan 'e boarne.
    ///
    /// Dit betsjut dat iteratoradapters kinne fertrouwe op 'e boarne dy't net feroaret by iteraasje, mar se kinne der net op fertrouwe yn har Drop-ymplementaasjes.
    ///
    /// It ymplementearjen fan dizze metoade betsjuttet dat adapters tagong hawwe ta privee-tagong ta har boarne en kinne allinich fertrouwe op garânsjes makke op basis fan metoade-ûntfanger-typen.
    /// It ûntbrekken fan beheinde tagong fereasket ek dat adapters de iepenbiere API fan 'e boarne moatte hanthavenje, sels as se tagong hawwe ta har yntern.
    ///
    /// Bellers moatte op har beurt ferwachtsje dat de boarne yn elke steat sil wêze dy't konsistint is mei har iepenbiere API, om't adapters tusken har en de boarne deselde tagong hawwe.
    /// Benammen in adapter kin mear eleminten hawwe konsumeare dan strikt nedich.
    ///
    /// It algemiene doel fan dizze easken is om de konsumint fan in pipeline gebrûk te meitsjen
    /// * wat bliuwt yn 'e boarne neidat iteraasje is stoppe
    /// * it ûnthâld dat net brûkt is troch it befoarderjen fan in konsumearjende iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// In iteratoradapter dy't útfier produseart salang't de ûnderlizzende iterator `Result::Ok`-wearden produseart.
///
///
/// As in flater is tsjinkaam, stopt de iterator en wurdt de flater opslein.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Ferwurkje de opjûne iterator as soe it in `T` opleverje ynstee fan in `Result<T, _>`.
/// Eltse flaters sille de ynterne iterator stopje en it algemiene resultaat sil in flater wêze.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}