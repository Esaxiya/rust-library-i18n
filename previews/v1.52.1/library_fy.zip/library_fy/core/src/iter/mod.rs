//! Komposearbere eksterne iteraasje.
//!
//! As jo josels hawwe fûn mei in samling fan ien of oare soarte, en nedich binne om in operaasje út te fieren op 'e eleminten fan' e neamde kolleksje, sille jo 'iterators' gau rinne.
//! Iterators wurde heul brûkt yn idiomatyske Rust-koade, dus it is de muoite wurdich mei har bekend te wurden.
//!
//! Foardat wy mear útlizze, litte wy prate oer hoe't dizze module is struktureare:
//!
//! # Organization
//!
//! Dizze module is foar in grut part organisearre troch type:
//!
//! * [Traits] binne it kearndiel: dizze traits bepale hokker soarte iterators besteane en wat jo dermei kinne dwaan.De metoaden fan dizze traits binne it wurdich om wat ekstra stúdzjetiid yn te stekken.
//! * [Functions] leverje wat nuttige manieren om guon basale iterators te meitsjen.
//! * [Structs] binne faak de returtypes fan 'e ferskate metoaden op' e traits fan dizze module.Jo wolle normaalwei nei de metoade sjen dy't de `struct` makket, yn stee fan de `struct` sels.
//! Foar mear details oer wêrom, sjoch '[Implementing Iterator](#implement-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dat is it!Litte wy grave yn iterators.
//!
//! # Iterator
//!
//! It hert en de siel fan dizze module is de [`Iterator`] trait.De kearn fan [`Iterator`] sjocht der sa út:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! In iterator hat in metoade, [`next`], dy't as se wurdt neamd, in [`Opsje`] werom '<Item>`.
//! [`next`] sil [`Some(Item)`] weromjaan salang't der eleminten binne, en as se allegear útput binne, sil `None` weromkomme om oan te jaan dat iteraasje klear is.
//! Yndividuele iterators kinne der foar kieze om werhelling te hervatten, en sa kin [`next`] opnij belje, miskien wol of net úteinlik opnij begjinne mei [`Some(Item)`] werom te jaan (sjoch [`TryIter`] bygelyks).
//!
//!
//! De folsleine definysje fan [`Iterator`] befettet ek in oantal oare metoaden, mar se binne standertmetoaden, boud boppe op [`next`], en dus krije jo se fergees.
//!
//! Iterators binne ek komposearber, en it is gewoan om se mei-inoar te keppeljen om kompleksere foarmen fan ferwurking te dwaan.Sjoch de seksje [Adapters](#adapters) hjirûnder foar mear details.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # De trije foarmen fan iteraasje
//!
//! D'r binne trije mienskiplike metoaden dy't iterators kinne meitsje út in samling:
//!
//! * `iter()`, dy't itereart oer `&T`.
//! * `iter_mut()`, dy't itereart oer `&mut T`.
//! * `into_iter()`, dy't itereart oer `T`.
//!
//! Ferskate dingen yn 'e standertbibleteek kinne ien as mear fan' e trije implementearje, wêr't passend.
//!
//! # Iterator útfiere
//!
//! In eigen iterator meitsje makket twa stappen: in `struct` oanmeitsje om de steat fan 'e iterator te hâlden, en dan [`Iterator`] út te fieren foar dy `struct`.
//! Dit is wêrom d'r yn dizze module safolle `struct`s binne: d'r is ien foar elke iterator en iteratoradapter.
//!
//! Litte wy in iterator meitsje mei de namme `Counter` dy't telt fan `1` oant `5`:
//!
//! ```
//! // Earst de struktuer:
//!
//! /// In iterator dy't telt fan ien oant fiif
//! struct Counter {
//!     count: usize,
//! }
//!
//! // wy wolle dat ús telling by ien begjint, dus litte wy in new()-metoade tafoegje om te helpen.
//! // Dit is net strikt nedich, mar is handich.
//! // Tink derom dat wy `count` op nul begjinne, sille wy sjen wêrom yn `next()`'s-ymplemintaasje hjirûnder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dan ymplementearje wy `Iterator` foar ús `Counter`:
//!
//! impl Iterator for Counter {
//!     // wy sille telle mei usize
//!     type Item = usize;
//!
//!     // next() is de ienige fereaske metoade
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ferheegje ús telling.Dit is wêrom't wy op nul begûnen.
//!         self.count += 1;
//!
//!         // Kontrolearje om te sjen as wy klear binne mei tellen of net.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // En no kinne wy it brûke!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Op dizze manier [`next`] neame wurdt repetitive.Rust hat in konstruksje dat [`next`] kin skilje op jo iterator, oant it `None` berikt.Litte wy dat folgje.
//!
//! Tink derom dat `Iterator` in standert ymplemintaasje biedt fan metoaden lykas `nth` en `fold` dy't `next` yntern skilje.
//! It is lykwols ek mooglik in oanpaste ymplemintaasje fan metoaden lykas `nth` en `fold` te skriuwen as in iterator se effisjinter kin berekkenje sûnder `next` te skiljen.
//!
//! # `for` loops en `IntoIterator`
//!
//! De `for`-loop-syntaksis fan Rust is eins sûker foar iterators.Hjir is in basisfoarbyld fan `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dit sil de nûmers ien oant fiif ôfdrukke, elk op har eigen rigel.Mar jo sille hjir wat fernimme: wy hawwe nea wat op ús vector neamd om in iterator te meitsjen.Wat jout?
//!
//! D'r is in trait yn 'e standertbibleteek foar it konvertearjen fan wat yn in iterator: [`IntoIterator`].
//! Dizze trait hat ien metoade, [`into_iter`], dy't it ding dat [`IntoIterator`] útfiert konverteart yn in iterator.
//! Litte wy opnij sjen nei dy `for`-loop, en wat de kompilear it konverteart yn:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-suiker dit yn:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Earst neame wy `into_iter()` op 'e wearde.Dan passe wy op 'e iterator dy't weromkomt, en roppe [`next`] hieltyd wer oant wy in `None` sjogge.
//! Op dat punt binne wy `break` út 'e loop, en wy binne iterearjen dien.
//!
//! D'r is hjir noch in subtile bit: de standertbibleteek befettet in nijsgjirrige ymplemintaasje fan [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Mei oare wurden, alle [`Iterator`] s implementearje [`IntoIterator`], troch gewoan sels werom te jaan.Dit betsjut twa dingen:
//!
//! 1. As jo in [`Iterator`] skriuwe, kinne jo dizze brûke mei in `for`-loop.
//! 2. As jo in kolleksje oanmeitsje, sil [`IntoIterator`] dêrfoar útfiere, dat jo kolleksje kin wurde brûkt mei de `for`-loop.
//!
//! # Iterearje troch referinsje
//!
//! Sûnt [`into_iter()`] nimt `self` op wearde, konsumeart it gebrûk fan in `for`-loop om iterearjen oer in samling.Faak kinne jo iterearje oer in samling sûnder it te konsumearjen.
//! In protte kolleksjes biede metoaden dy't iterators leverje oer referinsjes, konvinsjoneel neamd respektivelik `iter()` en `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` is noch altyd eigendom fan dizze funksje.
//! ```
//!
//! As in samlingstype `C` `iter()` leveret, ymplementeart it normaal ek `IntoIterator` foar `&C`, mei in ymplemintaasje dy't gewoan `iter()` neamt.
//! Likegoed ymplementeart in samling `C` dy't `iter_mut()` leveret `IntoIterator` algemien foar `&mut C` troch te delegearjen nei `iter_mut()`.Dit makket in handige ôfkoarte mooglik:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // itselde as `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // itselde as `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Wylst in protte kolleksjes `iter()` oanbiede, biede net allegear `iter_mut()`.
//! Bygelyks mutaasje fan de kaaien fan in [`HashSet<T>`] of [`HashMap<K, V>`] kin de kolleksje yn in inkonsekwente steat sette as de kaaihash feroaret, sadat dizze kolleksjes allinich `iter()` oanbiede.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funksjes dy't in [`Iterator`] nimme en in oare [`Iterator`] werombringe wurde faak 'iteratoradapters' neamd, om't se in foarm binne fan 'adapter'
//! pattern'.
//!
//! Gewoane iterator-adapters omfetsje [`map`], [`take`], en [`filter`].
//! Foar mear, sjoch har dokumintaasje.
//!
//! As in iteratoradapter panics, sil de iterator yn in net oantsjutte (mar ûnthâldfeilige) steat wêze.
//! Dizze steat is ek net garandearre om itselde te bliuwen oer ferzjes fan Rust, dus jo moatte foarkomme dat jo net fertrouwe op 'e krekte wearden weromjûn troch in iterator dy't yn panyk kaam.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (en iterator [adapters](#adapters)) binne *lui*. Dit betsjut dat gewoan it meitsjen fan in iterator _do_ net in soad makket. Neat bart echt oant jo [`next`] skilje.
//! Dit is soms in boarne fan betizing by it meitsjen fan in iterator allinich foar har side-effekten.
//! Bygelyks, de [`map`]-metoade neamt in sluting op elk elemint dat it werhellet:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dit sil gjin wearden ôfdrukke, om't wy allinich in iterator hawwe makke, yn stee fan it te brûken.De gearstaller sil ús warskôgje oer dit soarte fan gedrach:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! De idiomatyske manier om in [`map`] te skriuwen foar syn side-effekten is in `for`-loop te brûken of de [`for_each`]-metoade te neamen:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! In oare algemiene manier om in iterator te evaluearjen is de [`collect`]-metoade te brûken om in nije kolleksje te meitsjen.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators hoege net einich te wêzen.As foarbyld is in iepen ein berik in ûneinige iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! It is gewoan om de [`take`] iteratoradapter te brûken om in ûneinige iterator yn in einige te meitsjen:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dit sil de nûmers `0` oant `4` ôfdrukke, elk op har eigen rigel.
//!
//! Tink derom dat metoaden op ûneinige iterators, sels dyen wêr't in resultaat wiskundich yn einige tiid kin wurde bepaald, miskien net beëindigje.
//! Spesifyk sille metoaden lykas [`min`], dy't yn 't algemiene gefal fereaskje dat elk elemint yn' e iterator fereasket, wierskynlik net suksesfol weromkomme foar elke ûneinige iterators.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh nee!In ûneinige loop!
//! // `ones.min()` feroarsaket in ûneinige loop, dat wy sille dit punt net berikke!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;