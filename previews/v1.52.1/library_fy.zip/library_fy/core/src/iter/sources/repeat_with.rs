use crate::iter::{FusedIterator, TrustedLen};

/// Makket in nije iterator dy't eleminten fan it type `A` einleas herhellet troch de oanbeane sluting, de repeater, oan te passen, `F: FnMut() -> A`.
///
/// De `repeat_with()`-funksje neamt de repeater hieltyd wer.
///
/// Einleaze iterators lykas `repeat_with()` wurde faak brûkt mei adapters lykas [`Iterator::take()`], om se einich te meitsjen.
///
/// As it elemtype fan 'e iterator dy't jo nedich hawwe [`Clone`] ymplementeart, en it is OK om it boarne-elemint yn it ûnthâld te hâlden, moatte jo ynstee de [`repeat()`]-funksje brûke.
///
///
/// In iterator produsearre troch `repeat_with()` is gjin [`DoubleEndedIterator`].
/// As jo `repeat_with()` nedich binne om in [`DoubleEndedIterator`] werom te jaan, iepenje asjebleaft in GitHub-útjefte mei útlis oer jo gebrûk.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::iter;
///
/// // litte wy oannimme dat wy wat wearde hawwe fan in type dat net `Clone` is of dy't noch net yn it ûnthâld wolle hawwe, om't it djoer is:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // in bepaalde wearde foar altyd:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutaasje brûke en einich gean:
///
/// ```rust
/// use std::iter;
///
/// // Fan 'e nulle oant de tredde krêft fan twa:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... en no binne wy klear
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// In iterator dy't eleminten fan it type `A` einleas herhellet troch de oanbeane sluting `F: FnMut() -> A` oan te passen.
///
///
/// Dizze `struct` is makke troch de funksje [`repeat_with()`].
/// Sjoch de dokumintaasje foar mear.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}