use crate::fmt;

/// Makket in nije iterator wêr't elke iteraasje de levere sluting `F: FnMut() -> Option<T>` neamt.
///
/// Hjirmei kinne jo in oanpaste iterator oanmeitsje mei elk gedrach sûnder de mear útwreide syntaksis te brûken om in tawijd type te meitsjen en de [`Iterator`] trait derfoar te ymplementearjen.
///
/// Tink derom dat de `FromFn`-iterator gjin útgongspunten makket oer it gedrach fan 'e sluting, en dêrom [`FusedIterator`] konservatyf net ymplementeart, of [`Iterator::size_hint()`] oerskriuwt fan syn standert `(0, None)`.
///
///
/// De sluting kin opnames en har omjouwing brûke om steat te folgjen oer werhellingen.Ofhinklik fan hoe't iterator wurdt brûkt, kin dit nedich wêze om it [`move`]-kaaiwurd op te jaan op 'e sluting.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Litte wy de counter-iterator fan [module-level documentation] opnij ymplementearje:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Ferheegje ús telling.Dit is wêrom't wy op nul begûnen.
///     count += 1;
///
///     // Kontrolearje om te sjen as wy klear binne mei tellen of net.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// In iterator wêr't elke iteraasje de ferskafte sluting `F: FnMut() -> Option<T>` neamt.
///
/// Dizze `struct` is makke troch de funksje [`iter::from_fn()`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}