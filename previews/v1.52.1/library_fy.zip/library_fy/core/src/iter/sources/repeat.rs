use crate::iter::{FusedIterator, TrustedLen};

/// Makket in nije iterator oan dy't einleas ien elemint einiget.
///
/// De `repeat()`-funksje werhellet ien inkelde wearde hieltyd wer.
///
/// Einleaze iterators lykas `repeat()` wurde faak brûkt mei adapters lykas [`Iterator::take()`], om se einich te meitsjen.
///
/// As it elemtype fan 'e iterator dy't jo nedich hawwe gjin `Clone` ymplementeart, of as jo it werhelle elemint net yn it ûnthâld wolle bewarje, kinne jo ynstee de [`repeat_with()`]-funksje brûke.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::iter;
///
/// // it nûmer fjouwer 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, noch fjouwer
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Finite gean mei [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // dat lêste foarbyld wie tefolle fjouweren.Litte wy mar fjouwer fjouwer hawwe.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... en no binne wy klear
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// In iterator dy't in elemint einleas herhellet.
///
/// Dizze `struct` is makke troch de funksje [`repeat()`].Sjoch de dokumintaasje foar mear.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}