use crate::iter::{FusedIterator, TrustedLen};

/// Makket in iterator oan dy't in elemint presys ien kear oplevert.
///
/// Dit wurdt faak brûkt om ien wearde oan te passen yn in [`chain()`] fan oare soarten iteraasje.
/// Miskien hawwe jo in iterator dy't hast alles behannelt, mar jo hawwe in ekstra spesjaal gefal nedich.
/// Miskien hawwe jo in funksje dy't wurket op iterators, mar jo hoege mar ien wearde te ferwurkjen.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::iter;
///
/// // ien is it iensumste getal
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mar ien, dat is alles wat wy krije
/// assert_eq!(None, one.next());
/// ```
///
/// Keatling tegearre mei in oare iterator.
/// Litte we sizze dat wy iterearje wolle oer elke bestân fan 'e `.foo`-map, mar ek in konfiguraasjetriem,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // wy moatte konvertearje fan in iterator fan DirEntry-s nei in iterator fan PathBufs, dus wy brûke kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // no, ús iterator gewoan foar ús konfiguraasjetriem
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // keatelje de twa iterators tegearre yn ien grutte iterator
/// let files = dirs.chain(config);
///
/// // dit sil ús alle bestannen yn .foo en ek .foorc jaan
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// In iterator dy't presys ien kear in elemint oplevert.
///
/// Dizze `struct` is makke troch de funksje [`once()`].Sjoch de dokumintaasje foar mear.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}