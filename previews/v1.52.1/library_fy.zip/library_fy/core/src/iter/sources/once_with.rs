use crate::iter::{FusedIterator, TrustedLen};

/// Makket in iterator dy't lui in wearde presys ien kear genereart troch de opjûne sluting op te roppen.
///
/// Dit wurdt faak brûkt om in ienweardegenerator oan te passen yn in [`chain()`] fan oare soarten iteraasje.
/// Miskien hawwe jo in iterator dy't hast alles behannelt, mar jo hawwe in ekstra spesjaal gefal nedich.
/// Miskien hawwe jo in funksje dy't wurket op iterators, mar jo hoege mar ien wearde te ferwurkjen.
///
/// Oars as [`once()`] sil dizze funksje lui de wearde op oanfraach generearje.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::iter;
///
/// // ien is it iensumste getal
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mar ien, dat is alles wat wy krije
/// assert_eq!(None, one.next());
/// ```
///
/// Keatling tegearre mei in oare iterator.
/// Litte we sizze dat wy iterearje wolle oer elke bestân fan 'e `.foo`-map, mar ek in konfiguraasjetriem,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // wy moatte konvertearje fan in iterator fan DirEntry-s nei in iterator fan PathBufs, dus wy brûke kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // no, ús iterator gewoan foar ús konfiguraasjetriem
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // keatelje de twa iterators tegearre yn ien grutte iterator
/// let files = dirs.chain(config);
///
/// // dit sil ús alle bestannen yn .foo en ek .foorc jaan
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// In iterator dy't in inkeld elemint fan it type `A` oplevert troch de oanbeane sluting `F: FnOnce() -> A` oan te passen.
///
///
/// Dizze `struct` is makke troch de funksje [`once_with()`].
/// Sjoch de dokumintaasje foar mear.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}