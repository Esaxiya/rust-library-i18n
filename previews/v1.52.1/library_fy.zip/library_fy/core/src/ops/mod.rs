//! Overloadbere operators.
//!
//! Mei it útfieren fan dizze traits kinne jo beskate operators oerladen.
//!
//! Guon fan dizze traits wurde ymporteare troch de prelude, sadat se te krijen binne yn elk Rust-programma.Allinich operators stipe troch traits kinne wurde oerladen.
//! Bygelyks, de tafoegingsoperator (`+`) kin oerladen wurde fia de [`Add`] trait, mar om't de opdrachtbehearder (`=`) gjin stipe trait hat, is d'r gjin manier om syn semantyk te oerladen.
//! Derneist biedt dizze module gjin meganisme om nije operators te meitsjen.
//! As traitleaze oerbelesting of oanpaste operators nedich binne, moatte jo sjen nei makro's of kompilear-plugins om de syntaksis fan Rust út te wreidzjen.
//!
//! Ymplementaasjes fan operator traits moatte yn har ûnderskate konteksten net ferrassend wêze, mei it betinken fan har gewoane betsjuttingen en [operator precedence].
//! Bygelyks by it ymplementearjen fan [`Mul`] moat de operaasje wat oerienkomst hawwe mei multiplikaasje (en diele ferwachte eigenskippen lykas assosjativiteit).
//!
//! Tink derom dat de `&&`-en `||`-operators kortsluten, dat se evaluearje har twadde operand allinich as it bydraacht oan it resultaat.Om't dit gedrach net útfierber is troch traits, wurde `&&` en `||` net stipe as oerlêstbere operators.
//!
//! In protte fan 'e operators nimme har operands op wearde.Yn net-generike konteksten mei ynboude typen is dit normaal gjin probleem.
//! It brûken fan dizze operators yn generike koade freget lykwols wat oandacht as wearden moatte wurde opnij brûkt yn tsjinstelling ta it litten fan 'e operators.Ien opsje is om sa no en dan [`clone`] te brûken.
//! In oare opsje is te fertrouwen op 'e belutsen soarten dy't ekstra operatorimplementaasjes leverje foar referinsjes.
//! Bygelyks foar in brûker-definieare type `T` dy't supposjeare moat stypje, is it wierskynlik in goed idee om sawol `T` as `&T` de traits [`Add<T>`][`Add`] en [`Add<&T>`][`Add`] te ymplementearjen, sadat generike koade kin wurde skreaun sûnder ûnnedige kloning.
//!
//!
//! # Examples
//!
//! Dit foarbyld makket in `Point`-struktuer dy't [`Add`] en [`Sub`] ymplementeart, en dan toant tafoegjen en subtraksje fan twa `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Sjoch de dokumintaasje foar elke trait foar in foarbyldútfiering.
//!
//! De [`Fn`], [`FnMut`] en [`FnOnce`] traits wurde ymplementeare troch soarten dy't kinne wurde oproppen as funksjes.Tink derom dat [`Fn`] `&self` nimt, [`FnMut`] `&mut self` nimt en [`FnOnce`] `self` nimt.
//! Dizze komme oerien mei de trije soarten metoaden dy't kinne wurde oproppen op in eksimplaar: call-by-reference, call-by-mutable-reference, en call-by-value.
//! It meast foarkommende gebrûk fan dizze traits is om te fungearjen as grinzen foar funksjes op heger nivo dy't funksjes as slutingen nimme as arguminten.
//!
//! In [`Fn`] nimme as parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! In [`FnMut`] nimme as parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! In [`FnOnce`] nimme as parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ferbrûkt de opnommen fariabelen, sadat it net mear dan ien kear kin wurde rinne
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Besykje `func()` opnij oan te roppen smyt in `use of moved value`-flater foar `func` op
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kin op dit punt net mear oproppen wurde
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;