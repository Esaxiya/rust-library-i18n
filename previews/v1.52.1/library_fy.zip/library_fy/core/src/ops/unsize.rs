use crate::marker::Unsize;

/// Trait dat oanjout dat dit in oanwizer is of in wrapper foar ien, wêr't unsizing kin wurde útfierd op 'e pointee.
///
/// Sjoch de [DST coercion RFC][dst-coerce] en [the nomicon entry on coercion][nomicon-coerce] foar mear details.
///
/// Foar ynboude oanwizerssoarten sille oanwizers nei `T` twinge nei oanwizers nei `U` as `T: Unsize<U>` troch te konvertearjen fan in tinne oanwizer nei in dikke oanwizer.
///
/// Foar oanpaste typen wurket de twang hjir troch `Foo<T>` nei `Foo<U>` te twingen, mits in ympl fan `CoerceUnsized<Foo<U>> for Foo<T>` bestiet.
/// Sa'n impl kin allinich wurde skreaun as `Foo<T>` mar ien inkeld net-phantomdata fjild hat mei `T`.
/// As it type fan dat fjild `Bar<T>` is, moat in ymplemintaasje fan `CoerceUnsized<Bar<U>> for Bar<T>` bestean.
/// De twang sil wurkje troch it `Bar<T>`-fjild yn `Bar<U>` te twingen en de rest fan 'e fjilden yn te foljen fan `Foo<T>` om in `Foo<U>` te meitsjen.
/// Dit sil effektyf nei in oanwizerfjild boarje en dat twinge.
///
/// Yn 't algemien sille jo foar smart pointers `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ymplementearje, mei in opsjonele `?Sized` bûn oan `T` sels.
/// Foar wrapper-typen dy't `T` direkt as `Cell<T>` en `RefCell<T>` ynbêde, kinne jo `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` direkt ymplementearje.
///
/// Hjirmei kinne twang fan soarten lykas `Cell<Box<T>>` wurkje.
///
/// [`Unsize`][unsize] wurdt brûkt om soarten te markearjen dy't kinne wurde twongen oan DST's as efter oanwizings.It wurdt automatysk ymplementeare troch de gearstaller.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *konst T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dit wurdt brûkt foar feiligens fan objekten om te kontrolearjen dat it ûntfangerstype fan in metoade kin wurde ferstjoerd.
///
/// In foarbyld ymplemintaasje fan 'e trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *konst T->* konst U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}