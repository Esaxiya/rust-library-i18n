use crate::marker::Unpin;
use crate::pin::Pin;

/// It resultaat fan in hervatting fan generator.
///
/// Dit enum wurdt weromjûn fan 'e `Generator::resume`-metoade en jout de mooglike weromwearden fan in generator oan.
/// Op it stuit komt dit oerien mei of in ophingpunt (`Yielded`) as in einpunt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// De generator ophong mei in wearde.
    ///
    /// Dizze steat jout oan dat in generator is skorst, en typysk komt oerien mei in `yield`-ferklearring.
    /// De wearde levere yn dizze fariant komt oerien mei de útdrukking dy't wurdt oerdroegen oan `yield` en makket it mooglik generators in wearde te jaan elke kear as se opleverje.
    ///
    ///
    Yielded(Y),

    /// De generator foltôge mei in retoerwearde.
    ///
    /// Dizze steat jout oan dat in generator de útfiering hat ôfmakke mei de opjûne wearde.
    /// Sadree't in generator `Complete` hat weromjûn, wurdt it beskôge as in programmafout om `resume` opnij te skiljen.
    ///
    Complete(R),
}

/// De trait ymplementearre troch ynboude generatortypen.
///
/// Generators, ek wol coroutines neamd, binne op it stuit in eksperimintele taalfunksje yn Rust.
/// Tafoege yn [RFC 2033]-generators binne op it stuit bedoeld om foaral in boustien te leverjen foar async/await-syntaksis, mar sille wierskynlik útwreidzje nei ek in ergonomyske definysje foar iterators en oare primitiven.
///
///
/// De syntaksis en semantyk foar generators is ynstabyl en sil in fierdere RFC nedich wêze foar stabilisaasje.Op dit stuit is de syntaksis lykwols sluting-lykas:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mear dokumintaasje fan generators kin wurde fûn yn it ynstabile boek.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// It type wearde dat dizze generator oplevert.
    ///
    /// Dit assosjeare type komt oerien mei de `yield`-ekspresje en de wearden dy't elke kear weromkomme meie as in generator jout.
    ///
    /// Bygelyks in iterator-as-a-generator soe dit type wierskynlik hawwe as `T`, it type wurdt itereare.
    ///
    type Yield;

    /// It type wearde dat dizze generator jout.
    ///
    /// Dit komt oerien mei it type weromjûn fan in generator mei in `return`-ferklearring as ymplisyt as de lêste útdrukking fan in generator letterlik.
    /// Bygelyks futures soe dit brûke as `Result<T, E>`, om't it in foltôge future fertsjintwurdiget.
    ///
    ///
    type Return;

    /// Ferfangt de útfiering fan dizze generator.
    ///
    /// Dizze funksje sil de útfiering fan 'e generator hervetsje of de útfiering begjinne as dizze noch net is.
    /// Dizze oprop sil weromkomme yn it lêste ophingpunt fan 'e generator, en sil de útfiering fan' e lêste `yield` opnij opnimme.
    /// De generator sil trochgean mei útfieren oant hy opbringt of weromkomt, op hokker punt dizze funksje weromkomt.
    ///
    /// # Weromwearde
    ///
    /// It `GeneratorState`-enum werom fan dizze funksje jout oan yn hokker steat de generator is by weromkomst.
    /// As de `Yielded`-fariant wurdt weromjûn, hat de generator in ophingpunt berikt en is in wearde útjûn.
    /// Generators yn dizze steat binne op in letter punt beskikber foar hervatting.
    ///
    /// As `Complete` werombrocht wurdt, is de generator folslein klear mei de levere wearde.It is ûnjildich dat de generator opnij ferfette wurdt.
    ///
    /// # Panics
    ///
    /// Dizze funksje kin panic as se wurdt neamd nei't de `Complete`-fariant earder werom is.
    /// Wylst generatorliteralen yn 'e taal garandearre binne foar panic as se opnij begjinne nei `Complete`, is dit net garandearre foar alle ymplementaasjes fan' e `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}