/// Oanpaste koade binnen de destruktor.
///
/// As in wearde net langer nedich is, sil Rust in "destructor" op dizze wearde útfiere.
/// De meast foarkommende manier dat in wearde net mear nedich is, is as it bûten it berik giet.Destructors kinne noch rinne yn oare omstannichheden, mar wy sille ús rjochtsje op omfang foar de foarbylden hjir.
/// Om te learen oer guon fan dy oare gefallen, sjoch asjebleaft [the reference] seksje oer destruktoaren.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Dizze destruktor bestiet út twa komponinten:
/// - In oprop nei `Drop::drop` foar dy wearde, as dizze spesjale `Drop` trait wurdt ymplementearre foar syn type.
/// - De automatysk oanmakke "drop glue" dy't de destruktoaren fan alle fjilden fan dizze wearde rekursyf neamt.
///
/// Om't Rust de destruktors fan alle befette fjilden automatysk neamt, hoege jo yn 'e measte gefallen gjin `Drop` te ymplementearjen.
/// Mar d'r binne guon gefallen wêr't it nuttich is, bygelyks foar soarten dy't in boarne direkt beheare.
/// Dy boarne kin geheugen wêze, it kin in bestânsbeskriuwing wêze, it kin in netwurksocket wêze.
/// As ien kear in wearde fan dat type net mear brûkt wurdt, moat it de boarne "clean up" meitsje troch it ûnthâld frij te meitsjen of it bestân of de socket te sluten.
/// Dit is de taak fan in destruktor, en dêrom de taak fan `Drop::drop`.
///
/// ## Examples
///
/// Om fernielers yn aksje te sjen, litte wy efkes sjen nei it folgjende programma:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust sil earst `Drop::drop` foar `_x` skilje en dan foar sawol `_x.one` as `_x.two`, wat betsjuttet dat dit draait sil ôfdrukke
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Sels as wy de ymplemintaasje fan `Drop` foar `HasTwoDrop` fuortsmite, wurde de destruktoaren fan har fjilden noch altyd neamd.
/// Dit soe resultearje yn
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Jo kinne `Drop::drop` net sels skilje
///
/// Om't `Drop::drop` wurdt brûkt om in wearde op te romjen, kin it gefaarlik wêze om dizze wearde te brûken neidat de metoade is neamd.
/// Om't `Drop::drop` gjin eigendom nimt fan har ynput, foarkomt Rust misbrûk troch jo net tastean `Drop::drop` direkt te skiljen.
///
/// Mei oare wurden, as jo besykje `Drop::drop` eksplisyt te skiljen yn it boppesteande foarbyld, krije jo in kompilearflater.
///
/// As jo de destruktor fan in wearde eksplisyt wolle neame, kin [`mem::drop`] yn plak wurde brûkt.
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Hokker fan ús twa `HasDrop` sakket lykwols earst?Foar structs is it deselde folchoarder dat se wurde ferklearre: earst `one`, dan `two`.
/// As jo dit sels wolle besykje, kinne jo `HasDrop` hjirboppe oanpasse om wat gegevens te befetsjen, lykas in heule getal, en brûk it dan yn 'e `println!` binnen `Drop`.
/// Dit gedrach wurdt garandearre troch de taal.
///
/// Oars as foar structs wurde lokale fariabelen yn omkearde folchoarder falle litten:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dit sil ôfdrukke
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Besjoch [the reference] foar de folsleine regels.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` en `Drop` binne eksklusyf
///
/// Jo kinne net sawol [`Copy`] as `Drop` op itselde type ymplementearje.Typen dy't `Copy` binne wurde ymplisyt duplisearre troch de gearstaller, wêrtroch it heul dreech is om te foarsizzen wannear, en hoe faak destruktoaren wurde útfierd.
///
/// As sadanich kinne dizze soarten gjin destruktoaren hawwe.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Fiert de destruktor út foar dit type.
    ///
    /// Dizze metoade wurdt ymplisyt neamd as de wearde bûten it berik giet, en kin net eksplisyt neamd wurde (dit is kompilearflater [E0040]).
    /// De [`mem::drop`]-funksje yn 'e prelude kin lykwols brûkt wurde om `Drop`-ymplemintaasje fan it argumint te neamen.
    ///
    /// As dizze metoade is neamd, is `self` noch net deallokeard.
    /// Dat bart pas nei't de metoade foarby is.
    /// As dit net it gefal wie, soe `self` in hingjende referinsje wêze.
    ///
    /// # Panics
    ///
    /// Jûn dat in [`panic!`] `drop` sil skilje as it ûntspant, sil elke [`panic!`] yn in `drop`-ymplemintaasje wierskynlik ôfbrekke.
    ///
    /// Tink derom dat sels as dizze panics, de wearde wurdt beskôge as falle;
    /// jo moatte gjin `drop` opnij belje.
    /// Dit wurdt normaal automatysk behannele troch de kompilearder, mar by it brûken fan ûnfeilige koade kin it soms unbedoeld foarkomme, benammen by it brûken fan [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}