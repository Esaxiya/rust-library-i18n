/// In trait foar it oanpassen fan it gedrach fan 'e `?`-operator.
///
/// In type dat `Try` útfiert is ien dy't in kanonike manier hat om it te besjen yn termen fan in success/failure-twadieling.
/// Dizze trait makket it mooglik om beide wearden fan sukses as falen út in besteand eksimplaar te ekstraheren en in nij eksimplaar oan te meitsjen út in súkses-as mislearjen.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// It type fan dizze wearde as sjoen as suksesfol.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// It type fan dizze wearde as sjoen as mislearre.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Jout de "?"-operator oan.In weromreis fan `Ok(t)` betsjuttet dat de útfiering normaal trochgean moat, en it resultaat fan `?` is de wearde `t`.
    /// In weromkear fan `Err(e)` betsjut dat útfiering branch moat nei it ynderste omsletten `catch`, of werom moat fan 'e funksje.
    ///
    /// As in `Err(e)`-resultaat wurdt weromjûn, sil de wearde `e` "wrapped" wêze yn it retourtype fan 'e omslutende omfang (dy't sels `Try` moat ymplementearje).
    ///
    /// Spesifyk wurdt de wearde `X::from_error(From::from(e))` weromjûn, wêr't `X` it retoerstype is fan 'e omslutende funksje.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wikkel in flaterwearde yn om it gearstalde resultaat te konstruearjen.
    /// Bygelyks, `Result::Err(x)` en `Result::from_error(x)` binne lykweardich.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Wikkel in OK-wearde yn om it gearstalde resultaat te konstruearjen.
    /// Bygelyks, `Result::Ok(x)` en `Result::from_ok(x)` binne lykweardich.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}