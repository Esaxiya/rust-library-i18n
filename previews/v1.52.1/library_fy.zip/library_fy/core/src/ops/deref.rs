/// Gebrûk foar ûnferoarlike operaasjes foar dereferinsje, lykas `*v`.
///
/// Neist dat it wurdt brûkt foar eksplisite dereferinsje-operaasjes mei de (unary) `*`-operator yn ûnferoarlike konteksten, wurdt `Deref` ek yn in protte omstannichheden ymplisyt brûkt troch de kompilator.
/// Dit meganisme wurdt ['`Deref` coercion'][more] neamd.
/// Yn feroarbere konteksten wurdt [`DerefMut`] brûkt.
///
/// Ymplementearje `Deref` foar tûke oanwizings makket tagong ta de gegevens efter har handich, dêrom ymplementearje se `Deref`.
/// Oan 'e oare kant waarden de regels oangeande `Deref` en [`DerefMut`] spesifyk ûntwurpen om slimme pointers te befredigjen.
/// Hjirtroch moat **`Deref` allinich wurde ymplementeare foar tûke oanwizers** om betizing te foarkommen.
///
/// Om ferlykbere redenen moat **dizze trait nea mislearje**.Mislearjen by dereferinsje kin ekstreem betiizjend wêze as `Deref` ymplisyt wurdt oproppen.
///
/// # Mear oer `Deref`-twang
///
/// As `T` `Deref<Target = U>` ymplementeart, en `x` in wearde is fan type `T`, dan:
///
/// * Yn ûnferoarlike konteksten is `*x` (wêr't `T` noch gjin referinsje is noch in rauwe oanwizer) lykweardich oan `* Deref::deref(&x)`.
/// * Wearden fan type `&T` wurde twongen ta wearden fan type `&U`
/// * `T` ymplisyt ymplisyt alle (immutable)-metoaden fan it type `U`.
///
/// Foar mear details kinne jo besykje [the chapter in *The Rust Programming Language*][book] en ek de referinsjeseksjes oer [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// In struktuer mei ien fjild dat tagonklik is troch derferferinsje fan 'e struktuer.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// It resultearjende type nei dereferinsje.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Ferwiist de wearde.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Gebrûk foar mutabele dereferinsje-operaasjes, lykas yn `*v = 1;`.
///
/// Neist dat it wurdt brûkt foar eksplisite dereferinsje-operaasjes mei de (unary) `*`-operator yn feroarbere konteksten, wurdt `DerefMut` ek yn in protte omstannichheden ymplisyt brûkt troch de kompilator.
/// Dit meganisme wurdt ['`Deref` coercion'][more] neamd.
/// Yn ûnferoarlike konteksten wurdt [`Deref`] brûkt.
///
/// Ymplementearje `DerefMut` foar tûke oanwizings makket it mutearjen fan de gegevens efter har handich, dêrom ymplementearje se `DerefMut`.
/// Oan 'e oare kant waarden de regels oangeande [`Deref`] en `DerefMut` spesifyk ûntwurpen om slimme pointers te befredigjen.
/// Hjirtroch moat **`DerefMut` allinich wurde ymplementeare foar tûke oanwizers** om betizing te foarkommen.
///
/// Om ferlykbere redenen moat **dizze trait nea mislearje**.Mislearjen by dereferinsje kin ekstreem betiizjend wêze as `DerefMut` ymplisyt wurdt oproppen.
///
/// # Mear oer `Deref`-twang
///
/// As `T` `DerefMut<Target = U>` ymplementeart, en `x` in wearde is fan type `T`, dan:
///
/// * Yn feroarbere konteksten is `*x` (wêr't `T` gjin referinsje is noch in rauwe oanwizer) gelyk oan `* DerefMut::deref_mut(&mut x)`.
/// * Wearden fan type `&mut T` wurde twongen ta wearden fan type `&mut U`
/// * `T` ymplisyt ymplisyt alle (mutable)-metoaden fan it type `U`.
///
/// Foar mear details kinne jo besykje [the chapter in *The Rust Programming Language*][book] en ek de referinsjeseksjes oer [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// In struktuer mei ien fjild dat oanpasber is troch de struktuer te ferwize.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Muteare ferwiist de wearde.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Jout oan dat in struct kin brûkt wurde as metoade-ûntfanger, sûnder de `arbitrary_self_types`-funksje.
///
/// Dit wurdt ymplementeare troch stdlib-oanwizerstypen lykas `Box<T>`, `Rc<T>`, `&T`, en `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}