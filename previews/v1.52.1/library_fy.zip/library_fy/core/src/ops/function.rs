/// De ferzje fan de opropoperator dy't in ûnferoarlike ûntfanger nimt.
///
/// Ynstânsjes fan `Fn` kinne werhelle wurde neamd sûnder steat te mutearjen.
///
/// *Dizze trait (`Fn`) is net te betiizjen mei [function pointers] (`fn`).*
///
/// `Fn` wurdt automatysk ymplementeare troch slutingen dy't allinich unferoarlike referinsjes nimme nei ferovere fariabelen of hielendal neat opnimme, lykas (safe) [function pointers] (mei guon behertigingen, sjoch har dokumintaasje foar mear details).
///
/// Derneist, foar elk type `F` dat `Fn` ymplementeart, `&F` ek `Fn` ymplementeart.
///
/// Om't sawol [`FnMut`] as [`FnOnce`] supertrajekten fan `Fn` binne, kin elk eksimplaar fan `Fn` brûkt wurde as parameter wêr't in [`FnMut`] as [`FnOnce`] wurdt ferwachte.
///
/// Brûk `Fn` as in bân as jo in parameter wolle akseptearje fan funksje-achtich type en moatte it herhaaldelik neame en sûnder steat te mutearjen (bgl. As jo it tagelyk belje).
/// As jo sokke strange easken net nedich binne, brûk dan [`FnMut`] as [`FnOnce`] as grinzen.
///
/// Sjoch de [chapter on closures in *The Rust Programming Language*][book] foar wat mear ynformaasje oer dit ûnderwerp.
///
/// Ek fan opmerking is de spesjale syntaksis foar `Fn` traits (bgl
/// `Fn(usize, bool) -> brûkme ').Wa't ynteressearre is yn 'e technyske details hjirfan kin ferwize nei [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## In sluting skilje
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Mei help fan in `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sadat regex dy `&str: !FnMut` kin fertrouwe
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Fiert de opropaksje út.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// De ferzje fan de opropoperator dy't in feroarbere ûntfanger nimt.
///
/// Ynstânsjes fan `FnMut` kinne werhelle wurde neamd en kinne de steat feroarje.
///
/// `FnMut` wurdt automatysk ymplementeare troch slutingen dy't feroarbere referinsjes nimme nei ferovere fariabelen, lykas alle soarten dy't [`Fn`] ymplementearje, bgl. (safe) [function pointers] (sûnt `FnMut` is in supertrait fan [`Fn`]).
/// Derneist, foar elk type `F` dat `FnMut` ymplementeart, `&mut F` ek `FnMut` ymplementeart.
///
/// Sûnt [`FnOnce`] in supertrait fan `FnMut` is, kin elke eksimplaar fan `FnMut` brûkt wurde wêr't in [`FnOnce`] wurdt ferwachte, en om't [`Fn`] in subtray is fan `FnMut`, kin elke eksimplaar fan [`Fn`] brûkt wurde wêr't `FnMut` wurdt ferwachte.
///
/// Brûk `FnMut` as in bân as jo in parameter fan funksje-achtich type wolle akseptearje en it herhaaldelik moatte skilje, wylst it tastân kin feroarje.
/// As jo de parameter net wolle feroarje, brûk dan [`Fn`] as in bûn;as jo it net meardere kearen hoege te skiljen, brûk dan [`FnOnce`].
///
/// Sjoch de [chapter on closures in *The Rust Programming Language*][book] foar wat mear ynformaasje oer dit ûnderwerp.
///
/// Ek fan opmerking is de spesjale syntaksis foar `Fn` traits (bgl
/// `Fn(usize, bool) -> brûkme ').Wa't ynteressearre is yn 'e technyske details hjirfan kin ferwize nei [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Oproppe fan in mutabel fêstlizzende sluting
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Mei help fan in `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sadat regex dy `&str: !FnMut` kin fertrouwe
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Fiert de opropaksje út.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// De ferzje fan 'e opropbehearder dy't in ûntfanger fan bywearde nimt.
///
/// Ynstânsjes fan `FnOnce` kinne neamd wurde, mar kinne net meardere kearen oproppen wurde.Hjirtroch kin, as it iennichste bekend oer in type is dat it `FnOnce` ymplementeart, it mar ien kear wurde neamd.
///
/// `FnOnce` wurdt automatysk ymplementeare troch slutingen dy't ferovere fariabelen brûke kinne, lykas alle soarten dy't [`FnMut`] ymplementearje, bgl. (safe) [function pointers] (sûnt `FnOnce` is in supertrait fan [`FnMut`]).
///
///
/// Om't sawol [`Fn`] as [`FnMut`] subtraits binne fan `FnOnce`, kin elk eksimplaar fan [`Fn`] of [`FnMut`] brûkt wurde wêr't in `FnOnce` wurdt ferwachte.
///
/// Brûk `FnOnce` as in bûn as jo in parameter wolle akseptearje fan funksje-achtich type en hoege it mar ien kear te neamen.
/// As jo de parameter meardere kearen moatte skilje, brûk dan [`FnMut`] as in bân;as jo it ek nedich binne om steat net te mutearjen, brûk dan [`Fn`].
///
/// Sjoch de [chapter on closures in *The Rust Programming Language*][book] foar wat mear ynformaasje oer dit ûnderwerp.
///
/// Ek fan opmerking is de spesjale syntaksis foar `Fn` traits (bgl
/// `Fn(usize, bool) -> brûkme ').Wa't ynteressearre is yn 'e technyske details hjirfan kin ferwize nei [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Mei help fan in `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ferbrûkt de opnommen fariabelen, sadat it net mear dan ien kear kin wurde rinne.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Besykje `func()` opnij oan te roppen smyt in `use of moved value`-flater foar `func` op.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kin op dit punt net mear oproppen wurde
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sadat regex dy `&str: !FnMut` kin fertrouwe
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// It weromkommen type nei't de opropoperator wurdt brûkt.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Fiert de opropaksje út.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}