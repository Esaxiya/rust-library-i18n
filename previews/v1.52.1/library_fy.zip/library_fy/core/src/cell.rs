//! Dielbere feroarbere konteners.
//!
//! Rust ûnthâldfeiligens is basearre op dizze regel: Jûn in objekt `T` is it allinich mooglik ien fan 'e folgjende te hawwen:
//!
//! - Mei ferskate unferoarlike referinsjes (`&T`) nei it objekt (ek wol **aliasing** neamd).
//! - Ien mutabele referinsje hawwe (`&mut T`) nei it objekt (ek wol **mutabiliteit**).
//!
//! Dit wurdt twongen troch de Rust-kompilearder.D'r binne lykwols situaasjes wêr't dizze regel net fleksibel genôch is.Somtiden is it ferplicht meardere referinsjes nei in objekt te hawwen en it lykwols te mutearjen.
//!
//! Dielbere mutabele konteners besteane om mutabiliteit op in kontroleare manier ta te stean, sels yn 'e oanwêzigens fan aliasing.Sawol [`Cell<T>`] as [`RefCell<T>`] tastean dit op ienriedige manier te dwaan.
//! Noch `Cell<T>`, noch `RefCell<T>` binne threadfeil (se ymplementearje [`Sync`] net).
//! As jo aliasing en mutaasje moatte dwaan tusken meardere triedden, is it mooglik om [`Mutex<T>`]-, [`RwLock<T>`]-of [`atomic`]-typen te brûken.
//!
//! Wearden fan 'e `Cell<T>`-en `RefCell<T>`-typen kinne muteare wurde troch dielde referinsjes (ie
//! it mienskiplike `&T`-type), wylst de measte Rust-typen allinich kinne wurde muteare troch unike (`&mut T`) referinsjes.
//! Wy sizze dat `Cell<T>` en `RefCell<T>` 'ynterieurmutabiliteit' leverje, yn tsjinstelling mei typyske Rust-typen dy't 'erflike mutabiliteit' werjaan.
//!
//! Seltypen komme yn twa smaken: `Cell<T>` en `RefCell<T>`.`Cell<T>` ymplementeart ynterieurmutabiliteit troch wearden yn en út de `Cell<T>` te ferpleatsen.
//! Om referinsjes te brûken ynstee fan wearden, moat men it type `RefCell<T>` brûke, en in skriuwslot krije foardat men muteart.`Cell<T>` biedt metoaden om de hjoeddeistige ynterieurwearde op te heljen en te feroarjen:
//!
//!  - Foar typen dy't [`Copy`] ymplementearje, hellet de [`get`](Cell::get)-metoade de hjoeddeiske ynterieurwearde op.
//!  - Foar typen dy't [`Default`] ymplementearje, ferfangt de [`take`](Cell::take)-metoade de hjoeddeiske ynterieurwearde troch [`Default::default()`] en retourneert de ferfange wearde.
//!  - Foar alle soarten ferfangt de [`replace`](Cell::replace)-metoade de hjoeddeiske ynterieurwearde en jout de ferfange wearde werom en de [`into_inner`](Cell::into_inner)-metoade ferbrûkt de `Cell<T>` en retourneert de ynterieurwearde.
//!  Derneist ferfangt de [`set`](Cell::set)-metoade de ynterieurwearde en lit de ferfange wearde falle.
//!
//! `RefCell<T>` brûkt de libbensdagen fan Rust om 'dynamyske liening' te ymplementearjen, in proses wêrby't men tydlike, eksklusive, feroarbere tagong kin oant de ynderlike wearde.
//! Leint foar `RefCell<T>`s wurde 'op runtime' folge, yn tsjinstelling ta de native referinsjetypen fan Rust dy't op statyske tiid folslein statysk wurde folge.
//! Om't `RefCell<T>`-lieningen dynamysk binne, is it mooglik om te besykjen in wearde te lienen dy't al mutant lien is;as dit bart, resulteart it yn thread panic.
//!
//! # Wannear moatte jo feroarje yn ynterieur?
//!
//! De mear foarkommende erflike mutabiliteit, wêr't men unike tagong moat hawwe om in wearde te mutearjen, is ien fan 'e kaaistaaleleminten dy't Rust yn steat stelt om sterk te redenearjen oer oanwizer fan oanwizer, statysk foarkommen fan crashbugs.
//! Hjirtroch hat erflike mutabiliteit de foarkar, en ynterieurmutabiliteit is wat in lêste rêdmiddel.
//! Om't seltypen mutaasje ynskeakelje wêr't it oars lykwols net wurdt tastien, binne d'r gelegenheden dat ynterne mutabiliteit passend wêze kin, of sels *moat* wurde brûkt, bgl.
//!
//! * Yntroduksje fan mutabiliteit 'inside' fan wat ûnferoarlik
//! * Ymplemintaasjegegevens fan logysk-ûnferoarlike metoaden.
//! * Mutearjende ymplementaasjes fan [`Clone`].
//!
//! ## Yntroduksje fan mutabiliteit 'inside' fan wat ûnferoarlik
//!
//! In protte dielde smart-pointertypen, wêrûnder [`Rc<T>`] en [`Arc<T>`], leverje konteners dy't kinne wurde kloneare en dield tusken meardere partijen.
//! Om't de befette wearden multiply-alias kinne wêze, kinne se allinich lien wurde mei `&`, net `&mut`.
//! Sûnder sellen soe it ûnmooglik wêze om gegevens binnen dizze smart pointers te mutearjen.
//!
//! It is dan hiel gewoan in `RefCell<T>` te pleatsen yn dielde oanwizerstypes om mutabiliteit wer yn te fieren:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Meitsje in nij blok om de omfang fan 'e dynamyske liening te beheinen
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Tink derom dat as wy de foarige liening fan 'e cache net bûten it berik falle litte soene, dan soe de folgjende liening in dynamyske thread panic feroarsaakje.
//!     //
//!     // Dit is it grutste gefaar fan it brûken fan `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Tink derom dat dit foarbyld `Rc<T>` brûkt en net `Arc<T>`.`RefCell<T>`s binne foar senario's mei ien triedden.Tink oan it brûken fan [`RwLock<T>`] of [`Mutex<T>`] as jo dielde mutabiliteit nedich binne yn in situaasje mei meardere triedden.
//!
//! ## Ymplemintaasjegegevens fan logysk-ûnferoarlike metoaden
//!
//! Sa no en dan kin it winsklik wêze om net yn in API bleat te lizzen dat der mutaasje "under the hood" bart.
//! Dit kin wêze om't de operaasje logyskerwize ûnferoarlik is, mar bgl. Caching twingt de ymplemintaasje om mutaasje út te fieren;of om't jo mutaasje brûke moatte om in trait-metoade te ymplementearjen dy't oarspronklik waard definieare om `&self` te nimmen.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Djoere berekkening giet hjir
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutearjende ymplementaasjes fan `Clone`
//!
//! Dit is gewoan in spesjaal, mar gewoan, gefal fan 'e foarige: it ferbergjen fan mutabiliteit foar operaasjes dy't ûnferoarlik lykje te wêzen.
//! De ferwachting fan 'e [`clone`](Clone::clone)-metoade feroaret de boarnewearde net, en wurdt ferklearre `&self` te nimmen, net `&mut self`.
//! Dêrom moat elke mutaasje dy't bart yn 'e `clone`-metoade seltypen brûke.
//! Bygelyks, [`Rc<T>`] hâldt syn referinsjetellingen binnen in `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// In feroarbere ûnthâldlokaasje.
///
/// # Examples
///
/// Yn dit foarbyld kinne jo sjen dat `Cell<T>` mutaasje mooglik makket yn in ûnferoarlike struktuer.
/// Mei oare wurden, it makket "interior mutability" mooglik.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FOUT: `my_struct` is ûnferoarlik
/// // my_struct.regular_field =nije_wearde;
///
/// // WURKT: hoewol `my_struct` ûnferoarlik is, is `special_field` in `Cell`,
/// // dat kin altyd wurde mutearre
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Sjoch de [module-level documentation](self) foar mear.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Makket in `Cell<T>`, mei de `Default`-wearde foar T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Makket in nije `Cell` mei de opjûne wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Stelt de befette wearde yn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ruilje de wearden fan twa sellen yn.
    /// Ferskil mei `std::mem::swap` is dat dizze funksje gjin `&mut`-referinsje nedich is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // VEILIGHEID: Dit kin risikofol wêze as neamd wurde út aparte triedden, mar `Cell`
        // is `!Sync`, dat dit sil net barre.
        // Dit sil ek gjin oanwizings unjildich meitsje, om't `Cell` derfoar soarget dat neat oars nei ien fan dizze `Cell`s sil wize.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ferfangt de befette wearde mei `val`, en retourneert de âlde befette wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // VEILIGHEID: Dit kin gegevensraces feroarsaakje as se wurde neamd út in aparte tried,
        // mar `Cell` is `!Sync`, dat dit sil net barre.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Wurdt de wearde út.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Jout in kopy fan 'e befette wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // VEILIGHEID: Dit kin gegevensraces feroarsaakje as se wurde neamd út in aparte tried,
        // mar `Cell` is `!Sync`, dat dit sil net barre.
        unsafe { *self.value.get() }
    }

    /// Fernijt de befette wearde mei in funksje en retourneert de nije wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Jout in rauwe oanwizer nei de ûnderlizzende gegevens yn dizze sel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Jout in feroarbere ferwizing nei de ûnderlizzende gegevens.
    ///
    /// Dizze oprop lient `Cell` mutabel (op kompilaasjetiid) wat garandeart dat wy de iennige referinsje hawwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Jout in `&Cell<T>` fan in `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // VEILIGHEID: `&mut` soarget foar unike tagong.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Nimt de wearde fan 'e sel, en lit `Default::default()` op syn plak stean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Jout in `&[Cell<T>]` fan in `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // VEILIGHEID: `Cell<T>` hat deselde ûnthâldopmaak as `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// In feroarbere ûnthâldlokaasje mei dynamysk kontroleare lienregels
///
/// Sjoch de [module-level documentation](self) foar mear.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// In flater weromjûn troch [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// In flater weromjûn troch [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive wearden fertsjintwurdigje it oantal `Ref` aktyf.Negative wearden fertsjintwurdigje it oantal `RefMut` aktyf.
// Meardere `RefMut`'s kinne allinich tagelyk aktyf wêze as se ferwize nei ûnderskate, net-oerlappende ûnderdielen fan in `RefCell` (bgl. Ferskate gebieten fan in slach).
//
// `Ref` en `RefMut` binne beide twa wurden yn grutte, en dus sille d'r nei alle gedachten noait genôch `Ref`s of`RefMut`s wêze om de helte fan it `usize`-berik te oerstreamjen.
// Sa sil in `BorrowFlag` wierskynlik nea oerstreamje of ûnderstreamje.
// Dit is lykwols gjin garânsje, om't in patologysk programma opnij mem::forget `Ref`s of`RefMut`s kin oanmeitsje en dan.
// Sa moat alle koade eksplisyt kontrolearje op oerstreaming en ûnderstream om ûnfeilichheid te foarkommen, of op syn minst goed gedrage yn 't gefal dat oerstreaming of ûnderstreaming bart (bgl. Sjoch BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Makket in nije `RefCell` mei `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Ferbrûkt de `RefCell`, retourneert de ferpakte wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Om't dizze funksje `self` (de `RefCell`) op wearde nimt, ferifieart de gearstaller statysk dat it op it stuit net liend is.
        //
        self.value.into_inner()
    }

    /// Ferfangt de ferpakte wearde troch in nije, jout de âlde wearde werom, sûnder ien te desinitialisearjen.
    ///
    ///
    /// Dizze funksje komt oerien mei [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics as de wearde op it stuit liend is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ferfangt de ferpakte wearde troch in nije dy't wurdt berekkene fan `f`, wêrtroch de âlde wearde weromkomt, sûnder ien te deinitialisearjen.
    ///
    ///
    /// # Panics
    ///
    /// Panics as de wearde op it stuit liend is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Wikselet de ferpakte wearde fan `self` mei de ferpakte wearde fan `other`, sûnder ien te desinitialisearjen.
    ///
    ///
    /// Dizze funksje komt oerien mei [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably lient de ferpakte wearde.
    ///
    /// De liening duorret oant de weromkommende `Ref` de omfang útgiet.
    /// Meardere ûnferoarlike lieningen kinne tagelyk wurde nommen.
    ///
    /// # Panics
    ///
    /// Panics as de wearde op it stuit mutabel liend is.
    /// Brûk [`try_borrow`](#method.try_borrow) foar in fariant dy't net panikeftich is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// In foarbyld fan panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Unferoarlik lient de ferpakte wearde, in flater werom as de wearde op it stuit mutabel is liend.
    ///
    ///
    /// De liening duorret oant de weromkommende `Ref` de omfang útgiet.
    /// Meardere ûnferoarlike lieningen kinne tagelyk wurde nommen.
    ///
    /// Dit is de net-panike fariant fan [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` soarget derfoar dat der allinich unferoarlike tagong is
            // oan de wearde wylst liend.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// De ferpakte wearde lient mutabel.
    ///
    /// De liening duorret oant de weromkearde `RefMut` as alle 'RefMut`s binne ûntliend oan it útgongsgebiet.
    ///
    /// De wearde kin net lien wurde wylst dizze liening aktyf is.
    ///
    /// # Panics
    ///
    /// Panics as de wearde op it stuit liend is.
    /// Brûk [`try_borrow_mut`](#method.try_borrow_mut) foar in fariant dy't net panikeftich is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// In foarbyld fan panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Krijt de ferpakte wearde mutabel, werom in flater as de wearde op it stuit liend is.
    ///
    ///
    /// De liening duorret oant de weromkearde `RefMut` as alle 'RefMut`s binne ûntliend oan it útgongsgebiet.
    /// De wearde kin net lien wurde wylst dizze liening aktyf is.
    ///
    /// Dit is de net-panike fariant fan [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` garandeart unike tagong.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Jout in rauwe oanwizer nei de ûnderlizzende gegevens yn dizze sel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Jout in feroarbere ferwizing nei de ûnderlizzende gegevens.
    ///
    /// Dizze oprop lient `RefCell` mutabel (by kompilaasjetiid), sadat d'r gjin ferlet is fan dynamyske kontrôles.
    ///
    /// Wês lykwols foarsichtich: dizze metoade ferwachtet dat `self` feroarber is, wat normaal net it gefal is by it brûken fan in `RefCell`.
    ///
    /// Sjoch ynstee nei de [`borrow_mut`]-metoade as `self` net feroarber is.
    ///
    /// Hâld der ek rekken mei dat dizze metoade allinich is foar spesjale omstannichheden en normaal net is wat jo wolle.
    /// As jo twivelje, brûk dan [`borrow_mut`] yn plak.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ungedien meitsje fan it effekt fan lekte bewakers op 'e liensteat fan' e `RefCell`.
    ///
    /// Dizze oprop liket op [`get_mut`], mar mear spesjalisearre.
    /// It lient `RefCell` mutabel om te garandearjen dat der gjin lieningen besteane en reset dan de steat dy't dielde lieningen folget.
    /// Dit is relevant as guon `Ref`-of `RefMut`-lieningen binne lekt.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Unferoarlik lient de ferpakte wearde, in flater werom as de wearde op it stuit mutabel is liend.
    ///
    /// # Safety
    ///
    /// Oars as `RefCell::borrow` is dizze metoade ûnfeilich, om't se gjin `Ref` werombringe, wêrtroch de lienflagge ûnoantaaste bliuwt.
    /// Feroarlik liene de `RefCell` wylst de referinsje weromjûn troch dizze metoade libbet is net definieare gedrach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // VEILIGHEID: Wy kontrolearje dat nimmen no aktyf skriuwt, mar it is wol
            // de ferantwurdlikens fan 'e beller om derfoar te soargjen dat nimmen skriuwt oant de weromferwizende referinsje net mear yn gebrûk is.
            // `self.value.get()` ferwiist ek nei de wearde fan `self` en is dus garandearre jildich foar it libben fan `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Nimt de ferpakte wearde, en lit `Default::default()` op syn plak stean.
    ///
    /// # Panics
    ///
    /// Panics as de wearde op it stuit liend is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics as de wearde op it stuit mutabel liend is.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Makket in `RefCell<T>`, mei de `Default`-wearde foar T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics as de wearde yn beide `RefCell` op it stuit liend is.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ferheegjen fan liening kin yn dizze gefallen resultearje yn in net-lêsende wearde (<=0):
            // 1. It wie <0, dat wol sizze dat der skriuwlieningen binne, dat wy kinne gjin lienferliening tastean fanwegen Rust's referinsjealiasearingsregels
            // 2.
            // It wie isize::MAX (it maksimale bedrach fan lêslieningen) en it streamde oer yn isize::MIN (it maksimale bedrach fan skriuwlieningen), sadat wy gjin ekstra lêsliening tastean kinne, omdat isize net safolle lêslieningen kin fertsjintwurdigje (dit kin allinich barre as jo mem::forget mear dan in lyts konstante bedrach fan `Ref`s, dat is gjin goede praktyk)
            //
            //
            //
            //
            None
        } else {
            // Ferheegjen fan lien kin yn dizze gefallen resultearje yn in lêswearde (> 0):
            // 1. It wie=0, dus it waard net liend, en wy nimme de earste lêzen liening
            // 2. It wie> 0 en <isize::MAX, ie
            // d'r waarden lêzen lêzen, en isize is grut genôch om te fertsjintwurdigjen dat der noch ien lêzen is
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Sûnt dizze Ref bestiet, wite wy dat de lienflagge in lêsliening is.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Foarkom dat de lieneteller oerrint yn in skriuwliening.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Ferpakt in liende referinsje nei in wearde yn in `RefCell`-fak.
/// In wikkeltype foar in ûnferoarlik liende wearde fan in `RefCell<T>`.
///
/// Sjoch de [module-level documentation](self) foar mear.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopieart in `Ref`.
    ///
    /// De `RefCell` is al unferoarlik liend, dat dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `Ref::clone(...)`.
    /// In `Clone`-ymplemintaasje as in metoade soe ynterferearje mei it wiidferspraat gebrûk fan `r.borrow().clone()` om de ynhâld fan in `RefCell` te klonen.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Makket in nije `Ref` foar in ûnderdiel fan 'e liende gegevens.
    ///
    /// De `RefCell` is al unferoarlik liend, dat dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `Ref::map(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Makket in nije `Ref` foar in opsjoneel ûnderdiel fan 'e liende gegevens.
    /// De orizjinele wacht wurdt weromjûn as in `Err(..)` as de sluting `None` weromkomt.
    ///
    /// De `RefCell` is al unferoarlik liend, dat dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `Ref::filter_map(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Splittet in `Ref` yn meardere `Ref`s foar ferskillende ûnderdielen fan 'e liende gegevens.
    ///
    /// De `RefCell` is al unferoarlik liend, dat dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `Ref::map_split(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konvertearje yn in referinsje nei de ûnderlizzende gegevens.
    ///
    /// De ûnderlizzende `RefCell` kin nea wer mutabel liend wurde en sil altyd al unferoarlik lien ferskine.
    ///
    /// It is gjin goed idee om mear dan in konstant oantal referinsjes te lekken.
    /// De `RefCell` kin opnij ûnferoarlik lien wurde as mar in lytser oantal lekken yn totaal foarkommen binne.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `Ref::leak(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Troch dizze Ref te ferjitten, soargje wy derfoar dat de lieneteller yn 'e RefCell net werom kin nei UNUSED binnen it libben `'b`.
        // Resetten fan de referinsjestatuerstatus soe in unike ferwizing nedich wêze nei de liende RefCell.
        // Gjin fierdere feroarbere referinsjes kinne makke wurde út 'e orizjinele sel.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Makket in nije `RefMut` foar in ûnderdiel fan 'e liende gegevens, bgl. In enum fariant.
    ///
    /// De `RefCell` is al mutant liend, dus dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `RefMut::map(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fix liene-check
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Makket in nije `RefMut` foar in opsjoneel ûnderdiel fan 'e liende gegevens.
    /// De orizjinele wacht wurdt weromjûn as in `Err(..)` as de sluting `None` weromkomt.
    ///
    /// De `RefCell` is al mutant liend, dus dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `RefMut::filter_map(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fix liene-check
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // VEILIGHEID: funksje hâldt in eksklusive referinsje foar de doer
        // fan syn oprop fia `orig`, en de oanwizer wurdt allinich ferwiisd yn 'e funksje-oprop, wêrtroch de eksklusive referinsje nea ûntkomt.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // VEILIGHEID: itselde as hjirboppe.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Spalt in `RefMut` yn meardere `RefMut`s foar ferskate ûnderdielen fan 'e liende gegevens.
    ///
    /// De ûnderlizzende `RefCell` sil mutabel lien bliuwe oant beide werom 'RefMut's bûten it berik geane.
    ///
    /// De `RefCell` is al mutant liend, dus dit kin net mislearje.
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `RefMut::map_split(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konvertearje yn in feroarbere ferwizing nei de ûnderlizzende gegevens.
    ///
    /// De ûnderlizzende `RefCell` kin net wer lien wurde en sil altyd al mutant lien ferskine, wêrtroch de weromferwizings de iennige is foar it ynterieur.
    ///
    ///
    /// Dit is in assosjeare funksje dy't moat wurde brûkt as `RefMut::leak(...)`.
    /// In metoade soe bemuoie mei metoaden mei deselde namme op 'e ynhâld fan in `RefCell` brûkt fia `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Troch dizze BorrowRefMut te ferjitten, soargje wy derfoar dat de lieneteller yn 'e RefCell net werom kin nei UNUSED binnen it libben `'b`.
        // Resetten fan de referinsjestatuerstatus soe in unike ferwizing nedich wêze nei de liende RefCell.
        // Gjin fierdere referinsjes kinne wurde makke út 'e orizjinele sel binnen dat libben, wêrtroch de hjoeddeiske liening de iennige referinsje is foar it oerbleaune libben.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Oars as BorrowRefMut::clone wurdt nij neamd om de initial te meitsjen
        // mutabele referinsje, en dus moatte d'r op it stuit gjin besteande referinsjes wêze.
        // Sadwaande, wylst klon it feroarbere refcount ferheget, litte wy hjir eksplisyt allinich fan UNUSED nei UNUSED, 1, gean.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones in `BorrowRefMut`.
    //
    // Dit is allinich jildich as elke `BorrowRefMut` wurdt brûkt om in feroarbere ferwizing nei in ûnderskiedend, net-oerlappend berik fan it orizjinele objekt te folgjen.
    //
    // Dit is net yn in Clone-impl, sadat dizze koade dit net ymplisyt neamt.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Foarkom dat de lieneteller ûnderstreamt.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// In wikkeltype foar in mutant liende wearde fan in `RefCell<T>`.
///
/// Sjoch de [module-level documentation](self) foar mear.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// De kearnprimityf foar ynterieurmutabiliteit yn Rust.
///
/// As jo in referinsje `&T` hawwe, dan fiert de kompiler normaal yn Rust optimisaasjes út basearre op 'e kennis dat `&T` wiist op ûnferoarlike gegevens.Dat gegevens mutearje, bygelyks fia in alias of troch it transmutearjen fan in `&T` yn in `&mut T`, wurdt beskôge as net definieare gedrach.
/// `UnsafeCell<T>` kieze út de ûnferoarlike garânsje foar `&T`: in dielde referinsje `&UnsafeCell<T>` kin wize op gegevens dy't muteare wurde.Dit wurdt "interior mutability" neamd.
///
/// Alle oare soarten dy't ynterne mutabiliteit tastean, lykas `Cell<T>` en `RefCell<T>`, brûke `UnsafeCell` yntern om har gegevens yn te pakken.
///
/// Tink derom dat allinich de ûnferoarlike garânsje foar dielde referinsjes wurdt beynfloede troch `UnsafeCell`.De unike garânsje foar mutabele referinsjes is net beynfloede.D'r is *gjin* legale manier om aliasing `&mut` te krijen, sels net mei `UnsafeCell<T>`.
///
/// De `UnsafeCell` API sels is technysk heul ienfâldich: [`.get()`] jout jo in rauwe oanwizer `*mut T` foar har ynhâld.It is oan _you_ as abstraksje-ûntwerper om dy rauwe oanwizer korrekt te brûken.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// De krekte Rust-aliasingregels binne wat yn 'e gong, mar de haadpunten binne net kontroversjeel:
///
/// - As jo in feilige referinsje oanmeitsje mei lifetime `'a` (òf in `&T`-as `&mut T`-referinsje) dy't tagonklik is fia feilige koade (bygelyks om't jo dy weromjûn hawwe), dan moatte jo de gegevens net tagong krije op ien of oare manier dy't tsjin 'e referinsje yn' e rest is fan `'a`.
/// Dit betsjut bygelyks dat as jo de `*mut T` fan in `UnsafeCell<T>` nimme en dizze nei in `&T` smite, dan moatte de gegevens yn `T` ûnferoarlik bliuwe (modulo alle `UnsafeCell`-gegevens dy't binne fûn yn `T`, fansels) oant it libben fan 'e referinsje ferrint.
/// As jo in `&mut T`-referinsje oanmeitsje dy't wurdt frijjûn oan feilige koade, dan moatte jo gjin tagong krije ta de gegevens binnen de `UnsafeCell` oant dizze referinsje ferrint.
///
/// - Altyd moatte jo gegevensrassen foarkomme.As meardere triedden tagong hawwe ta deselde `UnsafeCell`, dan moatte alle skriuwen in goede barrens hawwe foar't alle oare tagongsrjochten binne (of atomics brûke).
///
/// Om te helpen by goed ûntwerp wurde de folgjende senario's eksplisyt legaal ferklearre foar koade mei ien triedden:
///
/// 1. In `&T`-referinsje kin frijjûn wurde nei feilige koade en dêr kin it bestean mei oare `&T`-referinsjes, mar net mei in `&mut T`
///
/// 2. In `&mut T`-referinsje kin wurde frijjûn nei feilige koade, mits noch oare `&mut T` noch `&T` der mei besteane.In `&mut T` moat altyd unyk wêze.
///
/// Tink derom dat wyls de mutaasje fan 'e ynhâld fan in `&UnsafeCell<T>` (sels wylst oare `&UnsafeCell<T>` alias de sel ferwiist) ok is (as jo de boppesteande invarianten op in oare manier hanthavenje), it is noch net definieare gedrach om meardere `&mut UnsafeCell<T>`-aliassen te hawwen.
/// Dat is, `UnsafeCell` is in omslach ûntwurpen om in spesjale ynteraksje mei _shared_ accesses (_i.e._ te hawwen, fia in `&UnsafeCell<_>` referinsje);d'r is gjin magie oeral as jo mei _exclusive_ accesses (_e.g._ omgean, fia in `&mut UnsafeCell<_>`): noch de sel noch de ferpakte wearde kinne foar de doer fan dy `&mut` lien wêze.
///
/// Dit wurdt toand troch de [`.get_mut()`] accessor, dat is in _safe_ getter dy't in `&mut T` opleveret.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hjir is in foarbyld dat toant hoe de ynhâld fan in `UnsafeCell<_>` goed mutearje kin, hoewol d'r meardere referinsjes binne dy't de sel aliasearje:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Krij meardere/dielde referinsjes nei deselde `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // VEILIGHEID: binnen dit gebiet binne d'r gjin oare ferwizings nei de ynhâld fan 'x',
///     // dat uzes is effektyf unyk.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- liene-+
///     *p1_exclusive += 27; // |
/// } // <---------- kin net fierder gean dan dit punt -------------------+
///
/// unsafe {
///     // VEILIGHEID: binnen dizze omfang ferwachtet nimmen eksklusive tagong te hawwen ta de ynhâld fan 'x',
///     // sadat wy tagelyk meardere dielde tagongsrjochten kinne hawwe.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// It folgjende foarbyld lit it feit sjen dat eksklusive tagong ta in `UnsafeCell<T>` eksklusive tagong betsjuttet ta syn `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // mei eksklusive tagong,
///                         // `UnsafeCell` is in trochsichtige no-op wrapper, dus hjir gjin `unsafe` ferlet.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Krij in unyk referinsje foar kompilearje-tiid kontroleare nei `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Mei in eksklusive referinsje kinne wy de ynhâld fergees mutearje.
/// *p_unique.get_mut() = 0;
/// // Of, lykweardich:
/// x = UnsafeCell::new(0);
///
/// // As wy de wearde hawwe, kinne wy de ynhâld fergees ekstrahearje.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstrueart in nij eksimplaar fan `UnsafeCell` dat de oantsjutte wearde sil ynpakke.
    ///
    ///
    /// Alle tagong ta de ynderlike wearde fia metoaden is `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Wurdt de wearde út.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Krijt in feroarbere oanwizer nei de ferpakte wearde.
    ///
    /// Dit kin wurde cast nei in oanwizer fan elke soart.
    /// Soargje derfoar dat de tagong unyk is (gjin aktive referinsjes, feroarber as net) by casting nei `&mut T`, en soargje derfoar dat d'r gjin mutaasjes of mutabele aliassen binne by casting nei `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Wy kinne gewoan de oanwizer fan `UnsafeCell<T>` nei `T` smite fanwegen #[repr(transparent)].
        // Dit eksploiteart de spesjale status fan libstd, d'r is gjin garânsje foar brûkerskoade dat dit sil wurkje yn future ferzjes fan 'e kompilearder!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Jout in feroarbere ferwizing nei de ûnderlizzende gegevens.
    ///
    /// Dizze oprop lient de `UnsafeCell` mutabel (op kompilaasjetiid) dy't garandeart dat wy de ienige referinsje hawwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Krijt in feroarbere oanwizer nei de ferpakte wearde.
    /// It ferskil foar [`get`] is dat dizze funksje in rauwe oanwizer aksepteart, wat nuttich is om it oanmeitsjen fan tydlike referinsjes te foarkommen.
    ///
    /// It resultaat kin wurde getten nei in oanwizer fan hokker soarte dan ek.
    /// Soargje derfoar dat de tagong unyk is (gjin aktive referinsjes, feroarber as net) as jo nei `&mut T` stjoere, en soargje derfoar dat d'r gjin mutaasjes of feroarbere aliassen binne by casting nei `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Stadige inisjalisaasje fan in `UnsafeCell` fereasket `raw_get`, om't `get` belje soe in ferwizing meitsje moatte nei uninitialisearre gegevens:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Wy kinne gewoan de oanwizer fan `UnsafeCell<T>` nei `T` smite fanwegen #[repr(transparent)].
        // Dit eksploiteart de spesjale status fan libstd, d'r is gjin garânsje foar brûkerskoade dat dit sil wurkje yn future ferzjes fan 'e kompilearder!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Makket in `UnsafeCell`, mei de `Default`-wearde foar T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}