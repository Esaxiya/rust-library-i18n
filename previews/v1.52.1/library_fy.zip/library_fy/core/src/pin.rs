//! Soarten dy't gegevens pinne nei har lokaasje yn it ûnthâld.
//!
//! It is somtiden nuttich om objekten te hawwen dy't garandearre binne net te bewegen, yn 't sin dat har pleatsing yn it ûnthâld net feroaret, en dus kin wurde fertrouwe op.
//! In prima foarbyld fan sa'n senario soe it bouwen fan selsferwizende struktueren wêze, om't in objekt mei oanwizings nei himsels ferpleatse sil dizze unjildich meitsje, wat undefined gedrach kin feroarsaakje.
//!
//! Op in heech nivo soarget in [`Pin<P>`] derfoar dat de oanwizer fan elke oanwizer type `P` in stabile lokaasje hat yn it ûnthâld, wat betsjut dat it net earne oars kin wurde ferpleatst en syn ûnthâld kin net wurde ferdield oant it falt.Wy sizze dat de oanwizer "pinned" is.Dingen wurde subtiler by it besprekken fan soarten dy't kombineare wurde mei net-pinned gegevens;[see below](#projections-and-structural-pinning) foar mear details.
//!
//! Standert binne alle soarten yn Rust beweechber.
//! Rust lit alle soarten by-wearde trochjaan, en mienskiplike smart-pointer-typen lykas [`Box<T>`] en `&mut T` kinne de wearden dy't se befetsje ferfange en ferpleatse: jo kinne út in [`Box<T>`] ferpleatse, of jo kinne [`mem::swap`] brûke.
//! [`Pin<P>`] ferpakt in oanwizer type `P`, dus [`Pin`]`<`[`Box`] `<T>>`funksjoneart in protte as in reguliere
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>"wurdt sakke, dus de ynhâld derfan, en it ûnthâld wurdt
//!
//! deallocated.Likegoed liket [`Pin`]`<&mut T>`in soad op `&mut T`.[`Pin<P>`] lit kliïnten lykwols net in [`Box<T>`] of `&mut T` krije foar pinned gegevens, wat betsjuttet dat jo gjin operaasjes lykas [`mem::swap`] kinne brûke:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` hat `&mut T` nedich, mar wy kinne it net krije.
//!     // Wy sitte fêst, wy kinne de ynhâld fan dizze referinsjes net ruilje.
//!     // Wy koenen `Pin::get_unchecked_mut` brûke, mar dat is om in reden ûnfeilich:
//!     // wy meie it net brûke foar it ferpleatsen fan dingen út 'e `Pin`.
//! }
//! ```
//!
//! It is it wurdich te herheljen dat [`Pin<P>`]*net* feroaret it feit dat in Rust-kompilearder alle soarten beweecht beskôget.[`mem::swap`] bliuwt oproppen foar elke `T`.Ynstee foarkomt [`Pin<P>`] dat bepaalde *wearden*(oanwize troch oanwizers ferpakt yn [`Pin<P>`]) ferpleatst wurde troch it ûnmooglik te meitsjen metoaden te neamen dy't `&mut T` derop nedich binne (lykas [`mem::swap`]).
//!
//! [`Pin<P>`] kin brûkt wurde om elke oanwizer type `P` yn te pakken, en as sadanich is it ynteraksje mei [`Deref`] en [`DerefMut`].In [`Pin<P>`] wêrby `P: Deref` moat wurde beskôge as in "`P`-style pointer" nei in pinne `P::Target`-dus, in [`Pin`]`<`[`Box`] `<T>>`is in eigen oanwizer nei in pinne `T`, en in [`Pin`] `<` [`Rc`]`<T>> is in referinsjegeteld oanwizer nei in pinne `T`.
//! Foar justigens fertrout [`Pin<P>`] op 'e ymplementaasjes fan [`Deref`] en [`DerefMut`] om net út har `self`-parameter te bewegen, en allinich in oanwizer werom te jaan nei pinned gegevens as se wurde neamd op in pinned oanwizer.
//!
//! # `Unpin`
//!
//! In protte soarten binne altyd frij ferpleatst, sels as se fêst binne, om't se net fertrouwe op it hawwen fan in stabyl adres.Dit omfettet alle basistypen (lykas [`bool`], [`i32`], en referinsjes), lykas typen dy't allinich út dizze soarten besteane.Typen dy't it net skele oer pinning, ymplementearje de [`Unpin`] auto-trait, dy't it effekt fan [`Pin<P>`] annuleart.
//! Foar `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`en [`Box<T>`] funksjonearje identyk, lykas [`Pin`] `<&mut T>` en `&mut T`.
//!
//! Tink derom dat pinning en [`Unpin`] allinich ynfloed hawwe op it wiisde type `P::Target`, net op it oanwizer type `P` sels dat waard ferpakt yn [`Pin<P>`].As [`Box<T>`] al dan net [`Unpin`] is, hat gjin effekt op it gedrach fan [`Pin`]`<`[`Box`] `<T>>`(hjir is `T` it wiisde type).
//!
//! # Foarbyld: self-referential struct
//!
//! Foardat wy mear details yngeane om de garânsjes en karren te ferklearjen ferbûn mei `Pin<T>`, besprekke wy wat foarbylden foar hoe't it kin wurde brûkt.
//! Fiel jo frij om [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dit is in selsferwizend struktuer, om't it snijfjild wiist op it datafjild.
//! // Wy kinne de gearstaller dêr net mei in normale referinsje oer ynformearje, om't dit patroan net kin wurde beskreaun mei de gewoane lienregels.
//! //
//! // Ynstee brûke wy in rauwe oanwizer, hoewol ien dy't bekend is as nul te wêzen, om't wy witte dat it op 'e tekenrige wiist.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Om derfoar te soargjen dat de gegevens net bewege as de funksje weromkomt, pleatse wy se yn 'e heap wêr't se de libbensdoer fan it objekt sille bliuwe, en de iennige manier om tagong ta te krijen soe fia in oanwizer dernei wêze.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // wy meitsje de oanwizer allinich as de gegevens te plak binne oars binne se al ferpleatst foardat wy sels begon
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // wy wite dat dit feilich is om't it feroarjen fan in fjild de hiele struktuer net beweecht
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // De oanwizer moat nei de juste lokaasje wize, salang't de struktuer net is ferpleatst.
//! //
//! // Underwilens binne wy frij om de oanwizer om te bewegen.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Sûnt ús type Unpin net ymplementeart, sil dit net kompilearje:
//! // lit mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Foarbyld: yngripende dûbel-keppele list
//!
//! Yn in yngripende dûbel-keppele list dielt de kolleksje it ûnthâld eins net ta foar de eleminten sels.
//! Tawizing wurdt kontroleare troch de kliïnten, en eleminten kinne libje op in stapelframe dat koarter libbet dan de samling docht.
//!
//! Om dit wurk te meitsjen hat elk elemint oanwizings nei syn foargonger en opfolger yn 'e list.Eleminten kinne allinich tafoege wurde as se wurde pinned, om't it ferpleatsen fan 'e eleminten de oanwizers ongeldig makket.Boppedat sil de [`Drop`]-ymplemintaasje fan in keppele listelemint de oanwizings fan syn foargonger en opfolger patchje om himsels fan 'e list te ferwiderjen.
//!
//! Wichtich moatte wy derop fertrouwe dat [`drop`] neamd wurdt.As in elemint koe wurde ferdield of oars ûnjildich makke sûnder [`drop`] te skiljen, soene de oanwizings dêryn fan 'e oanbuorjende eleminten ûnjildich wurde, wat de gegevensstruktuer soe brekke.
//!
//! Dêrom komt pinning ek mei in [`drop`]-relatearre garânsje.
//!
//! # `Drop` guarantee
//!
//! It doel fan pinning is om te fertrouwen op 'e pleatsing fan guon gegevens yn it ûnthâld.
//! Om dit wurk te meitsjen is net allinich it ferpleatsen fan de gegevens beheind;it ûnthâld dat brûkt wurdt om de gegevens te bewarjen, opnij pleatse, of oars ûnjildich meitsje is ek beheind.
//! Konkreet, foar fêstmakke gegevens moatte jo de invariant bewarje dat *it ûnthâld net ûnjildich of opnij wurdt fanôf it momint dat it wurdt pind oant doe't [`drop`] hjit*.Allinich as [`drop`] weromkomt as panics, kin it ûnthâld opnij brûkt wurde.
//!
//! Unthâld kin "invalidated" wêze troch deallokaasje, mar ek troch in [`Some(v)`] te ferfangen troch [`None`], of [`Vec::set_len`] nei "kill" te neamen guon eleminten fan in vector.It kin opnij wurde brûkt troch [`ptr::write`] te brûken om it te oerskriuwen sûnder earst de destruktor te skiljen.Gjin fan dit is tastien foar pinned gegevens sûnder [`drop`] te skiljen.
//!
//! Dit is krekt de soart garânsje dat de yngripende keppele list út 'e foarige paragraaf goed moat funksjonearje.
//!
//! Merken dat dizze garânsje *net* betsjuttet dat ûnthâld net lekt!It is noch altyd folslein okay om [`drop`] nea te neamen op in fêstmakke elemint (bgl. Jo kinne [`mem::forget`] noch altyd skilje op in [`Pin`]`<`[`Box`] `<T>>`).Yn it foarbyld fan 'e dûbel-keppele list soe dat elemint gewoan yn' e list bliuwe.Jo meie de opslach *lykwols net frij meitsje of opnij brûke sûnder [`drop`]* te skiljen.
//!
//! # `Drop` implementation
//!
//! As jo type pinning brûkt (lykas de hjirboppe twa foarbylden), moatte jo foarsichtich wêze by it ymplementearjen fan [`Drop`].De [`drop`]-funksje nimt `&mut self`, mar dit hjit *ek as jo type earder waard pind*!It is as soe de gearstaller automatysk [`Pin::get_unchecked_mut`] neamd wurde.
//!
//! Dit kin noait in probleem feroarsaakje yn feilige koade, om't it útfieren fan in type dat fertrout op pinning ûnfeilige koade fereasket, mar wês bewust dat besluten om gebrûk te meitsjen fan pinning yn jo type (bygelyks troch wat operaasje út te fieren op [`Pin`]`<&Sels>`of [`Pin`] `<&mut Sels>`) hat ek konsekwinsjes foar jo [`Drop`]-ymplemintaasje: as in elemint fan jo type koe wurde fêstmakke, moatte jo [`Drop`] behannelje as ymplisyt nimme [`Pin`]`<&mut Sels>`.
//!
//!
//! Jo kinne bygelyks `Drop` sa folgje:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` is goed, om't wy witte dat dizze wearde no wer wurdt brûkt nei't se binne fallen.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Eigentlike dropkoade giet hjir.
//!         }
//!     }
//! }
//! ```
//!
//! De funksje `inner_drop` hat it type dat [`drop`]*moat* hawwe, dus dit soarget derfoar dat jo `self`/`this` net per ongelok brûke op in manier dy't yn striid is mei pinning.
//!
//! Boppedat, as jo type `#[repr(packed)]` is, sil de gearstaller automatysk fjilden ferpleatse om se falle te kinnen.It kin dat sels dwaan foar fjilden dy't tafallich genôch útrjochte binne.As konsekwinsje kinne jo gjin pinning brûke mei in `#[repr(packed)]`-type.
//!
//! # Projeksjes en strukturele pinning
//!
//! By it wurkjen mei pinned structs, ûntstiet de fraach hoe't men tagong hat ta de fjilden fan dy struktuer yn in metoade dy't gewoan [`Pin`]`<&mut Struct>`nimt.
//! De gebrûklike oanpak is om helpmetoaden te skriuwen (saneamde *projeksjes*) dy't [`Pin`] '<&mut Struct>' feroarje yn in ferwizing nei it fjild, mar hokker type moat dy referinsje hawwe?Is it [`Pin`]`<&mut Fjild>`as `&mut Field`?
//! Deselde fraach ûntstiet by de fjilden fan in `enum`, en ek by it beskôgjen fan container/wrapper-soarten lykas [`Vec<T>`], [`Box<T>`] of [`RefCell<T>`].
//! (Dizze fraach jildt foar sawol mutabele as dielde referinsjes, wy brûke gewoan it faker gefal fan mutabele referinsjes hjir foar yllustraasje.)
//!
//! It docht bliken dat it eins oan 'e auteur fan' e datastruktuer is om te besluten oft de pinned projeksje foar in bepaald fjild ['Pin'] '<&mut Struct>' feroaret yn ['Pin'] '<&mut Field>' of `&mut Field`.D'r binne lykwols wat beheiningen, en de wichtichste beheining is *konsistinsje*:
//! elk fjild kin *of* projekteare wurde nei in pinned referinsje,*of* hawwe pinning as diel fan 'e projeksje ferwidere.
//! As beide foar itselde fjild wurde dien, sil dat wierskynlik net sûn wêze!
//!
//! As auteur fan in datastruktuer kinne jo foar elk fjild beslute of "propagates" op dit fjild wurdt fêstmakke of net.
//! Pinning dat propageart wurdt ek "structural" neamd, om't it de struktuer fan it type folget.
//! Yn 'e folgjende subseksjes beskriuwe wy de oerwagings dy't moatte wurde makke foar elke kar.
//!
//! ## Pinjen *is net* struktureel foar `field`
//!
//! It kin kontra-yntuïtyf lykje dat it fjild fan in fêstmakke struktuer miskien net wurdt pind, mar dat is eins de maklikste kar: as in [`Pin`]`<&mut Fjild>`noait wurdt oanmakke, kin neat ferkeard gean!Dat, as jo beslute dat guon fjilden gjin strukturele pinning hawwe, moatte jo allinich soargje dat jo noait in pinned referinsje meitsje nei dat fjild.
//!
//! Fjilden sûnder strukturele pinning kinne in projeksjemetoade hawwe dy't [`Pin`]`<&mut Struct>`yn `&mut Field` feroaret:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dit is goed, om't `field` noait wurdt beskôge as pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Jo kinne ek `impl Unpin for Struct`*ek as* it type `field` net [`Unpin`] is.Wat dat type tinkt oer pinning is net relevant as der noait gjin [`Pin`]`<&mut Field>`is oanmakke.
//!
//! ## Pinjen *is* struktureel foar `field`
//!
//! De oare opsje is om te besluten dat pinnen "structural" is foar `field`, wat betsjut dat as it struktuer wurdt pind, dan is it fjild ek.
//!
//! Hjirmei kinne jo in projeksje skriuwe dy't in [`Pin`] '<&mut fjild>' oanmakket, en sa tsjûgje dat it fjild is pind:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dit is goed, om't `field` wurdt pinned as `self` is.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Strukturele pinning komt lykwols mei in pear ekstra easken:
//!
//! 1. De struktuer moat allinich [`Unpin`] wêze as alle strukturele fjilden [`Unpin`] binne.Dit is de standert, mar [`Unpin`] is in feilige trait, dus as de auteur fan 'e struktuer is it jo ferantwurdlikens *net* om sokssawat as `impl<T> Unpin for Struct<T>` ta te foegjen.
//! (Tink derom dat it tafoegjen fan in projeksje-operaasje ûnfeilige koade fereasket, sadat [`Unpin`] in feilige trait is, brekt it prinsipe net dat jo allinich soargen hoege te meitsjen as jo 'ûnfeilich' brûke.)
//! 2. De destruktor fan 'e struktuer moat strukturele fjilden net út syn argumint ferpleatse.Dit is it krekte punt dat waard grutbrocht yn 'e [previous section][drop-impl]: `drop` nimt `&mut self`, mar de struktuer (en dus syn fjilden) soe earder al pind west hawwe.
//!     Jo moatte garandearje dat jo gjin fjild ferpleatse yn jo [`Drop`]-ymplemintaasje.
//!     Benammen, lykas earder útlein, betsjuttet dit dat jo struktuer *net*`#[repr(packed)]` moat wêze.
//!     Sjoch dy paragraaf foar hoe [`drop`] te skriuwen op in manier wêrop de gearstaller jo kin helpe net per ongelok pinning te brekken.
//! 3. Jo moatte derfoar soargje dat jo de [`Drop` guarantee][drop-guarantee] hanthavenje:
//!     ienris jo struktuer is pind, wurdt it ûnthâld dat de ynhâld befettet net oerskreaun of ôfdield sûnder de destruktoaren fan 'e ynhâld te neamen.
//!     Dit kin lestich wêze, lykas tsjûge troch [`VecDeque<T>`]: de destruktor fan [`VecDeque<T>`] kin mislearje om [`drop`] op alle eleminten te neamen as ien fan 'e destruktors panics.Dit is yn striid mei de [`Drop`]-garânsje, om't it kin liede ta eleminten dy't wurde oardiele sûnder dat har destruktor wurdt neamd.([`VecDeque<T>`] hat gjin pinneprojeksjes, dus dit feroarsaket gjin sûnens.)
//! 4. Jo moatte gjin oare operaasjes oanbiede dy't liede kinne ta dat gegevens wurde ferpleatst út 'e strukturele fjilden as jo type wurdt pind.As de struktuer bygelyks in [`Option<T>`] befettet en d'r in 'take'-like operaasje is mei type `fn(Pin<&mut Struct<T>>) -> Option<T>`, kin dy operaasje brûkt wurde om in `T` te ferpleatsen út in fêstmakke `Struct<T>`-wat betsjut dat pinnen net struktureel kin wêze foar it fjild dat dit hat data.
//!
//!     Foar in komplekser foarbyld fan it ferpleatsen fan gegevens út in fêstmakke type, stel dan foar as [`RefCell<T>`] in metoade `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` hie.
//!     Dan koene wy it folgjende dwaan:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dit is katastrofysk, it betsjuttet dat wy de ynhâld fan 'e [`RefCell<T>`] (mei `RefCell::get_pin_mut`) earst kinne pinje en dy ynhâld dan ferpleatse kinne mei de feroarbere referinsje dy't wy letter krigen.
//!
//! ## Examples
//!
//! Foar in type lykas [`Vec<T>`] hawwe beide mooglikheden (strukturele pinning as net) sin.
//! In [`Vec<T>`] mei strukturele pinning kin `get_pin`/`get_pin_mut`-metoaden hawwe om ferwizings nei eleminten te krijen.It koe lykwols *net* tastean om [`pop`][Vec::pop] op in fêstmakke [`Vec<T>`] te roppen, om't dat de (struktureel fêstpinne) ynhâld soe ferpleatse!It koe [`push`][Vec::push] ek net tastean, wat kin opnij tawize en dus ek de ynhâld ferpleatse.
//!
//! In [`Vec<T>`] sûnder strukturele pinning koe `impl<T> Unpin for Vec<T>`, om't de ynhâld nea wurdt pind en de [`Vec<T>`] sels is prima mei ek ferpleatst wurde.
//! Op dat punt hat pinning gewoan hielendal gjin effekt op 'e vector.
//!
//! Yn 'e standertbibleteek hawwe oanwizerstypen oer it algemien gjin strukturele pinning, en dus biede se gjin pinneprojeksjes oan.Dit is wêrom `Box<T>: Unpin` foar alle `T` hâldt.
//! It is sinfol om dit te dwaan foar oanwizertypen, om't it ferpleatsen fan 'e `Box<T>` de `T` eins net beweecht: de [`Box<T>`] kin frij beweechber wêze (ek wol `Unpin`), sels as de `T` net is.Eins, sels [`Pin`]`<`[`Box`] `<T>>`en [`Pin`] `<&mut T>` binne altyd [`Unpin`] sels, om deselde reden: har ynhâld (de `T`) wurde pind, mar de oanwizings sels kinne ferpleatst wurde sûnder de pinned gegevens te ferpleatsen.
//! Foar sawol [`Box<T>`] as [`Pin`]`<`[`Box`] `<T>>`, oft de ynhâld is fêstmakke, is folslein ûnôfhinklik fan oft de oanwizer wurdt fêstmakke, wat betsjut dat fêst *net* struktureel is.
//!
//! By it ymplementearjen fan in [`Future`]-kombinator, sille jo normaal strukturele pinning nedich wêze foar de nestele futures, om't jo pinned referinsjes moatte krije om [`poll`] te neamen.
//! Mar as jo kombinator oare gegevens befettet dy't net nedich binne, dan kinne jo dizze fjilden net struktureel meitsje en dêrmei frij tagong krije mei in feroarbere referinsje, sels as jo gewoan [`Pin`]` <&mut Self> 'hawwe (lykas lykas yn jo eigen [`poll`]-ymplemintaasje).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// In spelde oanwizer.
///
/// Dit is in omslach om in soarte fan oanwizer dy't de oanwizer "pin" syn wearde op syn plak makket, en foarkomt dat de wearde dy't troch dizze oanwizer wurdt neamd wurdt ferpleatst wurdt, útsein as hy [`Unpin`] ymplementeart.
///
///
/// *Sjoch de [`pin` module] dokumintaasje foar útlis oer pinning.*
///
/// [`pin` module]: self
///
// Note: de `Clone`-ôflaat hjirûnder feroarsaket sûnens, om't it mooglik is te ymplementearjen
// `Clone` foar feroarbere referinsjes.
// Sjoch <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> foar mear details.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// De folgjende ymplementaasjes binne net ûntliend om problemen mei sûnens te foarkommen.
// `&self.pointer` soe net tagonklik wêze moatte foar net fertroude trait-ymplementaasjes.
//
// Sjoch <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> foar mear details.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruearje in nije `Pin<P>` om in oanwizer nei guon gegevens fan in type dat [`Unpin`] ymplementeart.
    ///
    /// Oars as `Pin::new_unchecked` is dizze metoade feilich omdat de oanwizer `P` derferwiist nei in [`Unpin`]-type, wêrtroch de pinninggaranties annulearje.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // VEILIGHEID: de wearde nei wiisd is `Unpin`, en hat dus gjin easken
        // om pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Pakket dizze `Pin<P>` út de weromlizzende oanwizer werom.
    ///
    /// Dit fereasket dat de gegevens yn dizze `Pin` [`Unpin`] binne, sadat wy de pinnende invarianten kinne negearje as se útpakke.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruearje in nije `Pin<P>` om in referinsje nei guon gegevens fan in type dat `Unpin` al of net kin ymplementearje.
    ///
    /// As `pointer`-ferwizings nei in `Unpin`-type, moat `Pin::new` ynstee wurde brûkt.
    ///
    /// # Safety
    ///
    /// Dizze konstrukteur is ûnfeilich, om't wy net kinne garandearje dat de gegevens dy't `pointer` oanwiist is pind, wat betsjut dat de gegevens net wurde ferpleatst of de opslach fan dizze ûnjildich wurdt oant se falle.
    /// As de konstruearre `Pin<P>` net garandeart dat de gegevens wêrnei't `P` wiist, wurdt fêstmakke, is dat in ynbreuk op it API-kontrakt en kin dit liede ta undefined gedrach yn lettere (safe)-operaasjes.
    ///
    /// Troch dizze metoade te brûken meitsje jo in promise oer de `P::Deref`-en `P::DerefMut`-ymplementaasjes, as se besteane.
    /// It wichtigste is dat se net út har `self`-arguminten hoege te bewegen: `Pin::as_mut` en `Pin::as_ref` sille `DerefMut::deref_mut` en `Deref::deref`*oproppe op 'e pinned oanwizer* en ferwachtsje dat dizze metoaden de pinnende invarianten hanthavenje.
    /// Boppedat, troch dizze metoade te neamen promise dat de referinsje `P` dereferinsjes nei net wer ferpleatst wurde;yn it bysûnder moat it net mooglik wêze om in `&mut P::Target` te krijen en dan út dy referinsje wei te gean (brûk bygelyks [`mem::swap`]).
    ///
    ///
    /// Bygelyks it skiljen fan `Pin::new_unchecked` op in `&'a mut T` is ûnfeilich, om't jo it foar de opjûne libbensdoer `'a` kinne pinje, jo hawwe gjin kontrôle oer oft it wurdt fêstholden as `'a` einiget:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dit soe betsjutte dat de pointee `a` noait wer kin bewege.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // It adres fan `a` feroare yn 'b' 's stack slot, dat `a` waard ferpleatst, hoewol wy it earder hawwe fêstmakke!Wy hawwe it fêststeande API-kontrakt skeind.
    /////
    /// }
    /// ```
    ///
    /// In wearde, ienris fêstmakke, moat foar ivich fêstholden bliuwe (útsein as it type `Unpin` ymplementeart).
    ///
    /// Likegoed is `Pin::new_unchecked` op in `Rc<T>` oproppe ûnfeilich, om't der aliassen kinne wêze foar deselde gegevens dy't net ûnderwurpen binne oan 'e pinningbeheiningen:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dit soe betsjutte dat de pointee noait wer kin bewege.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // No, as `x` de iennige referinsje wie, hawwe wy in feroarbere ferwizing nei gegevens dy't wy hjirboppe pinne, dy't wy kinne brûke om it te ferpleatsen lykas wy yn it foarige foarbyld hawwe sjoen.
    ///     // Wy hawwe it fêststeande API-kontrakt skeind.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Kriget in pinned dielde referinsje fan dizze pinned oanwizer.
    ///
    /// Dit is in generike metoade om fan `&Pin<Pointer<T>>` nei `Pin<&T>` te gean.
    /// It is feilich om't, as ûnderdiel fan 'e kontrakt fan `Pin::new_unchecked`, de oanwizer net kin bewege nei't `Pin<Pointer<T>>` oanmakke is.
    ///
    /// "Malicious" ymplementaasjes fan `Pointer::Deref` wurde ek útsletten troch it kontrakt fan `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // VEILIGHEID: sjoch dokumintaasje oer dizze funksje
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Pakket dizze `Pin<P>` út de weromlizzende oanwizer werom.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich.Jo moatte garandearje dat jo trochgean mei it behanneljen fan de oanwizer `P` as fêstmakke neidat jo dizze funksje hawwe neamd, sadat de invarianten op it `Pin`-type kinne wurde bewarre.
    /// As de koade mei de resultearjende `P` de pinnende invarianten net trochhâldt, is dat in ynbreuk op it API-kontrakt en kin liede ta undefined gedrach yn lettere (safe)-operaasjes.
    ///
    ///
    /// As de ûnderlizzende gegevens [`Unpin`] binne, moat [`Pin::into_inner`] yn plak wurde brûkt.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Krijt in pinned feroarbere referinsje fan dizze pinned oanwizer.
    ///
    /// Dit is in generike metoade om fan `&mut Pin<Pointer<T>>` nei `Pin<&mut T>` te gean.
    /// It is feilich om't, as ûnderdiel fan 'e kontrakt fan `Pin::new_unchecked`, de oanwizer net kin bewege nei't `Pin<Pointer<T>>` oanmakke is.
    ///
    /// "Malicious" ymplementaasjes fan `Pointer::DerefMut` wurde ek útsletten troch it kontrakt fan `Pin::new_unchecked`.
    ///
    /// Dizze metoade is nuttich as jo meardere petearen dogge nei funksjes dy't it fêstmakke type ferbrûke.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // wat dwaan
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` ferbrûkt `self`, dus opnij betelle de `Pin<&mut Self>` fia `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // VEILIGHEID: sjoch dokumintaasje oer dizze funksje
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Jout in nije wearde ta oan it ûnthâld efter de pinned referinsje.
    ///
    /// Dit oerskriuwt pinned gegevens, mar dat is goed: syn destruktor wurdt riden foardat it wurdt oerskreaun, dus wurdt gjin fêstboarring garandearre.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstrueart in nije pin troch de ynterieurwearde yn kaart te bringen.
    ///
    /// As jo bygelyks in `Pin` fan in fjild fan wat wolle krije, kinne jo dit brûke om tagong te krijen ta dat fjild yn ien rigel koade.
    /// D'r binne lykwols ferskate gotchas mei dizze "pinning projections";
    /// sjoch de [`pin` module] dokumintaasje foar fierdere details oer dat ûnderwerp.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich.
    /// Jo moatte garandearje dat de gegevens dy't jo weromkomme net bewege salang't de argumintwearde net beweecht (bygelyks om't it ien fan 'e fjilden fan dy wearde is), en ek dat jo net út it argumint komme dat jo ûntfange de ynterieurfunksje.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // VEILIGHEID: it feiligenskontrakt foar `new_unchecked` moat wêze
        // befêstige troch de beller.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Krijt in dielde referinsje út in pin.
    ///
    /// Dit is feilich, om't it net mooglik is om út in dielde referinsje te bewegen.
    /// It kin lykje as is hjir in probleem mei ynterieurmutabiliteit: eins is it * mooglik om in `T` út in `&RefCell<T>` te ferpleatsen.
    /// Dit is lykwols gjin probleem, salang't d'r ek gjin `Pin<&T>` bestiet dy't op deselde gegevens wiist, en `RefCell<T>` lit jo net in pinned ferwizing nei de ynhâld meitsje.
    ///
    /// Sjoch de diskusje oer ["pinning projections"] foar fierdere details.
    ///
    /// Note: `Pin` ymplementeart ek `Deref` nei it doel, dat kin brûkt wurde om tagong te krijen ta de ynderlike wearde.
    /// `Deref` leveret lykwols allinich in referinsje dy't libbet sa lang as de liening fan 'e `Pin`, net it libben fan' e `Pin` sels.
    /// Dizze metoade lit de `Pin` feroarje yn in referinsje mei deselde libbensdoer as de orizjinele `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konverteart dizze `Pin<&mut T>` yn in `Pin<&T>` mei deselde libbensdoer.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Krijt in feroarbere ferwizing nei de gegevens yn dizze `Pin`.
    ///
    /// Dit fereasket dat de gegevens yn dizze `Pin` `Unpin` binne.
    ///
    /// Note: `Pin` ymplementeart ek `DerefMut` oan 'e gegevens, dy't brûkt wurde kinne om tagong te krijen ta de ynderlike wearde.
    /// `DerefMut` leveret lykwols allinich in referinsje dy't libbet sa lang as de liening fan 'e `Pin`, net it libben fan' e `Pin` sels.
    ///
    /// Dizze metoade lit de `Pin` feroarje yn in referinsje mei deselde libbensdoer as de orizjinele `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Krijt in feroarbere ferwizing nei de gegevens yn dizze `Pin`.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich.
    /// Jo moatte garandearje dat jo de gegevens nea sille ferpleatse út 'e mutabele referinsje dy't jo ûntfange as jo dizze funksje neame, sadat de invarianten op it `Pin`-type kinne wurde bewarre.
    ///
    ///
    /// As de ûnderlizzende gegevens `Unpin` binne, moat `Pin::get_mut` yn plak wurde brûkt.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// In nije pin konstruearje troch de ynterieurwearde yn kaart te bringen.
    ///
    /// As jo bygelyks in `Pin` fan in fjild fan wat wolle krije, kinne jo dit brûke om tagong te krijen ta dat fjild yn ien rigel koade.
    /// D'r binne lykwols ferskate gotchas mei dizze "pinning projections";
    /// sjoch de [`pin` module] dokumintaasje foar fierdere details oer dat ûnderwerp.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich.
    /// Jo moatte garandearje dat de gegevens dy't jo weromkomme net bewege salang't de argumintwearde net beweecht (bygelyks om't it ien fan 'e fjilden fan dy wearde is), en ek dat jo net út it argumint komme dat jo ûntfange de ynterieurfunksje.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // VEILIGHEID: de beller is ferantwurdlik foar it net ferpleatsen fan de
        // wearde út dizze referinsje.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // VEILIGHEID: om't de wearde fan `this` garandearre is dat it net hat
        // is ferpleatst, dizze oprop nei `new_unchecked` is feilich.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Krij in pinned referinsje fan in statyske referinsje.
    ///
    /// Dit is feilich, om't `T` wurdt liend foar it `'static`-libben, dat noait einiget.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // VEILIGHEID: De 'statyske liening garandeart dat de gegevens net wêze sille
        // moved/invalidated oant it falt (wat noait is).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Krij in pinned mutabele referinsje fan in statyske mutable referinsje.
    ///
    /// Dit is feilich, om't `T` wurdt liend foar it `'static`-libben, dat noait einiget.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // VEILIGHEID: De 'statyske liening garandeart dat de gegevens net wêze sille
        // moved/invalidated oant it falt (wat noait is).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dit betsjut dat elke ympl fan `CoerceUnsized` wêrtroch twang kin
// in type dat `Deref<Target=impl !Unpin>` ympliseart nei in type dat `Deref<Target=Unpin>` ympliseart is net sûn.
// Soksoarte impl soe wierskynlik om oare redenen net sûn wêze, dus wy moatte gewoan oppasse dat sokke impls net yn std lânje.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}