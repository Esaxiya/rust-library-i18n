//! Traits foar konversaasjes tusken soarten.
//!
//! De traits yn dizze module biedt in manier om te konvertearjen fan it iene nei it oare type.
//! Elke trait tsjinnet in oar doel:
//!
//! - Ymplementearje de [`AsRef`] trait foar goedkeape referinsjes-nei-referinsjekonversjes
//! - Ymplementearje de [`AsMut`] trait foar goedkeap konvertearbare mutable-nei-mutable
//! - Ymplementearje de [`From`] trait foar konsumpsje fan wearde-nei-wearde-konversaasjes
//! - Ymplementearje de [`Into`] trait foar konsumearjen fan wearde-oan-wearde-konversaasjes nei typen bûten de hjoeddeiske crate
//! - De [`TryFrom`] en [`TryInto`] traits gedrage har as [`From`] en [`Into`], mar moatte wurde ymplementeare as de konverzje kin mislearje.
//!
//! De traits yn dizze module wurde faak brûkt as trait bounds foar generike funksjes, sadat arguminten fan meardere soarten wurde stipe.Sjoch de dokumintaasje fan elke trait foar foarbylden.
//!
//! As auteur fan 'e bibleteek moatte jo altyd leaver [`From<T>`][`From`] of [`TryFrom<T>`][`TryFrom`] ymplementearje yn plak fan [`Into<U>`][`Into`] of [`TryInto<U>`][`TryInto`], om't [`From`] en [`TryFrom`] gruttere fleksibiliteit leverje en lykweardige [`Into`]-of [`TryInto`]-ymplementaasjes fergees oanbiede, troch in blanket-ymplemintaasje yn' e standertbibleteek.
//! As jo rjochtsje op in ferzje foarôfgeand oan Rust 1.41, kin it nedich wêze om [`Into`] of [`TryInto`] direkt te ymplementearjen as jo konvertearje nei in type bûten de hjoeddeiske crate.
//!
//! # Generike ymplemintaasjes
//!
//! - [`AsRef`] en [`AsMut`] autodereferinsje as it ynterne type in referinsje is
//! - [`Fan`]`<U>foar T` ympliseart [`Yn ']`</u><T><U>foar U`</u>
//! - [`TryFrom`]`<U>foar T` ympliseart [`TryInto`]`</u><T><U>foar U`</u>
//! - [`From`] en [`Into`] binne refleksyf, wat betsjut dat alle soarten sels `into` en `from` sels kinne
//!
//! Sjoch elke trait foar foarbylden fan gebrûk.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// De identiteitsfunksje.
///
/// Twa dingen binne wichtich om te notearjen oer dizze funksje:
///
/// - It is net altyd lykweardich oan in sluting lykas `|x| x`, om't de sluting `x` kin twinge yn in oar type.
///
/// - It ferpleatst de ynput `x` trochjûn nei de funksje.
///
/// Hoewol it miskien frjemd liket in funksje te hawwen dy't de ynput gewoan weromkomt, binne d'r wat nijsgjirrige gebrûken.
///
///
/// # Examples
///
/// `identity` brûke om neat te dwaan yn in folchoarder fan oare, nijsgjirrige funksjes:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Litte wy dwaan as ien tafoegje in ynteressante funksje is.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` brûke as "do nothing" basissaak yn in betingst:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Doch mear nijsgjirrige dingen ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` brûke om de `Some`-farianten fan in iterator fan `Option<T>` te behâlden:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Wurdt brûkt om in goedkeape referinsje-nei-referinsje-konverzje te dwaan.
///
/// Dizze trait liket op [`AsMut`] dy't wurdt brûkt foar konvertearjen tusken feroarbere referinsjes.
/// As jo in djoere konverzje moatte dwaan, is it better om [`From`] te ymplementearjen mei type `&T` of in oanpaste funksje te skriuwen.
///
/// `AsRef` hat deselde hantekening as [`Borrow`], mar [`Borrow`] is yn pear aspekten oars:
///
/// - Oars as `AsRef` hat [`Borrow`] in deken foar elke `T`, en kin brûkt wurde om in referinsje as in wearde te akseptearjen.
/// - [`Borrow`] fereasket ek dat [`Hash`], [`Eq`] en [`Ord`] foar liende wearde lykweardich binne oan dy fan 'e eigene wearde.
/// Om dizze reden, as jo mar ien fjild fan in struct liene wolle, kinne jo `AsRef` ymplementearje, mar net [`Borrow`].
///
/// **Note: Dizze trait moat net mislearje **.As de konverzje mislearret, brûk dan in tawijd metoade dy't in [`Option<T>`] as in [`Result<T, E>`] retourneert.
///
/// # Generike ymplemintaasjes
///
/// - `AsRef` auto-dereferences as it ynterne type in referinsje is as in feroarbere referinsje (bgl: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Troch trait bounds te brûken kinne wy arguminten fan ferskate soarten akseptearje, salang't se kinne wurde konvertearre nei it oantsjutte type `T`.
///
/// Bygelyks: Troch in generike funksje te meitsjen dy't in `AsRef<str>` nimt, sprekke wy út dat wy alle referinsjes akseptearje wolle dy't as argumint kinne wurde konverteare nei [`&str`].
/// Om't sawol [`String`] as [`&str`] `AsRef<str>` ymplementearje, kinne wy beide akseptearje as ynfierargumint.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Fiert de konverzje út.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Wurdt brûkt om in goedkeap mutable-to-mutable referinsjekonversje te dwaan.
///
/// Dizze trait liket op [`AsRef`], mar wurdt brûkt foar konvertearjen tusken feroarbere referinsjes.
/// As jo in djoere konverzje moatte dwaan, is it better om [`From`] te ymplementearjen mei type `&mut T` of in oanpaste funksje te skriuwen.
///
/// **Note: Dizze trait moat net mislearje **.As de konverzje mislearret, brûk dan in tawijd metoade dy't in [`Option<T>`] as in [`Result<T, E>`] retourneert.
///
/// # Generike ymplemintaasjes
///
/// - `AsMut` auto-dereferinsjes as it ynterne type in feroarbere referinsje is (bgl: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Mei `AsMut` as trait bound foar in generike funksje kinne wy alle feroarbere referinsjes akseptearje dy't kinne wurde konverteare nei type `&mut T`.
/// Om't [`Box<T>`] `AsMut<T>` ymplementeart, kinne wy in funksje `add_one` skriuwe dy't alle arguminten nimt dy't kinne wurde konverteare nei `&mut u64`.
/// Om't [`Box<T>`] `AsMut<T>` ymplementeart, aksepteart `add_one` ek arguminten fan type `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Fiert de konverzje út.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// In wearde-wearde-konverzje dy't de ynfierwearde ferbrûkt.It tsjinoerstelde fan [`From`].
///
/// Men moat foarkomme dat [`Into`] útfiert en [`From`] yn plak is.
/// Ymplemintaasje fan [`From`] leveret automatysk ien mei in ymplemintaasje fan [`Into`] troch de blanket-ymplemintaasje yn 'e standertbibleteek.
///
/// Brûk [`Into`] leaver as [`From`] as jo trait bounds oantsjutte op in generike funksje om derfoar te soargjen dat typen dy't allinich [`Into`] ymplementearje ek kinne wurde brûkt.
///
/// **Note: Dizze trait moat net mislearje **.As de konverzje kin mislearje, brûk dan [`TryInto`].
///
/// # Generike ymplemintaasjes
///
/// - [`Fan`]`<T>foar U` ympliseart `Into<U> for T`
/// - [`Into`] is refleksyf, wat betsjut dat `Into<T> for T` wurdt ymplementearre
///
/// # [`Into`] ymplementearje foar konversaasjes nei eksterne typen yn âlde ferzjes fan Rust
///
/// Foarôfgeand oan Rust 1.41, as it bestimmingstype gjin diel wie fan 'e hjoeddeistige crate, koene jo [`From`] net direkt ymplementearje.
/// Nim bygelyks dizze koade:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dit sil net kompilearje yn âldere ferzjes fan 'e taal, om't de weesregels fan Rust eartiids in bytsje stranger wiene.
/// Om dit om te gean, kinne jo [`Into`] direkt ymplementearje:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// It is wichtich om te begripen dat [`Into`] gjin [`From`]-ymplemintaasje leveret (lykas [`From`] docht mei [`Into`]).
/// Dêrom moatte jo altyd besykje [`From`] út te fieren en dan weromfalle nei [`Into`] as [`From`] net kin wurde ymplementeare.
///
/// # Examples
///
/// [`String`] ymplementeart [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Om út te drukken dat wy wolle dat in generike funksje alle arguminten nimt dy't kinne wurde konvertearre nei in spesifisearre type `T`, kinne wy in trait bound fan [`Into`]`brûke<T>`.
///
/// Bygelyks: De funksje `is_hello` nimt alle arguminten dy't kinne wurde omset yn in [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Fiert de konverzje út.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Wurdt brûkt om konverzjes fan wearde-oan-wearde te dwaan by it konsumearjen fan de ynfierwearde.It is it wjersidich fan [`Into`].
///
/// Men moat altyd de útfiering fan `From` boppe [`Into`] foarkomme, om't `From` automatysk in ymplemintaasje fan [`Into`] foarsjocht troch de ymplemintaasje fan deken yn 'e standertbibleteek.
///
///
/// Implementearje allinich [`Into`] as jo rjochtsje op in ferzje foarôfgeand oan Rust 1.41 en konvertearje nei in type bûten de hjoeddeiske crate.
/// `From` koe dizze soart konversaasjes net dwaan yn eardere ferzjes fanwegen de weesregels fan Rust.
/// Sjoch [`Into`] foar mear details.
///
/// Brûk foarkar [`Into`] boppe `From` as jo trait bounds oantsjutte op in generike funksje.
/// Op dizze manier kinne soarten dy't [`Into`] direkt ymplementearje ek wurde brûkt as arguminten.
///
/// De `From` is ek heul nuttich by it útfieren fan flaterbehanneling.By it oanlizzen fan in funksje dy't net slagget, sil it retourtype algemien wêze fan 'e foarm `Result<T, E>`.
/// De `From` trait ferienfâldigt flaterbehanneling troch in funksje ien flatertype werom te jaan dat meardere flatertypen ynkapselt.Sjoch de seksje "Examples" en [the book][book] foar mear details.
///
/// **Note: Dizze trait moat net mislearje **.As de konverzje kin mislearje, brûk dan [`TryFrom`].
///
/// # Generike ymplemintaasjes
///
/// - `From<T> for U` ympliseart [`Into`]`<U>foar T`</u>
/// - `From` is refleksyf, wat betsjut dat `From<T> for T` wurdt ymplementearre
///
/// # Examples
///
/// [`String`] ymplementeart `From<&str>`:
///
/// In eksplisite konverzje fan in `&str` nei in string wurdt as folgjend dien:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// By it útfieren fan flaterbehanneling is it faaks nuttich om `From` te ymplementearjen foar jo eigen flatertype.
/// Troch konvertearjen fan ûnderlizzende flatertypen nei ús eigen oanpaste flatertype dat it ûnderlizzende flatertype ynkapselt, kinne wy in inkeld flatertype weromjaan sûnder ynformaasje te ferliezen oer de ûnderlizzende oarsaak.
/// De '?'-operator konverteart automatysk it ûnderlizzende flatertype nei ús oanpaste flatertype troch `Into<CliError>::into` te skiljen, dat automatysk wurdt levere by it útfieren fan `From`.
/// De gearstaller liedt dan út hokker ymplemintaasje fan `Into` moat wurde brûkt.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Fiert de konverzje út.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// In poging ta konverzje dy't `self` ferbrûkt, wat wol of net djoer kin wêze.
///
/// Biblioteek-auteurs moatte dizze trait normaal net direkt ymplementearje, mar moatte leaver de [`TryFrom`] trait ymplementearje, dy't gruttere fleksibiliteit biedt en in lykweardige `TryInto`-ymplemintaasje fergees biedt, troch in tekkenimplementaasje yn 'e standertbibleteek.
/// Sjoch foar mear ynformaasje hjiroer de dokumintaasje foar [`Into`].
///
/// # `TryInto` útfiere
///
/// Dit lijt deselde beheiningen en redenaasjes as it ymplementearjen fan [`Into`], sjoch dêr foar details.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// It type is weromjûn yn gefal fan in konversaasjeflater.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Fiert de konverzje út.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Ienfâldige en feilige type konversaasjes dy't ûnder guon omstannichheden op in kontroleare manier kinne mislearje.It is it wjersidich fan [`TryInto`].
///
/// Dit is handich as jo in type konverzje dogge dy't triviaal kin slagje, mar miskien ek spesjale ôfhanneling nedich is.
/// Bygelyks is d'r gjin manier om in [`i64`] yn in [`i32`] te konvertearjen mei de [`From`] trait, om't in [`i64`] in wearde kin befetsje dy't in [`i32`] net kin fertsjintwurdigje en sadat de konverzje gegevens kwytreitsje soe.
///
/// Dit kin wurde behannele troch de [`i64`] ôf te trunken nei in [`i32`] (yn essinsje de ["i64"] 's wearde modulo [`i32::MAX`] te jaan) of troch gewoan [`i32::MAX`] werom te jaan, of troch in oare metoade.
/// De [`From`] trait is bedoeld foar perfekte konversaasjes, sadat de `TryFrom` trait de programmeur ynformeart as in type konverzje min kin gean en lit se beslute hoe't se der mei omgeane.
///
/// # Generike ymplemintaasjes
///
/// - `TryFrom<T> for U` ympliseart [`TryInto`]`<U>foar T`</u>
/// - [`try_from`] is refleksyf, wat betsjut dat `TryFrom<T> for T` wurdt ymplementearre en kin net mislearje-it assosjeare `Error`-type foar it skiljen fan `T::try_from()` op in wearde fan it type `T` is [`Infallible`].
/// As it [`!`]-type wurdt stabilisearre, sille [`Infallible`] en [`!`] ekwivalint wêze.
///
/// `TryFrom<T>` kin as folgjend wurde ymplementeare:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Lykas beskreaun implementeart [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunet `big_number` stil, fereasket de trunkaasje nei it feit op te spoaren en te behanneljen.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Jout in flater omdat `big_number` te grut is om yn in `i32` te passen.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Jout `Ok(3)` werom.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// It type is weromjûn yn gefal fan in konversaasjeflater.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Fiert de konverzje út.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// As liften oer&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// As liften oer &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ferfang de boppesteande impls foar&/&mut troch de folgjende algemiene:
// // As liften oer Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>foar D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut tilt oer &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ferfang de boppesteande impl foar &mut troch de folgjende algemiene:
// // AsMut tilt oer DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>foar D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Fan ympliseart Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Fan (en dus Into) is refleksyf
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabiliteitsnota:** Dizze impl bestiet noch net, mar wy binne "reserving space" om it ta te foegjen yn 'e future.
/// Sjoch [rust-lang/rust#64715][#64715] foar details.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ynstee in prinsipiële oplossing dwaan.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom ympliseart TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Unfeilbere konversaasjes binne semantysk ekwivalint mei feilbere konversaasjes mei in ûnbewenne flatertype.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// DE TYPE FOAR FOUT FOUT
////////////////////////////////////////////////////////////////////////////////

/// It flater type foar flaters dy't noait kinne barre.
///
/// Sûnt dit enum gjin fariant hat, kin in wearde fan dit type noait eins bestean.
/// Dit kin nuttich wêze foar generike API's dy't [`Result`] brûke en it flater type parameterisearje, om oan te jaan dat it resultaat altyd [`Ok`] is.
///
/// Bygelyks, de [`TryFrom`] trait (konverzje dy't in [`Result`] retourneert) hat in tekkenimplementaasje foar alle soarten wêr't in omkearde [`Into`]-ymplemintaasje bestiet.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future kompatibiliteit
///
/// Dit enum hat deselde rol as [the `!`“never”type][never], dy't ynstabyl is yn dizze ferzje fan Rust.
/// As `!` wurdt stabilisearre, planje wy `Infallible` in alias derfoar te meitsjen:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... en úteinlik `Infallible` ferfalle.
///
/// D'r is lykwols ien gefal wêr't `!`-syntaksis kin wurde brûkt foardat `!` wurdt stabilisearre as in folweardich type: yn 'e posysje fan it retourtype fan in funksje.
/// Spesifyk is it mooglik ymplementaasjes foar twa ferskillende oanwizertypes foar funksjes:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Mei't `Infallible` in enum is, is dizze koade jildich.
/// As `Infallible` lykwols in alias wurdt foar de never type, sille de twa 'impl's begjinne te oerlaapjen en wurde dêrom net tastien troch de gearhingingsregels fan' e taal trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}