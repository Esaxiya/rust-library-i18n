//! De libcore prelude
//!
//! Dizze module is bedoeld foar brûkers fan libcore dy't ek net keppele binne oan libstd.
//! Dizze module wurdt standert ymporteare as `#![no_std]` op deselde manier wurdt brûkt as de prelude fan 'e standertbibleteek.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// De ferzje fan 2015 fan 'e kearn prelude.
///
/// Sjoch de [module-level documentation](self) foar mear.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// De 2018-ferzje fan 'e kearn prelude.
///
/// Sjoch de [module-level documentation](self) foar mear.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// De ferzje fan 2021 fan 'e kearn prelude.
///
/// Sjoch de [module-level documentation](self) foar mear.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Foegje mear dingen ta.
}