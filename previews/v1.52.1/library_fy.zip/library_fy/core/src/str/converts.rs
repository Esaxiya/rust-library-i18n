//! Manieren om in `str` te meitsjen fan byte slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konverteart in stikje bytes nei in tekenrige.
///
/// In tekenrige ([`&str`]) is makke fan bytes ([`u8`]), en in byte plak ([`&[u8]`][byteslice]) wurdt makke fan bytes, sadat dizze funksje konverteart tusken de twa.
/// Net alle byteplakken binne jildige tekenplakken, lykwols: [`&str`] fereasket dat it jildich UTF-8 is.
/// `from_utf8()` kontrolearret om te soargjen dat de bytes jildich binne UTF-8, en docht dan de konverzje.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// As jo der wis fan binne dat de byteplaat UTF-8 jildich is, en jo de overhead fan 'e jildichheidskontrôle net wolle oanmeitsje, is d'r in ûnfeilige ferzje fan dizze funksje, [`from_utf8_unchecked`], dy't itselde gedrach hat, mar de kontrôle oerspringt.
///
///
/// As jo in `String` nedich binne ynstee fan in `&str`, beskôgje dan [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Om't jo in `[u8; N]` kinne stack-allocearje, en jo kinne in [`&[u8]`][byteslice] derfan nimme, is dizze funksje ien manier om in string-allocearre string te hawwen.D'r is in foarbyld hjirfan yn 'e seksje hjirûnder.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Jout `Err` werom as it stik net UTF-8 is mei in beskriuwing wêrom't it oanbeane plak net UTF-8 is.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::str;
///
/// // guon bytes, yn in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wy witte dat dizze bytes jildich binne, dus brûk gewoan `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Ferkearde bytes:
///
/// ```
/// use std::str;
///
/// // wat ûnjildige bytes, yn in vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Sjoch de dokuminten foar [`Utf8Error`] foar mear details oer de soarten flaters dy't kinne wurde weromjûn.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // guon bytes, yn in stack-tawiisde array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Wy witte dat dizze bytes jildich binne, dus brûk gewoan `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: Rint gewoan falidaasje.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konverteart in feroarbere stikje bytes nei in feroarbere tekenrige.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" as in feroarbere vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Sa't wy witte dat dizze bytes jildich binne, kinne wy `unwrap()` brûke
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Ferkearde bytes:
///
/// ```
/// use std::str;
///
/// // Guon unjildige bytes yn in feroarbere vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Sjoch de dokuminten foar [`Utf8Error`] foar mear details oer de soarten flaters dy't kinne wurde weromjûn.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: Rint gewoan falidaasje.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konverteart in stikje bytes nei in tekenrige sûnder te kontrolearjen dat de tekenrige jildige UTF-8 befettet.
///
/// Sjoch de feilige ferzje, [`from_utf8`], foar mear ynformaasje.
///
/// # Safety
///
/// Dizze funksje is ûnfeilich, omdat it net kontroleart dat de bytes dy't dêrop binne oerdroegen binne jildich binne UTF-8.
/// As dizze beheining wurdt oertrêdde, resulteart undefined gedrach, om't de rest fan Rust der fan út giet dat [`&str`] s jildich binne UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::str;
///
/// // guon bytes, yn in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // VEILIGHEID: de beller moat garandearje dat de bytes `v` jildich binne UTF-8.
    // Ek fertrout derop dat `&str` en `&[u8]` deselde opmaak hawwe.
    unsafe { mem::transmute(v) }
}

/// Konverteart in stikje bytes nei in tekenrige sûnder te kontrolearjen dat de tekenrige jildige UTF-8 befettet;feroarbere ferzje.
///
///
/// Sjoch de ûnferoarlike ferzje, [`from_utf8_unchecked()`] foar mear ynformaasje.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // VEILIGHEID: de beller moat garandearje dat de bytes `v`
    // binne jildich UTF-8, dus is de cast nei `*mut str` feilich.
    // Ek de oanwizingsferwizing is feilich, om't dy oanwizer komt fan in referinsje dy't garandearre is jildich foar skriuwen.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}