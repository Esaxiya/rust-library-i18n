//! Trait ymplementaasjes foar `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementeart it bestellen fan snaren.
///
/// Strings wurde [lexicographically](Ord#lexicographical-comparison) oardere troch har bytewearden.
/// Dit bestelt Unicode-koadepunten basearre op har posysjes yn 'e koadediagrammen.
/// Dit is net needsaaklik itselde as "alphabetical"-oarder, dat ferskilt per taal en lokaal.
/// Strings sortearje neffens kultureel aksepteare noarmen fereasket lokale spesifike gegevens dy't bûten it berik fan it `str`-type binne.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementeart fergelikingsoperaasjes op snaren.
///
/// Strings wurde [lexicographically](Ord#lexicographical-comparison) fergelike troch har bytewearden.
/// Dit fergeliket Unicode-koadepunten basearre op har posysjes yn 'e koadediagrammen.
/// Dit is net needsaaklik itselde as "alphabetical"-oarder, dat ferskilt per taal en lokaal.
/// Ferlykjen fan snaren neffens kultureel aksepteare noarmen fereasket lokale spesifike gegevens dy't bûten it berik fan it `str`-type binne.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementeart substring snijden mei syntaksis `&self[..]` of `&mut self[..]`.
///
/// Jout in stik fan 'e heule tekenrige werom, dat wol sizze dat `&self` as `&mut self` weromkomt.Ekwivalint mei `&sels [0 ..
/// len] `of`&mut sels [0 ..
/// len]`.
/// Oars as oare yndeksearjende operaasjes kin dit nea panic.
///
/// Dizze operaasje is *O*(1).
///
/// Foarôfgeand oan 1.20.0 waarden dizze yndeksearjende operaasjes noch stipe troch direkte ymplemintaasje fan `Index` en `IndexMut`.
///
/// Ekwivalint mei `&self[0 .. len]` as `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementeart substring snijden mei syntaksis `&self[begin .. end]` of `&mut self[begin .. end]`.
///
/// Jout in stik fan 'e opjûne tekenrige út it byte-berik [`begjinne`, `end`).
///
/// Dizze operaasje is *O*(1).
///
/// Foarôfgeand oan 1.20.0 waarden dizze yndeksearjende operaasjes noch stipe troch direkte ymplemintaasje fan `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `begin` of `end` net wiist op de startbyte-offset fan in karakter (lykas definieare troch `is_char_boundary`), as `begin > end`, of as `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // dizze sille panic:
/// // byte 2 leit binnen `ö`:
/// // &s [2 ..3];
///
/// // byte 8 leit yn `老`&s [1 ..
/// // 8];
///
/// // byte 100 is bûten de tekenrige&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: krekt kontroleare dat `start` en `end` op in karregrins binne,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            // Wy hawwe ek char-grinzen kontroleare, dus dit is jildich UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: krekt kontroleare dat `start` en `end` op in karregrins binne.
            // Wy witte dat de oanwizer unyk is, om't wy dizze hawwe fan `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: de beller garandeart dat `self` yn grinzen is fan `slice`
        // dy't foldocht oan alle betingsten foar `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: sjoch opmerkingen foar `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontroleart dat de yndeks yn [0 is, .len()] kin `get` net opnij brûke lykas hjirboppe, fanwegen NLL-problemen
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: krekt kontroleare dat `start` en `end` op in karregrins binne,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementeart substring snijden mei syntaksis `&self[.. end]` of `&mut self[.. end]`.
///
/// Jout in stik fan 'e opjûne tekenrige út it byteberik [`0`, `end`).
/// Ekwivalint mei `&self[0 .. end]` as `&mut self[0 .. end]`.
///
/// Dizze operaasje is *O*(1).
///
/// Foarôfgeand oan 1.20.0 waarden dizze yndeksearjende operaasjes noch stipe troch direkte ymplemintaasje fan `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `end` net wiist op de startbyte-offset fan in karakter (lykas definieare troch `is_char_boundary`), of as `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: krekt kontroleare dat `end` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: krekt kontroleare dat `end` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: krekt kontroleare dat `end` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementeart substring snijden mei syntaksis `&self[begin ..]` of `&mut self[begin ..]`.
///
/// Jout in stik fan 'e opjûne tekenrige út it byte-berik [`begjinne`, `len`).Ekwivalint mei `&sels [begjinne ..
/// len] `of`&mut sels [begjinne ..
/// len]`.
///
/// Dizze operaasje is *O*(1).
///
/// Foarôfgeand oan 1.20.0 waarden dizze yndeksearjende operaasjes noch stipe troch direkte ymplemintaasje fan `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `begin` net wiist op de startbyte-offset fan in karakter (lykas definieare troch `is_char_boundary`), of as `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: krekt kontroleare dat `start` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: krekt kontroleare dat `start` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: de beller garandeart dat `self` yn grinzen is fan `slice`
        // dy't foldocht oan alle betingsten foar `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: identyk oan `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: krekt kontroleare dat `start` op in koargrins is,
            // en wy passe yn in feilige referinsje, dus sil de weromfertsjintiid ek ien wêze.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementeart substring snijden mei syntaksis `&self[begin ..= end]` of `&mut self[begin ..= end]`.
///
/// Jout in stik fan 'e opjûne tekenrige út it byteberik [`begin`, `end`].Ekwivalint mei `&self [begin .. end + 1]` of `&mut self[begin .. end + 1]`, útsein as `end` de maksimale wearde hat foar `usize`.
///
/// Dizze operaasje is *O*(1).
///
/// # Panics
///
/// Panics as `begin` net wiist op de startbyte-offset fan in karakter (lykas definieare troch `is_char_boundary`), as `end` net wiist op de ein-byte-offset fan in karakter (`end + 1` is of in start-byte-offset of gelyk oan `len`), as `begin > end`, of as `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `get_unchecked` hanthavenje.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `get_unchecked_mut` hanthavenje.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementeart substring snijden mei syntaksis `&self[..= end]` of `&mut self[..= end]`.
///
/// Jout in stik fan 'e opjûne tekenrige út it byteberik [0, `end`].
/// Ekwivalint mei `&self [0 .. end + 1]`, útsein as `end` de maksimale wearde hat foar `usize`.
///
/// Dizze operaasje is *O*(1).
///
/// # Panics
///
/// Panics as `end` net wiist op de ein byte offset fan in karakter (`end + 1` is of in begjin byte offset lykas definieare troch `is_char_boundary`, of gelyk oan `len`), of as `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `get_unchecked` hanthavenje.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `get_unchecked_mut` hanthavenje.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Untleed in wearde fan in tekenrige
///
/// De [`from_str`]-metoade fan `FromStr` wurdt faak ymplisyt brûkt, fia de [`parse`]-metoade fan [`str`].
/// Sjoch de dokumintaasje fan [`parse`] foar foarbylden.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` hat gjin libbensparameter, en dus kinne jo allinich typen analysearje dy't gjin libbensparameter sels befetsje.
///
/// Mei oare wurden, jo kinne in `i32` analysearje mei `FromStr`, mar gjin `&i32`.
/// Jo kinne in struktuer analysearje dy't in `i32` befettet, mar net ien dy't in `&i32` befettet.
///
/// # Examples
///
/// Basis ymplemintaasje fan `FromStr` op in foarbyld `Point` type:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// De byhearende flater dy't kin wurde weromjûn fan parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Untleest in tekenrige `s` om in wearde fan dit type werom te jaan.
    ///
    /// As parsing slagget, retourneer dan de wearde binnen [`Ok`], oars as de tekenrige net goed opmakke is, retourneer in flater spesifyk foar de binnenkant [`Err`].
    /// It flatertype is spesifyk foar ymplemintaasje fan 'e trait.
    ///
    /// # Examples
    ///
    /// Basis gebrûk mei [`i32`], in type dat `FromStr` ymplementeart:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Untleed in `bool` fan in tekenrige.
    ///
    /// Jout in `Result<bool, ParseBoolError>`, om't `s` wol of net parseerber is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Opmerking, yn in protte gefallen is de `.parse()`-metoade op `str` krekter.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}