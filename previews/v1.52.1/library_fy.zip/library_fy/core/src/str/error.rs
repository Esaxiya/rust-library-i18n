//! Definieart utf8 flater type.

use crate::fmt;

/// Flaters dy't kinne foarkomme as jo besykje in folchoarder fan [`u8`] as in teken te ynterpretearjen.
///
/// As sadanich makket de `from_utf8`-famylje fan funksjes en metoaden foar sawol [`String`] s as [`&str`] s gebrûk fan dizze flater, bygelyks.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// De metoaden fan dit flater type kinne brûkt wurde om funksjonaliteit te meitsjen lykas `String::from_utf8_lossy` sûnder heapgeheugen te allocearjen:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Jout de yndeks werom yn 'e opjûne tekenrige wêrfan jildige UTF-8 ferifieare is.
    ///
    /// It is de maksimale yndeks, sadat `from_utf8(&input[..index])` `Ok(_)` weromkomt.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::str;
    ///
    /// // wat ûnjildige bytes, yn in vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 retourneert in Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // de twadde byte is hjir ûnjildich
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Jout mear ynformaasje oer it falen:
    ///
    /// * `None`: it ein fan 'e ynput waard ûnferwachts berikt.
    ///   `self.valid_up_to()` is 1 oant 3 bytes fan 'e ein fan' e ynput.
    ///   As in byte stream (lykas in bestân as in netwurk socket) stadichoan dekodearre wurdt, kin dit in jildige `char` wêze wêrfan de UTF-8 byte folchoarder meardere brokken oerspant.
    ///
    ///
    /// * `Some(len)`: in ûnferwachte byte waard oantroffen.
    ///   De levere lingte is dy fan 'e ûnjildige byte folchoarder dy't begjint by de yndeks jûn troch `valid_up_to()`.
    ///   Decodearje moat nei dy folchoarder opnij (nei ynfoeging fan in [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) yn gefal fan ferlies dekodearjen.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// In flater werom as parsing fan in `bool` mei [`from_str`] mislearret
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}