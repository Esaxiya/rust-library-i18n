//! Definieart iterator fan `IntoIter` eigendom foar arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// In bywearde [array]-iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dit is de array wêr't wy iterearje oer.
    ///
    /// Eleminten mei yndeks `i` wêr't `alive.start <= i < alive.end` noch net binne levere en jildige arrayynfieringen binne.
    /// Eleminten mei yndeksen `i < alive.start` of `i >= alive.end` binne al oplevere en moatte net mear tagonklik wurde!Dy deade eleminten kinne sels yn in folslein uninitialisearre steat wêze!
    ///
    ///
    /// De invarianten binne dus:
    /// - `data[alive]` libbet (dus befettet jildige eleminten)
    /// - `data[..alive.start]` en `data[alive.end..]` binne dea (dws de eleminten waarden al lêzen en moatte net mear oanrekke wurde!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// De eleminten yn `data` dy't noch net binne levere.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Makket in nije iterator oan oer de opjûne `array`.
    ///
    /// *Opmerking*: dizze metoade kin wurde ferfallen yn 'e future, nei [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // It type `value` is hjir in `i32`, ynstee fan `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // VEILIGHEID: De transmute hjir is eins feilich.De dokuminten fan `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` wurdt garandearre deselde grutte en ôfstimming te hawwen
        // > as `T`.
        //
        // De dokuminten litte sels in transmute sjen fan in array fan `MaybeUninit<T>` nei in array fan `T`.
        //
        //
        // Dêrmei foldocht dizze inisjalisaasje oan de invarianten.

        // FIXME(LukasKalbertodt): brûk `mem::transmute` hjir eins, as it ienris wurket mei const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Oant dan kinne wy `mem::transmute_copy` brûke om in bitwize kopy te meitsjen as in oar type, ferjit dan `array` sadat it net falt.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Jout in ûnferoarlike stik fan alle eleminten dy't noch net binne levere.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // VEILIGHEID: Wy witte dat alle eleminten binnen `alive` goed binne inisjalisearre.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Jout in mutabele stik fan alle eleminten dy't noch net binne levere.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // VEILIGHEID: Wy witte dat alle eleminten binnen `alive` goed binne inisjalisearre.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Krij de folgjende yndeks fan 'e foarkant.
        //
        // `alive.start` ferheegje mei 1 behâldt de invariant oangeande `alive`.
        // Troch dizze feroaring is de libbenssône foar in koarte tiid lykwols net `data[alive]` mear, mar `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lês it elemint út 'e array.
            // VEILIGHEID: `idx` is in yndeks yn 'e eardere "alive"-regio fan' e
            // array.It lêzen fan dit elemint betsjut dat `data[idx]` no wurdt beskôge as dea (dus net oanreitsje).
            // Om't `idx` it begjin fan 'e libbenssône wie, is de libbenssône no wer `data[alive]`, en herstelt alle invarianten.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Krij de folgjende yndeks fan 'e efterkant.
        //
        // `alive.end` ferminderje mei 1 behâldt de invariant oangeande `alive`.
        // Troch dizze feroaring is de libbenssône foar in koarte tiid lykwols net `data[alive]` mear, mar `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lês it elemint út 'e array.
            // VEILIGHEID: `idx` is in yndeks yn 'e eardere "alive"-regio fan' e
            // array.It lêzen fan dit elemint betsjut dat `data[idx]` no wurdt beskôge as dea (dus net oanreitsje).
            // Om't `idx` it ein fan 'e libbenssône wie, is de libbenssône no wer `data[alive]`, en herstelt alle invarianten.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is feilich: `as_mut_slice` retourneert krekt de sub-slice
        // fan eleminten dy't noch net binne ferpleatst en dy't falle moatte.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Sil nea ûnderstreamje troch de invariant `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// De iterator rapporteart yndie de juste lingte.
// It oantal "alive"-eleminten (dat sil noch wurde levere) is de lingte fan it berik `alive`.
// Dit berik wurdt yn 'e lingte yn `next` as `next_back` ôfnommen.
// It wurdt altyd ôfnommen troch 1 yn dy metoaden, mar allinich as `Some(_)` wurdt weromjûn.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Opmerking, wy hoege net krekt itselde libbensbereik te passen, dus kinne wy gewoan klone yn offset 0, ûnôfhinklik fan wêr't `self` is.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klon alle libbene eleminten.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skriuw in kloon yn 'e nije array, en update it libbene berik.
            // As jo panics klonearje, sille wy de foarige items korrekt falle.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Druk allinich de eleminten ôf dy't noch net waarden levere: wy kinne gjin tagong krije ta de levere eleminten mear.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}