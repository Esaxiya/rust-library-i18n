//! Konstanten foar it oanwizen fan heulgetaaltype mei pointergrutte.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Nije koade moat de assosjeare konstanten direkt brûke op it primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }