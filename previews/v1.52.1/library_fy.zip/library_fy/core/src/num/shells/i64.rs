//! Konstanten foar it 64-bit ûndertekene heule getalstype.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Nije koade moat de assosjeare konstanten direkt brûke op it primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }