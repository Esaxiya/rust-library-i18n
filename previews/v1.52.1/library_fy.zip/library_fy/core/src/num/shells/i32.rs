//! Konstanten foar it 32-bit ûndertekene heule getalstype.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Nije koade moat de assosjeare konstanten direkt brûke op it primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }