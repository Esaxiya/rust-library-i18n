//! Konstanten foar it 8-bit net-ûndertekene heulgetaaltype.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Nije koade moat de assosjeare konstanten direkt brûke op it primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }