//! Konstanten foar it 16-bit net-ûndertekene heule getalstype.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Nije koade moat de assosjeare konstanten direkt brûke op it primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }