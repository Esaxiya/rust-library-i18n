//! Hast direkte (mar in bytsje optimalisearre) Rust-oersetting fan figuer 3 fan "Driuwende puntnummers fluch en akkuraat" [^ 1].
//!
//!
//! [^1]: Burger, RG en Dybvig, RK 1996. Ofdrukken fan driuwende-nûmers
//!   fluch en krekt.SIGPLAN Net.31, 5 (maaie. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// foarút berekkene arrays fan `Digit`s foar 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// allinich brûkber as `x < 16 * scale`;`scaleN` moat `scale.mul_small(N)` wêze
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// De koartste modus ymplemintaasje foar Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // it nûmer `v` om op te meitsjen is bekend te wêzen:
    // - gelyk oan `mant * 2^exp`;
    // - foarôfgien troch `(mant - 2 *minus)* 2^exp` yn it orizjinele type;en
    // - folge troch `(mant + 2 *plus)* 2^exp` yn it orizjinele type.
    //
    // fansels, `minus` en `plus` kinne net nul wêze.(foar ûneinichheden brûke wy wearden bûten it berik.) wy geane der ek fan út dat op syn minst ien sifer wurdt generearre, dat `mant` ek net nul kin wêze.
    //
    // dit betsjut ek dat elk getal tusken `low = (mant - minus)*2^exp` en `high = (mant + plus)* 2^exp` yn kaart bringt nei dit krekte driuwende puntnûmer, mei grinzen opnommen doe't de orizjinele mantissa gelyk wie (ie `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` is `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // skatte `k_0` fan orizjinele yngongen dy't foldogge oan `10^(k_0-1) < high <= 10^(k_0+1)`.
    // de strakke bound `k` foldwaan `10^(k-1) < high <= 10^k` wurdt letter berekkene.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` konvertearje yn 'e fraksjonele foarm sadat:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // diel `mant` troch `10^k`.no `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup as `mant + plus > scale` (as `>=`).
    // wy wizigje `scale` eins net, om't wy de earste multiplikaasje yn plak kinne oerslaan.
    // no `scale < mant + plus <= scale * 10` en wy binne ree om sifers te generearjen.
    //
    // betinke dat `d[0]`*nul kin* wêze, as `scale - plus < mant < scale`.
    // yn dit gefal wurdt rûne betingst (`up` hjirûnder) direkt aktivearre.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ekwivalint as `scale` mei 10 skalearje
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` foar generearjen fan sifers.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, wêr't `d[0..n-1]` oant no ta sifers binne generearre:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (dus `mant / scale < 10`) wêrby `d[i..j]` in ôfkoarting is foar `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // generearje ien sifer: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // dit is in ferienfâldige beskriuwing fan it oanpaste Dragon-algoritme.
        // in protte tuskentrochliedings en folsleinensarguminten wurde wegere foar gemak.
        //
        // begjinne mei oanpaste invarianten, lykas wy `n` hawwe bywurke:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // gean der fan út dat `d[0..n-1]` de koartste foarstelling is tusken `low` en `high`, dat wol sizze, `d[0..n-1]` foldocht oan beide folgjende, mar `d[0..n-2]` net:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: sifers rûn oant `v`);en
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (it lêste sifer is korrekt).
        //
        // de twadde betingst ferienfâldiget nei `2 * mant <= scale`.
        // it oplossen fan invarianten yn termen fan `mant`, `low` en `high` leveret in ienfâldiger ferzje fan 'e earste betingst: `-plus < mant < minus`.
        // sûnt `-plus < 0 <= mant`, wy hawwe de juste koartste foarstelling as `mant < minus` en `2 * mant <= scale`.
        // (de earste wurdt `mant <= minus` as de orizjinele mantissa gelyk is.)
        //
        // as de twadde net hâldt (`2 * mant> skaal`), moatte wy it lêste sifer ferheegje.
        // dit is genôch foar it herstellen fan dy tastân: wy wite al dat de sifersgeneraasje `0 <= v / 10^(k-n) - d[0..n-1] < 1` garandeart.
        // yn dit gefal wurdt de earste betingst `-plus < mant - scale < minus`.
        // sûnt `mant < scale` nei de generaasje, wy hawwe `scale < mant + plus`.
        // (wer wurdt dit `scale <= mant + plus` as de orizjinele mantissa gelyk is.)
        //
        // Koartsein:
        // - stopje en rûn `down` (hâld sifers sa't it is) as `mant < minus` (of `<=`).
        // - stopje en rûn `up` (ferheegje it lêste sifer) as `scale < mant + plus` (as `<=`).
        // - bliuw oars generearje.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // wy hawwe de koartste fertsjintwurdiging, gean troch nei de rûning

        // weromsette de invarianten.
        // dit makket dat it algoritme altyd einiget: `minus` en `plus` nimt altyd ta, mar `mant` wurdt knipt modulo `scale` en `scale` is fêst.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // omheechgean bart as i) allinich de afrondingsbetingst waard aktivearre, of ii) beide betingsten waarden aktivearre en tie-break foarkar rûn omheech.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // as ôfrûning de lingte feroaret, moat de eksponint ek feroarje.
        // it liket derop dat dizze betingst heul dreech is te befredigjen (mooglik ûnmooglik), mar wy binne hjir gewoan feilich en konsistint.
        //
        // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// De krekte en fêste modus ymplemintaasje foar Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // skatte `k_0` fan orizjinele yngongen dy't foldogge oan `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // diel `mant` troch `10^k`.no `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup doe't `mant + plus >= scale`, wêr `plus / scale = 10^-buf.len() / 2`.
    // om de fêste grutte bignum te hâlden, brûke wy eins `mant + floor(plus) >= scale`.
    // wy wizigje `scale` eins net, om't wy de earste multiplikaasje yn plak kinne oerslaan.
    // wer mei it koartste algoritme kin `d[0]` nul wêze, mar sil úteinlik omheech wurde.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ekwivalint as `scale` mei 10 skalearje
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // as wy wurkje mei de beheining fan 'e lêste sifers, moatte wy de buffer koarterje foar de eigentlike rendering om dûbele rûning te foarkommen.
    //
    // tink derom dat wy de buffer wer moatte fergrutsje as ôfrûnjen bart!
    let mut len = if k < limit {
        // oeps, wy kinne net iens *ien* sifer produsearje.
        // dit is mooglik as wy, sis mar, hawwe wat as 9.5 en it wurdt ôfrûn nei 10.
        // wy jouwe in lege buffer werom, mei in útsûndering fan 'e lettere ôfrûne saak dy't foarkomt as `k == limit` en krekt ien sifer produsearje moat.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` foar generearjen fan sifers.
        // (dit kin djoer wêze, dus berekkenje se net as de buffer leech is.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // folgjende sifers binne allegear nullen, wy stopje hjir besykje *net* afrûning út te fieren!leaver, folje oerbleaune sifers.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // omheechrinne as wy midden yn sifers stopje as de folgjende sifers presys 5000 binne ..., kontrolearje it foarige sifer en besykje om gelyk te rûnen (dat is, foarkomme dat it omheech rint as it foarige sifer gelyk is).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // VEILIGHEID: `buf[len-1]` is inisjalisearre.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // as ôfrûning de lingte feroaret, moat de eksponint ek feroarje.
        // mar wy binne in fêste oantal sifers frege, feroarje de buffer dus net ...
        // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... behalve as wy ynstee fan de fêste presyzje binne frege.
            // wy moatte ek kontrolearje dat, as de orizjinele buffer leech wie, it ekstra sifer allinich kin wurde tafoege as `k == limit` (saak edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}