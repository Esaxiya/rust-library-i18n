//! Dekodeart in driuwende-punt wearde yn yndividuele dielen en flaterberik.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Decodearre ûnûndertekene einige wearde, sadanich dat:
///
/// - De orizjinele wearde is gelyk oan `mant * 2^exp`.
///
/// - Elk getal fan `(mant - minus)*2^exp` oant `(mant + plus)* 2^exp` sil rûn wurde nei de orizjinele wearde.
/// It berik is allinich ynklusyf as `inclusive` `true` is.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// De skalearde mantissa.
    pub mant: u64,
    /// It legere flaterberik.
    pub minus: u64,
    /// It boppeste flaterberik.
    pub plus: u64,
    /// De dielde eksponint yn basis 2.
    pub exp: i16,
    /// Wier as it flaterberik ynklusyf is.
    ///
    /// Yn IEEE 754 is dit wier as de orizjinele mantissa sels wie.
    pub inclusive: bool,
}

/// Unkodde wearde ûntsifere.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infiniteiten, posityf as negatyf.
    Infinite,
    /// Nul, posityf as negatyf.
    Zero,
    /// Einige getallen mei fierdere dekodearre fjilden.
    Finite(Decoded),
}

/// In driuwend puntstype dat kin wurde 'dekodearje`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// De minimale positive normalisearre wearde.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Jout in teken (wier as negatyf) en `FullDecoded`-wearde fan it opjûne driuwende komma-nûmer.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // buorlju: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode behâldt altyd de eksponint, sadat de mantissa wurdt skaleare foar subnormalen.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // buorlju: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // wêr maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // buorlju: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}