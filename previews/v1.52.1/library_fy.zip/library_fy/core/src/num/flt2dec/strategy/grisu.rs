//! Rust-oanpassing fan it Grisu3-algoritme beskreaun yn "Driuwende-puntnûmers fluch en akkuraat mei heelgetallen printsje" [^ 1].
//! It brûkt sawat 1KB fan foarôf komputeare tafel, en op syn beurt is it heul rap foar de measte yngongen.
//!
//! [^1]: Florian Loitsch.2010. Printsjen fan driuwende komma-getallen fluch en
//!   sekuer mei hiel getallen.SIGPLAN Net.45, 6 (juny 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// sjoch de opmerkingen yn `format_shortest_opt` foar de reden.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Jûn `x > 0`, retourneert `(k, 10^k)` sa dat `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// De koartste modus ymplemintaasje foar Grisu.
///
/// It retourneert `None` as it oars in ûnkrekte fertsjintwurdiging soe werombringe.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // wy hawwe teminsten trije bits ekstra presys nedich

    // begjinne mei de normalisearre wearden mei de dielde eksponint
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // fine alle `cached = 10^minusk` sa dat `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // om't `plus` normalisearre is, betsjut dit `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // jûn ús karren fan `ALPHA` en `GAMMA`, set dit `plus * cached` yn `[4, 2^32)`.
    //
    // it is fansels winsklik om `GAMMA - ALPHA` te maksimalisearjen, sadat wy net in soad cache-foegen fan 10 nedich binne, mar d'r binne wat oerwagings:
    //
    //
    // 1. wy wolle `floor(plus * cached)` binnen `u32` hâlde, om't it in djoere ferdieling nedich is.
    //    (dit is net echt te foarkommen, rest is nedich foar skatting fan krektens.)
    // 2.
    // de rest fan `floor(plus * cached)` wurdt herhaaldlik fermannichfâldige mei 10, en it moat net oerstreamje.
    //
    // de earste jout `64 + GAMMA <= 32`, wylst de twadde `10 * 2^-ALPHA <= 2^64` jout;
    // -60 en -32 is it maksimale berik mei dizze beheining, en V8 brûkt se ek.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skaal fps.dit jout de maksimale flater fan 1 ulp (bewiisd út Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-wirklik berik fan minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // boppe `minus`, `v` en `plus` binne *kwantifisearre* benaderingen (flater <1 ulp).
    // om't wy net witte dat de flater posityf as negatyf is, brûke wy twa approximaasjes dy't lyk op inoar binne en hawwe de maksimale flater fan 2 ulps.
    //
    // de "unsafe region" is in liberaal ynterval dat wy earst generearje.
    // de "safe region" is in konservatyf ynterval dat wy allinich akseptearje.
    // wy begjinne mei de juste repr binnen de ûnfeilige regio, en besykje de tichtste repr te finen nei `v` dy't ek binnen de feilige regio is.
    // as wy net kinne, jouwe wy op.
    //
    let plus1 = plus.f + 1;
    // lit plus0 = plus.f, 1;//allinich foar útlis lit minus0 = minus.f + 1;//allinich foar útlis
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // dielde eksponint

    // diel `plus1` yn yntegraal en fraksjonele dielen.
    // yntegraal dielen wurde garandearre dat se passe yn u32, om't cache krêft garandeart `plus < 2^32` en normalisearre `plus.f` is altyd minder dan `2^64 - 2^4` fanwege de presyseask.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // berekkenje de grutste `10^max_kappa` net mear dan `plus1` (dus `plus1 < 10^(max_kappa+1)`).
    // dit is in boppegrins fan `kappa` hjirûnder.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Stelling 6.2: as `k` it grutste gehiel is fan st
    // `0 <= y mod 10^k <= y - x`,              dan is `V = floor(y / 10^k) * 10^k` yn `[x, y]` en ien fan 'e koartste foarstellings (mei it minimale oantal wichtige sifers) yn dat berik.
    //
    //
    // fyn de lingte fan sifers `kappa` tusken `(minus1, plus1)` neffens Stelling 6.2.
    // Stelling 6.2 kin wurde oannaam om `x` út te sluten troch `y mod 10^k < y - x` ynstee te fereaskjen.
    // (bgl. `x` =32000, `y` =32777; `kappa` =2 sûnt `y mod 10 ^ 3=777 <y, x=777`.) fertrout it algoritme op 'e lettere ferifikaasjefase om `y` út te sluten.
    //
    let delta1 = plus1 - minus1;
    // lit delta1int=(delta1>> e) as usize;//allinich foar útlis
    let delta1frac = delta1 & ((1 << e) - 1);

    // yntegraal dielen werjaan, wylst jo kontrolearje op 'e krektens by elke stap.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // noch te werjaan sifers
    loop {
        // wy hawwe altyd op syn minst ien sifer te werjaan, as `plus1 >= 10^kappa`-invarianten:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (it folget dat `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // diel `remainder` troch `10^kappa`.beide wurde skaal makke troch `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; wy hawwe de juste `kappa` fûn.
            let ten_kappa = (ten_kappa as u64) << e; // skaal 10 ^ kappa werom nei de dielde eksponint
            return round_and_weed(
                // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // brek de loop as wy alle yntegraal sifers hawwe werjûn.
        // it krekte oantal sifers is `max_kappa + 1` as `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invarianten herstelle
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // fraksjonele dielen werjaan, wylst jo kontrolearje op 'e krektens by elke stap.
    // dizze kear fertrouwe wy op werhelle fermannichfâldigjen, om't divyzje de presyzje sil ferlieze.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // it folgjende sifer soe wichtich wêze moatte, om't wy dat hawwe hifke foardat wy invarianten útbrekke, wêr't `m = max_kappa + 1` (#sifers yn it yntegraal diel):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // sil net oerrinne, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // diel `remainder` troch `10^kappa`.
        // beide wurde skaleare troch `2^e / 10^kappa`, dus dat lêste is hjir ymplisyt.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ymplisite skieding
            return round_and_weed(
                // VEILIGHEID: wy hawwe dat ûnthâld hjirboppe inisjalisearre.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // invarianten herstelle
        kappa -= 1;
        remainder = r;
    }

    // wy hawwe alle wichtige sifers fan `plus1` generearre, mar net wis oft it de optimale is.
    // bygelyks as `minus1` 3.14153 is ... en `plus1` 3.14158 is ..., binne d'r 5 ferskate koartste fertsjintwurdiging fan 3.14154 nei 3.14158, mar wy hawwe allinich de grutste.
    // wy moatte it lêste sifer efterinoar ferminderje en kontrolearje oft dit de optimale repr is.
    // d'r binne op syn heechst 9 kandidaten (..1 oant ..9), dus dit is frij fluch.("rounding"-faze)
    //
    // de funksje kontroleart as dizze "optimal"-repr eins binnen de ulp-berik is, en it is ek mooglik dat de "second-to-optimal"-repr eins optimaal kin wêze fanwege de rûningsflater.
    // yn beide gefallen jout dit `None` werom.
    // ("weeding"-faze)
    //
    // alle arguminten wurde hjir skaalfergrutte troch de mienskiplike (mar ymplisite) wearde `k`, sadat:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (en ek, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (en ek, `threshold > plus1v` fan eardere invarianten)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produsearje twa approximations nei `v` (eins `plus1 - v`) binnen 1.5 ulps.
        // de resultearjende fertsjintwurdiging moat de tichtste fertsjintwurdiging wêze foar beide.
        //
        // hjir wurdt `plus1 - v` brûkt sûnt berekkeningen wurde dien mei respekt foar `plus1` om overflow/underflow te foarkommen (fandêr de skynber ynruile nammen).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // ferminderje it lêste sifer en stopje by de tichtst represintaasje by `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // wy wurkje mei de skatte sifers `w(n)`, dy't yn earste ynstânsje gelyk is oan `plus1 - plus1 % 10^kappa`.nei it rinnen fan it looplichaam `n` kear, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // wy sette `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (dus `rest= plus1w(0)`) om kontrôles te ferienfâldigjen.
            // derom dat `plus1w(n)` altyd tanimt.
            //
            // wy hawwe trije betingsten om te beëinigjen.ien fan har sil de loop net kinne trochgean, mar wy hawwe dan teminsten ien jildige fertsjintwurdiging wêrfan bekend is dat it dochs it tichtst by `v + 1 ulp` is.
            // wy sille se oantsjutte as TC1 fia TC3 foar koarte.
            //
            // TC1: `w(n) <= v + 1 ulp`, dat is dit de lêste repr dy't it tichtst kin wêze.
            // dit is lykweardich oan `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombineare mei TC2 (dy't kontroleart as `w(n+1)` is valid), dit foarkomt de mooglike oerstreaming op 'e berekkening fan `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dus de folgjende repr rint perfoarst net ôf nei `v`.
            // dit is lykweardich oan `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // de linker kant kin oerstreamje, mar wy witte `threshold > plus1v`, dus as TC1 falsk is, kinne `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` en wy kinne feilich testen as `threshold - plus1w(n) < 10^kappa` ynstee.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dus de folgjende repr is
            // net tichter by `v + 1 ulp` dan de hjoeddeiske repr.
            // jûn `z(n) = plus1v_up - plus1w(n)`, wurdt dit `abs(z(n)) <= abs(z(n+1))`.wer fanút dat TC1 falsk is, hawwe wy `z(n) > 0`.wy hawwe twa gefallen om te beskôgjen:
            //
            // - doe't `z(n+1) >= 0`: TC3 wurdt `z(n) <= z(n+1)`.
            // as `plus1w(n)` tanimt, moat `z(n)` ôfnimme en dit is dúdlik falsk.
            // - wannear `z(n+1) < 0`:
            //   - TC3a: de betingst is `plus1v_up < plus1w(n) + 10^kappa`.der fan út dat TC2 falsk is, `threshold >= plus1w(n) + 10^kappa` sadat it net oerstreamje kin.
            //   - TC3b: TC3 wurdt `z(n) <= -z(n+1)`, ie, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   de negearre TC1 jout `plus1v_up > plus1w(n)`, dat it kin net oerrin of ûnderstreamje as kombineare mei TC3a.
            //
            // dêrom moatte wy stopje as `TC1 || TC2 || (TC3a && TC3b)`.it folgjende is gelyk oan it omkearde, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // de koartste repr kin net einigje mei `0`
                plus1w += ten_kappa;
            }
        }

        // kontrolearje oft dizze fertsjintwurdiging ek de tichtste fertsjintwurdiging is fan `v - 1 ulp`.
        //
        // dit is gewoan itselde as de terminerende betingsten foar `v + 1 ulp`, mei alle `plus1v_up` ynstee ferfongen troch `plus1v_down`.
        // oerstreamingsanalyse hâldt likegoed.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // no hawwe wy de tichtste fertsjintwurdiging fan `v` tusken `plus1` en `minus1`.
        // dit is te liberaal, hoewol, dus wy fersmite elke `w(n)`, net tusken `plus0` en `minus0`, dus `plus1 - plus1w(n) <= minus0` of `plus1 - plus1w(n) >= plus0`.
        // wy brûke de feiten dy't `threshold = plus1 - minus1` en `plus1 - plus0 = minus0 - minus1 = 2 ulp` binne.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// De koartste modus ymplemintaasje foar Grisu mei Dragon fallback.
///
/// Dit moat foar de measte gefallen brûkt wurde.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // VEILIGHEID: De lienkontrole is net tûk genôch om ús `buf` brûke te litten
    // yn 'e twadde branch, sadat wy it libben hjir waskje.
    // Mar wy brûke `buf` allinich opnij as `format_shortest_opt` `None` weromkaam, dat dit is goed.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// De krekte en fêste modus ymplemintaasje foar Grisu.
///
/// It retourneert `None` as it oars in ûnkrekte fertsjintwurdiging soe werombringe.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // wy hawwe teminsten trije bits ekstra presys nedich
    assert!(!buf.is_empty());

    // normalisearje en skaal `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // diel `v` yn yntegraal en fraksjonele dielen.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // sawol âlde `v` as nije `v` (skaleare troch `10^-k`) hat in flater fan <1 ulp (Stelling 5.1).
    // om't wy net witte dat de flater posityf as negatyf is, brûke wy twa approximaasjes dy't lyk op inoar binne en hawwe de maksimale flater fan 2 ulps (itselde as it koartste gefal).
    //
    //
    // it doel is om de krekt ôfrûne searje sifers te finen dy't mienskiplik binne foar sawol `v - 1 ulp` as `v + 1 ulp`, sadat wy maksimaal fertrouwen hawwe.
    // as dit net mooglik is, wite wy net hokker de juste útfier is foar `v`, dat wy jouwe op en falle werom.
    //
    // `err` wurdt hjir definieare as `1 ulp * 2^e` (itselde as de ulp yn `vfrac`), en wy sille it skaalje as `v` skaal wurdt.
    //
    //
    //
    let mut err = 1;

    // berekkenje de grutste `10^max_kappa` net mear dan `v` (dus `v < 10^(max_kappa+1)`).
    // dit is in boppegrins fan `kappa` hjirûnder.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // as wy wurkje mei de beheining fan 'e lêste sifers, moatte wy de buffer koarterje foar de eigentlike rendering om dûbele rûning te foarkommen.
    //
    // tink derom dat wy de buffer wer moatte fergrutsje as ôfrûnjen bart!
    let len = if exp <= limit {
        // oeps, wy kinne net iens *ien* sifer produsearje.
        // dit is mooglik as wy, sis mar, hawwe wat as 9.5 en it wurdt ôfrûn nei 10.
        //
        // yn prinsipe kinne wy `possibly_round` fuortendaliks skilje mei in lege buffer, mar skaalfergrutting `max_ten_kappa << e` mei 10 kin resultearje yn oerrin.
        //
        // sadwaande binne wy hjir sljocht en ferheegje wy it flaterberik mei in faktor fan 10.
        // dit sil de falske negative taryf ferheegje, mar allinich heul,*heul* wat;
        // it kin allinich merkber saakje as de mantissa grutter is dan 60 bits.
        //
        // VEILIGHEID: `len=0`, dus de ferplichting om dit ûnthâld te initialisearjen is triviaal.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // yntegraal dielen werjaan.
    // de flater is folslein fraksje, dat wy hoege it net yn dit diel te kontrolearjen.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // noch te werjaan sifers
    loop {
        // wy hawwe altyd op syn minst ien sifer om invarianten wer te jaan:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (it folget dat `remainder = vint % 10^(kappa+1)`)
        //
        //

        // diel `remainder` troch `10^kappa`.beide wurde skaal makke troch `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // is de buffer fol?rint de rûnpas mei de rest.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // VEILIGHEID: wy hawwe `len` in protte bytes inisjalisearre.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // brek de loop as wy alle yntegraal sifers hawwe werjûn.
        // it krekte oantal sifers is `max_kappa + 1` as `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invarianten herstelle
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // fraksjonele dielen werjaan.
    //
    // yn prinsipe kinne wy trochgean nei it lêste beskikbere sifer en kontrolearje op 'e krektens.
    // spitigernôch wurkje wy mei de heule getallen fan einige grutte, dus wy hawwe wat kritearium nedich om de oerstreaming te detektearjen.
    // V8 brûkt `remainder > err`, dat falsk wurdt as de earste `i` signifikante sifers fan `v - 1 ulp` en `v` ferskille.
    // dit fersmyt lykwols tefolle oars jildige ynput.
    //
    // om't de lettere faze in krekte oerstreamdeteksje hat, brûke wy ynstee strakkere kritearium:
    // wy geane troch oant `err` `10^kappa / 2` grutter is, sadat it berik tusken `v - 1 ulp` en `v + 1 ulp` definityf twa of mear ôfrûne foarstellingen befettet.
    //
    // dit is itselde mei de earste twa fergelikingen fan `possibly_round`, foar de referinsje.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, wêrby `m = max_kappa + 1` (#sifers yn it yntegraal diel):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // sil net oerrinne, `2^e * 10 < 2^64`
        err *= 10; // sil net oerrinne, `err * 10 < 2^e * 5 < 2^64`

        // diel `remainder` troch `10^kappa`.
        // beide wurde skaleare troch `2^e / 10^kappa`, dus dat lêste is hjir ymplisyt.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // is de buffer fol?rint de rûnpas mei de rest.
        if i == len {
            // VEILIGHEID: wy hawwe `len` in protte bytes inisjalisearre.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // invarianten herstelle
        remainder = r;
    }

    // fierdere berekkening is nutteloos (`possibly_round` mislearret definityf), dat wy jouwe op.
    return None;

    // wy hawwe alle frege sifers fan `v` generearre, dy't ek itselde moatte wêze foar oerienkommende sifers fan `v - 1 ulp`.
    // no kontrolearje wy as d'r in unike fertsjintwurdiging is dield troch sawol `v - 1 ulp` as `v + 1 ulp`;dit kin itselde wêze foar generearre sifers, as foar de ôfrûne ferzje fan dy sifers.
    //
    // as it berik meardere foarstellings fan deselde lingte befettet, kinne wy net wis wêze en moatte wy `None` yn plak weromjaan.
    //
    // alle arguminten wurde hjir skaalfergrutte troch de mienskiplike (mar ymplisite) wearde `k`, sadat:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // VEILIGHEID: de earste `len`-bytes fan `buf` moatte inisjalisearre wurde.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (foar de referinsje jout de stippelline de krekte wearde oan foar mooglike foarstellings yn opjûn oantal sifers.)
        //
        //
        // flater is te grut dat d'r teminsten trije mooglike foarstellingen binne tusken `v - 1 ulp` en `v + 1 ulp`.
        // wy kinne net bepale hokker korrekt is.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // eins is 1/2 ulp genôch om twa mooglike foarstellings yn te fieren.
        // (tink derom dat wy in unike foarstelling nedich binne foar sawol `v - 1 ulp` as 'v + 1 ulp'.) Dit sil net oerstreamje, as `ulp < ten_kappa` fan 'e earste kontrôle.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // as `v + 1 ulp` tichterby de ôfrûne fertsjintwurdiging is (dy't al yn `buf` is), dan kinne wy feilich weromkomme.
        // betinke dat `v - 1 ulp` * minder kin wêze dan de hjoeddeistige fertsjintwurdiging, mar as `1 ulp < 10^kappa / 2` is dizze betingst genôch:
        // de ôfstân tusken `v - 1 ulp` en de hjoeddeistige fertsjintwurdiging kin `10^kappa / 2` net grutter wêze.
        //
        // de tastân is gelyk oan `remainder + ulp < 10^kappa / 2`.
        // sûnt dit kin maklik oerspielje, kontrolearje earst as `remainder < 10^kappa / 2`.
        // wy hawwe al ferifieare dat `ulp < 10^kappa / 2`, salang't `10^kappa` ommers net oerstreamde, is de twadde kontrôle prima.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // VEILIGHEID: ús beller hat dat ûnthâld inisjalisearre.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------rest------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // oan 'e oare hannen, as `v - 1 ulp` tichterby de ôfrûne fertsjintwurdiging is, moatte wy omheech en weromkomme.
        // om deselde reden hoege wy `v + 1 ulp` net te kontrolearjen.
        //
        // de tastân is gelyk oan `remainder - ulp >= 10^kappa / 2`.
        // wer kontrolearje wy earst as `remainder > ulp` (betinke dat dit net `remainder >= ulp` is, om't `10^kappa` noait nul is).
        //
        // betinke ek dat `remainder - ulp <= 10^kappa`, sadat de twadde kontrôle net oerrint.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // VEILIGHEID: ús beller moat dat ûnthâld hawwe inisjalisearre.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // foegje allinich in ekstra sifer ta as wy de fêste presyzje binne frege.
                // wy moatte ek kontrolearje dat, as de orizjinele buffer leech wie, it ekstra sifer allinich kin wurde tafoege as `exp == limit` (saak edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // VEILIGHEID: wy en ús beller hawwe dat ûnthâld inisjalisearre.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // oars binne wy feroardiele (dat wol sizze, guon wearden tusken `v - 1 ulp` en `v + 1 ulp` rûnen omleech en oaren rûnen omheech) en jouwe op.
        //
        None
    }
}

/// De krekte en fêste modus ymplemintaasje foar Grisu mei Dragon fallback.
///
/// Dit moat foar de measte gefallen brûkt wurde.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // VEILIGHEID: De lienkontrole is net tûk genôch om ús `buf` brûke te litten
    // yn 'e twadde branch, sadat wy it libben hjir waskje.
    // Mar wy brûke `buf` allinich opnij as `format_exact_opt` `None` weromkaam, dat dit is goed.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}