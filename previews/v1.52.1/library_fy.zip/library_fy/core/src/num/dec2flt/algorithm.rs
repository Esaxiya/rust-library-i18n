//! De ferskate algoritmen út it papier.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Oantal betsjuttingsbiten yn Fp
const P: u32 = 64;

// Wy bewarje gewoan de bêste approximaasje foar *alle* eksponinten, sadat de fariabele "h" en de byhearrende betingsten kinne wurde weilitten.
// Dit hannelet prestaasjes foar in pear kilobyte romte.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Yn 'e measte arsjitektuer hawwe driuwende punten operaasjes in eksplisite bitgrutte, dêrom wurdt de presyzje fan' e berekkening bepaald per basis.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Op x86 wurdt de x87 FPU brûkt foar floatoperaasjes as de SSE/SSE2-útwreidings net beskikber binne.
// De x87 FPU wurket standert mei 80 bits presyzje, wat betsjuttet dat operaasjes sille rûn wurde nei 80 bits wêrtroch't dûbele afronding bart as wearden úteinlik wurde fertsjintwurdige as
//
// 32/64 bit float wearden.Om dit te oerwinnen kin it FPU-bestjoerswurd sa wurde ynsteld dat de berekkeningen wurde útfierd yn 'e winske presyzje.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// In struktuer dy't wurdt brûkt om de orizjinele wearde fan it FPU-bestjoeringswurd te behâlden, sadat it kin wurde wersteld as de struktuer falt.
    ///
    ///
    /// De x87 FPU is in 16-bits register wêrfan de fjilden sa binne:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// De dokumintaasje foar alle fjilden is te krijen yn 'e IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// It ienige fjild dat relevant is foar de folgjende koade is PC, Precision Control.
    /// Dit fjild bepaalt de presysiteit fan 'e operaasjes útfierd troch de FPU.
    /// It kin ynsteld wurde op:
    ///  - 0b00, inkele presyzje ie, 32-bits
    ///  - 0b10, dûbele presyzje ie, 64-bits
    ///  - 0b11, dûbele útwreide presyzje, ie 80-bits (standertstatus) De wearde 0b01 is reservearre en moat net brûkt wurde.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // VEILIGHEID: de `fldcw`-ynstruksje is kontroleare om korrekt mei te wurkjen
        // eltse `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Wy brûke ATT-syntaksis om LLVM 8 en LLVM 9 te stypjen.
                options(att_syntax, nostack),
            )
        }
    }

    /// Stelt it presysjefjild fan 'e FPU yn op `T` en retourneert in `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Berekkenje de wearde foar it fjild Precision Control dat passend is foar `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // standert, 80 bits
        };

        // Krij de orizjinele wearde fan it bestjoerswurd om it letter te herstellen, as de `FPUControlWord`-struktuer wurdt ferdwûn VEILIGHEID: de `fnstcw`-ynstruksje is kontroleare om korrekt te wurkjen mei elke `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Wy brûke ATT-syntaksis om LLVM 8 en LLVM 9 te stypjen.
                options(att_syntax, nostack),
            )
        }

        // Stel it kontrolewurd yn op de winske presyzje.
        // Dit wurdt berikt troch de âlde presyzje (bits 8 en 9, 0x300) te maskearjen en te ferfangen troch de hjirboppe berekkene presysjeflagge.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// It snelle paad fan Bellerophon mei heule getallen en driuwers yn masjengrutte.
///
/// Dit wurdt ekstraheard yn in aparte funksje, sadat it kin wurde besocht foardat in bignum wurdt boud.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Wy fergelykje de krekte wearde mei MAX_SIG oan 'e ein, dit is gewoan in rappe, goedkeap ôfwizing (en befrijt de rest fan' e koade ek soargen oer ûnderstream).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // It rappe paad is krúsjaal ôfhinklik fan rekkenjen dat wurdt ôfrûn oant it juste oantal bits sûnder tuskenôfrûning.
    // Op x86 (sûnder SSE of SSE2) fereasket dit dat de presyzje fan 'e x87 FPU-stapel feroare wurdt sadat it direkt rint nei 64/32-bit.
    // De `set_precision`-funksje soarget foar it ynstellen fan de presyzje op arsjitektueren dy't it ynstelle moatte troch de wrâldwide steat te feroarjen (lykas it kontrolearwurd fan 'e x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // De saak e <0 kin net yn 'e oare branch wurde pleatst.
    // Negative krêften resultearje yn in werhellend fraksje diel yn binêre, dat wurde rûn, wat echte (en sa no en dan frij wichtige!) Flaters feroarsaket yn it einresultaat.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritme Bellerophon is triviale koade rjochtfeardige troch net-triviale numerike analyze.
///
/// It rint 'f' ôf nei in float mei 64 bits betsjutting en fermannichfâldicht it mei de bêste approximaasje fan `10^e` (yn itselde formaat foar driuwende punten).Dit is faak genôch om it juste resultaat te krijen.
/// As it resultaat lykwols tichtby healwei leit tusken twa neistlizzende (ordinary)-floaten, betsjuttet de gearstalde rûnfout fan it fermannichfâldigjen fan twa approximaasje dat it resultaat mei in pear bits kin wêze.
/// As dit bart, makket it iterative algoritme R dingen op.
///
/// De mei de hân weagjende "close to halfway" wurdt presys makke troch de numerike analyze yn it papier.
/// Yn 'e wurden fan Clinger:
///
/// > Slop, útdrukt yn ienheden fan it minste signifikante bit, is in ynklusief bûn foar de flater
/// > sammele tidens de driuwende puntberekkening fan 'e approximaasje nei f * 10 ^ e.(Slop is
/// > net in bûn foar de wiere flater, mar begrinzet it ferskil tusken de approximaasje z en
/// > de best mooglike approximaasje dy't p bits fan betsjutting brûkt.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // De gefallen abs(e) <log5(2^N) binne yn fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Is de slop grut genôch om ferskil te meitsjen by ôfrûne nei n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// In iteratyf algoritme dat in driuwende punt approximaasje fan `f * 10^e` ferbetteret.
///
/// Elke iteraasje krijt op it lêste plak ien ienheid tichterby, wat fansels freeslik lang duorret om te konvergearjen as `z0` sels myld út is.
/// Gelokkich, as brûkt as fallback foar Bellerophon, is de begjinnende approximaasje off troch op syn meast ien ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Fin positive heule getallen `x`, `y`, sadat `x / y` krekt `(f *10^e) / (m* 2^k)` is.
        // Dit foarkomt net allinich omgean mei de tekens fan `e` en `k`, wy eliminearje ek de krêft fan twa mienskiplik foar `10^e` en `2^k` om de oantallen lytser te meitsjen.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dit wurdt wat ûnhandich skreaun, om't ús bignums gjin negative getallen stypje, dus wy brûke de absolute wearde + tekenynformaasje.
        // De fermannichfâldigjen mei m_digits kin net oerstreamje.
        // As `x` of `y` grut genôch binne dat wy ús soargen meitsje moatte oer oerstreaming, dan binne se ek grut genôch dat `make_ratio` de fraksje hat fermindere mei in faktor fan 2 ^ 64 of mear.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Net x mear nedich, bewarje in clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Noch y nedich, meitsje in kopy.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Jûn `x = f` en `y = m` wêr't `f` as ynfier desimale sifers as gewoanlik fertsjintwurdigje en `m` de betsjutting is fan in driuwende punt approximaasje, meitsje de ferhâlding `x / y` gelyk oan `(f *10^e) / (m* 2^k)`, mooglik fermindere troch in krêft fan twa hawwe beide gemien.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, útsein dat wy de fraksje ferminderje mei wat krêft fan twa.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dit kin net oerstreamje om't it positive `e` en negatyf `k` fereasket, wat allinich kin barre foar wearden ekstreem tichtby 1, wat betsjut dat `e` en `k` relatyf lyts sille wêze.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dit kin ek net oerfloedzje, sjoch hjirboppe.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), wer ferminderje troch in mienskiplike krêft fan twa.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptueel is Algoritme M de ienfâldichste manier om in desimaal nei in float te konvertearjen.
///
/// Wy foarmje in ferhâlding dy't gelyk is oan `f * 10^e`, en smite dan foegen fan twa yn oant it in jildige float betsjutting jout.
/// De binaire eksponint `k` is it oantal kearen dat wy teller of neamer mei twa fermannichfâldigje, dat wol sizze dat `f *10^e` altyd is gelyk oan `(u / v)* 2^k`.
/// As wy signifikant hawwe fûn, hoege wy allinich troch te rinnen troch de rest fan 'e divyzje te besjen, wat wurdt dien yn helperfunksjes hjirûnder.
///
///
/// Dit algoritme is super stadich, sels mei de yn `quick_start()` beskreaune optimalisaasje.
/// It is lykwols de ienfâldichste fan 'e algoritmen om oan te passen foar oerstreaming, ûnderstream en subnormale resultaten.
/// Dizze ymplemintaasje nimt oer as Bellerophon en Algoritme R oerweldige binne.
/// Understream en oerrin opspoaren is maklik: De ferhâlding is noch hieltyd gjin betsjutting binnen it berik, mar dochs is de minimum/maximum-eksponint berikt.
/// Yn 't gefal fan oerstreaming jouwe wy gewoan infinity werom.
///
/// It behanneljen fan ûnderstream en subnormalen is lestiger.
/// Ien grut probleem is dat, mei de minimale eksponint, de ferhâlding noch te grut kin wêze foar in signifikant.
/// Sjoch underflow() foar details.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mooglike optimalisaasje: generalisearje big_to_fp, sadat wy hjir it ekwivalint fan fp_to_float(big_to_fp(u)) kinne dwaan, allinich sûnder de dûbele rûning.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Wy moatte stopje by de minimale eksponint, as wy wachtsje oant `k < T::MIN_EXP_INT`, dan sille wy mei in faktor fan twa wêze.
            // Spitigernôch betsjuttet dit dat wy normale getallen moatte spesjalisearje mei de minimale eksponint.
            // FIXME fynt in mear elegante formulearring, mar rint de `tiny-pow10`-test út om te soargjen dat it eins krekt is!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Skipt de measte algoritme M-werhellingen oer troch de bitlange te kontrolearjen.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // De bitlingte is in skatting fan 'e basis twa logaritme, en log(u / v) = log(u), log(v).
    // De skatting is op syn heechst 1 út, mar altyd in ûnderskatting, dus de flater op log(u) en log(v) is fan itselde teken en annulearje (as beide grut binne).
    // Dêrom is de flater foar log(u / v) ek maksimaal ien.
    // De doelferhâlding is ien wêr't u/v in in binnen-berik betsjuttet.Sadwaande is ús beëindigingsbetingst log2(u / v) as de betsjuttende bits, plus/minus ien.
    // FIXME Sjen nei it twadde bit kin de skatting ferbetterje en wat mear divyzjes foarkomme.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Understream as subnormaal.Litte it oer oan 'e haadfunksje.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Oerstreaming.Litte it oer oan 'e haadfunksje.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ferhâlding is gjin betsjutting binnen it berik mei de minimale eksponint, dat wy moatte oerstallige bitsen ôfrinne en de eksponint dêrnei oanpasse.
    // De echte wearde sjocht der no sa út:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(fertsjintwurdige troch rem)
    //
    // Dêrom, as de ôfrûne bits!= 0.5 ULP binne, beslute se de rûning op har eigen.
    // As se gelyk binne en de rest net-nul is, moat de wearde noch omheech rûn wurde.
    // Allinich as de ôfrûne bits 1/2 binne en de rest nul is, hawwe wy in heal oant sels situaasje.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Gewoane rûn-oant-gelyk, ferwidere troch rûn te meitsjen op basis fan 'e rest fan in divyzje.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}