//! Validearjen en ûntleden fan in desimale tekenrige fan it formulier:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Mei oare wurden, standert driuwende-punt-syntaksis, mei twa útsûnderingen: Gjin teken, en gjin ôfhanneling fan "inf" en "NaN".Dizze wurde behannele troch de bestjoerderfunksje (super::dec2flt).
//!
//! Hoewol it erkennen fan jildige yngongen relatyf maklik is, moat dizze module ek de ûntelbere unjildige fariaasjes ôfwize, nea panic, en in soad kontrôles útfiere wêr't de oare modules op fertrouwe dat panic (of oerstreamt) op har beurt.
//!
//! Om saken minder te meitsjen, giet alles dat bart yn ien inkelde pas oer de ynput.
//! Dat, wês foarsichtich as jo wat feroarje, en dûbel kontrolearje mei de oare modules.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// De nijsgjirrige dielen fan in desimale tekenrige.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// De desimale eksponint, garandearre minder dan 18 desimale sifers te hawwen.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kontroleart as de ynfierstring in jildich driuwend komma-nûmer is en as dat sa is, sykje it yntegraal diel, it fraksjonele diel en de eksponint dêryn.
/// Hanteart gjin buorden.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Gjin sifers foar 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Wy fereaskje teminsten in inkeld sifer foar of nei it punt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Efterlizzende rommel nei fraksje diel
            }
        }
        _ => Invalid, // Eftergrûn nei earste sifersnaar
    }
}

/// Knipt desimale sifers ôf oant it earste net-sifere karakter.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Eksponint ekstraksje en flater kontrôle.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Efterlizzende rommel nei eksponint
    }
    if number.is_empty() {
        return Invalid; // Lege eksponint
    }
    // Op dit punt hawwe wy wis in jildige tekenrige.It kin te lang wêze om yn in `i64` te setten, mar as it sa grut is, is de ynput wis nul as ûneinich.
    // Om't elke nul yn 'e desimale sifers de eksponint allinich mei +/-1 oanpast, soe de ynput by exp=10 ^ 18 17 exabyte (!) fan nullen wêze moatte om sels op ôfstân tichtby te wêzen om einich te wêzen.
    //
    // Dit is net krekt in gebrûk dat wy moatte soargje.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}