//! Bit fiddling op positive IEEE 754 driuwers.Negative oantallen binne net en hoege net wurde behannele.
//! Normale driuwende komma-nûmers hawwe in kanonike foarstelling as (frac, exp), sadat de wearde 2 <sup>exp</sup> * is (1 + sum(frac[N-i] / 2<sup>i</sup>)) wêrby N it oantal bits is.
//!
//! Subnormalen binne wat oars en frjemd, mar itselde prinsipe jildt.
//!
//! Hjir fertsjintwurdigje wy se lykwols as (sig, k) mei f posityf, sadat de wearde f * is
//! 2 <sup>e</sup> .Neist it "hidden bit" eksplisyt feroaret dit de eksponint troch de saneamde mantissa-ferskowing.
//!
//! Oars sein, normaal wurde driuwers skreaun as (1), mar hjir wurde se skreaun as (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Wy neame (1) de **fraksjonele foarstelling** en (2) de **yntegraal foarstelling**.
//!
//! In protte funksjes yn dizze module behannelje allinich normale getallen.De dec2flt-routines nimme konservatyf it universeel-korrekte stadige paad (Algoritme M) foar heul lytse en heul grutte oantallen.
//! Dat algoritme hat allinich next_float() nedich dy't subnormalen en nullen behannelt.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// In helper trait om foar te kommen dat duplisearjen fan alle konvertaasjekoade foar `f32` en `f64`.
///
/// Sjoch it dokumint fan 'e âldermodule foar wêrom't dit nedich is.
///
/// Moat **noait** wurde ymplementearre foar oare typen of wurde brûkt bûten de dec2flt-module.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Type brûkt troch `to_bits` en `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Fiert in rauwe transmutaasje út nei in hiel getal.
    fn to_bits(self) -> Self::Bits;

    /// Fiert in rauwe transmutaasje út fan in hiel getal.
    fn from_bits(v: Self::Bits) -> Self;

    /// Jout de kategory werom wêryn dit getal falt.
    fn classify(self) -> FpCategory;

    /// Jout de mantissa, eksponint en ûndertekenet as hiel getallen.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekodeart de float.
    fn unpack(self) -> Unpacked;

    /// Werpen fan in lyts hiel getal dat presys kin wurde fertsjintwurdige.
    /// Panic as it heule getal net kin wurde fertsjintwurdige, soarget de oare koade yn dizze module derfoar dat dat noait barre lit.
    fn from_int(x: u64) -> Self;

    /// Krijt de wearde 10 <sup>e</sup> fan in foarôf berekkene tafel.
    /// Panics foar `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Wat de namme seit.
    /// It is makliker om hurde koade te meitsjen dan yntrinsyk te jonglearjen en te hoopjen dat LLVM konstant it falt.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // In konservatyf bûn oan de desimale sifers fan yngongen dy't gjin oerstreaming of nul of kinne produsearje
    /// subnormalen.Wierskynlik de desimale eksponint fan 'e maksimale normale wearde, fandêr de namme.
    const MAX_NORMAL_DIGITS: usize;

    /// As it wichtichste desimale sifer in plakwearde hat dy't grutter is dan dit, wurdt it getal grif rûn oant ûneinich.
    ///
    const INF_CUTOFF: i64;

    /// As it wichtichste desimale sifer in plakwearde hat minder dan dit, wurdt it getal grif rûn op nul.
    ///
    const ZERO_CUTOFF: i64;

    /// It oantal bits yn 'e eksponint.
    const EXP_BITS: u8;

    /// It oantal bits yn it signifikant,*ynklusyf* it ferburgen bit.
    const SIG_BITS: u8;

    /// It oantal bits yn 'e betsjutting,*eksklusyf* de ferburgen bit.
    const EXPLICIT_SIG_BITS: u8;

    /// De maksimale juridyske eksponint yn fraksjonele fertsjintwurdiging.
    const MAX_EXP: i16;

    /// De minimale juridyske eksponint yn fraksjonele fertsjintwurdiging, eksklusyf subnormalen.
    const MIN_EXP: i16;

    /// `MAX_EXP` foar yntegraal fertsjintwurdiging, dus, mei de ferskowing tapast.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodearre (dus, mei offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` foar yntegraal fertsjintwurdiging, dus, mei de ferskowing tapast.
    const MIN_EXP_INT: i16;

    /// De maksimale normalisearre betsjutting yn yntegraal fertsjintwurdiging.
    const MAX_SIG: u64;

    /// De minimale normalisearre betsjutting yn yntegraal fertsjintwurdiging.
    const MIN_SIG: u64;
}

// Meast in oplossing foar #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Jout de mantissa, eksponint en ûndertekenet as hiel getallen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponint foaroardielen + mantissa ferskowing
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe is net wis oft `as` goed rûn op alle platfoarms.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Jout de mantissa, eksponint en ûndertekenet as hiel getallen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponint foaroardielen + mantissa ferskowing
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe is net wis oft `as` goed rûn op alle platfoarms.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konverteart in `Fp` nei it tichtste type float foar masines.
/// Beheart gjin subnormale resultaten.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f is 64 bit, dus xe hat in mantissa-ferskowing fan 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rûn de 64-bits betsjutting ôf oant T::SIG_BITS bits mei heal oant sels.
/// Beheart eksponentferrin net.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Pas mantissa shift oan
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Omkear fan `RawFloat::unpack()` foar normalisearre getallen.
/// Panics as de betsjutting of eksponint net jildich is foar normalisearre getallen.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Ferwiderje it ferburgen bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Pas de eksponint oan foar eksponentbias en mantissa-ferskowing
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lit tekenbit op 0 ("+"), ús oantallen binne allegear posityf
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// In subnormaal konstruearje.In mantissa fan 0 is tastien en konstrueart nul.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodearre eksponint is 0, it tekenbit is 0, dat wy moatte de bits gewoan ynterpretearje.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ungefear in bignum mei in Fp.Rûnt binnen 0.5 ULP mei heal oant sels.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Wy hawwe alle bits foarôfgeand oan 'e yndeks `start`, dat wol sizze, wy ferskowe effektyf mei in bedrach fan `start`, dus dit is ek de eksponint dy't wy nedich binne.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rûn (half-to-even) ôfhinklik fan 'e ôfkoarte bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Fynt it grutste driuwende nûmer strikt lytser dan it argumint.
/// Beheart gjin subnormalen, nul as eksponint ûnderstream.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Fyn it lytste nûmer driuwende punt strikt grutter dan it argumint.
// Dizze hanneling is verzadigjend, dus next_float(inf) ==inf.
// Oars as de measte koade yn dizze module, behannelet dizze funksje nul, subnormalen en ûneinichheden.
// Lykas alle oare koade hjir behannelt it lykwols net mei NaN en negative getallen.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dit liket te goed om wier te wêzen, mar it wurket.
        // 0.0 wurdt kodearre as it wurd fan nul.Subnormalen binne 0x000m ... m wêr't m de mantissa is.
        // Benammen de lytste subnormaal is 0x0 ... 01 en de grutste is 0x000F ... F.
        // It lytste normale getal is 0x0010 ... 0, dus dizze hoeksaak wurket ek.
        // As de ferheging de mantissa oerslacht, ferheget de draachbit de eksponint lykas wy wolle, en de mantissabits wurde nul.
        // Fanwegen de ferburgen bitkonvinsje is dit ek krekt wat wy wolle!
        // Uteinlik is f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}