//! Utilityfunksjes foar bignums dy't net te folle sin hawwe om yn metoaden te feroarjen.

// FIXME De namme fan dizze module is wat spitich, om't oare modules ek `core::num` ymportearje.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Besykje oft alle bitsjes minder wichtich binne as `ones_place`, in relative flater yntrodusearje minder, gelyk of grutter dan 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // As alle oerbleaune bits nul binne, dan is it= 0.5 ULP, oars> 0.5 As d'r gjin bits mear binne (heal_bit==0), dan jout it hjirûnder ek Jild werom.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konverteart in ASCII-tekenrige mei allinich desimale sifers nei in `u64`.
///
/// Fiert gjin kontrôles út foar oerlêst of unjildige tekens, dus as de beller net foarsichtich is, is it resultaat nep en kin panic (hoewol it net `unsafe` wêze).
/// Derneist wurde lege snaren behannele as nul.
/// Dizze funksje bestiet om't
///
/// 1. mei help fan `FromStr` op `&[u8]` is `from_utf8_unchecked` nedich, wat min is, en
/// 2. it gearfoegjen fan de resultaten fan `integral.parse()` en `fractional.parse()` is yngewikkelder dan dizze heule funksje.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konverteart in tekenrige fan ASCII-sifers yn in bignum.
///
/// Lykas `from_str_unchecked` fertrout dizze funksje op 'e parser om net-sifers út te wreidzjen.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Wreidet in bignum út yn in 64-getal.Panics as it getal te grut is.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ekstraheret in oantal bits.

/// Yndeks 0 is it minste signifikante bit en it berik is as gewoan heal iepen.
/// Panics as frege wurdt om mear bits te ekstrahearjen dan passe yn it retourtype.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}