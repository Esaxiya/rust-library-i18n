//! Konstanten spesifyk foar it type `f64` dûbeldpräzis floatpunt.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Wiskundich wichtige oantallen wurde levere yn 'e `consts`-submodule.
//!
//! Foar de konstanten dy't direkt yn dizze module binne definieare (oars as dy definieare binne yn 'e `consts`-submodule), moat nije koade ynstee de byhearrende konstanten brûke dy't direkt binne definieare op it `f64`-type.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// De radiks as basis fan 'e ynterne fertsjintwurdiging fan `f64`.
/// Brûk [`f64::RADIX`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // bedoelde manier
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Oantal wichtige sifers yn basis 2.
/// Brûk [`f64::MANTISSA_DIGITS`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // bedoelde manier
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Likernôch oantal wichtige sifers yn basis 10.
/// Brûk [`f64::DIGITS`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // bedoelde manier
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] wearde foar `f64`.
/// Brûk [`f64::EPSILON`] ynstee.
///
/// Dit is it ferskil tusken `1.0` en it folgjende gruttere fertsjintwurdigbere getal.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // bedoelde manier
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Lytste einige `f64`-wearde.
/// Brûk [`f64::MIN`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // bedoelde manier
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Lytste positive normale `f64`-wearde.
/// Brûk [`f64::MIN_POSITIVE`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // bedoelde manier
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Grutste einige `f64`-wearde.
/// Brûk [`f64::MAX`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // bedoelde manier
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Ien grutter dan de minimale mooglike normale krêft fan 2 eksponint.
/// Brûk [`f64::MIN_EXP`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // bedoelde manier
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Maksimum mooglike krêft fan 2 eksponint.
/// Brûk [`f64::MAX_EXP`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // bedoelde manier
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Minimale mooglike normale krêft fan 10 eksponint.
/// Brûk [`f64::MIN_10_EXP`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // bedoelde manier
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Maksimum mooglike krêft fan 10 eksponint.
/// Brûk [`f64::MAX_10_EXP`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // bedoelde manier
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Net in nûmer (NaN).
/// Brûk [`f64::NAN`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // bedoelde manier
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Brûk [`f64::INFINITY`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // bedoelde manier
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Negative ûneinich (−∞).
/// Brûk [`f64::NEG_INFINITY`] ynstee.
///
/// # Examples
///
/// ```rust
/// // ferfallen manier
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // bedoelde manier
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Basis wiskundige konstanten.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ferfange troch wiskundige konstanten fan cmath.

    /// De konstante (π) fan Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// De folsleine sirkel konstante (τ)
    ///
    /// Gelyk oan 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Eulers nûmer (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// De radiks as basis fan 'e ynterne fertsjintwurdiging fan `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Oantal wichtige sifers yn basis 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Likernôch oantal wichtige sifers yn basis 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] wearde foar `f64`.
    ///
    /// Dit is it ferskil tusken `1.0` en it folgjende gruttere fertsjintwurdigbere getal.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Lytste einige `f64`-wearde.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Lytste positive normale `f64`-wearde.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Grutste einige `f64`-wearde.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Ien grutter dan de minimale mooglike normale krêft fan 2 eksponint.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Maksimum mooglike krêft fan 2 eksponint.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Minimale mooglike normale krêft fan 10 eksponint.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Maksimum mooglike krêft fan 10 eksponint.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Net in nûmer (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Negative ûneinich (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Jout `true` werom as dizze wearde `NaN` is.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` is iepenbier net beskikber yn libcore fanwegen soargen oer portabiliteit, dus dizze ymplemintaasje is foar yntern privee gebrûk.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Jout `true` werom as dizze wearde posityf ûneinich is as negatyf ûneinich, en `false` oars.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Jout `true` werom as dit getal noch ûneinich is noch `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // It is net nedich om NaN apart te behanneljen: as sels NaN is, is de ferliking net wier, krekt as winske.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Jout `true` werom as it getal [subnormal] is.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Wearden tusken `0` en `min` binne Subnormaal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Jout `true` werom as it getal gjin nul, ûneinich, [subnormal] as `NaN` is.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Wearden tusken `0` en `min` binne Subnormaal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Jout de kategory driuwend punt fan it getal.
    /// As mar ien eigendom wurdt hifke, is it oer it algemien rapper om ynstee it spesifike predikaat te brûken.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Jout `true` werom as `self` in posityf teken hat, ynklusyf `+0.0`, `NaN`s mei positive tekenbit en positive ûneinichheid.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Jout `true` werom as `self` in negatyf teken hat, ynklusyf `-0.0`, `NaN`s mei negatyf tekenbit en negatyf ûneinich.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Nimt de wjersidige (inverse) fan in getal, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Konverteart radialen nei graden.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // De divyzje is hjir korrekt ôfrûn mei respekt foar de wiere wearde fan 180/π.
        // (Dit ferskilt fan f32, wêr't in konstante moat wurde brûkt om in korrekt ôfrûne resultaat te garandearjen.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Konverteart graden nei radialen.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Jout it maksimum fan 'e twa getallen.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// As ien fan 'e arguminten NaN is, dan wurdt it oare argumint weromjûn.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Jout it minimum fan 'e twa getallen werom.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// As ien fan 'e arguminten NaN is, dan wurdt it oare argumint weromjûn.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Rûnt nei nul en konverteart nei elk primityf gehielstype, útgeande fan de wearde einich en past yn dat type.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// De wearde moat:
    ///
    /// * Net `NaN` wêze
    /// * Net ûneinich wêze
    /// * Wês represintabel yn it retoertype `Int`, nei't er syn fraksjonele diel ôfkapt hat
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `FloatToInt::to_int_unchecked` hanthavenje.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutaasje nei `u64`.
    ///
    /// Dit is op it stuit identyk oan `transmute::<f64, u64>(self)` op alle platfoarms.
    ///
    /// Sjoch `from_bits` foar wat diskusje oer de portabiliteit fan dizze operaasje (d'r binne hast gjin problemen).
    ///
    /// Tink derom dat dizze funksje ûnderskiedt fan `as`-casting, dy't besiket de *numerike* wearde te behâlden, en net de bitwize wearde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() is gjin casting!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // VEILIGHEID: `u64` is in gewoan âld datatype, sadat wy der altyd nei kinne transmutearje
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutaasje fan `u64`.
    ///
    /// Dit is op it stuit identyk oan `transmute::<u64, f64>(v)` op alle platfoarms.
    /// It docht bliken dat dit ongelooflijk draagbaar is, om twa redenen:
    ///
    /// * Floats en Ints hawwe deselde einigens op alle stipe platfoarms.
    /// * IEEE-754 spesifiseart hiel presys de bitopstelling fan driuwers.
    ///
    /// D'r is lykwols ien behertiging: foarôfgeand oan 'e 2008-ferzje fan IEEE-754 waard hoe it ynterpretearjen fan' e NaN-sinjaalbit net eins spesifisearre.
    /// De measte platfoarms (benammen x86 en ARM) keas de ynterpretaasje dy't úteinlik waard standerdisearre yn 2008, mar guon net (notammentlik MIPS).
    /// As resultaat binne alle signalearjende NaN's op MIPS stille NaN's op x86, en oarsom.
    ///
    /// Ynstee fan besykjen cross-platform foar sinjaal-wêzen te behâlden, befoarderet dizze ymplemintaasje it behâld fan 'e krekte bits.
    /// Dit betsjut dat alle ladingsladen kodearre yn NaNs wurde bewarre, sels as it resultaat fan dizze metoade wurdt ferstjoerd oer it netwurk fan in x86-masine nei in MIPS-ien.
    ///
    ///
    /// As de resultaten fan dizze metoade allinich wurde manipulearre troch deselde arsjitektuer dy't se produsearre, dan is d'r gjin soargen oer portabiliteit.
    ///
    /// As de ynput net NaN is, dan is d'r gjin soargen foar portabiliteit.
    ///
    /// As jo net skele oer sinjaal-wêzen (heul wierskynlik), dan is d'r gjin soargen oer portabiliteit.
    ///
    /// Tink derom dat dizze funksje ûnderskiedt fan `as`-casting, dy't besiket de *numerike* wearde te behâlden, en net de bitwize wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // VEILIGHEID: `u64` is in gewoan âld datatype, sadat wy der altyd fan kinne transmutearje
        // It docht bliken dat de feiligensproblemen mei sNaN oerspield binne!Hoera!
        unsafe { mem::transmute(v) }
    }

    /// Jout de ûnthâldfertsjintwurdiging fan dit floatpuntnûmer werom as byte-array yn grutte-endian (network) byte folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Jou de ûnthâldfertsjintwurdiging fan dit driuwende puntnûmer werom as in byte-array yn lytse-endiaanske byte folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Jout de ûnthâldfertsjintwurdiging fan dit driuwende nûmer werom as byte-array yn native byte-folchoarder.
    ///
    /// Om't de native endianness fan it doelplatfoarm wurdt brûkt, moat draachbere koade [`to_be_bytes`] of [`to_le_bytes`] brûke, as passend, yn plak.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Jout de ûnthâldfertsjintwurdiging fan dit driuwende nûmer werom as byte-array yn native byte-folchoarder.
    ///
    ///
    /// [`to_ne_bytes`] moatte hjir foarkar wurde as it mooglik is.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // VEILIGHEID: `f64` is in gewoan âld datatype, sadat wy der altyd nei kinne transmutearje
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Meitsje in driuwende puntwearde út har foarstelling as byte-array yn grutte endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Meitsje in driuwende komma-wearde fanút har foarstelling as byte-array yn lyts endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Meitsje in driuwende puntwearde út har foarstelling as byte-array yn native endian.
    ///
    /// Om't de native endianness fan it doelplatfoarm wurdt brûkt, wol draachbere koade wierskynlik [`from_be_bytes`] of [`from_le_bytes`] brûke, as passend yn plak.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Jout in oardering tusken sels-en oare wearden.
    /// Oars as de standert parsjele fergeliking tusken driuwende komma-nûmers, produseart dizze fergeliking altyd in oardering yn oerienstimming mei it totalOrder predikaat lykas definieare yn IEEE 754 (2008 revyzje) floatpuntstandaard.
    /// De wearden binne oardere yn folgjende folchoarder:
    /// - Negatyf stil NaN
    /// - Negatyf sinjalearjen NaN
    /// - Negative ûneinichheid
    /// - Negative getallen
    /// - Negative subnormale getallen
    /// - Negatyf nul
    /// - Posityf nul
    /// - Posityf subnormale oantallen
    /// - Positive getallen
    /// - Posityf ûneinichheid
    /// - Posityf sinjalearjen NaN
    /// - Posityf stil NaN
    ///
    /// Tink derom dat dizze funksje net altyd iens is mei de [`PartialOrd`]-en [`PartialEq`]-ymplementaasjes fan `f64`.Benammen beskôgje se negatyf en posityf nul as gelyk, wylst `total_cmp` net.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Yn gefal fan negativen flipje alle bitsen, útsein it teken, om in ferlykbere opmaak te berikken as komplementgetallen fan twa
        //
        // Wêrom wurket dit?IEEE 754 driuwers besteane út trije fjilden:
        // Tekenbit, eksponint en mantissa.De set eksponent-en mantissafjilden as gehiel hat it eigenskip dat har bitwize folchoarder is gelyk oan de numerike grutte wêr't de grutte wurdt definieare.
        // De grutte wurdt normaal net definieare op NaN-wearden, mar IEEE 754 totalOrder definieart de NaN-wearden ek om de bitwize folchoarder te folgjen.Dit liedt ta oarder útlein yn 'e doc-kommentaar.
        // De foarstelling fan grutte is lykwols itselde foar negative en positive getallen-allinich it tekenbit is oars.
        // Om de driuwers maklik te fergelykjen as ûndertekene gehiele getallen, moatte wy de eksponint-en mantissabits omdraaie yn gefal fan negative getallen.
        // Wy konvertearje de getallen effektyf yn "two's complement"-foarm.
        //
        // Om it flippen te meitsjen bouwe wy in masker en XOR derop.
        // Wy berekkenje sûnder tellen in "all-ones except for the sign bit"-masker út wearden mei negatyf-ûndertekene: rjochts ferskowend teken-wreidet it heule getal út, dat wy "fill" it masker mei tekenbits, en konvertearje dan nei net-ûndertekene om noch ien nulbit te drukken.
        //
        // Op positive wearden is it masker allegear nullen, dus it is in no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// In wearde beheine ta in bepaald ynterval, útsein as it NaN is.
    ///
    /// Jout `max` as `self` grutter is as `max`, en `min` as `self` minder is as `min`.
    /// Oars jout dit `self` werom.
    ///
    /// Tink derom dat dizze funksje NaN werombringt as de begjinwearde ek NaN wie.
    ///
    /// # Panics
    ///
    /// Panics as `min > max`, `min` NaN is, of `max` NaN is.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}