//! Fouttypen foar konverzje nei yntegraal typen.

use crate::convert::Infallible;
use crate::fmt;

/// It flatertype is weromjûn as in kontrolearre yntegraal konverzje mislearret.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Wedstriid yn stee fan twinge om derfoar te soargjen dat koade lykas `From<Infallible> for TryFromIntError` hjirboppe bliuwt wurkje as `Infallible` in alias wurdt foar `!`.
        //
        //
        match never {}
    }
}

/// In flater dy't kin wurde weromjûn by it analysearjen fan in hiel getal.
///
/// Dizze flater wurdt brûkt as it flatertype foar de `from_str_radix()`-funksjes op 'e primitive gehielstypen, lykas [`i8::from_str_radix`].
///
/// # Potensjele oarsaken
///
/// Under oare oarsaken kin `ParseIntError` wurde smiten fanwegen liedende of efterlizzende spaasjes yn 'e tekenrige bgl. As it wurdt krigen fan' e standertynfier.
///
/// It brûken fan 'e [`str::trim()`]-metoade soarget derfoar dat der gjin wytromte bliuwt foardat it analysearjen is.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum om de ferskate soarten flaters op te slaan dy't kinne ûntleden fan in heule getal mislearret.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Wearde dy't wurdt analysearre is leech.
    ///
    /// Under oare oarsaken sil dizze fariant wurde konstruearre by it analysearjen fan in lege tekenrige.
    Empty,
    /// Befettet in unjildich sifer yn syn kontekst.
    ///
    /// Under oare oarsaken sil dizze fariant wurde konstruearre by it parsen fan in tekenrige dy't in net-ASCII-tekens befettet.
    ///
    /// Dizze fariant wurdt ek konstruearre as in `+` as `-` op in eigen of yn 'e midden fan in getal ferkeard wurdt pleatst.
    ///
    ///
    InvalidDigit,
    /// Heelgetal is te grut om te opslaan yn it doele gehielstype.
    PosOverflow,
    /// Heelgetal is te lyts om te bewarjen yn it heule gehielstype.
    NegOverflow,
    /// Wearde wie Nul
    ///
    /// Dizze fariant wurdt útstjoerd as de parsingstring in wearde hat fan nul, wat yllegaal soe wêze foar typen dy't net nul binne.
    ///
    Zero,
}

impl ParseIntError {
    /// Jout de detaillearre oarsaak fan parsing fan in hiel getal út.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}