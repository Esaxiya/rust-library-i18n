//! In module foar wurkjen mei liende gegevens.

#![stable(feature = "rust1", since = "1.0.0")]

/// In trait foar liengegevens.
///
/// Yn Rust is it gewoan om ferskate foarstellingen fan in type te leverjen foar ferskate gebrûk fan gefallen.
/// Bygelyks, opslachlokaasje en behear foar in wearde kinne spesifyk wurde keazen as passend foar in bepaald gebrûk fia oanwiistypen lykas [`Box<T>`] of [`Rc<T>`].
/// Behalven dizze generike wrappers dy't mei elk type kinne wurde brûkt, leverje guon soarten opsjonele fasetten dy't potensjeel kostbere funksjonaliteit leverje.
/// In foarbyld foar sa'n type is [`String`] dy't de mooglikheid foeget in tekenrige út te wreidzjen nei de basis [`str`].
/// Dit freget om ekstra ynformaasje ûnnedich te hâlden foar in ienfâldige, ûnferoarlike string.
///
/// Dizze soarten jouwe tagong ta de ûnderlizzende gegevens fia referinsjes nei it type fan dy gegevens.Der wurdt sein dat dat type 'liend is'.
/// In [`Box<T>`] kin bygelyks lien wurde as `T`, wylst in [`String`] kin wurde lien as `str`.
///
/// Soarten jouwe út dat se kinne wurde lien as ien of oar type `T` troch `Borrow<T>` te ymplementearjen, en jouwe in ferwizing nei in `T` yn 'e trait's [`borrow`]-metoade.In type is fergees te lienjen as ferskate ferskillende soarten.
/// As it mutabel lienje wol as it type-wêrtroch de ûnderlizzende gegevens kinne wurde oanpast, kin it [`BorrowMut<T>`] derneist ymplementearje.
///
/// Fierder moat by it leverjen fan ymplementaasjes foar ekstra traits besjoen wurde oft se identyk moatte gedrage oan dy fan it ûnderlizzende type as gefolch fan optreden as fertsjintwurdiging fan dat ûnderlizzende type.
/// Generike koade brûkt typysk `Borrow<T>` as it fertrout op it identike gedrach fan dizze ekstra trait-ymplementaasjes.
/// Dizze traits sille wierskynlik ferskine as ekstra trait bounds.
///
/// Benammen `Eq`, `Ord` en `Hash` moatte lykweardich wêze foar liende en eigene wearden: `x.borrow() == y.borrow()` moat itselde resultaat jaan as `x == y`.
///
/// As generike koade gewoan wurkje moat foar alle soarten dy't in ferwizing kinne leverje nei relatearre type `T`, is it faaks better om [`AsRef<T>`] te brûken, om't mear soarten it feilich kinne ymplementearje.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// As gegevensammeling hat [`HashMap<K, V>`] sawol kaaien as wearden.As de werklike gegevens fan 'e kaai binne ferpakt yn in soarte fan behearen, dan soe it lykwols noch mooglik wêze kinne om nei in wearde te sykjen mei in ferwizing nei de gegevens fan' e kaai.
/// As de kaai bygelyks in tekenrige is, dan wurdt it wierskynlik mei de hashkaart opslein as [`String`], wylst it mooglik wêze soe om te sykjen mei in [`&str`][`str`].
/// Sa moat `insert` op in `String` operearje, wylst `get` in `&str` brûke kin.
///
/// In bytsje ferienfâldige sjogge de relevante dielen fan `HashMap<K, V>` der sa út:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // fjilden weilitten
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// De heule hashkaart is generyk oer in kaaityp `K`.Om't dizze toetsen wurde opslein mei de hashkaart, moat dit type de gegevens fan 'e kaai hawwe.
/// By it ynfoegjen fan in kaai-weardepaar krijt de kaart sa'n `K` en moat de juste hash-emmer fine en kontrolearje oft de kaai al oanwêzich is basearre op dy `K`.It fereasket dêrom `K: Hash + Eq`.
///
/// By it sykjen nei in wearde op 'e kaart, hoecht it lykwols in ferwizing nei in `K` te jaan as de kaai om nei te sykjen, altyd sa'n eigendom wearde oan te meitsjen.
/// Foar tekenrige toetsen soe dit betsjutte dat in `String`-wearde moat wurde makke krekt foar it sykjen nei gefallen wêr't allinich in `str` beskikber is.
///
/// Ynstee is de `get`-metoade generyk oer it type fan 'e ûnderlizzende kaaigegevens, neamd `Q` yn' e hjirboppe metoade-hantekening.It stelt dat `K` lient as `Q` troch dat `K: Borrow<Q>` te easkjen.
/// Troch ekstra `Q: Hash + Eq` te fereaskjen, sinjaleart it de eask dat `K` en `Q` ymplementaasjes hawwe fan 'e `Hash` en `Eq` traits dy't identike resultaten produsearje.
///
/// De ymplemintaasje fan `get` fertrout benammen op identike ymplementaasjes fan `Hash` troch de hash-bak fan 'e kaai te bepalen troch `Hash::hash` op te roppen op' e `Q`-wearde, hoewol it de kaai ynfoege basearre op 'e hash-wearde berekkene fan' e `K`-wearde.
///
///
/// As konsekwinsje brekt de hashkaart as in `K` dy't in `Q`-wearde ynpakt in oare hash produseart dan `Q`.Stel jo bygelyks foar dat jo in type hawwe dat in tekenrige wikkelt, mar ASCII-letters fergeliket dy't har saak negearje:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Om't twa gelikense wearden deselde hashwearde moatte produsearje, moat de ymplemintaasje fan `Hash` ek ASCII-saak negearje:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kin `CaseInsensitiveString` `Borrow<str>` útfiere?It kin grif in ferwizing leverje nei in snijstik fia syn befette string.
/// Mar om't de `Hash`-ymplemintaasje oars is, gedraacht it har oars as `str` en moat it `Borrow<str>` eins net ymplementearje.
/// As it oaren tagong wolle ta de ûnderlizzende `str`, kin it dat dwaan fia `AsRef<str>` dy't gjin ekstra easken hat.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutably lient fan in eigendom wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// In trait foar gegevens dy't mutabel liene kinne.
///
/// As begelieder fan [`Borrow<T>`] lit dizze trait in type liene as ûnderlizzend type troch in feroarbere referinsje te leverjen.
/// Sjoch [`Borrow<T>`] foar mear ynformaasje oer liening as in oar type.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutabel lient fan in eigen wearde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}