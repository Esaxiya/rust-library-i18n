//! Komposearbere asynchrone iteraasje.
//!
//! As futures asynchrone wearden binne, dan binne streamen asynchrone iterators.
//! As jo josels hawwe fûn mei in asynchrone kolleksje fan ien of oare soarte, en nedich binne om in operaasje út te fieren op 'e eleminten fan' e samling, sille jo 'streams' fluch rinne.
//! Streamen wurde swier brûkt yn idiomatyske asynchrone Rust-koade, dus it is de muoite wurdich om dêr fertroud mei te wurden.
//!
//! Foardat wy mear útlizze, litte wy prate oer hoe't dizze module is struktureare:
//!
//! # Organization
//!
//! Dizze module is foar in grut part organisearre troch type:
//!
//! * [Traits] binne it kearndiel: dizze traits bepale hokker soart streamen besteane en wat jo dermei kinne dwaan.De metoaden fan dizze traits binne it wurdich om wat ekstra stúdzjetiid yn te stekken.
//! * Funksjes leverje wat nuttige manieren om wat basisstreamen te meitsjen.
//! * Structs binne faak de retourtypen fan 'e ferskate metoaden op' e traits fan dizze module.Jo wolle normaalwei nei de metoade sjen dy't de `struct` makket, yn stee fan de `struct` sels.
//! Foar mear details oer wêrom, sjoch '[Implementing Stream](#implement-stream)'.
//!
//! [Traits]: #traits
//!
//! Dat is it!Litte wy yn streamingen grave.
//!
//! # Stream
//!
//! It hert en de siel fan dizze module is de [`Stream`] trait.De kearn fan [`Stream`] sjocht der sa út:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Oars as `Iterator` makket `Stream` in ûnderskied tusken de [`poll_next`]-metoade dy't wurdt brûkt by it ymplementearjen fan in `Stream`, en in (to-be-implemented) `next`-metoade dy't wurdt brûkt by it konsumearjen fan in stream.
//!
//! Konsuminten fan `Stream` hoege allinich `next` te beskôgjen, dy't as neamd wurdt in future werombringt dy't `Option<Stream::Item>` opleveret.
//!
//! De future weromjûn troch `next` sil `Some(Item)` opleverje salang't der eleminten binne, en as se allegear útput binne, sil `None` opleverje om oan te jaan dat iteraasje klear is.
//! As wy wachtsje op wat asynchront om op te lossen, sil de future wachtsje oant de stream wer klear is om op te leverjen.
//!
//! Yndividuele streamen kinne der foar kieze om iteraasje te ferfetsjen, en sa kin `next` opnij belje `Some(Item)` op in bepaald stuit wer of net opleverje.
//!
//! De folsleine definysje fan [`Stream`] befettet ek in oantal oare metoaden, mar se binne standertmetoaden, boud boppe op [`poll_next`], en dus krije jo se fergees.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Stream ymplementearje
//!
//! In eigen stream oanmeitsje omfettet twa stappen: in `struct` oanmeitsje om de steat fan 'e stream te hâlden, en dan [`Stream`] út te fieren foar dy `struct`.
//!
//! Litte wy in stream meitsje mei de namme `Counter` dy't telt fan `1` oant `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Earst de struktuer:
//!
//! /// In stream dy't telt fan ien oant fiif
//! struct Counter {
//!     count: usize,
//! }
//!
//! // wy wolle dat ús telling by ien begjint, dus litte wy in new()-metoade tafoegje om te helpen.
//! // Dit is net strikt nedich, mar is handich.
//! // Tink derom dat wy `count` op nul begjinne, sille wy sjen wêrom yn `poll_next()`'s-ymplemintaasje hjirûnder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dan ymplementearje wy `Stream` foar ús `Counter`:
//!
//! impl Stream for Counter {
//!     // wy sille telle mei usize
//!     type Item = usize;
//!
//!     // poll_next() is de ienige fereaske metoade
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Ferheegje ús telling.Dit is wêrom't wy op nul begûnen.
//!         self.count += 1;
//!
//!         // Kontrolearje om te sjen as wy klear binne mei tellen of net.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Streamen binne *lui*.Dit betsjut dat gewoan in stream kreëarje net in heule soad _do_.Neat bart echt oant jo `next` skilje.
//! Dit is soms in boarne fan betizing by it meitsjen fan in stream allinich foar har side-effekten.
//! De gearstaller sil ús warskôgje oer dit soarte fan gedrach:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;