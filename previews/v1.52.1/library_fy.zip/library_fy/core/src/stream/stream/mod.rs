use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// In ynterface foar it omgean mei asynchrone iterators.
///
/// Dit is de haadstream trait.
/// Sjoch asjebleaft de [module-level documentation] foar mear oer it konsept fan streamen.
/// Yn it bysûnder wolle jo miskien witte hoe't jo [implement `Stream`][impl] moatte.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// It type artikels levere troch de stream.
    type Item;

    /// Besykje de folgjende wearde fan dizze stream te heljen, de hjoeddeistige taak te registrearjen foar wakeup as de wearde noch net beskikber is, en `None` werom te jaan as de stream útput is.
    ///
    /// # Weromwearde
    ///
    /// D'r binne ferskate mooglike weromwearden, dy't elk in ûnderskate streamtastatus oanjouwe:
    ///
    /// - `Poll::Pending` betsjut dat de folgjende wearde fan dizze stream noch net klear is.Ymplementaasjes sille derfoar soargje dat de hjoeddeistige taak wurdt op 'e hichte brocht as de folgjende wearde mooglik wêze kin.
    ///
    /// - `Poll::Ready(Some(val))` betsjut dat de stream in wearde, `val`, mei súkses hat produsearre en fierdere wearden kin produsearje op folgjende `poll_next`-oproppen.
    ///
    /// - `Poll::Ready(None)` betsjut dat de stream is beëinige, en `poll_next` moat net opnij oanroppen wurde.
    ///
    /// # Panics
    ///
    /// As in stream ienris is klear (`Ready(None)` from `poll_next`) weromkomt, opnij `poll_next`-metoade neame, kin panic, foar altyd blokkearje, of oare soarten problemen feroarsaakje; `Stream` trait stelt gjin easken foar de effekten fan sa'n oprop.
    ///
    /// Om't de `poll_next`-metoade lykwols net `unsafe` is markearre, jilde de gewoane regels fan Rust: oproppen moatte nea net definieare gedrach feroarsaakje (geheugenkorrupsje, ferkeard gebrûk fan `unsafe`-funksjes, of sokssawat), ûnôfhinklik fan 'e steatsteat.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Jout de grinzen werom op 'e oerbleaune lingte fan' e stream.
    ///
    /// Spesifyk jout `size_hint()` in tupel werom wêr't it earste elemint de ûndergrins is, en it twadde elemint de boppegrins is.
    ///
    /// De twadde helte fan 'e tuple dy't weromkomt is in [`Option`]`<`[`usize`] `>`.
    /// In [`None`] hjir betsjut dat d'r gjin bekende boppegrins is, of dat de boppegrins grutter is dan [`usize`].
    ///
    /// # Ymplementaasjenota's
    ///
    /// It wurdt net ôftwongen dat in ymplemintaasje fan stream it ferklearre oantal eleminten oplevert.In buggystream kin minder leverje dan de ûndergrins as mear as de boppegrins fan eleminten.
    ///
    /// `size_hint()` is foaral bedoeld om te brûken foar optimalisaasjes lykas romte reservearje foar de eleminten fan 'e stream, mar hoecht net te fertrouwen dat bgl. kontrôles yn unfeilige koade weilitte.
    /// In ferkearde ymplemintaasje fan `size_hint()` moat net liede ta oertredings fan ûnthâldfeiligens.
    ///
    /// Dat sei, de ymplemintaasje moat in krekte skatting leverje, want oars soe it in ynbreuk wêze op it protokol fan 'e trait.
    ///
    /// De standert ymplemintaasje jout '(0, `[` Gjin`]')`dat is korrekt foar elke stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}