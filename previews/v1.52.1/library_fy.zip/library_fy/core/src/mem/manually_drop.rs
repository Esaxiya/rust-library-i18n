use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// In wrapper om kompilearder te remjen automatysk de destruktor fan 'T' te neamen.
/// Dizze wrapper is 0-kosten.
///
/// `ManuallyDrop<T>` is ûnderwerp fan deselde optimisaasjes foar opmaak as `T`.
/// As konsekwinsje hat it *gjin effekt* op 'e oannames dy't de gearstaller makket oer har ynhâld.
/// Inisjalisearjen fan in `ManuallyDrop<&mut T>` mei [`mem::zeroed`] is bygelyks net definieare gedrach.
/// As jo uninitialisearre gegevens behannelje moatte, brûk dan [`MaybeUninit<T>`].
///
/// Tink derom dat tagong ta de wearde yn in `ManuallyDrop<T>` feilich is.
/// Dit betsjut dat in `ManuallyDrop<T>` wêrfan de ynhâld is fallen is net bleatsteld moatte wurde fia in iepenbiere feilige API.
/// Lykwols is `ManuallyDrop::drop` ûnfeilich.
///
/// # `ManuallyDrop` en drop oarder.
///
/// Rust hat in goed definieare [drop order] fan wearden.
/// Om derfoar te soargjen dat fjilden as pleatslike befolking yn in spesifike folchoarder falle, opnij oarderje de deklaraasjes sa dat de ymplisite dropopdracht de juste is.
///
/// It is mooglik `ManuallyDrop` te brûken foar it kontrolearjen fan 'e drop-oarder, mar dit fereasket ûnfeilige koade en is dreech om korrekt te dwaan yn' e oanwêzigens fan ûntspanning.
///
///
/// As jo bygelyks wolle soargje dat in spesifyk fjild nei de oaren falt, meitsje it dan it lêste fjild fan in struktuer:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` sil nei `children` falle.
///     // Rust garandeart dat fjilden falle yn 'e folchoarder fan ferklearring.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Wrap in wearde yn om mei de hân te fallen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Jo kinne noch feilich wurkje op 'e wearde
    /// assert_eq!(*x, "Hello");
    /// // Mar `Drop` sil hjir net wurde rinne
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Pakt de wearde út fan 'e `ManuallyDrop`-kontener.
    ///
    /// Hjirmei kin de wearde opnij falle.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dit sakket de `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Nimt de wearde fan 'e `ManuallyDrop<T>`-kontener út.
    ///
    /// Dizze metoade is primêr bedoeld foar it ferpleatsen fan wearden yn drop.
    /// Ynstee fan [`ManuallyDrop::drop`] te brûken om de wearde manuell te fallen, kinne jo dizze metoade brûke om de wearde te nimmen en it lykwols te brûken.
    ///
    /// As it mooglik is, hat it de foarkar om [`into_inner`][`ManuallyDrop::into_inner`] yn plak te brûken, wat foarkomt dat de ynhâld fan 'e `ManuallyDrop<T>` dupliseart.
    ///
    ///
    /// # Safety
    ///
    /// Dizze funksje ferpleatst de befette wearde semantysk sûnder fierdere gebrûk te foarkommen, wêrtroch de steat fan dizze kontener net feroare is.
    /// It is jo ferantwurdlikheid om te soargjen dat dizze `ManuallyDrop` net wer brûkt wurdt.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // VEILIGHEID: wy lêze út in referinsje, dy't garandearre is
        // jildich te wêzen foar lêzen.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Falt de befette wearde mei de hân.Dit is krekt lykweardich oan [`ptr::drop_in_place`] mei in oanwizer oproppe nei de befette wearde.
    /// As sadanich, as de befette wearde in ynpakke struktuer is, sil de destruktor yn plak wurde neamd sûnder de wearde te ferpleatsen, en kin dus brûkt wurde om [pinned]-gegevens feilich te litten falle.
    ///
    /// As jo eigendom hawwe fan 'e wearde, kinne jo [`ManuallyDrop::into_inner`] ynstee brûke.
    ///
    /// # Safety
    ///
    /// Dizze funksje rint de destruktor fan 'e befette wearde.
    /// Oars as wizigingen makke troch de destruktor sels, wurdt it ûnthâld ûnferoare litten, en wat de gearstaller oanbelanget noch in bitpatroan hat dat jildich is foar it type `T`.
    ///
    ///
    /// Dizze "zombie"-wearde moat lykwols net wurde bleatsteld oan feilige koade, en dizze funksje moat net mear dan ien kear neamd wurde.
    /// Om in wearde te brûken neidat dizze is fallen, of meardere kearen in wearde falle, kin Undefined Gedrach feroarsaakje (ôfhinklik fan wat `drop` docht).
    /// Dit wurdt normaal foarkommen troch it type systeem, mar brûkers fan `ManuallyDrop` moatte dizze garânsjes hanthavenje sûnder help fan 'e kompilearder.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // VEILIGHEID: wy falle de wearde nei oanwize troch in feroarbere referinsje
        // dat garandearre jildich is foar skriuwen.
        // It is oan 'e beller om te soargjen dat `slot` net wer falt.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}