use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// In wrapper-type om uninitialisearre eksimplaren fan `T` te bouwen.
///
/// # Initialization invariant
///
/// De gearstaller giet yn 't algemien fanút dat in fariabele goed is initialisearre neffens de easken fan it type fan' e fariabele.Bygelyks, in fariabele fan referinsjetype moat wurde ôfstimd en net-NULL.
/// Dit is in invariant dy't *altyd* moat wurde bewarre, sels yn ûnfeilige koade.
/// As konsekwinsje feroarsaket nul-inisjalisearjen fan in fariabele fan referinsjetype fuortendaliks [undefined behavior][ub], likefolle oft dizze referinsje ea wend wurdt om tagong te krijen ta ûnthâld:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined gedrach!⚠️
/// // De lykweardige koade mei `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined gedrach!⚠️
/// ```
///
/// Dit wurdt brûkt troch de kompilearder foar ferskate optimisaasjes, lykas ferwidering fan runtime-kontrôles en it optimalisearjen fan `enum`-opmaak.
///
/// Likegoed kin folslein uninitialisearre ûnthâld elke ynhâld hawwe, wylst in `bool` altyd `true` of `false` moat wêze.Hjirtroch is it meitsjen fan in net-inisjalisearre `bool` undefined gedrach:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined gedrach!⚠️
/// // De lykweardige koade mei `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined gedrach!⚠️
/// ```
///
/// Boppedat is uninitialisearre ûnthâld spesjaal dat it gjin fêste wearde hat ("fixed" betsjuttet "it won't change without being written to").Deselde uninitialisearre byte meardere kearen lêze kin ferskillende resultaten jaan.
/// Dit makket it undefined gedrach om uninitialisearre gegevens yn in fariabele te hawwen, sels as dizze fariabele in heulgetaaltype hat, dat oars kin elk *fêst* bitpatroan hawwe:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined gedrach!⚠️
/// // De lykweardige koade mei `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined gedrach!⚠️
/// ```
/// (Tink derom dat de regels om uninitialisearre integers noch net binne finalisearre, mar oant se binne, is it oan te rieden om se te foarkommen.)
///
/// Boppedat, tink derom dat de measte soarten ekstra invarianten hawwe, bûten allinich wurde beskôge as inisjalisearre op it type nivo.
/// Bygelyks, in '1`-inisjalisearre [`Vec<T>`] wurdt as inisjalisearre beskôge (ûnder de hjoeddeistige ymplemintaasje; dit is gjin stabile garânsje), om't de iennige fereaske dy't de gearstaller derfan wit dat de gegevenswizer net-nul moat wêze.
/// It meitsjen fan sa'n `Vec<T>` feroarsaket gjin *direkte* undefined gedrach, mar sil undefined gedrach feroarsaakje mei de measte feilige operaasjes (ynklusyf drop it).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` tsjinnet om ûnfeilige koade yn te skeakeljen om te gean mei uninitialisearre gegevens.
/// It is in sinjaal nei de gearstaller dat oanjout dat de gegevens hjir miskien net *kinne* inisjalisearre wurde:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Meitsje in eksplisyt uninitialisearre referinsje.
/// // De gearstaller wit dat gegevens yn in `MaybeUninit<T>` unjildich kinne wêze, en dêrom is dit net UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Set it op in jildige wearde.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Pak de inisjalisearre gegevens út-dit is allinich tastien * nei't `x` goed initialisearre is!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// De gearstaller wit dan gjin ferkearde oannames of optimisaasjes te meitsjen op dizze koade.
///
/// Jo kinne tinke oan `MaybeUninit<T>` as in bytsje lykas `Option<T>`, mar sûnder ien fan 'e runtime tracking en sûnder ien fan' e feiligenskontrôles.
///
/// ## out-pointers
///
/// Jo kinne `MaybeUninit<T>` brûke om "out-pointers" te ymplementearjen: ynstee fan gegevens werom te jaan fan in funksje, jou it in oanwizer nei wat (uninitialized)-ûnthâld om it resultaat yn te bringen.
/// Dit kin nuttich wêze as it wichtich is foar de beller om te kontrolearjen hoe't it ûnthâld dat it resultaat opslein wurdt tawiisd wurdt, en jo wolle ûnnedige bewegingen foarkomme.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` lit de âlde ynhâld net falle, wat wichtich is.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // No wite wy dat `v` is inisjalisearre!Dit soarget ek derfoar dat de vector goed falt.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inisjalisearjen fan in array elemint foar elemint
///
/// `MaybeUninit<T>` kin brûkt wurde om in grut array elemint foar elemint te inisjalisearjen:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Meitsje in uninitialisearre array fan `MaybeUninit`.
///     // De `assume_init` is feilich, om't it type dat wy hjir beweare inisjalisearre binne in bosk fan 'MaybeUninit's is, dy't gjin inisjalisaasje nedich binne.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // In `MaybeUninit` falle docht neat.
///     // Sadwaande feroarsaket it brûken fan rauwe oanwizer yn plak fan `ptr::write` de âlde net-inisjalisearre wearde net.
/////
///     // Ek as d'r in panic is yn dizze loop, hawwe wy in ûnthâldlekkage, mar d'r is gjin probleem foar geheugenfeiligens.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alles is inisjalisearre.
///     // Transmute de array nei it inisjalisearre type.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Jo kinne ek wurkje mei diels inisjalisearre arrays, dy't fûn wurde kinne yn datastruktueren op leech nivo.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Meitsje in uninitialisearre array fan `MaybeUninit`.
/// // De `assume_init` is feilich, om't it type dat wy hjir beweare inisjalisearre binne in bosk fan 'MaybeUninit's is, dy't gjin inisjalisaasje nedich binne.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tel it oantal eleminten dat wy hawwe tawiisd.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Drop foar elk item yn 'e array as wy it tawiisd hawwe.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inisjalisearjen fan in struktuer fjild foar fjild
///
/// Jo kinne `MaybeUninit<T>` en de [`std::ptr::addr_of_mut`]-makro brûke om structs fjild foar fjild te inisjalisearjen:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inisjalisearjen fan it `name`-fjild
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // It `list`-fjild inisjalisearje As hjir in panic is, dan lekt de `String` yn it `name`-fjild.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alle fjilden binne inisjalisearre, dus wy skilje `assume_init` om in inisjalisearre Foo te krijen.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` is garandearre deselde grutte, ôfstimming en ABI te hawwen as `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Unthâld lykwols dat in type *mei* in `MaybeUninit<T>` net needsaaklik deselde opmaak is;Rust garandeart yn 't algemien net dat de fjilden fan in `Foo<T>` deselde oarder hawwe as in `Foo<U>`, sels as `T` en `U` deselde grutte en ôfstimming hawwe.
///
/// Fierder om't elke bitwearde jildich is foar in `MaybeUninit<T>`, kin de kompilator gjin non-zero/niche-filling-optimisaasjes tapasse, wat mooglik resulteart yn in gruttere maat:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// As `T` FFI-feilich is, dan is `MaybeUninit<T>` dat ek.
///
/// Wylst `MaybeUninit` `#[repr(transparent)]` is (wat oanjout dat it deselde grutte, útrjochting en ABI garandeart as `T`), feroaret dit *gjin* ien fan 'e eardere behertigingen.
/// `Option<T>` en `Option<MaybeUninit<T>>` kinne noch ferskillende maten hawwe, en typen dy't in fjild fan type `T` befetsje, kinne oars oanlein (en grut wurde) dan as dat fjild `MaybeUninit<T>` wie.
/// `MaybeUninit` is in uny-type, en `#[repr(transparent)]` op fakbûnen is ynstabyl (sjoch [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Nei ferrin fan tiid kinne de krekte garânsjes fan `#[repr(transparent)]` op fakbûnen evoluearje, en `MaybeUninit` kin `#[repr(transparent)]` wol of net bliuwe.
/// Dat sei, `MaybeUninit<T>` sil *altyd* garandearje dat it deselde grutte, ôfstimming en ABI hat as `T`;it is gewoan dat de manier wêrop `MaybeUninit` dizze garânsje ymplementeart kin evoluearje.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item, sadat wy oare soarten dêryn kinne ynpakke.Dit is nuttich foar generators.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Net `T::clone()` skilje, kinne wy net witte as wy dêrfoar genôch initialisearre binne.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Makket in nije `MaybeUninit<T>` inisjalisearre mei de opjûne wearde.
    /// It is feilich [`assume_init`] te skiljen oer de weromwearde fan dizze funksje.
    ///
    /// Tink derom dat it dropjen fan in `MaybeUninit<T>` de dropkoade fan 'T' nea neame sil.
    /// It is jo ferantwurdlikens om derfoar te soargjen dat `T` falt as it inisjalisearre wurdt.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Makket in nije `MaybeUninit<T>` oan yn ininitialisearre steat.
    ///
    /// Tink derom dat it dropjen fan in `MaybeUninit<T>` de dropkoade fan 'T' nea neame sil.
    /// It is jo ferantwurdlikens om derfoar te soargjen dat `T` falt as it inisjalisearre wurdt.
    ///
    /// Sjoch de [type-level documentation][MaybeUninit] foar guon foarbylden.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Meitsje in nije array fan `MaybeUninit<T>`-artikels, yn in net-inisjalisearre steat.
    ///
    /// Note: yn in ferzje future Rust kin dizze metoade net nedich wurde as array letterlike syntaksis [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) tastiet.
    ///
    /// It foarbyld hjirûnder kin dan `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` brûke.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Jout in (mooglik lytsere) stikje gegevens dat eins waard lêzen
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // VEILIGHEID: In net-inisjalisearre `[MaybeUninit<_>; LEN]` is jildich.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Makket in nije `MaybeUninit<T>` oan yn ininitialisearre steat, mei it ûnthâld fol mei `0`-bytes.It hinget fan `T` ôf oft dat al foar in goede inisjalisaasje soarget.
    ///
    /// Bygelyks, `MaybeUninit<usize>::zeroed()` is inisjalisearre, mar `MaybeUninit<&'static i32>::zeroed()` is net om't referinsjes net nul moatte wêze.
    ///
    /// Tink derom dat it dropjen fan in `MaybeUninit<T>` de dropkoade fan 'T' nea neame sil.
    /// It is jo ferantwurdlikens om derfoar te soargjen dat `T` falt as it inisjalisearre wurdt.
    ///
    /// # Example
    ///
    /// Korrekt gebrûk fan dizze funksje: inisjalisearjen fan in struktuer mei nul, wêr't alle fjilden fan 'e struktuer it bitpatroan 0 as jildige wearde kinne hâlde.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Ferkeard* gebrûk fan dizze funksje: `x.zeroed().assume_init()` skilje as `0` gjin jildich bitpatroan is foar it type:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Binnen in pear meitsje wy in `NotZero` dy't gjin jildige diskriminant hat.
    /// // Dit is undefined gedrach.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // VEILIGHEID: `u.as_mut_ptr()` wiist op tawiisd ûnthâld.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Stelt de wearde fan 'e `MaybeUninit<T>` yn.
    /// Dit oerskriuwt elke foarige wearde sûnder dizze te litten, dus wês foarsichtich dit net twa kear te brûken, útsein as jo de destruktor oerslaan wolle.
    ///
    /// Foar jo gemak jout dit ek in feroarbere ferwizing nei de (no feilich inisjalisearre) ynhâld fan `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // VEILIGHEID: Wy hawwe dizze wearde krekt inisjalisearre.
        unsafe { self.assume_init_mut() }
    }

    /// Krijt in oanwizer nei de befette wearde.
    /// Lêze fan dizze oanwizer of as in referinsje feroarje is net definieare gedrach, útsein as de `MaybeUninit<T>` inisjalisearre is.
    /// Skriuwen nei ûnthâld dat dizze oanwizer (non-transitively) wiist op is undefined gedrach (útsein yn in `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Meitsje in referinsje yn 'e `MaybeUninit<T>`.Dit is goed, om't wy it inisjaliseare.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Ferkeard* gebrûk fan dizze metoade:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Wy hawwe in ferwizing makke nei in net-inisjalisearre vector!Dit is undefined gedrach.⚠️
    /// ```
    ///
    /// (Let op dat de regels om ferwizings nei uninitialisearre gegevens noch net binne finalisearre, mar oant se binne, is it oan te rieden om se te foarkommen.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` en `ManuallyDrop` binne beide `repr(transparent)`, sadat wy de oanwizer kinne goaie.
        self as *const _ as *const T
    }

    /// Krijt in feroarbere oanwizer nei de befette wearde.
    /// Lêze fan dizze oanwizer of as in referinsje feroarje is net definieare gedrach, útsein as de `MaybeUninit<T>` inisjalisearre is.
    ///
    /// # Examples
    ///
    /// Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Meitsje in referinsje yn 'e `MaybeUninit<Vec<u32>>`.
    /// // Dit is goed, om't wy it inisjaliseare.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Ferkeard* gebrûk fan dizze metoade:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Wy hawwe in ferwizing makke nei in net-inisjalisearre vector!Dit is undefined gedrach.⚠️
    /// ```
    ///
    /// (Let op dat de regels om ferwizings nei uninitialisearre gegevens noch net binne finalisearre, mar oant se binne, is it oan te rieden om se te foarkommen.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` en `ManuallyDrop` binne beide `repr(transparent)`, sadat wy de oanwizer kinne goaie.
        self as *mut _ as *mut T
    }

    /// Pakt de wearde út fan 'e `MaybeUninit<T>`-kontener.Dit is in geweldige manier om derfoar te soargjen dat de gegevens sille falle, om't de resultearjende `T` ûnderwerp is fan 'e gewoane drophannel.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat de `MaybeUninit<T>` echt yn in inisjalisearre steat is.Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket direkte undefined gedrach.
    /// De [type-level documentation][inv] befettet mear ynformaasje oer dizze initialisearjende invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Boppedat, tink derom dat de measte soarten ekstra invarianten hawwe, bûten allinich wurde beskôge as inisjalisearre op it type nivo.
    /// Bygelyks, in '1`-inisjalisearre [`Vec<T>`] wurdt as inisjalisearre beskôge (ûnder de hjoeddeistige ymplemintaasje; dit is gjin stabile garânsje), om't de iennige fereaske dy't de gearstaller derfan wit dat de gegevenswizer net-nul moat wêze.
    ///
    /// It meitsjen fan sa'n `Vec<T>` feroarsaket gjin *direkte* undefined gedrach, mar sil undefined gedrach feroarsaakje mei de measte feilige operaasjes (ynklusyf drop it).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Ferkeard* gebrûk fan dizze metoade:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` wie noch net inisjalisearre, dus dizze lêste rigel feroarsake undefined gedrach.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // VEILIGHEID: de beller moat garandearje dat `self` is inisjalisearre.
        // Dit betsjut ek dat `self` in `value`-fariant moat wêze.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lês de wearde fan 'e `MaybeUninit<T>`-kontener.De resultearjende `T` is ûnderwerp fan 'e gewoane dripbehanneling.
    ///
    /// As it mooglik is, hat it de foarkar om [`assume_init`] yn plak te brûken, wat foarkomt dat de ynhâld fan 'e `MaybeUninit<T>` dupliseart.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat de `MaybeUninit<T>` echt yn in inisjalisearre steat is.Belje dit as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach.
    /// De [type-level documentation][inv] befettet mear ynformaasje oer dizze initialisearjende invariant.
    ///
    /// Boppedat lit dit in kopy fan deselde gegevens efter yn 'e `MaybeUninit<T>`.
    /// As jo meardere kopyen fan 'e gegevens brûke (troch meardere kearen `assume_init_read` te skiljen, of earst `assume_init_read` en dan [`assume_init`] te skiljen), is it jo ferantwurdlikens om te soargjen dat dizze gegevens yndie kinne wurde dupliseare.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy`, dat wy kinne meardere kearen lêze.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // In `None`-wearde duplisearje is goed, dat wy kinne meardere kearen lêze.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Ferkeard* gebrûk fan dizze metoade:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Wy hawwe no twa eksimplaren makke fan deselde vector, wat liedt ta in dûbelfrij ⚠️ as se beide falle!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // VEILIGHEID: de beller moat garandearje dat `self` is inisjalisearre.
        // Lêze fan `self.as_ptr()` is feilich, om't `self` inisjalisearre wurde moat.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Falt de befette wearde te plak.
    ///
    /// As jo eigner binne fan 'e `MaybeUninit`, kinne jo [`assume_init`] ynstee brûke.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat de `MaybeUninit<T>` echt yn in inisjalisearre steat is.Belje dit as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach.
    ///
    /// Boppedat moatte alle ekstra invarianten fan it type `T` tefreden wêze, om't de `Drop`-ymplemintaasje fan `T` (as har leden) hjirop kin fertrouwe.
    /// Bygelyks, in '1`-inisjalisearre [`Vec<T>`] wurdt as inisjalisearre beskôge (ûnder de hjoeddeistige ymplemintaasje; dit is gjin stabile garânsje), om't de iennige fereaske dy't de gearstaller derfan wit dat de gegevenswizer net-nul moat wêze.
    ///
    /// Soargen fan sa'n `Vec<T>` sil lykwols net definieare gedrach feroarsaakje.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // VEILIGHEID: de beller moat garandearje dat `self` is inisjalisearre en
        // foldocht oan alle invarianten fan `T`.
        // De wearde op syn plak falle is feilich as dat it gefal is.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Krijt in dielde ferwizing nei de befette wearde.
    ///
    /// Dit kin nuttich wêze as wy tagong wolle ta in `MaybeUninit` dy't inisjalisearre is, mar gjin eigendom hawwe fan 'e `MaybeUninit` (foarkommen fan it brûken fan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dit skilje as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach: it is oan 'e beller om te garandearjen dat de `MaybeUninit<T>` echt yn in inisjalisearre steat is.
    ///
    ///
    /// # Examples
    ///
    /// ### Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialisearje `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // No dat bekend is dat ús `MaybeUninit<_>` is inisjalisearre, is it goed om in dielde ferwizing dernei te meitsjen:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // VEILIGHEID: `x` is inisjalisearre.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Ferkearde* gebrûken fan dizze metoade:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Wy hawwe in ferwizing makke nei in net-inisjalisearre vector!Dit is undefined gedrach.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialisearje de `MaybeUninit` mei `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Ferwizing nei in net-inisjalisearre `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // VEILIGHEID: de beller moat garandearje dat `self` is inisjalisearre.
        // Dit betsjut ek dat `self` in `value`-fariant moat wêze.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Krijt in feroarbere (unique)-ferwizing nei de befette wearde.
    ///
    /// Dit kin nuttich wêze as wy tagong wolle ta in `MaybeUninit` dy't inisjalisearre is, mar gjin eigendom hawwe fan 'e `MaybeUninit` (foarkommen fan it brûken fan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dit skilje as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach: it is oan 'e beller om te garandearjen dat de `MaybeUninit<T>` echt yn in inisjalisearre steat is.
    /// `.assume_init_mut()` kin bygelyks net brûkt wurde om in `MaybeUninit` te inisjalisearjen.
    ///
    /// # Examples
    ///
    /// ### Korrekt gebrûk fan dizze metoade:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inisjaliseart *alle* bytes fan de ynfierbuffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialisearje `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // No wite wy dat `buf` is inisjalisearre, dus wy koenen `.assume_init()` it.
    /// // Mei it brûken fan `.assume_init()` kin lykwols in `memcpy` fan 'e 2048 bytes aktivearje.
    /// // Om te befestigjen dat ús buffer is inisjalisearre sûnder it te kopiearjen, upgrade wy de `&mut MaybeUninit<[u8; 2048]>` nei in `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // VEILIGHEID: `buf` is inisjalisearre.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // No kinne wy `buf` brûke as in normale slach:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Ferkearde* gebrûken fan dizze metoade:
    ///
    /// Jo kinne `.assume_init_mut()` net brûke om in wearde te inisjalisearjen:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Wy hawwe in (mutable)-referinsje makke nei in net-inisjalisearre `bool`!
    ///     // Dit is undefined gedrach.⚠️
    /// }
    /// ```
    ///
    /// Jo kinne bygelyks net [`Read`] yn in net-inisjalisearre buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ferwizing nei uninitialisearre ûnthâld!
    ///                             // Dit is undefined gedrach.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Jo kinne ek gjin direkte fjildtoegang brûke om fjild foar fjild stadige inisjalisaasje te dwaan:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ferwizing nei uninitialisearre ûnthâld!
    ///                  // Dit is undefined gedrach.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ferwizing nei uninitialisearre ûnthâld!
    ///                  // Dit is undefined gedrach.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Wy fertrouwe op it stuit op it boppesteande ferkeard, dus wy hawwe ferwizingen nei net-inisjalisearre gegevens (bgl. Yn `libcore/fmt/float.rs`).
    // Wy moatte in definityf beslút nimme oer de regels foar stabilisaasje.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moat garandearje dat `self` is inisjalisearre.
        // Dit betsjut ek dat `self` in `value`-fariant moat wêze.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Pakket de wearden út fan in array fan `MaybeUninit`-konteners.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat alle eleminten fan' e array yn inisjalisearre steat binne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // VEILIGHEID: No feilich as wy alle eleminten inisjaliseare
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * De beller garandeart dat alle eleminten fan 'e array wurde inisjalisearre
        // * `MaybeUninit<T>` en T wurde garandearre dat se deselde opmaak hawwe
        // * MaybeUnint falt net, dus d'r binne gjin dûbel-frees En dus is de konverzje feilich
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Stel dat alle eleminten binne inisjalisearre, krij dan in stikje nei har.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat de `MaybeUninit<T>`-eleminten echt yn in inisjalisearre steat binne.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach.
    ///
    /// Sjoch [`assume_init_ref`] foar mear details en foarbylden.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // VEILIGHEID: it smiten fan in plak nei in `*const [T]` is feilich, om't de beller dat garandeart
        // `slice` wurdt inisjalisearre, en 'MaybeUninit' is garandearre dat deselde opmaak is as `T`.
        // De ferkochte oanwizer is jildich, om't it ferwiist nei ûnthâld dat eigendom is fan `slice`, dat is in referinsje en dus garandearre is jildich foar lêzen.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Stel dat alle eleminten binne inisjalisearre, krijst in feroarbere stikje foar har.
    ///
    /// # Safety
    ///
    /// It is oan 'e beller om te garandearjen dat de `MaybeUninit<T>`-eleminten echt yn in inisjalisearre steat binne.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket undefined gedrach.
    ///
    /// Sjoch [`assume_init_mut`] foar mear details en foarbylden.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // VEILIGHEID: fergelykber mei feiligensnota's foar `slice_get_ref`, mar wy hawwe in
        // mutabele referinsje dy't ek garandearre is jildich foar skriuwen.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Krijt in oanwizer nei it earste elemint fan 'e array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Krijt in feroarbere oanwizer nei it earste elemint fan 'e array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopieart de eleminten fan `src` nei `this`, en jout in feroarbere ferwizing nei de no yitalisearre ynhâld fan `this`.
    ///
    /// As `T` `Copy` net ymplementeart, brûk dan [`write_slice_cloned`]
    ///
    /// Dit is fergelykber mei [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de twa plakjes ferskillende lingtes hawwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: wy hawwe krekt alle eleminten fan len yn 'e frije kapasiteit kopieare
    /// // de earste src.len()-eleminten fan 'e vec binne no jildich.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // VEILIGHEID: &[T] en&[MaybeUninit<T>] hawwe deselde opmaak
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // VEILIGHEID: Jildige eleminten binne krekt kopieare yn `this`, sadat it wurdt ynitalisearre
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonet de eleminten fan `src` nei `this`, en bringt in feroarbere ferwizing werom nei de no yitalisearre ynhâld fan `this`.
    /// Eltse al initalisearre eleminten sille net falle.
    ///
    /// As `T` `Copy` ymplementeart, brûk dan [`write_slice`]
    ///
    /// Dit liket op [`slice::clone_from_slice`], mar lit besteande eleminten net falle.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de twa plakjes ferskillende lingtes hawwe, of as de ymplemintaasje fan `Clone` panics.
    ///
    /// As d'r in panic is, sille de al klone eleminten falle.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: wy hawwe krekt alle eleminten fan len yn 'e frije kapasiteit kloneare
    /// // de earste src.len()-eleminten fan 'e vec binne no jildich.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // yn tsjinstelling ta copy_from_slice hjit dit net clone_from_slice op 'e slice dit komt om't `MaybeUninit<T: Clone>` Clone net ymplementeart.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // VEILIGHEID: dizze rauwe plak sil allinich inisjalisearre objekten befetsje
                // dêrom is it tastien om it te fallen.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Wy moatte se eksplisyt op deselde lingte snije
        // foar grinzen kontrolearje om te wurde ferwidere, en de optimizer sil memcpy generearje foar ienfâldige gefallen (bygelyks T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // wacht is nedich b/c panic kin barre tidens in kloon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // VEILIGHEID: Jildige eleminten binne krekt yn `this` skreaun, sadat it wurdt ynitalisearre
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}