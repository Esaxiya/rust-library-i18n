//! Basisfunksjes foar omgean mei ûnthâld.
//!
//! Dizze module befettet funksjes foar it freegjen fan grutte en ôfstimming fan soarten, initialisearjen en manipulearjen fan ûnthâld.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Nim eigendom en "forgets" oer de wearde **sûnder har destruktor** út te fieren.
///
/// Eltse boarnen dy't de wearde beheart, lykas heapgeheugen as in bestânsgreep, sille foar ivich bliuwe yn in ûnberikbere steat.It garandeart lykwols net dat oanwizings nei dit ûnthâld jildich bliuwe.
///
/// * As jo ûnthâld wolle lekke, sjoch [`Box::leak`].
/// * As jo in rauwe oanwizer wolle krije foar it ûnthâld, sjoch [`Box::into_raw`].
/// * As jo in wearde goed wolle beskikke oer it útfieren fan har destruktor, sjoch [`mem::drop`].
///
/// # Safety
///
/// `forget` wurdt net markearre as `unsafe`, om't de feiligensgarânsjes fan Rust gjin garânsje befetsje dat destruktoaren altyd rinne.
/// In programma kin bygelyks in referinsjesyklus meitsje mei [`Rc`][rc], of [`process::exit`][exit] skilje om út te gean sûnder destruktors út te fieren.
/// Sadwaande feroaret `mem::forget` fan feilige koade net de feiligensgaranties fan Rust fundamenteel.
///
/// Dat sei, lekkende boarnen lykas ûnthâld as I/O-objekten is normaal net winsklik.
/// De needsaak komt op yn guon spesjale gefallen foar FFI as ûnfeilige koade, mar ek dan wurdt [`ManuallyDrop`] typysk foarkar.
///
/// Om't in wearde ferjitte is tastien, moat elke `unsafe`-koade dy't jo skriuwe dizze mooglikheid tastean.Jo kinne gjin wearde weromjaan en ferwachtsje dat de beller needsaaklik de destruktor fan 'e wearde sil rinne.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// It kanonike feilige gebrûk fan `mem::forget` is om de destruktor fan in wearde te omlizzen troch de `Drop` trait.Dit sil bygelyks in `File` lekje, ie
/// werneam de romte nommen troch de fariabele, mar slút de ûnderlizzende systeemboarne nea:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dit is nuttich as it eigendom fan 'e ûnderlizzende boarne earder waard oerdroegen oan koade bûten Rust, bygelyks troch de rûge bestânsbeskriuwing oer te stjoeren nei C-koade.
///
/// # Relaasje mei `ManuallyDrop`
///
/// Wylst `mem::forget` ek kin wurde brûkt om *ûnthâld* eigendom oer te dragen, is dit flatergefoelich.
/// [`ManuallyDrop`] moat yn plak wurde brûkt.Tink bygelyks oan dizze koade:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bouwe in `String` mei de ynhâld fan `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lekje `v` om't syn ûnthâld no beheard wurdt troch `s`
/// mem::forget(v);  // FOUT, v is ûnjildich en mei net trochjûn wurde oan in funksje
/// assert_eq!(s, "Az");
/// // `s` wurdt ymplisyt falle litten en it ûnthâld is ferdield.
/// ```
///
/// D'r binne twa problemen mei it boppesteande foarbyld:
///
/// * As mear koade waard tafoege tusken de oanlis fan `String` en de oanroppen fan `mem::forget()`, soe in panic dêryn in dûbele frije feroarsaakje, om't itselde ûnthâld wurdt behannele troch sawol `v` as `s`.
/// * Nei't `v.as_mut_ptr()` neamd is en it eigendom fan 'e gegevens oerbrocht nei `s`, is de `v`-wearde unjildich.
/// Sels as in wearde krekt is ferpleatst nei `mem::forget` (dy't it net kontroleart), hawwe guon soarten strikte easken oan har wearden dy't se unjildich meitsje as se hingje of net mear eigendom binne.
/// Unjildige wearden brûke op hokker manier dan ek, trochjaan oan of weromjaan fan funksjes, is undefined gedrach en kin de útgongspunten troch de gearstaller brekke.
///
/// Skeakelje nei `ManuallyDrop` foarkomt beide problemen:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Foardat wy `v` yn 'e rauwe dielen demontere, moatte jo derfoar soargje dat it net falt!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Demontearje no `v`.Dizze operaasjes kinne net panic, dus d'r kin gjin lek wêze.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Uteinlik bouwe in `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` wurdt ymplisyt falle litten en it ûnthâld is ferdield.
/// ```
///
/// `ManuallyDrop` befet robúst dûbel-frij, om't wy 'v''s destruktor útskeakelje foardat wy wat oars dogge.
/// `mem::forget()` lit dit net ta om't it syn argumint ferbrûkt, en twingt ús it allinich te skiljen nei alles dat wy nedich binne út `v` te heljen.
/// Sels as in panic waard yntrodusearre tusken konstruksje fan `ManuallyDrop` en it bouwen fan 'e tekenrige (wat kin net barre yn' e koade lykas werjûn), soe it resultearje yn in lek en net in dûbele fergees.
/// Mei oare wurden, `ManuallyDrop` flaters oan 'e kant fan lekken ynstee fan flaters oan' e kant fan (dûbel-) falle.
///
/// Ek `ManuallyDrop` foarkomt dat wy nei "touch" `v` moatte nei it oerdragen fan it eigendom nei `s`-de lêste stap fan ynteraksje mei `v` om it te ferwiderjen sûnder syn destruktor te rinnen wurdt folslein foarkommen.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Lykas [`forget`], mar aksepteart ek net grutte wearden.
///
/// Dizze funksje is gewoan in shim bedoeld om te ferwiderjen as de `unsized_locals`-funksje stabilisearre wurdt.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Jout de grutte fan in type yn bytes.
///
/// Mear spesifyk is dit de kompensaasje yn bytes tusken opienfolgjende eleminten yn in array mei dat artikeltype ynklusyf alignment padding.
///
/// Sa hat `[T; n]` foar elk type `T` en lingte `n` in grutte fan `n * size_of::<T>()`.
///
/// Yn 't algemien is de grutte fan in type net stabyl oer kompilaasjes, mar spesifike soarten lykas primitiven binne.
///
/// De folgjende tabel jout de grutte foar primitiven.
///
/// Soart |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karakters |4
///
/// Fierder hawwe `usize` en `isize` deselde grutte.
///
/// De soarten `*const T`, `&T`, `Box<T>`, `Option<&T>`, en `Option<Box<T>>` hawwe allegear deselde grutte.
/// As `T` grutte is, hawwe al dy soarten deselde grutte as `usize`.
///
/// De feroaring fan in oanwizer feroaret syn grutte net.As sadanich hawwe `&T` en `&mut T` deselde grutte.
/// Likegoed foar `*const T` en `* mut T`.
///
/// # Grutte fan `#[repr(C)]` items
///
/// De `C`-fertsjintwurdiging foar items hat in definieare yndieling.
/// Mei dizze yndieling is de grutte fan items ek stabyl salang't alle fjilden in stabile grutte hawwe.
///
/// ## Grutte fan Structs
///
/// Foar `structs` wurdt de grutte bepaald troch it folgjende algoritme.
///
/// Foar elk fjild yn 'e struktuer besteld troch deklaraasjebefel:
///
/// 1. Foegje de grutte fan it fjild ta.
/// 2. Rûn de hjoeddeistige grutte omheech nei it tichtstbye multipel fan 'e [alignment] fan it folgjende fjild.
///
/// Ta beslút, rûn de grutte fan 'e struktuer ôf nei it tichtste mearfâld fan syn [alignment].
/// De ôfstimming fan 'e struktuer is normaal de grutste ôfstimming fan al har fjilden;dit kin feroare wurde mei it brûken fan `repr(align(N))`.
///
/// Oars as `C` wurde strûken mei nulgrutte net oprûn oant ien byte yn grutte.
///
/// ## Grutte fan Enums
///
/// Enums dy't gjin oare gegevens hawwe dan de diskriminant hawwe deselde grutte as C enums op it platfoarm wêr't se foar binne gearstald.
///
/// ## Grutte fan Unies
///
/// De grutte fan in uny is de grutte fan har grutste fjild.
///
/// Oars as `C` wurde fakbûnen mei nulgrutte net oprûn oant ien byte yn grutte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Guon primitiven
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Guon arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointergrutte gelikensens
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` brûke.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // De grutte fan it earste fjild is 1, foegje dus 1 ta oan 'e grutte.Grutte is 1.
/// // De ôfstimming fan it twadde fjild is 2, dus foegje 1 ta oan 'e grutte foar padding.Grutte is 2.
/// // De grutte fan it twadde fjild is 2, dus foegje 2 ta oan 'e grutte.Grutte is 4.
/// // De ôfstimming fan it tredde fjild is 1, foegje dus 0 ta oan 'e grutte foar padding.Grutte is 4.
/// // De grutte fan it tredde fjild is 1, dus foegje 1 ta oan 'e grutte.Grutte is 5.
/// // Uteinlik is de útrjochting fan 'e struktuer 2 (om't de grutste opstelling ûnder har fjilden 2 is), foegje dus 1 ta oan' e grutte foar padding.
/// // Grutte is 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tupelstructs folgje deselde regels.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Tink derom dat it opnij oarderjen fan 'e fjilden de grutte kin ferleegje.
/// // Wy kinne beide paddingbytes fuortsmite troch `third` foar `second` te setten.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unygrutte is de grutte fan it grutste fjild.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Jout de grutte fan de oanwiisde wearde yn bytes.
///
/// Dit is normaal itselde as `size_of::<T>()`.
/// As `T` * lykwols gjin statysk bekende grutte hat, bgl. In stik [`[T]`][slice] as in [trait object], dan kin `size_of_val` brûkt wurde om de dynamysk bekende grutte te krijen.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: `val` is in referinsje, dus it is in jildige rauwe oanwizer
    unsafe { intrinsics::size_of_val(val) }
}

/// Jout de grutte fan de oanwiisde wearde yn bytes.
///
/// Dit is normaal itselde as `size_of::<T>()`.As `T` * lykwols gjin statysk bekende grutte hat, bgl. In stik [`[T]`][slice] as in [trait object], dan kin `size_of_val_raw` brûkt wurde om de dynamysk bekende grutte te krijen.
///
/// # Safety
///
/// Dizze funksje is allinich feilich te skiljen as de folgjende betingsten binne:
///
/// - As `T` `Sized` is, is dizze funksje altyd feilich te skiljen.
/// - As de net grutte sturt fan `T` is:
///     - in [slice], dan moat de lingte fan 'e snytail in inisjalisearre gehiel wêze, en de grutte fan' e *folsleine wearde*(dynamyske sturtlingte + foarheaksel statysk grut) moat passe yn `isize`.
///     - in [trait object], dan moat it vtabeldiel fan 'e oanwizer wize op in jildige vtabel ferwurven troch in net-grutte twang, en de grutte fan' e *folsleine wearde*(dynamyske sturtlingte + foarheaksel statysk) moat passe yn `isize`.
///
///     - in (unstable) [extern type], dan is dizze funksje altyd feilich te skiljen, mar kin panic of oars de ferkearde wearde werombringe, om't de opmaak fan it eksterne type net bekend is.
///     Dit is itselde gedrach as [`size_of_val`] op in ferwizing nei in type mei in eksterne type sturt.
///     - oars is it konservatyf net tastien dizze funksje te neamen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: de beller moat in jildige rauwe oanwizer leverje
    unsafe { intrinsics::size_of_val(val) }
}

/// Jout de [ABI]-fereaske minimale ôfstimming fan in type.
///
/// Elke ferwizing nei in wearde fan it type `T` moat in meardere fan dit getal wêze.
///
/// Dit is de ôfstimming dy't wurdt brûkt foar struktuerfjilden.It kin lytser wêze dan de foarkommende opstelling.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Jout de [ABI] fereaske minimale ôfstimming fan it type fan 'e wearde dat `val` wiist.
///
/// Elke ferwizing nei in wearde fan it type `T` moat in meardere fan dit getal wêze.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is in referinsje, dus it is in jildige rauwe oanwizer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jout de [ABI]-fereaske minimale ôfstimming fan in type.
///
/// Elke ferwizing nei in wearde fan it type `T` moat in meardere fan dit getal wêze.
///
/// Dit is de ôfstimming dy't wurdt brûkt foar struktuerfjilden.It kin lytser wêze dan de foarkommende opstelling.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Jout de [ABI] fereaske minimale ôfstimming fan it type fan 'e wearde dat `val` wiist.
///
/// Elke ferwizing nei in wearde fan it type `T` moat in meardere fan dit getal wêze.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is in referinsje, dus it is in jildige rauwe oanwizer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jout de [ABI] fereaske minimale ôfstimming fan it type fan 'e wearde dat `val` wiist.
///
/// Elke ferwizing nei in wearde fan it type `T` moat in meardere fan dit getal wêze.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Dizze funksje is allinich feilich te skiljen as de folgjende betingsten binne:
///
/// - As `T` `Sized` is, is dizze funksje altyd feilich te skiljen.
/// - As de net grutte sturt fan `T` is:
///     - in [slice], dan moat de lingte fan 'e snytail in inisjalisearre gehiel wêze, en de grutte fan' e *folsleine wearde*(dynamyske sturtlingte + foarheaksel statysk grut) moat passe yn `isize`.
///     - in [trait object], dan moat it vtabeldiel fan 'e oanwizer wize op in jildige vtabel ferwurven troch in net-grutte twang, en de grutte fan' e *folsleine wearde*(dynamyske sturtlingte + foarheaksel statysk) moat passe yn `isize`.
///
///     - in (unstable) [extern type], dan is dizze funksje altyd feilich te skiljen, mar kin panic of oars de ferkearde wearde werombringe, om't de opmaak fan it eksterne type net bekend is.
///     Dit is itselde gedrach as [`align_of_val`] op in ferwizing nei in type mei in eksterne type sturt.
///     - oars is it konservatyf net tastien dizze funksje te neamen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: de beller moat in jildige rauwe oanwizer leverje
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jout `true` werom as wearden fan it type `T` sakje.
///
/// Dit is suver in hint fan optimalisaasje, en kin konservatyf wurde ymplementeare:
/// it kin `true` werombringe foar typen dy't eins net hoege te fallen.
/// As sadanich soe `true` altyd in jildige ymplemintaasje wêze fan dizze funksje.As dizze funksje lykwols `false` werombringt, dan kinne jo der wis fan wêze dat `T` falle hat gjin side-effekt.
///
/// Ymplementaasjes op leech nivo fan dingen lykas kolleksjes, dy't har gegevens mei de hân moatte falle, moatte dizze funksje brûke om te foarkommen dat se ûnnedich besykje al har ynhâld te fallen as se wurde ferneatige.
///
/// Dit makket miskien gjin ferskil yn release builds (wêr't in loop dy't gjin side-effekten hat maklik wurdt ûntdutsen en elimineare), mar is faaks in grutte winst foar debug builds.
///
/// Tink derom dat [`drop_in_place`] dizze kontrôle al útfiert, dus as jo wurkdruk kin wurde werombrocht nei wat lyts oantal [`drop_in_place`]-oproppen, is dit net nedich te brûken.
/// Tink derom oan dat jo in stik [`drop_in_place`] kinne, en dat sil ien need_drop-kontrôle dwaan foar alle wearden.
///
/// Soarten lykas Vec dêrom gewoan `drop_in_place(&mut self[..])` sûnder `needs_drop` eksplisyt te brûken.
/// Soarten lykas [`HashMap`], oan 'e oare kant, moatte wearden ien tagelyk falle en moatte dizze API brûke.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hjir is in foarbyld fan hoe't in samling `needs_drop` brûke kin:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // drop de gegevens
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Jout de wearde werom fan type `T` fertsjintwurdige troch it byte-patroan fan nul.
///
/// Dit betsjut dat de paddingbyte yn `(u8, u16)` bygelyks net needsaaklik is nulsteld.
///
/// D'r is gjin garânsje dat in byte-patroan fan nul in jildige wearde fan wat type `T` fertsjintwurdiget.
/// Bygelyks, it byte-patroan fan nul is gjin jildige wearde foar referinsjetypes (`&T`, `&mut T`) en funksjoneart oanwizers.
/// `zeroed` brûke op sokke soarten feroarsaket direkte [undefined behavior][ub] omdat [the Rust compiler assumes][inv] dat d'r altyd in jildige wearde is yn in fariabele dy't se as initialisearre beskôget.
///
///
/// Dit hat itselde effekt as [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// It is soms nuttich foar FFI, mar moat oer it algemien foarkommen wurde.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Korrekt gebrûk fan dizze funksje: inisjalisearje in hiel getal mei nul.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Ferkeard* gebrûk fan dizze funksje: in referinsje initialisearje mei nul.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefined gedrach!
/// let _y: fn() = unsafe { mem::zeroed() }; // En op 'e nij!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // VEILIGHEID: de beller moat garandearje dat in wearde fan nul jildich is foar `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses normale ûnthâld-inisjalisaasjekontrôles fan Rust troch te dwaan as in wearde fan type `T` te produsearjen, wylst jo hielendal neat dogge.
///
/// **Dizze funksje is ôfret.** Brûk [`MaybeUninit<T>`] ynstee.
///
/// De reden foar ôfskriuwing is dat de funksje yn prinsipe net goed kin wurde brûkt: it hat itselde effekt as [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// As de [`assume_init` documentation][assume_init] ferklearret, wurdt [the Rust compiler assumes][inv] dat wearden goed inisjalisearre binne.
/// As konsekwinsje, bellen bgl
/// `mem::uninitialized::<bool>()` feroarsaket direkte undefined gedrach foar it werombringen fan in `bool` dat net perfoarst `true` of `false` is.
/// Slimmer, wier uninitialisearre ûnthâld, lykas wat hjir weromkomt, is spesjaal, om't de gearstaller wit dat it gjin fêste wearde hat.
/// Dit makket it undefined gedrach om uninitialisearre gegevens yn in fariabele te hawwen, sels as dy fariabele in heulgetaaltype hat.
/// (Tink derom dat de regels om uninitialisearre integers noch net binne finalisearre, mar oant se binne, is it oan te rieden om se te foarkommen.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // VEILIGHEID: de beller moat garandearje dat in ienheidswearde jildich is foar `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ruilje de wearden op twa feroarbere lokaasjes, sûnder ien te desinitialisearjen.
///
/// * As jo wolle ruilje mei in standert-of dummywearde, sjoch [`take`].
/// * As jo wolle wikselje mei in trochjûn wearde, weromsette de âlde wearde, sjoch [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // VEILIGHEID: de rauwe oanwizings binne makke út feilige mutabele referinsjes dy't alle foldogge
    // beheiningen op `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ferfangt `dest` mei de standertwearde fan `T`, werom de foarige `dest`-wearde.
///
/// * As jo de wearden fan twa fariabelen ferfange wolle, sjoch [`swap`].
/// * As jo wolle ferfange troch in trochjûn wearde ynstee fan de standertwearde, sjoch [`replace`].
///
/// # Examples
///
/// In ienfâldich foarbyld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` makket it mooglik eigendom te nimmen fan in struktuerfjild troch it te ferfangen troch in "empty"-wearde.
/// Sûnder `take` kinne jo problemen lykas dizze krije:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Tink derom dat `T` [`Clone`] net ympleminteart, dus it kin `self.buf` net iens klone en weromsette.
/// Mar `take` kin brûkt wurde om de orizjinele wearde fan `self.buf` fan `self` los te meitsjen, sadat it werom kin wurde:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Ferpleatst `src` yn 'e referearre `dest`, werom de foarige `dest`-wearde.
///
/// Gjin wearde falt.
///
/// * As jo de wearden fan twa fariabelen ferfange wolle, sjoch [`swap`].
/// * As jo wolle ferfange troch in standertwearde, sjoch [`take`].
///
/// # Examples
///
/// In ienfâldich foarbyld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` lit konsumpsje fan in struktuerfjild ta troch it te ferfangen troch in oare wearde.
/// Sûnder `replace` kinne jo problemen lykas dizze krije:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Tink derom dat `T` [`Clone`] net needsaaklik ymplementeart, dat wy kinne `self.buf[i]` net iens klone om de beweging te foarkommen.
/// Mar `replace` kin brûkt wurde om de orizjinele wearde fan 'e yndeks fan `self` los te meitsjen, sadat it werom kin wurde:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // VEILIGHEID: Wy lêze fan `dest`, mar skriuwe `src` dernei direkt yn,
    // sadanich dat de âlde wearde net duplisearre wurdt.
    // Neat wurdt falle litten en neat kin hjir panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Beskikt oer in wearde.
///
/// Dit docht dat troch de ymplemintaasje fan it argumint fan [`Drop`][drop] te neamen.
///
/// Dit docht effektyf neat foar typen dy't `Copy` ymplementearje, bgl
/// integers.
/// Sokke wearden wurde kopieare en _then_ ferpleatst nei de funksje, sadat de wearde oanhâldt nei dizze funksje-oprop.
///
///
/// Dizze funksje is net magysk;it wurdt letterlik definieare as
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Om't `_x` yn 'e funksje wurdt ferpleatst, wurdt it automatysk falle foardat de funksje weromkomt.
///
/// [drop]: Drop
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // drop de vector eksplisyt
/// ```
///
/// Sûnt [`RefCell`] de lienregels hanthavenet by runtime, kin `drop` in [`RefCell`]-liening frijlitte:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ferlitte de mutabele liening op dit slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integers en oare soarten dy't [`Copy`] ymplementearje, wurde net beynfloede troch `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // in kopy fan `x` wurdt ferpleatst en falle litten
/// drop(y); // in kopy fan `y` wurdt ferpleatst en falle litten
///
/// println!("x: {}, y: {}", x, y.0); // Noch beskikber
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Ynterpreteart `src` as type `&U`, en lêst dan `src` sûnder de befette wearde te ferpleatsen.
///
/// Dizze funksje sil ûnfeilich oannimme dat de oanwizer `src` jildich is foar [`size_of::<U>`][size_of]-bytes troch `&T` nei `&U` te transmutearjen en dan de `&U` te lêzen (útsein dat dit wurdt dien op in manier dy't korrekt is, sels as `&U` strangere oanpassingseasken stelt dan `&T`).
/// It sil ek in kopy fan 'e befette wearde ûnfeilich meitsje ynstee fan `src` te ferpleatsen.
///
/// It is gjin kompilearfout as `T` en `U` ferskillende maten hawwe, mar it wurdt sterk oanmoedige dizze funksje allinich op te roppen wêr't `T` en `U` deselde grutte hawwe.Dizze funksje aktivearet [undefined behavior][ub] as `U` grutter is dan `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopiearje de gegevens fan 'foo_array' en behannelje se as in 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Wizigje de kopieare gegevens
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // De ynhâld fan 'foo_array' soe net moatte feroare wêze
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // As U in hegere ôfstammingseasken hat, kin src miskien net passend útrjochte wurde.
    if align_of::<U>() > align_of::<T>() {
        // VEILIGHEID: `src` is in referinsje dy't garandearre jildich is foar lêzen.
        // De beller moat garandearje dat de wirklike transmutaasje feilich is.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // VEILIGHEID: `src` is in referinsje dy't garandearre jildich is foar lêzen.
        // Wy hawwe gewoan kontroleare dat `src as *const U` goed útrjochte wie.
        // De beller moat garandearje dat de wirklike transmutaasje feilich is.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaque type dat de diskriminant fan in enum fertsjintwurdiget.
///
/// Sjoch de [`discriminant`]-funksje yn dizze module foar mear ynformaasje.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Dizze trait-ymplementaasjes kinne net ûntliend wurde, om't wy gjin grinzen wolle op T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Jout in wearde dy't unyk de enum-fariant yn `v` identifiseart.
///
/// As `T` gjin enum is, sil it skiljen fan dizze funksje net resultearje yn undefined gedrach, mar de weromwearde is net oantsjutte.
///
///
/// # Stability
///
/// De diskriminant fan in enum-fariant kin feroarje as de definysje fan enum feroaret.
/// In diskriminant fan guon fariaasjes sil net feroarje tusken kompilaasjes mei deselde kompilator.
///
/// # Examples
///
/// Dit kin brûkt wurde om enums te fergelykjen dy't gegevens drage, wylst de werklike gegevens negeare:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Jout it oantal farianten yn it enumtype `T`.
///
/// As `T` gjin enum is, sil it skiljen fan dizze funksje net resultearje yn undefined gedrach, mar de weromwearde is net oantsjutte.
/// Likegoed, as `T` in enum is mei mear farianten dan `usize::MAX`, is de returnwearde net oantsjutte.
/// Unbewenne farianten sille wurde teld.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}