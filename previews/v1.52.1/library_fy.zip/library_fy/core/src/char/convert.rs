//! Character bekearing.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konverteart in `u32` nei in `char`.
///
/// Tink derom dat alle [`char`] s jildich [`u32`] s binne, en mei ien kinne wurde getten
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// It omkearde is lykwols net wier: net alle jildige [`u32`] s binne jildich [`char`] s.
/// `from_u32()` sil `None` weromjaan as de ynput gjin jildige wearde is foar in [`char`].
///
/// Sjoch [`from_u32_unchecked`] foar in ûnfeilige ferzje fan dizze funksje dy't dizze kontrôles negeart.
///
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` weromkomme as de ynput gjin jildige [`char`] is:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konverteart in `u32` nei in `char`, en negeart de jildigens.
///
/// Tink derom dat alle [`char`] s jildich [`u32`] s binne, en mei ien kinne wurde getten
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// It omkearde is lykwols net wier: net alle jildige [`u32`] s binne jildich [`char`] s.
/// `from_u32_unchecked()` sil dit negearje, en blyn nei [`char`] smite, mooglik in unjildige oanmeitsje.
///
///
/// # Safety
///
/// Dizze funksje is ûnfeilich, om't it unjildige `char`-wearden kin konstruearje.
///
/// Foar in feilige ferzje fan dizze funksje, sjoch de [`from_u32`]-funksje.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // VEILIGHEID: de beller moat garandearje dat `i` in jildige karwearde is.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Konverteart in [`char`] yn in [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Konverteart in [`char`] yn in [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // De kar wurdt getten nei de wearde fan it koadepunt, dan wurdt nul ferlingd nei 64 bit.
        // Sjoch [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Konverteart in [`char`] yn in [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // De kar wurdt getten nei de wearde fan it koadepunt, dan nul ferlingd nei 128 bit.
        // Sjoch [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapt in byte yn 0x00 ..=0xFF nei in `char` wêrfan it koadepunt deselde wearde hat, yn U + 0000 ..=U + 00FF.
///
/// Unicode is sa ûntwurpen dat dit bytes effektyf dekodeart mei de karakterkodearring dy't IANA ISO-8859-1 neamt.
/// Dizze kodearring is kompatibel mei ASCII.
///
/// Tink derom dat dit oars is as ISO/IEC 8859-1 aka
/// ISO 8859-1 (mei ien keppelstreekje minder), wat wat "blanks", byte-wearden efterlit dy't net oan ien karakter binne tawiisd.
/// ISO-8859-1 (de IANA-ien) wijt se oan 'e C0-en C1-kontrôlekoades ta.
///
/// Tink derom dat dit *ek* oars is as Windows-1252 aka
/// koadepagina 1252, dat is in superset ISO/IEC 8859-1 dat guon (net allegear!) blanken tawiist oan punktuaasje en ferskate Latynske karakters.
///
/// Om dingen fierder te ferwikseljen binne [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` en `windows-1252` allegear aliassen foar in superset fan Windows-1252 dy't de oerbleaune blanken follet mei oerienkommende C0-en C1-kontrôlekoades.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Konverteart in [`u8`] yn in [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// In flater dy't kin wurde weromjûn by it ûntlêsten fan in kar.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // VEILIGHEID: kontroleare dat it in legale unicode-wearde is
            Ok(unsafe { transmute(i) })
        }
    }
}

/// It flatertype kaam werom as in konverzje fan u32 nei char mislearret.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Konverteart in sifer yn 'e opjûne radix nei in `char`.
///
/// In 'radix' wurdt hjir soms ek in 'base' neamd.
/// In radiks fan twa jout in binair getal oan, in radiks fan tsien, desimaal en in radiks fan sechtjin, heksadesimaal, om wat mienskiplike wearden te jaan.
///
/// Willekeurige radizen wurde stipe.
///
/// `from_digit()` sil `None` weromjaan as de ynput gjin sifer is yn 'e opjûne radix.
///
/// # Panics
///
/// Panics as in radix grutter dan 36 wurdt jûn.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desimaal 11 is in inkeld sifer yn basis 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` werombringe as de ynfier gjin sifer is:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Trochjaan fan in grutte radix, wêrtroch in panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}