//! Utilities foar opmaak en printen fan snaren.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Mooglike opstellingen weromjûn troch `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Oantsjutting dat de ynhâld loftsrjochte moat wêze.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Oantsjutting dat de ynhâld rjochtsútrjochte moat wêze.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Oantsjutting dat de ynhâld sintraal moat wêze.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// It type is weromjûn troch formatteringsmetoaden.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// It flatertype dat weromkomt fan it opmaak fan in berjocht yn in stream.
///
/// Dit type stipet gjin oerdracht fan in oare flater dan dat der in flater barde.
/// Elke ekstra ynformaasje moat wurde regele om te wurde oerbrocht op oare manieren.
///
/// In wichtich ding om te ûnthâlden is dat it type `fmt::Error` net betize wurde moat mei [`std::io::Error`] of [`std::error::Error`], dat jo miskien ek hawwe yn omfang.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// In trait foar skriuwen of opmaak yn buffers as streams dy't Unicode akseptearje.
///
/// Dizze trait aksepteart allinich UTF-8-kodearre gegevens en is net [flushable].
/// As jo allinich Unicode akseptearje wolle en jo gjin spoeling nedich binne, moatte jo dizze trait ymplementearje;
/// oars moatte jo [`std::io::Write`] útfiere.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Skriuwt in tekenrige yn dizze skriuwer, werom as it skriuwen slagge.
    ///
    /// Dizze metoade kin allinich slagje as it heule tekenrige suksesfol is skreaun, en dizze metoade komt net werom foardat alle gegevens binne skreaun of as der in flater optreedt.
    ///
    ///
    /// # Errors
    ///
    /// Dizze funksje sil in eksimplaar fan [`Error`] by flater werombringe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Skriuwt in [`char`] yn dizze skriuwer, werom as it skriuwen slagge.
    ///
    /// In inkele [`char`] kin wurde kodearre as mear dan ien byte.
    /// Dizze metoade kin allinich slagje as de heule byte folchoarder suksesfol is skreaun, en dizze metoade komt net werom foardat alle gegevens binne skreaun of as der in flater optreedt.
    ///
    ///
    /// # Errors
    ///
    /// Dizze funksje sil in eksimplaar fan [`Error`] by flater werombringe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Lijm foar gebrûk fan 'e [`write!`]-makro mei ymplementators fan dizze trait.
    ///
    /// Dizze metoade moat oer it algemien net mei de hân wurde oproppen, mar leaver fia de [`write!`]-makro sels.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Konfiguraasje foar opmaak.
///
/// In `Formatter` fertsjintwurdiget ferskate opsjes yn ferbân mei opmaak.
/// Brûkers konstruearje `Formatter`s net direkt;in feroarbere ferwizing nei ien wurdt trochjûn oan 'e `fmt`-metoade fan alle opmaak fan traits, lykas [`Debug`] en [`Display`].
///
///
/// Om ynteraksje mei in `Formatter`, skilje jo ferskate metoaden om de ferskate opsjes te feroarjen yn ferbân mei opmaak.
/// Sjoch foar foarbylden hjirûnder de dokumintaasje fan 'e metoaden definieare op `Formatter`.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argumint is yn essinsje in optimalisearre diels tapaste opmaakfunksje, lykweardich oan `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Dizze struktuer fertsjintwurdiget de generike "argument" dy't wurdt nommen troch de Xprintf-famylje fan funksjes.It befettet in funksje om de opjûne wearde op te meitsjen.
/// Op kompilaasjetiid wurdt der foar soarge dat de funksje en de wearde de juste soarten hawwe, en dan wurdt dizze struct brûkt om arguminten foar ien type te kanonikalisearjen.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Dit garandeart in ienige stabile wearde foar de oanwizer fan funksjes assosjeare mei indices/counts yn de opmaakynfrastruktuer.
//
// Tink derom dat in funksje as sadanich definieare net korrekt soe wêze, om't funksjes altyd unnamed_addr wurde tagged mei de aktuele ferleging nei LLVM IR, sadat har adres net wichtich wurdt beskôge foar LLVM en as sadanich koe de cast as_usize ferkeard kompileare wêze.
//
// Yn 'e praktyk neame wy no as_usize op net-gebrûk mei gegevens (as saak fan statyske generaasje fan' e opmaakarguminten), dus dit is gewoan in ekstra kontrôle.
//
// Wy wolle foaral soargje dat de funksjewizer by `USIZE_MARKER` in adres hat dat *allinich* oerienkomt mei funksjes dy't ek `&usize` as earste argumint nimme.
// De read_volatile soarget hjirfoar dat wy in usize feilich kinne klearmeitsje fan 'e trochjûn referinsje en dat dit adres net wiist op in net-usize nimmefunksje.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // VEILIGHEID: ptr is in referinsje
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // VEILIGHEID: `mem::transmute(x)` is feilich omdat
        //     1. `&'b T` hâldt it libben dat it ûntstie mei `'b` (om gjin unbeheind libben te hawwen)
        //     2.
        //     `&'b T` en `&'b Opaque` hawwe deselde ûnthâldopmaak (as `T` `Sized` is, sa't it hjir is) `mem::transmute(f)` is feilich, om't `fn(&T, &mut Formatter<'_>) -> Result` en `fn(&Opaque, &mut Formatter<'_>) -> Result` deselde ABI hawwe (sa lang as `T` `Sized` is)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // VEILIGHEID: It `formatter`-fjild is allinich ynsteld op USIZE_MARKER as
            // de wearde is in gebrûk, dus dit is feilich
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// flaggen beskikber yn it v1-formaat fan format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// By it brûken fan de format_args! () Makro wurdt dizze funksje brûkt om de Argumintestruktuer te generearjen.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Dizze funksje wurdt brûkt om net-standert opmaakparameters op te jaan.
    /// De `pieces`-array moat teminsten sa lang wêze as `fmt` om in jildige Argumintestruktuer te bouwen.
    /// Ek elke `Count` binnen `fmt` dat `CountIsParam` of `CountIsNextParam` is, moat wize op in argumint dat is makke mei `argumentusize`.
    ///
    /// As jo dit net dogge, feroarsaket it lykwols net ûnfeiligens, mar sil unjildich negearje.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Skat de lingte fan 'e opmakke tekst.
    ///
    /// Dit is bedoeld om te brûken foar it ynstellen fan earste `String`-kapasiteit by it brûken fan `format!`.
    /// Note: dit is noch de ûnderste noch boppegrins.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // As de opmaakstring begjint mei in argumint, pleatst dan neat foarôf, útsein as de lingte fan stikken wichtich is.
            //
            //
            0
        } else {
            // D'r binne wat arguminten, dus elke ekstra druk sil de tekenrige opnij tawize.
            //
            // Om dat te foarkommen, binne wy "pre-doubling" de kapasiteit hjir.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Dizze struktuer fertsjintwurdiget in feilich foarôf kompileare ferzje fan in opmaakstring en har arguminten.
/// Dit kin net wurde generearre by runtime, om't it net feilich kin wurde dien, dus wurde gjin konstrukteurs jûn en de fjilden binne privee om wiziging te foarkommen.
///
///
/// De [`format_args!`]-makro sil feilich in eksimplaar meitsje fan dizze struktuer.
/// De makro valideart de opmaakstring by kompilearjen, sadat gebrûk fan 'e funksjes [`write()`] en [`format()`] feilich kinne wurde útfierd.
///
/// Jo kinne de `Arguments<'a>` brûke dat [`format_args!`] weromkomt yn `Debug`-en `Display`-konteksten lykas hjirûnder te sjen.
/// It foarbyld lit ek sjen dat `Debug`-en `Display`-formaat op itselde ding: de ynterpolearre opmaakstring yn `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Formaat snaarstikken om te drukken.
    pieces: &'a [&'static str],

    // Pleatshâlder specs, as `None` as alle specs standert binne (lykas yn "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dynamyske arguminten foar ynterpolaasje, wurde ferweve mei stringstikken.
    // (Elk argumint wurdt foarôfgien troch in tekenrige.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Krij de opmakke tekenrige, as dizze gjin arguminten hat om te wurde opmakke.
    ///
    /// Dit kin brûkt wurde om allocaasjes yn 't triviale gefal te foarkommen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` moat de útfier opmakke yn in kontekst-rjochte, debuggen kontekst.
///
/// Oer it algemien moatte jo gewoan `derive` in `Debug`-ymplemintaasje.
///
/// Wannear't brûkt wurdt mei de spesifike spesifikaasje `#?` foar alternatyf, is de útfier aardich-printe.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// Dizze trait kin brûkt wurde mei `#[derive]` as alle fjilden `Debug` ymplementearje.
/// As 'ôfliede' d foar structs, sil it de namme fan 'e `struct` brûke, dan `{`, dan in komma-skieden list fan' e namme fan elk fjild en `Debug`-wearde, dan `}`.
/// Foar `enum`s sil it de namme fan 'e fariant brûke en, as fan tapassing, `(`, dan de `Debug`-wearden fan' e fjilden, dan `)`.
///
/// # Stability
///
/// Ivedflaat `Debug`-formaten binne net stabyl, en kinne sa feroarje mei future Rust-ferzjes.
/// Derneist binne `Debug`-ymplementaasjes fan soarten levere troch de standertbibleteek (`libstd`, `libcore`, `liballoc`, ensfh.) Net stabyl, en kinne ek feroarje mei future Rust-ferzjes.
///
///
/// # Examples
///
/// Untfange fan in ymplemintaasje:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manuell ymplementearje:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// D'r binne in oantal helpmetoaden op 'e [`Formatter`]-struktuer om jo te helpen mei manuele ymplementaasjes, lykas [`debug_struct`].
///
/// `Debug` ymplementaasjes mei `derive` as de debugbouwer API op [`Formatter`] stypje moai printsjen mei de alternative flagge: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Pretty-printing mei `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Formateert de wearde mei de opjûne formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Aparte module om de makro `Debug` fan prelude opnij te eksportearjen sûnder de trait `Debug`.
pub(crate) mod macros {
    /// Meitsje makro dy't in ympl genereart fan 'e trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Formaat trait foar in leech formaat, `{}`.
///
/// `Display` liket op [`Debug`], mar `Display` is foar útfier foar brûkers, en kin dus net ôflaat wurde.
///
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Formateert de wearde mei de opjûne formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// De `Octal` trait moat de útfier opmeitsje as in getal yn base-8.
///
/// Foar primitive ûndertekene integers (`i8` oant `i128`, en `isize`) wurde negative wearden opmakke as de komplementfertsjintwurdiging fan 'e twa.
///
///
/// De alternative flagge, `#`, foeget in `0o` ta foar de útfier.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `i32`:
///
/// ```
/// let x = 42; // 42 is '52' yn oktaal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // delegearje nei de ymplemintaasje fan i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// De `Binary` trait moat de útfier as in getal yn binêre formearje.
///
/// Foar primitive ûndertekene integers ([`i8`] oant [`i128`], en [`isize`]) wurde negative wearden opmakke as de komplementfertsjintwurdiging fan 'e twa.
///
///
/// De alternative flagge, `#`, foeget in `0b` ta foar de útfier.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei [`i32`]:
///
/// ```
/// let x = 42; // 42 is '101010' yn binêre
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // delegearje nei de ymplemintaasje fan i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// De `LowerHex` trait moat de útfier opmeitsje as in getal yn heksadesimaal, mei `a` oant `f` yn lytse letters.
///
/// Foar primitive ûndertekene integers (`i8` oant `i128`, en `isize`) wurde negative wearden opmakke as de komplementfertsjintwurdiging fan 'e twa.
///
///
/// De alternative flagge, `#`, foeget in `0x` ta foar de útfier.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `i32`:
///
/// ```
/// let x = 42; // 42 is '2a' yn heks
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // delegearje nei de ymplemintaasje fan i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// De `UpperHex` trait moat de útfier opmeitsje as in getal yn heksadesimaal, mei `A` oant `F` yn haadletter.
///
/// Foar primitive ûndertekene integers (`i8` oant `i128`, en `isize`) wurde negative wearden opmakke as de komplementfertsjintwurdiging fan 'e twa.
///
///
/// De alternative flagge, `#`, foeget in `0x` ta foar de útfier.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `i32`:
///
/// ```
/// let x = 42; // 42 is '2A' yn heks
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // delegearje nei de ymplemintaasje fan i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// De `Pointer` trait moat de útfier opmakke as in ûnthâldlokaasje.
/// Dit wurdt normaal presinteare as heksadesimaal.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // dit produseart sokssawat as '0x7f06092ac6d0'
/// ```
///
/// `Pointer` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // brûk `as` om te konvertearjen nei in `*const T`, dy't Pointer ymplementeart, dy't wy kinne brûke
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// De `LowerExp` trait moat syn útfier yn wittenskiplike notaasje opmeitsje mei in lytse `e`.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `f64`:
///
/// ```
/// let x = 42.0; // 42.0 is '4.2e1' yn wittenskiplike notaasje
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delegearje nei de útfiering fan f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// De `UpperExp` trait moat de útfier yn wittenskiplike notaasje formearje mei in haadletter `E`.
///
/// Sjoch [the module-level documentation][module] foar mear ynformaasje oer formateurs.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis gebrûk mei `f64`:
///
/// ```
/// let x = 42.0; // 42.0 is '4.2E1' yn wittenskiplike notaasje
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp` ymplementearje op in type:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delegearje nei de útfiering fan f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Formateert de wearde mei de opjûne formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// De `write`-funksje nimt in útfierstream, en in `Arguments`-struktuer dy't kin wurde kompileare mei de `format_args!`-makro.
///
///
/// De arguminten wurde neffens de oantsjutte opmaakstring opmakke yn 'e levere stream.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Tink derom dat it brûken fan [`write!`] foarkar wêze kin.Foarbyld:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Wy kinne standert opmaakparameters brûke foar alle arguminten.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Elke spesifikaasje hat in oerienkommende argumint dat wurdt foarôfgien troch in tekenrige.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // VEILIGHEID: arg en args.args komme út deselde arguminten,
                // dy't garandeart dat de yndeksen altyd binnen grinzen binne.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // D'r kin mar ien efterlizzend snaarstik oer wêze.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // VEILIGHEID: arg en args komme út deselde arguminten,
    // dy't garandeart dat de yndeksen altyd binnen grinzen binne.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Pak it juste argumint út
    debug_assert!(arg.position < args.len());
    // VEILIGHEID: arg en args komme út deselde arguminten,
    // dy't garandeart dat syn yndeks altyd binnen grinzen leit.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Dan eins wat drukke
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // VEILIGHEID: cnt en args komme út deselde arguminten,
            // dy't dizze yndeks garandeart is altyd binnen de grinzen.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding nei it ein fan wat.Weromjûn troch `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Skriuw dizze post padding.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Wy wolle dit feroarje
            buf: wrap(self.buf),

            // En bewarje dizze
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Helpermetoaden brûkt foar it paddjen en ferwurkjen fan opmaakarguminten dy't alle opmaak fan traits kin brûke.
    //

    /// Fiert de juste padding út foar in hiel getal dat al is útjûn yn in str.
    /// De str moat *net* it teken foar it heule getal befetsje, dat sil wurde tafoege troch dizze metoade.
    ///
    /// # Arguments
    ///
    /// * is_net-negatyf, of it orizjinele heule getal posityf as nul wie.
    /// * foarheaksel, as it '#'-karakter (Alternate) wurdt oanbean, is dit it foarheaksel om foar it getal te setten.
    ///
    /// * buf, de byte-array wêrop it getal is opmakke
    ///
    /// Dizze funksje sil korrek rekken hâlde mei de levere flaggen en ek de minimale breedte.
    /// It sil gjin presyzje rekkenje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Wy moatte "-" fuortsmite fan 'e nûmerútfier.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Skriuwt it teken as it bestiet, en dan it foarheaksel as it is oanfrege
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // It `width`-fjild is op dit punt mear in `min-width`-parameter.
        match self.width {
            // As d'r gjin easken foar minimale lingte binne, kinne wy gewoan de bytes skriuwe.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Kontrolearje as wy oer de minimale breedte binne, as dat sa is, kinne wy ek gewoan de bytes skriuwe.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // It teken en foarheaksel giet foar it padding as it ynfollingsteken nul is
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Oars giet it teken en foarheaksel nei de padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Dizze funksje nimt in tekenrige en stjoert it út nei de ynterne buffer nei it tapassen fan de oantsjutte opmaakflaggen.
    /// De flaggen erkend foar generike snaren binne:
    ///
    /// * breedte, de minimale breedte fan wat te emitearjen
    /// * fill/align - wat te emitearjen en wêr't it út te stjoeren as de oanbeane snaar padded wurde moat
    /// * presyzje, de maksimale lingte om út te stjoeren, de tekenrige wurdt ôfkapt as it langer is dan dizze lingte
    ///
    /// Dizze funksje negeart de `flag`-parameters.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Soargje derfoar dat d'r in rap paad fan foaren is
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // It `precision`-fjild kin ynterpretearre wurde as in `max-width` foar de tekenrige dy't wurdt opmakke.
        //
        let s = if let Some(max) = self.precision {
            // As ús string langer is as de presyzje, dan moatte wy trunkaasje hawwe.
            // Oare flaggen lykas `fill`, `width` en `align` moatte lykwols as altyd hannelje.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM hjir kin net bewize dat `..i` net panic `&s[..i]` sil, mar wy witte dat it panic net kin.
                // Brûk `get` + `unwrap_or` om `unsafe` te foarkommen en stjoer hjir oars gjin panic-relatearre koade út.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // It `width`-fjild is op dit punt mear in `min-width`-parameter.
        match self.width {
            // As wy ûnder de maksimale lingte binne, en d'r binne gjin minimumlange easken, dan kinne wy de snaar gewoan útstjoere
            //
            None => self.buf.write_str(s),
            // As wy ûnder de maksimale breedte binne, kontrolearje dan as wy oer de minimale breedte binne, as dat dan is it sa maklik as gewoan de tekenrige útstjoere.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // As wy sawol ûnder de maksimale as de minimale breedte binne, folje dan de minimale breedte yn mei de oantsjutte tekenrige + wat oanpassing.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Skriuw de pre-padding en retourneer de unwritten post-padding.
    /// Bellers binne ferantwurdlik foar it garandearjen fan post-padding wurdt skreaun nei it ding dat wurdt padded.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Nimt de opmakke dielen en past de padding ta.
    /// Giet derfan út dat de beller de ûnderdielen al mei fereaske presyzje hat werjûn, sadat `self.precision` kin wurde negeare.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // foar de tekenbewuste nul padding, jouwe wy it teken earst oan en gedrage ús as hiene wy fan it begjin ôf gjin teken.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // in teken giet altyd earst
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ferwiderje it teken fan 'e opmakke dielen
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // oerbleaune dielen geane troch it gewoane paddingproses.
            let len = formatted.len();
            let ret = if width <= len {
                // gjin padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // dit is it algemiene gefal en wy nimme in fluchtoets
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // VEILIGHEID: Dit wurdt brûkt foar `flt2dec::Part::Num` en `flt2dec::Part::Copy`.
            // It is feilich te brûken foar `flt2dec::Part::Num`, om't elke kar `c` tusken `b'0'` en `b'9'` is, wat betsjut dat `s` jildich UTF-8 is.
            // It is ek wierskynlik feilich yn 'e praktyk om te brûken foar `flt2dec::Part::Copy(buf)`, om't `buf` gewoan ASCII wêze moat, mar it is mooglik dat immen in minne wearde foar `buf` yn `flt2dec::to_shortest_str` trochjout, om't it in iepenbiere funksje is.
            //
            // FIXME: Bepale oft dit kin resultearje yn UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 nullen
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Skriuwt wat gegevens nei de ûnderlizzende buffer befette yn dizze formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Dit is lykweardich oan:
    ///         // skriuwe! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Skriuwt wat opmakke ynformaasje yn dit eksimplaar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Flaggen foar opmaak
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Karakter brûkt as 'fill' wannear't d'r útrjochting is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Wy sette rjochtsôf mei ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flagge oanjaan hokker foarm fan oanpassing waard frege.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Opsjoneel oantsjutte heule getalbreedte dat de útfier wêze moat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // As wy in breedte krigen, brûke wy it
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Oars dogge wy neat spesjaals
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Opsjoneel oantsjutte presyzje foar numerike soarten.
    /// As alternatyf de maksimale breedte foar tekenrige typen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // As wy in presyzje krigen, brûke wy it.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Oars binne wy standert op 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Bepaalt as de `+`-flagge waard oantsjutte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Bepaalt as de `-`-flagge waard oantsjutte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Jo wolle in minteken?Hawwe ien!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Bepaalt as de `#`-flagge waard oantsjutte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Bepaalt as de `0`-flagge waard oantsjutte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Wy negearje de opsjes fan de formatter.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Beslute hokker iepenbiere API wy wolle foar dizze twa flaggen.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Makket in [`DebugStruct`]-bouwer ûntwurpen om te helpen by it meitsjen fan [`fmt::Debug`]-ymplementaasjes foar structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Makket in `DebugTuple`-bouwer ûntwurpen om te helpen by oanmeitsjen fan `fmt::Debug`-ymplementaasjes foar tupelstrucken.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Makket in `DebugList`-bouwer ûntwurpen om te helpen by it meitsjen fan `fmt::Debug`-ymplementaasjes foar list-like struktueren.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Makket in `DebugSet`-bouwer ûntwurpen om te helpen by it meitsjen fan `fmt::Debug`-ymplementaasjes foar set-like struktueren.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Yn dit kompleksere foarbyld brûke wy [`format_args!`] en `.debug_set()` om in list mei matchearms te bouwen:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Makket in `DebugMap`-bouwer ûntwurpen om te helpen by it meitsjen fan `fmt::Debug`-ymplementaasjes foar map-like struktueren.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Ymplemintaasjes fan de kearnopmaak fan traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // As kar moat ûntkomme, spielje jo efterstân oant no ta en skriuwe, oars oerslaan
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // De alternative flagge wurdt al behannele troch LowerHex as spesjaal-it jout oan of it foarôfgeand wêze moat oan 0x.
        // Wy brûke it om út te wurkjen om al dan net te ferlingjen, en sette it dan sûnder betingst yn om it foarheaksel te krijen.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Ymplemintaasje fan Display/Debug foar ferskate kearntypen

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // De RefCell is mutabel liend, sadat wy hjir net kinne sjen nei de wearde.
                // Toan ynstee in plakhâlder.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// As jo ferwachte dat testen hjir soene wêze, sjoch dan yn plak nei it core/tests/fmt.rs-bestân, it is in soad makliker dan hjir alle rt::Piece-struktueren oan te meitsjen.
//
// D'r binne ek tests yn 'e allocaasje crate, foar dyjingen dy't allocaasjes nedich binne.