//! Dit is in ynterne module brûkt troch de ifmt!runtime.Dizze struktueren wurde útstjoerd nei statyske arrays foar it kompilearjen fan formaatstrings foar de tiid.
//!
//! Dizze definysjes binne fergelykber mei har `ct`-ekwivalinten, mar ferskille yn 't sin dat dizze statysk kinne wurde tawiisd en binne wat optimisearre foar de runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mooglike oanpassingen dy't kinne wurde oanfrege as ûnderdiel fan in opmaakrjochtline.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Oantsjutting dat de ynhâld loftsrjochte moat wêze.
    Left,
    /// Oantsjutting dat de ynhâld rjochtsútrjochte moat wêze.
    Right,
    /// Oantsjutting dat de ynhâld sintraal moat wêze.
    Center,
    /// Gjin ôfstimming waard frege.
    Unknown,
}

/// Brûkt troch [width](https://doc.rust-lang.org/std/fmt/#width)-en [precision](https://doc.rust-lang.org/std/fmt/#precision)-spesifikers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Opjûn mei in letterlik getal, bewarret de wearde
    Is(usize),
    /// Spesifisearre mei `$`-en `*`-syntaksis, bewarret de yndeks yn `args`
    Param(usize),
    /// Net oantsjutte
    Implied,
}