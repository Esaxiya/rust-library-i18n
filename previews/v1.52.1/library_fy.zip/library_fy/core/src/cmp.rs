//! Funksjonaliteit foar bestellen en fergeliking.
//!
//! Dizze module befettet ferskate ark foar it bestellen en fergelykjen fan wearden.Gearfetsjend:
//!
//! * [`Eq`] en [`PartialEq`] binne traits wêrmei jo respektivelik totale en parsjele gelikensens tusken wearden kinne definiearje.
//! Ymplemintearjen oerbelastet de `==`-en `!=`-operators.
//! * [`Ord`] en [`PartialOrd`] binne traits wêrmei jo respektivelik totale en parsjele oarders tusken wearden kinne definiearje.
//!
//! Ymplemintearjen oerbelastet de `<`-, `<=`-, `>`-en `>=`-operators.
//! * [`Ordering`] is in enum weromjûn troch de haadfunksjes fan [`Ord`] en [`PartialOrd`], en beskriuwt in bestelling.
//! * [`Reverse`] is in struktuer wêrmei jo in oardering maklik keare kinne.
//! * [`max`] en [`min`] binne funksjes dy't opbouwe fan [`Ord`] en kinne jo it maksimum as minimum fan twa wearden fine.
//!
//! Foar mear details, sjoch de oanbelangjende dokumintaasje fan elk item yn 'e list.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait foar fergeliking fan gelikensens dy't [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) binne.
///
/// Dizze trait soarget foar parsjele gelikensens, foar typen dy't gjin folsleine ekwivalensjerelaasje hawwe.
/// Bygelyks yn nûmers mei driuwende punten `NaN != NaN`, sa driuwende puntstypen ymplementearje `PartialEq` mar net [`trait@Eq`].
///
/// Formeel moat de gelikensens wêze (foar alle `a`, `b`, `c` fan type `A`, `B`, `C`):
///
/// - **Symmetrysk**: as `A: PartialEq<B>` en `B: PartialEq<A>`, dan betsjuttet **`a==b`` b==a`**;en
///
/// - **Transitive**: as `A: PartialEq<B>` en `B: PartialEq<C>` en `A:
///   PartialEq<C>`, dan **` a==b`en `b == c` ympliseart`a==c`**.
///
/// Tink derom dat de `B: PartialEq<A>` (symmetric)-en `A: PartialEq<C>` (transitive)-ymplen net twongen binne te bestean, mar dizze easken jilde as se besteane.
///
/// ## Derivable
///
/// Dizze trait kin brûkt wurde mei `#[derive]`.As 'ôflaat' d op structs, binne twa gefallen gelyk as alle fjilden gelyk binne, en net gelyk as alle fjilden net gelyk binne.As 'ôflaat' d op enums, is elke fariant gelyk oan himsels en net gelyk oan de oare farianten.
///
/// ## Hoe kin ik `PartialEq` útfiere?
///
/// `PartialEq` fereasket allinich dat de [`eq`]-metoade wurdt ymplementearre;[`ne`] is standert definieare yn termen.Elke hantlieding fan [`ne`]*moat* de regel respektearje dat [`eq`] in strikte omkearing fan [`ne`] is;dat is `!(a == b)` as en allinich as `a != b`.
///
/// Ymplementaasjes fan `PartialEq`, [`PartialOrd`] en [`Ord`]*moatte* mei-inoar iens wêze.It is maklik om se per ongelok net mei iens te meitsjen troch guon fan 'e traits te ûntlieden en oaren manuell te ymplementearjen.
///
/// In foarbyldútfiering foar in domein wêryn twa boeken itselde boek wurde beskôge as har ISBN oerienkomt, sels as de formaten ferskille:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Hoe kin ik twa ferskillende soarten fergelykje?
///
/// It type wêrmei jo kinne fergelykje wurdt regele troch de typeparameter fan 'PartialEq`.
/// Litte wy bygelyks ús foarige koade in bytsje oanpasse:
///
/// ```
/// // De ôfliede ymplementearret<BookFormat>==<BookFormat>fergelikingen
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ymplemintearje<Book>==<BookFormat>fergelikingen
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ymplemintearje<BookFormat>==<Book>fergelikingen
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Troch `impl PartialEq for Book` yn `impl PartialEq<BookFormat> for Book` te feroarjen, tastean wy 'BookFormat`s te fergelykjen mei`Book`s.
///
/// In fergeliking lykas hjirboppe, dy't guon fjilden fan 'e struktuer negeart, kin gefaarlik wêze.It kin maklik liede ta in ûnbedoelde oertreding fan 'e easken foar in parsjele ekwivalensjerelaasje.
/// As wy bygelyks de boppesteande ymplemintaasje fan `PartialEq<Book>` foar `BookFormat` hâlde en in ymplemintaasje tafoege fan `PartialEq<Book>` foar `Book` (fia in `#[derive]` as fia de hânmjittige ymplemintaasje fan it earste foarbyld), soe it resultaat yn striid wêze mei transitiviteit:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Dizze metoade test foar `self`-en `other`-wearden om gelyk te wêzen, en wurdt brûkt troch `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Dizze metoade test foar `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait foar fergeliking fan gelikensens dy't [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) binne.
///
/// Dit betsjut dat neist `a == b` en `a != b` strikte omkearingen is, moat de gelikensens wêze (foar alle `a`, `b` en `c`):
///
/// - reflexive: `a == a`;
/// - symmetrysk: `a == b` ympliseart `b == a`;en
/// - transitive: `a == b` en `b == c` ympliseart `a == c`.
///
/// Dizze eigenskip kin net wurde kontroleare troch de gearstaller, en dêrom ympliseart `Eq` [`PartialEq`], en hat gjin ekstra metoaden.
///
/// ## Derivable
///
/// Dizze trait kin brûkt wurde mei `#[derive]`.
/// As 'derive' d, om't `Eq` gjin ekstra metoaden hat, is it allinich de kompilearder te ynformearjen dat dit in ekwivalensjerelaasje is yn plak fan in dielsekwivalensjerelaasje.
///
/// Tink derom dat de `derive`-strategy fereasket dat alle fjilden `Eq` binne, wat net altyd winske is.
///
/// ## Hoe kin ik `Eq` útfiere?
///
/// As jo de `derive`-strategy net kinne brûke, spesifisearje dan dat jo type `Eq` ymplementeart, dy't gjin metoaden hat:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // dizze metoade wurdt allinich brûkt troch#[ôfliede] om te bewearen dat elke komponint fan in type#[ûntlient] sels ymplementeart, de hjoeddeiske ûntliene ynfrastruktuer betsjut dat dizze bewearing dwaan is sûnder in metoade te brûken op dizze trait is hast ûnmooglik.
    //
    //
    // Dit moat nea mei de hân wurde ymplementeare.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: dizze struktuer wurdt allinich brûkt troch#[ûntliene] oan
// beweare dat elke komponint fan in type ekw. ymplementeart.
//
// Dizze struktuer moat nea ferskine yn brûkerskoade.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// In `Ordering` is it resultaat fan in ferliking tusken twa wearden.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// In oarder wêr't in fergelike wearde minder is dan in oare.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// In oarder wêr't in fergelike wearde gelyk is oan in oare.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// In oarder wêr't in fergelike wearde grutter is dan in oare.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Jout `true` werom as it bestellen de `Equal`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Jout `true` werom as it bestellen net de `Equal`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Jout `true` werom as it bestellen de `Less`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Jout `true` werom as it bestellen de `Greater`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Jout `true` werom as de oarder de `Less`-of `Equal`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Jout `true` werom as de oarder de `Greater`-of `Equal`-fariant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Fertelt de `Ordering`.
    ///
    /// * `Less` wurdt `Greater`.
    /// * `Greater` wurdt `Less`.
    /// * `Equal` wurdt `Equal`.
    ///
    /// # Examples
    ///
    /// Basis gedrach:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Dizze metoade kin brûkt wurde om in fergeliking te kearen:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sortearje de array fan grutste nei lytste.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Keatlingen twa oarders.
    ///
    /// Jout `self` werom as it net `Equal` is.Oars jout `other` werom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Keatling it oarderjen mei de opjûne funksje.
    ///
    /// Jout `self` as it net `Equal` is.
    /// Oars neamt `f` en jout it resultaat werom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// In helpende struktuer foar omkearde oardering.
///
/// Dizze struktuer is in helper om te brûken mei funksjes lykas [`Vec::sort_by_key`] en kin brûkt wurde om in diel fan in kaai werom te draaien.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait foar typen dy't in [total order](https://en.wikipedia.org/wiki/Total_order) foarmje.
///
/// In oarder is in totale oarder as it is (foar alle `a`, `b` en `c`):
///
/// - totaal en asymmetrysk: presys ien fan `a < b`, `a == b` of `a > b` is wier;en
/// - transitive, `a < b` en `b < c` ymplisyt `a < c`.Itselde moat hâlde foar sawol `==` as `>`.
///
/// ## Derivable
///
/// Dizze trait kin brûkt wurde mei `#[derive]`.
/// As 'ôfliede' op structs, sil it in [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order)-oarder produsearje basearre op 'e folchoarder fan' e top-nei-ûnderkant fan 'e leden fan' e struct.
///
/// As 'ôflaat' op enums, wurde farianten besteld troch har diskriminearjende folchoarder fan boppe-nei-ûnder.
///
/// ## Leksikografyske ferliking
///
/// Leksikografyske fergeliking is in operaasje mei de folgjende eigenskippen:
///  - Twa sekwinsjes wurde elemint foar elemint fergelike.
///  - It earste mismatching-elemint definieart hokker folchoarder leksikografysk minder of grutter is as de oare.
///  - As de iene folchoarder in foarheaksel is fan 'e oare, is de koartere folchoarder leksikografysk minder dan de oare.
///  - As twa sekwinsjes lykweardige eleminten hawwe en deselde lingte hawwe, dan binne de sekwinsjes leksikografysk gelyk.
///  - In lege folchoarder is leksikografysk minder dan alle net-lege folchoarder.
///  - Twa lege sekwinsjes binne leksikografysk gelyk.
///
/// ## Hoe kin ik `Ord` útfiere?
///
/// `Ord` fereasket dat it type ek [`PartialOrd`] en [`Eq`] is (wat [`PartialEq`] fereasket).
///
/// Dan moatte jo in ymplemintaasje foar [`cmp`] definiearje.Jo kinne it nuttich fine om [`cmp`] te brûken op 'e fjilden fan jo type.
///
/// Ymplementaasjes fan [`PartialEq`], [`PartialOrd`] en `Ord`*moatte* mei-inoar iens wêze.
/// Dat is `a.cmp(b) == Ordering::Equal` as en allinich as `a == b` en `Some(a.cmp(b)) == a.partial_cmp(b)` foar alle `a` en `b`.
/// It is maklik om se per ongelok net mei iens te meitsjen troch guon fan 'e traits te ûntlieden en oaren manuell te ymplementearjen.
///
/// Hjir is in foarbyld wêr't jo minsken allinich op hichte wolle sortearje, sûnder `id` en `name` te negearjen:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Dizze metoade jout in [`Ordering`] werom tusken `self` en `other`.
    ///
    /// By konvinsje jout `self.cmp(&other)` de folchoarder werom dy't oerienkomt mei de útdrukking `self <operator> other` as wier.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Fergeliket en jout it maksimum fan twa wearden werom.
    ///
    /// Jout it twadde argumint werom as de fergeliking bepaalt dat se gelyk binne.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Fergeliket en retourneert it minimum fan twa wearden.
    ///
    /// Jout it earste argumint werom as de fergeliking bepaalt dat se gelyk binne.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// In wearde beheine ta in bepaald ynterval.
    ///
    /// Jout `max` as `self` grutter is as `max`, en `min` as `self` minder is as `min`.
    /// Oars jout dit `self` werom.
    ///
    /// # Panics
    ///
    /// Panics as `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait foar wearden dy't kinne wurde ferlike foar in soarte-oarder.
///
/// De fergeliking moat foldwaan, foar alle `a`, `b` en `c`:
///
/// - asymmetry: as `a < b` dan `!(a > b)`, lykas `a > b` wat `!(a < b)` betsjuttet;en
/// - transitiviteit: `a < b` en `b < c` ymplisearret `a < c`.Itselde moat hâlde foar sawol `==` as `>`.
///
/// Tink derom dat dizze easken betsjutte dat de trait sels symmetrysk en transityf moat wurde ymplementeare: as `T: PartialOrd<U>` en `U: PartialOrd<V>` dan `U: PartialOrd<T>` en `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Dizze trait kin brûkt wurde mei `#[derive]`.As 'ôflaat' d fan structs, sil it in leksikografyske oarder produsearje basearre op 'e folchoarder fan' e top-nei-ûnderkant fan 'e leden fan' e struct.
/// As 'ôflaat' op enums, wurde farianten besteld troch har diskriminearjende folchoarder fan boppe-nei-ûnder.
///
/// ## Hoe kin ik `PartialOrd` útfiere?
///
/// `PartialOrd` fereasket allinich ymplemintaasje fan 'e [`partial_cmp`]-metoade, wêrby't de oaren genereare binne út standert ymplementaasjes.
///
/// It bliuwt lykwols mooglik de oaren apart te ymplementearjen foar typen dy't gjin totale oarder hawwe.
/// Bygelyks foar nûmers mei driuwende punten, `NaN < 0 == false` en `NaN >= 0 == false` (fgl.
/// IEEE 754-2008 seksje 5.11).
///
/// `PartialOrd` fereasket dat jo type [`PartialEq`] is.
///
/// Ymplementaasjes fan [`PartialEq`], `PartialOrd` en [`Ord`]*moatte* mei-inoar iens wêze.
/// It is maklik om se per ongelok net mei iens te meitsjen troch guon fan 'e traits te ûntlieden en oaren manuell te ymplementearjen.
///
/// As jo type [`Ord`] is, kinne jo [`partial_cmp`] ymplementearje troch [`cmp`] te brûken:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Jo kinne it ek nuttich fine om [`partial_cmp`] te brûken op 'e fjilden fan jo type.
/// Hjir is in foarbyld fan `Person`-typen dy't in floatpunt `height`-fjild hawwe dat it iennichste fjild is dat brûkt wurdt foar sortearjen:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Dizze metoade jout in oarder werom tusken `self`-en `other`-wearden as der ien bestiet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// As fergeliking ûnmooglik is:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Dizze metoade test minder dan (foar `self` en `other`) en wurdt brûkt troch de `<`-operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Dizze metoade test minder dan of gelyk oan (foar `self` en `other`) en wurdt brûkt troch de `<=`-operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Dizze metoade test grutter dan (foar `self` en `other`) en wurdt brûkt troch de `>`-operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Dizze metoade test grutter as of gelyk oan (foar `self` en `other`) en wurdt brûkt troch de `>=`-operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Meitsje makro dy't in ympl genereart fan 'e trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Fergeliket en retourneert it minimum fan twa wearden.
///
/// Jout it earste argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// Yntern brûkt in alias foar [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Jout it minimum fan twa wearden oangeande de oantsjutte ferlikingsfunksje.
///
/// Jout it earste argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Jout it elemint werom dat de minimale wearde jout fan 'e oantsjutte funksje.
///
/// Jout it earste argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Fergeliket en jout it maksimum fan twa wearden werom.
///
/// Jout it twadde argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// Yntern brûkt in alias foar [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Jout it maksimum fan twa wearden oangeande de oantsjutte ferlikingsfunksje.
///
/// Jout it twadde argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Jout it elemint werom dat de maksimale wearde jout fan 'e oantsjutte funksje.
///
/// Jout it twadde argumint werom as de fergeliking bepaalt dat se gelyk binne.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Ymplemintaasje fan PartialEq, Eq, PartialOrd en Ord foar primitive typen
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // De oarder hjir is wichtich om mear optimale gearkomste te generearjen.
                    // Sjoch <https://github.com/rust-lang/rust/issues/63758> foar mear ynfo.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Casten nei i8's en it konvertearjen fan it ferskil nei in Ordering genereart in optimale gearkomste.
            //
            // Sjoch <https://github.com/rust-lang/rust/issues/66780> foar mear ynfo.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // VEILIGHEID: bool as i8 jout 0 of 1 werom, sadat it ferskil net oars kin wêze
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &oanwizings

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}