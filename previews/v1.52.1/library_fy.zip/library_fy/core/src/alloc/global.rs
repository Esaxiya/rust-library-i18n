use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// In ûnthâld allocator dy't kin wurde registrearre as de standertbibleteek's standert fia it `#[global_allocator]`-attribút.
///
/// Guon fan 'e metoaden fereaskje dat in ûnthâldblok *op it stuit tawiisd* wurdt fia in allocator.Dit betsjut dat:
///
/// * it startadres foar dat ûnthâldblok waard earder weromjûn troch in eardere oprop nei in allocaasjemetoade lykas `alloc`, en
///
/// * it ûnthâldblok is net neitiid deallocated, wêr't blokken wurde deallocated troch troch te gean nei in deallokaasjemetoade lykas `dealloc` of troch te wurde trochjûn oan in reallokaasjemetoade dy't in net-nul oanwizer retourneert.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// De `GlobalAlloc` trait is om in oantal redenen in `unsafe` trait, en implementeurs moatte derfoar soargje dat se har hâlde oan dizze kontrakten:
///
/// * It is undefined gedrach as globale allocators ûntspanne.Dizze beheining kin opheft wurde yn 'e future, mar op it stuit kin in panic fan ien fan dizze funksjes liede ta ûnfeiligens yn ûnthâld.
///
/// * `Layout` fragen en berekkeningen yn 't algemien moatte korrekt wêze.Bellers fan dizze trait meie fertrouwe op 'e kontrakten dy't binne definieare op elke metoade, en ymplementanten moatte derfoar soargje dat sokke kontrakten wier bliuwe.
///
/// * Jo kinne net fertrouwe op allocaasjes dy't eins barre, sels as d'r eksplisite heap-allocaasjes binne yn 'e boarne.
/// De optimizer kin ûngebrûkte allocaasjes ûntdekke dat hy kin folslein eliminearje of nei de stapel ferpleatse en dus nea de allocator oproppe.
/// De optimizer kin fierder oannimme dat tawizing ûnfeilber is, sadat koade dy't eartiids mislearre fanwege mislearrings fan allocator no ynienen kin wurkje om't de optimizer wurke om de needsaak foar in tawizing.
/// Mear konkreet is it folgjende koade-foarbyld net sûn, ûnôfhinklik oft jo oanpaste allocator telt hoefolle allocaasjes binne bard.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Tink derom dat de hjirboppe neamde optimisaasjes net de ienige optimisaasje binne dy't tapast wurde kinne.Jo kinne oer it algemien net fertrouwe op bultetallokaasjes dy't barre as se kinne wurde fuorthelle sûnder it programmagedrach te feroarjen.
///   Oft allocaasjes barre of net is gjin diel fan it programmagedrach, sels as it koe wurde ûntdutsen fia in allocator dy't allocaasjes folget troch te drukken of oars side-effekten hat.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tawize ûnthâld as beskreaun troch de opjûne `layout`.
    ///
    /// Jout in oanwizer nei nij tawiisd ûnthâld, of nul om tawiisingsfeil oan te jaan.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich om't undefined gedrach kin ûntstean as de beller net soarget derfoar dat `layout` net-nul grutte hat.
    ///
    /// (Ekstra-subraits kinne mear spesifike grinzen op gedrach leverje, bgl. In garânsje-adres of in nulwizer garandearje as antwurd op in fersyk foar tawizing fan nul-grutte.)
    ///
    /// It tawiisde ûnthâldblok kin wol of net inisjalisearre wurde.
    ///
    /// # Errors
    ///
    /// It werombringen fan in nulpointer jout oan dat it ûnthâld ûnthâld is útput, of dat `layout` net foldocht oan de grutte of de beheiningsbeperkingen fan dizze allocator.
    ///
    /// Ymplemintaasjes wurde oanmoedige om null werom te jaan op ûnthâldútputting ynstee fan ôfbrekken, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Lokalisearje it blok ûnthâld by de opjûne `ptr`-oanwizer mei de opjûne `layout`.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich om't undefined gedrach kin resultearje as de beller net alle folgjende soarget:
    ///
    ///
    /// * `ptr` moat in blok ûnthâld oantsjutte dat op dit stuit tawiisd is fia dizze allocator,
    ///
    /// * `layout` moat deselde opmaak wêze dy't waard brûkt om dat blok geheugen ta te wizen.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Gedraacht har as `alloc`, mar soarget der ek foar dat de ynhâld op nul is ynsteld foardat se wurde weromjûn.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich om deselde redenen dat `alloc` is.
    /// It tawiisde blok ûnthâld is lykwols garandearre dat it inisjalisearre wurdt.
    ///
    /// # Errors
    ///
    /// It werombringen fan in nulpointer jout oan dat it ûnthâld ûnthâld is útput, of dat `layout` net foldocht oan de grutte fan de allocator of de beheiningsbeperkingen, krekt as yn `alloc`.
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // VEILIGHEID: it feiligenskontrakt foar `alloc` moat wurde yn stân hâlden troch de beller.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // VEILIGHEID: doe't de tawizing slagge, de regio fan `ptr`
            // fan grutte `size` is garandearre jildich foar skriuwen.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Krimp of groeie in blok ûnthâld nei de opjûne `new_size`.
    /// It blok wurdt beskreaun troch de opjûne `ptr`-oanwizer en `layout`.
    ///
    /// As dit in net-nul oanwizer jout, is eigendom fan it ûnthâldblok dat `ptr` ferwiist nei oerdroegen oan dizze allocator.
    /// It ûnthâld is al of net deallokeard, en moat as unbrûkber wurde beskôge (behalve as it fansels wer waard oerdroegen oan 'e beller fia de weromwearde fan dizze metoade).
    /// It nije ûnthâldblok wurdt tawiisd mei `layout`, mar mei de `size` bywurke nei `new_size`.
    /// Dizze nije opmaak moat brûkt wurde as it nije ûnthâldblok mei `dealloc` behannele wurdt.
    /// It berik `0..min(layout.size(), new_size) `fan it nije ûnthâldblok hat garandearre deselde wearden as it orizjinele blok.
    ///
    /// As dizze metoade nul jout, dan is eigendom fan it ûnthâldblok net oerdroegen oan dizze allocator, en is de ynhâld fan it ûnthâldblok net feroare.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich om't undefined gedrach kin resultearje as de beller net alle folgjende soarget:
    ///
    /// * `ptr` moat op it stuit wurde tawiisd fia dizze allocator,
    ///
    /// * `layout` moat deselde opmaak wêze dy't waard brûkt om dat geheugenblok ta te wizen,
    ///
    /// * `new_size` moat grutter wêze dan nul.
    ///
    /// * `new_size`, as it omheech rint nei it tichtste mearfâld fan `layout.align()`, moat it net oerstreamje (dat wol sizze, de ôfrûne wearde moat minder wêze as `usize::MAX`).
    ///
    /// (Ekstra-subraits kinne mear spesifike grinzen op gedrach leverje, bgl. In garânsje-adres of in nulwizer garandearje as antwurd op in fersyk foar tawizing fan nul-grutte.)
    ///
    /// # Errors
    ///
    /// Jout nul werom as de nije opmaak net foldocht oan de beheinings fan grutte en ôfstimming fan 'e allocator, of as werlokaasje oars mislearret.
    ///
    /// Ymplementaasjes wurde oanmoedige om nul werom te jaan op útputting fan ûnthâld ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in weryndielingsflater wurde stimulearre om de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of ferlykber oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // VEILIGHEID: de beller moat derfoar soargje dat de `new_size` net oerrint.
        // `layout.align()` komt fan in `Layout` en is dus garandearre jildich te wêzen.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // VEILIGHEID: de beller moat derfoar soargje dat `new_layout` grutter is dan nul.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // VEILIGHEID: it earder tawiisde blok kin it nij tawiisde blok net oerlaapje.
            // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}