//! APIs foar tawizing fan ûnthâld

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// De `AllocError`-flater wiist op in tawijingsfout dat kin wêze troch wurgens fan boarnen of troch wat ferkeard by it kombinearjen fan de opjûne ynfierarguminten mei dizze tawizer.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (wy hawwe dit nedich foar downstream-ympl fan trait Flater)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// In ymplemintaasje fan `Allocator` kin willekeurige blokken gegevens beskriuwe fia [`Layout`][] allocearje, groeie, krimpe en deallokearje.
///
/// `Allocator` is ûntwurpen om te wurde ymplementeare op ZST's, referinsjes, of tûke oanwizings, om't in allocator lykas `MyAlloc([u8; N])` net kin wurde ferpleatst, sûnder de oanwizings te updaten nei it tawiisde ûnthâld.
///
/// Oars as [`GlobalAlloc`][] binne allocaasjes mei nulgrutte tastien yn `Allocator`.
/// As in ûnderlizzende allocator dit net stipet (lykas jemalloc) of in nulpointer (lykas `libc::malloc`) retourneert, moat dit wurde fongen troch de ymplemintaasje.
///
/// ### Op it stuit tawiisd ûnthâld
///
/// Guon fan 'e metoaden fereaskje dat in ûnthâldblok *op it stuit tawiisd* wurdt fia in allocator.Dit betsjut dat:
///
/// * it startadres foar dat ûnthâldblok waard earder weromjûn troch [`allocate`], [`grow`], of [`shrink`], en
///
/// * it ûnthâldblok is net neitiid deallocated, wêr't blokken of direkt wurde deallocated troch te wurde trochjûn oan [`deallocate`] of waarden feroare troch te wurde oerdroegen oan [`grow`] of [`shrink`] dy't `Ok` weromkomt.
///
/// As `grow` as `shrink` `Err` hawwe weromjûn, bliuwt de trochjûn oanwizer jildich.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Unthâld passend
///
/// Guon fan 'e metoaden fereaskje dat in opmaak *past* in ûnthâldblok.
/// Wat it betsjuttet foar in opmaak foar "fit" betsjuttet in ûnthâldblok (of ekwivalint, foar in ûnthâldblok foar "fit" in opmaak) is dat de folgjende betingsten moatte wêze:
///
/// * It blok moat wurde tawiisd mei deselde opstelling as [`layout.align()`], en
///
/// * De levere [`layout.size()`] moat falle yn it berik `min ..= max`, wêr:
///   - `min` is de grutte fan 'e opmaak dy't it lêst brûkt is om it blok te allocearjen, en
///   - `max` is de lêste werklike grutte weromjûn fan [`allocate`], [`grow`], of [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Unthâldblokken dy't werom binne fan in allocator moatte nei jildich ûnthâld wize en har jildigens behâlde oant it eksimplaar en al syn klonen wurde weilitten,
///
/// * it klonjen of ferpleatse fan de allocator mei net ûnthâlde ûnthâldblokken dy't binne weromjûn fan dizze allocator.In klone allocator moat him gedrage as deselde allocator, en
///
/// * elke oanwizer nei in ûnthâldblok dat [*currently allocated*] is, kin wurde trochjûn oan elke oare metoade fan 'e allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Besiket in geheugenblok ta te kennen.
    ///
    /// As sukses retourneert in [`NonNull<[u8]>`][NonNull] dy't foldocht oan de garânsjes fan grutte en ôfstimming fan `layout`.
    ///
    /// It weromblok kin in gruttere maat hawwe dan oantsjutte troch `layout.size()`, en de ynhâld kin al of net initialisearre wurde.
    ///
    /// # Errors
    ///
    /// Weromgean fan `Err` jout oan dat it ûnthâld útput is of dat `layout` net foldocht oan de grutte fan 'e allocator of de beheinings fan' e ôfstimming.
    ///
    /// Ymplemintaasjes wurde stimulearre om `Err` werom te jaan op ûnthâldútputting ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Gedrach lykas `allocate`, mar soarget der ek foar dat it weromjûn ûnthâld nul-inisjalisearre is.
    ///
    /// # Errors
    ///
    /// Weromgean fan `Err` jout oan dat it ûnthâld útput is of dat `layout` net foldocht oan de grutte fan 'e allocator of de beheinings fan' e ôfstimming.
    ///
    /// Ymplemintaasjes wurde stimulearre om `Err` werom te jaan op ûnthâldútputting ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // VEILIGHEID: `alloc` jout in jildich ûnthâldblok werom
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallokeart it ûnthâld dat wurdt ferwiisd troch `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` moat in blok ûnthâld [*currently allocated*] oantsjutte fia dizze allocator, en
    /// * `layout` moat [*fit*] dat blok fan ûnthâld.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Besiket it ûnthâldblok út te wreidzjen.
    ///
    /// Jout in nije [`NonNull<[u8]>`][NonNull] mei in oanwizer en de werklike grutte fan it tawiisde ûnthâld.De oanwizer is geskikt foar it bewarjen fan gegevens beskreaun troch `new_layout`.
    /// Om dit te berikken kin de tawizer de tawizing dy't `ptr` ferwiist nei útwreidzje nei de nije opmaak.
    ///
    /// As dit `Ok` weromkomt, is eigendom fan it ûnthâldblok dat `ptr` ferwiist nei oerdroegen oan dizze allocator.
    /// It ûnthâld kin al of net befrijd wêze, en moat as net brûkber wurde beskôge, útsein as it wer werom is oerbrocht nei de beller fia de weromwearde fan dizze metoade.
    ///
    /// As dizze metoade `Err` werombringt, is eigendom fan it ûnthâldblok net oerdroegen oan dizze allocator, en de ynhâld fan it ûnthâldblok is net feroare.
    ///
    /// # Safety
    ///
    /// * `ptr` moat in blok ûnthâld [*currently allocated*] oantsjutte fia dizze allocator.
    /// * `old_layout` moat dat blok geheugen [*fit*] (It `new_layout`-argumint hoecht it net te passen.).
    /// * `new_layout.size()` moat grutter wêze as of gelyk oan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jout `Err` werom as de nije opmaak net foldocht oan de grutte fan de allocator en de beheiningsbeperkingen fan 'e allocator, of as groei oars net slagget.
    ///
    /// Ymplemintaasjes wurde stimulearre om `Err` werom te jaan op ûnthâldútputting ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: om't `new_layout.size()` grutter wêze moat as of gelyk oan
        // `old_layout.size()`, sawol de âlde as de nije ûnthâld is tawiisd foar lêzen en skriuwen foar `old_layout.size()`-bytes.
        // Om't de âlde allocaasje noch net behannele is, kin it `new_ptr` net oerlaapje.
        // Sadwaande is de oprop nei `copy_nonoverlapping` feilich.
        // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Gedrach lykas `grow`, mar soarget der ek foar dat de nije ynhâld op nul is ynsteld foardat se weromkomme.
    ///
    /// It ûnthâldblok sil de folgjende ynhâld befetsje nei in suksesfolle oprop nei
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` wurde bewarre fan 'e orizjinele allocaasje.
    ///   * Bytes `old_layout.size()..old_size` wurdt of bewarre of nulsteld, ôfhinklik fan de ymplemintaasje fan de allocator.
    ///   `old_size` ferwiist nei de grutte fan it ûnthâldblok foarôfgeand oan de `grow_zeroed`-oprop, dy't grutter kin wêze dan de grutte dy't oarspronklik waard frege doe't it waard tawiisd.
    ///   * Bytes `old_size..new_size` binne nulsteld.`new_size` ferwiist nei de grutte fan it ûnthâldblok dat weromkomt troch de `grow_zeroed`-oprop.
    ///
    /// # Safety
    ///
    /// * `ptr` moat in blok ûnthâld [*currently allocated*] oantsjutte fia dizze allocator.
    /// * `old_layout` moat dat blok geheugen [*fit*] (It `new_layout`-argumint hoecht it net te passen.).
    /// * `new_layout.size()` moat grutter wêze as of gelyk oan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jout `Err` werom as de nije opmaak net foldocht oan de grutte fan de allocator en de beheiningsbeperkingen fan 'e allocator, of as groei oars net slagget.
    ///
    /// Ymplemintaasjes wurde stimulearre om `Err` werom te jaan op ûnthâldútputting ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // VEILIGHEID: om't `new_layout.size()` grutter wêze moat as of gelyk oan
        // `old_layout.size()`, sawol de âlde as de nije ûnthâld is tawiisd foar lêzen en skriuwen foar `old_layout.size()`-bytes.
        // Om't de âlde allocaasje noch net behannele is, kin it `new_ptr` net oerlaapje.
        // Sadwaande is de oprop nei `copy_nonoverlapping` feilich.
        // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Besiket it ûnthâldblok te krimpen.
    ///
    /// Jout in nije [`NonNull<[u8]>`][NonNull] mei in oanwizer en de werklike grutte fan it tawiisde ûnthâld.De oanwizer is geskikt foar it bewarjen fan gegevens beskreaun troch `new_layout`.
    /// Om dit te berikken kin de tawizer de tawizing troch `ptr` ferwiisd krimp om te passen by de nije opmaak.
    ///
    /// As dit `Ok` weromkomt, is eigendom fan it ûnthâldblok dat `ptr` ferwiist nei oerdroegen oan dizze allocator.
    /// It ûnthâld kin al of net befrijd wêze, en moat as net brûkber wurde beskôge, útsein as it wer werom is oerbrocht nei de beller fia de weromwearde fan dizze metoade.
    ///
    /// As dizze metoade `Err` werombringt, is eigendom fan it ûnthâldblok net oerdroegen oan dizze allocator, en de ynhâld fan it ûnthâldblok is net feroare.
    ///
    /// # Safety
    ///
    /// * `ptr` moat in blok ûnthâld [*currently allocated*] oantsjutte fia dizze allocator.
    /// * `old_layout` moat dat blok geheugen [*fit*] (It `new_layout`-argumint hoecht it net te passen.).
    /// * `new_layout.size()` moat lytser wêze as of gelyk oan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jout `Err` werom as de nije opmaak net foldocht oan de grutte fan de allocator en de beheiningsbeperkingen fan 'e allocator, of as krimp oars net slagget.
    ///
    /// Ymplemintaasjes wurde stimulearre om `Err` werom te jaan op ûnthâldútputting ynstee fan yn panyk of ôfbrekke, mar dit is gjin strikte eask.
    /// (Spesifyk: it is *legaal* om dizze trait te ymplementearjen boppe op in ûnderlizzende natuerlike allocaasjebibleteek dy't ôfbrûkt op útputting fan ûnthâld.)
    ///
    /// Kliïnten dy't berekkening ôfbrekke wolle as antwurd op in tawizingsflater wurde stimulearre de [`handle_alloc_error`]-funksje te skiljen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: om't `new_layout.size()` leger as of gelyk moat wêze
        // `old_layout.size()`, sawol de âlde as de nije ûnthâld is tawiisd foar lêzen en skriuwen foar `new_layout.size()`-bytes.
        // Om't de âlde allocaasje noch net behannele is, kin it `new_ptr` net oerlaapje.
        // Sadwaande is de oprop nei `copy_nonoverlapping` feilich.
        // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Makket in "by reference"-adapter foar dit eksimplaar fan `Allocator`.
    ///
    /// De weromkommende adapter ymplementeart ek `Allocator` en sil dit gewoan liene.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // VEILIGHEID: it feiligenskontrakt moat wurde opromme troch de beller
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: it feiligenskontrakt moat wurde opromme troch de beller
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: it feiligenskontrakt moat wurde opromme troch de beller
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: it feiligenskontrakt moat wurde opromme troch de beller
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}