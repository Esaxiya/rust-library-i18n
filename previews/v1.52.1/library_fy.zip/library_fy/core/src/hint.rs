#![stable(feature = "core_hint", since = "1.27.0")]

//! Tips foar gearstaller dy't beynfloedet hoe koade útstjoerd of optimalisearre wurde moat.
//! Hints kinne tiid of runtime wêze.

use crate::intrinsics;

/// Ynformeart de gearstaller dat dit punt yn 'e koade net te berikken is, wêrtroch fierdere optimisaasjes mooglik binne.
///
/// # Safety
///
/// Dizze funksje berikke is folslein *undefined gedrach*(UB).Benammen de gearstaller giet derfan út dat alle UB noait moat barre, en sil dêrom alle tûken eliminearje dy't berikke nei in oprop nei `unreachable_unchecked()`.
///
/// Lykas alle gefallen fan UB, as dizze oanname ferkeard blykt te wêzen, dat wol sizze dat de `unreachable_unchecked()`-oprop eins berikber is tusken alle mooglike kontrôleflommen, sil de gearstaller de ferkearde optimalisaasjestrategy tapasse, en kin soms sels skynber net-relatearre koade korrupte wurde, wêrtroch lestich-problemen mei debuggen.
///
///
/// Brûk dizze funksje allinich as jo kinne bewize dat de koade it nea neame sil.
/// Oars, beskôgje it gebrûk fan 'e [`unreachable!`]-makro, dy't gjin optimisaasjes tastiet, mar panic sil wurde útfierd.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` is altyd posityf (net nul), fandêr dat `checked_div` `None` noait weromkomt.
/////
///     // Dêrom is de oare branch net te berikken.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // VEILIGHEID: it feiligenskontrakt foar `intrinsics::unreachable` moat
    // wurde oprjochte troch de beller.
    unsafe { intrinsics::unreachable() }
}

/// Stjoert in masine-ynstruksje út om de prosessor te sinjalearjen dat hy draait yn in spin-loop mei drok wachtsje ("spin-lock").
///
/// By ûntfangst fan it spin-loop-sinjaal kin de prosessor syn gedrach optimalisearje troch bygelyks enerzjybesparring of hyper-thread te wikseljen.
///
/// Dizze funksje is oars as [`thread::yield_now`] dy't direkt oplevert oan 'e planner fan it systeem, wylst `spin_loop` net ynteraksje hat mei it bestjoeringssysteem.
///
/// In algemien gebrûk foar `spin_loop` is it ymplementearjen fan beheind optimistysk spinnen yn in CAS-loop yn syngronisaasjeprimitiven.
/// Om problemen lykas prioriteitsynversje te foarkommen, wurdt it sterk oanrikkemandearre dat de spin-loop wurdt beëinige nei in einige hoemannichte werhellings en in passende blokkearjende syscall wurdt makke.
///
///
/// **Opmerking**: Op platfoarms dy't gjin ûntfangst fan spin-loop-hintsjes stypje docht dizze funksje hielendal neat.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // In dielde atoomwearde dy't triedden sille brûke om te koördinearjen
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Yn in eftergrûntried sette wy de wearde úteinlik yn
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Doch wat wurk, meitsje de wearde dan live
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Werom op ús hjoeddeistige tried wachtsje wy op 'e wearde dy't ynsteld wurdt
/// while !live.load(Ordering::Acquire) {
///     // De spin-loop is in hint foar de CPU dat wy wachtsje, mar wierskynlik net heul lang
/////
///     hint::spin_loop();
/// }
///
/// // De wearde is no ynsteld
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // VEILIGHEID: de `cfg` attr soarget derfoar dat wy dit allinich útfiere op x86-doelen.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // VEILIGHEID: de `cfg` attr soarget derfoar dat wy dit allinich útfiere op x86_64-doelen.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // VEILIGHEID: de `cfg` attr soarget derfoar dat wy dit allinich útfiere op aarch64-doelen.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // VEILIGHEID: de `cfg` attr soarget derfoar dat wy dit allinich útfiere op earmdoelen
            // mei stipe foar de v6-funksje.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// In identiteitsfunksje dy't *__ hintsje __* oan 'e gearstaller om maksimaal pessimistysk te wêzen oer wat `black_box` koe dwaan.
///
/// Oars as [`std::convert::identity`] wurdt in Rust-kompilator stimulearre om oan te nimmen dat `black_box` `dummy` kin brûke op elke mooglike jildige manier wêrop't Rust-koade is tastien sûnder undefined gedrach yn 'e belkoade yn te fieren.
///
/// Dizze eigenskip makket `black_box` nuttich foar it skriuwen fan koade wêryn bepaalde optimisaasjes net winske binne, lykas benchmarks.
///
/// Tink derom dat `black_box` allinich (en kin allinich wurde) levere op basis fan "best-effort".De mjitte wêryn't it optimisaasjes kin blokkearje kin ferskille ôfhinklik fan it brûkte platfoarm en code-gen-backend.
/// Programma's kinne op gjin inkelde manier fertrouwe op `black_box` foar *korrektheid*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Wy moatte it argumint op ien of oare manier "use" LLVM kin net yntrospektearje, en op doelen dy't it stypje kinne wy typysk inline-gearstalling brûke om dit te dwaan.
    // De ynterpretaasje fan LLVM fan inline-assemblage is dat it, no ja, in swarte doaze is.
    // Dit is net de grutste ymplemintaasje, om't it wierskynlik mear deoptimaliseart dan wy wolle, mar it is oant no ta goed genôch.
    //
    //

    #[cfg(not(miri))] // Dit is gewoan in hint, dus it is prima om yn Miri oer te slaan.
    // VEILIGHEID: de ynline gearkomste is in no-op.
    unsafe {
        // FIXME: Kin `asm!` net brûke, om't it MIPS en oare arsjitektuer net stipet.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}