Panics de hjoeddeiske tried.

Hjirmei kin in programma fuortendaliks beëindigje en feedback jaan oan de beller fan it programma.
`panic!` moat wurde brûkt as in programma in net werom te krijen steat berikt.

Dizze makro is de perfekte manier om betingsten te bewearjen yn foarbyldkoade en yn tests.
`panic!` is nau ferbûn mei de `unwrap`-metoade fan sawol [`Option`][ounwrap]-as [`Result`][runwrap]-enums.
Beide ymplementaasjes neame `panic!` as se binne ynsteld op [`None`] of [`Err`] farianten.

As jo `panic!()` brûke, kinne jo in stringbelesting oantsjutte, dy't wurdt boud mei de [`format!`]-syntaksis.
Dy lading wurdt brûkt as de panic ynjekteare yn 'e opropende Rust-thread, wêrtroch't de thread hielendal panic feroarsaket.

It gedrach fan 'e standert `std` hook, ie
de koade dy't direkt rint nei't de panic is oproppen, is om de lading foar berjochten nei `stderr` te drukken tegearre mei de file/line/column-ynformaasje fan 'e `panic!()`-oprop.

Jo kinne de panic hook mei [`std::panic::set_hook()`] oerskriuwe.
Binnen de hook is in panic te berikken as in `&dyn Any + Send`, dy't of in `&str` as `String` befettet foar reguliere `panic!()`-oanroppen.
Foar panic mei in wearde fan in oar oar type, kin [`panic_any`] brûkt wurde.

[`Result`] enum is faaks in bettere oplossing foar herstellen fan flaters dan it brûken fan de `panic!`-makro.
Dizze makro moat brûkt wurde om te foarkommen dat trochgean mei ferkearde wearden, lykas fan eksterne boarnen.
Detaillearre ynformaasje oer flaterbehanneling is te finen yn 'e [book].

Sjoch ek de makro [`compile_error!`] foar it opheljen fan flaters by kompilaasje.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aktuele ymplemintaasje

As de haadtried panics sil al jo threads beëindigje en jo programma einigje mei koade `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





