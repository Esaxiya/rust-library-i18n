#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Wreidet út nei `$crate::panic::panic_2015` as `$crate::panic::panic_2021`, ôfhinklik fan 'e edysje fan' e beller.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Beweart dat twa útdrukkingen gelyk binne oan elkoar (mei [`PartialEq`]).
///
/// Op panic sil dizze makro de wearden fan 'e ekspresjes mei har debug-foarstellingen drukke.
///
///
/// Lykas [`assert!`] hat dizze makro in twadde foarm, wêr't in oanpast panic-berjocht kin wurde levere.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // De hjirûnder weromlieningen binne opsetsin.
                    // Sûnder har wurdt it stackslot foar it lien initialisearre noch foardat de wearden wurde ferlike, wat liedt ta in opmerklike fertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // De hjirûnder weromlieningen binne opsetsin.
                    // Sûnder har wurdt it stackslot foar it lien initialisearre noch foardat de wearden wurde ferlike, wat liedt ta in opmerklike fertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Beweart dat twa útdrukkingen net gelyk binne oan elkoar (mei [`PartialEq`]).
///
/// Op panic sil dizze makro de wearden fan 'e ekspresjes mei har debug-foarstellingen drukke.
///
///
/// Lykas [`assert!`] hat dizze makro in twadde foarm, wêr't in oanpast panic-berjocht kin wurde levere.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // De hjirûnder weromlieningen binne opsetsin.
                    // Sûnder har wurdt it stackslot foar it lien initialisearre noch foardat de wearden wurde ferlike, wat liedt ta in opmerklike fertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // De hjirûnder weromlieningen binne opsetsin.
                    // Sûnder har wurdt it stackslot foar it lien initialisearre noch foardat de wearden wurde ferlike, wat liedt ta in opmerklike fertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Beweart dat in booleaanske ekspresje `true` is by runtime.
///
/// Dit sil de [`panic!`]-makro oproppe as de opjûne ekspresje net kin wurde evaluearre nei `true` by runtime.
///
/// Lykas [`assert!`] hat dizze makro ek in twadde ferzje, wêr't in oanpast panic-berjocht kin wurde levere.
///
/// # Uses
///
/// Oars as [`assert!`] binne `debug_assert!`-útspraken standert allinich ynskeakele yn net-optimisearre bouwurken.
/// In optimalisearre build sil `debug_assert!`-útspraken net útfiere, útsein as `-C debug-assertions` wurdt trochjûn oan 'e kompilearder.
/// Dit makket `debug_assert!` nuttich foar kontrôles dy't te djoer binne om oanwêzich te wêzen yn in release-build, mar kinne nuttich wêze by ûntwikkeling.
/// It resultaat fan útwreidzjen fan `debug_assert!` wurdt altyd type kontroleare.
///
/// In net-kontroleare bewearing lit in programma yn in inkonsekwint steat trochgean, wat unferwachte gefolgen kin hawwe, mar gjin ûnfeilichheid yntroduseart salang't dit allinich bart yn feilige koade.
///
/// De prestaasjekosten fan bewearingen binne lykwols algemien net mjitber.
/// [`assert!`] ferfange troch `debug_assert!` wurdt dus allinich stimulearre nei yngeande profilearjen, en wichtiger noch, allinich yn feilige koade!
///
/// # Examples
///
/// ```
/// // it berjocht panic foar dizze bewearingen is de strikte wearde fan 'e jûn ekspresje.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // in heul ienfâldige funksje
/// debug_assert!(some_expensive_computation());
///
/// // bewearje mei in oanpast berjocht
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Beweart dat twa útdrukkingen gelyk binne oan elkoar.
///
/// Op panic sil dizze makro de wearden fan 'e ekspresjes mei har debug-foarstellingen drukke.
///
/// Oars as [`assert_eq!`] binne `debug_assert_eq!`-útspraken standert allinich ynskeakele yn net-optimisearre bouwurken.
/// In optimalisearre build sil `debug_assert_eq!`-útspraken net útfiere, útsein as `-C debug-assertions` wurdt trochjûn oan 'e kompilearder.
/// Dit makket `debug_assert_eq!` nuttich foar kontrôles dy't te djoer binne om te wêzen yn in release-build, mar kinne nuttich wêze by ûntwikkeling.
///
/// It resultaat fan útwreidzjen fan `debug_assert_eq!` wurdt altyd type kontroleare.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Beweart dat twa útdrukkingen net gelyk binne oan elkoar.
///
/// Op panic sil dizze makro de wearden fan 'e ekspresjes mei har debug-foarstellingen drukke.
///
/// Oars as [`assert_ne!`] binne `debug_assert_ne!`-útspraken standert allinich ynskeakele yn net-optimisearre bouwurken.
/// In optimalisearre build sil `debug_assert_ne!`-útspraken net útfiere, útsein as `-C debug-assertions` wurdt trochjûn oan 'e kompilearder.
/// Dit makket `debug_assert_ne!` nuttich foar kontrôles dy't te djoer binne om oanwêzich te wêzen yn in release-build, mar kinne nuttich wêze by ûntwikkeling.
///
/// It resultaat fan útwreidzjen fan `debug_assert_ne!` wurdt altyd type kontroleare.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Jout werom oft de opjûne ekspresje oerienkomt mei ien fan 'e opjûne patroanen.
///
/// Lykas yn in `match`-ekspresje kin it patroan opsjoneel wurde folge troch `if` en in wachtekspresje dy't tagong hat ta nammen bûn troch it patroan.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Pakket in resultaat út of propageart har flater.
///
/// De `?`-operator waard tafoege om `try!` te ferfangen en soe ynstee moatte wurde brûkt.
/// Fierder is `try` in reservearre wurd yn Rust 2018, dus as jo it brûke moatte, moatte jo de [raw-identifier syntax][ris] brûke: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` komt oerien mei de opjûne [`Result`].Yn 't gefal fan' e `Ok`-fariant hat de útdrukking de wearde fan 'e ferpakte wearde.
///
/// Yn gefal fan 'e `Err`-fariant hellet it de ynderlike flater op.`try!` fiert dan konverzje út mei `From`.
/// Dit soarget foar automatyske konverzje tusken spesjale flaters en algemiene.
/// De resultearjende flater wurdt dan fuortendaliks weromjûn.
///
/// Fanwegen it betide weromkommen kin `try!` allinich brûkt wurde yn funksjes dy't [`Result`] werombringe.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // De foarkar metoade foar fluch weromkommende fouten
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // De foarige metoade foar fluch weromkommende fouten
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dit is lykweardich oan:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skriuwt opmakke gegevens yn in buffer.
///
/// Dizze makro aksepteart in 'writer', in opmaakstring en in list mei arguminten.
/// Arguminten sille wurde opmakke neffens de oantsjutte opmaakstring en it resultaat wurdt trochjûn oan de skriuwer.
/// De skriuwer kin elke wearde wêze mei in `write_fmt`-metoade;oer it algemien komt dit út in ymplemintaasje fan de [`fmt::Write`] as de [`io::Write`] trait.
/// De makro jout werom wat de `write_fmt`-metoade werombringt;faaks in [`fmt::Result`], as in [`io::Result`].
///
/// Sjoch [`std::fmt`] foar mear ynformaasje oer de syntaksis fan de snaarformaat.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// In module kin sawol `std::fmt::Write` as `std::io::Write` ymportearje en `write!` skilje op objekten dy't beide útfiere, om't objekten typysk beide net ymplementearje.
///
/// De module moat de kwalifisearre traits lykwols ymportearje, sadat har nammen net yn konflikt binne:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // brûkt fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // brûkt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Dizze makro kin ek brûkt wurde yn `no_std`-ynstellingen.
/// Yn in `no_std`-opset binne jo ferantwurdlik foar de ymplementaasjegegevens fan 'e komponinten.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skriuw opmakke gegevens yn in buffer, mei in nije line tafoege.
///
/// Op alle platfoarms is de nijline allinich it LINE FEED-karakter (`\n`/`U+000A`) allinich (gjin ekstra CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Sjoch [`write!`] foar mear ynformaasje.Foar ynformaasje oer de opmaak fan string syntaksis, sjoch [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// In module kin sawol `std::fmt::Write` as `std::io::Write` ymportearje en `write!` skilje op objekten dy't beide útfiere, om't objekten typysk beide net ymplementearje.
/// De module moat de kwalifisearre traits lykwols ymportearje, sadat har nammen net yn konflikt binne:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // brûkt fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // brûkt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Jout unberikbere koade oan.
///
/// Dit is nuttich elk momint dat de gearstaller net kin bepale dat guon koade net te berikken is.Bygelyks:
///
/// * Match earms mei beskermingsbetingsten.
/// * Loops dy't dynamysk beëindigje.
/// * Iterators dy't dynamysk beëindigje.
///
/// As de bepaling dat de koade ûnberikber is ferkeard bewiist, einiget it programma fuortendaliks mei in [`panic!`].
///
/// De ûnfeilige tsjinhinger fan dizze makro is de [`unreachable_unchecked`]-funksje, dy't ûnbeskreaun gedrach feroarsaket as de koade wurdt berikt.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dit sil altyd [`panic!`] wêze.
///
/// # Examples
///
/// Wedstriden earms:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompilear flater as kommentaar
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ien fan 'e earmste ymplementaasjes fan x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Jout unimplementearre koade oan yn panyk mei in berjocht fan "not implemented".
///
/// Hjirmei kin jo koade typekontrôle, wat nuttich is as jo in trait prototypearje of ymplementearje dy't meardere metoaden nedich binne wêr't jo net fan plan binne allegear te brûken.
///
/// It ferskil tusken `unimplemented!` en [`todo!`] is dat, wylst `todo!` in bedoeling oerbringt om de funksjonaliteit letter te ymplementearjen en it berjocht "not yet implemented" is, `unimplemented!` gjin sokke oanspraken makket.
/// It berjocht is "not implemented".
/// Ek guon IDE's sille 'todo! `S markearje.
///
/// # Panics
///
/// Dit sil altyd [`panic!`] wêze, om't `unimplemented!` gewoan in ôfkoarte is foar `panic!` mei in fêst, spesifyk berjocht.
///
/// Lykas `panic!` hat dizze makro in twadde foarm foar werjaan fan oanpaste wearden.
///
/// # Examples
///
/// Sis dat wy in trait `Foo` hawwe:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Wy wolle `Foo` foar 'MyStruct' ymplementearje, mar om ien of oare reden is it allinich logysk de `bar()`-funksje út te fieren.
/// `baz()` en `qux()` sille noch moatte wurde definieare yn ús ymplemintaasje fan `Foo`, mar wy kinne `unimplemented!` brûke yn har definysjes om ús koade te kompilearjen.
///
/// Wy wolle noch hawwe dat ús programma stopt mei draaien as de unimplementeare metoaden wurde berikt.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // It hat gjin sin om `baz` in `MyStruct` te hawwen, dat wy hawwe hjir hielendal gjin logika.
/////
///         // Dit sil "thread 'main' panicked at 'not implemented'" werjaan.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Wy hawwe hjir wat logika, Wy kinne in berjocht tafoegje oan unimplementeare!om ús weilitting wer te jaan.
///         // Dit sil werjaan: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Jout ûnfoltôge koade oan.
///
/// Dit kin nuttich wêze as jo prototypearje en gewoan sykje om jo koade typecheck te hawwen.
///
/// It ferskil tusken [`unimplemented!`] en `todo!` is dat, wylst `todo!` in bedoeling oerbringt om de funksjonaliteit letter te ymplementearjen en it berjocht "not yet implemented" is, `unimplemented!` gjin sokke oanspraken makket.
/// It berjocht is "not implemented".
/// Ek guon IDE's sille 'todo! `S markearje.
///
/// # Panics
///
/// Dit sil altyd [`panic!`] wêze.
///
/// # Examples
///
/// Hjir is in foarbyld fan guon koade yn oanrin.Wy hawwe in trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Wy wolle `Foo` ymplementearje op ien fan ús soarten, mar wy wolle ek earst oan gewoan `bar()` wurkje.Om ús koade te kompilearjen, moatte wy `baz()` ymplementearje, sadat wy `todo!` kinne brûke:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ymplemintaasje giet hjir
///     }
///
///     fn baz(&self) {
///         // lit ús no gjin soargen meitsje oer it útfieren fan baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // wy brûke baz() net iens, dus dit is prima.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definysjes fan ynboude makro's.
///
/// De measte makro-eigenskippen (stabiliteit, sichtberens, ensfh.) Wurde hjir fan 'e boarne koade nommen, mei útsûndering fan útwreidingsfunksjes dy't makro-yngongen feroarje yn útfier, dy funksjes wurde levere troch de gearstaller.
///
///
pub(crate) mod builtin {

    /// Feroaret kompilaasje mei it opjûne flaterberjocht as it tsjinkomt.
    ///
    /// Dizze makro moat brûkt wurde as in crate in betingste kompilaasjestrategy brûkt om bettere flaterberjochten te leverjen foar ferkearde omstannichheden.
    ///
    /// It is de kompiler-nivo foarm fan [`panic!`], mar stjoert in flater út by *kompilaasje* ynstee fan by *runtime*.
    ///
    /// # Examples
    ///
    /// Twa sokke foarbylden binne makro's en `#[cfg]`-omjouwings.
    ///
    /// Utstjoere bettere kompilearflater as in makro ûnjildige wearden wurdt trochjûn.
    /// Sûnder de definitive branch soe de gearstaller noch in flater útstjoere, mar it berjocht fan 'e flater neamt de twa jildige wearden net.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Kompilearflater emitearje as ien fan in oantal funksjes net beskikber is.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstrueart parameters foar de oare makro's foar tekenopmaak.
    ///
    /// Dizze makro funksjonearret troch in opmaakstring letterlik te nimmen mei `{}` foar elk trochjûn argumint.
    /// `format_args!` bereidt de ekstra parameters foar om derfoar te soargjen dat de útfier kin wurde ynterpretearre as in tekenrige en kanonisearet de arguminten yn ien type.
    /// Elke wearde dy't de [`Display`] trait ymplementeart, kin wurde trochjûn oan `format_args!`, lykas elke [`Debug`]-ymplemintaasje kin wurde trochjûn oan in `{:?}` binnen de opmaakstring.
    ///
    ///
    /// Dizze makro produseart in wearde fan it type [`fmt::Arguments`].Dizze wearde kin oerdroegen wurde oan de makro's binnen [`std::fmt`] foar it útfieren fan nuttige trochferwizing.
    /// Alle oare opmaakmakro's ([`opmaak!`], [`write!`], [`println!`], ensfh.) Wurde fia dizze folmakke.
    /// `format_args!`, yn tsjinstelling ta de ôflaat makro's, foarkomt heulallokaasjes.
    ///
    /// Jo kinne de [`fmt::Arguments`]-wearde brûke dy't `format_args!` weromkomt yn `Debug`-en `Display`-konteksten lykas hjirûnder te sjen.
    /// It foarbyld lit ek sjen dat `Debug`-en `Display`-formaat op itselde ding: de ynterpolearre opmaakstring yn `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Sjoch foar mear ynformaasje de dokumintaasje yn [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Itselde as `format_args`, mar foeget úteinlik in nije rigel ta.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ynspektearret in omjouwingsfariabele op kompilearjende tiid.
    ///
    /// Dizze makro sil op kompilearjende tiid útwreidzje nei de wearde fan 'e neamde omjouwingsfariabele, wat in ekspresje fan it type `&'static str` opsmyt.
    ///
    ///
    /// As de omjouwingsfariabele net is definieare, sil in kompilaasjeflater útstjoerd wurde.
    /// Om gjin kompilearfout út te stjoeren, brûk dan yn plak de [`option_env!`]-makro.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Jo kinne it flaterberjocht oanpasse troch in tekenrige as twadde parameter troch te jaan:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// As de `documentation`-omjouwingsfariabele net is definieare, krije jo de folgjende flater:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opsjonearret as opsje in omjouwingsfariabele op kompilearjende tiid.
    ///
    /// As de neamde omjouwingsfariabele oanwêzich is by it kompilearjen, sil dizze útwreidzje nei in útdrukking fan type `Option<&'static str>` wêrfan de wearde `Some` is fan 'e wearde fan' e omjouwingsfariabele.
    /// As de omjouwingsfariabele net oanwêzich is, sil dit útwreidzje nei `None`.
    /// Sjoch [`Option<T>`][Option] foar mear ynformaasje oer dit type.
    ///
    /// In kompilearingsfout wurdt nea útstjoerd by it brûken fan dizze makro, likefolle oft de omjouwingsfariabele oanwêzich is of net.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ferbine identifiers yn ien identifier.
    ///
    /// Dizze makro nimt in oantal komma-skieden identifiers, en ferbynt se allegear ta ien, wat in útdrukking oplevert dy't in nije identifier is.
    /// Tink derom dat hygiëne it sa makket dat dizze makro lokale fariabelen net kin fêstlizze.
    /// Ek, as algemiene regel, binne makro's allinich tastien yn posysje fan artikel, ferklearring as ekspresje.
    /// Dat betsjut dat jo dizze makro kinne brûke foar ferwize nei besteande fariabelen, funksjes of modules ensfh., Jo kinne der lykwols gjin nije mei definiearje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nij, wille, namme) { }//net brûkber op dizze manier!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ferbûn literêre ta in statyske tekenrige.
    ///
    /// Dizze makro nimt in oantal komma-skieden lettertekens, wat in útdrukking oplevert fan it type `&'static str` dat alle lettertekens fan links nei rjochts fertsjintwurdiget.
    ///
    ///
    /// Heel-en driuwende letterliteraren wurde stringeare om te wurde ferbûn.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Wreidet út nei it rigelnûmer wêrop it waard oproppen.
    ///
    /// Mei [`column!`] en [`file!`] leverje dizze makro's ynformaasje foar debuggen foar ûntwikkelders oer de lokaasje binnen de boarne.
    ///
    /// De útwreide ekspresje hat type `u32` en is 1-basearre, sadat de earste rigel yn elk bestân evalueart nei 1, de twadde nei 2, ensfh.
    /// Dit is konsekwint mei flaterberjochten troch mienskiplike gearstallers as populêre bewurkers.
    /// De weromkommende line is *net needsaaklik* de line fan 'e `line!`-oanroppen sels, mar earder de earste makro-oanropping dy't liedt ta de oanroppen fan' e `line!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Wreidet út nei it kolumnûmer wêrop it waard oproppen.
    ///
    /// Mei [`line!`] en [`file!`] leverje dizze makro's feilsokingsynformaasje foar ûntwikkelders oer de lokaasje binnen de boarne.
    ///
    /// De útwreide ekspresje hat type `u32` en is 1-basearre, sadat de earste kolom yn elke regel evalueart nei 1, de twadde nei 2, ensfh.
    /// Dit is konsekwint mei flaterberjochten troch mienskiplike gearstallers as populêre bewurkers.
    /// De weromkommen kolom is *net needsaaklik* de line fan 'e `column!`-oanroppen sels, mar earder de earste makro-oanropping dy't liedt ta de oanroppen fan' e `column!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Wreidet út nei de bestânsnamme wêrop it waard oproppen.
    ///
    /// Mei [`line!`] en [`column!`] leverje dizze makro's ynformaasje foar debuggen foar ûntwikkelders oer de lokaasje binnen de boarne.
    ///
    /// De útwreide ekspresje hat type `&'static str`, en it weromkommen bestân is net de oanroppen fan 'e `file!`-makro sels, mar earder de earste makro-oanropping dy't liedt ta de oanroppen fan' e `file!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Strijkt har arguminten.
    ///
    /// Dizze makro sil in ekspresje opleverje fan it type `&'static str`, dat is de stringifikaasje fan alle tokens dy't trochjûn binne oan 'e makro.
    /// Gjin beheiningen wurde pleatst op 'e syntaksis fan' e makro-oanroppen sels.
    ///
    /// Tink derom dat de útwreide resultaten fan 'e ynput tokens kinne feroarje yn' e future.Jo moatte foarsichtich wêze as jo fertrouwe op 'e útfier.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Omfettet in UTF-8 kodearre bestân as string.
    ///
    /// It bestân leit relatyf oan it hjoeddeiske bestân (lykas hoe't modules wurde fûn).
    /// It levere paad wurdt op kompilaasjetiid op in platfoarmspesifike manier ynterpretearre.
    /// Dat, bygelyks, in oanroppen mei in Windows-paad mei efterút skruten `\` soe net goed kompilearje op Unix.
    ///
    ///
    /// Dizze makro sil in ekspresje opleverje fan it type `&'static str` dat de ynhâld fan it bestân is.
    ///
    /// # Examples
    ///
    /// Stel dat d'r twa bestannen binne yn deselde map mei de folgjende ynhâld:
    ///
    /// Bestân 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Bestân 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' kompilearje en it resultearjende binêre útfiere sil "adiós" ôfdrukke.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Befettet in bestân as ferwizing nei in byte-array.
    ///
    /// It bestân leit relatyf oan it hjoeddeiske bestân (lykas hoe't modules wurde fûn).
    /// It levere paad wurdt op kompilaasjetiid op in platfoarmspesifike manier ynterpretearre.
    /// Dat, bygelyks, in oanroppen mei in Windows-paad mei efterút skruten `\` soe net goed kompilearje op Unix.
    ///
    ///
    /// Dizze makro sil in ekspresje opleverje fan it type `&'static [u8; N]` dat de ynhâld fan it bestân is.
    ///
    /// # Examples
    ///
    /// Stel dat d'r twa bestannen binne yn deselde map mei de folgjende ynhâld:
    ///
    /// Bestân 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Bestân 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' kompilearje en it resultearjende binêre útfiere sil "adiós" ôfdrukke.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Wreidet út nei in tekenrige dy't it hjoeddeistige modelpaad fertsjintwurdiget.
    ///
    /// It hjoeddeistige modelpaad kin beskôge wurde as de hiërargy fan modules dy't weromlûke nei de crate root.
    /// De earste komponint fan it weromkommen paad is de namme fan 'e crate dy't op it stuit wurdt kompileare.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evalueart booleaanske kombinaasjes fan konfiguraasjeflaggen op kompilaasjetiid.
    ///
    /// Neist it `#[cfg]`-attribút is dizze makro foarsjoen om booleaanske ekspresje-evaluaasje fan konfiguraasjeflaggen mooglik te meitsjen.
    /// Dit liedt faaks ta minder duplikaat koade.
    ///
    /// De syntaksis jûn oan dizze makro is deselde syntaksis as it [`cfg`]-attribút.
    ///
    /// `cfg!`, yn tsjinstelling ta `#[cfg]`, ferwideret gjin koade en evalueart allinich nei wier as net.
    /// Bygelyks, alle blokken yn in if/else-útdrukking moatte jildich wêze as `cfg!` wurdt brûkt foar de tastân, ûnôfhinklik fan wat `cfg!` evalueart.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Untleest in bestân as ekspresje as in item neffens de kontekst.
    ///
    /// It bestân leit relatyf oan it hjoeddeiske bestân (lykas hoe't modules wurde fûn).It levere paad wurdt op kompilaasjetiid op in platfoarmspesifike manier ynterpretearre.
    /// Dat, bygelyks, in oanroppen mei in Windows-paad mei efterút skruten `\` soe net goed kompilearje op Unix.
    ///
    /// It brûken fan dizze makro is faaks in min idee, want as it bestân wurdt analysearre as útdrukking, sil it ûnhygiënysk yn 'e omlizzende koade wurde pleatst.
    /// Dit kin resultearje yn fariabelen of funksjes dy't oars binne as wat it bestân ferwachte as d'r fariabelen of funksjes binne dy't deselde namme hawwe yn it hjoeddeiske bestân.
    ///
    ///
    /// # Examples
    ///
    /// Stel dat d'r twa bestannen binne yn deselde map mei de folgjende ynhâld:
    ///
    /// Bestân 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Bestân 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' kompilearje en it resultearjende binêre útfiere sil "🙈🙊🙉🙈🙊🙉" ôfdrukke.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Beweart dat in booleaanske ekspresje `true` is by runtime.
    ///
    /// Dit sil de [`panic!`]-makro oproppe as de opjûne ekspresje net kin wurde evaluearre nei `true` by runtime.
    ///
    /// # Uses
    ///
    /// Bewearingen wurde altyd kontroleare yn sawol debug-as release-builds, en kinne net útskeakele wurde.
    /// Sjoch [`debug_assert!`] foar bewearingen dy't standert net binne ynskeakele yn release builds.
    ///
    /// Unfeilige koade kin op `assert!` fertrouwe om run-time invarianten ôf te twingen dy't, as oertrêdde, kin liede ta ûnfeiligens.
    ///
    /// Oare gebrûksgefallen fan `assert!` omfetsje testen en hanthavenjen fan run-time invariants yn feilige koade (wêrfan oertreding net kin resultearje yn ûnfeiligens).
    ///
    ///
    /// # Oanpaste berjochten
    ///
    /// Dizze makro hat in twadde foarm, wêr't in oanpast panic-berjocht kin wurde levere mei of sûnder arguminten foar opmaak.
    /// Sjoch [`std::fmt`] foar syntaksis foar dit formulier.
    /// Ekspresjes brûkt as opmaakarguminten wurde allinich evaluearre as de bewearing mislearret.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // it berjocht panic foar dizze bewearingen is de strikte wearde fan 'e jûn ekspresje.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // in heul ienfâldige funksje
    ///
    /// assert!(some_computation());
    ///
    /// // bewearje mei in oanpast berjocht
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline gearkomste.
    ///
    /// Lês de [unstable book] foar it gebrûk.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Inline assemblage yn LLVM-styl.
    ///
    /// Lês de [unstable book] foar it gebrûk.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline-assemblage op module-nivo.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints hawwe tokens trochjûn yn 'e standertútfier.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Skakelt trasearringsfunksjonaliteit yn of út om te brûken foar it debuggen fan oare makro's.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attribútmakro brûkt foar it tapassen fan ôfliede makro's.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attribútmakro tapast op in funksje om dizze yn ienheidstest te meitsjen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attribútmakro tapast op in funksje om dizze yn in benchmarktest te meitsjen.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// In ymplemintaasjedetail fan 'e `#[test]`-en `#[bench]`-makro's.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attribútmakro tapast op in statyk om it te registrearjen as in globale allocator.
    ///
    /// Sjoch ek [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Hâldt it item dat it is tapast op as it trochgeande paad tagonklik is, en ferwideret it oars.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Wreidet alle `#[cfg]`-en `#[cfg_attr]`-attributen út yn it koade fragmint dat it is tapast op.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ynstabyl ymplemintaasjedetail fan 'e `rustc`-kompilearder, net brûke.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ynstabyl ymplemintaasjedetail fan 'e `rustc`-kompilearder, net brûke.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}