//! Dizze module ymplementeart de `Any` trait, wêrtroch dynamysk typen fan elk `'static`-type mooglik is fia refleksje fan runtime.
//!
//! `Any` sels kin brûkt wurde om in `TypeId` te krijen, en hat mear funksjes as brûkt as trait-objekt.
//! As `&dyn Any` (in liend trait-objekt) hat it de metoaden `is` en `downcast_ref`, om te testen as de befette wearde fan in bepaald type is, en om in ferwizing te krijen nei de ynderlike wearde as type.
//! As `&mut dyn Any` is d'r ek de `downcast_mut`-metoade, om in feroarbere ferwizing nei de ynderlike wearde te krijen.
//! `Box<dyn Any>` foeget de `downcast`-metoade ta, dy't besiket te konvertearjen nei in `Box<T>`.
//! Sjoch de [`Box`] dokumintaasje foar de folsleine details.
//!
//! Tink derom dat `&dyn Any` is beheind ta testen oft in wearde fan in spesifisearre betontype is, en kin net brûkt wurde om te testen oft in type in trait ymplementeart.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers en `dyn Any`
//!
//! Ien gedrach om te ûnthâlden by it brûken fan `Any` as trait-objekt, fral mei typen lykas `Box<dyn Any>` of `Arc<dyn Any>`, is dat gewoanwei `.type_id()` op 'e wearde neamt de `TypeId` fan' e *container* sil produsearje, net it ûnderlizzende trait-objekt.
//!
//! Dit kin foarkommen wurde troch de tûke oanwizer yn plak fan in `&dyn Any` te konvertearjen, wêrtroch it `TypeId` fan it objekt weromkomt.
//! Bygelyks:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Jo wolle dit wierskynliker wolle:
//! let actual_id = (&*boxed).type_id();
//! // ... dan dit:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tink oan in situaasje wêr't wy in wearde wolle útfiere dy't trochjûn is oan in funksje.
//! Wy kenne de wearde wêr't wy oan wurkje, Debug implementeart, mar wy kenne it konkrete type net.Wy wolle spesjale behanneling jaan oan bepaalde soarten: yn dit gefal de lingte fan stringwearden ôfdrukke foarôfgeand oan har wearde.
//! Wy kenne it konkrete type fan ús wearde net op kompilearjende tiid, dus moatte wy ynstee runtime refleksje brûke.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Loggerfunksje foar elk type dat Debug implementeart.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Besykje ús wearde te konvertearjen nei in `String`.
//!     // As suksesfol, wolle wy de lingte fan 'e string lykas de wearde derfan útfiere.
//!     // As net, dan is it in oar type: druk it gewoan unversierd út.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Dizze funksje wol syn parameter útlogge foardat se der wurk mei dogge.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... wat oar wurk dwaan
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Eltse trait
///////////////////////////////////////////////////////////////////////////////

/// In trait om dynamysk typen te emulearjen.
///
/// De measte soarten ymplementearje `Any`.Elk type dat in net-'statyske 'referinsje befettet, docht dat lykwols net.
/// Sjoch de [module-level documentation][mod] foar mear details.
///
/// [mod]: crate::any
// Dizze trait is net ûnfeilich, hoewol wy fertrouwe op 'e spesifikaasjes fan' e `type_id`-funksje fan 'e ienige ympl yn unfeilige koade (bgl. `downcast`).Normaal soe dat in probleem wêze, mar om't de iennichste ympl fan `Any` in tekken ymplemintaasje is, kin gjin oare koade `Any` útfiere.
//
// Wy koene dizze trait wierskynlik ûnfeilich meitsje-it soe gjin brek feroarsaakje, om't wy alle ymplementaasjes kontrolearje-mar wy kieze net, om't dat beide net echt needsaaklik is en brûkers ferwiderje kinne oer it ûnderskied fan ûnfeilige traits en ûnfeilige metoaden (ie `type_id` soe noch feilich wêze om te skiljen, mar wy wolle wierskynlik as sadanich oanjaan yn dokumintaasje).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Krij de `TypeId` fan `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Utwreidingsmetoaden foar alle trait-objekten.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Soargje derfoar dat it resultaat fan bgl., Oanslute by in tried kin wurde printe en dêrmei brûkt wurde mei `unwrap`.
// Kin úteinlik net langer nedich wêze as ferstjoering wurket mei opcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Jout `true` werom as it ynbakke type itselde is as `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Krij `TypeId` fan it type wêrmei dizze funksje wurdt instantieare.
        let t = TypeId::of::<T>();

        // Krij `TypeId` fan it type yn it trait-objekt (`self`).
        let concrete = self.type_id();

        // Fergelykje beide `TypeId`s oer gelikensens.
        t == concrete
    }

    /// Jout werom wat referinsje nei de bokswearde as it fan type `T` is, of `None` as dat net is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // VEILIGHEID: gewoan kontroleare oft wy nei it juste type wize, en wy kinne op fertrouwe
            // dat kontrolearje op geheugenfeiligens, om't wy Any hawwe ymplementeare foar alle soarten;gjin oare ymplen kinne bestean, om't se konflikt hawwe mei ús ympl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Jout wat mutabele ferwizing nei de ynbakke wearde as it fan type `T` is, of `None` as dat net is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // VEILIGHEID: gewoan kontroleare oft wy nei it juste type wize, en wy kinne op fertrouwe
            // dat kontrolearje op geheugenfeiligens, om't wy Any hawwe ymplementeare foar alle soarten;gjin oare ymplen kinne bestean, om't se konflikt hawwe mei ús ympl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Trochstjoert nei de metoade definieare op it type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID en har metoaden
///////////////////////////////////////////////////////////////////////////////

/// In `TypeId` fertsjintwurdiget in wrâldwide unike identifier foar in type.
///
/// Elke `TypeId` is in ûntrochsichtich objekt dat gjin ynspeksje fan wat deryn stiet mooglik makket, mar basale operaasjes lykas kloning, fergeliking, printsjen en werjaan mooglik makket.
///
///
/// In `TypeId` is op it stuit allinich beskikber foar typen dy't oan `'static` tajaan, mar dizze beheining kin wurde ferwidere yn 'e future.
///
/// Wylst `TypeId` `Hash`, `PartialOrd` en `Ord` ymplementeart, is it de muoite wurdich opskriuwen dat de hashes en oarder sille fariearje tusken Rust releases.
/// Pas op om op har te fertrouwen binnen jo koade!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Jout de `TypeId` werom fan it type wêrmei't dizze generike funksje is instantieare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Jout de namme fan in type werom as tekenrige.
///
/// # Note
///
/// Dit is bedoeld foar diagnostyk gebrûk.
/// De krekte ynhâld en de opmaak fan 'e weromkommende tekenrige wurde net oantsjutte, oars as in best-ynspanning beskriuwing fan it type.
/// Bygelyks ûnder de snaren dy't `type_name::<Option<String>>()` werom kinne komme, binne `"Option<String>"` en `"std::option::Option<std::string::String>"`.
///
///
/// De weromkommende tekenrige moat net beskôge wurde as in unike identifier fan in type, om't meardere soarten kinne mapje oan deselde type namme.
/// Likemin is d'r gjin garânsje dat alle ûnderdielen fan in type ferskine yn 'e weromkommende tekenrige: bygelyks spesifikaasjes foar libben binne op it stuit net opnommen.
/// Derneist kin de útfier feroarje tusken ferzjes fan 'e kompilearder.
///
/// De hjoeddeistige ymplemintaasje brûkt deselde ynfrastruktuer as kompileardiagnostyk en debuginfo, mar dit is net garandearre.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Jout de namme werom fan it type fan de oanwiisde wearde as in tekenrige.
/// Dit is itselde as `type_name::<T>()`, mar kin brûkt wurde wêr't it type fan in fariabele net maklik te krijen is.
///
/// # Note
///
/// Dit is bedoeld foar diagnostyk gebrûk.De krekte ynhâld en opmaak fan 'e tekenrige wurde net oantsjutte, oars as in beskriuwing fan it type mei bêste ynspanning.
/// Bygelyks, `type_name_of_val::<Option<String>>(None)` koe `"Option<String>"` as `"std::option::Option<std::string::String>"` weromjaan, mar net `"foobar"`.
///
/// Derneist kin de útfier feroarje tusken ferzjes fan 'e kompilearder.
///
/// Dizze funksje lost trait-objekten net op, wat betsjut dat `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` kin werombringe, mar net `"u32"`.
///
/// De type namme moat net wurde beskôge as in unike identifier fan in type;
/// meardere soarten kinne deselde type namme diele.
///
/// De hjoeddeistige ymplemintaasje brûkt deselde ynfrastruktuer as kompileardiagnostyk en debuginfo, mar dit is net garandearre.
///
/// # Examples
///
/// Printset de standert gehiel-en floatsoarten ôf.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}