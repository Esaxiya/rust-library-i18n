use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` mar net-nul en kovariant.
///
/// Dit is faaks it juste ding om te brûken by it bouwen fan datastruktueren mei rauwe oanwizers, mar is úteinlik gefaarliker te brûken fanwegen de ekstra eigenskippen.As jo net wis binne as jo `NonNull<T>` brûke moatte, brûk dan gewoan `*mut T`!
///
/// Oars as `*mut T`, moat de oanwizer altyd net-nul wêze, sels as de oanwizer nea wurdt ferwidere.Dit is sa dat enums dizze ferbeane wearde kinne brûke as diskriminant-`Option<NonNull<T>>` hat deselde grutte as `* mut T`.
/// De oanwizer kin lykwols noch hingje as it net wurdt ferwidere.
///
/// Oars as `*mut T` waard `NonNull<T>` keazen om kovariant te wêzen boppe `T`.Dit makket it mooglik om `NonNull<T>` te brûken by it bouwen fan kovariant-typen, mar yntroduseart it risiko fan sûnens as brûkt yn in type dat eins net kovariant wêze moat.
/// (De tsjinoerstelde kar waard makke foar `*mut T`, hoewol technysk koe de ûngerêstens allinich wurde feroarsake troch ûnfeilige funksjes oan te roppen.)
///
/// Kovariânsje is korrekt foar de measte feilige abstraksjes, lykas `Box`, `Rc`, `Arc`, `Vec`, en `LinkedList`.Dit is it gefal om't se in iepenbiere API leverje dy't de normale dielde XOR mutabele regels fan Rust folget.
///
/// As jo type net feilich kovariant kin wêze, moatte jo derfoar soargje dat it wat ekstra fjild befettet om invariânsje te leverjen.Faak sil dit fjild in [`PhantomData`]-type wêze lykas `PhantomData<Cell<T>>` of `PhantomData<&'a mut T>`.
///
/// Merken dat `NonNull<T>` in `From`-eksimplaar foar `&T` hat.Dit feroaret lykwols net it feit dat mutearjen troch in (oanwizer ôflaat fan in) dielde referinsje undefined gedrach is, útsein as de mutaasje bart yn in [`UnsafeCell<T>`].Itselde jildt foar it meitsjen fan in feroarbere referinsje út in dielde referinsje.
///
/// As jo dit `From`-eksimplaar brûke sûnder in `UnsafeCell<T>`, is it jo ferantwurdlikens te soargjen dat `as_mut` nea wurdt neamd, en `as_ptr` wurdt noait brûkt foar mutaasje.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointers binne net `Send`, om't de gegevens dy't se ferwize, alias wêze kinne.
// NB, dizze impl is net nedich, mar moat bettere flaterberjochten leverje.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers binne net `Sync`, om't de gegevens dy't se ferwize, alias wêze kinne.
// NB, dizze impl is net nedich, mar moat bettere flaterberjochten leverje.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Makket in nije `NonNull` oan dy't hinget, mar goed oanpast is.
    ///
    /// Dit is nuttich foar it initialisearjen fan soarten dy't lui tawize, lykas `Vec::new` docht.
    ///
    /// Tink derom dat de oanwizerwearde mooglik in jildige oanwizer foar in `T` kin fertsjintwurdigje, wat betsjut dat dit net moat wurde brûkt as in "not yet initialized"-sentinelwearde.
    /// Soarten dy't lui tawize, moatte inisjalisaasje folgje op oare manieren.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() retourneert in net-nul usize dy't dan wurdt getten
        // nei in * mut T.
        // Dêrom is `ptr` net nul en wurde de betingsten foar it skiljen fan new_unchecked() respekteare.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Jout in dielde ferwizings nei de wearde.Yn tsjinstelling ta [`as_ref`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Jout in unike ferwizings nei de wearde.Yn tsjinstelling ta [`as_mut`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Makket in nije `NonNull` oan.
    ///
    /// # Safety
    ///
    /// `ptr` moat net-nul wêze.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: de beller moat garandearje dat `ptr` net-nul is.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Makket in nije `NonNull` oan as `ptr` net-nul is.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: De oanwizer is al hifke en is net nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Fiert deselde funksjonaliteit as [`std::ptr::from_raw_parts`], útsein dat in `NonNull`-oanwizer wurdt weromjûn, yn tsjinstelling ta in rauwe `*const`-oanwizer.
    ///
    ///
    /// Sjoch de dokumintaasje fan [`std::ptr::from_raw_parts`] foar mear details.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // VEILIGHEID: It resultaat fan `ptr::from::raw_parts_mut` is net-nul omdat `data_address` is.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Dekomponearje in (mooglik brede) oanwizer yn is adres-en metadatakomponinten.
    ///
    /// De oanwizer kin letter wurde rekonstruearre mei [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Krijt de ûnderlizzende `*mut`-oanwizer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Jout in dielde ferwizing nei de wearde.As de wearde uninitialisearre is, moat [`as_uninit_ref`] yn plak wurde brûkt.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * De oanwizer moat wize op in inisjalisearre eksimplaar fan `T`.
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    /// (It diel oer inisjalisearjen is noch net folslein besletten, mar oant it is, is de iennichste feilige oanpak om te soargjen dat se yndie wurde inisjalisearre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        unsafe { &*self.as_ptr() }
    }

    /// Jout in unike ferwizing nei de wearde.As de wearde uninitialisearre is, moat [`as_uninit_mut`] yn plak wurde brûkt.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * De oanwizer moat wize op in inisjalisearre eksimplaar fan `T`.
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    /// (It diel oer inisjalisearjen is noch net folslein besletten, mar oant it is, is de iennichste feilige oanpak om te soargjen dat se yndie wurde inisjalisearre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in feroarbere referinsje.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werpt nei in oanwizer fan in oar type.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // VEILIGHEID: `self` is in `NonNull`-oanwizer dy't needsaaklik net null is
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Makket in net-nul rau plak út in tinne oanwizer en in lingte.
    ///
    /// It `len`-argumint is it oantal **eleminten**, net it oantal bytes.
    ///
    /// Dizze funksje is feilich, mar it ferwiderjen fan 'e weromwearde is ûnfeilich.
    /// Sjoch de dokumintaasje fan [`slice::from_raw_parts`] foar easken foar feiligens fan plakken.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // meitsje in snijpointer as jo begjinne mei in oanwizer nei it earste elemint
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Tink derom dat dit foarbyld keunstmjittich in gebrûk fan dizze metoade demonstreart, mar `lit slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // VEILIGHEID: `data` is in `NonNull`-oanwizer dy't needsaaklik net null is
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Jout de lingte fan in net-rau plak.
    ///
    /// De weromkommende wearde is it oantal **eleminten**, net it oantal bytes.
    ///
    /// Dizze funksje is feilich, sels as de net-nul rauwe plak net kin wurde ferwidere ta in stik omdat de oanwizer gjin jildich adres hat.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Jout in net-nul oanwizer nei de buffer fan it stik.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // VEILIGHEID: Wy witte dat `self` net-nul is.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Jout in rauwe oanwizer nei de buffer fan it stik.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Jout in dielde ferwizing nei in stikje mooglik uninitialisearre wearden.Yn tsjinstelling ta [`as_ref`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat [valid] wêze foar lêzen foar `ptr.len() * mem::size_of::<T>()` in protte bytes, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
    ///
    ///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
    ///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.
    ///
    ///     * De oanwizer moat sels wurde ôfstimd foar plakjes mei nul-lingte.
    ///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
    ///
    ///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
    ///
    /// * De totale grutte `ptr.len() * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
    ///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// Sjoch ek [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `as_uninit_slice` hanthavenje.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Jout in unike ferwizing nei in stikje mooglik uninitialisearre wearden.Yn tsjinstelling ta [`as_mut`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// As jo dizze metoade neame, moatte jo derfoar soargje dat al it folgjende wier is:
    ///
    /// * De oanwizer moat [valid] wêze foar in soad bytes foar lêzen en skriuwen foar `ptr.len() * mem::size_of::<T>()`, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
    ///
    ///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
    ///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.
    ///
    ///     * De oanwizer moat sels wurde ôfstimd foar plakjes mei nul-lingte.
    ///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
    ///
    ///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
    ///
    /// * De totale grutte `ptr.len() * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
    ///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// Sjoch ek [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dit is feilich, om't `memory` in soad bytes jildich is foar lêzen en skriuwen foar `memory.len()`.
    /// // Tink derom dat hjir `memory.as_mut()` belje is net tastien, om't de ynhâld uninitialisearre kin wêze.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `as_uninit_slice_mut` hanthavenje.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Jout in rauwe oanwizer werom nei in elemint of subslice, sûnder grinzen te kontrolearjen.
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen of as `self` net te ferwiderjen is, is *[undefined behavior]*, sels as de resultearjende oanwizer net wurdt brûkt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: de beller soarget derfoar dat `self` derferenberber is en `index` binnen de grinzen is.
        // As konsekwinsje kin de resultearjende oanwizer net NULL wêze.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // VEILIGHEID: In unike oanwizer kin net nul wêze, dus de betingsten foar
        // new_unchecked() wurde respekteare.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: In feroarbere referinsje kin net nul wêze.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // VEILIGHEID: In referinsje kin net nul wêze, dus de betingsten foar
        // new_unchecked() wurde respekteare.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}