#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Jout it oanwizer-metadatatype fan elk type oanwiisd.
///
/// # Oanwizer metadata
///
/// Rauwe oanwizerssoarten en referinsjetypes yn Rust kinne wurde beskôge as makke fan twa dielen:
/// in gegevenspointer dy't it ûnthâldadres fan 'e wearde befettet, en wat metadata.
///
/// Foar statyske grutte typen (dy't de `Sized` traits ymplementearje) en ek foar `extern`-soarten, wurde oanwizers sein "dun": metadata binne nulgrutte en it type is `()`.
///
///
/// Oanwizers nei [dynamically-sized types][dst] wurde sein dat se "breed" of "fet" binne, se hawwe metadata fan net-grutte:
///
/// * Foar structs wêrfan it lêste fjild in DST is, binne metadata de metadata foar it lêste fjild
/// * Foar it `str`-type binne metadata de lingte yn bytes as `usize`
/// * Foar skyfsoarten lykas `[T]` binne metadata de lingte yn items as `usize`
/// * Foar objekten fan trait lykas `dyn SomeTrait` binne metadata [`DynMetadata<Self>`][DynMetadata] (bgl. `DynMetadata<dyn SomeTrait>`)
///
/// Yn 'e future kin de taal Rust nije soarten soarten krije dy't ferskate metadata foar pointer hawwe.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # De `Pointee` trait
///
/// It punt fan dizze trait is it `Metadata` assosjeare type, dat is `()` of `usize` of `DynMetadata<_>` lykas hjirboppe beskreaun.
/// It wurdt automatysk ymplementeare foar elk type.
/// It kin oannommen wurde ymplementeare yn in generike kontekst, sels sûnder in oerienkommende grins.
///
/// # Usage
///
/// Raw pointers kinne wurde ûntbûn yn it gegevensadres en metadatakomponinten mei har [`to_raw_parts`]-metoade.
///
/// Alternatyf kinne metadata allinich wurde ekstraheare mei de [`metadata`]-funksje.
/// In referinsje kin wurde oerdroegen oan [`metadata`] en ymplisyt twongen.
///
/// In (possibly-wide)-oanwizer kin werombrocht wurde fanút syn adres en metadata mei [`from_raw_parts`] of [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// It type foar metadata yn pointers en ferwizings nei `Self`.
    #[lang = "metadata_type"]
    // NOTE: Hâld trait bounds yn `static_assert_expected_bounds_for_metadata`
    //
    // yn `library/core/src/ptr/metadata.rs` yn syngronisaasje mei dy hjir:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Oanwizings foar soarten dy't dizze trait-alias ymplementearje binne "tin".
///
/// Dit omfettet statysk-Sized-typen en `extern`-typen.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabilisearje dit net foardat trait-aliassen stabyl binne yn 'e taal?
pub trait Thin = Pointee<Metadata = ()>;

/// Pak de metadatakomponint fan in oanwizer út.
///
/// Wearden fan type `*mut T`, `&T` of `&mut T` kinne direkt nei dizze funksje wurde trochjûn, om't se ymplisyt twinge nei `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // VEILIGHEID: Tagong ta de wearde fan 'e `PtrRepr`-uny is feilich sûnt * konst T
    // en PtrComponents<T>hawwe deselde ûnthâldlay-outs.
    // Allinich std kin dizze garânsje meitsje.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Foarmet in (possibly-wide) rauwe oanwizer fanút in gegevensadres en metadata.
///
/// Dizze funksje is feilich, mar de weromwizende oanwizer is net needsaaklik feilich foar ferwidering.
/// Sjoch foar dokuminten de dokumintaasje fan [`slice::from_raw_parts`] foar feiligenseasken.
/// Foar trait-objekten moatte de metadata komme fan in oanwizer nei itselde ûnderlizzende ferwidere type.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // VEILIGHEID: Tagong ta de wearde fan 'e `PtrRepr`-uny is feilich sûnt * konst T
    // en PtrComponents<T>hawwe deselde ûnthâldlay-outs.
    // Allinich std kin dizze garânsje meitsje.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Fiert deselde funksjonaliteit as [`from_raw_parts`], útsein dat in rauwe `*mut`-oanwizer wurdt weromjûn, yn tsjinstelling ta in rauwe `* const`-oanwizer.
///
///
/// Sjoch de dokumintaasje fan [`from_raw_parts`] foar mear details.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // VEILIGHEID: Tagong ta de wearde fan 'e `PtrRepr`-uny is feilich sûnt * konst T
    // en PtrComponents<T>hawwe deselde ûnthâldlay-outs.
    // Allinich std kin dizze garânsje meitsje.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Hânlieding impl nedich om `T: Copy` bûn te foarkommen.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Hânlieding impl nedich om `T: Clone` bûn te foarkommen.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// De metadata foar in `Dyn = dyn SomeTrait` trait-objekttype.
///
/// It is in oanwizer nei in vtabel (firtuele oproptabel) dy't alle nedige ynformaasje fertsjintwurdiget om it konkrete type te bewurkjen yn in trait-objekt.
/// De vtabel befettet benammen:
///
/// * type grutte
/// * type ôfstimming
/// * in oanwizer nei it type `drop_in_place` impl (kin in no-op wêze foar gewoane-âlde-gegevens)
/// * oanwizings foar alle metoaden foar it útfieren fan it type trait
///
/// Tink derom dat de earste trije spesjaal binne, om't se nedich binne om elk trait-objekt te allocearjen, te dropjen en te hanneljen.
///
/// It is mooglik om dizze struktuer te neamen mei in type parameter dy't gjin `dyn` trait-objekt is (bygelyks `DynMetadata<u64>`), mar gjin betsjuttingswearde fan dizze struktuer te krijen.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// It mienskiplike foarheaksel fan alle tabellen.It wurdt folge troch funksje-oanwizings foar trait-metoaden.
///
/// Privee útfiering detail fan `DynMetadata::size_of` ensfh.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Jout de grutte werom fan it type dat ferbûn is mei dizze vtabel.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Jout de ôfstimming fan it type dat ferbûn is mei dizze vtabel.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Jout de grutte en de útrjochting tegearre werom as in `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // VEILIGHEID: de gearstaller stjoerde dizze vtabel út foar in konkreet Rust-type dat
        // is bekend in jildige opmaak te hawwen.Deselde reden as yn `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Hânlieding nedich om `Dyn: $Trait`-grinzen te foarkommen.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}