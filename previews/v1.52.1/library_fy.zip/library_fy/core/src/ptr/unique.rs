use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// In omslach om in rau net-nul `*mut T` dy't oanjout dat de besitter fan dizze omslach de referint hat.
/// Nuttich foar it bouwen fan abstraksjes lykas `Box<T>`, `Vec<T>`, `String`, en `HashMap<K, V>`.
///
/// Oars as `*mut T` gedraacht `Unique<T>` "as if", it wie in eksimplaar fan `T`.
/// It ymplementeart `Send`/`Sync` as `T` `Send`/`Sync` is.
/// It ympliseart ek de soarte fan sterke aliasing garandeart in eksimplaar fan `T` kin ferwachtsje:
/// de referint fan 'e oanwizer moat net wizige wurde sûnder in unyk paad nei it besit fan Unyk.
///
/// As jo net wis binne of it korrekt is om `Unique` foar jo doelen te brûken, beskôgje dan `NonNull` te brûken, dy't swakkere semantyk hat.
///
///
/// Oars as `*mut T`, moat de oanwizer altyd net-nul wêze, sels as de oanwizer nea wurdt ferwidere.
/// Dit is sa dat enums dizze ferbeane wearde kinne brûke as diskriminant-`Option<Unique<T>>` hat deselde grutte as `Unique<T>`.
/// De oanwizer kin lykwols noch hingje as it net wurdt ferwidere.
///
/// Oars as `*mut T` is `Unique<T>` kovariant oer `T`.
/// Dit moat altyd korrekt wêze foar elk type dat de aliasingeasken fan Unique hanthavenet.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: dizze marker hat gjin gefolgen foar fariânsje, mar is nedich
    // foar dropck om te begripen dat wy logyskerwize in `T` hawwe.
    //
    // Foar details, sjoch:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointers binne `Send` as `T` `Send` is, om't de gegevens dy't se ferwize net unjildich binne.
/// Tink derom dat dizze aliasing-invariant net wurdt twongen troch it type systeem;de abstraksje mei de `Unique` moat it ôftwinge.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointers binne `Sync` as `T` `Sync` is, om't de gegevens dy't se ferwize net unjildich binne.
/// Tink derom dat dizze aliasing-invariant net wurdt twongen troch it type systeem;de abstraksje mei de `Unique` moat it ôftwinge.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Makket in nije `Unique` oan dy't hinget, mar goed oanpast is.
    ///
    /// Dit is nuttich foar it initialisearjen fan soarten dy't lui tawize, lykas `Vec::new` docht.
    ///
    /// Tink derom dat de oanwizerwearde mooglik in jildige oanwizer foar in `T` kin fertsjintwurdigje, wat betsjut dat dit net moat wurde brûkt as in "not yet initialized"-sentinelwearde.
    /// Soarten dy't lui tawize, moatte inisjalisaasje folgje op oare manieren.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() retourneert in jildige, net-nul oanwizer.De
        // betingsten om new_unchecked() te skiljen wurde dus respekteare.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Makket in nije `Unique` oan.
    ///
    /// # Safety
    ///
    /// `ptr` moat net-nul wêze.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: de beller moat garandearje dat `ptr` net-nul is.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Makket in nije `Unique` oan as `ptr` net-nul is.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: De oanwizer is al kontroleare en is net nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Krijt de ûnderlizzende `*mut`-oanwizer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ferwiist de ynhâld.
    ///
    /// De resultearjende libbensdoer is oan himsels bûn, dus dit gedraacht "as if", it wie eins in eksimplaar fan T dat lien wurdt.
    /// As in langere (unbound)-libben nedich is, brûk dan `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        unsafe { &*self.as_ptr() }
    }

    /// Ferwiderje de ynhâld mutabel.
    ///
    /// De resultearjende libbensdoer is oan himsels bûn, dus dit gedraacht "as if", it wie eins in eksimplaar fan T dat lien wurdt.
    /// As in langere (unbound)-libben nedich is, brûk dan `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in feroarbere referinsje.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werpt nei in oanwizer fan in oar type.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // VEILIGHEID: Unique::new_unchecked() skept in nij unyk en ferlet
        // de opjûne oanwizer om net nul te wêzen.
        // Om't wy sels trochjaan as oanwizer, kin it net nul wêze.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: In feroarbere referinsje kin net nul wêze
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}