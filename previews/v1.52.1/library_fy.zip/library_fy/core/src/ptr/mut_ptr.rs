use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Jout `true` werom as de oanwizer nul is.
    ///
    /// Tink derom dat net grutte typen in protte mooglike nullepointers hawwe, om't allinich de rauwe gegevenswizer wurdt beskôge, net har lingte, vtabel, ensfh.
    /// Dêrom kinne twa oanwizings dy't nul binne noch hieltyd net gelyk oan elkoar ferlykje.
    ///
    /// ## Gedrach by konst evaluaasje
    ///
    /// As dizze funksje wurdt brûkt tidens const-evaluaasje, kin it `false` weromjaan foar oanwizers dy't nul blike te wêzen by runtime.
    /// Spesifyk, as in oanwizer nei wat ûnthâld bûten syn grinzen wurdt kompensearre op sa'n manier dat de resultearjende oanwizer nul is, sil de funksje `false` noch altyd weromjaan.
    ///
    /// D'r is gjin manier foar CTFE om de absolute posysje fan dat ûnthâld te kennen, dat wy kinne net fertelle as de oanwizer nul is of net.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Fergelykje fia in cast mei in tinne oanwizer, dus dikke pointers beskôgje allinich har "data"-diel foar nulens.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Werpt nei in oanwizer fan in oar type.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Dekomponearje in (mooglik brede) oanwizer yn is adres-en metadatakomponinten.
    ///
    /// De oanwizer kin letter wurde rekonstruearre mei [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in dielde ferwizing nei de wearde ferpakt yn `Some`.As de wearde uninitialisearre is, moat [`as_uninit_ref`] yn plak wurde brûkt.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * De oanwizer moat wize op in inisjalisearre eksimplaar fan `T`.
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    /// (It diel oer inisjalisearjen is noch net folslein besletten, mar oant it is, is de iennichste feilige oanpak om te soargjen dat se yndie wurde inisjalisearre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nul-net-hifke ferzje
    ///
    /// As jo der wis fan binne dat de oanwizer noait nul kin wêze en op syk binne nei in soarte fan `as_ref_unchecked` dy't de `&T` retourneert ynstee fan `Option<&T>`, wite dan dat jo de oanwizer direkt kinne ferwiderje.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // VEILIGHEID: de beller moat garandearje dat `self` jildich is foar a
        // referinsje as it net nul is.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in dielde ferwizing nei de wearde ferpakt yn `Some`.
    /// Yn tsjinstelling ta [`as_ref`] fereasket dit net dat de wearde moat inisjalisearre wurde.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Berekkent de offset fan in oanwizer.
    ///
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// As ien fan 'e folgjende betingsten wurdt skeind, is it resultaat Undefined Behavior:
    ///
    /// * Sawol de begjinnende as de resultearjende oanwizer moatte yn grinzen wêze as ien byte foarby it ein fan itselde tawiisde objekt.
    /// Tink derom dat yn Rust elke (stack-allocated)-fariabele wurdt beskôge as in apart tawiisd objekt.
    ///
    /// * De berekkene kompensaasje,**yn bytes**, kin in `isize` net oerstreamje.
    ///
    /// * De kompensaasje yn grinzen kin net fertrouwe op "wrapping around" de adresromte.Dat is, de ûneinige-presysjesom,**yn bytes** moat passe yn in grutte.
    ///
    /// De gearstaller en standertbibleteek besiket yn 't algemien te soargjen dat allocaasjes nea in grutte berikke wêr't in kompensaasje in soarch is.
    /// Bygelyks, `Vec` en `Box` soargje derfoar dat se nea mear as `isize::MAX` bytes allocearje, dus `vec.as_ptr().add(vec.len())` is altyd feilich.
    ///
    /// De measte platfoarms kinne sa'n tawizing net iens konstruearje.
    /// Bygelyks, gjin bekend 64-bit platfoarm kin ea in fersyk tsjinje foar 2 <sup>63</sup> bytes fanwege beheiningen fan paginatabel of it splitsen fan de adresromte.
    /// Guon 32-bit-en 16-bit-platfoarms kinne lykwols mei súkses in fersyk tsjinje foar mear dan `isize::MAX` bytes mei saken lykas Fysike adresútwreiding.
    ///
    /// As sadanich kin ûnthâld dat direkt wurdt oanskaft fan allocators as geheime yn kaart brocht bestannen *te* wêze om mei dizze funksje te behanneljen.
    ///
    /// Betink ynstee [`wrapping_offset`] te brûken as dizze beheiningen dreech binne te befredigjen.
    /// It iennige foardiel fan dizze metoade is dat it mear agressive kompilearingsoptimisaasjes mooglik makket.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `offset` hanthavenje.
        // De verkregen oanwizer is jildich foar skriuwen, om't de beller moat garandearje dat hy wiist op itselde tawiisde objekt as `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Berekkent de kompensaasje fan in oanwizer mei wikkelyn.
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Dizze operaasje sels is altyd feilich, mar it brûken fan 'e resultearjende oanwizer is net.
    ///
    /// De resultearjende oanwizer bliuwt ferbûn oan itselde tawiisde objekt dat `self` wiist.
    /// It kin *net* wurde brûkt om tagong te krijen ta in oar tawiisd objekt.Tink derom dat yn Rust elke (stack-allocated)-fariabele beskôge wurdt as in apart tawiisd objekt.
    ///
    /// Mei oare wurden, `let z = x.wrapping_offset((y as isize) - (x as isize))` makket *net*`z` itselde as `y`, sels as wy oannimme dat `T` de grutte `1` hat en d'r is gjin oerstreaming: `z` is noch hechte oan it objekt `x` is hechte oan, en derferferinsje is net definieare gedrach, útsein as `x` en `y` wiist yn itselde tawiisde objekt.
    ///
    /// Yn ferliking mei [`offset`] fertraget dizze metoade yn prinsipe de eask om yn itselde tawiisde objekt te bliuwen: [`offset`] is direkt Undefined Gedrach by it oerstekken fan objektgrinzen;`wrapping_offset` produseart in oanwizer, mar liedt noch ta Undefined Behavior as in oanwizer wurdt ferwidere as it bûten de grinzen is fan it objekt dat it is oan.
    /// [`offset`] kin better wurde optimalisearre en is dus foarkar yn prestaasjegefoelige koade.
    ///
    /// De fertrage kontrôle kontroleart allinich de wearde fan 'e oanwizer dy't waard ferwidere, net de tuskenwearden dy't brûkt waarden by de berekkening fan it einresultaat.
    /// Bygelyks, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` is altyd itselde as `x`.Mei oare wurden, it tawize objekt litte en dan letter opnij ynfiere is tastien.
    ///
    /// As jo objektsgrinzen moatte oerstekke, smyt dan de oanwizer nei in hiel getal en doch dêr de rekken.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // Iterearje mei in rauwe oanwizer yn stappen fan twa eleminten
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: de yntrinsike `arith_offset` hat gjin betingsten om te wurde neamd.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in unike ferwizing nei de wearde ferpakt yn `Some`.As de wearde uninitialisearre is, moat [`as_uninit_mut`] yn plak wurde brûkt.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * De oanwizer moat wize op in inisjalisearre eksimplaar fan `T`.
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    /// (It diel oer inisjalisearjen is noch net folslein besletten, mar oant it is, is de iennichste feilige oanpak om te soargjen dat se yndie wurde inisjalisearre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // It sil ôfdrukke: "[4, 2, 3]".
    /// ```
    ///
    /// # Nul-net-hifke ferzje
    ///
    /// As jo der wis fan binne dat de oanwizer noait nul kin wêze en op syk binne nei in soarte fan `as_mut_unchecked` dy't de `&mut T` retourneert ynstee fan `Option<&mut T>`, wite dan dat jo de oanwizer direkt kinne ferwiderje.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // It sil ôfdrukke: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // VEILIGHEID: de beller moat garandearje dat `self` jildich is foar
        // in feroarbere referinsje as it net nul is.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in unike ferwizing nei de wearde ferpakt yn `Some`.
    /// Yn tsjinstelling ta [`as_mut`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat goed útrjochte wêze.
    ///
    /// * It moat "dereferencable" wêze yn 'e sin definieare yn [the module documentation].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat garandearje dat `self` oan alle
        // easken foar in referinsje.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Jout werom oft twa oanwizings garandearre binne gelyk te wêzen.
    ///
    /// By runtime gedraacht dizze funksje har as `self == other`.
    /// Yn guon konteksten (bgl. Evaluaasje fan kompilaasjetiid) is it lykwols net altyd mooglik de gelikensens fan twa oanwizers te bepalen, dat dizze funksje kin `false` falsk werombringe foar oanwizings dy't letter eins gelyk blike te wêzen.
    ///
    /// Mar as it `true` weromkomt, wurde de oanwizers garandearre gelyk te wêzen.
    ///
    /// Dizze funksje is de spegel fan [`guaranteed_ne`], mar net syn omkearde.D'r binne oanwizerferlikings wêrfoar beide funksjes `false` werombringe.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// De weromwearde kin feroarje ôfhinklik fan de kompilearferzje en ûnfeilige koade kin net fertrouwe op it resultaat fan dizze funksje foar sûnens.
    /// It wurdt suggereare om dizze funksje allinich te brûken foar optimalisaasjes foar prestaasjes wêr't falske `false`-wearden troch dizze funksje gjin ynfloed hawwe op 'e útkomst, mar allinich op' e prestaasje.
    /// De gefolgen fan it brûken fan dizze metoade om runtime en koade foar kompilearje-tiid oars te gedragen binne net ûndersocht.
    /// Dizze metoade moat net brûkt wurde om sokke ferskillen yn te fieren, en it moat ek net stabilisearre wurde foardat wy in better begryp hawwe fan dit probleem.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Jout werom oft twa oanwizings garandearre binne dat se ûngelikens binne.
    ///
    /// By runtime gedraacht dizze funksje har as `self != other`.
    /// Yn guon konteksten (bgl. Evaluaasje fan kompilaasjetiid) is it lykwols net altyd mooglik om de ûngelikensens fan twa oanwizers te bepalen, dat dizze funksje kin `false` falsk werombringe foar oanwizings dy't letter eins ûngelikens blike te wêzen.
    ///
    /// Mar as it `true` weromkomt, wurde de oanwizings garandearre ûngelikens te wêzen.
    ///
    /// Dizze funksje is de spegel fan [`guaranteed_eq`], mar net syn omkearde.D'r binne oanwizerferlikings wêrfoar beide funksjes `false` werombringe.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// De weromwearde kin feroarje ôfhinklik fan de kompilearferzje en ûnfeilige koade kin net fertrouwe op it resultaat fan dizze funksje foar sûnens.
    /// It wurdt suggereare om dizze funksje allinich te brûken foar optimalisaasjes foar prestaasjes wêr't falske `false`-wearden troch dizze funksje gjin ynfloed hawwe op 'e útkomst, mar allinich op' e prestaasje.
    /// De gefolgen fan it brûken fan dizze metoade om runtime en koade foar kompilearje-tiid oars te gedragen binne net ûndersocht.
    /// Dizze metoade moat net brûkt wurde om sokke ferskillen yn te fieren, en it moat ek net stabilisearre wurde foardat wy in better begryp hawwe fan dit probleem.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Berekkent de ôfstân tusken twa oanwizers.De weromkommende wearde is yn ienheden fan T: de ôfstân yn bytes wurdt dield troch `mem::size_of::<T>()`.
    ///
    /// Dizze funksje is it omkearde fan [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// As ien fan 'e folgjende betingsten wurdt skeind, is it resultaat Undefined Behavior:
    ///
    /// * Sawol de start-as oare oanwizer moatte yn grinzen wêze as ien byte foarby it ein fan itselde tawiisde objekt.
    /// Tink derom dat yn Rust elke (stack-allocated)-fariabele wurdt beskôge as in apart tawiisd objekt.
    ///
    /// * Beide oanwizers moatte *ôflaat wêze fan* in oanwizer nei itselde objekt.
    ///   (Sjoch hjirûnder foar in foarbyld.)
    ///
    /// * De ôfstân tusken de oanwizers, yn bytes, moat in eksakt meartal wêze fan 'e grutte fan `T`.
    ///
    /// * De ôfstân tusken de oanwizings,**yn bytes**, kin in `isize` net oerstreamje.
    ///
    /// * De ôfstân yn grinzen kin net fertrouwe op "wrapping around" de adresromte.
    ///
    /// Rust-typen binne nea grutter dan `isize::MAX`-en Rust-allocaasjes wreidet nea om 'e adresromte, dus twa pointers binnen wat wearde fan elke Rust-type `T` sille altyd oan' e lêste twa betingsten foldwaan.
    ///
    /// De standertbibleteek soarget ek algemien foar dat allocaasjes nea in grutte berikke wêr't in kompensaasje in soarch is.
    /// Bygelyks, `Vec` en `Box` soargje derfoar dat se nea mear dan `isize::MAX` bytes allocearje, sadat `ptr_into_vec.offset_from(vec.as_ptr())` altyd oan de lêste twa betingsten foldocht.
    ///
    /// De measte platfoarms kinne yn prinsipe net iens sa'n grutte allocaasje konstruearje.
    /// Bygelyks, gjin bekend 64-bit platfoarm kin ea in fersyk tsjinje foar 2 <sup>63</sup> bytes fanwege beheiningen fan paginatabel of it splitsen fan de adresromte.
    /// Guon 32-bit-en 16-bit-platfoarms kinne lykwols mei súkses in fersyk tsjinje foar mear dan `isize::MAX` bytes mei saken lykas Fysike adresútwreiding.
    /// As sadanich kin ûnthâld dat direkt wurdt oanskaft fan allocators as geheime yn kaart brocht bestannen *te* wêze om mei dizze funksje te behanneljen.
    /// (Tink derom dat [`offset`] en [`add`] ek in ferlykbere beheining hawwe en dus ek net kinne wurde brûkt op sokke grutte allocaasjes.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Dizze funksje panics as `T` in nulmjittich type ("ZST") is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Ferkeard* gebrûk:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Meitsje ptr2_other in "alias" fan ptr2, mar ôflaat fan ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Sûnt ptr2_other en ptr2 binne ôflaat fan oanwizings nei ferskillende objekten, is it komputearjen fan har offset net definieare gedrach, hoewol se op itselde adres wize!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefined Gedrach
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `offset_from` hanthavenje.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Berekkent de offset fan in oanwizer (gemak foar `.offset(count as isize)`).
    ///
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// As ien fan 'e folgjende betingsten wurdt skeind, is it resultaat Undefined Behavior:
    ///
    /// * Sawol de begjinnende as de resultearjende oanwizer moatte yn grinzen wêze as ien byte foarby it ein fan itselde tawiisde objekt.
    /// Tink derom dat yn Rust elke (stack-allocated)-fariabele wurdt beskôge as in apart tawiisd objekt.
    ///
    /// * De berekkene kompensaasje,**yn bytes**, kin in `isize` net oerstreamje.
    ///
    /// * De kompensaasje yn grinzen kin net fertrouwe op "wrapping around" de adresromte.Dat is, de einleaze presysjebedrach moat passe yn in `usize`.
    ///
    /// De gearstaller en standertbibleteek besiket yn 't algemien te soargjen dat allocaasjes nea in grutte berikke wêr't in kompensaasje in soarch is.
    /// Bygelyks, `Vec` en `Box` soargje derfoar dat se nea mear as `isize::MAX` bytes allocearje, dus `vec.as_ptr().add(vec.len())` is altyd feilich.
    ///
    /// De measte platfoarms kinne sa'n tawizing net iens konstruearje.
    /// Bygelyks, gjin bekend 64-bit platfoarm kin ea in fersyk tsjinje foar 2 <sup>63</sup> bytes fanwege beheiningen fan paginatabel of it splitsen fan de adresromte.
    /// Guon 32-bit-en 16-bit-platfoarms kinne lykwols mei súkses in fersyk tsjinje foar mear dan `isize::MAX` bytes mei saken lykas Fysike adresútwreiding.
    ///
    /// As sadanich kin ûnthâld dat direkt wurdt oanskaft fan allocators as geheime yn kaart brocht bestannen *te* wêze om mei dizze funksje te behanneljen.
    ///
    /// Betink ynstee [`wrapping_add`] te brûken as dizze beheiningen dreech binne te befredigjen.
    /// It iennige foardiel fan dizze metoade is dat it mear agressive kompilearingsoptimisaasjes mooglik makket.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `offset` hanthavenje.
        unsafe { self.offset(count as isize) }
    }

    /// Berekkent de offset fanút in oanwizer (gemak foar `.offset ((telle as isize).wrapping_neg())`).
    ///
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// As ien fan 'e folgjende betingsten wurdt skeind, is it resultaat Undefined Behavior:
    ///
    /// * Sawol de begjinnende as de resultearjende oanwizer moatte yn grinzen wêze as ien byte foarby it ein fan itselde tawiisde objekt.
    /// Tink derom dat yn Rust elke (stack-allocated)-fariabele wurdt beskôge as in apart tawiisd objekt.
    ///
    /// * De berekkene kompensaasje kin `isize::MAX`**bytes** net heger wêze.
    ///
    /// * De kompensaasje yn grinzen kin net fertrouwe op "wrapping around" de adresromte.Dat is, de ûneinige-presysjonele som moat passe yn in grutte.
    ///
    /// De gearstaller en standertbibleteek besiket yn 't algemien te soargjen dat allocaasjes nea in grutte berikke wêr't in kompensaasje in soarch is.
    /// Bygelyks, `Vec` en `Box` soargje derfoar dat se nea mear dan `isize::MAX` bytes allocearje, dus `vec.as_ptr().add(vec.len()).sub(vec.len())` is altyd feilich.
    ///
    /// De measte platfoarms kinne sa'n tawizing net iens konstruearje.
    /// Bygelyks, gjin bekend 64-bit platfoarm kin ea in fersyk tsjinje foar 2 <sup>63</sup> bytes fanwege beheiningen fan paginatabel of it splitsen fan de adresromte.
    /// Guon 32-bit-en 16-bit-platfoarms kinne lykwols mei súkses in fersyk tsjinje foar mear dan `isize::MAX` bytes mei saken lykas Fysike adresútwreiding.
    ///
    /// As sadanich kin ûnthâld dat direkt wurdt oanskaft fan allocators as geheime yn kaart brocht bestannen *te* wêze om mei dizze funksje te behanneljen.
    ///
    /// Betink ynstee [`wrapping_sub`] te brûken as dizze beheiningen dreech binne te befredigjen.
    /// It iennige foardiel fan dizze metoade is dat it mear agressive kompilearingsoptimisaasjes mooglik makket.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `offset` hanthavenje.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Berekkent de kompensaasje fan in oanwizer mei wikkelyn.
    /// (gemak foar `.wrapping_offset(count as isize)`)
    ///
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Dizze operaasje sels is altyd feilich, mar it brûken fan 'e resultearjende oanwizer is net.
    ///
    /// De resultearjende oanwizer bliuwt ferbûn oan itselde tawiisde objekt dat `self` wiist.
    /// It kin *net* wurde brûkt om tagong te krijen ta in oar tawiisd objekt.Tink derom dat yn Rust elke (stack-allocated)-fariabele beskôge wurdt as in apart tawiisd objekt.
    ///
    /// Mei oare wurden, `let z = x.wrapping_add((y as usize) - (x as usize))` makket *net*`z` itselde as `y`, sels as wy oannimme dat `T` de grutte `1` hat en d'r is gjin oerstreaming: `z` is noch hechte oan it objekt `x` is hechte oan, en derferferinsje is net definieare gedrach, útsein as `x` en `y` wiist yn itselde tawiisde objekt.
    ///
    /// Yn ferliking mei [`add`] fertraget dizze metoade yn prinsipe de eask om yn itselde tawiisde objekt te bliuwen: [`add`] is direkt Undefined Gedrach by it oerstekken fan objektgrinzen;`wrapping_add` produsearret in oanwizer, mar liedt noch ta Undefined Gedrach as in oanwizer wurdt ferwidere as it bûten de grinzen is fan it objekt dat it is oan.
    /// [`add`] kin better wurde optimalisearre en is dus foarkar yn prestaasjegefoelige koade.
    ///
    /// De fertrage kontrôle kontroleart allinich de wearde fan 'e oanwizer dy't waard ferwidere, net de tuskenwearden dy't brûkt waarden by de berekkening fan it einresultaat.
    /// Bygelyks, `x.wrapping_add(o).wrapping_sub(o)` is altyd itselde as `x`.Mei oare wurden, it tawize objekt litte en dan letter opnij ynfiere is tastien.
    ///
    /// As jo objektsgrinzen moatte oerstekke, smyt dan de oanwizer nei in hiel getal en doch dêr de rekken.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // Iterearje mei in rauwe oanwizer yn stappen fan twa eleminten
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Dizze loop printen "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Berekkent de kompensaasje fan in oanwizer mei wikkelyn.
    /// (gemak foar `.wrapping_offset ((rekkenje as isize).wrapping_neg())`)
    ///
    /// `count` is yn ienheden fan T;bgl. in `count` fan 3 fertsjintwurdiget in oanwizer fan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Dizze operaasje sels is altyd feilich, mar it brûken fan 'e resultearjende oanwizer is net.
    ///
    /// De resultearjende oanwizer bliuwt ferbûn oan itselde tawiisde objekt dat `self` wiist.
    /// It kin *net* wurde brûkt om tagong te krijen ta in oar tawiisd objekt.Tink derom dat yn Rust elke (stack-allocated)-fariabele beskôge wurdt as in apart tawiisd objekt.
    ///
    /// Mei oare wurden, `let z = x.wrapping_sub((x as usize) - (y as usize))` makket *net*`z` itselde as `y`, sels as wy oannimme dat `T` de grutte `1` hat en d'r is gjin oerstreaming: `z` is noch hechte oan it objekt `x` is hechte oan, en derferferinsje is net definieare gedrach, útsein as `x` en `y` wiist yn itselde tawiisde objekt.
    ///
    /// Yn ferliking mei [`sub`] fertraget dizze metoade yn prinsipe de eask om yn itselde tawiisde objekt te bliuwen: [`sub`] is direkt Undefined Gedrach by it oerstekken fan objektgrinzen;`wrapping_sub` produseart in oanwizer, mar liedt noch ta Undefined Behavior as in oanwizer wurdt ferwidere as it bûten de grinzen is fan it objekt dat it is oan.
    /// [`sub`] kin better wurde optimalisearre en is dus foarkar yn prestaasjegefoelige koade.
    ///
    /// De fertrage kontrôle kontroleart allinich de wearde fan 'e oanwizer dy't waard ferwidere, net de tuskenwearden dy't brûkt waarden by de berekkening fan it einresultaat.
    /// Bygelyks, `x.wrapping_add(o).wrapping_sub(o)` is altyd itselde as `x`.Mei oare wurden, it tawize objekt litte en dan letter opnij ynfiere is tastien.
    ///
    /// As jo objektsgrinzen moatte oerstekke, smyt dan de oanwizer nei in hiel getal en doch dêr de rekken.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // Iterearje mei in rauwe oanwizer yn stappen fan twa (backwards)-eleminten
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Dizze loop printen "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Stelt de oanwizerwearde yn op `ptr`.
    ///
    /// As `self` in (fat)-oanwizer is foar in net-grutte type, sil dizze hanneling allinich ynfloed hawwe op it oanwizerpart, wylst dit foar (thin)-oanwizers nei grutte soarten itselde effekt hat as in ienfâldige opdracht.
    ///
    /// De resultearjende oanwizer hat herkomst fan `val`, dat wol sizze, foar in dikke oanwizer is dizze hanneling semantysk itselde as it meitsjen fan in nije dikke oanwizer mei de gegevenswizer fan `val`, mar de metadata fan `self`.
    ///
    ///
    /// # Examples
    ///
    /// Dizze funksje is yn it foarste plak nuttich foar it tastean fan byte-wize oanwizer-rekkens op potinsjeel dikke oanwizers:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // sil "3" ôfdrukke
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // VEILIGHEID: Yn gefal fan in tinne oanwizer is dizze operaasjes identyk
        // nei in ienfâldige opdracht.
        // Yn it gefal fan in fetpointer, mei de hjoeddeiske ymplementaasje fan fetpointer-opmaak, is it earste fjild fan sa'n oanwizer altyd de gegevenswizer, dy't ek wurdt tawiisd.
        //
        unsafe { *thin = val };
        self
    }

    /// Lest de wearde fan `self` sûnder dizze te ferpleatsen.
    /// Dit lit it ûnthâld yn `self` net feroarje.
    ///
    /// Sjoch [`ptr::read`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `` hanthavenje.
        unsafe { read(self) }
    }

    /// Fiert in flechtich lêzen fan de wearde fan `self` út sûnder dizze te ferpleatsen.Hjirmei bliuwt it ûnthâld yn `self` net feroare.
    ///
    /// Fluchtige operaasjes binne bedoeld om te hanneljen op I/O-ûnthâld, en wurde garandearre dat se net troch de kompilearder wurde ferwidere of opnij oardere oer oare flechtige operaasjes.
    ///
    ///
    /// Sjoch [`ptr::read_volatile`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `read_volatile` hanthavenje.
        unsafe { read_volatile(self) }
    }

    /// Lest de wearde fan `self` sûnder dizze te ferpleatsen.
    /// Dit lit it ûnthâld yn `self` net feroarje.
    ///
    /// Oars as `read` kin de oanwizer unalignearre wêze.
    ///
    /// Sjoch [`ptr::read_unaligned`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `read_unaligned` hanthavenje.
        unsafe { read_unaligned(self) }
    }

    /// Kopieart `count * size_of<T>` bytes fan `self` nei `dest`.
    /// De boarne en bestimming kinne oerlaapje.
    ///
    /// NOTE: dit hat de *deselde* argumintfolchoarder as [`ptr::copy`].
    ///
    /// Sjoch [`ptr::copy`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `copy` hanthavenje.
        unsafe { copy(self, dest, count) }
    }

    /// Kopieart `count * size_of<T>` bytes fan `self` nei `dest`.
    /// De boarne en bestimming kinne *net* oerlaapje.
    ///
    /// NOTE: dit hat de *deselde* argumintfolchoarder as [`ptr::copy_nonoverlapping`].
    ///
    /// Sjoch [`ptr::copy_nonoverlapping`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `copy_nonoverlapping` hanthavenje.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopieart `count * size_of<T>` bytes fan `src` nei `self`.
    /// De boarne en bestimming kinne oerlaapje.
    ///
    /// NOTE: dit hat de *tsjinoerstelde* argumintfolchoarder fan [`ptr::copy`].
    ///
    /// Sjoch [`ptr::copy`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `copy` hanthavenje.
        unsafe { copy(src, self, count) }
    }

    /// Kopieart `count * size_of<T>` bytes fan `src` nei `self`.
    /// De boarne en bestimming kinne *net* oerlaapje.
    ///
    /// NOTE: dit hat de *tsjinoerstelde* argumintfolchoarder fan [`ptr::copy_nonoverlapping`].
    ///
    /// Sjoch [`ptr::copy_nonoverlapping`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `copy_nonoverlapping` hanthavenje.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Fiert de destruktor út (as ien) fan 'e oanwiisde wearde.
    ///
    /// Sjoch [`ptr::drop_in_place`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `drop_in_place` hanthavenje.
        unsafe { drop_in_place(self) }
    }

    /// Oerskriuwt in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
    ///
    ///
    /// Sjoch [`ptr::write`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `write` hanthavenje.
        unsafe { write(self, val) }
    }

    /// Ropt memset op op 'e oantsjutte oanwizer, set `count * size_of::<T>()` bytes ûnthâld yn fan `self` oant `val`.
    ///
    ///
    /// Sjoch [`ptr::write_bytes`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `write_bytes` hanthavenje.
        unsafe { write_bytes(self, val, count) }
    }

    /// Fiert in flechtich skriuwen út fan in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
    ///
    /// Fluchtige operaasjes binne bedoeld om te hanneljen op I/O-ûnthâld, en wurde garandearre dat se net troch de kompilearder wurde ferwidere of opnij oardere oer oare flechtige operaasjes.
    ///
    ///
    /// Sjoch [`ptr::write_volatile`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `write_volatile` hanthavenje.
        unsafe { write_volatile(self, val) }
    }

    /// Oerskriuwt in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
    ///
    ///
    /// Oars as `write` kin de oanwizer unalignearre wêze.
    ///
    /// Sjoch [`ptr::write_unaligned`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `write_unaligned` hanthavenje.
        unsafe { write_unaligned(self, val) }
    }

    /// Ferfangt de wearde op `self` mei `src`, retourneert de âlde wearde, sûnder ek te fallen.
    ///
    ///
    /// Sjoch [`ptr::replace`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `replace` hanthavenje.
        unsafe { replace(self, src) }
    }

    /// Ruilje de wearden op twa feroarbere lokaasjes fan itselde type, sûnder deinitialisearjen.
    /// Se kinne oerlaapje, oars as `mem::swap`, wat oars ekwivalint is.
    ///
    /// Sjoch [`ptr::swap`] foar soargen en foarbylden oer feiligens.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `swap` hanthavenje.
        unsafe { swap(self, with) }
    }

    /// Berekent de kompensaasje dy't op 'e oanwizer tapast wurde moat om dizze op `align` te rjochtsjen.
    ///
    /// As it net mooglik is de oanwizer út te lizzen, jout de ymplemintaasje `usize::MAX` werom.
    /// It is tastien foar de útfiering `usize::MAX` altyd * werom te jaan.
    /// Allinich de prestaasje fan jo algoritme kin ôfhingje fan it krijen fan in brûkbere kompensaasje hjir, net de justigens.
    ///
    /// De offset wurdt útdrukt yn oantal `T`-eleminten, en net bytes.De weromkommende wearde kin brûkt wurde mei de `wrapping_add`-metoade.
    ///
    /// D'r binne gjin garânsjes dat kompensaasje fan 'e oanwizer net oerstreamt of fierder giet dan de tawizing wêryn't de oanwizer wiist.
    ///
    /// It is oan 'e beller om te soargjen dat de weromkommende kompensaasje korrekt is yn alle oare termen dan ôfstimming.
    ///
    /// # Panics
    ///
    /// De funksje panics as `align` gjin macht-fan-twa is.
    ///
    /// # Examples
    ///
    /// Tagong ta neistlizzende `u8` as `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // wylst de oanwizer fia `offset` kin wurde útrjochte, soe it bûten de tawizing wize
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // VEILIGHEID: `align` is kontroleare as in krêft fan 2 hjirboppe
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Jout de lingte fan in rau plak.
    ///
    /// De weromkommende wearde is it oantal **eleminten**, net it oantal bytes.
    ///
    /// Dizze funksje is feilich, sels as de rauwe plak net nei in plakferwizing kin wurde smiten, omdat de oanwizer nul of net útrikt is.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // VEILIGHEID: dit is feilich, om't `*const [T]` en `FatPtr<T>` deselde opmaak hawwe.
            // Allinich `std` kin dizze garânsje meitsje.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Jout in rauwe oanwizer nei de buffer fan it stik.
    ///
    /// Dit is lykweardich oan casting `self` nei `*mut T`, mar mear type-feilich.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Jout in rauwe oanwizer werom nei in elemint of subslice, sûnder grinzen te kontrolearjen.
    ///
    /// Dizze metoade neame mei in yndeks bûten de grinzen of as `self` net te ferwiderjen is, is *[undefined behavior]*, sels as de resultearjende oanwizer net wurdt brûkt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: de beller soarget derfoar dat `self` derferenberber is en `index` binnen de grinzen is.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in dielde stik werom oan 'e wearde ferpakt yn `Some`.
    /// Yn tsjinstelling ta [`as_ref`] fereasket dit net dat de wearde moat inisjalisearre wurde.
    ///
    /// Foar de mutabele tsjinhinger sjoch [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat [valid] wêze foar lêzen foar `ptr.len() * mem::size_of::<T>()` in protte bytes, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
    ///
    ///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
    ///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.
    ///
    ///     * De oanwizer moat sels wurde ôfstimd foar plakjes mei nul-lingte.
    ///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
    ///
    ///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
    ///
    /// * De totale grutte `ptr.len() * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
    ///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Yn it bysûnder, foar de doer fan dit libben, moat it ûnthâld dat de oanwizer wiist op net muteare wurde (útsein yn `UnsafeCell`).
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// Sjoch ek [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: de beller moat it feiligenskontrakt foar `as_uninit_slice` hanthavenje.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Jout `None` werom as de oanwizer nul is, of oars jout in unyk stikje werom nei de wearde ferpakt yn `Some`.
    /// Yn tsjinstelling ta [`as_mut`] fereasket dit net dat de wearde inisjalisearre wurde moat.
    ///
    /// Foar de dielde tsjinhinger sjoch [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// As jo dizze metoade oanroppe, moatte jo derfoar soargje dat *of* de oanwizer NULL is *of* al it folgjende wier is:
    ///
    /// * De oanwizer moat [valid] wêze foar in soad bytes foar lêzen en skriuwen foar `ptr.len() * mem::size_of::<T>()`, en it moat goed oanpast wurde.Dit betsjut yn it bysûnder:
    ///
    ///     * It heule ûnthâldberik fan dizze slice moat befette wurde yn ien allinich tawiisd objekt!
    ///       Plakken kinne noait oerspanne oer meardere tawiisde objekten.
    ///
    ///     * De oanwizer moat sels wurde ôfstimd foar plakjes mei nul-lingte.
    ///     Ien reden hjirfoar is dat optimisaasjes fan enumlay-out kinne fertrouwe op referinsjes (ynklusyf slúven fan elke lingte) dy't útrjochte binne en net-nul om se te ûnderskieden fan oare gegevens.
    ///
    ///     Jo kinne in oanwizer krije dy't brûkber is as `data` foar plakjes mei nul lingte mei [`NonNull::dangling()`].
    ///
    /// * De totale grutte `ptr.len() * mem::size_of::<T>()` fan it stik moat net grutter wêze as `isize::MAX`.
    ///   Sjoch de feiligensdokumintaasje fan [`pointer::offset`].
    ///
    /// * Jo moatte de aliasingregels fan Rust ôftwinge, om't it weromkommen libben `'a` willekeurich is keazen en net needsaaklikerwize de eigentlike libbensdoer fan 'e gegevens werjout.
    ///   Benammen foar de doer fan dit libben moat it ûnthâld dat de oanwizer wiist net tagong krije (lêzen of skreaun) fia in oare oanwizer.
    ///
    /// Dit jildt sels as it resultaat fan dizze metoade net brûkt wurdt!
    ///
    /// Sjoch ek [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: de beller moat it feiligenskontrakt foar `as_uninit_slice_mut` hanthavenje.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Gelikensens foar oanwizings
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}