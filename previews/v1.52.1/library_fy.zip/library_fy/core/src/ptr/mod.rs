//! Manueel ûnthâld beheare fia rauwe oanwizers.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! In protte funksjes yn dizze module nimme rauwe oanwizings as arguminten en lêze derfan of skriuwt se nei.Om dit feilich te wêzen, moatte dizze oanwizings *jildich* wêze.
//! Oft in oanwizer jildich is, hinget ôf fan 'e hanneling wêrfoar hy wurdt brûkt (lêze of skriuwe), en de omfang fan it ûnthâld dat tagong is (dus hoefolle bytes binne read/written).
//! De measte funksjes brûke `*mut T` en `* const T` om tagong te krijen ta mar ien wearde, yn hokker gefal de dokumintaasje de grutte wegert en ymplisyt derfan út giet dat it `size_of::<T>()` bytes is.
//!
//! De krekte regels foar jildigens wurde noch net bepaald.De garânsjes dy't op dit punt wurde levere binne heul minimaal:
//!
//! * In [null]-oanwizer is *nea* jildich, net iens foar tagong fan [size zero][zst].
//! * Foar in oanwizer is jildich, it is needsaaklik, mar net altyd genôch, dat de oanwizer *derferenseabel is*: it ûnthâldberik fan 'e opjûne grutte begjinnend by de oanwizer moat allegear binnen de grinzen wêze fan in inkeld tawiisd objekt.
//!
//! Tink derom dat yn Rust elke (stack-allocated)-fariabele wurdt beskôge as in apart tawiisd objekt.
//! * Sels foar operaasjes fan [size zero][zst] moat de oanwizer net wize op deallokearre ûnthâld, dat wol sizze: deallokaasje makket oanwizers unjildich sels foar operaasjes mei nul grutte.
//! It werjaan fan in net-nul hiel getal *letterlik* nei in oanwizer is lykwols jildich foar tagongsrjochten mei nulgrutte, sels as der wat ûnthâld bestiet op dat adres en wurdt deallokeard.
//! Dit komt oerien mei it skriuwen fan jo eigen allocator: it tawizen fan objekten fan nulgrutte is net heul hurd.
//! De kanonike manier om in oanwizer te krijen dy't jildich is foar tagong ta nulgrutte is [`NonNull::dangling`].
//! * Alle tagongsrjochten útfierd troch funksjes yn dizze module binne *net-atoom* yn 'e sin fan [atomic operations] dy't wurdt brûkt om te syngronisearjen tusken triedden.
//! Dit betsjut dat it net definieare gedrach is om twa tagelyk tagong ta deselde lokaasje út te fieren fan ferskate threads, útsein as beide tagong allinich lêze út it ûnthâld.
//! Merken dat dit eksplisyt [`read_volatile`] en [`write_volatile`] omfettet: Fluchtige tagongsrjochten kinne net brûkt wurde foar syngronisaasje tusken triedden.
//! * It resultaat fan it werjaan fan in ferwizing nei in oanwizer is jildich salang't it ûnderlizzende objekt live is en gjin referinsje (gewoan rauwe oanwizers) wurdt brûkt om tagong te krijen ta itselde ûnthâld.
//!
//! Dizze axioma's, tegearre mei foarsichtich gebrûk fan [`offset`] foar oanwizerrekken, binne genôch om in soad nuttige dingen yn yfeilige koade korrekt te ymplementearjen.
//! Sterker garânsjes sille úteinlik wurde levere, om't de [aliasing]-regels wurde bepaald.
//! Sjoch foar mear ynformaasje de [book] en ek de seksje yn 'e referinsje wijd oan [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Jildige rauwe oanwizers lykas hjirboppe definieare binne net needsaaklik goed ôfstimd (wêrby't "proper"-útrjochting wurdt definieare troch it oanwizertype, dat wol sizze dat `*const T` op `mem::align_of::<T>()` moat wurde rjochte).
//! De measte funksjes fereaskje lykwols dat har arguminten goed oanpast wurde, en sille dizze eask eksplisyt yn har dokumintaasje.
//! Opfallende útsûnderingen hjirop binne [`read_unaligned`] en [`write_unaligned`].
//!
//! As in funksje in goede ôfstimming fereasket, dan docht dat dat sels as de tagong grutte 0 hat, dat wol sizze, sels as ûnthâld net eins wurdt oanrekke.Tink oan it brûken fan [`NonNull::dangling`] yn sokke gefallen.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Fiert de destruktor út (as ien) fan 'e oanwiisde wearde.
///
/// Dit is semantysk lykweardich mei it skiljen fan [`ptr::read`] en it wegwerpjen fan it resultaat, mar hat de folgjende foardielen:
///
/// * It is *ferplicht* om `drop_in_place` te brûken om net-grutte typen lykas trait-objekten te fallen, om't se net op 'e stapel kinne wurde lêzen en normaal falle kinne.
///
/// * It is freonliker foar de optimizer om dit oer [`ptr::read`] te dwaan as jo handich tawiisd ûnthâld falle (bgl. Yn 'e ymplementaasjes fan `Box`/`Rc`/`Vec`), om't de gearstaller net hoecht te bewizen dat it lûd is om de kopy te elide.
///
///
/// * It kin brûkt wurde om [pinned]-gegevens te litten as `T` net `repr(packed)` is (pinned gegevens moatte net ferpleatst wurde foardat se falle).
///
/// Net-útrjochte wearden kinne net te plak falle, se moatte earst mei [`ptr::read_unaligned`] nei in rjochte lokaasje wurde kopieare.Foar ynpakke structs wurdt dizze stap automatysk dien troch de gearstaller.
/// Dit betsjut dat de fjilden fan ynpakte strucken net te plak falle.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `to_drop` moat [valid] wêze foar sawol lêzen as skriuwen.
///
/// * `to_drop` moat goed oanpast wurde.
///
/// * De wearde `to_drop` wiist nei moat jildich wêze foar falle, wat kin betsjutte dat it ekstra invarianten moat hanthavenje, dit is type-ôfhinklik.
///
/// Derneist, as `T` net [`Copy`] is, kin it brûken fan de oanwiisde wearde nei it oproppen fan `drop_in_place` undefined gedrach feroarsaakje.Tink derom dat `*to_drop = foo` telt as gebrûk, om't it derfoar soarget dat de wearde wer falt.
/// [`write()`] kin brûkt wurde om gegevens te oerskriuwen sûnder dat dizze falle litte.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ferwiderje it lêste item mei de hân fan in vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Krij in rauwe oanwizer nei it lêste elemint yn `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Koart `v` om foar te kommen dat it lêste item falle lit.
///     // Wy dogge dat earst, om problemen te foarkommen as de `drop_in_place` ûnder panics.
///     v.set_len(1);
///     // Sûnder in oprop `drop_in_place` soe it lêste item noait falle, en it ûnthâld dat it beheart soe lekte.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Soargje derfoar dat it lêste item is fallen.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Tink derom dat de gearstaller dizze kopy automatysk útfiert by it ynleverjen fan ynpakte structs, dat jo moatte jo normaal net soargen meitsje oer sokke problemen, útsein as jo `drop_in_place` mei de hân skilje.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koade hjir makket net út, dit wurdt ferfongen troch de echte droplijm troch de gearstaller.
    //

    // VEILIGHEID: sjoch hjirboppe kommentaar
    unsafe { drop_in_place(to_drop) }
}

/// Makket in nul rauwe oanwizer oan.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Makket in nul mutabele rauwe oanwizer oan.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Hânlieding impl nedich om `T: Clone` bûn te foarkommen.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Hânlieding impl nedich om `T: Copy` bûn te foarkommen.
impl<T> Copy for FatPtr<T> {}

/// Foarmet in rau plak fan in oanwizer en in lingte.
///
/// It `len`-argumint is it oantal **eleminten**, net it oantal bytes.
///
/// Dizze funksje is feilich, mar eins is it brûken fan de weromwearde ûnfeilich.
/// Sjoch de dokumintaasje fan [`slice::from_raw_parts`] foar easken foar feiligens fan plakken.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // meitsje in snijpointer as jo begjinne mei in oanwizer nei it earste elemint
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // VEILIGHEID: Tagong ta de wearde fan 'e `Repr`-uny is feilich sûnt * const [T]
        //
        // en FatPtr hawwe deselde ûnthâldlay-outs.Allinich std kin dizze garânsje meitsje.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Fiert deselde funksjonaliteit as [`slice_from_raw_parts`], útsein dat in rau mutabele skyfke wurdt weromjûn, yn tsjinstelling ta in rau ûnferoarlike slach.
///
///
/// Sjoch de dokumintaasje fan [`slice_from_raw_parts`] foar mear details.
///
/// Dizze funksje is feilich, mar eins is it brûken fan de weromwearde ûnfeilich.
/// Sjoch de dokumintaasje fan [`slice::from_raw_parts_mut`] foar easken foar feiligens fan plakken.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tawize in wearde oan in yndeks yn it stik
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // VEILIGHEID: Tagong ta de wearde fan 'e `Repr`-uny is feilich sûnt * mut [T]
        // en FatPtr hawwe deselde ûnthâldlay-outs
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ruilje de wearden op twa feroarbere lokaasjes fan itselde type, sûnder deinitialisearjen.
///
/// Mar foar de folgjende twa útsûnderingen is dizze funksje semantysk gelyk oan [`mem::swap`]:
///
///
/// * It wurket op rauwe oanwizings ynstee fan referinsjes.
/// As referinsjes beskikber binne, moat [`mem::swap`] de foarkar hawwe.
///
/// * De twa wiisde wearden kinne oerlaapje.
/// As de wearden oerlaapje, sil de oerlaapjende regio fan ûnthâld fan `x` brûkt wurde.
/// Dit wurdt oantoand yn it twadde foarbyld hjirûnder.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * Sawol `x` as `y` moatte [valid] wêze foar sawol lêzen as skriuwen.
///
/// * Sawol `x` as `y` moatte goed oanpast wurde.
///
/// Tink derom dat sels as `T` grutte `0` hat, moatte de oanwizers net-NULL wêze en goed oanpast wurde.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Wikselje twa net-oerlappende regio's:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dit is `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dit is `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Wikselje twa oerlappende regio's:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dit is `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dit is `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // De yndeksen `1..3` fan it stik oerlaapje tusken `x` en `y`.
///     // Redelike resultaten soene foar har wêze `[2, 3]`, sadat yndeksen `0..3` `[1, 2, 3]` binne (oerienkomme mei `y` foar de `swap`);of dat se `[0, 1]` binne, sadat yndeksen `1..4` `[0, 1, 2]` binne (oerienkommende `x` foar de `swap`).
/////
///     // Dizze ymplemintaasje is definieare om de lêste kar te meitsjen.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Jou ússels wat skrapromte om mei te wurkjen.
    // Wy hoege ús gjin soargen te meitsjen oer drippen: `MaybeUninit` docht neat as se falle.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Fiere de ruilfergrutting VEILIGHEID út: de beller moat garandearje dat `x` en `y` jildich binne foar skriuwen en goed útrjochte.
    // `tmp` kin gjin `x` as `y` oerlaapje, om't `tmp` krekt op 'e stapel waard tawiisd as in apart tawiisd objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` en `y` kinne oerlaapje
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ruilje `count * size_of::<T>()` bytes tusken de twa regio's fan ûnthâld, begjinnend by `x` en `y`.
/// De twa regio's moatte *net* oerlaapje.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * Sawol `x` as `y` moatte [valid] wêze foar sawol lêzen as skriuwen fan `count *
///   size_of: :<T>() `bytes.
///
/// * Sawol `x` as `y` moatte goed oanpast wurde.
///
/// * De regio fan ûnthâld begjint by `x` mei in grutte fan `count *
///   size_of: :<T>() `bytes moatte *net* oerlaapje mei de regio ûnthâld dy't begjint by `y` mei deselde grutte.
///
/// Tink derom dat sels as de effektyf kopieare grutte (`count * size_of: :<T>()`) is `0`, de oanwizers moatte net-NULL wêze en goed rjochte wêze.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // VEILIGHEID: de beller moat garandearje dat `x` en `y` binne
    // jildich foar skriuwen en goed oanpast.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Foar soarten lytser dan de blokoptimalisaasje hjirûnder, wikselje gewoan direkt om foarkommende codegen te foarkommen.
    //
    if mem::size_of::<T>() < 32 {
        // VEILIGHEID: de beller moat garandearje dat `x` en `y` jildich binne
        // foar skriuwt, goed ôfstimd, en net-oerlappend.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // VEILIGHEID: de beller moat it feiligenskontrakt foar `swap_nonoverlapping` hanthavenje.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // De oanpak hjir is om simd te brûken om x&y effisjint te ruiljen.
    // Ut testen docht bliken dat it wikseljen fan 32 bytes as 64 bytes tagelyk it effisjintst is foar Intel Haswell E processors.
    // LLVM is better yn steat om te optimalisearjen as wy in struktuer in #[repr(simd)] jouwe, sels as wy dizze struktuer net direkt brûke.
    //
    //
    // FIXME repr(simd) brutsen op emscripten en redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop troch x&y, kopiearje se tagelyk `Block` De optimizer moat de lus foar de measte soarten folslein útrolje NB
    // Wy kinne gjin for loop brûke, om't de `range` impl `mem::swap` rekursyf neamt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Meitsje wat uninitialisearre ûnthâld as skrapromte `t` ferklearje hjir foarkomt it oanpassen fan 'e stapel as dizze loop net brûkt wurdt
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // VEILIGHEID: As `i < len`, en as de beller moat garandearje dat `x` en `y` jildich binne
        // foar `len`-bytes moatte `x + i` en `y + i` jildige adressen wêze, dy't foldogge oan it feiligenskontrakt foar `add`.
        //
        // Ek moat de beller garandearje dat `x` en `y` jildich binne foar skriuwen, goed oanpast en net-oerlappend, wat it feiligenskontrakt foar `copy_nonoverlapping` foltôget.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ruil in blok bytes fan x&y om, mei t as tydlike buffer brûke. Dit moat wurde optimalisearre yn effisjinte SIMD-operaasjes, wêr beskikber
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ruil alle oerbleaune bytes yn
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // VEILIGHEID: sjoch foarige feiligensopmerking.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Ferpleatst `src` yn 'e spitse `dst`, wêrtroch de foarige `dst`-wearde weromkomt.
///
/// Gjin wearde falt.
///
/// Dizze funksje is semantysk gelyk oan [`mem::replace`], útsein dat se wurket op rauwe oanwizers ynstee fan referinsjes.
/// As referinsjes beskikber binne, moat [`mem::replace`] de foarkar hawwe.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `dst` moat [valid] wêze foar sawol lêzen as skriuwen.
///
/// * `dst` moat goed oanpast wurde.
///
/// * `dst` moat wize op in goed inisjalisearre wearde fan it type `T`.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` soe itselde effekt hawwe sûnder it ûnfeilige blok te fereaskjen.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // VEILIGHEID: de beller moat garandearje dat `dst` jildich is
    // cast nei in feroarbere referinsje (jildich foar skriuwen, ôfstimd, inisjalisearre), en kin `src` net oerlaapje, om't `dst` moat wize op in ûnderskate tawiisd objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kin net oerlaapje
    }
    src
}

/// Lest de wearde fan `src` sûnder dizze te ferpleatsen.Hjirmei bliuwt it ûnthâld yn `src` net feroare.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `src` moat [valid] wêze foar lêzen.
///
/// * `src` moat goed oanpast wurde.Brûk [`read_unaligned`] as dit net it gefal is.
///
/// * `src` moat wize op in goed inisjalisearre wearde fan it type `T`.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] mei de hân ymplementearje:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Meitsje in bitwize kopy fan 'e wearde by `a` yn `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ofslute op dit punt (troch eksplisyt werom te kommen as troch in funksje oan te roppen dy't panics) soene feroarsaakje dat de wearde yn `tmp` falle sil, wylst deselde wearde noch wurdt ferwiisd troch `a`.
///         // Dit kin undefined gedrach útlitte as `T` net `Copy` is.
/////
/////
///
///         // Meitsje in bitwize kopy fan 'e wearde by `b` yn `a`.
///         // Dit is feilich, om't mutabele referinsjes gjin alias kinne wêze.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Lykas hjirboppe, kin hjirútgean ûnbestimd gedrach útlitte, om't deselde wearde wurdt ferwiisd troch `a` en `b`.
/////
///
///         // Ferpleats `tmp` yn `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` is ferpleatst (`write` nimt eigendom fan har twadde argumint), dus wurdt hjir ymplisyt neat falle litten.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Eigendom fan 'e weromkommende wearde
///
/// `read` makket in bitwize kopy fan `T`, likefolle oft `T` [`Copy`] is.
/// As `T` net [`Copy`] is, kin it brûken fan sawol de weromkommende wearde as de wearde by `*src` de feiligens fan it ûnthâld yn striid bringe.
/// Tink derom dat tawizen oan `*src` telt as gebrûk, om't it sil besykje de wearde op `* src` te fallen.
///
/// [`write()`] kin brûkt wurde om gegevens te oerskriuwen sûnder dat dizze falle litte.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` wiist no op itselde ûnderlizzende ûnthâld as `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Tawize oan `s2` feroarsaket de oarspronklike wearde.
///     // Bûten dit punt moat `s` net mear brûkt wurde, om't it ûnderlizzende ûnthâld is befrijd.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Tawize oan `s` soe de âlde wearde wer falle litte, wat resulteart yn undefined gedrach.
/////
///     // s= String::from("bar");//FOUT
///
///     // `ptr::write` kin brûkt wurde om in wearde te oerskriuwen sûnder dizze te fallen.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VEILIGHEID: de beller moat garandearje dat `src` jildich is foar lêzen.
    // `src` kin `tmp` net oerlaapje, om't `tmp` krekt op 'e stapel waard tawiisd as in apart tawiisd objekt.
    //
    //
    // Sûnt wy krekt in jildige wearde yn `tmp` skreaun hawwe, wurdt it garandearre dat dizze goed inisjalisearre is.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lest de wearde fan `src` sûnder dizze te ferpleatsen.Hjirmei bliuwt it ûnthâld yn `src` net feroare.
///
/// Oars as [`read`] wurket `read_unaligned` mei unjustere oanwizings.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `src` moat [valid] wêze foar lêzen.
///
/// * `src` moat wize op in goed inisjalisearre wearde fan it type `T`.
///
/// Lykas [`read`] makket `read_unaligned` in bitwize kopy fan `T`, likefolle oft `T` [`Copy`] is.
/// As `T` net [`Copy`] is, kin sawol de weromkommende wearde as de wearde by `*src` [violate memory safety][read-ownership] brûke.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Op `packed` structs
///
/// It is op it stuit ûnmooglik om rauwe oanwizings te meitsjen foar unalignearre fjilden fan in ynpakke struktuer.
///
/// Besykje in rauwe oanwizer te meitsjen nei in `unaligned`-struktuerfjild mei in ekspresje lykas `&packed.unaligned as *const FieldType` makket in tuskenferwizende unalignearre referinsje foardat dizze konverteart nei in rauwe oanwizer.
///
/// Dat dizze referinsje tydlik is en fuortendaliks cast is ûnbedoeld, om't de gearstaller altyd ferwachtet dat referinsjes goed útrjochte wurde.
/// As resultaat feroarsaket `&packed.unaligned as *const FieldType` direkt* undefined gedrach * yn jo programma.
///
/// In foarbyld fan wat net te dwaan en hoe't dit relateart oan `read_unaligned` is:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hjir besykje wy it adres te nimmen fan in 32-bit heulgetal dat net útrikt is.
///     let unaligned =
///         // In tydlike net-rjochte referinsje wurdt hjir makke dy't resulteart yn undefined gedrach, ûnôfhinklik fan oft de referinsje wurdt brûkt as net.
/////
///         &packed.unaligned
///         // Gieten nei in rauwe oanwizer helpt net;de flater barde al.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tagonklik tagong krije ta net-rjochte fjilden mei bgl. `packed.unaligned` is lykwols feilich.
///
///
///
///
///
///
// FIXME: Update dokuminten basearre op útkomst fan RFC #2582 en freonen.
/// # Examples
///
/// Lês in wearde fan in byte-buffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VEILIGHEID: de beller moat garandearje dat `src` jildich is foar lêzen.
    // `src` kin `tmp` net oerlaapje, om't `tmp` krekt op 'e stapel waard tawiisd as in apart tawiisd objekt.
    //
    //
    // Sûnt wy krekt in jildige wearde yn `tmp` skreaun hawwe, wurdt it garandearre dat dizze goed inisjalisearre is.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Oerskriuwt in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
///
/// `write` lit de ynhâld fan `dst` net falle.
/// Dit is feilich, mar it kin allocaasjes as boarnen lekke, dus der moat foarsichtich wêze wurde om in objekt dat net falle moat te oerskriuwe.
///
///
/// Derneist falt `src` net.Semantysk wurdt `src` ferpleatst nei de lokaasje dy't `dst` oanwiist.
///
/// Dit is passend foar inisjalisearjen fan net-inisjalisearre ûnthâld, of oerskriuwe fan ûnthâld dat earder [`read`] west hat fan.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `dst` moat [valid] wêze foar skriuwen.
///
/// * `dst` moat goed oanpast wurde.Brûk [`write_unaligned`] as dit net it gefal is.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] mei de hân ymplementearje:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Meitsje in bitwize kopy fan 'e wearde by `a` yn `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ofslute op dit punt (troch eksplisyt werom te kommen as troch in funksje oan te roppen dy't panics) soene feroarsaakje dat de wearde yn `tmp` falle sil, wylst deselde wearde noch wurdt ferwiisd troch `a`.
///         // Dit kin undefined gedrach útlitte as `T` net `Copy` is.
/////
/////
///
///         // Meitsje in bitwize kopy fan 'e wearde by `b` yn `a`.
///         // Dit is feilich, om't mutabele referinsjes gjin alias kinne wêze.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Lykas hjirboppe, kin hjirútgean ûnbestimd gedrach útlitte, om't deselde wearde wurdt ferwiisd troch `a` en `b`.
/////
///
///         // Ferpleats `tmp` yn `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` is ferpleatst (`write` nimt eigendom fan har twadde argumint), dus wurdt hjir ymplisyt neat falle litten.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Wy skilje de yntrinsika direkt om funksjesoproppen yn 'e generearre koade te foarkommen, om't `intrinsics::copy_nonoverlapping` in wrapperfunksje is.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // VEILIGHEID: de beller moat garandearje dat `dst` jildich is foar skriuwen.
    // `dst` kin `src` net oerlaapje, om't de beller feroarbere tagong hat ta `dst`, wylst `src` eigendom is fan dizze funksje.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Oerskriuwt in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
///
/// Oars as [`write()`] kin de oanwizer unalignearre wêze.
///
/// `write_unaligned` lit de ynhâld fan `dst` net falle.Dit is feilich, mar it kin allocaasjes as boarnen lekke, dus der moat foarsichtich wêze wurde om in objekt dat net falle moat te oerskriuwe.
///
/// Derneist falt `src` net.Semantysk wurdt `src` ferpleatst nei de lokaasje dy't `dst` oanwiist.
///
/// Dit is passend foar inisjalisearjen fan net-inisjalisearre ûnthâld, of oerskriuwe fan ûnthâld dat earder mei [`read_unaligned`] is lêzen.
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `dst` moat [valid] wêze foar skriuwen.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze.
///
/// [valid]: self#safety
///
/// ## Op `packed` structs
///
/// It is op it stuit ûnmooglik om rauwe oanwizings te meitsjen foar unalignearre fjilden fan in ynpakke struktuer.
///
/// Besykje in rauwe oanwizer te meitsjen nei in `unaligned`-struktuerfjild mei in ekspresje lykas `&packed.unaligned as *const FieldType` makket in tuskenferwizende unalignearre referinsje foardat dizze konverteart nei in rauwe oanwizer.
///
/// Dat dizze referinsje tydlik is en fuortendaliks cast is ûnbedoeld, om't de gearstaller altyd ferwachtet dat referinsjes goed útrjochte wurde.
/// As resultaat feroarsaket `&packed.unaligned as *const FieldType` direkt* undefined gedrach * yn jo programma.
///
/// In foarbyld fan wat net te dwaan en hoe't dit relateart oan `write_unaligned` is:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hjir besykje wy it adres te nimmen fan in 32-bit heulgetal dat net útrikt is.
///     let unaligned =
///         // In tydlike net-rjochte referinsje wurdt hjir makke dy't resulteart yn undefined gedrach, ûnôfhinklik fan oft de referinsje wurdt brûkt as net.
/////
///         &mut packed.unaligned
///         // Gieten nei in rauwe oanwizer helpt net;de flater barde al.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tagonklik tagong krije ta net-rjochte fjilden mei bgl. `packed.unaligned` is lykwols feilich.
///
///
///
///
///
///
///
///
///
// FIXME: Update dokuminten basearre op útkomst fan RFC #2582 en freonen.
/// # Examples
///
/// Skriuw in usize-wearde nei in byte-buffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // VEILIGHEID: de beller moat garandearje dat `dst` jildich is foar skriuwen.
    // `dst` kin `src` net oerlaapje, om't de beller feroarbere tagong hat ta `dst`, wylst `src` eigendom is fan dizze funksje.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Wy skilje de yntrinsike direkt oan om funksjeanroppen yn 'e generearre koade te foarkommen.
        intrinsics::forget(src);
    }
}

/// Fiert in flechtich lêzen fan de wearde fan `src` út sûnder dizze te ferpleatsen.Hjirmei bliuwt it ûnthâld yn `src` net feroare.
///
/// Fluchtige operaasjes binne bedoeld om te hanneljen op I/O-ûnthâld, en wurde garandearre dat se net troch de kompilearder wurde ferwidere of opnij oardere oer oare flechtige operaasjes.
///
/// # Notes
///
/// Rust hat op it stuit gjin strang en formeel definieare ûnthâldmodel, sadat de krekte semantyk fan wat "volatile" hjir betsjuttet kin feroarje oer tiid.
/// Dat wurdt sein, de semantyk sil hast altyd aardich fergelykje mei [C11's definition of volatile][c11].
///
/// De gearstaller moat de relative folchoarder of it oantal fluchtige ûnthâldbewegingen net feroarje.
/// Fluchtige ûnthâldbedriuwen op nulgrutte typen (bgl. As in nulgrutte type wurdt trochjûn oan `read_volatile`) binne noops en kinne wurde negeare.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `src` moat [valid] wêze foar lêzen.
///
/// * `src` moat goed oanpast wurde.
///
/// * `src` moat wize op in goed inisjalisearre wearde fan it type `T`.
///
/// Lykas [`read`] makket `read_volatile` in bitwize kopy fan `T`, likefolle oft `T` [`Copy`] is.
/// As `T` net [`Copy`] is, kin sawol de weromkommende wearde as de wearde by `*src` [violate memory safety][read-ownership] brûke.
/// It opslaan fan net-[`Kopie`]-typen yn fluchtich ûnthâld is lykwols hast wis ferkeard.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Krekt lykas yn C hat of in operaasje fluchtich is neat te meitsjen foar fragen oangeande tagelyk tagong fan meardere triedden.Fluchtige tagongsrjochten gedrage har krekt as net-atoom tagong yn dat ferbân.
///
/// Benammen in race tusken in `read_volatile` en elke skriuwbehear nei deselde lokaasje is net definieare gedrach.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Gjin panyk om codegen-ynfloed lytser te hâlden.
        abort();
    }
    // VEILIGHEID: de beller moat it feiligenskontrakt foar `volatile_load` hanthavenje.
    unsafe { intrinsics::volatile_load(src) }
}

/// Fiert in flechtich skriuwen út fan in ûnthâldlokaasje mei de opjûne wearde sûnder de âlde wearde te lêzen of te litten.
///
/// Fluchtige operaasjes binne bedoeld om te hanneljen op I/O-ûnthâld, en wurde garandearre dat se net troch de kompilearder wurde ferwidere of opnij oardere oer oare flechtige operaasjes.
///
/// `write_volatile` lit de ynhâld fan `dst` net falle.Dit is feilich, mar it kin allocaasjes as boarnen lekke, dus der moat foarsichtich wêze wurde om in objekt dat net falle moat te oerskriuwe.
///
/// Derneist falt `src` net.Semantysk wurdt `src` ferpleatst nei de lokaasje dy't `dst` oanwiist.
///
/// # Notes
///
/// Rust hat op it stuit gjin strang en formeel definieare ûnthâldmodel, sadat de krekte semantyk fan wat "volatile" hjir betsjuttet kin feroarje oer tiid.
/// Dat wurdt sein, de semantyk sil hast altyd aardich fergelykje mei [C11's definition of volatile][c11].
///
/// De gearstaller moat de relative folchoarder of it oantal fluchtige ûnthâldbewegingen net feroarje.
/// Fluchtige ûnthâldbedriuwen op nulgrutte typen (bgl. As in nulgrutte type wurdt trochjûn oan `write_volatile`) binne noops en kinne wurde negeare.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Gedrach is net definieare as ien fan 'e folgjende betingsten ynbreuk is:
///
/// * `dst` moat [valid] wêze foar skriuwen.
///
/// * `dst` moat goed oanpast wurde.
///
/// Tink derom dat sels as `T` grutte `0` hat, de oanwizer net-NULL moat wêze en goed útrjochte moat wêze.
///
/// [valid]: self#safety
///
/// Krekt lykas yn C hat of in operaasje fluchtich is neat te meitsjen foar fragen oangeande tagelyk tagong fan meardere triedden.Fluchtige tagongsrjochten gedrage har krekt as net-atoom tagong yn dat ferbân.
///
/// Benammen in race tusken in `write_volatile` en elke oare operaasje (lêzen of skriuwen) op deselde lokaasje is net definieare gedrach.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Gjin panyk om codegen-ynfloed lytser te hâlden.
        abort();
    }
    // VEILIGHEID: de beller moat it feiligenskontrakt foar `volatile_store` hanthavenje.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Pointer `p` rjochtsje.
///
/// Berekkenje offset (yn termen fan eleminten fan `stride`-stap) dy't tapast wurde moat op oanwizer `p`, sadat oanwizer `p` oanpast wurdt oan `a`.
///
/// Note: Dizze ymplemintaasje is mei soarch oanpast oan net panic.It is UB hjirfoar nei panic.
/// De ienige echte feroaring dy't hjir kin wurde makke is feroaring fan `INV_TABLE_MOD_16` en byhearrende konstanten.
///
/// As wy ea beslute it mooglik te meitsjen it yntrinsike mei `a` te neamen dat gjin krêft-fan-twa is, sil it wierskynlik ferstanniger wêze om gewoan te feroarjen nei in naïve ymplemintaasje yn stee fan te besykjen dit oan te passen om dizze feroaring oan te passen.
///
///
/// Alle fragen gean nei@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direkt gebrûk fan dizze yntinsins ferbetteret codegen signifikant op opt-nivo <=
    // 1, wêr't de metoadeferzjes fan dizze operaasjes net ynline binne.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Berekkenje multiplikatyf modulêr ynvers fan `x` modulo `m`.
    ///
    /// Dizze ymplemintaasje is oanpast foar `align_offset` en hat folgjende betingsten:
    ///
    /// * `m` is in krêft-fan-twa;
    /// * `x < m`; (as `x ≥ m`, ynstee yn `x % m` trochjaan)
    ///
    /// Ymplemintaasje fan dizze funksje mei net panic.Ea.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikative modulêre omkearde tabel modulo 2⁴=16.
        ///
        /// Tink derom dat dizze tabel gjin wearden befettet wêr't invers net bestiet (dus foar `0⁻¹ mod 16`, `2⁻¹ mod 16`, ensfh.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo wêrfoar de `INV_TABLE_MOD_16` bedoeld is.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // VEILIGHEID: `m` is ferplicht in power-of-two te wêzen, dus net-nul.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Wy werhelje "up" mei de folgjende formule:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // oant 2²ⁿ ≥ m.Dan kinne wy ferminderje nei ús winske `m` troch it resultaat `mod m` te nimmen.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Tink derom dat wy hjir mei opsetsin operaasjes brûke-de orizjinele formule brûkt bg. Subtraksje `mod n`.
                // It is heul prima om se ynstee `mod usize::MAX` te dwaan, om't wy it resultaat `mod n` dochs oan 'e ein nimme.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // VEILIGHEID: `a` is in krêft-fan-twa, dus net-nul.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` saak kin ienfâldiger wurde berekkene fia `-p (mod a)`, mar dat remt it fermogen fan LLVM om ynstruksjes lykas `lea` te selektearjen.Ynstee berekkenje wy
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // dy't operaasjes ferspriedt om 'e drager, mar `and` genôch pessimiseart foar LLVM om de ferskate optimisaasjes te brûken dy't se witte.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Al oanpast.Yay!
        return 0;
    } else if stride == 0 {
        // As de oanwizer net útrikt is, en it elemint nulgrutte is, dan sil gjin bedrach fan eleminten de oanwizer oait rjochtsje.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // VEILIGHEID: a is macht-fan-twa dus net-nul.stride==0 saak wurdt hjirboppe behannele.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // VEILIGHEID: gcdpow hat in boppegrins dat is op syn meast it oantal bits yn in grutte.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // VEILIGHEID: gcd is altyd grutter as of gelyk oan 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Dizze branch lost de folgjende lineêre kongruinsjeglykaasje op:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hjir is de oanwizerwearde, `s`, stride fan `T`, `o` offset yn `T`s, en `a`, de frege ôfstimming.
        //
        // Mei `g = gcd(a, s)`, en de boppesteande betingst dy't beweart dat `p` ek dielber is troch `g`, kinne wy `a' = a/g`, `s' = s/g`, `p' = p/g` oantsjutte, dan wurdt dit lykweardich oan:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // De earste termyn is "the relative alignment of `p` to `a`" (dield troch de `g`), de twadde termyn is "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (wer dield troch `g`).
        //
        // Dieling troch `g` is nedich om it omkearde goed foarme te meitsjen as `a` en `s` net co-prime binne.
        //
        // Fierder is it resultaat produsearre troch dizze oplossing net "minimal", dus is it needsaaklik om it resultaat `o mod lcm(s, a)` te nimmen.Wy kinne `lcm(s, a)` ferfange troch gewoan in `a'`.
        //
        //
        //
        //
        //

        // VEILIGHEID: `gcdpow` hat in boppegrins net grutter dan it oantal efterlizzende 0-bits yn `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // VEILIGHEID: `a2` is net-nul.`a` troch `gcdpow` ferskowe kin gjin fan 'e ynstelde bits ferskowe
        // yn `a` (wêrfan it presys ien hat).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // VEILIGHEID: `gcdpow` hat in boppegrins net grutter dan it oantal efterlizzende 0-bits yn `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // VEILIGHEID: `gcdpow` hat in boppegrins dy't net grutter is dan it oantal efterbliuwende 0-bits yn
        // `a`.
        // Fierder kin de subtraksje net oerstreamje, om't `a2 = a >> gcdpow` altyd strikt grutter wêze sil dan `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // VEILIGHEID: `a2` is in krêft-fan-twa, lykas hjirboppe bewiisd.`s2` is strikt minder dan `a2`
        // om't `(s % a) >> gcdpow` strikt minder is dan `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kin hielendal net oanpast wurde.
    usize::MAX
}

/// Fergeliket rauwe oanwizings foar gelikensens.
///
/// Dit is itselde as it brûken fan de `==`-operator, mar minder generyk:
/// de arguminten moatte `*const T` rauwe oanwizers wêze, net alles dat `PartialEq` ymplementeart.
///
/// Dit kin brûkt wurde om `&T`-referinsjes te fergelykjen (dy't ymplisyt twinge oan `*const T`) troch har adres ynstee fan 'e wearden dy't se oanwize te fergelykjen (wat de `PartialEq for &T`-ymplemintaasje docht).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Plakken wurde ek fergelike troch har lingte (dikke pointers):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits wurde ek fergelike troch har ymplemintaasje:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Oanwizers hawwe gelikense adressen.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekten hawwe gelikense adressen, mar `Trait` hat ferskillende ymplementaasjes.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // It konvertearjen fan de referinsje nei in `*const u8` wurdt fergelike op adres.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash in rauwe oanwizer.
///
/// Dit kin brûkt wurde om in `&T`-referinsje te hashearjen (dy't ymplisyt twingt nei `*const T`) troch syn adres yn stee fan 'e wearde dêrnei wiist (wat de `Hash for &T`-ymplemintaasje docht).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Ympls foar funksjewizers
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De tuskenlizzende cast as usize is fereaske foar AVR
                // sadat de adresromte fan 'e boarnerfunksjewizer bewarre wurdt yn' e definitive funksjewizer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De tuskenlizzende cast as usize is fereaske foar AVR
                // sadat de adresromte fan 'e boarnerfunksjewizer bewarre wurdt yn' e definitive funksjewizer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Gjin fariabele funksjes mei 0 parameters
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Meitsje in `const` rauwe oanwizer nei in plak, sûnder in tuskenferwizing te meitsjen.
///
/// In referinsje oanmeitsje mei `&`/`&mut` is allinich tastien as de oanwizer goed is rjochte en wiist op inisjalisearre gegevens.
/// Foar gefallen wêr't dy easken net hâlde, moatte rauwe oanwizers yn plak wurde brûkt.
/// `&expr as *const _` makket lykwols in referinsje foardat hy dizze nei in rauwe oanwizer smyt, en dizze referinsje is ûnderwerp fan deselde regels as alle oare referinsjes.
///
/// Dizze makro kin in rauwe oanwizer meitsje *sûnder* earst in referinsje oan te meitsjen.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` soe in unjildige referinsje oanmeitsje, en dus Undefined Behaviour wêze!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Meitsje in `mut` rauwe oanwizer nei in plak, sûnder in tuskenferwizing te meitsjen.
///
/// In referinsje oanmeitsje mei `&`/`&mut` is allinich tastien as de oanwizer goed is rjochte en wiist op inisjalisearre gegevens.
/// Foar gefallen wêr't dy easken net hâlde, moatte rauwe oanwizers yn plak wurde brûkt.
/// `&mut expr as *mut _` makket lykwols in referinsje foardat hy dizze nei in rauwe oanwizer smyt, en dizze referinsje is ûnderwerp fan deselde regels as alle oare referinsjes.
///
/// Dizze makro kin in rauwe oanwizer meitsje *sûnder* earst in referinsje oan te meitsjen.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` soe in unjildige referinsje oanmeitsje, en dus Undefined Behaviour wêze!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` twingt it fjild te kopiearjen ynstee fan in referinsje te meitsjen.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}