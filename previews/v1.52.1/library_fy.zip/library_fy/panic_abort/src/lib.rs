//! Ymplemintaasje fan Rust panics fia proses ôfbrutsen
//!
//! As fergelike mei de ymplemintaasje fia ôfwikkeling, is dizze crate *folle* ienfâldiger!Dat wurdt sein, it is net sa alsidich, mar hjir giet!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" de lading en shim nei it relevante ôfbrekken op it platfoarm yn kwestje.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // skilje std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Op Windows brûk it prosessor-spesifike __fastfail-meganisme.Yn Windows 8 en letter sil dit proses fuortendaliks beëindigje sûnder yn behanneling útsûnderingshannelers út te fieren.
            // Yn eardere ferzjes fan Windows sil dizze folchoarder fan ynstruksjes wurde behannele as in tagongsfeil, wêrtroch it proses beëinige wurdt, mar sûnder alle útsûnderingshannelers needsaaklik te omlizzen.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: dit is deselde ymplemintaasje as yn XSTX fan libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Dit ... is in bytsje frjemd.De tl; dr;is dat dit nedich is om korrekt te keppeljen, de langere útlis is hjirûnder.
//
// Op it stuit binne de binearingen fan libcore/libstd dy't wy ferstjoere allegear kompileare mei `-C panic=unwind`.Dit wurdt dien om te soargjen dat de binearingen maksimaal kompatibel binne mei safolle mooglik situaasjes.
// De gearstaller fereasket lykwols in "personality function" foar alle funksjes gearstald mei `-C panic=unwind`.Dizze persoanlikheidsfunksje is hurdkodearre foar it symboal `rust_eh_personality` en wurdt definieare troch it `eh_personality` lang item.
//
// So...
// wêrom net gewoan definiearje dat lang item hjir?Goeie fraach!De manier wêrop panic-runtimes keppele binne, is eins in bytsje subtyl, om't se "sort of" binne yn 'e crate-winkel fan' e kompilearder, mar allinich allinich keppele as in oar net eins keppele is.
//
// Dit einiget mei betsjutting dat sawol dizze crate as de panic_unwind crate kinne ferskine yn 'e crate-winkel fan' e kompilearder, en as beide it `eh_personality` lang item definiearje dan sil dat in flater slaan.
//
// Om dit te behanneljen fereasket de kompilear allinich dat de `eh_personality` wurdt definieare as de panic-runtime dy't yn keppele is de ûntspannen runtime is, en oars is it net nedich om te definiearjen (mei rjocht).
// Yn dit gefal definieart dizze bibleteek dit symboal lykwols gewoan, sadat d'r teminsten earne wat persoanlikheid is.
//
// Yn essinsje is dit symboal krekt definieare om bedrade te wurden nei libcore/libstd-binaries, mar it soe nea moatte wurde neamd, om't wy hielendal net yn in ûntspannende runtime keppelje.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Op x86_64-pc-windows-gnu brûke wy ús eigen persoanlikheidsfunksje dy't `ExceptionContinueSearch` werombringe moat as wy al ús frames trochjaan.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Lykas hjirboppe komt dit oerien mei it `eh_catch_typeinfo` lang-item dat op it stuit allinich wurdt brûkt op Emscripten.
    //
    // Om't panics gjin útsûnderingen genereart en bûtenlânske útsûnderingen op it stuit UB binne mei -C panic=ôfbrekke (hoewol dit kin feroarje), sille alle catch_unwind-petearen dizze typeinfo nea brûke.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Dizze twa wurde neamd troch ús startobjekten op i686-pc-windows-gnu, mar se hoege neat te dwaan, sadat de lichems nops binne.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}