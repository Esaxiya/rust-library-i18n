//! In stipebibleteek foar makro-auteurs by it definiearjen fan nije makro's.
//!
//! Dizze bibleteek, levere troch de standertferdieling, leveret de soarten konsumeare yn 'e ynterfaces fan prosedureel definieare makro-definysjes lykas funksje-like makro's `#[proc_macro]`, makro-attributen `#[proc_macro_attribute]` en oanpaste derive-attributen `#[proc_macro_derive]`.
//!
//!
//! Sjoch [the book] foar mear.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Bepaalt oft proc_macro tagonklik is makke foar it programma dat no rint.
///
/// De proc_macro crate is allinich bedoeld foar gebrûk yn 'e ymplemintaasje fan prosedurele makro's.Alle funksjes yn dizze crate panic as oproppen fan bûten in prosedurele makro, lykas fan in bouwskript of ienheidstest of gewoan Rust-binair.
///
/// Mei omtinken foar Rust-biblioteken dy't ûntwurpen binne om sawol makro-as net-makro-gebrûk te stypjen, biedt `proc_macro::is_available()` in net-panike manier om te spoaren oft de ynfrastruktuer nedich is foar it brûken fan de API fan proc_macro is op it stuit beskikber.
/// Jout wier as oproppen wurdt fan binnenút fan in prosedurele makro, falsk as oproppen fanút in oare binêre.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// It haadtype levere troch dizze crate, dy't in abstrakte stream fan tokens fertsjintwurdiget, of, mear spesifyk, in folchoarder fan token-beammen.
/// It type biedt ynterfaces foar iterearjen oer dy token-beammen en, oarsom, in oantal token-beammen yn ien stream te sammeljen.
///
///
/// Dit is sawol de yn-as útfier fan definysjes `#[proc_macro]`, `#[proc_macro_attribute]` en `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Flater weromjûn fan `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Jout in lege `TokenStream` mei gjin token-beammen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontroleart oft dizze `TokenStream` leech is.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Besiket de snaar yn tokens te brekken en dy tokens te analysearjen yn in token-stream.
/// Kin om in oantal redenen mislearje, bygelyks as de tekenrige unbalansearre skiedsrjochten of tekens befettet dy't net yn 'e taal besteane.
///
/// Alle tokens yn 'e analyseare stream krije `Span::call_site()`-oerspannen.
///
/// NOTE: guon flaters kinne panics feroarsaakje ynstee fan `LexError` werom te jaan.Wy reservearje it rjocht om dizze flaters te feroarjen yn `LexError`s letter.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Printset de token-stream ôf as in tekenrige dy't as losslessless konvertibele moat wurde werom yn deselde token-stream (modulo-oerspannen), útsein mooglik 'TokenTree: : Group`s mei `Delimiter::None`-skiedingsteken en negative numerike literatuer.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Printset token ôf yn in foarm handich foar debuggen.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Makket in token-stream mei ien token-beam.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Sammelt in oantal token-beammen yn ien stream.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// In "flattening"-operaasje op token-streamen sammelt token-beammen fan meardere token-streamen yn ien stream.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Brûk in optimale útfiering if/when mooglik.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Details oer iepenbiere ymplemintaasje foar it `TokenStream`-type, lykas iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// In iterator oer 'TokenStream`'s`TokenTree`s.
    /// De iteraasje is "shallow", bgl. De iterator ferfarret net yn ôfskieden groepen, en retourneert hiele groepen as token-beammen.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` aksepteart willekeurige tokens en wreidet út nei in `TokenStream` dy't de ynput beskriuwt.
/// Bygelyks, `quote!(a + b)` sil in útdrukking produsearje, dy't, as evaluearre, de `TokenStream` `[Ident("a"), Punct('+', Alone) konstrueart, Ident("b")]`.
///
///
/// Untsiferje wurdt dien mei `$`, en wurket troch de single folgjende ident te nimmen as de unoteerde term.
/// Om `$` sels te sitearjen, brûk `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// In regio fan boarne koade, tegearre mei ynformaasje oer makro-útwreiding.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Makket in nije `Diagnostic` mei de opjûne `message` oan 'e span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// In spanwiidte dat oplost op 'e makro-definysje-side.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// De span fan 'e oanroppen fan' e hjoeddeistige prosedurele makro.
    /// Identifiers makke mei dizze span wurde oplost as soene se direkt op 'e lokaasje fan' e makro-oprop (oprophygiëne) wurde skreaun en oare koade op 'e makro-opropside kin ek nei har ferwize.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// In span dat `macro_rules` hygiëne foarstelt, en soms oplost op 'e makro-definysjesite (lokale fariabelen, labels, `$crate`) en soms op' e makro-opropsite (al it oare).
    ///
    /// De spanlokaasje is nommen fan 'e opropsite.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// It orizjinele boarne bestân wêryn dit span wiist.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// De `Span` foar de tokens yn 'e foarige makro-útwreiding wêrfan `self` waard generearre, as ien.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// De spanwiidte foar de oarsprongboarne koade wêrfan `self` waard generearre.
    /// As dizze `Span` net waard generearre út oare makro-útwreidings, dan is de weromwearde itselde as `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Krijt de begjinnende line/column yn it boarne bestân foar dizze span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Krijt de ein line/column yn it boarne bestân foar dizze span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Makket in nije span omfetsje `self` en `other`.
    ///
    /// Jout `None` werom as `self` en `other` fan ferskate bestannen binne.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Makket in nije span mei deselde line/column-ynformaasje as `self`, mar dat symboalen oplost as wie it by `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Makket in nije span mei deselde resolúsje-gedrach as `self`, mar mei de line/column-ynformaasje fan `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Fergeliket mei spanningen om te sjen oft se gelyk binne.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Jout de boarnetekst efter in span.
    /// Dit behâldt de orizjinele boarne koade, ynklusyf spaasjes en opmerkingen.
    /// It jout allinich in resultaat as de span oerienkomt mei echte boarne koade.
    ///
    /// Note: It waarnimbere resultaat fan in makro moat allinich fertrouwe op 'e tokens en net op dizze boarnetekst.
    ///
    /// It resultaat fan dizze funksje is in bêste poging om allinich te brûken foar diagnostyk.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Printsje in spanwiidte yn in foarm handich foar debuggen.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// In line-kolompaar dat it begjin of it ein fan in `Span` fertsjintwurdiget.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// De line mei 1-yndekseare yn it boarne bestân wêrop de span (inclusive) begjint of einiget.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// De kolom mei 0-yndekseare (yn UTF-8-tekens) yn it boarne bestân wêrop de span (inclusive) begjint of einiget.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// It boarne bestân fan in opjûne `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Krijt it paad nei dit boarne bestân.
    ///
    /// ### Note
    /// As de koadespan ferbûn mei dizze `SourceFile` waard generearre troch in eksterne makro, dizze makro, is dit miskien net in eigentlike paad op it bestânsysteem.
    /// Brûk [`is_real`] om te kontrolearjen.
    ///
    /// Tink derom dat sels as `is_real` `true` weromkomt, as `--remap-path-prefix` waard trochjûn op 'e kommandorigel, it opjûne paad miskien net eins jildich is.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Jout `true` werom as dit boarne bestân in echte boarne bestân is, en net generearre troch de útwreiding fan in eksterne makro.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Dit is in hack oant yntercrate-oerspanningen wurde ymplementeare en wy kinne echte boarne-bestannen hawwe foar spanningen generearre yn eksterne makro's.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// In inkele token as in begrinze folchoarder fan token-beammen (bgl. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// In token-stream omjûn troch beugelafgrensers.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// In identifier.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// In inkeld punktuaasjeteken (`+`, `,`, `$`, ensfh.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// In letterlik karakter (`'a'`), tekenrige (`"hello"`), nûmer (`2.3`), ensfh.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Jout de spanwiidte fan dizze beam, delegearjend nei de `span`-metoade fan 'e befette token as in begrinze stream.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigureart de spanwiidte foar *allinich dizze token*.
    ///
    /// Tink derom dat as dizze token in `Group` is, dan sil dizze metoade de span fan elk fan 'e ynterne tokens net konfigurearje, dit sil gewoan delegearje nei de `set_span`-metoade fan elke fariant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Printset token-beam ôf yn in foarm dy't handich is foar debuggen.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Elk fan dizze hat de namme yn it struktuertype yn it ôflaat debug, dus lestich mei in ekstra laach fan yndireksje
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Printsje de token-beam as in tekenrige dy't ferliesleas konvertibel wêze moat werom yn deselde token-beam (modulo-oerspannen), útsein mooglik 'TokenTree: : Group`s mei `Delimiter::None`-ôfskieders en negative numerike letteren.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// In begrinze token-stream.
///
/// In `Group` befettet yntern in `TokenStream` dy't wurdt omjûn troch `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Beskriuwt hoe't in folchoarder fan token-beammen wurdt begrinze.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// In ymplisite skieding, dy't bygelyks kin ferskine om tokens komt fan in "macro variable" `$var`.
    /// It is wichtich om operatorprioriteiten te behâlden yn gefallen lykas `$var * 3` wêr't `$var` `1 + 2` is.
    /// Ymplisite skiedsrjochten meie in rûnwei fan in token-stream troch in tekenrige net oerlibje.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Makket in nije `Group` mei de opjûne ôfgrenser en token stream.
    ///
    /// Dizze konstrukteur sil de span foar dizze groep ynstelle op `Span::call_site()`.
    /// Om de spanwiziging te feroarjen kinne jo de `set_span`-metoade hjirûnder brûke.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Jout de skiedingsteken fan dizze `Group` werom
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Jout de `TokenStream` fan tokens dy't yn dizze `Group` ôfskieden binne.
    ///
    /// Tink derom dat de weromkommende token-stream de boppesteande skieding net omfettet.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Jout de spanwiidte foar de ôfskieders fan dizze token-stream, oerspant oer de heule `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Jout de spanwize dy't wiist op de iepeningsôfgrenser fan dizze groep.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Jout de spanwize dy't wiist op de ôfslutende ôfgrenser fan dizze groep.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigureart de spanwiidte foar dizze 'groep' ôfskieders, mar net de ynterne tokens.
    ///
    /// Dizze metoade sil **net** de span ynstelle fan alle ynterne tokens dy't troch dizze groep oerspand wurdt, mar leaver allinich de span fan 'e skieding tokens op it nivo fan' e `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printsje de groep ôf as in tekenrige dy't ferliesleas konvertibel wêze moat werom yn deselde groep (modulo oerspant), útsein mooglik `TokenTree: : Group`s mei `Delimiter::None`-skiedingsteken.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// In `Punct` is in inkeld punktuaasjekarakter lykas `+`, `-` as `#`.
///
/// Multi-karakter-operators lykas `+=` wurde fertsjintwurdige as twa gefallen fan `Punct` mei ferskate foarmen fan `Spacing` werom.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Oft in `Punct` fuortendaliks wurdt folge troch in oare `Punct` as folge troch in oare token as wite romte.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// bgl. `+` is `Alone` yn `+ =`, `+ident` as `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// bgl. `+` is `Joint` yn `+=` of `'#`.
    /// Derneist kin ien sitaat `'` meidwaan mei identifiers om `'ident` libbensdagen te foarmjen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Makket in nije `Punct` út it opjûne karakter en spaasjes.
    /// It `ch`-argumint moat in jildich punktuaasjeteken wêze dat tastien is troch de taal, oars sil de funksje panic.
    ///
    /// De weromkommende `Punct` sil de standert span fan `Span::call_site()` hawwe dy't fierder kin wurde konfigureare mei de `set_span`-metoade hjirûnder.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Jout de wearde fan dit punktuaasjeteken as `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Jout de ôfstân fan dit punktuaasjeteken oan, en jout oan oft it fuortendaliks wurdt folge troch in oare `Punct` yn 'e token-stream, sadat se potinsjeel kinne wurde kombineare yn in multi-karakter-operator (`Joint`), of it wurdt folge troch in oare token of wite romte (`Alone`), sadat de operator wis hat einige.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Jout de spanwiidte foar dit punktuaasjeteken.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurearje de spanwiidte foar dit punktuaasjekarakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printset it punktuaasjeteken as in tekenrige dy't ferliesleas konvertibel wêze moat yn itselde karakter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// In identifier (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Makket in nije `Ident` mei de opjûne `string` en ek de oantsjutte `span`.
    /// It `string`-argumint moat in jildige identifier wêze dy't tastien is troch de taal (ynklusyf kaaiwurden, bgl. `self` of `fn`).Oars sil de funksje panic.
    ///
    /// Tink derom dat `span`, op it stuit yn rustc, de hygiëne-ynformaasje foar dizze identifier konfigureart.
    ///
    /// Fanôf dizze tiid kiest `Span::call_site()` eksplisyt yn foar "call-site" hygiëne, wat betsjut dat identifiers dy't binne makke mei dizze span sille wurde oplost as soene se direkt wurde skreaun op 'e lokaasje fan' e makro-oprop, en oare koade op 'e makro-opropside sil kinne ferwize nei se ek.
    ///
    ///
    /// Lettere oerspanningen lykas `Span::def_site()` sille it mooglik meitsje om oan te melden foar "definition-site" hygiëne, wat betsjuttet dat identifiers dy't binne makke mei dizze span wurde oplost op 'e lokaasje fan' e makrodefinysje en oare koade op 'e makro-opropside kin net nei har ferwize.
    ///
    /// Fanwegen it hjoeddeistige belang fan hygiëne fereasket dizze konstrukteur, yn tsjinstelling ta oare tokens, dat in `Span` wurdt oantsjutte by konstruksje.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Itselde as `Ident::new`, mar makket in rauwe identifier (`r#ident`).
    /// It `string`-argumint is in jildige identifier dy't tastien is troch de taal (ynklusyf kaaiwurden, bgl. `fn`).
    /// Keywords dy't brûkber binne yn paadsegminten (bgl
    /// `self`, `super`) wurde net stipe, en sille in panic feroarsaakje.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Jout de spanwiidte fan dizze `Ident`, omfettet de heule tekenrige weromjûn troch [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigureart de spanwiidte fan dizze `Ident`, feroaret mooglik syn hygiënskontekst.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printset de identifier ôf as in tekenrige dy't ferliesleas konvertibel wêze moat werom yn deselde identifier.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// In letterlike tekenrige (`"hello"`), byte tekenrige (`b"hello"`), teken (`'a'`), byte karakter (`b'a'`), in hiel getal of driuwend puntnûmer mei of sûnder efterheaksel (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Booleaanske lettertekens lykas `true` en `false` hearre hjir net by, se binne `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Makket in nij efterheaksel hiel getal oan mei de oantsjutte wearde.
        ///
        /// Dizze funksje sil in hiel getal lykas `1u32` oanmeitsje wêr't de oantsjutte heule wearde it earste diel is fan 'e token en de yntegraal ek oan it ein wurdt efterhelle.
        /// Literatueren oanmakke út negative getallen oerlibje miskien net rûnreizen troch `TokenStream` as snaren en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
        ///
        ///
        /// Letteren makke fia dizze metoade hawwe standert de `Span::call_site()`-span, dy't kin wurde konfigureare mei de `set_span`-metoade hjirûnder.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Makket in nij net-tafoege heule getal letterlik mei de oantsjutte wearde.
        ///
        /// Dizze funksje sil in hiel getal lykas `1` oanmeitsje wêr't de oantsjutte heule getal it earste diel is fan 'e token.
        /// D'r is gjin efterheaksel opjûn op dizze token, wat betsjut dat oanroppen lykas `Literal::i8_unsuffixed(1)` lykweardich binne oan `Literal::u32_unsuffixed(1)`.
        /// Literatueren oanmakke út negative getallen oerlibje miskien rontrips fia `TokenStream` as snaren net en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
        ///
        ///
        /// Letteren makke fia dizze metoade hawwe standert de `Span::call_site()`-span, dy't kin wurde konfigureare mei de `set_span`-metoade hjirûnder.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Makket in nij net-taheakke letterlik driuwend punt oan.
    ///
    /// Dizze konstruktor is fergelykber mei dy lykas `Literal::i8_unsuffixed` wêr't de floatwearde direkt wurdt útjûn yn 'e token, mar gjin efterheaksel wurdt brûkt, dus it kin wurde ôfliede om letter in `f64` te wêzen yn' e kompilator.
    ///
    /// Literatueren oanmakke út negative getallen oerlibje miskien rontrips fia `TokenStream` as snaren net en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
    ///
    /// # Panics
    ///
    /// Dizze funksje fereasket dat de oantsjutte float einich is, bygelyks as it ûneinich is of NaN sil dizze funksje panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Makket in nij efterheaksel letterlik driuwend punt.
    ///
    /// Dizze konstrukteur sil in letterlik meitsje lykas `1.0f32` wêr't de oantsjutte wearde it foargeande diel fan 'e token is en `f32` it efterheaksel fan' e token is.
    /// Dizze token sil altyd wurde ôflaat om in `f32` te wêzen yn 'e kompilearder.
    /// Literatueren oanmakke út negative getallen oerlibje miskien rontrips fia `TokenStream` as snaren net en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
    ///
    ///
    /// # Panics
    ///
    /// Dizze funksje fereasket dat de oantsjutte float einich is, bygelyks as it ûneinich is of NaN sil dizze funksje panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Makket in nij net-taheakke letterlik driuwend punt oan.
    ///
    /// Dizze konstruktor is fergelykber mei dy lykas `Literal::i8_unsuffixed` wêr't de floatwearde direkt wurdt útjûn yn 'e token, mar gjin efterheaksel wurdt brûkt, dus it kin wurde ôfliede om letter in `f64` te wêzen yn' e kompilator.
    ///
    /// Literatueren oanmakke út negative getallen oerlibje miskien rontrips fia `TokenStream` as snaren net en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
    ///
    /// # Panics
    ///
    /// Dizze funksje fereasket dat de oantsjutte float einich is, bygelyks as it ûneinich is of NaN sil dizze funksje panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Makket in nij efterheaksel letterlik driuwend punt.
    ///
    /// Dizze konstrukteur sil in letterlik meitsje lykas `1.0f64` wêr't de oantsjutte wearde it foargeande diel fan 'e token is en `f64` it efterheaksel fan' e token is.
    /// Dizze token sil altyd wurde ôflaat om in `f64` te wêzen yn 'e kompilearder.
    /// Literatueren oanmakke út negative getallen oerlibje miskien rontrips fia `TokenStream` as snaren net en kinne wurde opdield yn twa tokens (`-` en posityf letterlik).
    ///
    ///
    /// # Panics
    ///
    /// Dizze funksje fereasket dat de oantsjutte float einich is, bygelyks as it ûneinich is of NaN sil dizze funksje panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte string letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Jout de spanwiidte fan dizze letterlike.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigureart de span dy't assosjearre is foar dizze letterlike.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Jout in `Span` dat in subset fan `self.span()` is dy't allinich de boarne bytes befettet yn berik `range`.
    /// Jout `None` werom as de besunige span bûten de grinzen fan `self` leit.
    ///
    // FIXME(SergioBenitez): kontrolearje dat it byteberik begjint en einiget op in UTF-8-grins fan 'e boarne.
    // oars is it wierskynlik dat in panic earne oars sil foarkomme as de boarnetekst wurdt ôfprinte.
    // FIXME(SergioBenitez): d'r is gjin manier foar de brûker om te witten wat `self.span()` eins yn kaart bringt, dat dizze metoade kin op it stuit allinich blyn neamd wurde.
    // Bygelyks, `to_string()` foar it karakter 'c' jout "'\u{63}'" werom;d'r is gjin manier foar de brûker om te witten oft de boarnetekst 'c' wie of dat it '\u{63}' wie.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) wat besibbe oan `Option::cloned`, mar foar `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, de brêge leveret allinich `to_string`, `fmt::Display` útfiere op basis dêrfan (it omkearde fan 'e gewoane relaasje tusken de twa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printset de letterlike ôf as in tekenrige dy't ferliesleas konvertibel wêze moat werom yn deselde letterlike (útsein foar mooglike ôfrûning foar driuwende letterliteralen).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Tracked tagong ta omjouwingsfariabelen.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Untfange in omjouwingsfariabele en foegje dizze ta oan it bouwen fan ôfhinklikensynfo.
    /// Build-systeem dat de kompiler útfiert, sil wite dat de fariabele tagong waard by kompilaasje, en sil de build kinne opnij útfiere as de wearde fan dizze fariabele feroaret.
    ///
    /// Njonken it folgjen fan ôfhinklikens moat dizze funksje lykweardich wêze mei `env::var` út 'e standertbibleteek, útsein dat it argumint UTF-8 moat wêze.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}