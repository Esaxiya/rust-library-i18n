//! Windows SEH
//!
//! Op Windows (op it stuit allinich op MSVC) is it standert behannelingsmeganisme foar útsûndering Structured Exception Handling (SEH).
//! Dit is heul oars as op Dwarf-basearre útsûnderingshanneling (bgl. Wat oare unix-platfoarms brûke) yn termen fan ynterne kompilator, dus is LLVM ferplicht in soad ekstra stipe foar SEH te hawwen.
//!
//! Yn in nutedop is wat hjir bart:
//!
//! 1. De `panic`-funksje neamt de standert Windows-funksje `_CxxThrowException` om in C++ -lykas útsûndering te gooien, wêrtroch it ûntwikkelingsproses aktiveart.
//! 2.
//! Alle lâningspads generearre troch de kompilear brûke de persoanlikheidsfunksje `__CxxFrameHandler3`, in funksje yn 'e CRT, en de ûntspanningskoade yn Windows sil dizze persoanlikheidsfunksje brûke om alle opromingskoade op' e stack út te fieren.
//!
//! 3. Alle kompilear-generearre oproppen nei `invoke` hawwe in lâningsplak ynsteld as in `cleanuppad` LLVM-ynstruksje, wat it begjin fan 'e opromingsroutine oanjout.
//! De persoanlikheid (yn stap 2, definieare yn 'e CRT) is ferantwurdlik foar it útfieren fan de skjinmakingsroutines.
//! 4. Uteinlik wurdt de "catch"-koade yn 'e `try` yntrinsike (generearre troch de kompiler) útfierd en jout oan dat kontrôle werom moat nei Rust.
//! Dit wurdt dien fia in `catchswitch` plus in `catchpad`-ynstruksje yn LLVM IR-termen, en einlings wer normale kontrôle werom nei it programma mei in `catchret`-ynstruksje.
//!
//! Guon spesifike ferskillen fan 'e gcc-basearre útsûnderingshanneling binne:
//!
//! * Rust hat gjin oanpaste persoanlikheidsfunksje, it is ynstee *altyd*`__CxxFrameHandler3`.Derneist wurdt gjin ekstra filtering útfierd, dus wy fange alle C++ útsûnderingen dy't tafallich lykje op it soarte dat wy smite.
//! Tink derom dat in útsûndering yn Rust goaie is lykwols definieare gedrach, dus dit moat goed wêze.
//! * Wy hawwe wat gegevens om te stjoeren oer de ôfwikkeljende grins, spesifyk in `Box<dyn Any + Send>`.Lykas by útsûnderingen fan Dwerch wurde dizze twa oanwizings opslein as lading yn 'e útsûndering sels.
//! Op MSVC is d'r lykwols gjin ferlet fan in ekstra heuvelferdieling om't de opropstapel bewarre wurdt wylst filterfunksjes wurde útfierd.
//! Dit betsjuttet dat de oanwizings direkt nei `_CxxThrowException` wurde trochjûn, dy't dan wurde weromfûn yn 'e filterfunksje om te skriuwen nei it stackframe fan' e intrinsike `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dit moat in opsje wêze, om't wy de útsûndering fange troch referinsje en har destruktor wurdt útfierd troch de C++ runtime.
    // As wy it fakje út 'e útsûndering nimme, moatte wy de útsûndering yn in jildige steat litte foar syn destruktor om te rinnen sûnder it fakje dûbel te fallen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Earst op, in heule bulte type definysjes.D'r binne hjir in pear platfoarm-spesifike eigenaardichheden, en in protte dat gewoan blatant is kopieare fan LLVM.It doel fan dit alles is it útfieren fan 'e `panic`-funksje hjirûnder fia in oprop nei `_CxxThrowException`.
//
// Dizze funksje nimt twa arguminten.De earste is in oanwizer nei de gegevens dy't wy trochjaan, wat yn dit gefal ús trait-objekt is.Frij maklik te finen!De folgjende is lykwols yngewikkelder.
// Dit is in oanwizer nei in `_ThrowInfo`-struktuer, en it is gewoanlik bedoeld om gewoan de útsûndering te beskriuwen dy't wurdt smiten.
//
// Op it stuit is de definysje fan dit type [1] in bytsje harich, en de wichtichste eigenaardichheid (en ferskil fan it online artikel) is dat de oanwizers op 32-bit oanwizings binne, mar op 64-bit wurde de oanwizers útdrukt as 32-bit offsets fan 'e `__ImageBase` symboal.
//
// De makro `ptr_t` en `ptr!` yn 'e ûndersteande modules wurde brûkt om dit út te drukken.
//
// It labyrint fan type definysjes folget ek nau wat LLVM emitearret foar dit soarte operaasjes.As jo bygelyks dizze C++ -koade op MSVC kompilearje en de LLVM IR útstjoere:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      leech foo() { rust_panic a = {0, 1};
//          goaie a;}
//
// Dat is yn essinsje wat wy besykje te emulearjen.De measte fan 'e konstante wearden hjirûnder waarden gewoan kopieare fan LLVM,
//
// Yn alle gefallen binne dizze struktueren allegear op in ferlykbere manier konstruearre, en it is gewoan wat wiidweidich foar ús.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Tink derom dat wy hjir mei opsetsin regels foar negearrings negearje: wy wolle net dat C++ Rust panics kin fange troch gewoan in `struct rust_panic` te ferklearjen.
//
//
// Soargje by it wizigjen derfoar dat de tekenrige fan 'e namme krekt oerienkomt mei dy yn `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // De liedende `\x01`-byte hjir is eins in magysk sinjaal nei LLVM om *gjin* oare mangling oan te passen lykas foarôfgeand oan in `_`-karakter.
    //
    //
    // Dit symboal is de vtabel dy't wurdt brûkt troch C++ 's `std::type_info`.
    // Objekten fan it type `std::type_info`, type omskriuwers, hawwe in oanwizer nei dizze tabel.
    // Typebeskriuwers wurde referearre troch de hjirboppe definieare C++ EH-struktueren en dy't wy hjirûnder bouwe.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Dizze type beskriuwing wurdt allinich brûkt as in útsûndering smyt.
// It fangen diel wurdt behannele troch de yntrinsike try, dy't in eigen TypeDescriptor genereart.
//
// Dit is prima, om't de MSVC-runtime stringferliking brûkt op 'e type namme om te passen by TypeDescriptors ynstee fan oanwizer fan' e oanwizer.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor brûkt as de C++ -koade beslút de útsûndering te feroverjen en te fallen sûnder te propagearjen.
// It fangdiel fan 'e yntinsive besykje sil it earste wurd fan it útsûnderingsobjekt op 0 sette, sadat it wurdt oerslein troch de destruktor.
//
// Tink derom dat x86 Windows de "thiscall"-opropkonvinsje brûkt foar C++ -lidfunksjes ynstee fan de standert "C"-opropkonvinsje.
//
// De funksje exception_copy is hjir in bytsje spesjaal: it wurdt oproppen troch de MSVC-runtime ûnder in try/catch-blok en de panic dy't wy hjir generearje sil brûkt wurde as resultaat fan 'e útsûnderingskopie.
//
// Dit wurdt brûkt troch de C++ runtime om stipe te meitsjen foar útsûnderingen mei std::exception_ptr, dy't wy net kinne stypje om't Box<dyn Any>is net klonber.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException útfiert folslein op dit stapelframe, dus it is net nedich om `data` oars oer te dragen nei de heap.
    // Wy jouwe gewoan in stapelwizer nei dizze funksje.
    //
    // De ManuallyDrop is hjir nedich, om't wy net wolle dat útsûndering wurdt weilitten by ûntspanning.
    // Ynstee sil it wurde fallen troch exception_cleanup dat wurdt oproppen troch de C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dit ... kin ferrassend lykje, en terjochte.Op 32-bit MSVC binne de oanwizings tusken dizze struktuer krekt dat, oanwizings.
    // Op 64-bit MSVC wurde de oanwizings tusken struktueren lykwols earder útdrukt as 32-bit offsets fan `__ImageBase`.
    //
    // Dêrtroch kinne wy op 32-bit MSVC al dizze oanwizings ferklearje yn 'hjirboppe statyske.
    // Op 64-bit MSVC soene wy subtraksje fan oanwizers yn statyk moatte útdrukke, wat Rust op it stuit net tastiet, dat wy kinne dat eins net dwaan.
    //
    // It folgjende bêste ding is dan dizze struktueren yn te foljen by runtime (panyk is dochs al de "slow path").
    // Dat hjir ynterpretearje wy al dizze oanwizerfjilden as 32-bit gehielde getallen en bewarje dan de relevante wearde dêryn (atoomysk, om't tagelyk panics kin barre).
    //
    // Technysk sil de runtime wierskynlik in nonatomyske lêzing fan dizze fjilden dwaan, mar yn teory lêze se noait de *ferkearde* wearde, dus it moat net te min wêze ...
    //
    // Yn alle gefallen moatte wy yn prinsipe sokssawat dwaan oant wy mear operaasjes yn statyk kinne útdrukke (en wy kinne it noait kinne).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // In NULL-lading hjir betsjuttet dat wy hjir binne fan 'e fang (...) fan __rust_try.
    // Dit bart as in bûtenlânske útsûndering dy't net Rust is fongen.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dit is ferplicht troch de gearstaller om te bestean (bgl. It is in lang item), mar it wurdt noait eins neamd troch de gearstaller omdat __C_specific_handler of_except_handler3 de persoanlikheidsfunksje is dy't altyd wurdt brûkt.
//
// Hjirtroch is dit gewoan in ôfbrekke stomp.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}