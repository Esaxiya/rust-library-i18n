//! Untwikkelje panics foar Miri.
use alloc::boxed::Box;
use core::any::Any;

// It type fan 'e lading dy't de Miri-motor propageart troch ûntspannen foar ús.
// Moat pointergrutte wêze.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri levere eksterne funksje om te ûntspannen.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // De lading dy't wy trochjaan oan `miri_start_panic` sil krekt it argumint wêze dat wy hjirûnder yn `cleanup` krije.
    // Dat wy bokse it gewoan ien kear op, om wat oanwizer te krijen.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ferfange de ûnderlizzende `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}