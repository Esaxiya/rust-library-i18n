//! Ymplemintaasje fan panics fia ûntspannen fan stack
//!
//! Dizze crate is in ymplemintaasje fan panics yn Rust mei help fan "most native" stack-ûntspanningsmeganisme fan it platfoarm dêrfoar wurdt kompilearre.
//! Dit wurdt op it stuit yndield yn trije bakken:
//!
//! 1. MSVC-doelen brûke SEH yn it `seh.rs`-bestân.
//! 2. Emscripten brûkt C++ útsûnderingen yn it `emcc.rs`-bestân.
//! 3. Alle oare doelen brûke libunwind/libgcc yn it `gcc.rs`-bestân.
//!
//! Mear dokumintaasje oer elke ymplemintaasje is te finen yn 'e oanbelangjende module.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` is net brûkt mei Miri, dus warskôgje stilte.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // De opstartobjekten fan Rust runtime binne ôfhinklik fan dizze symboalen, dus meitsje se iepenbier.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Doelstellingen dy't gjin ûntspannen stypje.
        // - arch=wasm32
        // - os=gjin ("bare metal"-doelen)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Brûk de Miri-runtime.
        // Wy moatte de normale runtime hjirboppe ek noch lade, om't rustc ferwachtet dat bepaalde lang items fanôf dêr definieare wurde.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Brûk de echte runtime.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler yn libstd belle as in panic-objekt bûten `catch_unwind` wurdt sakke.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler yn libstd belle as in bûtenlânske útsûndering wurdt fongen.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Yntreepunt foar it ferheegjen fan in útsûndering, delegeart gewoan nei de platfoarm-spesifike ymplemintaasje.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}