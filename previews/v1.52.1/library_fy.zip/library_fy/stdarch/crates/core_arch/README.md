`core::arch` - De kearnbibleteek-arsjitektuer-spesifike yntrinsika fan Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

De `core::arch`-module ymplementeart arsjitektuerôfhinklike yntrinsika (bgl. SIMD).

# Usage 

`core::arch` is te krijen as ûnderdiel fan `libcore` en it wurdt opnij eksportearre troch `libstd`.Brûk it leaver fia `core::arch` of `std::arch` dan fia dizze crate.
Ynstabile funksjes binne faaks te krijen yn nachtlike Rust fia de `feature(stdsimd)`.

`core::arch` brûke fia dizze crate fereasket nachts Rust, en it kin (en docht) faak brekke.De iennige gefallen wêryn jo it brûke moatte oer dizze crate binne:

* as jo `core::arch` sels opnij moatte kompilearje, bgl. mei bepaalde ynskakele doelfunksjes dy't net binne ynskeakele foar `libcore`/`libstd`.
Note: as jo it opnij kompilearje moatte foar in net-standert doel, brûk asjebleaft `xargo` en `libcore`/`libstd` opnij kompilearje as passend ynstee fan dizze crate te brûken.
  
* guon funksjes brûke dy't miskien net beskikber binne sels efter ynstabile Rust-funksjes.Wy besykje dizze oant in minimum te beheinen.
As jo guon fan dizze funksjes brûke moatte, iepenje asjebleaft in probleem sadat wy se yn 'e nachtlike Rust kinne eksposearje en jo se dêrwei kinne brûke.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` wurdt primêr ferspraat ûnder de betingsten fan sawol de MIT-lisinsje as de Apache-lisinsje (Ferzje 2.0), mei dielen behannele troch ferskate BSD-lykas lisinsjes.

Sjoch LICENSE-APACHE, en LICENSE-MIT foar details.

# Contribution

Behalven as jo oars eksplisyt sizze, sil elke bydrage dy't mei opsetsin wurdt yntsjinne foar opnimmen yn `core_arch` troch jo, lykas definieare yn 'e Apache-2.0-lisinsje, as hjirboppe lisinsearre wurde sûnder ekstra betingsten of betingsten.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












