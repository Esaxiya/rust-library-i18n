use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Wurdt brûkt om ús `#[assert_instr]`-oantekeningen te fertellen dat alle simd-yntrinsika beskikber binne om har codegen te testen, om't guon efter in ekstra `-Ctarget-feature=+unimplemented-simd128` binne poarte dy't no no gjin ekwivalint hat yn `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}