# Bydrage oan stdarch

De `stdarch` crate is mear dan ree om bydragen te akseptearjen!Earst wolle jo wierskynlik it repository kontrolearje en derfoar soargje dat tests foar jo passe:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Wêr't `<your-target-arch>` de doelfâldige triple is lykas brûkt troch `rustup`, bgl. `x86_x64-unknown-linux-gnu` (sûnder foarôfgeande `nightly-` as soksoarte).
Unthâld ek dat dit repository it nachtkanaal fan Rust fereasket!
De boppesteande tests fereaskje eins dat rust jûns de standert is op jo systeem, om dat gebrûk `rustup default nightly` (en `rustup default stable` om werom te setten) yn te stellen.

As ien fan 'e boppesteande stappen net wurket, [please let us know][new]!

Hjirnei kinne jo [find an issue][issues] helpe, wy hawwe in pear selekteare mei de [`help wanted`][help]-en [`impl-period`][impl]-tags dy't benammen wat help kinne brûke. 
Jo kinne it meast ynteressearje yn [#40][vendor], en implementearje alle yntrinsika's fan leveransiers op x86.Dat probleem hat wat goede oanwizings oer wêr't te begjinnen!

As jo algemiene fragen hawwe, fiel jo frij om [join us on gitter][gitter] en freegje om!Fiel jo frij om@BurntSushi as@alexcrichton mei fragen te pingeljen.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hoe kinne jo foarbylden skriuwe foar intradinsjes fan stdarch

D'r binne in pear funksjes dy't moatte wurde ynskeakele foar de opjûne intrinsike om goed te wurkjen en it foarbyld moat allinich wurde útfierd troch `cargo test --doc` as de funksje wurdt stipe troch de CPU.

As resultaat sil de standert `fn main` dy't wurdt generearre troch `rustdoc` net wurkje (yn 'e measte gefallen).
Tink oan it brûken fan it folgjende as hantlieding om te soargjen dat jo foarbyld wurket lykas ferwachte.

```rust
/// # // Wy hawwe cfg_target_feature nedich om te soargjen dat it foarbyld allinich is
/// # // rinne troch `cargo test --doc` as de CPU de funksje stipet
/// # #![feature(cfg_target_feature)]
/// # // Wy hawwe target_feature nedich foar it yntrinsike om te wurkjen
/// # #![feature(target_feature)]
/// #
/// # // rustdoc brûkt standert `extern crate stdarch`, mar wy moatte de
/// # // `#[macro_use]`
/// # # [macro_use] ekstern crate stdarch;
/// #
/// # // De echte haadfunksje
/// # fn main() {
/// #     // Laad dit allinich as `<target feature>` wurdt stipe
/// #     as cfg_feature_enabled! ("<target feature>"){
/// #         // Meitsje in `worker`-funksje dy't allinich wurdt útfierd as de doelfunksje
/// #         // wurdt stipe en soargje derfoar dat `target_feature` is ynskeakele foar jo arbeider
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ûnfeilich fn worker() {
/// // Skriuw jo foarbyld hjir.Funksje spesifike yntrinsiken sille hjir wurkje!Gean wyld!
///
/// #         }
///
/// #         ûnfeilich { worker(); }
/// #     }
/// # }
```

As guon fan 'e boppesteande syntaksis net fertroud sjocht, beskriuwt de [Documentation as tests]-seksje fan' e [Rust Book] de `rustdoc`-syntaksis frij goed.
Lykas altyd, fiel jo frij om [join us on gitter][gitter] te freegjen en freegje ús as jo alle snags hawwe, en tankje jo foar it helpen by it ferbetterjen fan de dokumintaasje fan `stdarch`!

# Ynstruksjes foar alternative testen

It is algemien oan te rieden dat jo `ci/run.sh` brûke om de tests út te fieren.
Dit kin lykwols net foar jo wurkje, bgl. As jo op Windows binne.

Yn dat gefal kinne jo weromfalle nei it útfieren fan `cargo +nightly test` en `cargo +nightly test --release -p core_arch` foar testen fan de koade-generaasje.
Tink derom dat dizze de nachtlike arkketen nedich binne te ynstallearjen en dat `rustc` te witten is oer jo doelfâldige triple en syn CPU.
Yn it bysûnder moatte jo de omjouwingsfariabele `TARGET` ynstelle lykas by `ci/run.sh`.
Derneist moatte jo `RUSTCFLAGS` ynstelle (de `C` nedich) om doelfunksjes oan te jaan, bgl `RUSTCFLAGS="-C -target-features=+avx2"`.
Jo kinne `-C -target-cpu=native` ek ynstelle as jo "just" ûntwikkelje tsjin jo hjoeddeistige CPU.

Wês warskôge dat as jo dizze alternative ynstruksjes brûke, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], bgl
ynstruksjegeneraasjetests kinne mislearje, om't de disassembler se oars neamde, bgl
it kin `vaesenc` generearje ynstee fan `aesenc`-ynstruksjes, hoewol se itselde gedrage.
Dizze ynstruksjes fiere ek minder tests út dan normaal soe wurde dien, dat ferjit jo net dat as jo úteinlik pull-fersykje, wat flaters kinne ferskine foar tests dy't hjir net behannele binne.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






