/// Makket in [`Vec`] mei de arguminten.
///
/// `vec!` lit `Vec`s wurde definieare mei deselde syntaksis as array-ekspresjes.
/// D'r binne twa foarmen fan dizze makro:
///
/// - Meitsje in [`Vec`] mei in opjûne list mei eleminten:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Meitsje in [`Vec`] út in bepaald elemint en grutte:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Tink derom dat yn tsjinstelling ta array-ekspresjes dizze syntaksis alle eleminten stipet dy't [`Clone`] ymplementearje en it oantal eleminten hoecht net konstant te wêzen.
///
/// Dit sil `clone` brûke om in ekspresje te duplisearjen, dus men moat foarsichtich wêze mei dit te brûken mei typen dy't in net-standert `Clone`-ymplemintaasje hawwe.
/// Bygelyks `vec![Rc::new(1);5] `sil in vector oanmeitsje fan fiif referinsjes nei deselde yntegerwearde, net fiif referinsjes dy't ferwize nei ûnôfhinklik ynboxen yn totaal.
///
///
/// Tink derom ek dat `vec![expr; 0]` tastien is, en in lege vector produseart.
/// Dit sil `expr` lykwols noch evaluearje en de resultearjende wearde fuortdaliks falle, dus tink oan side-effekten.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): mei cfg(test) is de ynherinte `[T]::into_vec`-metoade, dy't nedich is foar dizze makrodefinysje, net beskikber.
// Brûk ynstee de `slice::into_vec`-funksje dy't allinich te krijen is mei cfg(test) NB sjoch de slice::hack-module yn slice.rs foar mear ynformaasje
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Makket in `String` oan mei ynterpolaasje fan runtime-ekspresjes.
///
/// It earste argumint dat `format!` krijt is in opmaakstring.Dit moat in tekenrige wêze.De krêft fan 'e opmaakstring sit yn' e '{} s befette.
///
/// Ekstra parameters oerdroegen oan `format!` ferfangt de '{}' s yn 'e opmaakstring yn' e oarder, útsein as neamd of posysjonele parameters wurde brûkt;sjoch [`std::fmt`] foar mear ynformaasje.
///
///
/// In mienskiplik gebrûk foar `format!` is ferbining en ynterpolaasje fan snaren.
/// Deselde konvinsje wurdt brûkt mei [`print!`]-en [`write!`]-makro's, ôfhinklik fan 'e bedoelde bestimming fan' e tekenrige.
///
/// Om de ienige wearde nei in string te konvertearjen, brûk de [`to_string`]-metoade.Dit sil de [`Display`]-opmaak trait brûke.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics as in opmaak fan trait-ymplemintaasje in flater jout.
/// Dit jout oan in ferkearde ymplemintaasje, om't `fmt::Write for String` noait in flater sels werombringt.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Force AST-knooppunt nei in ekspresje om diagnostyk yn patroanposysje te ferbetterjen.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}