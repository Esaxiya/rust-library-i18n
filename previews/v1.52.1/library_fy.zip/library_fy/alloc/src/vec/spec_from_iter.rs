use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spesjalisaasje trait brûkt foar Vec::from_iter
///
/// ## De delegaasjegrafyk:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // In mienskiplik gefal is it trochjaan fan in vector yn in funksje dy't fuortendaliks opnij sammelt yn in vector.
        // Wy kinne dit kortslute as de IntoIter hielendal net foarút is.
        // As it foarútgien is, kinne wy it ûnthâld ek opnij brûke en de gegevens nei de foarkant ferpleatse.
        // Mar wy dogge dat allinich as de resultearjende Vec net mear unbenutte kapasiteit soe hawwe dan it oanmeitsjen fia de generike FromIterator-ymplemintaasje.
        //
        // Dy beheining is net strikt nedich, om't it tawizingsgedrach fan Vec mei opsetsin net spesifisearre is.
        // Mar it is in konservative kar.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // moat delegearje nei spec_extend(), om't extend() sels delegeart nei spec_from foar lege Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dit brûkt `iterator.as_slice().to_vec()`, om't spec_extend mear stappen moat nimme om te redenearjen oer de definitive kapasiteit + lingte en dus mear wurk dwaan.
// `to_vec()` dielt direkt it juste bedrach ta en follet it presys yn.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): mei cfg(test) is de ynherinte `[T]::to_vec`-metoade, dy't nedich is foar dizze metoadedefinysje, net beskikber.
    // Brûk ynstee de `slice::to_vec`-funksje dy't allinich te krijen is mei cfg(test) NB sjoch de slice::hack-module yn slice.rs foar mear ynformaasje
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}