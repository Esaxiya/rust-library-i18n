#![stable(feature = "rust1", since = "1.0.0")]

//! Rigelfeilige oanwizings foar tellen fan referinsjes.
//!
//! Sjoch de [`Arc<T>`][Arc]-dokumintaasje foar mear details.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// In sêfte limyt op it oantal referinsjes dat kin wurde makke nei in `Arc`.
///
/// Boppe dizze limyt gean sil jo programma (hoewol net needsaaklik) ôfbrekke by _exactly_ `MAX_REFCOUNT + 1`-referinsjes.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer stipet gjin ûnthâldhekken.
// Om falske positive rapporten yn Arc/Swakke ymplemintaasje te foarkommen, brûke jo ynstee atomyske lesten foar syngronisaasje.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// In triedfeilige oanwizer foar referinsjetelling.'Arc' stiet foar 'Atomically Reference Counted'.
///
/// It type `Arc<T>` leveret dielde eigendom fan in wearde fan it type `T`, tawiisd yn 'e heap.[`clone`][clone] op `Arc` oanroppe produseart in nij `Arc`-eksimplaar, dat wiist op deselde tawizing op 'e heap as de boarne `Arc`, wylst in referinsjetelling fergruttet.
/// As de lêste `Arc`-oanwizer nei in opjûne tawizing wurdt ferneatige, wurdt de yn dizze tawizing opslein wearde (faak oantsjutten as "inner value") ek sakke.
///
/// Diele referinsjes yn Rust jouwe mutaasje standert net ta, en `Arc` is gjin útsûndering: jo kinne oer it algemien gjin feroarbere ferwizing nei wat binnen in `Arc` krije.As jo moatte mutearje fia in `Arc`, brûk dan [`Mutex`][mutex], [`RwLock`][rwlock], of ien fan 'e [`Atomic`][atomic]-typen.
///
/// ## Thread Feiligens
///
/// Oars as [`Rc<T>`] brûkt `Arc<T>` atomyske operaasjes foar har referinsjetelling.Dit betsjut dat it tried-feilich is.It neidiel is dat atoombedriuwen djoerder binne dan gewoane ûnthâldtoegangen.As jo gjin referinsjes telle allocaasjes diele tusken threads, beskôgje dan [`Rc<T>`] te brûken foar legere overhead.
/// [`Rc<T>`] is in feilige standert, om't de gearstaller elk besykjen sil fange om in [`Rc<T>`] tusken triedden te stjoeren.
/// In bibleteek kin lykwols `Arc<T>` kieze om bibleteekkonsuminten mear fleksibiliteit te jaan.
///
/// `Arc<T>` sil [`Send`] en [`Sync`] ymplemintearje salang't de `T` [`Send`] en [`Sync`] ymplementeart.
/// Wêrom kinne jo in net-thread-feilich type `T` yn in `Arc<T>` sette om it thread-safe te meitsjen?Dit kin earst in bytsje tsjin-yntuïtyf wêze: is it punt fan `Arc<T>`-threadfeiligens ommers net?De kaai is dit: `Arc<T>` makket it thread feilich om meardere eigendom fan deselde gegevens te hawwen, mar it foeget gjin feiligens foar thread oan har gegevens ta.
///
/// Tink oan `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] is net [`Sync`], en as `Arc<T>` altyd [`Send`] wie, is 'Arc <`[` RefCell<T>`]`> `soe ek wêze.
/// Mar dan hawwe wy in probleem:
/// [`RefCell<T>`] is net tried feilich;it hâldt de lieningstelling by mei help fan net-atomyske operaasjes.
///
/// Oan 'e ein betsjuttet dit dat jo `Arc<T>` miskien moatte pearje mei in soarte fan [`std::sync`]-type, meast [`Mutex<T>`][mutex].
///
/// ## Breaking cycles mei `Weak`
///
/// De [`downgrade`][downgrade]-metoade kin brûkt wurde om in [`Weak`]-oanwizer dy't net besit is oan te meitsjen.In [`Weak`]-oanwizer kin wêze [`upgrade`][upgrade] d nei in `Arc`, mar dit sil [`None`] werombringe as de wearde opslein yn 'e tawizing al is sakke.
/// Mei oare wurden, `Weak`-pointers hâlde de wearde yn 'e allocaasje net libben;lykwols *hâlde se* de allocaasje (de backing store foar de wearde) libben.
///
/// In syklus tusken `Arc`-oanwizers wurdt nea deallokeard.
/// Om dizze reden wurdt [`Weak`] brûkt om syklussen te brekken.In beam kin bygelyks sterke `Arc`-oanwizers hawwe fan âlderknooppunten nei bern, en [`Weak`]-oanwizings fan bern werom nei har âlders.
///
/// # Cloning referinsjes
///
/// In nije referinsje oanmeitsje fanút in besteande referinsjetelke oanwizer wurdt dien mei de `Clone` trait ymplementeare foar [`Arc<T>`][Arc] en [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De twa hjirûnder syntaksis binne ekwivalint.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b en foo binne allegear Bôgen dy't wize op deselde ûnthâldlokaasje
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatysk ferwiderje nei `T` (fia de [`Deref`][deref] trait), sadat jo de metoaden fan 'T' kinne skilje op in wearde fan it type `Arc<T>`.Om nammebotsingen mei 'T'-metoaden te foarkommen, binne de metoaden fan `Arc<T>` sels assosjeare funksjes, neamd [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>De ymplementaasjes fan traits lykas `Clone` kinne ek wurde neamd mei folslein kwalifisearre syntaksis.
/// Guon minsken brûke leaver folsleine kwalifisearre syntaksis, wylst oaren it foarkomme mei syntaksis fan metoade-oprop.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metoade-oprop syntaksis
/// let arc2 = arc.clone();
/// // Folslein kwalifisearre syntaksis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] docht gjin automatyske ferwidering nei `T`, om't de ynderlike wearde miskien al is sakke.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Guon unferoarlike gegevens diele tusken triedden:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Tink derom dat wy dizze tests hjir net ** útfiere.
// De windows-bouwers wurde super ûngelokkich as in tried de haadtried oerlibbet en dan tagelyk útgiet (wat deadlocks), dat wy dit gewoan foarkomme troch dizze tests net út te fieren.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// In feroarbere [`AtomicUsize`] diele:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Sjoch de [`rc` documentation][rc_examples] foar mear foarbylden fan referinsjetelling yn it algemien.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` is in ferzje fan [`Arc`] dy't in net-besitende ferwizing hat nei de behearde allocaasje.
/// De tawizing is tagong troch [`upgrade`] op te roppen op 'e `Weak`-oanwizer, dy't in ["Opsje"] "<" ["Arc"] "weromkomt<T>>`.
///
/// Sûnt in `Weak`-referinsje telt net by eigendom, sil it net foarkomme dat de wearde opslein yn 'e tawizing falt, en `Weak` sels makket gjin garânsjes oer de wearde dy't noch oanwêzich is.
///
/// Sa kin it [`None`] werombringe as [`upgrade`] d.
/// Tink derom lykwols dat in `Weak`-referinsje * foarkomt dat de tawizing sels (de backingwinkel) deallokearre wurdt.
///
/// In `Weak`-oanwizer is nuttich foar it behâld fan in tydlike ferwizing nei de tawizing beheard troch [`Arc`] sûnder te foarkommen dat de ynderlike wearde derfan falt.
/// It wurdt ek brûkt om sirkulêre referinsjes tusken [`Arc`]-oanwizers foar te kommen, om't wjerskanten referinsjes nea [`Arc`] kinne falle litte.
/// In beam kin bygelyks sterke [`Arc`]-oanwizers hawwe fan âlderknooppunten oant bern, en `Weak`-oanwizings fan bern werom nei har âlders.
///
/// De typyske manier om in `Weak`-oanwizer te krijen is [`Arc::downgrade`] te skiljen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is in `NonNull` om de grutte fan dit type yn enums te optimalisearjen, mar it is net needsaaklik in jildige oanwizer.
    //
    // `Weak::new` stelt dit yn op `usize::MAX`, sadat it gjin romte hoecht te jaan op 'e heap.
    // Dat is gjin wearde dy't in echte oanwizer ea sil hawwe, om't RcBox op syn minst 2 hat.
    // Dit is allinich mooglik as `T: Sized`;net grutte `T` bongelt noait.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dit is repr(C) oant future-bestindich tsjin mooglike fjildferoaring, wat soe ynterferearje mei oars feilige [into|from]_raw() fan transmutabele ynderlike typen.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // de wearde usize::MAX fungeart as in skildwacht foar tydlik "locking" de mooglikheid om swakke pointers op te upgrade of sterke te degradearjen;dit wurdt brûkt om races yn `make_mut` en `get_mut` te foarkommen.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstrueart in nije `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Begjin de swakke oanwizer telle as 1 dat is de swakke oanwizer dy't wurdt holden troch alle sterke oanwizers (kinda), sjoch std/rc.rs foar mear ynfo
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstrueart in nije `Arc<T>` mei in swakke ferwizing nei himsels.
    /// Besykje de swakke referinsje te ferbetterjen foardat dizze funksje weromkomt, sil resultearje yn in `None`-wearde.
    /// De swakke referinsje kin lykwols frij wurde kloneare en op in letter tiid bewarre wurde foar gebrûk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruearje it binnenste yn 'e "uninitialized"-steat mei in inkele swakke referinsje.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // It is wichtich dat wy it eigendom fan 'e swakke oanwizer net opjaan, oars kin it ûnthâld befrijd wurde as `data_fn` weromkomt.
        // As wy echt eigendom wolle trochjaan, kinne wy in ekstra swakke oanwizer foar ússels oanmeitsje, mar dit soe resultearje yn ekstra updates foar de swakke referinsjetelling dy't oars net nedich is.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // No kinne wy de ynderlike wearde goed inisjalisearje en ús swakke referinsje yn in sterke referinsje feroarje.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // It boppesteande skriuwt nei it datafjild moat sichtber wêze foar alle threads dy't in sterke telling fan net-nul observearje.
            // Dêrom hawwe wy teminsten "Release"-bestelling nedich om te syngronisearjen mei de `compare_exchange_weak` yn `Weak::upgrade`.
            //
            // "Acquire" bestellen is net fereaske.
            // As wy it mooglike gedrach fan `data_fn` beskôgje, hoege wy allinich te sjen wat it kin dwaan mei in ferwizing nei in net-opwurdearbere `Weak`:
            //
            // - It kin de `Weak` * klonearje, wêrtroch it swakke referinsjetelling fergruttet.
            // - It kin dy klonen falle, wêrtroch it swakke referinsjetelling fermindert (mar noait oant nul).
            //
            // Dizze side-effekten hawwe gjin ynfloed op ús, en gjin oare side-effekten binne allinich mooglik mei feilige koade.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Sterke referinsjes moatte kollektyf in dielde swakke referinsje hawwe, dus run de destruktor net foar ús âlde swakke referinsje.
        //
        mem::forget(weak);
        strong
    }

    /// Konstrueart in nije `Arc` mei net-inisjalisearre ynhâld.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueart in nije `Arc` mei net-inisjalisearre ynhâld, mei it ûnthâld fol mei `0`-bytes.
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueart in nije `Pin<Arc<T>>`.
    /// As `T` `Unpin` net ymplementeart, wurdt `data` yn it ûnthâld fêstmakke en kin net ferpleatst wurde.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstrueart in nije `Arc<T>`, weromsette in flater as de tawizing mislearret.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Begjin de swakke oanwizer telle as 1 dat is de swakke oanwizer dy't wurdt holden troch alle sterke oanwizers (kinda), sjoch std/rc.rs foar mear ynfo
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstrueart in nije `Arc` mei net-inisjalisearre ynhâld, en jout in flater as de tawizing mislearret.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstrueart in nije `Arc` mei net-inisjalisearre ynhâld, wêrby't it ûnthâld wurdt fol mei `0`-bytes, en jout in flater as de tawizing mislearret.
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Jout de ynderlike wearde werom, as de `Arc` presys ien sterke referinsje hat.
    ///
    /// Oars wurdt in [`Err`] weromjûn mei deselde `Arc` dy't waard trochjûn.
    ///
    ///
    /// Dit sil slagje, sels as d'r opfallende swakke referinsjes binne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Meitsje in swakke oanwizer om de ymplisite sterk-swakke referinsje op te romjen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstrueart in nije atomysk referinsjegeteld stikje mei net-inisjalisearre ynhâld.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstrueart in nij atomysk referinsjegeteld stikje mei net-inisjalisearre ynhâld, mei it ûnthâld fol mei `0` bytes.
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konverteart nei `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Lykas by [`MaybeUninit::assume_init`] is it oan 'e beller om te garandearjen dat de ynderlike wearde echt yn in inisjalisearre steat is.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket direkte undefined gedrach.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konverteart nei `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Lykas by [`MaybeUninit::assume_init`] is it oan 'e beller om te garandearjen dat de ynderlike wearde echt yn in inisjalisearre steat is.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket direkte undefined gedrach.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ferbrûkt de `Arc`, retourneert de wikkele oanwizer.
    ///
    /// Om in geheugenlek te foarkommen moat de oanwizer mei [`Arc::from_raw`] werom wurde konvertearre nei in `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Jout in rauwe oanwizer nei de gegevens.
    ///
    /// De tellen wurde op gjin inkelde manier beynfloede en de `Arc` wurdt net konsumeare.
    /// De oanwizer is jildich salang't d'r sterke tellen binne yn 'e `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kin net troch Deref::deref of RcBoxPtr::inner gean om't
        // dit is ferplicht om raw/mut herkomst te behâlden sa dat bgl
        // `get_mut` kin fia de oanwizer skriuwe neidat de Rc is weromfûn fia `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstrueart in `Arc<T>` fan in rauwe oanwizer.
    ///
    /// De rauwe oanwizer moat earder werom west hawwe troch in oprop nei [`Arc<U>::into_raw`][into_raw] wêr't `U` deselde grutte en ôfstimming moat hawwe as `T`.
    /// Dit is triviaal wier as `U` `T` is.
    /// Tink derom dat as `U` net `T` is, mar deselde grutte en ôfstimming hat, dit yn prinsipe is as ferwizings fan referinsjes fan ferskate soarten.
    /// Sjoch [`mem::transmute`][transmute] foar mear ynformaasje oer hokker beheiningen jilde yn dit gefal.
    ///
    /// De brûker fan `from_raw` moat derfoar soargje dat in spesifike wearde fan `T` mar ien kear falt.
    ///
    /// Dizze funksje is ûnfeilich om't ferkeard gebrûk liede kin ta ûnthâldfeiligens, sels as de weromkommende `Arc<T>` noait tagong wurdt.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertearje werom nei in `Arc` om lek te foarkommen.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Fierdere oproppen nei `Arc::from_raw(x_ptr)` soene geheugen-ûnfeilich wêze.
    /// }
    ///
    /// // It ûnthâld waard befrijd doe't `x` bûten it berik hjirboppe gie, dus `x_ptr` hinget no!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // De offset omkeare om it orizjinele ArcInner te finen.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Makket in nije [`Weak`]-oanwizer foar dizze tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dit ûntspannen is OK, om't wy de wearde kontrolearje yn 'e CAS hjirûnder.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrolearje as de swakke teller op it stuit "locked" is;as dat sa is, spinne.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: dizze koade negeart op it stuit de mooglikheid fan oerstreaming
            // yn usize::MAX;yn 't algemien moatte sawol Rc as Arc oanpast wurde om te gean mei oerrin.
            //

            // Oars as by Clone(), hawwe wy dit nedich om in lêzing te krijen om te syngronisearjen mei it skriuwen dat komt fan `is_unique`, sadat de barrens foarôfgeand oan dat skriuwen barre foardat dit lêzen is.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Soargje derfoar dat wy gjin hingjende Swakke meitsje
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Krijt it oantal [`Weak`]-oanwizers foar dizze tawizing.
    ///
    /// # Safety
    ///
    /// Dizze metoade is op himsels feilich, mar it korrekt brûken fereasket ekstra soarch.
    /// In oare tried kin de swakke telling op elts momint feroarje, ynklusyf potensjeel tusken dizze metoade neame en hannelje op it resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Dizze bewearing is deterministysk om't wy de `Arc` of `Weak` net hawwe dield tusken threads.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // As de swakke teller op it stuit is beskoattele, wie de wearde fan it tellen 0 krekt foardat it slot waard nommen.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Krijt it oantal sterke (`Arc`)-oanwizers foar dizze tawizing.
    ///
    /// # Safety
    ///
    /// Dizze metoade is op himsels feilich, mar it korrekt brûken fereasket ekstra soarch.
    /// In oare tried kin de sterke telling op elts momint feroarje, ynklusyf potensjeel tusken dizze metoade neame en hannelje op it resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Dizze bewearing is deterministysk om't wy de `Arc` net hawwe dield tusken threads.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Fergruttet de sterke referinsjetelling op 'e `Arc<T>` ferbûn mei de oanjûne oanwizer troch ien.
    ///
    /// # Safety
    ///
    /// De oanwizer moat fia `Arc::into_raw` krigen wêze, en it byhearrende `Arc`-eksimplaar moat jildich wêze (ie
    /// de sterke telling moat teminsten 1 wêze) foar de doer fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Dizze bewearing is deterministysk om't wy de `Arc` net hawwe dield tusken threads.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc behâlde, mar reitsje net opnij oan troch yn te pakken yn ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // No fergrutsje refcount, mar drop gjin nije refcount ek
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ferleget de sterke referinsjetelling op 'e `Arc<T>` ferbûn mei de oanjûne oanwizer troch ien.
    ///
    /// # Safety
    ///
    /// De oanwizer moat fia `Arc::into_raw` krigen wêze, en it byhearrende `Arc`-eksimplaar moat jildich wêze (ie
    /// de sterke telling moat teminsten 1 wêze) as dizze metoade opropt.
    /// Dizze metoade kin brûkt wurde om de definitive `Arc`-en backing-opslach frij te jaan, mar **moat** net neamd wurde nei't de definitive `Arc` is frijjûn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Dy bewearingen binne deterministysk, om't wy de `Arc` net hawwe dield tusken threads.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Dizze ûnfeilichheid is ok, want wylst dizze bôge libbet, wurde wy garandearre dat de ynderlike oanwizer jildich is.
        // Fierder wite wy dat de `ArcInner`-struktuer sels `Sync` is, om't de ynderlike gegevens ek `Sync` binne, dus wy kinne ok in unferoarlike oanwizer liene oan dizze ynhâld.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Net-ynline diel fan `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ferneatigje de gegevens op dit stuit, hoewol wy de fakttoewijzing sels miskien net frijmeitsje (d'r kinne noch swakke oanwizings lizze).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Drop de swakke ref kollektyf hâlden troch alle sterke referinsjes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Jout `true` werom as de twa `Arc`s op deselde tawizing wize (yn in trant lykas [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Jout in `ArcInner<T>` ta mei foldwaande romte foar in mooglik net grutte binnenwearde wêr't de wearde de opmaak hat.
    ///
    /// De funksje `mem_to_arcinner` wurdt neamd mei de gegevenswizer en moat in (potinsjeel dikke)-wizer werom jaan foar de `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Berekkenje opmaak mei de opjûne weardeopmaak.
        // Earder waard opmaak berekkene op 'e útdrukking `&*(ptr as* const ArcInner<T>)`, mar dit makke in ferkearde referinsje (sjoch #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Jout in `ArcInner<T>` ta mei genôch romte foar in mooglik net grutte binnenwearde wêr't de wearde hat de opmaak levere, en jout in flater as de tawizing mislearret.
    ///
    ///
    /// De funksje `mem_to_arcinner` wurdt neamd mei de gegevenswizer en moat in (potinsjeel dikke)-wizer werom jaan foar de `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Berekkenje opmaak mei de opjûne weardeopmaak.
        // Earder waard opmaak berekkene op 'e útdrukking `&*(ptr as* const ArcInner<T>)`, mar dit makke in ferkearde referinsje (sjoch #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialisearje de ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Jout in `ArcInner<T>` ta mei genôch romte foar in net grutte ynderlike wearde.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tawize foar de `ArcInner<T>` mei de opjûne wearde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiearje wearde as bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Befrij de tawizing sûnder de ynhâld derfan te litten
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Jout in `ArcInner<[T]>` ta mei de opjûne lingte.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopiearje eleminten fan slice yn nij tawiisd Arc <\[T\]>
    ///
    /// Unfeilich omdat de beller eigendom moat nimme of `T: Copy` moat bine.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruearret in `Arc<[T]>` fan in iterator dy't bekend is fan in beskate grutte.
    ///
    /// Gedrach is undefined as de grutte ferkeard wêze soe.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic wachter by kloning fan T-eleminten.
        // Yn it gefal fan in panic sille eleminten dy't binne skreaun yn 'e nije ArcInner falle, dan wurdt it ûnthâld befrijd.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Oanwizer nei earste elemint
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles dúdlik.Ferjit de wacht, sadat it de nije ArcInner net befrijt.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesjalisaasje trait brûkt foar `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Makket in kloon fan 'e `Arc`-oanwizer.
    ///
    /// Dit soarget foar in oare oanwizer foar deselde tawizing, wêrtroch it sterke referinsjetelling fergruttet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // In ûntspannen oardering brûke is hjir goed, om't kennis fan 'e orizjinele referinsje foarkomt dat oare triedden it objekt ferkeard wiskje.
        //
        // Lykas útlein yn 'e [Boost documentation][1], Ferheegje de referinsjeteller kin altyd dien wurde mei memory_order_relaxed: Nije referinsjes nei in objekt kinne allinich wurde foarme út in besteande referinsje, en it trochjaan fan in besteande referinsje fan de iene thread nei de oare moat al in fereaske syngronisaasje leverje.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Wy moatte lykwols hoedzje tsjin massale reftellingen foar it gefal dat immen 'mem: : ferjit' Bôgen is.
        // As wy dit net dogge, kin de telling oerstreamje en brûkers sille it fergees brûke.
        // Wy wurde rassich verzadigd nei `isize::MAX` ûnder de oanname dat d'r gjin ~2 miljard triedden tagelyk de referinsjetelling ferheegje.
        //
        // Dizze branch sil nea wurde nommen yn ien realistysk programma.
        //
        // Wy ôfbrekke omdat sa'n programma ongelooflijk degenerearre is, en wy it net skele om it te stypjen.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Makket in feroarbere ferwizing nei de opjûne `Arc`.
    ///
    /// As d'r oare `Arc`-of [`Weak`]-oanwizers binne foar deselde tawizing, sil `make_mut` in nije tawizing meitsje en [`clone`][clone] oproppe op 'e ynderlike wearde om unyk eigendom te garandearjen.
    /// Dit wurdt ek wol clone-on-write neamd.
    ///
    /// Tink derom dat dit ferskilt fan it gedrach fan [`Rc::make_mut`] dat alle oerbleaune `Weak`-oanwizers loskeppelt.
    ///
    /// Sjoch ek [`get_mut`][get_mut], dat sil mislearje ynstee fan kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Sil neat klone
    /// let mut other_data = Arc::clone(&data); // Sil gjin ynderlike gegevens klone
    /// *Arc::make_mut(&mut data) += 1;         // Klonet ynderlike gegevens
    /// *Arc::make_mut(&mut data) += 1;         // Sil neat klone
    /// *Arc::make_mut(&mut other_data) *= 2;   // Sil neat klone
    ///
    /// // No wize `data` en `other_data` op ferskate allocaasjes.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Tink derom dat wy sawol in sterke referinsje as in swakke referinsje hawwe.
        // Sadwaande sil it frijjaan fan ús sterke referinsje op himsels net feroarsaakje dat it ûnthâld ôfhannele wurdt.
        //
        // Brûk Oankeapje om derfoar te soargjen dat wy alle skriuwen nei `weak` sjogge dy't barre foardat frijlitting skriuwt (dus ôfnimmingen) nei `strong`.
        // Om't wy in swakke telling hawwe, is d'r gjin kâns dat de ArcInner sels kin wurde tawiisd.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // In oare sterke oanwizer bestiet, dat wy moatte klone.
            // Foardiel tawize geheugen om de kloneare wearde direkt te skriuwen.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relax is genôch yn it boppesteande, om't dit yn prinsipe in optimalisaasje is: wy rinne altyd mei swakke pointers dy't falle.
            // It minste gefal, wy hawwe einlings in nije Arc ûnnedich tawiisd.
            //

            // Wy hawwe de lêste sterke ref fuorthelle, mar der binne ekstra swakke refs oer.
            // Wy ferpleatse de ynhâld nei in nije bôge, en meitsje de oare swakke refs unjildich.
            //

            // Tink derom dat it net mooglik is foar it lêzen fan `weak` om usize::MAX op te leverjen (dus, beskoattele), om't de swakke telling allinich kin wurde beskoattele troch in tried mei in sterke referinsje.
            //
            //

            // Materialisearje ús eigen ymplisite swakke oanwizer, sadat it de ArcInner as nedich kin skjinmeitsje.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kin de gegevens gewoan stelle, alles wat oer is, is Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Wy wiene de ienige referinsje fan beide soarten;stypje de sterke ref count werom.
            //
            this.inner().strong.store(1, Release);
        }

        // Lykas by `get_mut()` is de ûnfeiligens ok omdat ús referinsje unyk wie om te begjinnen, of ien waard by it klonen fan 'e ynhâld.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Jout in feroarbere ferwizing nei de opjûne `Arc`, as d'r gjin oare `Arc`-of [`Weak`]-oanwizings binne foar deselde tawizing.
    ///
    ///
    /// Jout [`None`] oars werom, om't it net feilich is om in dielde wearde te mutearjen.
    ///
    /// Sjoch ek [`make_mut`][make_mut], dat [`clone`][clone] de ynderlike wearde sil as der oare oanwizings binne.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Dizze ûnfeilichheid is ok, om't wy garandearre binne dat de weromwizer de *iennige* oanwizer is dy't ea nei T weromjûn wurdt.
            // Us referinsjetelling is garandearre op dit punt 1 te wêzen, en wy hawwe de Arc sels ferplicht `mut` te wêzen, dat wy jouwe de iennichste mooglike referinsje werom nei de ynderlike gegevens.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Jout in feroarbere referinsje yn 'e opjûne `Arc`, sûnder kontrôle.
    ///
    /// Sjoch ek [`get_mut`], dat is feilich en docht passende kontrôles.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Eltse oare `Arc`-of [`Weak`]-oanwizings foar deselde tawizing meie net wurde ferwidere foar de doer fan 'e werombetelle liening.
    ///
    /// Dit is triviaal it gefal as der gjin sokke oanwizings besteane, bygelyks direkt nei `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Wy binne foarsichtich om *gjin* referinsje te meitsjen dy't de "count"-fjilden befettet, om't dit alias soe wêze mei tagelyk tagong ta de referinsjetellingen (bgl.
        // troch `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bepale oft dit de unike referinsje is (ynklusyf swakke refs) nei de ûnderlizzende gegevens.
    ///
    ///
    /// Tink derom dat dit de swakke ref-count fereasket.
    fn is_unique(&mut self) -> bool {
        // beskoattelje de swakke pointertelling as wy de ienige swakke pointerhâlder ferskine.
        //
        // It ferwervingsetiket hjir soarget foar in barrens-foar-relaasje mei skriuwen nei `strong` (yn it bysûnder yn `Weak::upgrade`) foarôfgeand oan ferlegingen fan 'e `weak`-telling (fia `Weak::drop`, dy't frijlitting brûkt).
        // As de opwurdearre swakke ref noait waard sakke, sil it CAS hjir mislearje, sadat wy it net skele om te syngronisearjen.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dit moat in `Acquire` wêze om te syngronisearjen mei de fermindering fan 'e `strong`-teller yn `drop`-de iennige tagong dy't bart as ien, mar de lêste referinsje wurdt falle litten.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // De release-skriuw hjir syngroniseart mei in lêzen yn `downgrade`, wêrtroch effektyf foarkomt dat boppesteande lêzing fan `strong` nei it skriuwen bart.
            //
            //
            self.inner().weak.store(1, Release); // lit it slot los
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Falt de `Arc` del.
    ///
    /// Dit sil de sterke referinsjetelling ferminderje.
    /// As de sterke referinsjetelling nul berikt, dan binne de iennige oare referinsjes (as ien) [`Weak`], dus wy `drop` de ynderlike wearde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Printset neat
    /// drop(foo2);   // Printsje "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Om't `fetch_sub` al atoom is, hoege wy net te syngronisearjen mei oare threads, útsein as wy it objekt wiskje.
        // Deselde logika jildt foar de hjirûnder `fetch_sub` foar de `weak`-telling.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dizze hek is nedich om opnij oarderjen fan gebrûk fan 'e gegevens en ferwidering fan' e gegevens te foarkommen.
        // Om't it `Release` is markearre, syngroniseart it ferminderjen fan 'e referinsjetelling mei dizze `Acquire`-hek.
        // Dit betsjut dat gebrûk fan 'e gegevens bart foardat de referinsjetelling fermindert, wat bart foar dizze hek, wat bart foar it wiskjen fan' e gegevens.
        //
        // Lykas útlein yn 'e [Boost documentation][1],
        //
        // > It is wichtich om alle mooglike tagong ta it objekt yn ien te twingen
        // > thread (fia in besteande referinsje) nei *barre foardat* wiskje
        // > it objekt yn in oare tried.Dit wurdt berikt troch in "release"
        // > operaasje nei in referinsje falle litten (elke tagong ta it objekt
        // > troch dizze referinsje moat fansels earder barre), en in
        // > "acquire" operaasje foardat jo it objekt wiskje.
        //
        // Yn it bysûnder, hoewol de ynhâld fan in bôge normaal ûnferoarlik is, is it mooglik om ynterieur te skriuwen oan sokssawat as in Mutex<T>,
        // Om't in Mutex net wurdt oanskaft as it wurdt wiske, kinne wy net op syn syngronisaasjelogika fertrouwe om skriuwen yn thread A sichtber te meitsjen foar in destruktor dy't yn thread B rint.
        //
        //
        // Tink derom ek dat de Feanhichte ferwiderje hjir wierskynlik koe wurde ferfongen troch in lading oernimme, dy't de prestaasjes yn heul stride situaasjes koe ferbetterje.Sjoch [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Poging de `Arc<dyn Any + Send + Sync>` te downcast nei in konkreet type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstrueart in nije `Weak<T>`, sûnder ûnthâld te allocearjen.
    /// [`upgrade`] skilje op 'e retoerwearde jouwt [`None`] altyd.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Helpertype om tagong te krijen ta de referinsjetellingen sûnder bewearingen te meitsjen oer it datafjild.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Jout in rauwe oanwizer nei it objekt `T` wiisd troch dizze `Weak<T>`.
    ///
    /// De oanwizer is allinich jildich as d'r in pear sterke referinsjes binne.
    /// De oanwizer kin oars hingje, unjustere of sels [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Beide wize op itselde objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // De sterke hjir hâldt it libben, dat wy kinne noch tagong krije ta it objekt.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mar net mear.
    /// // Wy kinne weak.as_ptr() dwaan, mar tagong ta de oanwizer soe liede ta undefined gedrach.
    /// // assert_eq! ("hallo", ûnfeilich {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // As de oanwizer hinget, stjoere wy de sentinel direkt werom.
            // Dit kin gjin jildich adres foar lading wêze, om't de lading op syn minst like ôfstimd is as ArcInner (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: as is_dangling falsk jout, dan is de oanwizer te ferwiderjen.
            // De lading kin op dit punt wurde sakke, en wy moatte de herkomst behâlde, dus brûk rûge oanwizermanipulaasje.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Ferbrûkt de `Weak<T>` en makket it yn in rauwe oanwizer.
    ///
    /// Dit konverteart de swakke oanwizer yn in rauwe oanwizer, wylst it eigendom fan ien swakke referinsje noch behâldt (de swakke telling wurdt net oanpast troch dizze operaasje).
    /// It kin werombrocht wurde yn 'e `Weak<T>` mei [`from_raw`].
    ///
    /// Deselde beheiningen foar tagong ta it doel fan 'e oanwizer jilde as mei [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverteart in rauwe oanwizer dy't earder makke is troch [`into_raw`] werom yn `Weak<T>`.
    ///
    /// Dit kin brûkt wurde om feilich in sterke referinsje te krijen (troch letter [`upgrade`] te skiljen) of om de swakke telling te fertsjinjen troch de `Weak<T>` te litten falle.
    ///
    /// It nimt eigendom fan ien swakke referinsje (mei útsûndering fan oanwizings makke troch [`new`], om't dizze neat hawwe; de metoade wurket noch altyd op har).
    ///
    /// # Safety
    ///
    /// De oanwizer moat ûntstien wêze fan 'e [`into_raw`] en moat syn potensjele swakke referinsje noch hawwe.
    ///
    /// It is tastien dat de sterke telling 0 is op it momint dat dit wurdt neamd.
    /// Dochs nimt dit eigendom fan ien swakke referinsje dy't op it stuit fertsjintwurdige is as in rauwe oanwizer (de swakke telling wurdt net wizige troch dizze operaasje) en dêrom moat it wurde keppele oan in eardere oprop nei [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ferlytsje de lêste swakke greve.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sjoch Weak::as_ptr foar kontekst oer hoe't de ynfierpointer ôflaat is.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is in hingjende Swak.
            ptr as *mut ArcInner<T>
        } else {
            // Oars wurde wy garandearre dat de oanwizer kaam fan in net-bûnte Swak.
            // VEILIGHEID: data_offset is feilich te beljen, om't ptr in echte (potinsjeel sakke) T. ferwiist.
            let offset = unsafe { data_offset(ptr) };
            // Sadwaande keare wy de offset om de hiele RcBox te krijen.
            // VEILIGHEID: de oanwizer is ûntstien út in Swak, dus dizze kompensaasje is feilich.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: wy hawwe no de orizjinele Swakke oanwizer weromfûn, dus kinne wy de Swakke oanmeitsje.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Besiket de `Weak`-oanwizer op te ferbetterjen nei in [`Arc`], fertraging fan 'e ynderlike wearde as it suksesfol is.
    ///
    ///
    /// Jout [`None`] werom as de ynderlike wearde yntusken is sakke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ferneatigje alle sterke oanwizings.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Wy brûke in CAS-loop om de sterke telling te ferheegjen ynstee fan in fetch_add, om't dizze funksje de referinsjetelling nea fan nul nei ien moat nimme.
        //
        //
        let inner = self.inner()?;

        // Relaxe lading, om't elke skriuwe fan 0 dy't wy kinne observearje it fjild yn in permanint nul-steat lit (dus in "stale"-lêzing fan 0 is prima), en elke oare wearde wurdt befestige fia it CAS hjirûnder.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Sjoch opmerkingen yn `Arc::clone` foar wêrom wy dit dogge (foar `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed is prima foar de mislearring, om't wy gjin ferwachtingen hawwe oer de nije steat.
            // Oankeap is nedich foar it suksesfak om te syngronisearjen mei `Arc::new_cyclic`, as de ynderlike wearde kin inisjalisearre wurde neidat `Weak` referinsjes al binne oanmakke.
            // Yn dat gefal ferwachtsje wy de folslein inisjalisearre wearde te observearjen.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null kontrolearre hjirboppe
                Err(old) => n = old,
            }
        }
    }

    /// Krijt it oantal sterke (`Arc`)-oanwizers dy't op dizze tawizing wize.
    ///
    /// As `self` is makke mei [`Weak::new`], sil dit 0 werombringe.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Krijt in skatting fan it oantal `Weak`-oanwizers dy't op dizze tawizing wize.
    ///
    /// As `self` is makke mei [`Weak::new`], as d'r gjin oerbleaune sterke oanwizings binne, sil dit 0 werombringe.
    ///
    /// # Accuracy
    ///
    /// Fanwegen ymplemintaasjegegevens kin de weromkommende wearde troch 1 yn beide rjochtingen útskeakele wurde as oare triedden alle 'Arc's of' Swakke 'manipulearje dy't op deselde allocaasje wize.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Om't wy observeare dat d'r nei it lêzen fan 'e swakke teller teminsten ien sterke oanwizer wie, wite wy dat de ymplisite swakke referinsje (oanwêzich as sterke referinsjes libje) noch rûn wie doe't wy de swakke tellerij observearren, en kin it dêrom feilich lûke.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Jout `None` werom as de oanwizer hinget en d'r gjin `ArcInner` tawiisd is, (dus as dizze `Weak` is makke troch `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Wy binne foarsichtich om *net* in referinsje te meitsjen dy't it "data"-fjild omfettet, om't it fjild tagelyk kin wurde muteare (bygelyks as de lêste `Arc` falt, sil it gegevensfjild te plak falle).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Jout `true` werom as de twa 'Swakke' op deselde tawizing wize (gelyk oan [`ptr::eq`]), of as beide net wize op in tawizing (om't se binne makke mei `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Om't dit oanwizings fergeliket, betsjuttet it dat `Weak::new()` inoar sille lykweardich wêze, hoewol se net op in allocaasje wize.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Fergelykje `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Makket in kloon fan 'e `Weak`-oanwizer dy't wiist op deselde tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Sjoch opmerkingen yn Arc::clone() foar wêrom dit ûntspannen is.
        // Dit kin in fetch_add brûke (negearje it slot), om't de swakke telling allinich beskoattele is wêr't *gjin oare* swakke oanwizings binne.
        //
        // (Sa kinne wy dizze koade yn dat gefal net útfiere).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Sjoch opmerkingen yn Arc::clone() foar wêrom wy dit dogge (foar mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstrueart in nije `Weak<T>`, sûnder ûnthâld te allocearjen.
    /// [`upgrade`] skilje op 'e retoerwearde jouwt [`None`] altyd.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Smyt de `Weak`-oanwizer del.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Printset neat
    /// drop(foo);        // Printsje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // As wy útfine dat wy de lêste swakke oanwizer wiene, dan is it tiid om de gegevens folslein te fertsjinjen.Sjoch de diskusje yn Arc::drop() oer de bestellingen fan ûnthâld
        //
        // It is net nedich om hjir te kontrolearjen foar de beskoattele tastân, om't de swakke telling allinich kin wurde beskoattele as d'r krekt ien swakke ref wie, wat betsjuttet dat drip pas letter op dy oerbleaune swakke ref koe draaie, wat pas kin barre neidat it slot wurdt frijjûn.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Wy dogge dizze spesjalisaasje hjir, en net as in mear algemiene optimalisaasje op `&T`, om't it oars in kosten tafoege oan alle gelikenskontrôles op refs.
/// Wy geane derfan út dat `Arc`s wurde brûkt om grutte wearden op te slaan, dy't stadich klone, mar ek swier om te kontrolearjen op gelikens, wêrtroch dizze kosten makliker betelje.
///
/// It is ek wierskynlik twa `Arc`-klonen te hawwen, dy't op deselde wearde wize, dan twa `&T`s.
///
/// Wy kinne dit allinich dwaan as `T: Eq` as `PartialEq` bewust irreflexyf wêze kin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Gelikens foar twa `Arc`s.
    ///
    /// Twa `Arc`s binne gelyk as har ynderlike wearden gelyk binne, sels as se wurde opslein yn ferskillende tawizing.
    ///
    /// As `T` ek `Eq` ymplementeart (wat refleksiviteit fan gelikens ympliseart), binne twa `Arc`s dy't op deselde tawizing wize altyd gelyk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ungelikens foar twa `Arc`s.
    ///
    /// Twa `Arc`s binne ûngelikens as har ynderlike wearden ûngelikens binne.
    ///
    /// As `T` ek `Eq` ymplementeart (refleksiviteit fan gelikens ymplisyt), binne twa `Arc`s dy't op deselde wearde wize, nea unyk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Partiel ferliking foar twa `Arc`s.
    ///
    /// De twa wurde fergelike troch `partial_cmp()` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder dan fergeliking foar twa `Arc`s.
    ///
    /// De twa wurde fergelike troch `<` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Minder as of gelyk oan' fergeliking foar twa `Arc`s.
    ///
    /// De twa wurde fergelike troch `<=` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Grutter dan fergeliking foar twa `Arc`s.
    ///
    /// De twa wurde fergelike troch `>` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Grutter dan of gelyk oan' fergeliking foar twa 'Arc`s.
    ///
    /// De twa wurde fergelike troch `>=` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Fergeliking foar twa `Arc`s.
    ///
    /// De twa wurde fergelike troch `cmp()` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Makket in nije `Arc<T>` oan, mei de `Default`-wearde foar `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tawize in troch referinsje rekkene stik en folje it troch klonen fan 'v' items.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tawize in referinsjeteld `str` en kopiearje `v` dêryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tawize in referinsjeteld `str` en kopiearje `v` dêryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Ferpleats in foarwerp yn in doaze nei in nije, troch referinsjes telle allocaasje.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tawize in skyfke dat troch referinsjes teld is en ferpleatse 'v''s items deryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Tastean de Vec har ûnthâld te befrijen, mar har ynhâld net te ferneatigjen
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Nimt elk elemint yn 'e `Iterator` en sammelt it yn in `Arc<[T]>`.
    ///
    /// # Performance skaaimerken
    ///
    /// ## De algemiene saak
    ///
    /// Yn it algemiene gefal wurdt sammeljen yn `Arc<[T]>` dien troch earst te sammeljen yn in `Vec<T>`.Dat is by it skriuwen fan it folgjende:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit gedraacht as skreau wy:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // De earste set fan allocaasjes bart hjir.
    ///     .into(); // In twadde allocaasje foar `Arc<[T]>` bart hjir.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit sil safolle kearen allocearje as nedich foar it bouwen fan 'e `Vec<T>` en dan sil it ien kear tawize foar it feroarjen fan' e `Vec<T>` yn 'e `Arc<[T]>`.
    ///
    ///
    /// ## Iterators fan bekende lingte
    ///
    /// As jo `Iterator` `TrustedLen` ymplementeart en fan in krekte grutte is, sil in inkele allocaasje wurde makke foar de `Arc<[T]>`.Bygelyks:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Krekt in inkele allocaasje bart hjir.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spesjalisaasje trait brûkt foar sammeljen yn `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dit is it gefal foar in `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: Wy moatte derfoar soargje dat de iterator in krekte lingte hat en wy hawwe.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Falle werom nei normale ymplemintaasje.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Krij de kompensaasje binnen in `ArcInner` foar de lading efter in oanwizer.
///
/// # Safety
///
/// De oanwizer moat wize op (en jildige metadata hawwe foar) in earder jildich eksimplaar fan T, mar de T is tastien te falle.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Rjochtsje de net grutte wearde út oan 'e ein fan' e ArcInner.
    // Om't RcBox repr(C) is, sil it altyd it lêste fjild yn it ûnthâld wêze.
    // VEILIGHEID: om't de iennichste net grutte soarten mooglik binne plakjes, trait-objekten,
    // en eksterne typen, de ynfierfeiligensfereaske is op it stuit genôch om te foldwaan oan de easken fan align_of_val_raw;dit is in ymplementaasjedetail fan 'e taal dy't net bûten std kin wurde fertroud.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}