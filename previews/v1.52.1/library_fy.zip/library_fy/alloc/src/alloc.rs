//! APIs foar tawizing fan ûnthâld

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Dit binne de magyske symboalen om de wrâldwide allocator te neamen.rustc genereart se om `__rg_alloc` ensfh.
    // as d'r in `#[global_allocator]`-attribút is (de koade dy't it attribútmakro útwreidet genereart dy funksjes), of de standertútfieringen yn libstd (`__rdl_alloc` ensfh.)
    //
    // yn `library/std/src/alloc.rs`) oars.
    // De rustc fork fan LLVM spesjaal-gefallen dizze funksjesnammen om se te optimalisearjen lykas respektivelik `malloc`, `realloc` en `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// De wrâldwide ûnthâld allocator.
///
/// Dit type ymplementeart de [`Allocator`] trait troch oproppen troch te stjoeren nei de allocator dy't registrearre is by it `#[global_allocator]`-attribút as d'r ien is, of de standert `std` crate.
///
///
/// Note: wylst dit type ynstabyl is, kin de funksjonaliteit dy't it leveret tagonklik wurde fia de [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Tawize ûnthâld mei de globale allocator.
///
/// Dizze funksje stjoert oproppen troch nei de [`GlobalAlloc::alloc`]-metoade fan 'e allocator dy't registrearre is by it `#[global_allocator]`-attribút as d'r ien is, of de standert `std` crate.
///
///
/// Nei ferwachting wurdt dizze funksje ôfret ten gunste fan 'e `alloc`-metoade fan it [`Global`]-type as dizze en de [`Allocator`] trait stabyl wurde.
///
/// # Safety
///
/// Sjoch [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Distribuearje ûnthâld mei de globale allocator.
///
/// Dizze funksje stjoert oproppen troch nei de [`GlobalAlloc::dealloc`]-metoade fan 'e allocator dy't registrearre is by it `#[global_allocator]`-attribút as d'r ien is, of de standert `std` crate.
///
///
/// Nei ferwachting wurdt dizze funksje ôfret ten gunste fan 'e `dealloc`-metoade fan it [`Global`]-type as dizze en de [`Allocator`] trait stabyl wurde.
///
/// # Safety
///
/// Sjoch [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Wizigje ûnthâld wer op mei de wrâldwide allocator.
///
/// Dizze funksje stjoert oproppen troch nei de [`GlobalAlloc::realloc`]-metoade fan 'e allocator dy't registrearre is by it `#[global_allocator]`-attribút as d'r ien is, of de standert `std` crate.
///
///
/// Nei ferwachting wurdt dizze funksje ôfret ten gunste fan 'e `realloc`-metoade fan it [`Global`]-type as dizze en de [`Allocator`] trait stabyl wurde.
///
/// # Safety
///
/// Sjoch [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Tawize nul-inisjalisearre ûnthâld mei de globale allocator.
///
/// Dizze funksje stjoert oproppen troch nei de [`GlobalAlloc::alloc_zeroed`]-metoade fan 'e allocator dy't registrearre is by it `#[global_allocator]`-attribút as d'r ien is, of de standert `std` crate.
///
///
/// Nei ferwachting wurdt dizze funksje ôfret ten gunste fan 'e `alloc_zeroed`-metoade fan it [`Global`]-type as dizze en de [`Allocator`] trait stabyl wurde.
///
/// # Safety
///
/// Sjoch [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // VEILIGHEID: `layout` is net nul yn grutte,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // FEILIGHEID: Itselde as `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // VEILIGHEID: `new_size` is net-nul, om't `old_size` grutter is as of gelyk oan `new_size`
            // lykas ferplicht troch feiligensbetingsten.Oare betingsten moatte wurde bewarre troch de beller
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` kontroleart wierskynlik op `new_size >= old_layout.size()` of sokssawat.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // VEILIGHEID: om't `new_layout.size()` grutter as of gelyk moat wêze oan `old_size`,
            // sawol de âlde as de nije ûnthâld is tawiisd foar lêzen en skriuwen foar `old_size`-bytes.
            // Om't de âlde allocaasje noch net behannele is, kin it `new_ptr` net oerlaapje.
            // Sadwaande is de oprop nei `copy_nonoverlapping` feilich.
            // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // VEILIGHEID: `layout` is net nul yn grutte,
            // oare betingsten moatte wurde bewarre troch de beller
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: alle betingsten moatte wurde bewarre troch de beller
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: alle betingsten moatte wurde bewarre troch de beller
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // VEILIGHEID: betingsten moatte wurde bewarre troch de beller
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // VEILIGHEID: `new_size` is net-nul.Oare betingsten moatte wurde bewarre troch de beller
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` kontroleart wierskynlik op `new_size <= old_layout.size()` of sokssawat.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // VEILIGHEID: om't `new_size` lytser wêze moat as of gelyk oan `old_layout.size()`,
            // sawol de âlde as de nije ûnthâld is tawiisd foar lêzen en skriuwen foar `new_size`-bytes.
            // Om't de âlde allocaasje noch net behannele is, kin it `new_ptr` net oerlaapje.
            // Sadwaande is de oprop nei `copy_nonoverlapping` feilich.
            // It feilichheidskontrakt foar `dealloc` moat wurde biwarre troch de beller.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// De allocator foar unike pointers.
// Dizze funksje mei net losrinne.As dat sa is, sil MIR codegen mislearje.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Dizze hantekening moat itselde wêze as `Box`, oars sil in ICE barre.
// As in ekstra parameter oan `Box` wurdt tafoege (lykas `A: Allocator`), moat dizze hjir ek tafoege wurde.
// As `Box` bygelyks wurdt feroare yn `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, moat dizze funksje ek feroare wurde yn `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Fermelding foar tawizingsflater

extern "Rust" {
    // Dit is it magyske symboal om de globale allocaasjefehanneler te neamen.
    // rustc genereart it om `__rg_oom` te skiljen as d'r in `#[alloc_error_handler]` is, of oars de standertútfieringen ûnder (`__rdl_oom`) te neamen.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Ofbrekke by flater of mislearjen fan ûnthâldsallokaasje.
///
/// Bellers foar ûnthâldtoekenings-API's dy't berekkening ôfbrekke wolle as antwurd op in tawijingsflater wurde stimulearre dizze funksje te neamen, ynstee fan direkt `panic!` of soksoarte oan te roppen.
///
///
/// It standertgedrach fan dizze funksje is om in berjocht nei standertflater ôf te drukken en it proses ôf te brekken.
/// It kin wurde ferfongen troch [`set_alloc_error_hook`] en [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Foar allocaasjetest kin `std::alloc::handle_alloc_error` direkt brûkt wurde.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // neamd fia generearre `__rust_alloc_error_handler`

    // as d'r gjin `#[alloc_error_handler]` is
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // as der in `#[alloc_error_handler]` is
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Spesjalisearje klonen yn foarôf tawiisd, uninitialisearre ûnthâld.
/// Brûkt troch `Box::clone` en `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // As jo *earst* hawwe tawiisd, kin de optimizer de klone wearde op syn plak oanmeitsje, it lokaal oerslaan en ferpleatse.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Wy kinne altyd yn plak kopiearje, sûnder oait in lokale wearde te beheljen.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}