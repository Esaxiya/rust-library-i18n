//! In dynamysk grutte werjefte yn in oanswettende folchoarder, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Plakken binne in werjefte yn in blok ûnthâld werjûn as oanwizer en in lingte.
//!
//! ```
//! // in Vec snije
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // in array twinge nei in stik
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Plakken binne ofwikselber as dield.
//! It dielde slice-type is `&[T]`, wylst it feroarbere slice-type `&mut [T]` is, wêr't `T` it elemint-type fertsjintwurdiget.
//! Jo kinne bygelyks it blok ûnthâld ûnthâlde dat in feroarbere stik wiist op:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hjir binne wat dingen dy't dizze module befettet:
//!
//! ## Structs
//!
//! D'r binne ferskate structs dy't nuttich binne foar plakjes, lykas [`Iter`], dy't iteraasje oer in plak fertsjintwurdiget.
//!
//! ## Trait Ymplemintaasjes
//!
//! D'r binne ferskate ymplementaasjes fan mienskiplike traits foar plakjes.Guon foarbylden omfetsje:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], foar plakjes wêrfan it type elemint [`Eq`] of [`Ord`] is.
//! * [`Hash`] - foar plakjes wêrfan it type [`Hash`] is.
//!
//! ## Iteration
//!
//! De plakjes ymplementearje `IntoIterator`.De iterator leveret ferwizingen op nei de slice-eleminten.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! It feroarbere stik leveret feroarbere ferwizings nei de eleminten:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Dizze iterator leveret feroarbere referinsjes op 'e eleminten fan' e slice, dus wylst it elemtype fan 'e slach `i32` is, is it elemtype fan' e iterator `&mut i32`.
//!
//!
//! * [`.iter`] en [`.iter_mut`] binne de eksplisite metoaden om de standert iterators werom te jaan.
//! * Fierdere metoaden dy't iterators werombringe binne [`.split`], [`.splitn`], [`.chunks`], [`.windows`] en mear.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// In protte fan 'e gebrûken yn dizze module wurde allinich brûkt yn' e testkonfiguraasje.
// It is skjinner om de warskôging unused_imports gewoan út te setten dan te reparearjen.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basis metoaden foar slachferlinging
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nedich foar de ymplemintaasje fan `vec!` makro by testen NB, sjoch de `hack` module yn dit bestân foar mear details.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nedich foar de ymplemintaasje fan `Vec::clone` by testen NB, sjoch de `hack`-module yn dit bestân foar mear details.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Mei cfg(test) `impl [T]` is net beskikber, dizze trije funksjes binne eins metoaden dy't yn `impl [T]` binne, mar net yn `core::slice::SliceExt`, wy moatte dizze funksjes leverje foar de `test_permutations`-test
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Wy moatte dit net inline attribuut tafoegje, om't dit meast yn `vec!`-makro wurdt brûkt en perf regression feroarsaket.
    // Sjoch #71204 foar diskusje en perfekte resultaten.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // items waarden markearre inisjalisearre yn 'e loop hjirûnder
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) is nedich foar LLVM om grinzen fan kontrôles te ferwiderjen en hat bettere codegen dan zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // de vec waard hjirboppe tawiisd en inisjalisearre oant teminsten dizze lingte.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // hjirboppe tawiisd mei de kapasiteit fan `s`, en inisjalisearje nei `s.len()` yn ptr::copy_to_non_overlapping hjirûnder.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorteert it stik.
    ///
    /// Dit soarte is stabyl (dat is, net oarderje gelikense eleminten) en *O*(*n*\*log(* n*)) minste gefal.
    ///
    /// As fan tapassing is ynstabile sortearjen foarkar om't it oer it algemien rapper is dan stabile sortearjen en it ekstra geheugen net alloceart.
    /// Sjoch [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is in adaptive, iterative merge-soarte ynspireare troch [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// It is ûntwurpen om heul rap te wêzen yn gefallen wêr't it stik hast sorteare is, of bestiet út twa of mear sorteare sekwinsjes efterinoar gearkeatst.
    ///
    ///
    /// Ek alloceart it tydlike opslach de helte fan 'e grutte fan `self`, mar foar koarte plakken wurdt ynstee in net-allocearjende ynsteksoart brûkt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorteert it stik mei in komparatorfunksje.
    ///
    /// Dit soarte is stabyl (dat is, net oarderje gelikense eleminten) en *O*(*n*\*log(* n*)) minste gefal.
    ///
    /// De komparatorfunksje moat in totale folchoarder definiearje foar de eleminten yn 'e snij.As de oardering net totaal is, is de oarder fan 'e eleminten net oantsjutte.
    /// In oarder is in totale oarder as it is (foar alle `a`, `b` en `c`):
    ///
    /// * totaal en antisymmetrysk: presys ien fan `a < b`, `a == b` of `a > b` is wier, en
    /// * transitive, `a < b` en `b < c` ymplisyt `a < c`.Itselde moat hâlde foar sawol `==` as `>`.
    ///
    /// Wylst bygelyks [`f64`] [`Ord`] net ymplementeart om't `NaN != NaN`, kinne wy `partial_cmp` brûke as ús sortfunksje as wy witte dat it stik gjin `NaN` befettet.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// As fan tapassing is ynstabile sortearjen foarkar om't it oer it algemien rapper is dan stabile sortearjen en it ekstra geheugen net alloceart.
    /// Sjoch [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is in adaptive, iterative merge-soarte ynspireare troch [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// It is ûntwurpen om heul rap te wêzen yn gefallen wêr't it stik hast sorteare is, of bestiet út twa of mear sorteare sekwinsjes efterinoar gearkeatst.
    ///
    /// Ek alloceart it tydlike opslach de helte fan 'e grutte fan `self`, mar foar koarte plakken wurdt ynstee in net-allocearjende ynsteksoart brûkt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omkearde sortearring
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorteert it stik mei in funksje foar kaai-ekstraksje.
    ///
    /// Dit soarte is stabyl (dat is, net gelikense eleminten opnij oarderje) en *O*(*m*\* * n *\* log(*n*)) minste gefal, wêr't de kaaifunksje *O*(*m*) is.
    ///
    /// Foar djoere kaaifunksjes (bgl
    /// funksjes dy't gjin ienfâldige tagong binne ta eigendom of basale operaasjes), sil [`sort_by_cached_key`](slice::sort_by_cached_key) wierskynlik signifikant rapper wêze, om't it elemint-toetsen net opnij rekkent.
    ///
    ///
    /// As fan tapassing is ynstabile sortearjen foarkar om't it oer it algemien rapper is dan stabile sortearjen en it ekstra geheugen net alloceart.
    /// Sjoch [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is in adaptive, iterative merge-soarte ynspireare troch [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// It is ûntwurpen om heul rap te wêzen yn gefallen wêr't it stik hast sorteare is, of bestiet út twa of mear sorteare sekwinsjes efterinoar gearkeatst.
    ///
    /// Ek alloceart it tydlike opslach de helte fan 'e grutte fan `self`, mar foar koarte plakken wurdt ynstee in net-allocearjende ynsteksoart brûkt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorteert it stik mei in funksje foar kaai-ekstraksje.
    ///
    /// By it sortearjen wurdt de kaaifunksje mar ien kear per elemint neamd.
    ///
    /// Dit soarte is stabyl (dat is, net gelikense eleminten opnij oarderje) en *O*(*m*\* * n *+* n *\* log(*n*)) minste gefal, wêr't de kaaifunksje *O*(*m*) is ,
    ///
    /// Foar ienfâldige kaaifunksjes (bgl. Funksjes dy't tagong hawwe ta eigendom as basale operaasjes) is [`sort_by_key`](slice::sort_by_key) wierskynlik rapper.
    ///
    /// # Aktuele ymplemintaasje
    ///
    /// It hjoeddeistige algoritme is basearre op [pattern-defeating quicksort][pdqsort] fan Orson Peters, dy't it rappe gemiddelde gefal fan randomisearre kwiksort kombineart mei it rapste minste gefal fan heapsort, wylst it lineêre tiid berikke op plakken mei bepaalde patroanen.
    /// It brûkt wat randomisaasje om degenerearre gefallen te foarkommen, mar mei in fêste seed om altyd deterministysk gedrach te leverjen.
    ///
    /// Yn it slimste gefal alloceart it algoritme tydlike opslach yn in `Vec<(K, usize)>` de lingte fan it stik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helppermakro foar yndeksearjen fan ús vector troch it lytste mooglike type, om de tawizing te ferminderjen.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // De eleminten fan `indices` binne unyk, om't se yndekseare binne, dus elke soart sil stabyl wêze mei respekt foar it orizjinele plak.
                // Wy brûke `sort_unstable` hjir, om't it minder ûnthâldtokaasje fereasket.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopieart `self` yn in nije `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hjir kinne `s` en `x` selsstannich oanpast wurde.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopieart `self` yn in nije `Vec` mei in allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hjir kinne `s` en `x` selsstannich oanpast wurde.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, sjoch de `hack`-module yn dit bestân foar mear details.
        hack::to_vec(self, alloc)
    }

    /// Konverteart `self` yn in vector sûnder klonen of tawizing.
    ///
    /// De resultearjende vector kin werom wurde konvertearre yn in doaze fia `Vec<T>'s `into_boxed_slice`-metoade.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kin net mear brûkt wurde omdat it is omboud ta `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, sjoch de `hack`-module yn dit bestân foar mear details.
        hack::into_vec(self)
    }

    /// Makket in vector oan troch in stik `n` kear te herheljen.
    ///
    /// # Panics
    ///
    /// Dizze funksje sil panic as de kapasiteit oerspielje soe.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// In panic by oerrin:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // As `n` grutter is dan nul, kin it wurde splitst as `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` is it getal dat wurdt fertsjintwurdige troch it loftsste '1'-bit fan `n`, en `rem` is it oerbleaune diel fan `n`.
        //
        //

        // `Vec` brûke om tagong te krijen ta `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` werhelling wurdt dien troch ferdûbeling fan `buf` `expn`-tiden.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // As `m > 0`, binne d'r oerbleaune bits oant de lofterste '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` hat kapasiteit fan `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) werhelling wurdt dien troch earste `rem`-werhellingen te kopiearjen fan `buf` sels.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dit is sûnt `2^expn > rem` net-oerlappend.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` is lyk oan `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Platet in stikje `T` út yn ien wearde `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flakket in stikje `T` yn ien wearde `Self::Output`, en pleatst in opjûne skiedingsteken tusken elk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flakket in stikje `T` yn ien wearde `Self::Output`, en pleatst in opjûne skiedingsteken tusken elk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Jout in vector mei in kopy fan dit stik wêr't elke byte wurdt yn kaart brocht oan syn ASCII haadletters ekwivalint.
    ///
    ///
    /// ASCII-letters 'a' nei 'z' wurde yn kaart brocht oan 'A' nei 'Z', mar net-ASCII-letters binne net feroare.
    ///
    /// Om de wearde te pleatsen yn grutte, brûk [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Jout in vector mei in kopy fan dit stik wêr't elke byte wurdt yn kaart brocht oan syn ASCII-lytse ekwivalint.
    ///
    ///
    /// ASCII-letters 'A' nei 'Z' wurde yn kaart brocht oan 'a' nei 'z', mar net-ASCII-letters binne net feroare.
    ///
    /// Brûk [`make_ascii_lowercase`] om de wearde op in lyts plak te meitsjen.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Utwreiding traits foar plakjes oer spesifike soarten gegevens
////////////////////////////////////////////////////////////////////////////////

/// Helper trait foar [`[T]: : concat`](slice::concat).
///
/// Note: de parameter `Item`-type wurdt net brûkt yn dizze trait, mar it lit impls mear generyk wêze.
/// Sûnder it krije wy dizze flater:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dit komt om't d'r `V`-typen mei meardere `Borrow<[_]>`-ymplen kinne bestean, sadat meardere `T`-typen jilde soene:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// It resultearjende type nei gearfoeging
    type Output;

    /// Ymplemintaasje fan [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait foar [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// It resultearjende type nei gearfoeging
    type Output;

    /// Ymplemintaasje fan [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standert trait-ymplementaasjes foar plakjes
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // drop alles yn doel dat net oerskreaun wurde sil
        target.truncate(self.len());

        // target.len <= self.len fanwegen it boppesteande ôfkoarte, dus de plakjes hjir binne altyd binnen.
        //
        let (init, tail) = self.split_at(target.len());

        // brûk de befette wearden allocations/resources opnij.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Foeget `v[0]` yn in foar-sorteare folchoarder `v[1..]`, sadat hiele `v[..]` wurdt sorteare.
///
/// Dit is de yntegraal subrutine fan ynfoegingssoarte.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // D'r binne trije manieren om ynfoeging hjir te realisearjen:
            //
            // 1. Ruilje neistlizzende eleminten oant de earste by syn definitive bestimming komt.
            //    Op dizze manier kopiearje wy gegevens lykwols om mear dan nedich is.
            //    As eleminten grutte struktueren binne (djoer te kopiearjen), sil dizze metoade stadich wêze.
            //
            // 2. Iterearje oant it juste plak foar it earste elemint is fûn.
            // Ferpleats dan de eleminten dy't it slagje om der romte foar te meitsjen en pleatst it einlings yn it oerbleaune gat.
            // Dit is in goede metoade.
            //
            // 3. Kopiearje it earste elemint yn in tydlike fariabele.Iterearje oant it juste plak dêrfoar is fûn.
            // As wy trochgean, kopiearje alle trochgeande eleminten yn it slot derfoar.
            // Uteinlik kopiearje gegevens fan 'e tydlike fariabele yn it oerbleaune gat.
            // Dizze metoade is heul goed.
            // Benchmarks toande wat bettere prestaasjes dan mei de 2e metoade.
            //
            // Alle metoaden waarden benchmarked, en de 3e toande de bêste resultaten.Dat wy hawwe dy keazen.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Tuskenstân fan it ynfoegingsproses wurdt altyd folge troch `hole`, dy't twa doelen tsjinnet:
            // 1. Beskermet yntegriteit fan `v` fan panics yn `is_less`.
            // 2. Folt it oerbleaune gat yn `v` op it lêst.
            //
            // Panic feiligens:
            //
            // As `is_less` panics op elk punt yn 't proses sil `hole` falle en it gat yn `v` folje mei `tmp`, en soarget derfoar dat `v` noch elk objekt hâldt dat it ynearsten presys ien kear hold.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` wurdt sakke en kopieart dus `tmp` yn it oerbleaune gat yn `v`.
        }
    }

    // As se falle, kopyen fan `src` nei `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Fuseart net-ôfnimmend rint `v[..mid]` en `v[mid..]` mei `buf` as tydlike opslach, en bewarret it resultaat yn `v[..]`.
///
/// # Safety
///
/// De twa plakken moatte net-leech wêze en `mid` moat yn grinzen wêze.
/// Buffer `buf` moat lang genôch wêze om in kopy fan 'e koartere plak te hâlden.
/// Ek moat `T` gjin type fan nulgrutte wêze.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // It fúzjeproses kopieart earst de koartere run yn `buf`.
    // Dan folget it de nij kopieare run en de langere run foarút (of efterút), ferlykje har folgjende net konsumeare eleminten en kopiearje de mindere (of gruttere) ien nei `v`.
    //
    // Sadree't de koartere run folslein konsumeare is, is it proses dien.As de langere run earst konsumeare wurdt, dan moatte wy kopiearje wat oerbliuwt fan 'e koartere run yn it oerbleaune gat yn `v`.
    //
    // Tuskenstân fan it proses wurdt altyd folge troch `hole`, dy't twa doelen tsjinnet:
    // 1. Beskermet yntegriteit fan `v` fan panics yn `is_less`.
    // 2. Folt it oerbleaune gat yn `v` as de langere run earst konsumeare wurdt.
    //
    // Panic feiligens:
    //
    // As `is_less` panics op ien punt yn 't proses sil `hole` falle en it gat yn `v` folje mei it ûnferbrûkte berik yn `buf`, en soarget derfoar dat `v` noch elk objekt hâldt dat it ynearsten presys ien kear hold.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // De linker run is koarter.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Yn 't earstoan wize dizze oanwizings op it begjin fan har arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Konsumearje de mindere kant.
            // As gelyk, foarkar dan de linker run om stabiliteit te behâlden.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // De juste run is koarter.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Yn 't earstoan wize dizze oanwizings foarby de einen fan har arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Konsumearje de gruttere kant.
            // As gelyk, foarkar dan de juste run om stabiliteit te behâlden.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Uteinlik wurdt `hole` sakke.
    // As de koartere run net folslein konsumearre waard, sil wat der noch oerbliuwt no wurde kopieare yn it gat yn `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // As se falle, kopiearje it berik `start..end` yn `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` is gjin type fan nulgrutte, dus it is goed om te dielen troch syn grutte.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Dizze fúzje sorteart guon (mar net alle) ideeën fan TimSort, dy't yn detail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) wurdt beskreaun.
///
///
/// It algoritme identifiseart strikt delgeande en net-delgeande folchoarder, dy't natuerlike rinnen wurde neamd.D'r is in stapel oansteande rinnen dy't noch moatte wurde fuseare.
/// Elke nij fûn run wurdt op 'e stapel skood, en dan wurde guon pearen fan neistlizzende runs gearfoege oant dizze twa invarianten tefreden binne:
///
/// 1. foar elke `i` yn `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. foar elke `i` yn `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// De invarianten soargje derfoar dat de totale draaitiid *O*(*n*\*log(* n*)) minste gefal is.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Plakken fan oant dizze lingte wurde sorteare mei ynsettingssoarte.
    const MAX_INSERTION: usize = 20;
    // Hiel koarte rinnen wurde útwreide mei ynsetsoarte om teminsten dizze protte eleminten te fersprieden.
    const MIN_RUN: usize = 10;

    // Sortearje hat gjin betsjuttend gedrach op nulgrutte typen.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Koarte arrays wurde op 'e plak sorteare fia ynfoegingssoarte om allocaasjes te foarkommen.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tawiik in buffer om te brûken as skrapgeheugen.Wy hâlde de lingte 0, sadat wy dêryn ûndjippe kopyen fan 'e ynhâld fan `v` kinne behâlde sûnder dat de dtors op kopyen rinne as `is_less` panics.
    //
    // By it gearfoegjen fan twa sorteare runen hat dizze buffer in kopy fan 'e koartere run, dy't altyd lingte hat op syn meast `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Om natuerlike rinnen yn `v` te identifisearjen, trochkringe wy it efterút.
    // Dat kin in frjemd beslút lykje, mar beskôgje it feit dat fúzjes faker yn 'e tsjinoerstelde rjochting gean (forwards).
    // Neffens peilmerken is foarút fusearje wat rapper dan efterút fusearje.
    // Ta beslút ferbetteret it identifisearjen fan rinnen troch efterút te gean de prestaasjes.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Fyn de folgjende natuerlike run, en keare it werom as it strikt delkomt.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Foegje wat mear eleminten yn 'e run as it te koart is.
        // Ynfoegingssorte is rapper dan fusearje op koarte sekwinsjes, sadat dit de prestaasje signifikant ferbettert.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Druk dizze run op 'e stapel.
        runs.push(Run { start, len: end - start });
        end = start;

        // Foegje inkele pearen neistlizzende rinnen gear om de invarianten te befredigjen.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Uteinlik moat krekt ien run yn 'e stapel bliuwe.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Undersykje de stapel rinnen en identifiseart it folgjende pear rinnen om te fusearjen.
    // Mear spesifyk, as `Some(r)` wurdt weromjûn, betsjuttet dat `runs[r]` en `runs[r + 1]` dan moatte wurde fuseare.
    // As it algoritme ynstee trochgean mei it bouwen fan in nije run, wurdt `None` weromjûn.
    //
    // TimSort is berucht foar syn buggy-ymplementaasjes, lykas hjir beskreaun:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // De kearn fan it ferhaal is: wy moatte de invarianten ôftwinge op 'e boppeste fjouwer rinnen op' e stapel.
    // Enforcing se op just top trije is net genôch om te soargjen dat de invariants noch foar *alle* runs yn 'e stack hâlde.
    //
    // Dizze funksje kontroleart invarianten korrekt foar de top fjouwer runs.
    // Derneist, as de boppeste run begjint by yndeks 0, sil it altyd in gearfoegingsaksje easkje oant de stapel folslein is ynstoart, om it soarte te foltôgjen.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}