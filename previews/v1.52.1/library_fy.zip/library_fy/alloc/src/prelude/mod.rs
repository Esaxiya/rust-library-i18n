//! De allocaasje Prelude
//!
//! It doel fan dizze module is om ymport fan faak brûkte items fan 'e `alloc` crate te ferleegjen troch in glob-ymport ta te foegjen oan' e boppekant fan modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;