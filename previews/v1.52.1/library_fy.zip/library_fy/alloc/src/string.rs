//! In UTF-8-kodearre, groeie string.
//!
//! Dizze module befettet it [`String`]-type, de [`ToString`] trait foar konvertearjen nei snaren, en ferskate flatertypen dy't resultearje kinne út it wurkjen mei [`String`] s.
//!
//!
//! # Examples
//!
//! D'r binne meardere manieren om in nije [`String`] te meitsjen fan in letterlike tekenrige:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Jo kinne in nije [`String`] meitsje fan in besteande troch te ferbinen mei
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! As jo in vector mei jildige UTF-8-bytes hawwe, kinne jo der in [`String`] fan meitsje.Jo kinne ek it omkearde dwaan.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Wy witte dat dizze bytes jildich binne, dat wy sille `unwrap()` brûke.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// In UTF-8-kodearre, groeie string.
///
/// It `String`-type is it meast foarkommende tekenrige dat eigendom hat oer de ynhâld fan 'e tekenrige.It hat in nauwe relaasje mei har liende tsjinhinger, de primitive [`str`].
///
/// # Examples
///
/// Jo kinne in `String` meitsje fan [a literal string][`str`] mei [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Jo kinne in [`char`] tafoegje oan in `String` mei de [`push`]-metoade, en in [`&str`] tafoegje mei de [`push_str`]-metoade:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// As jo in vector fan UTF-8-bytes hawwe, kinne jo der in `String` oanmeitsje mei de [`from_utf8`]-metoade:
///
/// ```
/// // guon bytes, yn in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wy witte dat dizze bytes jildich binne, dat wy sille `unwrap()` brûke.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s binne altyd jildich UTF-8.Dit hat in pear ymplikaasjes, wêrfan de earste is dat as jo in net-UTF-8-string nedich binne, beskôgje [`OsString`].It is gelyk, mar sûnder de UTF-8-beheining.De twadde ymplikaasje is dat jo net kinne yndeksearje yn in `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Yndeksearje is bedoeld om in konstante tiid operaasje te wêzen, mar UTF-8-kodearring lit ús dit net ta.Fierder is it net dúdlik hokker soarte ding de yndeks werom moat: in byte, in codepunt, as in grafeme-kluster.
/// De [`bytes`]-en [`chars`]-metoaden jouwe iterators respektivelik oer de earste twa werom.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [`Deref`] `<Target=str>`, en ervje dus alle [[str`]] metoaden.Derneist betsjuttet dit dat jo in `String` kinne trochjaan oan in funksje dy't in [`&str`] nimt mei in ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Dit sil in [`&str`] meitsje fan 'e `String` en trochjaan. Dizze konverzje is heul goedkeap, en sa sille funksjes algemien [`&str`] s as arguminten akseptearje, útsein as se om ien of oare reden in `String` nedich binne.
///
/// Yn bepaalde gefallen hat Rust net genôch ynformaasje om dizze konverzje te meitsjen, bekend as [`Deref`]-twang.Yn it folgjende foarbyld ymplementeart in tekenrige [`&'a str`][`&str`] de trait `TraitExample`, en de funksje `example_func` nimt alles dat de trait ymplementeart.
/// Yn dit gefal soe Rust twa ymplisite konversaasjes moatte meitsje, dy't Rust net de middelen hat om te dwaan.
/// Om dy reden sil it folgjende foarbyld net kompilearje.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// D'r binne twa opsjes dy't ynstee wurkje soene.De earste soe wêze om de line `example_func(&example_string);` te feroarjen nei `example_func(example_string.as_str());`, mei de metoade [`as_str()`] om de tekenrige mei de tekenrige eksplisyt te ekstraheren.
/// De twadde manier feroaret `example_func(&example_string);` nei `example_func(&*example_string);`.
/// Yn dit gefal ferwize wy in `String` nei in [`str`][`&str`], dan ferwize wy nei de [`str`][`&str`] werom nei [`&str`].
/// De twadde manier is idiomatysker, lykwols wurkje beide om de konverzje eksplisyt te dwaan ynstee fan te fertrouwen op 'e ymplisite konverzje.
///
/// # Representation
///
/// In `String` bestiet út trije komponinten: in oanwizer nei guon bytes, in lingte en in kapasiteit.De oanwizer wiist op in ynterne buffer `String` brûkt om har gegevens op te slaan.De lingte is it oantal bytes dat op it stuit opslein is yn 'e buffer, en de kapasiteit is de grutte fan' e buffer yn bytes.
///
/// As sadanich sil de lingte altyd minder wêze as of gelyk oan de kapasiteit.
///
/// Dizze buffer wurdt altyd op 'e heap opslein.
///
/// Jo kinne dizze besjen mei de metoaden [`as_ptr`], [`len`] en [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Update dit as vec_into_raw_parts wurdt stabilisearre.
/// // Foarkom dat gegevens fan 'e String automatysk falle
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ferhaal hat njoggentjin bytes
/// assert_eq!(19, len);
///
/// // Wy kinne in String opnij bouwe út ptr, len en kapasiteit.
/// // Dit is allegear ûnfeilich, om't wy ferantwurdlik binne om te soargjen dat de ûnderdielen jildich binne:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// As in `String` genôch kapasiteit hat, sil it tafoegjen fan eleminten der net opnij tawiisd wurde.Besjoch dit programma bygelyks:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Dit sil it folgjende útfiere:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Earst hawwe wy hielendal gjin ûnthâld tawiisd, mar as wy tafoegje oan 'e tekenrige, fergruttet it syn kapasiteit passend.As wy yn plak fan 'e [`with_capacity`]-metoade earst de juste kapasiteit tawize:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Wy einigje mei in oare útfier:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hjir is it net nedich om mear ûnthâld yn 'e loop te allocearjen.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// In mooglike flaterwearde by it konvertearjen fan in `String` fan in UTF-8-byte vector.
///
/// Dit type is it filtype foar de [`from_utf8`]-metoade op [`String`].
/// It is op sa'n manier ûntwurpen om weryndielingen foarsichtich te foarkommen: de [`into_bytes`]-metoade sil de byte vector weromjaan dy't waard brûkt yn 'e konversaasjepoging.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// It [`Utf8Error`]-type levere troch [`std::str`] stiet foar in flater dy't foarkomme kin by it konvertearjen fan in stik fan [`u8`] nei in [`&str`].
/// Yn dizze sin is it in analooch oan `FromUtf8Error`, en jo kinne ien krije fan in `FromUtf8Error` fia de [`utf8_error`]-metoade.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// // wat ûnjildige bytes, yn in vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// In mooglike flaterwearde by it konvertearjen fan in `String` fan in UTF-16-byte slice.
///
/// Dit type is it filtype foar de [`from_utf16`]-metoade op [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Makket in nije lege `String` oan.
    ///
    /// Jûn dat de `String` leech is, sil dit gjin earste buffer allocearje.Hoewol dat betsjuttet dat dizze earste operaasje heul goedkeap is, kin it letter oermjittige tawizing feroarsaakje as jo gegevens tafoegje.
    ///
    /// As jo in idee hawwe fan hoefolle gegevens de `String` sil bewarje, beskôgje de [`with_capacity`]-metoade om oermjittige re-allocaasje te foarkommen.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Makket in nije lege `String` mei in bepaalde kapasiteit.
    ///
    /// `String`s hawwe in ynterne buffer om har gegevens te bewarjen.
    /// De kapasiteit is de lingte fan dy buffer, en kin wurde frege mei de [`capacity`]-metoade.
    /// Dizze metoade makket in lege `String`, mar ien mei in earste buffer dy't `capacity` bytes kin hâlde.
    /// Dit is handich as jo in bosk gegevens tafoegje kinne oan 'e `String`, wêrtroch it oantal weryndielingen ferminderje dat it moat.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// As de opjûne kapasiteit `0` is, sil gjin tawizing foarkomme, en dizze metoade is identyk oan de [`new`]-metoade.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // De String befettet gjin tekens, hoewol it kapasiteit hat foar mear
    /// assert_eq!(s.len(), 0);
    ///
    /// // Dizze wurde allegear dien sûnder opnij te allocearjen ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... mar dit kin de tekenrige opnij tawize
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): mei cfg(test) is de ynherinte `[T]::to_vec`-metoade, dy't nedich is foar dizze metoadedefinysje, net beskikber.
    // Om't wy dizze metoade net nedich binne foar testdoelen, sil ik it gewoan stompje NB sjoch de slice::hack-module yn slice.rs foar mear ynformaasje
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konverteart in vector fan bytes nei in `String`.
    ///
    /// In tekenrige ([`String`]) is makke fan bytes ([`u8`]), en in vector fan bytes ([`Vec<u8>`]) is makke fan bytes, sadat dizze funksje konverteart tusken de twa.
    /// Net alle byteplakken binne jildich `String`s, lykwols: `String` fereasket dat it jildich UTF-8 is.
    /// `from_utf8()` kontrolearret om te soargjen dat de bytes jildich binne UTF-8, en docht dan de konverzje.
    ///
    /// As jo der wis fan binne dat de byteplaat UTF-8 jildich is, en jo de overhead fan 'e jildichheidskontrôle net wolle oanmeitsje, is d'r in ûnfeilige ferzje fan dizze funksje, [`from_utf8_unchecked`], dy't itselde gedrach hat, mar de kontrôle oerspringt.
    ///
    ///
    /// Dizze metoade sil der foar soargje dat de vector net kopieare wurdt, omwille fan effisjinsje.
    ///
    /// As jo in [`&str`] nedich binne ynstee fan in `String`, beskôgje dan [`str::from_utf8`].
    ///
    /// It omkearde fan dizze metoade is [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Jout [`Err`] werom as it stik net UTF-8 is mei in beskriuwing wêrom't de levere bytes net UTF-8 binne.De vector dy't jo hawwe ferpleatst is ek opnommen.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // guon bytes, yn in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Wy witte dat dizze bytes jildich binne, dat wy sille `unwrap()` brûke.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ferkearde bytes:
    ///
    /// ```
    /// // wat ûnjildige bytes, yn in vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Sjoch de dokuminten foar [`FromUtf8Error`] foar mear details oer wat jo mei dizze flater kinne dwaan.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konverteart in stikje bytes nei in tekenrige, ynklusyf unjildige tekens.
    ///
    /// Strings binne makke fan bytes ([`u8`]), en in stikje bytes ([`&[u8]`][byteslice]) wurdt makke fan bytes, dus dizze funksje konverteart tusken de twa.Net alle byteplakken binne jildige snaren, lykwols: snaren moatte jildich UTF-8 wêze.
    /// Tidens dizze konverzje sil `from_utf8_lossy()` alle unjildige UTF-8-sekwinsjes ferfange troch [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], dy't der sa útsjocht:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// As jo der wis fan binne dat de byteplaat UTF-8 jildich is, en jo de overhead fan 'e konverzje net wolle oanmeitsje, is d'r in ûnfeilige ferzje fan dizze funksje, [`from_utf8_unchecked`], dy't itselde gedrach hat, mar de kontrôles oerspringt.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Dizze funksje jout in [`Cow<'a, str>`] werom.As ús byteplaat UTF-8 ûnjildich is, moatte wy de ferfangende tekens ynfoegje, dy't de grutte fan 'e tekenrige feroarje, en dêrom in `String` nedich binne.
    /// Mar as it al UTF-8 jildich is, hawwe wy gjin nije allocaasje nedich.
    /// Mei dit retourtype kinne wy beide gefallen behannelje.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // guon bytes, yn in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ferkearde bytes:
    ///
    /// ```
    /// // wat unjildige bytes
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decodearje in UTF-16-kodearre vector `v` yn in `String`, werom [`Err`] as `v` unjildige gegevens befettet.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Dit wurdt net dien fia sammelje: : <Result<_, _>> () om prestaasjesredenen.
        // FIXME: de funksje kin opnij wurde ferienfâldige as #48994 is sluten.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodearje in UTF-16-kodearre plak `v` yn in `String`, en ferfangt unjildige gegevens troch [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Oars as [`from_utf8_lossy`] dy't in [`Cow<'a, str>`] retourneert, retourneert `from_utf16_lossy` in `String` sûnt de UTF-16-nei UTF-8-konverzje fereasket in tawizing fan ûnthâld.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Ferset in `String` yn har rauwe ûnderdielen.
    ///
    /// Jout de rauwe oanwizer werom nei de ûnderlizzende gegevens, de lingte fan 'e tekenrige (yn bytes), en de tawiisde kapasiteit fan' e gegevens (yn bytes).
    /// Dit binne deselde arguminten yn deselde folchoarder as de arguminten foar [`from_raw_parts`].
    ///
    /// Nei't dizze funksje neamd is, is de beller ferantwurdlik foar it ûnthâld dat earder beheard waard troch de `String`.
    /// De iennige manier om dit te dwaan is om de rauwe oanwizer, lingte en kapasiteit werom te konvertearjen yn in `String` mei de [`from_raw_parts`]-funksje, wêrtroch de destruktor de oproming kin útfiere.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Makket in nije `String` oan fanút lingte, kapasiteit en oanwizer.
    ///
    /// # Safety
    ///
    /// Dit is heul ûnfeilich, fanwegen it oantal invarianten dy't net kontroleare binne:
    ///
    /// * It ûnthâld by `buf` moat earder tawiisd wêze troch deselde allocator dy't de standertbibleteek brûkt, mei in fereaske ôfstimming fan presys 1.
    /// * `length` moat minder dan of gelyk wêze oan `capacity`.
    /// * `capacity` moat de juste wearde wêze.
    /// * De earste `length`-bytes by `buf` moatte jildich wêze UTF-8.
    ///
    /// Oertrêding fan dizze kin problemen feroarsaakje lykas it ferdjerjen fan de ynterne datastrukturen fan de allocator.
    ///
    /// It eigendom fan `buf` wurdt effektyf oerdroegen oan 'e `String`, dy't dan de ynhâld fan ûnthâld wizigje kinne, wizigje troch de oanwizer nei willekeur.
    /// Soargje derfoar dat neat oars de oanwizer brûkt nei't dizze funksje neamd is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Update dit as vec_into_raw_parts wurdt stabilisearre.
    ///     // Foarkom dat gegevens fan 'e String automatysk falle
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konverteart in vector fan bytes nei in `String` sûnder te kontrolearjen dat de tekenrige jildige UTF-8 befettet.
    ///
    /// Sjoch de feilige ferzje, [`from_utf8`], foar mear details.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich, omdat it net kontroleart dat de bytes dy't dêrop binne oerdroegen binne jildich binne UTF-8.
    /// As dizze beheining wurdt oertrêdde, kin it problemen mei ûnthâldfeiligens feroarsaakje mei future-brûkers fan 'e `String`, om't de rest fan' e standertbibleteek der fan út giet dat 'String`s jildich binne UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // guon bytes, yn in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konverteart in `String` yn in byte vector.
    ///
    /// Dit ferbrûkt de `String`, dus hoege wy de ynhâld net te kopiearjen.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ekstraheret in tekenrige mei de heule `String`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konverteart in `String` yn in feroarbere tekenrige.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Foeget in opjûne tekenrige ta oan 'e ein fan dizze `String`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Jout de kapasiteit fan dizze 'String' yn bytes.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Soarget derfoar dat de kapasiteit fan dizze 'String' op syn minst `additional` bytes grutter is dan syn lingte.
    ///
    /// De kapasiteit kin wurde ferhege mei mear dan `additional` bytes as it kiest, om faak weryndielingen te foarkommen.
    ///
    ///
    /// As jo dit "at least"-gedrach net wolle, sjoch dan de [`reserve_exact`]-metoade.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dit kin de kapasiteit miskien net ferheegje:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hat no in lingte fan 2 en in kapasiteit fan 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Om't wy al in ekstra 8-kapasiteit hawwe, sille wy dit neame ...
    /// s.reserve(8);
    ///
    /// // ... ferheget eins net.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Soarget derfoar dat de kapasiteit fan dizze 'String' `additional` bytes grutter is dan de lingte.
    ///
    /// Tink oan it brûken fan de [`reserve`]-metoade, útsein as jo perfoarst better witte dan de allocator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan `usize`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dit kin de kapasiteit miskien net ferheegje:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hat no in lingte fan 2 en in kapasiteit fan 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Om't wy al in ekstra 8-kapasiteit hawwe, sille wy dit neame ...
    /// s.reserve_exact(8);
    ///
    /// // ... ferheget eins net.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Besiket kapasiteit te reservearjen foar teminsten `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `String`.
    /// De kolleksje kin mear romte reservearje om faak weryndielingen te foarkommen.
    /// Nei it oproppen fan `reserve` sil de kapasiteit grutter wêze as of gelyk oan `self.len() + additional`.
    /// Docht neat as kapasiteit al genôch is.
    ///
    /// # Errors
    ///
    /// As de kapasiteit oerrint, as de allocator in mislearring rapporteart, dan wurdt in flater weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservearje it ûnthâld foarôf en gean út as wy net kinne
    ///     output.try_reserve(data.len())?;
    ///
    ///     // No wite wy dat dit net OOM kin midden yn ús komplekse wurk
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Besiket de minimale kapasiteit te reservearjen foar presys `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `String`.
    ///
    /// Nei it oproppen fan `reserve_exact` sil de kapasiteit grutter wêze as of gelyk oan `self.len() + additional`.
    /// Docht neat as de kapasiteit al genôch is.
    ///
    /// Tink derom dat de allocator de kolleksje mear romte kin jaan dan hy freget.
    /// Dêrom kin net wurde fertrouwe op kapasiteit om krekt minimal te wêzen.
    /// Foarkar `reserve` as ynstekken fan future wurde ferwachte.
    ///
    /// # Errors
    ///
    /// As de kapasiteit oerrint, as de allocator in mislearring rapporteart, dan wurdt in flater weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservearje it ûnthâld foarôf en gean út as wy net kinne
    ///     output.try_reserve(data.len())?;
    ///
    ///     // No wite wy dat dit net OOM kin midden yn ús komplekse wurk
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Krimp de kapasiteit fan dizze `String` om syn lingte oan te passen.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Krimpt de kapasiteit fan dizze `String` mei in legere grins.
    ///
    /// De kapasiteit sil op syn minst like grut bliuwe as sawol de lingte as de levere wearde.
    ///
    ///
    /// As de hjoeddeistige kapasiteit minder is dan de legere limyt, is dit in no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Foeget de opjûne [`char`] oan 'e ein fan dizze `String` ta.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Jout in byte-diel fan 'e ynhâld fan dizze' String '.
    ///
    /// It omkearde fan dizze metoade is [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Koartet dizze `String` ta de oantsjutte lingte.
    ///
    /// As `new_len` grutter is dan de hjoeddeistige lingte fan 'e tekenrige, hat dit gjin effekt.
    ///
    ///
    /// Tink derom dat dizze metoade gjin effekt hat op 'e tawiisde kapasiteit fan' e tekenrige
    ///
    /// # Panics
    ///
    /// Panics as `new_len` net op in [`char`]-grins leit.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Ferwideret it lêste teken út 'e tekenrige buffer en retourneert it.
    ///
    /// Jout [`None`] werom as dizze `String` leech is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Ferwideret in [`char`] fan dizze `String` op in byteposysje en retourneert dizze.
    ///
    /// Dit is in *O*(*n*) operaasje, om't it elemint yn 'e buffer kopiearje moat.
    ///
    /// # Panics
    ///
    /// Panics as `idx` grutter is as of gelyk oan de lingte fan 'String', of as it net op in [`char`]-grins leit.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Fuortsmite alle wedstriden fan patroan `pat` yn 'e `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Wedstriden wurde iteratyf ûntdutsen en fuortsmiten, dus yn gefallen wêr't patroanen oerlaapje, wurdt allinich it earste patroan fuortsmiten:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // VEILIGHEID: begjin en ein sille wêze op utf8 byte grinzen per
        // de Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Hâldt allinich de karakters opjûn troch it predikaat.
    ///
    /// Mei oare wurden, ferwiderje alle tekens `c` sadat `f(c)` `false` weromkomt.
    /// Dizze metoade wurket te plak, besiket elk karakter presys ien kear yn 'e orizjinele folchoarder, en behâldt de folchoarder fan' e bewarre karakters.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// De krekte folchoarder kin nuttich wêze foar folgjen fan eksterne steat, lykas in yndeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Rjochtsje idx nei de folgjende kar
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Stekt in karakter yn dizze `String` yn op in byteposysje.
    ///
    /// Dit is in *O*(*n*) operaasje, om't it elemint yn 'e buffer kopiearje moat.
    ///
    /// # Panics
    ///
    /// Panics as `idx` grutter is dan de lingte fan 'String', as it net op in [`char`]-grins leit.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Foeget in tekenrige yn dizze `String` op in byteposysje.
    ///
    /// Dit is in *O*(*n*) operaasje, om't it elemint yn 'e buffer kopiearje moat.
    ///
    /// # Panics
    ///
    /// Panics as `idx` grutter is dan de lingte fan 'String', as it net op in [`char`]-grins leit.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Jout in feroarbere ferwizing nei de ynhâld fan dizze `String`.
    ///
    /// # Safety
    ///
    /// Dizze funksje is ûnfeilich, omdat it net kontroleart dat de bytes dy't dêrop binne oerdroegen binne jildich binne UTF-8.
    /// As dizze beheining wurdt oertrêdde, kin it problemen mei ûnthâldfeiligens feroarsaakje mei future-brûkers fan 'e `String`, om't de rest fan' e standertbibleteek der fan út giet dat 'String`s jildich binne UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Jout de lingte fan dizze `String` werom, yn bytes, net [`char`] s as grafemen.
    /// Mei oare wurden, it kin net wêze wat in minske de lingte fan 'e string beskôget.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Jout `true` werom as dizze `String` in lingte fan nul hat, en `false` oars.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Spalt de tekenrige yn twa by de opjûne byte-yndeks.
    ///
    /// Jout in nij tawiisde `String`.
    /// `self` befettet bytes `[0, at)`, en it weromkommen `String` befettet bytes `[at, len)`.
    /// `at` moat oan 'e grins fan in UTF-8-koadepunt wêze.
    ///
    /// Tink derom dat de kapasiteit fan `self` net feroaret.
    ///
    /// # Panics
    ///
    /// Panics as `at` net op in `UTF-8`-koadepuntgrins is, of as it bûten it lêste koadepunt fan 'e tekenrige is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Trunket dizze `String`, en ferwideret alle ynhâld.
    ///
    /// Hoewol dit betsjuttet dat de `String` in lingte fan nul hat, rekket syn kapasiteit net oan.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Makket in drainerende iterator dy't it oantsjutte berik yn 'e `String` fuortsmyt en de ferwidere `chars` opsmyt.
    ///
    ///
    /// Note: It elemintberik wurdt fuorthelle, sels as de iterator oant it ein net wurdt konsumeare.
    ///
    /// # Panics
    ///
    /// Panics as it begjinpunt as einpunt net op in [`char`]-grins lizze, of as se bûten de grinzen binne.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ferwiderje it berik oant de β fan 'e tekenrige
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // In folslein berik wisket de tekenrige
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Memory feiligens
        //
        // De String-ferzje fan Drain hat gjin problemen mei ûnthâldfeiligens fan 'e vector-ferzje.
        // De gegevens binne gewoan bytes.
        // Om't it berikferwidering bart yn Drop, as de Drain-iterator lekt wurdt, sil de ferwidering net barre.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Nim twa tagelyk lieningen út.
        // De &mut String sil net tagong wurde oant iteraasje is foarby, yn Drop.
        let self_ptr = self as *mut _;
        // VEILIGHEID: `slice::range` en `is_char_boundary` dogge de passende grinzen kontrolearje.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Ferwideret it oantsjutte berik yn 'e tekenrige, en ferfangt it troch de opjûne tekenrige.
    /// De opjûne tekenrige hoecht net deselde lingte te hawwen as it berik.
    ///
    /// # Panics
    ///
    /// Panics as it begjinpunt as einpunt net op in [`char`]-grins lizze, of as se bûten de grinzen binne.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ferfang it berik oant de β fan 'e tekenrige
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Memory feiligens
        //
        // Replace_range hat gjin problemen mei ûnthâldfeiligens fan in vector Splice.
        // fan de ferzje vector.De gegevens binne gewoan bytes.

        // WARSKOGING: it ynlinejen fan dizze fariabele soe (#81138) net sûn wêze
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WARSKOGING: it ynlinejen fan dizze fariabele soe (#81138) net sûn wêze
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` opnij brûke soe net sûn wêze (#81138) Wy geane derfan út dat de troch `range` rapporteare grinzen itselde bliuwe, mar in tsjinstridige ymplemintaasje kin feroarje tusken petearen
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konvertearret dizze `String` yn in [`Box`]`<`[`str`] `>`.
    ///
    /// Dit sil alle oerstallige kapasiteit falle.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Jout in stikje fan [`u8`] s bytes dy't waard besocht om te konvertearjen nei in `String`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // wat ûnjildige bytes, yn in vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Jout de bytes werom dy't binne besocht om te konvertearjen nei in `String`.
    ///
    /// Dizze metoade is foarsichtich konstruearre om tawizing te foarkommen.
    /// It sil de flater ferbrûke, de bytes ferpleatse, sadat in kopy fan 'e bytes net hoecht te meitsjen.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // wat ûnjildige bytes, yn in vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Helje in `Utf8Error` op om mear details te krijen oer de konversaasjefout.
    ///
    /// It [`Utf8Error`]-type levere troch [`std::str`] stiet foar in flater dy't foarkomme kin by it konvertearjen fan in stik fan [`u8`] nei in [`&str`].
    /// Yn dizze sin is it in analooch oan `FromUtf8Error`.
    /// Sjoch de dokumintaasje foar mear details oer it gebrûk.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// // wat ûnjildige bytes, yn in vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // de earste byte is hjir ûnjildich
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Om't wy iterearje oer `String`s, kinne wy teminsten ien allocaasje foarkomme troch de earste tekenrige fan 'e iterator te krijen en alle folgjende stringen derby oan te heakjen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Om't wy itere oer CoW's, kinne wy (potentially) teminsten ien allocaasje foarkomme troch it earste item te krijen en alle folgjende artikels derby te heakjen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// In gemak impl dat delegeart nei it impl foar `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Makket in lege `String` oan.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementeart de `+`-operator foar it gearfoegjen fan twa snaren.
///
/// Dit ferbrûkt de `String` oan 'e linkerkant en brûkt syn buffer opnij (groeit it as it nedich is).
/// Dit wurdt dien om te foarkommen dat in nije `String` tawiisd wurdt en de folsleine ynhâld op elke operaasje kopieare, wat soe liede ta *O*(*n*^ 2) draaitiid by it bouwen fan in *n*-byte string troch werhelle gearketting.
///
///
/// De snaar oan 'e rjochterkant is allinich liend;de ynhâld wurdt kopieare yn 'e werom `String`.
///
/// # Examples
///
/// It gearfoegjen fan twa `String`s nimt de earste op wearde en lient de twadde:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` wurdt ferpleatst en kin hjir net mear brûkt wurde.
/// ```
///
/// As jo de earste `String` trochgean wolle, kinne jo it klonearje en ynstee tafoegje oan 'e klon:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` is hjir noch jildich.
/// ```
///
/// `&str`-plakken gearfoegje kinne wurde dien troch de earste nei in `String` te konvertearjen:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementeart de `+=`-operator foar tafoeging oan in `String`.
///
/// Dit hat itselde gedrach as de [`push_str`][String::push_str]-metoade.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// In type alias foar [`Infallible`].
///
/// Dizze alias bestiet foar efterkompatibiliteit, en kin úteinlik ôfret wurde.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// In trait foar it konvertearjen fan in wearde nei in `String`.
///
/// Dizze trait wurdt automatysk ymplementeare foar elk type dat de [`Display`] trait ymplementeart.
/// As sadanich moat `ToString` net direkt wurde ymplementeare:
/// [`Display`] moat ynstee wurde ymplementeare, en jo krije de `ToString`-ymplemintaasje fergees.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konverteart de opjûne wearde nei in `String`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Yn dizze ymplemintaasje jout de `to_string`-metoade panics as de `Display`-ymplemintaasje in flater jout.
/// Dit jout oan in ferkearde `Display`-ymplemintaasje, om't `fmt::Write for String` nea in flater sels werombringt.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // In mienskiplike rjochtline is it net ynline generike funksjes.
    // It fuortsmiten fan `#[inline]` fan dizze metoade feroarsaket lykwols net negeare regressjes.
    // Sjoch <https://github.com/rust-lang/rust/pull/74852>, it lêste besykjen om it te ferwiderjen.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konverteart in `&mut str` yn in `String`.
    ///
    /// It resultaat wurdt tawiisd op 'e heap.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test lûkt yn libstd, wat hjir flaters feroarsaket
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konverteart it opjûne ynbox `str`-stik nei in `String`.
    /// It is opmerklik dat it `str`-stik eigendom is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konverteart de opjûne `String` nei in ynrjochte `str`-stik dat eigendom is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konverteart in tekenrige yn in liene fariant.
    /// D'r wurdt gjin heap tawiisd, en de tekenrige wurdt net kopieare.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konverteart in tekenrige yn in eigen fariant.
    /// D'r wurdt gjin heap tawiisd, en de tekenrige wurdt net kopieare.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konverteart in tekenreferinsje yn in liene fariant.
    /// D'r wurdt gjin heap tawiisd, en de tekenrige wurdt net kopieare.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konverteart de opjûne `String` nei in vector `Vec` dy't wearden fan type `u8` hat.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// In ôfwetterjende iterator foar `String`.
///
/// Dizze struktuer is makke troch de [`drain`]-metoade op [`String`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Sil wurde brûkt as&'in mutte string yn' e destruktor
    string: *mut String,
    /// Start fan diel om te ferwiderjen
    start: usize,
    /// Ein fan diel te ferwiderjen
    end: usize,
    /// Aktueel oerbleaun berik te ferwiderjen
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Brûk Vec::drain.
            // "Reaffirm" de grinzen kontrolearje om foar te kommen dat panic-koade opnij ynfoege wurdt.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Jout de oerbleaune (sub) string fan dizze iterator werom as in stik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef ympliseart hjirûnder by stabilisearjen.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Unkommentaar by it stabilisearjen fan `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>foar Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ympl <'a> AsRef <[u8]> foar Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}