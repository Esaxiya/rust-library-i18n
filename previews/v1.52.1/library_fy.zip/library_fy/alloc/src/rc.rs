//! Oanwizings foar tellen mei ien triedden.'Rc' stiet foar 'Reference
//! Counted'.
//!
//! It type [`Rc<T>`][`Rc`] leveret dielde eigendom fan in wearde fan it type `T`, tawiisd yn 'e heap.
//! [`clone`][clone] op [`Rc`] oanroppe produsearret in nije oanwizer foar deselde tawizing yn 'e heap.
//! As de lêste [`Rc`]-oanwizer nei in opjûne tawizing wurdt ferneatige, wurdt de yn dizze tawizing opslein wearde (faak oantsjutten as "inner value") ek sakke.
//!
//! Diele referinsjes yn Rust jouwe mutaasje standert net ta, en [`Rc`] is gjin útsûndering: jo kinne oer it algemien gjin feroarbere ferwizing krije nei wat yn in [`Rc`].
//! As jo mutabiliteit nedich binne, set in [`Cell`] of [`RefCell`] yn 'e [`Rc`];sjoch [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] brûkt net-atomyske referinsjetelling.
//! Dit betsjut dat overhead heul leech is, mar in [`Rc`] kin net tusken threads ferstjoerd wurde, en [`Rc`] ymplementeart [`Send`][send] dêrom net.
//! As resultaat sil de Rust-kompilearder *op kompilaasjetiid* kontrolearje dat jo gjin [`Rc`] s tusken threads stjoere.
//! As jo tellen mei meardere triedden, atoomferwizings nedich binne, brûk dan [`sync::Arc`][arc].
//!
//! De [`downgrade`][downgrade]-metoade kin brûkt wurde om in [`Weak`]-oanwizer dy't net besit is oan te meitsjen.
//! In [`Weak`]-oanwizer kin ['upgrade'][upgrade] d wêze nei in [`Rc`], mar dit sil [`None`] werombringe as de wearde opslein yn 'e tawizing al is sakke.
//! Mei oare wurden, `Weak`-oanwizers hâlde de wearde yn 'e tawizing net libben;lykwols *hâlde se* de tawizing (de backingwinkel foar de ynderlike wearde) libben.
//!
//! In syklus tusken [`Rc`]-oanwizers wurdt nea deallokeard.
//! Om dizze reden wurdt [`Weak`] brûkt om syklussen te brekken.
//! In beam kin bygelyks sterke [`Rc`]-oanwizers hawwe fan âlderknooppunten oant bern, en [`Weak`]-oanwizings fan bern werom nei har âlders.
//!
//! `Rc<T>` automatysk ferwiderje nei `T` (fia de [`Deref`] trait), sadat jo de metoaden fan 'T' kinne skilje op in wearde fan it type [`Rc<T>`][`Rc`].
//! Om nammebotsingen mei 'T'-metoaden te foarkommen, binne de metoaden fan [`Rc<T>`][`Rc`] sels assosjeare funksjes, neamd [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>De ymplementaasjes fan traits lykas `Clone` kinne ek wurde neamd mei folslein kwalifisearre syntaksis.
//! Guon minsken brûke leaver folsleine kwalifisearre syntaksis, wylst oaren it foarkomme mei syntaksis fan metoade-oprop.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metoade-oprop syntaksis
//! let rc2 = rc.clone();
//! // Folslein kwalifisearre syntaksis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] docht gjin automatyske ferwidering nei `T`, om't de ynderlike wearde miskien al is sakke.
//!
//! # Cloning referinsjes
//!
//! In nije referinsje oanmeitsje foar deselde tawizing as in besteande referinsjeteld oanwizer wurdt dien mei de `Clone` trait ymplementeare foar [`Rc<T>`][`Rc`] en [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // De twa hjirûnder syntaksis binne ekwivalint.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a en b wize beide op deselde ûnthâldlokaasje as foo.
//! ```
//!
//! De `Rc::clone(&from)`-syntaksis is de idiomatyskste, om't it de betsjutting fan 'e koade eksplisyt trochjout.
//! Yn it boppesteande foarbyld makket dizze syntaksis it makliker om te sjen dat dizze koade in nije referinsje oanmakket yn stee fan it kopiearjen fan 'e heule ynhâld fan foo.
//!
//! # Examples
//!
//! Tink oan in senario wêr't in set fan 'Gadget's eigendom is fan in opjûne `Owner`.
//! Wy wolle ús 'Gadget's' wize op har `Owner`.Wy kinne dit net mei unyk eigendom dwaan, om't mear dan ien gadget ta deselde `Owner` kin hearre.
//! [`Rc`] lit ús in `Owner` diele tusken meardere `Gadget`s, en hawwe de `Owner` tawiisd bliuwe salang't `Gadget` derop wiist.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... oare fjilden
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... oare fjilden
//! }
//!
//! fn main() {
//!     // Meitsje in referinsjetelde `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Meitsje 'Gadget's dy't ta `gadget_owner` hearre.
//!     // Kloning fan 'e `Rc<Owner>` jouwt ús in nije oanwizer foar deselde `Owner`-allocaasje, wêrtroch't de referinsjetelling yn it proses ferheget.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Besykje ús lokale fariabele `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Nettsjinsteande it fallen fan `gadget_owner`, kinne wy de namme fan 'e `Owner` fan' Gadget's 'noch altyd ôfdrukke.
//!     // Dit komt om't wy mar ien `Rc<Owner>` hawwe fallen, net de `Owner` dy't it wiist.
//!     // Salang't d'r oare `Rc<Owner>` op deselde `Owner`-allocaasje wize, sil it live bliuwe.
//!     // De fjildprojeksje `gadget1.owner.name` wurket om't `Rc<Owner>` automatysk ferwidere nei `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Oan 'e ein fan' e funksje wurde `gadget1` en `gadget2` ferneatige, en mei har de lêst telde ferwizings nei ús `Owner`.
//!     // Gadget Man wurdt no ek ferneatige.
//!     //
//! }
//! ```
//!
//! As ús easken feroarje, en wy moatte ek kinne trochgean fan `Owner` nei `Gadget`, sille wy problemen hawwe.
//! In [`Rc`]-oanwizer fan `Owner` nei `Gadget` yntroduseart in syklus.
//! Dit betsjut dat har referinsjetellingen noait 0 kinne berikke, en de tawizing sil nea wurde ferneatige:
//! in geheugenlek.Om dit te krijen, kinne wy [`Weak`]-oanwizers brûke.
//!
//! Rust makket it eins wat lestich om dizze loop yn it earste plak te produsearjen.Om mei twa wearden te einigjen dy't op elkoar wize, moat ien dêrfan feroarber wêze.
//! Dit is lestich, om't [`Rc`] ûnthâldfeiligens twingt troch allinich dielde referinsjes út te jaan nei de wearde dy't it wikkelt, en dizze tastean gjin direkte mutaasje.
//! Wy moatte it diel fan 'e wearde dat wy wolle mutearje ynpakke yn in [`RefCell`], dy't *ynterieurmutabiliteit* biedt: in metoade om mutabiliteit te berikken fia in dielde referinsje.
//! [`RefCell`] twingt de lienregels fan Rust by runtime ôf.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... oare fjilden
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... oare fjilden
//! }
//!
//! fn main() {
//!     // Meitsje in referinsjetelde `Owner`.
//!     // Tink derom dat wy de vector fan 'Eigner' fan 'Gadget' yn in `RefCell` hawwe set, sadat wy it kinne mutearje fia in dielde referinsje.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Meitsje 'Gadget's dy't ta `gadget_owner` hearre, lykas earder.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Foegje de `Gadget`s ta oan har `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamyske lien einiget hjir.
//!     }
//!
//!     // Iterearje oer ús 'Gadget's, drukje har details út.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` is in `Weak<Gadget>`.
//!         // Om't `Weak`-oanwizers net garandearje kinne dat de tawizing noch bestiet, moatte wy `upgrade` skilje, dy't in `Option<Rc<Gadget>>` retourneert.
//!         //
//!         //
//!         // Yn dit gefal wite wy dat de allocaasje noch bestiet, dus wy `unwrap` de `Option` gewoan.
//!         // Yn in yngewikkelder programma kinne jo sierlike flaterbehanneling nedich wêze foar in `None`-resultaat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Oan 'e ein fan' e funksje wurde `gadget_owner`, `gadget1` en `gadget2` ferneatige.
//!     // D'r binne no gjin sterke (`Rc`)-oanwizings foar de gadgets, sadat se wurde ferneatige.
//!     // Dit nulet de referinsjetelling op Gadget Man, sadat hy ek wurdt ferneatige.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dit is repr(C) oant future-bestindich tsjin mooglike fjildferoaring, wat soe ynterferearje mei oars feilige [into|from]_raw() fan transmutabele ynderlike typen.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// In referinsjetelling oanwizer mei ien triedden.'Rc' stiet foar 'Reference
/// Counted'.
///
/// Sjoch de [module-level documentation](./index.html) foar mear details.
///
/// De ynherinte metoaden fan `Rc` binne allegear assosjeare funksjes, wat betsjut dat jo se moatte neame as bgl. [`Rc::get_mut(&mut value)`][get_mut] ynstee fan `value.get_mut()`.
/// Dit foarkomt konflikten mei metoaden fan it ynterne type `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Dizze ûnfeilichheid is ok, want wylst dizze Rc libbet, wurde wy garandearre dat de ynderlike oanwizer jildich is.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstrueart in nije `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // D'r is in ymplisite swakke oanwizer eigendom fan alle sterke oanwizers, dy't derfoar soarget dat de swakke destruktor de tawizing nea befrijt, wylst de sterke destruktor rint, sels as de swakke oanwizer wurdt opslein yn 'e sterke.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstrueart in nije `Rc<T>` mei in swakke ferwizing nei himsels.
    /// Besykje de swakke referinsje te ferbetterjen foardat dizze funksje weromkomt, sil resultearje yn in `None`-wearde.
    ///
    /// De swakke referinsje kin lykwols frij wurde kloneare en op in letter tiid bewarre wurde foar gebrûk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mear fjilden
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruearje it binnenste yn 'e "uninitialized"-steat mei in inkele swakke referinsje.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // It is wichtich dat wy it eigendom fan 'e swakke oanwizer net opjaan, oars kin it ûnthâld befrijd wurde as `data_fn` weromkomt.
        // As wy echt eigendom wolle trochjaan, kinne wy in ekstra swakke oanwizer foar ússels oanmeitsje, mar dit soe resultearje yn ekstra updates foar de swakke referinsjetelling dy't oars net nedich is.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Sterke referinsjes moatte kollektyf in dielde swakke referinsje hawwe, dus run de destruktor net foar ús âlde swakke referinsje.
        //
        mem::forget(weak);
        strong
    }

    /// Konstrueart in nije `Rc` mei net-inisjalisearre ynhâld.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueart in nije `Rc` mei net-inisjalisearre ynhâld, mei it ûnthâld fol mei `0`-bytes.
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueart in nije `Rc<T>`, weromsette in flater as de tawizing mislearret
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // D'r is in ymplisite swakke oanwizer eigendom fan alle sterke oanwizers, dy't derfoar soarget dat de swakke destruktor de tawizing nea befrijt, wylst de sterke destruktor rint, sels as de swakke oanwizer wurdt opslein yn 'e sterke.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstrueart in nije `Rc` mei net-inisjalisearre ynhâld, en jout in flater werom as de tawizing mislearret
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstrueart in nije `Rc` mei net-inisjalisearre ynhâld, mei it ûnthâld fol mei `0`-bytes, en jout in flater as de tawizing mislearret
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstrueart in nije `Pin<Rc<T>>`.
    /// As `T` `Unpin` net ymplementeart, wurdt `value` yn it ûnthâld fêstmakke en kin net ferpleatst wurde.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Jout de ynderlike wearde werom, as de `Rc` presys ien sterke referinsje hat.
    ///
    /// Oars wurdt in [`Err`] weromjûn mei deselde `Rc` dy't waard trochjûn.
    ///
    ///
    /// Dit sil slagje, sels as d'r opfallende swakke referinsjes binne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopiearje it befette objekt

                // Jou foar Weaks oan dat se net kinne wurde befoardere troch de sterke telling te ferleegjen, en ferwiderje dan de ymplisite "strong weak"-oanwizer, wylst jo ek drop logika behannelje troch gewoan in falske Weak te meitsjen.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruearret in nije referinsjetelde slach mei net-inisjalisearre ynhâld.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstrueart in nij referinsjeteld stikje mei net-inisjalisearre ynhâld, wêrby it ûnthâld wurdt fol mei `0`-bytes.
    ///
    ///
    /// Sjoch [`MaybeUninit::zeroed`][zeroed] foar foarbylden fan korrekt en ferkeard gebrûk fan dizze metoade.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konverteart nei `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Lykas by [`MaybeUninit::assume_init`] is it oan 'e beller om te garandearjen dat de ynderlike wearde echt yn in inisjalisearre steat is.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket direkte undefined gedrach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konverteart nei `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Lykas by [`MaybeUninit::assume_init`] is it oan 'e beller om te garandearjen dat de ynderlike wearde echt yn in inisjalisearre steat is.
    ///
    /// Dit neame as de ynhâld noch net folslein is inisjalisearre feroarsaket direkte undefined gedrach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsteld inisjalisaasje:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Ferbrûkt de `Rc`, retourneert de wikkele oanwizer.
    ///
    /// Om in geheugenlek te foarkommen moat de oanwizer mei [`Rc::from_raw`][from_raw] werom wurde konvertearre nei in `Rc`.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Jout in rauwe oanwizer nei de gegevens.
    ///
    /// De tellen wurde op gjin inkelde manier beynfloede en de `Rc` wurdt net konsumeare.
    /// De oanwizer is jildich salang't d'r sterke tellen binne yn 'e `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kin net troch Deref::deref of Rc::inner gean om't
        // dit is ferplicht om raw/mut herkomst te behâlden sa dat bgl
        // `get_mut` kin fia de oanwizer skriuwe neidat de Rc is weromfûn fia `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstrueart in `Rc<T>` fan in rauwe oanwizer.
    ///
    /// De rauwe oanwizer moat earder werom west hawwe troch in oprop nei [`Rc<U>::into_raw`][into_raw] wêr't `U` deselde grutte en ôfstimming moat hawwe as `T`.
    /// Dit is triviaal wier as `U` `T` is.
    /// Tink derom dat as `U` net `T` is, mar deselde grutte en ôfstimming hat, dit yn prinsipe is as ferwizings fan referinsjes fan ferskate soarten.
    /// Sjoch [`mem::transmute`][transmute] foar mear ynformaasje oer hokker beheiningen jilde yn dit gefal.
    ///
    /// De brûker fan `from_raw` moat derfoar soargje dat in spesifike wearde fan `T` mar ien kear falt.
    ///
    /// Dizze funksje is ûnfeilich om't ferkeard gebrûk liede kin ta ûnthâldfeiligens, sels as de weromkommende `Rc<T>` noait tagong wurdt.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertearje werom nei in `Rc` om lek te foarkommen.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Fierdere petearen nei `Rc::from_raw(x_ptr)` soene geheugen-ûnfeilich wêze.
    /// }
    ///
    /// // It ûnthâld waard befrijd doe't `x` bûten it berik hjirboppe gie, dus `x_ptr` hinget no!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // De offset omkeare om de orizjinele RcBox te finen.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Makket in nije [`Weak`]-oanwizer foar dizze tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Soargje derfoar dat wy gjin hingjende Swakke meitsje
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Krijt it oantal [`Weak`]-oanwizers foar dizze tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Krijt it oantal sterke (`Rc`)-oanwizers foar dizze tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Jout `true` werom as d'r gjin oare `Rc`-of [`Weak`]-oanwizers binne foar dizze tawizing.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Jout in feroarbere ferwizing nei de opjûne `Rc`, as d'r gjin oare `Rc`-of [`Weak`]-oanwizings binne foar deselde tawizing.
    ///
    ///
    /// Jout [`None`] oars werom, om't it net feilich is om in dielde wearde te mutearjen.
    ///
    /// Sjoch ek [`make_mut`][make_mut], dat [`clone`][clone] de ynderlike wearde sil as der oare oanwizings binne.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Jout in feroarbere referinsje yn 'e opjûne `Rc`, sûnder kontrôle.
    ///
    /// Sjoch ek [`get_mut`], dat is feilich en docht passende kontrôles.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Eltse oare `Rc`-of [`Weak`]-oanwizings foar deselde tawizing meie net wurde ferwidere foar de doer fan 'e werombetelle liening.
    ///
    /// Dit is triviaal it gefal as der gjin sokke oanwizings besteane, bygelyks direkt nei `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Wy binne foarsichtich om *gjin* referinsje te meitsjen dy't de "count"-fjilden befettet, om't dit konflikt hat mei tagong ta de referinsjetellingen (bgl.
        // troch `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Jout `true` werom as de twa `Rc`s op deselde tawizing wize (yn in trant lykas [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Makket in feroarbere ferwizing nei de opjûne `Rc`.
    ///
    /// As d'r oare `Rc`-oanwizings binne foar deselde tawizing, dan sil `make_mut` de binnenste wearde [`clone`] foar in nije tawizing om unyk eigendom te garandearjen.
    /// Dit wurdt ek wol clone-on-write neamd.
    ///
    /// As d'r gjin oare `Rc`-oanwizers binne foar dizze tawizing, dan wurde [`Weak`]-oanwizers foar dizze tawizing loskeppele.
    ///
    /// Sjoch ek [`get_mut`], dat sil mislearje ynstee fan kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Sil neat klone
    /// let mut other_data = Rc::clone(&data);    // Sil gjin ynderlike gegevens klone
    /// *Rc::make_mut(&mut data) += 1;        // Klonet ynderlike gegevens
    /// *Rc::make_mut(&mut data) += 1;        // Sil neat klone
    /// *Rc::make_mut(&mut other_data) *= 2;  // Sil neat klone
    ///
    /// // No wize `data` en `other_data` op ferskate allocaasjes.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pointers sille wurde loskeppele:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Moat de gegevens klone, d'r binne oare RC's.
            // Foardiel tawize geheugen om de kloneare wearde direkt te skriuwen.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kin de gegevens gewoan stelle, alles wat oer is, is Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ferwiderje ymplisite sterk-swakke ref (gjin need hjir in falske Swak te meitsjen-wy witte dat oare Swakken foar ús kinne opromje)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Dizze ûnfeilichheid is ok, om't wy garandearre binne dat de weromwizer de *iennige* oanwizer is dy't ea nei T weromjûn wurdt.
        // Us referinsjetelling is garandearre 1 te wêzen op dit punt, en wy hawwe easke dat de `Rc<T>` sels `mut` is, dat wy jouwe de iennichste mooglike referinsje werom nei de tawizing.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Poging de `Rc<dyn Any>` te downcast nei in konkreet type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Jout in `RcBox<T>` ta mei foldwaande romte foar in mooglik net grutte binnenwearde wêr't de wearde de opmaak hat.
    ///
    /// De funksje `mem_to_rcbox` wurdt neamd mei de gegevenswizer en moat in (potinsjeel dikke)-wizer werom jaan foar de `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Berekkenje opmaak mei de opjûne weardeopmaak.
        // Earder waard opmaak berekkene op 'e útdrukking `&*(ptr as* const RcBox<T>)`, mar dit makke in ferkearde referinsje (sjoch #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Jout in `RcBox<T>` ta mei genôch romte foar in mooglik net grutte binnenwearde wêr't de wearde de opmaak hat, en jout in flater as de tawizing mislearret.
    ///
    ///
    /// De funksje `mem_to_rcbox` wurdt neamd mei de gegevenswizer en moat in (potinsjeel dikke)-wizer werom jaan foar de `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Berekkenje opmaak mei de opjûne weardeopmaak.
        // Earder waard opmaak berekkene op 'e útdrukking `&*(ptr as* const RcBox<T>)`, mar dit makke in ferkearde referinsje (sjoch #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Tawize foar de opmaak.
        let ptr = allocate(layout)?;

        // Initialisearje de RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Jout in `RcBox<T>` ta mei genôch romte foar in net grutte ynderlike wearde
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Tawize foar de `RcBox<T>` mei de opjûne wearde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiearje wearde as bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Befrij de tawizing sûnder de ynhâld derfan te litten
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Jout in `RcBox<[T]>` ta mei de opjûne lingte.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopiearje eleminten fan slice nei nij tawiisde Rc <\[T\]>
    ///
    /// Unfeilich omdat de beller eigendom moat nimme of `T: Copy` moat bine
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruearret in `Rc<[T]>` fan in iterator dy't bekend is fan in beskate grutte.
    ///
    /// Gedrach is undefined as de grutte ferkeard wêze soe.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic wachter by kloning fan T-eleminten.
        // Yn it gefal fan in panic sille eleminten dy't binne skreaun yn 'e nije RcBox wurde falle litten, dan wurdt it ûnthâld befrijd.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Oanwizer nei earste elemint
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles dúdlik.Ferjit de wacht, sadat it de nije RcBox net befrijt.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesjalisaasje trait brûkt foar `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Falt de `Rc` del.
    ///
    /// Dit sil de sterke referinsjetelling ferminderje.
    /// As de sterke referinsjetelling nul berikt, dan binne de iennige oare referinsjes (as ien) [`Weak`], dus wy `drop` de ynderlike wearde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Printset neat
    /// drop(foo2);   // Printsje "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ferneatigje it befette objekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ferwiderje de ymplisite "strong weak"-oanwizer no't wy de ynhâld hawwe ferneatige.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Makket in kloon fan 'e `Rc`-oanwizer.
    ///
    /// Dit soarget foar in oare oanwizer foar deselde tawizing, wêrtroch it sterke referinsjetelling fergruttet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Makket in nije `Rc<T>` oan, mei de `Default`-wearde foar `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack om spesjalisaasje op `Eq` ta te litten, hoewol `Eq` in metoade hat.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Wy dogge dizze spesjalisaasje hjir, en net as in mear algemiene optimalisaasje op `&T`, om't it oars in kosten tafoege oan alle gelikenskontrôles op refs.
/// Wy geane derfan út dat `Rc`s wurde brûkt om grutte wearden op te slaan, dy't stadich binne om te klonen, mar ek swier om te kontrolearjen op gelikens, wêrtroch dizze kosten makliker betelje.
///
/// It is ek wierskynlik twa `Rc`-klonen te hawwen, dy't op deselde wearde wize, dan twa `&T`s.
///
/// Wy kinne dit allinich dwaan as `T: Eq` as `PartialEq` bewust irreflexyf wêze kin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Gelikensens foar twa `Rc`s.
    ///
    /// Twa `Rc`s binne gelyk as har ynderlike wearden gelyk binne, sels as se wurde opslein yn ferskillende tawizing.
    ///
    /// As `T` ek `Eq` ymplementeart (wat refleksiviteit fan gelikens ympliseart), binne twa 'Rc's dy't op deselde tawizing wize altyd gelyk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ungelikens foar twa `Rc`s.
    ///
    /// Twa `Rc`s binne ûngelikens as har ynderlike wearden ûngelikens binne.
    ///
    /// As `T` ek `Eq` ymplementeart (refleksiviteit fan gelikens ymplisyt), binne twa `Rc`s dy't op deselde tawizing wize nea ûngelikens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Parsjele fergeliking foar twa `Rc`s.
    ///
    /// De twa wurde fergelike troch `partial_cmp()` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder dan fergeliking foar twa `Rc`s.
    ///
    /// De twa wurde fergelike troch `<` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Minder as of gelyk oan' fergeliking foar twa 'Rc's.
    ///
    /// De twa wurde fergelike troch `<=` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Grutter dan fergeliking foar twa `Rc`s.
    ///
    /// De twa wurde fergelike troch `>` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Grutter dan of gelyk oan' fergeliking foar twa 'Rc's.
    ///
    /// De twa wurde fergelike troch `>=` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Fergeliking foar twa `Rc`s.
    ///
    /// De twa wurde fergelike troch `cmp()` op te roppen op har ynderlike wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Tawize in troch referinsje rekkene stik en folje it troch klonen fan 'v' items.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Soargje in referinsjetelde tekenrige en kopiearje `v` dêryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Soargje in referinsjetelde tekenrige en kopiearje `v` dêryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Ferpleats in fakobjekt nei in nij, referinsje teld, tawizing.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Tawize in skyfke dat troch referinsjes teld is en ferpleatse 'v''s items deryn.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Tastean de Vec har ûnthâld te befrijen, mar har ynhâld net te ferneatigjen
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Nimt elk elemint yn 'e `Iterator` en sammelt it yn in `Rc<[T]>`.
    ///
    /// # Performance skaaimerken
    ///
    /// ## De algemiene saak
    ///
    /// Yn it algemiene gefal wurdt sammeljen yn `Rc<[T]>` dien troch earst te sammeljen yn in `Vec<T>`.Dat is by it skriuwen fan it folgjende:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit gedraacht as skreau wy:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // De earste set fan allocaasjes bart hjir.
    ///     .into(); // In twadde allocaasje foar `Rc<[T]>` bart hjir.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit sil safolle kearen allocearje as nedich foar it bouwen fan 'e `Vec<T>` en dan sil it ien kear tawize foar it feroarjen fan' e `Vec<T>` yn 'e `Rc<[T]>`.
    ///
    ///
    /// ## Iterators fan bekende lingte
    ///
    /// As jo `Iterator` `TrustedLen` ymplementeart en fan in krekte grutte is, sil in inkele allocaasje wurde makke foar de `Rc<[T]>`.Bygelyks:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Krekt in inkele allocaasje bart hjir.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spesjalisaasje trait brûkt foar sammeljen yn `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dit is it gefal foar in `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: Wy moatte derfoar soargje dat de iterator in krekte lingte hat en wy hawwe.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Falle werom nei normale ymplemintaasje.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` is in ferzje fan [`Rc`] dy't in net-besitende ferwizing hat nei de behearde allocaasje.De tawizing is tagong troch [`upgrade`] op te roppen op 'e `Weak`-oanwizer, dy't in [`Option`]`<`[`Rc`] `<T>>`.
///
/// Sûnt in `Weak`-referinsje telt net by eigendom, sil it net foarkomme dat de wearde opslein yn 'e tawizing falt, en `Weak` sels makket gjin garânsjes oer de wearde dy't noch oanwêzich is.
/// Sa kin it [`None`] werombringe as [`upgrade`] d.
/// Tink derom lykwols dat in `Weak`-referinsje * foarkomt dat de tawizing sels (de backingwinkel) deallokearre wurdt.
///
/// In `Weak`-oanwizer is nuttich foar it behâld fan in tydlike ferwizing nei de tawizing beheard troch [`Rc`] sûnder te foarkommen dat de ynderlike wearde derfan falt.
/// It wurdt ek brûkt om sirkulêre referinsjes tusken [`Rc`]-oanwizers foar te kommen, om't wjerskanten referinsjes nea [`Rc`] kinne falle litte.
/// In beam kin bygelyks sterke [`Rc`]-oanwizers hawwe fan âlderknooppunten oant bern, en `Weak`-oanwizings fan bern werom nei har âlders.
///
/// De typyske manier om in `Weak`-oanwizer te krijen is [`Rc::downgrade`] te skiljen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is in `NonNull` om de grutte fan dit type yn enums te optimalisearjen, mar it is net needsaaklik in jildige oanwizer.
    //
    // `Weak::new` stelt dit yn op `usize::MAX`, sadat it gjin romte hoecht te jaan op 'e heap.
    // Dat is gjin wearde dy't in echte oanwizer ea sil hawwe, om't RcBox op syn minst 2 hat.
    // Dit is allinich mooglik as `T: Sized`;net grutte `T` bongelt noait.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstrueart in nije `Weak<T>`, sûnder ûnthâld te allocearjen.
    /// [`upgrade`] skilje op 'e retoerwearde jouwt [`None`] altyd.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Helpertype om tagong te krijen ta de referinsjetellingen sûnder bewearingen te meitsjen oer it datafjild.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Jout in rauwe oanwizer nei it objekt `T` wiisd troch dizze `Weak<T>`.
    ///
    /// De oanwizer is allinich jildich as d'r in pear sterke referinsjes binne.
    /// De oanwizer kin oars hingje, unjustere of sels [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Beide wize op itselde objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // De sterke hjir hâldt it libben, dat wy kinne noch tagong krije ta it objekt.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mar net mear.
    /// // Wy kinne weak.as_ptr() dwaan, mar tagong ta de oanwizer soe liede ta undefined gedrach.
    /// // assert_eq! ("hallo", ûnfeilich {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // As de oanwizer hinget, stjoere wy de sentinel direkt werom.
            // Dit kin gjin jildich adres foar lading wêze, om't de lading teminsten like ôfstimd is as RcBox (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: as is_dangling falsk jout, dan is de oanwizer te ferwiderjen.
            // De lading kin op dit punt wurde sakke, en wy moatte de herkomst behâlde, dus brûk rûge oanwizermanipulaasje.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Ferbrûkt de `Weak<T>` en makket it yn in rauwe oanwizer.
    ///
    /// Dit konverteart de swakke oanwizer yn in rauwe oanwizer, wylst it eigendom fan ien swakke referinsje noch behâldt (de swakke telling wurdt net oanpast troch dizze operaasje).
    /// It kin werombrocht wurde yn 'e `Weak<T>` mei [`from_raw`].
    ///
    /// Deselde beheiningen foar tagong ta it doel fan 'e oanwizer jilde as mei [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverteart in rauwe oanwizer dy't earder makke is troch [`into_raw`] werom yn `Weak<T>`.
    ///
    /// Dit kin brûkt wurde om feilich in sterke referinsje te krijen (troch letter [`upgrade`] te skiljen) of om de swakke telling te fertsjinjen troch de `Weak<T>` te litten falle.
    ///
    /// It nimt eigendom fan ien swakke referinsje (mei útsûndering fan oanwizings makke troch [`new`], om't dizze neat hawwe; de metoade wurket noch altyd op har).
    ///
    /// # Safety
    ///
    /// De oanwizer moat ûntstien wêze fan 'e [`into_raw`] en moat syn potensjele swakke referinsje noch hawwe.
    ///
    /// It is tastien dat de sterke telling 0 is op it momint dat dit wurdt neamd.
    /// Dochs nimt dit eigendom fan ien swakke referinsje dy't op it stuit fertsjintwurdige is as in rauwe oanwizer (de swakke telling wurdt net wizige troch dizze operaasje) en dêrom moat it wurde keppele oan in eardere oprop nei [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ferlytsje de lêste swakke greve.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sjoch Weak::as_ptr foar kontekst oer hoe't de ynfierpointer ôflaat is.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is in hingjende Swak.
            ptr as *mut RcBox<T>
        } else {
            // Oars wurde wy garandearre dat de oanwizer kaam fan in net-bûnte Swak.
            // VEILIGHEID: data_offset is feilich te beljen, om't ptr in echte (potinsjeel sakke) T. ferwiist.
            let offset = unsafe { data_offset(ptr) };
            // Sadwaande keare wy de offset om de hiele RcBox te krijen.
            // VEILIGHEID: de oanwizer is ûntstien út in Swak, dus dizze kompensaasje is feilich.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: wy hawwe no de orizjinele Swakke oanwizer weromfûn, dus kinne wy de Swakke oanmeitsje.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Besiket de `Weak`-oanwizer op te ferbetterjen nei in [`Rc`], en fertraging fan 'e ynderlike wearde as it suksesfol is, fertrage.
    ///
    ///
    /// Jout [`None`] werom as de ynderlike wearde yntusken is sakke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ferneatigje alle sterke oanwizings.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Krijt it oantal sterke (`Rc`)-oanwizers dy't op dizze tawizing wize.
    ///
    /// As `self` is makke mei [`Weak::new`], sil dit 0 werombringe.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Krijt it oantal `Weak`-oanwizers dy't op dizze tawizing wize.
    ///
    /// As der gjin sterke oanwizings bliuwe, sil dit nul werombringe.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // lûk it ymplisite swakke ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Jout `None` werom as de oanwizer hinget en d'r gjin `RcBox` tawiisd is, (dus as dizze `Weak` is makke troch `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Wy binne foarsichtich om *net* in referinsje te meitsjen dy't it "data"-fjild omfettet, om't it fjild tagelyk kin wurde muteare (bygelyks as de lêste `Rc` falt, sil it gegevensfjild te plak falle).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Jout `true` werom as de twa 'Swakke' op deselde tawizing wize (gelyk oan [`ptr::eq`]), of as beide net wize op in tawizing (om't se binne makke mei `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Om't dit oanwizings fergeliket, betsjuttet it dat `Weak::new()` inoar sille lykweardich wêze, hoewol se net op in allocaasje wize.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Fergelykje `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Smyt de `Weak`-oanwizer del.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Printset neat
    /// drop(foo);        // Printsje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // de swakke telling begjint by 1, en sil allinich nei nul gean as alle sterke oanwizings ferdwûn binne.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Makket in kloon fan 'e `Weak`-oanwizer dy't wiist op deselde tawizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstrueart in nije `Weak<T>`, tawiist ûnthâld foar `T` sûnder it te initialisearjen.
    /// [`upgrade`] skilje op 'e retoerwearde jouwt [`None`] altyd.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Wy kontroleare_add hjir om feilich mei mem::forget om te gean.Yn't bysonder
// as jo mem::forget Rcs (of Weaks) binne, kin de ref-count oerstreamje, en dan kinne jo de tawizing frijmeitsje, wylst der útsûnderlike Rcs (as Weaks) besteane.
//
// Wy ôfbrekke om't dit sa'n degenerearre senario is dat wy net skele oer wat der bart-gjin echt programma soe dit ea moatte ûnderfine.
//
// Dit moat negeare overhead hawwe, om't jo dizze eigentlik net in soad moatte klone yn Rust, tank oan eigendom en move-semantyk.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Wy wolle ôfbrekke by oerrin ynstee fan de wearde te fallen.
        // De referinsjetelling sil nea nul wêze as dit hjit;
        // nettsjinsteande ynfoegje wy hjir in ôfbrekke om LLVM oan te jaan op in oars miste optimisaasje.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Wy wolle ôfbrekke by oerrin ynstee fan de wearde te fallen.
        // De referinsjetelling sil nea nul wêze as dit hjit;
        // nettsjinsteande ynfoegje wy hjir in ôfbrekke om LLVM oan te jaan op in oars miste optimisaasje.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Krij de kompensaasje binnen in `RcBox` foar de lading efter in oanwizer.
///
/// # Safety
///
/// De oanwizer moat wize op (en jildige metadata hawwe foar) in earder jildich eksimplaar fan T, mar de T is tastien te falle.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Rjochtsje de net grutte wearde út oan 'e ein fan' e RcBox.
    // Om't RcBox repr(C) is, sil it altyd it lêste fjild yn it ûnthâld wêze.
    // VEILIGHEID: om't de iennichste net grutte soarten mooglik binne plakjes, trait-objekten,
    // en eksterne typen, de ynfierfeiligensfereaske is op it stuit genôch om te foldwaan oan de easken fan align_of_val_raw;dit is in ymplementaasjedetail fan 'e taal dy't net bûten std kin wurde fertroud.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}