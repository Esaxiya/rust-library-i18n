#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// De ynhâld fan it nije ûnthâld is uninitialisearre.
    Uninitialized,
    /// It nije ûnthâld sil garandearre wurde nulsteld.
    Zeroed,
}

/// In helpmiddel op leech nivo foar ergonomysk tawizen, weryndieljen en ôfhanneljen fan in buffer ûnthâld op 'e heap sûnder hoege te soargen oer alle belutsen hoeksaken.
///
/// Dit type is poerbêst foar it bouwen fan jo eigen datastrukturen lykas Vec en VecDeque.
/// Yn't bysonder:
///
/// * Produseart `Unique::dangling()` op nulgrutte soarten.
/// * Produseart `Unique::dangling()` op allocaasjes mei nul-lingte.
/// * Foarkomt `Unique::dangling()` frij.
/// * Fanget alle oerstreamingen yn berekkeningen fan kapasiteit (befoardert se nei "capacity overflow" panics).
/// * Wachten tsjin 32-bit systemen tawize mear dan isize::MAX bytes.
/// * Wachten tsjin oerrin fan jo lingte.
/// * Ropt `handle_alloc_error` op foar feilbere allocaasjes.
/// * Befettet in `ptr::Unique` en jouwt de brûker dus alle relatearre foardielen.
/// * Brûkt it oerskot dat werom is fan 'e allocator om de grutste beskikbere kapasiteit te brûken.
///
/// Dit type ynspekteart yn elk gefal net it ûnthâld dat it beheart.As it falt, sil *it ûnthâld* frijmeitsje, mar it *sil net* besykje de ynhâld te fallen.
/// It is oan 'e brûker fan `RawVec` om de eigentlike dingen *yn*`RawVec` te behanneljen.
///
/// Tink derom dat it oerskot fan nul-grutte typen altyd ûneinich is, dat `capacity()` altyd `usize::MAX` weromjout.
/// Dit betsjut dat jo foarsichtich moatte wêze as jo dit type mei in `Box<[T]>` rûn trippe, om't `capacity()` de lingte net oplevert.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dit bestiet om't `#[unstable]` `const fn`s net hoecht te foldwaan oan `min_const_fn` en dat se dus ek net kinne wurde neamd yn`min_const_fn`s.
    ///
    /// As jo `RawVec<T>::new` of ôfhinklikens feroarje, soargje der dan foar dat jo neat yntrodusearje dat wier `min_const_fn` yn striid is.
    ///
    /// NOTE: Wy koenen dizze hack foarkomme en konformiteit kontrolearje mei wat `#[rustc_force_min_const_fn]`-attribút dat konformiteit mei `min_const_fn` fereasket, mar it net needsaaklik makket it op te roppen yn `stable(...) const fn`/brûkerskoade dat `foo` net ynskeakelt as `#[rustc_const_unstable(feature = "foo", issue = "01234")]` oanwêzich is.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Makket de grutste mooglike `RawVec` (op 'e systeemheap) sûnder tawize.
    /// As `T` positive grutte hat, dan makket dit in `RawVec` mei kapasiteit `0`.
    /// As `T` nulgrutte is, dan makket it in `RawVec` mei kapasiteit `usize::MAX`.
    /// Nuttich foar it útfieren fan fertrage tawizing.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Makket in `RawVec` (op 'e systeemheap) mei krekt de easken foar kapasiteit en ôfstimming foar in `[T; capacity]`.
    /// Dit is lykweardich oan it skiljen fan `RawVec::new` as `capacity` `0` is as `T` nulgrutte is.
    /// Tink derom dat as `T` nulgrutte is, dit betsjut dat jo *gjin* in `RawVec` krije mei de frege kapasiteit.
    ///
    /// # Panics
    ///
    /// Panics as de frege kapasiteit `isize::MAX` bytes grutter is.
    ///
    /// # Aborts
    ///
    /// Ofbrutsen op OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Lykas `with_capacity`, mar garandeart dat de buffer nul is.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Herstelt in `RawVec` op fan in oanwizer en kapasiteit.
    ///
    /// # Safety
    ///
    /// De `ptr` moat wurde tawiisd (op 'e systeemheap), en mei de opjûne `capacity`.
    /// De `capacity` kin `isize::MAX` net grutter wêze foar grutte soarten.(allinich in soarch op 32-bit-systemen).
    /// ZST vectors kin in kapasiteit hawwe oant `usize::MAX`.
    /// As de `ptr` en `capacity` fan in `RawVec` komme, dan is dit garandearre.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs binne stom.Gean nei:
    // - 8 as de elemintgrutte 1 is, om't alle heupferdelers wierskynlik in fersyk fan minder dan 8 byten oant teminsten 8 bytes ôfrinne.
    //
    // - 4 as eleminten matig binne (<=1 KiB).
    // - 1 oars, om foar te kommen dat jo te folle romte fergrieme foar heul koarte Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Lykas `new`, mar parameterisearre oer de kar fan allocator foar de werom `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` betsjut "unallocated".nulgrutte typen wurde negeare.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Lykas `with_capacity`, mar parameterisearre oer de kar fan allocator foar de werom `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Lykas `with_capacity_zeroed`, mar parameterisearre oer de kar fan allocator foar de werom `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konverteart in `Box<[T]>` yn in `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konverteart de folsleine buffer yn `Box<[MaybeUninit<T>]>` mei de oantsjutte `len`.
    ///
    /// Tink derom dat dit alle `cap`-wizigingen dy't mooglik binne útfierd, werstelle.(Sjoch beskriuwing fan type foar details.)
    ///
    /// # Safety
    ///
    /// * `len` moat grutter wêze as of gelyk oan de lêst frege kapasiteit, en
    /// * `len` moat minder wêze as of gelyk oan `self.capacity()`.
    ///
    /// Tink derom dat de frege kapasiteit en `self.capacity()` ferskille kinne, om't in allocator in grutter ûnthâldblok koe oerskriuwe en werombringe dan frege.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-kontrôle de helte fan 'e feiligenseasken (wy kinne de oare helte net kontrolearje).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Wy foarkomme `unwrap_or_else` hjir, om't it it bedrach fan oanmakke LLVM IR opbloeit.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Herstelt in `RawVec` op fan in oanwizer, kapasiteit en allocator.
    ///
    /// # Safety
    ///
    /// De `ptr` moat wurde tawiisd (fia de opjûne allocator `alloc`), en mei de opjûne `capacity`.
    /// De `capacity` kin `isize::MAX` net grutter wêze foar grutte soarten.
    /// (allinich in soarch op 32-bit-systemen).
    /// ZST vectors kin in kapasiteit hawwe oant `usize::MAX`.
    /// As de `ptr` en `capacity` komme fan in `RawVec` makke fia `alloc`, dan is dit garandearre.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Krijt in rauwe oanwizer nei it begjin fan 'e tawizing.
    /// Tink derom dat dit `Unique::dangling()` is as `capacity == 0` as `T` nulgrutte is.
    /// Yn it eardere gefal moatte jo foarsichtich wêze.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Kriget de kapasiteit fan 'e tawizing.
    ///
    /// Dit sil altyd `usize::MAX` wêze as `T` nulgrutte is.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Jout in dielde ferwizing nei de allocator dy't dizze `RawVec` stipet.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Wy hawwe in tawiisd stik geheugen, sadat wy runtime-kontrôles kinne omgean om ús hjoeddeistige opmaak te krijen.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Soarget derfoar dat de buffer teminsten genôch romte befettet om `len + additional`-eleminten te hâlden.
    /// As it net genôch kapasiteit hat, sil genôch romte opnij pleatse plus noflike slimme romte om amortisearre *O*(1) gedrach te krijen.
    ///
    /// Sil dit gedrach beheine as it him ûnnedich feroarsaakje sil oan panic.
    ///
    /// As `len` `self.capacity()` grutter is, kin dit miskien net de oanfrege romte tawize.
    /// Dit is net echt ûnfeilich, mar de ûnfeilige koade * dy't jo skriuwe dy't fertrout op it gedrach fan dizze funksje kin brekke.
    ///
    /// Dit is ideaal foar it útfieren fan in bulk-push-operaasje lykas `extend`.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit `isize::MAX` bytes grutter is.
    ///
    /// # Aborts
    ///
    /// Ofbrutsen op OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve soe hawwe ôfbrutsen of yn panyk as de len `isize::MAX` oertrof, dus dit is feilich om no net te kontrolearjen te dwaan.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Itselde as `reserve`, mar komt werom op flaters ynstee fan panyk of ôfbrekke.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Soarget derfoar dat de buffer teminsten genôch romte befettet om `len + additional`-eleminten te hâlden.
    /// As it noch net is, sil de minimale mooglike hoemannichte ûnthâld opnij tawize.
    /// Yn 't algemien sil dit krekt de hoemannichte ûnthâld wêze, mar yn prinsipe is de allocator frij om mear werom te jaan dan wy frege hawwe.
    ///
    ///
    /// As `len` `self.capacity()` grutter is, kin dit miskien net de oanfrege romte tawize.
    /// Dit is net echt ûnfeilich, mar de ûnfeilige koade * dy't jo skriuwe dy't fertrout op it gedrach fan dizze funksje kin brekke.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit `isize::MAX` bytes grutter is.
    ///
    /// # Aborts
    ///
    /// Ofbrutsen op OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Itselde as `reserve_exact`, mar komt werom op flaters ynstee fan panyk of ôfbrekke.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Krimp de tawizing del nei it oantsjutte bedrach.
    /// As it opjûne bedrach 0 is, dan lokeart it eins folslein.
    ///
    /// # Panics
    ///
    /// Panics as it opjûne bedrach *grutter* is dan de hjoeddeistige kapasiteit.
    ///
    /// # Aborts
    ///
    /// Ofbrutsen op OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Jout werom as de buffer groeie moat om de nedige ekstra kapasiteit te ferfoljen.
    /// Benammen brûkt om ynlining reserve-petearen mooglik te meitsjen sûnder `grow` yn te lizzen.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Dizze metoade wurdt normaal in protte kearen instantieare.Dat wy wolle dat it sa lyts mooglik is, kompilaasjetiden ferbetterje.
    // Mar wy wolle ek dat safolle fan har ynhâld statysk berekkenber mooglik is, om de oanmakke koade rapper te meitsjen.
    // Dêrom wurdt dizze metoade mei soarch skreaun, sadat alle koade dy't ôfhinklik is fan `T` deryn is, wylst safolle fan 'e koade dy't net ôfhinklik is fan `T` mooglik is yn funksjes dy't net-generyk binne oer `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dit wurdt garandearre troch de opropkonteksten.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Om't wy in kapasiteit fan `usize::MAX` werombringe as `elem_size` is
            // 0, hjir oankomme betsjuttet needsaaklikerwize dat de `RawVec` te folle is.
            return Err(CapacityOverflow);
        }

        // Neat dat wy echt kinne dwaan oan dizze kontrôles, spitigernôch.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dit garandeart eksponensjele groei.
        // De ferdûbeling kin net oerstreamje om't `cap <= isize::MAX` en it type `cap` `usize` is.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is net-generyk oer `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // De beheiningen foar dizze metoade binne folle itselde as dy op `grow_amortized`, mar dizze metoade wurdt normaal minder faak instantieare, sadat it minder kritysk is.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Om't wy in kapasiteit fan `usize::MAX` werombringe as de type grutte is
            // 0, hjir oankomme betsjuttet needsaaklikerwize dat de `RawVec` te folle is.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is net-generyk oer `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Dizze funksje is bûten `RawVec` om kompilaasjetiden te minimalisearjen.Sjoch de opmerking hjirboppe `RawVec::grow_amortized` foar details.
// (De `A`-parameter is net wichtich, om't it oantal ferskillende `A`-soarten yn 'e praktyk te sjen is folle lytser dan it oantal `T`-soarten.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kontrolearje hjir foar de flater om de grutte fan `RawVec::grow_*` te minimalisearjen.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // De allocator kontrolearret op gelikens fan ôfstimming
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Befrijt it ûnthâld dat eigendom is fan 'e `RawVec`*sûnder* de ynhâld te besykjen.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Sintrale funksje foar ôfhanneljen fan reservefouten.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Wy moatte it folgjende garandearje:
// * Wy allocearje gjin `> isize::MAX`-byte-grutte objekten.
// * Wy oerstreamje `usize::MAX` net en allocearje eins te min.
//
// Op 64-bit moatte wy gewoan kontrolearje op oerstreaming, om't it besykjen om `> isize::MAX`-bytes te allocearjen wis mislearret.
// Op 32-bit en 16-bit moatte wy hjirfoar in ekstra wacht tafoegje as wy rinne op in platfoarm dat alle 4GB kin brûke yn brûkersromte, bgl. PAE of x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Ien sintrale funksje ferantwurdlik foar rapportaazjefermogen oerstreamt.
// Dit soarget derfoar dat de koadegeneraasje relatearre oan dizze panics minimaal is, om't d'r mar ien lokaasje is dy't panics ynstee fan in bosk yn 'e module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}