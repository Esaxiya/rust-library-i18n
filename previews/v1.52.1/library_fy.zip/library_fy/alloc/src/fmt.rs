//! Utilities foar opmaak en printsjen fan 'String`s.
//!
//! Dizze module befettet de runtime-stipe foar de [`format!`]-syntaksis-útwreiding.
//! Dizze makro wurdt ymplementearre yn 'e kompilearder om oproppen út te stjoeren nei dizze module om arguminten op te meitsjen yn runtime yn snaren.
//!
//! # Usage
//!
//! De [`format!`]-makro is bedoeld om bekend te wêzen foar dyjingen dy't komme fan C's `printf`/`fprintf`-funksjes of Python's `str.format`-funksje.
//!
//! Guon foarbylden fan 'e [`format!`]-útwreiding binne:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" mei foaroansteande nullen
//! ```
//!
//! Fan dizze kinne jo sjen dat it earste argumint in opmaakstring is.It is fereaske troch de gearstaller dat dit in tekenrige is;it kin gjin fariabele wêze dy't ynjûn is (om jildichheidskontrôle út te fieren).
//! De gearstaller sil dan de opmaakstring analysearje en bepale oft de list mei arguminten levere geskikt is om troch te jaan oan dizze opmaakstring.
//!
//! Om de ienige wearde nei in string te konvertearjen, brûk de [`to_string`]-metoade.Dit sil de [`Display`]-opmaak trait brûke.
//!
//! ## Posysjeparameters
//!
//! Elk opmaakargumint kin oantsjutte hokker wearde-argumint it refereart, en as weilitten wurdt oannommen dat it "the next argument" is.
//! Bygelyks, de opmaakstring `{} {} {}` soe trije parameters nimme, en se soene yn deselde folchoarder wurde opmakke as se wurde jûn.
//! De opmaakstring `{2} {1} {0}` soe arguminten lykwols opmeitsje yn omkearde folchoarder.
//!
//! Dingen kinne in bytsje lestich wurde as jo de twa soarten posysjonele spesifikaasjes begjinne te mingjen.De "next argument"-spesifikaasje kin wurde beskôge as in iterator oer it argumint.
//! Elke kear as in "next argument"-spesifikaasje wurdt sjoen, giet de iterator troch.Dit liedt ta gedrach lykas dit:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! De ynterne iterator oer it argumint is net foardere op 'e tiid dat de earste `{}` wurdt sjoen, dus it earste argumint wurdt ôfprinte.Doe't de iterator by it berikken fan de twadde `{}` foarút gie nei it twadde argumint.
//! Yn essinsje hawwe parameters dy't har argumint eksplisyt neame gjin ynfloed op parameters dy't gjin argumint neame yn termen fan posysjonele spesifikaasjes.
//!
//! In opmaakstring is ferplicht om al syn arguminten te brûken, oars is it in kompilearfout.Jo kinne meardere kearen nei itselde argumint ferwize yn 'e opmaakstring.
//!
//! ## Neamde parameters
//!
//! Rust sels hat gjin Python-lykweardich fan neamde parameters foar in funksje, mar de [`format!`]-makro is in syntaksis-útwreiding wêrmei it beneamde parameters brûke kin.
//! Neamde parameters steane oan 'e ein fan' e argumintlist en hawwe de syntaksis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Bygelyks, de folgjende [`format!`]-útdrukkingen brûke allegear neamd argumint:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! It is net jildich om posysjeparameters (dy sûnder nammen) te setten nei arguminten dy't nammen hawwe.Lykas by posysjeparameters is it net jildich om neamde parameters op te leverjen dy't net brûkt wurde troch de opmaakstring.
//!
//! # Opmaakparameters
//!
//! Elk argumint dat wurdt opmakke kin wurde transformeare troch in oantal opmaakparameters (oerienkomt mei `format_spec` yn [the syntax](#syntax)). Dizze parameters hawwe ynfloed op de tekenrepresintaasje fan wat wurdt opmakke.
//!
//! ## Width
//!
//! ```
//! // Al dizze printsje "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dit is in parameter foar de "minimum width" dy't it formaat moat opnimme.
//! As de tekenrige fan 'e wearde net safolle karakters ynfollet, dan sil de troch fill/alignment oantsjutte padding wurde brûkt om de fereaske romte yn te nimmen (sjoch hjirûnder).
//!
//! De wearde foar de breedte kin ek wurde levere as in [`usize`] yn 'e list mei parameters troch in postfix `$` ta te heakjen, wat oanjout dat it twadde argumint in [`usize`] is dat de breedte oantsjut.
//!
//! Ferwize nei in argumint mei de dollar-syntaksis hat gjin ynfloed op de "next argument"-teller, dus it is normaal in goed idee om nei arguminten te ferwizen op posysje, of beneamde arguminten te brûken.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! It opsjonele fillkarakter en-ôfstimming wurdt normaal levere yn kombinaasje mei de parameter [`width`](#width).It moat wurde definieare foar `width`, direkt nei de `:`.
//! Dit jout oan dat as de opmakke wearde lytser is dan `width`, der wat ekstra tekens deromhinne wurde printe.
//! Ynfoljen komt yn 'e folgjende farianten foar ferskate opstellingen:
//!
//! * `[fill]<` - it argumint is loftsôf yn `width`-kolommen
//! * `[fill]^` - it argumint is sintraal rjochte yn `width`-kolommen
//! * `[fill]>` - it argumint is rjochtsôf yn `width`-kolommen
//!
//! De standert [fill/alignment](#fillalignment) foar net-numeryk is in spaasje en lofts-rjochte.De standert foar numerike formateurs is ek in romtekarakter, mar mei rjochtsôfstimming.
//! As de `0`-flagge (sjoch hjirûnder) is oantsjutte foar numeryk, dan is it ymplisite fill-karakter `0`.
//!
//! Tink derom dat ôfstimming miskien net troch guon soarten wurdt ymplementearre.Benammen wurdt it algemien net ymplementearre foar de `Debug` trait.
//! In goede manier om te soargjen dat padding wurdt tapast is jo ynput op te meitsjen, dan dizze resultearjende string te padjen om jo útfier te krijen:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hallo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dit binne allegear flaggen dy't it gedrach fan 'e formatter feroarje.
//!
//! * `+` - Dit is bedoeld foar numerike soarten en jout oan dat it teken altyd moat wurde printe.Positive tekens wurde noait standert ôfprinte, en it negative teken wurdt allinich standert printe foar de `Signed` trait.
//! Dizze flagge jout oan dat it juste teken (`+` of `-`) altyd moat wurde ôfprinte.
//! * `-` - Op it stuit net brûkt
//! * `#` - Dizze flagge jout oan dat de "alternate"-foarm fan printsjen moat wurde brûkt.De alternative foarmen binne:
//!     * `#?` - de [`Debug`]-opmaak moai ôfdrukke
//!     * `#x` - foarôfgeand oan it argumint mei in `0x`
//!     * `#X` - foarôfgeand oan it argumint mei in `0x`
//!     * `#b` - foarôfgeand oan it argumint mei in `0b`
//!     * `#o` - foarôfgeand oan it argumint mei in `0o`
//! * `0` - Dit wurdt brûkt om foar heulgetalformaten oan te jaan dat de padding nei `width` beide moatte wurde dien mei in `0`-karakter en ek tekenbewust wêze.
//! In yndieling lykas `{:08}` soe `00000001` opleverje foar it heule getal `1`, wylst itselde formaat `-0000001` foar it heule getal `-1` opleverje soe.
//! Merken dat de negative ferzje ien minder nul hat dan de positive ferzje.
//!         Tink derom dat vullingsnullen altyd wurde pleatst nei it teken (as der is) en foar de sifers.As brûkt tegearre mei de `#`-flagge, jildt in soartgelikense regel: padding-nullen wurde ynfoege nei it foarheaksel, mar foar de sifers.
//!         It foarheaksel is opnommen yn 'e totale breedte.
//!
//! ## Precision
//!
//! Foar net-numerike soarten kin dit wurde beskôge as in "maximum width".
//! As de resultearende tekenrige langer is dan dizze breedte, dan wurdt dizze ôfkapt oant dizze protte karakters en wurdt dizze ôfkoarte wearde útjûn mei juste `fill`, `alignment` en `width` as dizze parameters binne ynsteld.
//!
//! Foar yntegraal typen wurdt dit negeare.
//!
//! Foar typen fan driuwende punten jout dit oan hoefolle sifers nei it desimale punt moatte wurde ôfprinte.
//!
//! D'r binne trije mooglike manieren om de winske `precision` op te jaan:
//!
//! 1. In hiel getal `.N`:
//!
//!    it heule getal `N` sels is de presyzje.
//!
//! 2. In hiel getal as namme folge troch dollarteken `.N$`:
//!
//!    brûk formaat *argumint*`N` (dat moat in `usize` wêze) as de presyzje.
//!
//! 3. In asterisk `.*`:
//!
//!    `.*` betsjut dat dizze `{...}` yn ferbân is mei *twa* formaat yngongen ynstee fan ien: de earste ynfier hat de `usize`-presyzje, en de twadde hâldt de wearde om te printsjen.
//!    Tink derom dat yn dit gefal, as men de opmaakstring `{<arg>:<spec>.*}` brûkt, it `<arg>`-diel ferwiist nei de* wearde * om ôf te drukken, en de `precision` moat komme yn 'e ynput foarôfgeand oan `<arg>`.
//!
//! Bygelyks, de folgjende oproppen drukke allegear itselde ding `Hello x is 0.01000` ôf:
//!
//! ```
//! // Hello {arg 0 ("x")} is {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} is {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} is {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} is {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} is {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} is {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Wylst dizze:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! druk trije wichtige ferskillende dingen ôf:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Yn guon programmearttalen hinget it gedrach fan funksjes foar tekenopmaak ôf fan 'e lokale ynstelling fan it bestjoeringssysteem.
//! De formaatfunksjes levere troch de standertbibleteek fan Rust hawwe gjin konsept fan lokale en sille deselde resultaten op alle systemen produsearje, ûnôfhinklik fan brûkerskonfiguraasje.
//!
//! Bygelyks, de folgjende koade sil `1.5` altyd ôfdrukke, sels as de systeemlokaasje in desimale skieding brûkt dan in punt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! De letterlike karakters `{` en `}` kinne wurde opnommen yn in tekenrige troch itselde karakter foar te gean.Bygelyks, it `{`-karakter is ûntsnapt mei `{{` en it `}`-karakter is ûntsnapt mei `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! As gearfetting kinne jo hjir de folsleine grammatika fine fan formaatstrings.
//! De syntaksis foar de brûkte opmakttaal is ôflaat fan oare talen, dus it moat net te frjemd wêze.Arguminten wurde opmakke mei Python-like syntaksis, wat betsjut dat arguminten wurde omjûn troch `{}` ynstee fan de C-like `%`.
//! De eigentlike grammatika foar de opmaak syntaksis is:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yn 'e boppesteande grammatika kin `text` gjin `'{'`-of `'}'`-tekens befetsje.
//!
//! # Opmaak fan traits
//!
//! As jo freegje dat in argumint wurdt opmakke mei in bepaald type, freegje jo eins dat in argumint oan in bepaalde trait taskreaun wurdt.
//! Hjirmei kinne meardere feitlike typen wurde opmakke fia `{:x}` (lykas [`i8`] as [`isize`]).De hjoeddeiske mapping fan soarten oan traits is:
//!
//! * *neat* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] mei lytse heksadesimale getallen
//! * `X?` ⇒ [`Debug`] mei heksadesimale getallen yn haadletters
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Wat dit betsjuttet is dat elk type argumint dat de [`fmt::Binary`][`Binary`] trait ymplementeart dan kin wurde opmakke mei `{:b}`.Ymplemintaasjes wurde levere foar dizze traits foar in oantal primitive typen ek troch de standertbibleteek.
//!
//! As der gjin formaat wurdt oantsjutte (lykas yn `{}` of `{:6}`), dan is it formaat trait dat brûkt wurdt de [`Display`] trait.
//!
//! As jo in formaat trait foar jo eigen type ymplementearje, moatte jo in metoade fan 'e hantekening ymplementearje:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ús oanpaste type
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jo type wurdt trochjûn as `self` trochferwizing, en dan moat de funksje útfier útstjoere yn 'e `f.buf`-stream.It is oan elke formaat trait-ymplemintaasje om de oanfrege opmaakparameters korrekt oan te hâlden.
//! De wearden fan dizze parameters sille wurde neamd yn 'e fjilden fan' e [`Formatter`] struct.Om hjirmei te helpen leveret de [`Formatter`] struct ek wat helpermetoaden.
//!
//! Derneist is de weromfertsjintwearde fan dizze funksje [`fmt::Result`] dat in type alias is fan [`Resultaat`]`<(),`[`std: : fmt::Flater`] `>`.
//! Ymplemintaasje opmaak moat derfoar soargje dat se flaters ferspriede fan 'e [`Formatter`] (bgl. By it skiljen fan [`write!`]).
//! Se moatte lykwols flaters net falsk werombringe.
//! Dat is, in ymplemintaasje foar opmaak moat en kin allinich in flater weromjaan as de trochjûn [`Formatter`] in flater jout.
//! Dit komt om't, yn tsjinstelling ta wat de funksje-hantekening suggerearje kin, tekenopmaak in ûnfeilbere operaasje is.
//! Dizze funksje jout allinich in resultaat omdat skriuwen nei de ûnderlizzende stream miskien mislearret en it moat in manier leverje om it feit dat in flater is bard werom yn 'e stapel te propagearjen.
//!
//! In foarbyld foar it ymplementearjen fan de opmaak traits soe der útsjen:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // De `f`-wearde ymplementeart de `Write` trait, dat is wat it skriuwt!makro ferwachtet.
//!         // Tink derom dat dizze opmaak de ferskate flaggen negeare om snaren op te meitsjen.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ferskillende traits tastean ferskillende foarmen fan útfier fan in type.
//! // De betsjutting fan dit formaat is om de grutte fan in vector ôf te drukken.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektearje de opmaakflaggen mei de helpermetoade `pad_integral` op it Formatter-objekt.
//!         // Sjoch de metoadedokumintaasje foar details, en de funksje `pad` kin brûkt wurde om snaren te padjen.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` tsjin `fmt::Debug`
//!
//! Dizze twa traits opmaak hawwe ûnderskate doelen:
//!
//! - [`fmt::Display`][`Display`] ymplementaasjes bewearje dat it type altyd trou kin wurde fertsjintwurdige as in UTF-8-tekenrige.It wurdt **net** ferwachte dat alle soarten de [`Display`] trait ymplementearje.
//! - [`fmt::Debug`][`Debug`] ymplementaasjes moatte wurde ymplementeare foar **alle** iepenbiere soarten.
//!   Utfier sil de ynterne steat typysk sa trou mooglik fertsjintwurdigje.
//!   It doel fan 'e [`Debug`] trait is om debuggen fan Rust-koade te fasilitearjen.Yn 'e measte gefallen is it brûken fan `#[derive(Debug)]` genôch en oan te rieden.
//!
//! Guon foarbylden fan 'e útfier fan beide traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Besibbe makro's
//!
//! D'r binne in oantal relatearre makro's yn 'e [`format!`]-famylje.Dejingen dy't op it stuit binne ymplementeare binne:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dit en [`writeln!`] binne twa makro's dy't wurde brûkt om de opmaakstring út te stjoeren nei in opjûne stream.Dit wurdt brûkt om tuskenferdielingen fan formaatstrings te foarkommen en ynstee direkt de útfier te skriuwen.
//! Under de motorkap ropt dizze funksje eins op de [`write_fmt`]-funksje definieare op 'e [`std::io::Write`] trait.
//! Foarbyldgebrûk is:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dit en [`println!`] stjoere har útfier út nei stdout.Krekt as de [`write!`]-makro is it doel fan dizze makro's om tuskenlizzende allocaasjes te foarkommen by it printsjen fan útfier.Foarbyldgebrûk is:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! De [`eprint!`]-en [`eprintln!`]-makro's binne identyk oan respektivelik [`print!`] en [`println!`], útsein as se har útfier útstjoere nei stderr.
//!
//! ### `format_args!`
//!
//! Dit is in nijsgjirrige makro dy't wurdt brûkt om feilich in trochsichtich objekt troch te jaan dat de opmaakstring beskriuwt.Dit objekt fereasket gjin heuptoekenningen om te meitsjen, en it ferwiist allinich ynformaasje oer de stapel.
//! Under de motorkap wurde alle relatearre makro's ynfierd yn termen hjirfan.
//! As earste is wat gebrûk fan foarbylden:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! It resultaat fan 'e [`format_args!`]-makro is in wearde fan it type [`fmt::Arguments`].
//! Dizze struktuer kin dan wurde trochjûn oan 'e [`write`]-en [`format`]-funksjes yn dizze module om de opmaakstring te ferwurkjen.
//! It doel fan dizze makro is om tuskenfoardielen noch fierder te foarkommen by it behanneljen fan snaren foar opmaak.
//!
//! In logboekbibleteek kin bygelyks de standert opmaak-syntaksis brûke, mar it soe dizze struktuer yntern trochjaan oant bepaald is wêr't útfier nei moat.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// De funksje `format` nimt in [`Arguments`]-struktuer en retourneert de resultearde opmakke tekenrige.
///
///
/// It [`Arguments`]-eksimplaar kin makke wurde mei de [`format_args!`]-makro.
///
/// # Examples
///
/// Basis gebrûk:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tink derom dat it brûken fan [`format!`] foarkar wêze kin.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}