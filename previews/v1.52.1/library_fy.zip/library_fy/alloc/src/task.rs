#![stable(feature = "wake_trait", since = "1.51.0")]
//! Soarten en Traits foar wurkjen mei asynchrone taken.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// De ymplemintaasje fan it wekken fan in taak op in útfierder.
///
/// Dizze trait kin brûkt wurde om in [`Waker`] te meitsjen.
/// In útfierder kin in ymplemintaasje fan dizze trait definiearje, en dy brûke om in Waker te konstruearjen om troch te jaan oan de taken dy't wurde útfierd op dy útfierder.
///
/// Dizze trait is in geheugenfeilich en ergonomysk alternatyf foar it bouwen fan in [`RawWaker`].
/// It stipet it mienskiplike útfierdersûntwerp wêryn de gegevens dy't brûkt wurde om in taak wekker te meitsjen wurde opslein yn in [`Arc`].
/// Guon útfierders (foaral dy foar ynbêde systemen) kinne dizze API net brûke, dêrom bestiet [`RawWaker`] as alternatyf foar dy systemen.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// In basale `block_on`-funksje dy't in future nimt en rint oant foltôgjen op 'e hjoeddeistige thread.
///
/// **Note:** Dit foarbyld ferhannelt korrektheid foar ienfâld.
/// Om deadlocks te foarkommen, moatte ymplementaasjes fan produksjegraad ek tuskenoproppen nei `thread::unpark` behannelje, lykas nêst ynroppen.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// In wekker dy't de hjoeddeistige tried wekker makket as er wurdt neamd.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Run a future oant foltôging op 'e hjoeddeistige thread.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin de future sadat it kin wurde frege.
///     let mut fut = Box::pin(fut);
///
///     // Meitsje in nije kontekst dy't trochjûn wurdt oan de future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Rin de future oant foltôgjen.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wekker dizze taak.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Wekker dizze taak sûnder de wekker te konsumearjen.
    ///
    /// As in eksekuteur in goedkeapere manier stipet om te wekkerjen sûnder de waker te konsumearjen, moat dizze metoade oerskriuwe.
    /// Standert klonet it de [`Arc`] en ropt [`wake`] op 'e kloan.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // VEILIGHEID: Dit is feilich, om't raw_waker feilich konstrueart
        // in RawWaker út Arc<W>,
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Dizze priveefunksje foar it konstruearjen fan in RawWaker wurdt brûkt, ynstee fan
// dit ynline yn 'e `From<Arc<W>> for RawWaker`-impl, om derfoar te soargjen dat de feiligens fan `From<Arc<W>> for Waker` net ôfhinget fan' e juste trait-ferstjoering, ynstee neame beide impls dizze funksje direkt en eksplisyt.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ferheegje de referinsjetelling fan 'e bôge om it te klonen.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wekker wurde troch wearde, ferpleatse de Arc nei de Wake::wake-funksje
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wekker wurde troch referinsje, wikkel de wekker yn ManuallyDrop om it te fallen te foarkommen
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Ferlytsje de referinsjetelling fan 'e Arc by drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}