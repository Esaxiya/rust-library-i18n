//! In prioriteitswachtrige ymplementeare mei in binêre heap.
//!
//! Ynstekken en poppen fan it grutste elemint hawwe *O*(log(*n*)) tiidkompleksiteit.
//! Kontrolearje it grutste elemint is *O*(1).In vector konvertearje nei in binêre heap kin op it plak wurde dien, en hat *O*(*n*) kompleksiteit.
//! In binêre heap kin ek wurde konverteare yn in sorteare vector op it plak, wêrtroch it kin wurde brûkt foar in *O*(*n*\*log(* n*)) heapsort yn plak.
//!
//! # Examples
//!
//! Dit is in grutter foarbyld dat [Dijkstra's algorithm][dijkstra] ymplementeart om de [shortest path problem][sssp] op te lossen op in [directed graph][dir_graph].
//!
//! It lit sjen hoe [`BinaryHeap`] te brûken mei oanpaste typen.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // De prioriteitskoer is ôfhinklik fan `Ord`.
//! // Ymplisyt eksplisyt de trait sadat de wachtrige in minheap wurdt ynstee fan in max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Merk op dat wy de bestelling op kosten keare.
//!         // Yn gefal fan in lykspul fergelykje wy posysjes, dizze stap is nedich om ymplementaasjes fan `PartialEq` en `Ord` konsistint te meitsjen.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` moat ek wurde ymplementeare.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Elke knooppunt wurdt fertsjintwurdige as in `usize`, foar in koartere ymplemintaasje.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra's koartste paadalgoritme.
//!
//! // Begjin by `start` en brûk `dist` om de hjoeddeistige koartste ôfstân nei elk knooppunt te folgjen.Dizze ymplemintaasje is net ûnthâld-effisjint, om't it duplikaatknooppels yn 'e wachtrige kin litte.
//! //
//! // It brûkt `usize::MAX` ek as sentinelwearde, foar in ienfâldiger ymplemintaasje.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=hjoeddeistige koartste ôfstân fan `start` nei `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Wy binne by `start`, mei nul kosten
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Undersykje de grins mei legere kosten nodes earst (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // As alternatyf koene wy trochgean mei it finen fan alle koartste paden
//!         if position == goal { return Some(cost); }
//!
//!         // Wichtich om't wy miskien al in bettere manier fûn hawwe
//!         if cost > dist[position] { continue; }
//!
//!         // Foar elke knooppunt kinne wy berikke, sjen as wy in manier kinne fine mei in legere kosten dy't troch dizze knooppunt geane
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // As dat sa is, foegje it ta oan 'e grins en gean troch
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Untspanning, wy hawwe no in bettere manier fûn
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Doel net te berikken
//!     None
//! }
//!
//! fn main() {
//!     // Dit is de rjochte grafyk dy't wy sille brûke.
//!     // De knooppuntnûmers komme oerien mei de ferskillende tastannen, en de gewichten edge symbolisearje de kosten fan it ferpleatsen fan it iene knooppunt nei it oare.
//!     //
//!     // Tink derom dat de rânen ienrjochting binne.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // De grafyk wurdt fertsjintwurdige as in oanhinglist wêr't elke yndeks, oerienkomt mei in knooppuntwearde, in list hat mei útgeande rânen.
//!     // Keas foar syn effisjinsje.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Knooppunt 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Knooppunt 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Knooppunt 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Knooppunt 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Knooppunt 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// In prioriteitswachtrige ymplementeare mei in binêre heap.
///
/// Dit sil in maksimale heap wêze.
///
/// It is in logyske flater foar in item om sa te wizigjen dat de bestelling fan it artikel relatyf oan in oar item, lykas bepaald troch de `Ord` trait, feroaret wylst it yn 'e heap leit.
///
/// Dit is normaal allinich mooglik fia `Cell`, `RefCell`, wrâldwide steat, I/O, as ûnfeilige koade.
/// It gedrach as gefolch fan sa'n logyske flater wurdt net oantsjutte, mar sil net resultearje yn undefined gedrach.
/// Dit kin panics omfetsje, ferkearde resultaten, ôfbrekke, ûnthâldlekken, en net-beëindiging.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Mei typeferliening kinne wy in eksplisite type hantekening weilitte (wat `BinaryHeap<i32>` soe wêze yn dit foarbyld).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Wy kinne peek brûke om nei it folgjende item yn 'e heap te sjen.
/// // Yn dit gefal sitte d'r noch gjin artikels yn, dat wy krije Gjin.
/// assert_eq!(heap.peek(), None);
///
/// // Litte wy wat punten tafoegje ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // No lit peek it wichtichste item yn 'e heap sjen.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Wy kinne de lingte fan in heap kontrolearje.
/// assert_eq!(heap.len(), 3);
///
/// // Wy kinne itearje oer de items yn 'e heap, hoewol se yn willekeurige folchoarder wurde weromjûn.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // As wy yn plak fan dizze skoares popke, moatte se wer yn oarder komme.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Wy kinne de heap wiskje fan oerbleaune items.
/// heap.clear();
///
/// // De heap moat no leech wêze.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Of `std::cmp::Reverse` as in oanpaste `Ord`-ymplemintaasje kin brûkt wurde om `BinaryHeap` in minheap te meitsjen.
/// Dit makket `heap.pop()` de lytste wearde werom yn plak fan de grutste.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Wurden yn `Reverse` ynpakke
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // As wy dizze punten no popke, moatte se weromkomme yn 'e omkearde folchoarder.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Tiidkompleksiteit
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// De wearde foar `push` is in ferwachte kosten;de metoadedokumintaasje jout in mear detaillearre analyze.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktuer ynpakt in feroarbere ferwizing nei it grutste item op in `BinaryHeap`.
///
///
/// Dizze `struct` is makke troch de [`peek_mut`]-metoade op [`BinaryHeap`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // VEILIGHEID: PeekMut wurdt allinich instantieare foar net-lege heapen.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut wurdt allinich instantieare foar net-lege heapen
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut wurdt allinich instantieare foar net-lege heapen
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Ferwideret de peekde wearde fan 'e heap en retourneert dizze.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Makket in lege `BinaryHeap<T>` oan.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Makket in lege `BinaryHeap` oan as maksimale heap.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Makket in lege `BinaryHeap` oan mei in spesifike kapasiteit.
    /// Dit foarlokeart genôch ûnthâld foar `capacity`-eleminten, sadat de `BinaryHeap` net opnij moat wurde tawiist oant it teminsten safolle wearden befettet.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Jout in feroarbere ferwizing nei it grutste item yn 'e binêre heap, of `None` as it leech is.
    ///
    /// Note: As de `PeekMut`-wearde wurdt lekt, kin de heap yn in inkonsekwint steat wêze.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Tiidkompleksiteit
    ///
    /// As it artikel wurdt oanpast, is de minste gefal de tiidkompleksiteit *O*(log(*n*)), oars is it *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Ferwideret it grutste item fan 'e binêre heap en retourneert it, as `None` as it leech is.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Tiidkompleksiteit
    ///
    /// De minste saakkosten fan `pop` op in heap mei *n* eleminten binne *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // VEILIGHEID: !self.is_empty() betsjut dat self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Triuwt in item op 'e binêre heap.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Tiidkompleksiteit
    ///
    /// De ferwachte kosten fan `push`, gemiddeld oer alle mooglike oardering fan 'e yndrukke eleminten, en oer in foldwaande grut oantal triuwe, is *O*(1).
    ///
    /// Dit is de meast betsjuttende kostmetrik as jo eleminten drukke dy't *net* al binne yn elk sorteare patroan.
    ///
    /// De tiidkompleksiteit degradeart as eleminten yn oerwinnend opkommende folchoarder wurde skood.
    /// Yn it minste gefal wurde eleminten yn opkommende sorteare folchoarder skood en de amortisearre kosten per druk is *O*(log(*n*)) tsjin in heap mei *n* eleminten.
    ///
    /// De minste kosten fan in *inkele* oprop nei `push` binne *O*(*n*).It slimste gefal komt foar as kapasiteit is útput en in grutte nedich is.
    /// De feroaringskosten binne amortisearre yn 'e eardere sifers.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // VEILIGHEID: Sûnt wy in nij item skowe, betsjuttet it dat
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Ferbrûkt de `BinaryHeap` en retourneert in vector yn sorteare (ascending)-folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // VEILIGHEID: `end` giet fan `self.len() - 1` nei 1 (beide ynbegrepen),
            //  dat it is altyd in jildige yndeks om tagong te krijen.
            //  It is feilich om tagong te krijen ta yndeks 0 (dus `ptr`), om't
            //  1 <=ein <self.len(), wat self.len()>=2 betsjut.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // VEILIGHEID: `end` giet fan `self.len() - 1` nei 1 (beide ynbegrepen), sadat:
            //  0 <1 <=ein <= self.len(), 1 <self.len() Wat betsjut 0 <ein en ein <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // De ymplementaasjes fan sift_up en sift_down brûke ûnfeilige blokken om in elemint út 'e vector te ferpleatsen (efterlitte in gat), ferskowe lâns de oaren en ferpleatse it fuorthelle elemint werom yn' e vector op 'e definitive lokaasje fan it gat.
    //
    // It `Hole`-type wurdt brûkt om dit te fertsjintwurdigjen, en soargje derfoar dat it gat wurdt foltôge oan 'e ein fan' e omfang, sels op panic.
    // Mei in gat fermindert de konstante faktor yn ferliking mei swaps brûke, wêrby't twa kear safolle bewegingen omfetsje.
    //
    //
    //
    //

    /// # Safety
    ///
    /// De beller moat dy `pos < self.len()` garandearje.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Nim de wearde by `pos` út en meitsje in gat.
        // VEILIGHEID: De beller garandeart dat pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // VEILIGHEID: hole.pos()> start>=0, wat hole.pos()> 0 betsjut
            //  en sa kin hole.pos(), 1 net ûnderstreamje.
            //  Dit garandeart dat âlder <hole.pos(), sadat it in jildige yndeks is en ek!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // VEILIGHEID: Itselde as hjirboppe
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Nim in elemint by `pos` en ferpleatse it by de heap del, wylst har bern grutter binne.
    ///
    ///
    /// # Safety
    ///
    /// De beller moat dy `pos < end <= self.len()` garandearje.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // VEILIGHEID: De beller garandeart dat pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: bern==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // fergelykje mei de grutste fan de twa bern FEILIGHEID: bern <ein, 1 <self.len() en bern + 1 <ein <= self.len(), dat se binne jildige yndeksen.
            //
            //  bern==2 *hole.pos() + 1!= hole.pos() en bern + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 of 2* hole.pos() + 2 kin oerstreamje as T in ZST is
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // as wy al yn oarder binne, stopje dan.
            // VEILIGHEID: bern is no it âlde bern as it âlde bern + 1
            //  Wy hawwe al bewiisd dat beide <self.len() en!= hole.pos() binne
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // VEILIGHEID: itselde as hjirboppe.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // VEILIGHEID: &&koartsluting, dat betsjut dat yn 'e
        //  twadde betingst is it al wier dat bern==ein, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // VEILIGHEID: bern is al bewiisd in jildige yndeks te wêzen en
            //  bern==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// De beller moat dy `pos < self.len()` garandearje.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // VEILIGHEID: pos <len wurdt garandearre troch de beller en
        //  fansels len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Nim in elemint by `pos` en ferpleatse it heulendal de heuvel del, sif it dan nei syn posysje.
    ///
    ///
    /// Note: Dit is rapper as it bekend is dat it elemint grut is/tichter by de boaiem moat wêze.
    ///
    /// # Safety
    ///
    /// De beller moat dy `pos < self.len()` garandearje.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // VEILIGHEID: De beller garandeart dat pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: bern==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // VEILIGHEID: bern <ein, 1 <self.len() en
            //  bern + 1 <ein <= self.len(), dat se binne jildige yndeksen.
            //  bern==2 *hole.pos() + 1!= hole.pos() en bern + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 of 2* hole.pos() + 2 kin oerstreamje as T in ZST is
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // VEILIGHEID: Itselde as hjirboppe
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // VEILIGHEID: bern==ein, 1 <self.len(), dus it is in jildige yndeks
            //  en bern==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // VEILIGHEID: pos is de posysje yn it gat en wie al bewiisd
        //  in jildige yndeks te wêzen.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // VEILIGHEID: n begjint fan self.len()/2 en giet omleech nei 0.
            //  It iennige gefal wannear! (N <self.len()) is as self.len() ==0, mar it is útsletten troch de loop-betingst.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Ferpleatst alle eleminten fan `other` nei `self`, wêrtroch `other` leech is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` nimt O(len1 + len2)-operaasjes en sawat 2 *(len1 + len2) fergelikingen yn 't slimste gefal, wylst `extend` O(len2* log(len1))-operaasjes nimt en sawat 1 *len2* log_2(len1) fergelikingen yn' t slimste gefal, útgeande fan len1>= len2.
        // Foar gruttere heapen folget it crossoverpunt dizze redenaasje net mear en waard empirysk bepaald.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Jout in iterator werom dy't eleminten yn heap folchoarder hellet.
    /// De ophelle eleminten wurde fuortsmiten fan 'e orizjinele heap.
    /// De oerbleaune eleminten sille wurde ferwidere by drop yn heapfolchoarder.
    ///
    /// Note:
    /// * `.drain_sorted()` is *O*(*n*\*log(* n*)); folle stadiger dan `.drain()`.
    ///   Jo moatte de lêste foar de measte gefallen brûke.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // smyt alle eleminten yn heapoarder op
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Behâldt allinich de eleminten oantsjutte troch it predikaat.
    ///
    /// Mei oare wurden, ferwiderje alle eleminten `e` sadat `f(&e)` `false` weromkomt.
    /// De eleminten wurde besocht yn net-sorteerde (en net oantsjutte) folchoarder.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // allinich even nûmers hâlde
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Jout in iterator dy't alle wearden besiket yn 'e ûnderlizzende vector, yn willekeurige folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Printsje 1, 2, 3, 4 yn willekeurige folchoarder
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Jout in iterator werom dy't eleminten yn heap folchoarder hellet.
    /// Dizze metoade ferbrûkt de orizjinele heap.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Jout it grutste item yn 'e binêre heap werom, as `None` as it leech is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Tiidkompleksiteit
    ///
    /// Kosten binne *O*(1) yn it slimste gefal.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Jout it oantal eleminten werom dat de binaire heap kin befetsje sûnder opnij tawiizgjen.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserveart de minimale kapasiteit foar presys `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `BinaryHeap`.
    /// Docht neat as de kapasiteit al genôch is.
    ///
    /// Tink derom dat de allocator de kolleksje mear romte kin jaan dan hy freget.
    /// Dêrom kin net op ferteld wurde dat se krekt minimal binne.
    /// Foarkar [`reserve`] as ynstekken fan future wurde ferwachte.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan `usize`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserveart kapasiteit foar teminsten `additional` mear eleminten dy't wurde ynfoege yn 'e `BinaryHeap`.
    /// De kolleksje kin mear romte reservearje om faak weryndielingen te foarkommen.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan `usize`.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Smyt safolle mooglik ekstra kapasiteit ôf.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Smyt kapasiteit mei in legere grins ôf.
    ///
    /// De kapasiteit sil op syn minst like grut bliuwe as sawol de lingte as de levere wearde.
    ///
    ///
    /// As de hjoeddeistige kapasiteit minder is dan de legere limyt, is dit in no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Ferbrûkt de `BinaryHeap` en retourneert de ûnderlizzende vector yn willekeurige folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Sil yn guon folchoarder ôfdrukke
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Jout de lingte fan 'e binêre heap werom.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kontroleart as de binêre heap leech is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Wisket de binaire heap werom, jout in iterator werom oer de fuorthelle eleminten.
    ///
    /// De eleminten wurde yn willekeurige folchoarder ferwidere.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Smyt alle items út 'e binêre heap.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Gat fertsjintwurdiget in gat yn in stik ie, in yndeks sûnder jildige wearde (om't it waard ferpleatst fan of duplisearre).
///
/// Yn drop sil `Hole` it stik herstelle troch de gatposysje yn te foljen mei de wearde dy't oarspronklik waard fuorthelle.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Meitsje in nije `Hole` by yndeks `pos`.
    ///
    /// Unfeilich omdat pos binnen it gegevensstik moat wêze.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos moat binnen it plak wêze
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Jout in ferwizing nei it fuorthelle elemint.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Jout in ferwizing nei it elemint by `index`.
    ///
    /// Unfeilich omdat de yndeks binnen de gegevensplaat moat wêze en net gelyk is oan pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Ferpleats gat nei nije lokaasje
    ///
    /// Unfeilich omdat de yndeks binnen de gegevensplaat moat wêze en net gelyk is oan pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // folje it gat wer
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// In iterator oer de eleminten fan in `BinaryHeap`.
///
/// Dizze `struct` is makke troch [`BinaryHeap::iter()`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Fuortsmite yn it foardiel fan `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// In besittende iterator oer de eleminten fan in `BinaryHeap`.
///
/// Dizze `struct` is makke troch [`BinaryHeap::into_iter()`] (levere troch de `IntoIterator` trait).
/// Sjoch de dokumintaasje foar mear.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// In drainerende iterator oer de eleminten fan in `BinaryHeap`.
///
/// Dizze `struct` is makke troch [`BinaryHeap::drain()`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// In drainerende iterator oer de eleminten fan in `BinaryHeap`.
///
/// Dizze `struct` is makke troch [`BinaryHeap::drain_sorted()`].
/// Sjoch de dokumintaasje foar mear.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Ferwideret heapeleminten yn heap folchoarder.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Konverteart in `Vec<T>` yn in `BinaryHeap<T>`.
    ///
    /// Dizze konverzje bart op it plak, en hat *O*(*n*) tiidkompleksiteit.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Konverteart in `BinaryHeap<T>` yn in `Vec<T>`.
    ///
    /// Dizze konverzje fereasket gjin gegevensbeweging as tawizing, en hat konstante tiidkompleksiteit.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Makket in konsumearende iterator oan, dat is ien dy't elke wearde yn willekeurige folchoarder út 'e binêre heap beweecht.
    /// De binêre heap kin net brûkt wurde nei't dit neamd is.
    ///
    /// # Examples
    ///
    /// Basis gebrûk:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Printsje 1, 2, 3, 4 yn willekeurige folchoarder
    /// for x in heap.into_iter() {
    ///     // x hat type i32, net &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}