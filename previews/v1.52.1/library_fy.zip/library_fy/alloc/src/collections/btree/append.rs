use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Foeget alle kaai-weardepearen ta út 'e feriening fan twa opkommende iterators, en ûnderweis in `length`-fariabele oan.Dat lêste makket it makliker foar de beller om in lek te foarkommen as in dripbehearder yn panyk komt.
    ///
    /// As beide iterators deselde kaai produsearje, falt dizze metoade it pear fan 'e linker iterator en foeget it pear fan' e rjochter iterator oan.
    ///
    /// As jo wolle dat de beam yn in strang opkommende folchoarder komt, lykas foar in `BTreeMap`, moatte beide iterators kaaien produsearje yn strang opkommende folchoarder, elk grutter dan alle toetsen yn 'e beam, ynklusyf alle kaaien dy't al yn' e beam binne by yngong.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Wy meitsje ús taret om `left` en `right` te fusearjen yn in sorteare folchoarder yn lineêre tiid.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Underwilens bouwe wy in line fan 'e sorteare folchoarder yn lineêre tiid.
        self.bulk_push(iter, length)
    }

    /// Triuwt alle kaai-weardepearen nei it ein fan 'e beam, en ferheget ûnderweis in `length`-fariabele.
    /// Dat lêste makket it makliker foar de beller om in lek te foarkommen as de iterator yn panyk rint.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterearje troch alle kaai-weardepearen, en druk se yn knooppunten op it juste nivo.
        for (key, value) in iter {
            // Besykje toetswearde-pear yn 'e hjoeddeiske blêdknooppunt te triuwen.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Gjin romte mear, gean omheech en druk der hinne.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // In knooppunt fûn mei romte oer, druk hjir.
                                open_node = parent;
                                break;
                            } else {
                                // Gean wer op.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Wy steane boppe, meitsje in nije rootknooppunt en triuwe derhinne.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Druk op toetswearde-pear en nij rjochtsûnderbeam.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gean wer nei it rjochtsste blêd.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Steiger lingte elke iteraasje, om derfoar te soargjen dat de kaart de tafoegde eleminten sakket, sels as it iterator foarút giet.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// In iterator foar it gearfoegjen fan twa sorteare sekwinsjes yn ien
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// As twa toetsen gelyk binne, retourneert it kaai-weardepaar fan 'e juste boarne.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}