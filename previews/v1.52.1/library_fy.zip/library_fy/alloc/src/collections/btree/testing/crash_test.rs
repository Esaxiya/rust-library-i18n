use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// In blaudruk foar crash-test dummy-eksemplaren dy't bepaalde barrens kontrolearje.
/// Guon eksimplaren kinne op in stuit konfigureare wurde op panic.
/// Eveneminten binne `clone`, `drop` as in anonime `query`.
///
/// Crash test dummies wurde identifisearre en oardere troch in id, sadat se kinne wurde brûkt as kaaien yn in BTreeMap.
/// De ymplemintaasje mei opsetsin brûkt fertrout net op alles dat is definieare yn 'e crate, útsein de `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Makket in dummy-ûntwerp foar crashtest.De `id` bepaalt oarder en gelikensens fan gefallen.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Makket in eksimplaar oan fan in crashtestdummy dy't registreart hokker barrens it ûnderfynt en eventueel panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Jout werom hoefolle kearen gefallen fan 'e dummy binne kloneare.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Jout werom hoefolle kearen gefallen fan 'e dummy binne fallen.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Jout werom hoefolle kearen eksimplaren fan 'e dummy har `query`-lid hawwe oproppen.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Guon anonime fraach, it resultaat dêrfan is al jûn.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}