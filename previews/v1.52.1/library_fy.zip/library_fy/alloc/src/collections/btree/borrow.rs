use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelle in werberte fan wat unike referinsjes, as jo wite dat de werberte en al syn neikommelingen (dus alle oanwizings en referinsjes derút ûntliend binne) op in stuit net mear sille wurde brûkt, wêrnei't jo de orizjinele unike referinsje wer wolle brûke ,
///
///
/// De lienkontrôler behannelt meast dizze stapeling lieningen foar jo, mar guon kontrôlestrommen dy't dit stapeljen realisearje binne te yngewikkeld foar de gearstaller om te folgjen.
/// In `DormantMutRef` lit jo sels lieningen kontrolearje, wylst jo de steapele aard noch útdrukke, en de rauwe oanwizerkoade ynkapselje dy't nedich is om dit te dwaan sûnder undefined gedrach.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Meitsje in unike liening, en opnij belje.
    /// Foar de gearstaller is it libben fan 'e nije referinsje itselde as it libben fan' e orizjinele referinsje, mar jo promise om it foar in koartere perioade te brûken.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // VEILIGHEID: wy hâlde de liening troch 'a fia `_marker`, en wy bleatstelle
        // allinich dizze referinsje, dus it is unyk.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Kear werom nei de unike liening dy't earst waard fongen.
    ///
    /// # Safety
    ///
    /// De reborrow moat beëinige wêze, dat wol sizze, de referinsje weromjûn troch `new` en alle oanwizings en referinsjes dy't derút binne ûntstien, meie net mear brûkt wurde.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // VEILIGHEID: ús eigen feiligensbetingsten betsjutte dat dizze referinsje wer unyk is.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;