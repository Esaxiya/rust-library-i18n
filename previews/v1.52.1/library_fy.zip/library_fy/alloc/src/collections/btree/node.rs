// Dit is in besykjen ta in ymplemintaasje nei it ideaal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Om't Rust eins gjin ôfhinklike soarten en polymorfe rekursje hat, meitsje wy it mei in protte ûnfeiligens.
//

// In wichtich doel fan dizze module is om kompleksiteit te foarkommen troch de beam te behanneljen as in generike (as frjemd foarmige) kontener en it omgean mei de measte B-Tree-invarianten te foarkommen.
//
// As sadanich kin dizze module net skele oft de yngongen binne sorteare, hokker knooppunten ûnderfol kinne wêze, of sels wat ûnderfol betsjuttet.Wy fertrouwe lykwols op in pear invarianten:
//
// - Beammen moatte unifoarm depth/height hawwe.Dit betsjut dat elk paad nei in blêd fan in bepaald knooppunt presys deselde lingte hat.
// - In knooppunt fan lingte `n` hat `n`-kaaien, `n`-wearden, en `n + 1`-rânen.
//   Dit hâldt yn dat sels in lege node teminsten ien edge hat.
//   Foar in blêdknoop betsjuttet "having an edge" allinich dat wy in posysje yn 'e knooppunt kinne identifisearje, om't blêdrânen leech binne en gjin gegevensfertsjintwurdiging nedich binne.
// Yn in ynterne node identifiseart in edge beide in posysje en befettet in oanwizer nei in berneknoop.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// De ûnderlizzende foarstelling fan blêdknopen en in diel fan 'e foarstelling fan ynterne knopen.
struct LeafNode<K, V> {
    /// Wy wolle kovariant wêze yn `K` en `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// De yndeks fan dizze knooppunt yn 'e `edges`-array fan it âlder knooppunt.
    /// `*node.parent.edges[node.parent_idx]` moat itselde wêze as `node`.
    /// Dit wurdt allinich garandearre dat inisjalisearre wurdt as `parent` net-nul is.
    parent_idx: MaybeUninit<u16>,

    /// It oantal kaaien en wearden dat dizze knooppunt bewarret.
    len: u16,

    /// De arrays dy't de werklike gegevens fan it knooppunt bewarje.
    /// Allinich de earste `len`-eleminten fan elke array binne inisjalisearre en jildich.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inisjaliseart in nije `LeafNode` te plak.
    unsafe fn init(this: *mut Self) {
        // As algemien belied litte wy fjilden uninitialisearre litte as se kinne, om't dit yn Valgrind sawol wat flugger as makliker moatte wurde folge.
        //
        unsafe {
            // parent_idx, toetsen en vals binne allegear MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Makket in nije doaze `LeafNode` oan.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// De ûnderlizzende fertsjintwurdiging fan ynterne knooppunten.Lykas by 'LeafNode`s, moatte dizze wurde ferburgen efter' BoxedNode`s om foarkommen fan net-inisjalisearre toetsen en wearden te foarkommen.
/// Elke oanwizer nei in `InternalNode` kin direkt nei in oanwizer nei it ûnderlizzende `LeafNode`-diel fan 'e knooppunt wurde getten, wêrtroch koade generyk kin hannelje op blêd-en ynterne knooppunten sûnder sels te kontrolearjen op hokker fan' e twa in oanwizer wiist.
///
/// Dizze eigenskip is ynskeakele troch it brûken fan `repr(C)`.
///
#[repr(C)]
// gdb_providers.py brûkt dizze type namme foar yntrospeksje.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// De oanwizings foar de bern fan dizze knooppunt.
    /// `len + 1` hjirfan wurde as inisjalisearre en jildich beskôge, útsein dat tichtby it ein, wylst de beam wurdt hâlden troch liensoart `Dying`, guon fan dizze oanwizings hingje.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Makket in nije doaze `InternalNode` oan.
    ///
    /// # Safety
    /// In invariant fan ynterne knooppunten is dat se teminsten ien initialisearre en jildich edge hawwe.
    /// Dizze funksje stelt sa'n edge net yn.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Wy hoege de gegevens allinich te initialisearjen;de rânen binne MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// In behearde, net-nul oanwizer nei in knooppunt.Dit is of in oantsjutte oanwizer nei `LeafNode<K, V>` as in oanwizer oanwizer nei `InternalNode<K, V>`.
///
/// `BoxedNode` befettet lykwols gjin ynformaasje oer hokker fan 'e twa soarten knooppunten it eins befettet, en, foar in part troch dit gebrek oan ynformaasje, is gjin apart type en hat gjin destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// De woartelknooppunt fan in eigen beam.
///
/// Tink derom dat dit gjin destruktor hat, en manuell moat wurde skjinmakke.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Jout in nije beam dy't eigendom is, mei in eigen rootknooppunt dat earst leech is.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` moat net nul wêze.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Untlient mutabel it eigendom root-knooppunt.
    /// Oars as `reborrow_mut` is dit feilich omdat de weromwearde net kin wurde brûkt om de woartel te ferneatigjen, en d'r kinne gjin oare ferwizings nei de beam wêze.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// In bytsje mutabel lient de eigen rootknooppunt.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unomkearber giet oer nei in referinsje dy't traversal mooglik makket en destruktive metoaden biedt en net folle oars.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Foeget in nije ynterne node ta mei ien edge dy't wiist op it foarige rootknooppunt, meitsje dat nije knooppunt de rootknooppunt, en retourneer it.
    /// Dit fergruttet de hichte mei 1 en is it tsjinoerstelde fan `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, behalven dat wy no krekt fergetten binne dat wy no yntern binne:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ferwideret de ynterne rootknooppunt, mei syn earste bern as nije rootknooppunt.
    /// Om't it allinich bedoeld is om te wurde neamd as it rootknooppunt mar ien bern hat, wurdt gjin opromjen dien op ien fan 'e toetsen, wearden en oare bern.
    ///
    /// Dit ferleget de hichte mei 1 en is it tsjinoerstelde fan `push_internal_level`.
    ///
    /// Fereasket eksklusive tagong ta it `Root`-objekt, mar net ta de rootknooppunt;
    /// it sil oare hannelingen as referinsjes nei it rootknooppunt net unjildich meitsje.
    ///
    /// Panics as d'r gjin yntern nivo is, dus as de rootknooppunt in blêd is.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // VEILIGHEID: wy bewearden ynterne te wêzen.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // VEILIGHEID: wy hawwe `self` eksklusyf liend en syn lienstype is eksklusyf.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // VEILIGHEID: de earste edge wurdt altyd inisjalisearre.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` is altyd kovariant yn `K` en `V`, sels as de `BorrowType` `Mut` is.
// Dit is technysk ferkeard, mar kin net resultearje yn ûnfeiligens troch ynterne gebrûk fan `NodeRef`, om't wy folslein generyk bliuwe oer `K` en `V`.
//
// As in iepenbier type `NodeRef` ynpakt, soargje der lykwols foar dat it de juste fariaasje hat.
//
/// In ferwizing nei in knooppunt.
///
/// Dit type hat in oantal parameters dy't kontrolearje hoe't it wurket:
/// - `BorrowType`: In dummy-type dat it soarte lien beskriuwt en in libben lang draacht.
///    - As dit `Immut<'a>` is, docht de `NodeRef` sawat as `&'a Node`.
///    - As dit `ValMut<'a>` is, docht de `NodeRef` sawat as `&'a Node` mei respekt foar kaaien en beamstruktuer, mar lit ek in protte feroarbere referinsjes nei wearden yn 'e beam tegearre bestean.
///    - As dit `Mut<'a>` is, docht de `NodeRef` sawat as `&'a mut Node`, hoewol ynfoegingsmetoaden tastean dat in feroarbere oanwizer nei in wearde kin bestean.
///    - As dit `Owned` is, hannelet de `NodeRef` sawat as `Box<Node>`, mar hat gjin destruktor, en moat de hân wurde skjinmakke.
///    - As dit `Dying` is, hannelet de `NodeRef` noch sawat as `Box<Node>`, mar hat metoaden om de beam bytsje foar bytsje te ferneatigjen, en gewoane metoaden, hoewol net markearre as ûnfeilich om te skiljen, kinne UB oproppe as se ferkeard wurde neamd.
///
///   Om't elke `NodeRef` troch de beam navigearje kin, jildt `BorrowType` effektyf foar de heule beam, net allinich foar de knooppunt sels.
/// - `K` en `V`: Dit binne de soarten kaaien en wearden opslein yn 'e knooppunten.
/// - `Type`: Dit kin `Leaf`, `Internal`, of `LeafOrInternal` wêze.
/// As dit `Leaf` is, wiist de `NodeRef` nei in blêdknooppunt, as dit `Internal` is, wiist de `NodeRef` nei in ynterne knooppunt, en as dit `LeafOrInternal` is, kin de `NodeRef` wize op elk type knooppunt.
///   `Type` wurdt `NodeType` neamd as brûkt wurdt bûten `NodeRef`.
///
/// Sawol `BorrowType` as `NodeType` beheine hokker metoaden wy ymplementearje, om statyske type feiligens te brûken.D'r binne beheiningen yn 'e manier wêrop wy sokke beheiningen kinne tapasse:
/// - Foar elke type parameter kinne wy allinich in metoade definieare as generyk as foar ien bepaald type.
/// Wy kinne bygelyks gjin metoade lykas `into_kv` generyk definiearje foar alle `BorrowType`, of ien kear foar alle soarten dy't in libben lang drage, om't wy wolle dat it `&'a`-referinsjes werombringt.
///   Dêrom definiearje wy it allinich foar it minste machtige type `Immut<'a>`.
/// - Wy kinne gjin ymplisite twang krije fan sizze `Mut<'a>` nei `Immut<'a>`.
///   Dêrom moatte wy `reborrow` eksplisyt skilje op in krêftiger `NodeRef` om in metoade lykas `into_kv` te berikken.
///
/// Alle metoaden op `NodeRef` dy't in soart referinsje werombringe, of:
/// - Nim `self` op wearde, en retourneer it libben dat `BorrowType` draacht.
///   Somtiden, om sa'n metoade op te roppen, moatte wy `reborrow_mut` skilje.
/// - Nim `self` as referinsje, en (implicitly) jout it referinsjelibben werom, ynstee fan it libben dat wurdt droegen troch `BorrowType`.
/// Op dy manier garandeart de lienkontrole dat de `NodeRef` lien bliuwt salang't de weromferwizende referinsje wurdt brûkt.
///   De metoaden dy't ynfoegje stypje bûgje dizze regel troch in rauwe oanwizer werom te jaan, dus in referinsje sûnder ienich libben.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// It oantal nivo's dat it knooppunt en it nivo fan 'e blêden apart binne, in konstante fan' e knooppunt dy't net folslein kin wurde beskreaun troch `Type`, en dat it knooppunt sels net opslaat.
    /// Wy hoege allinich de hichte fan 'e rootknooppunt te bewarjen en de hichte fan elke oare knooppunt derút te heljen.
    /// Moat nul wêze as `Type` `Leaf` is en net-nul as `Type` `Internal` is.
    ///
    ///
    height: usize,
    /// De oanwizer nei it blêd of ynterne knooppunt.
    /// De definysje fan `InternalNode` soarget derfoar dat de oanwizer op ien of oare manier jildich is.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pak in knooppuntreferinsje út dy't ynpakt is as `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Bleatstelt de gegevens fan in ynterne node.
    ///
    /// Jout in rauwe ptr om foar te kommen dat oare ferwizings nei dizze knooppunt ûnjildich wurde.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // VEILIGHEID: it statyske knooppuntype is `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leint eksklusive tagong ta de gegevens fan in ynterne node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Fynt de lingte fan it knooppunt.Dit is it oantal kaaien as wearden.
    /// It oantal rânen is `len() + 1`.
    /// Tink derom dat, nettsjinsteande feilich, it skiljen fan dizze funksje it sydeffekt kin hawwe fan unjildige ferwizings dy't ûnfeilige koade hat oanmakke.
    ///
    pub fn len(&self) -> usize {
        // Wichtich binne wy hjir allinich tagong ta it `len`-fjild.
        // As BorrowType marker::ValMut is, kinne d'r opfallende mutabele ferwizings wêze nei wearden dy't wy net unjildich moatte.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Jout it oantal nivo's werom dat de knooppunt en de blêden apart binne.
    /// Nulhichte betsjut dat de knooppunt sels in blêd is.
    /// As jo beammen ôfbylde mei de woartel boppe-oan, dan seit it getal op hokker hichte it knooppunt ferskynt.
    /// As jo beammen mei blêden boppeop ôfbylde, seit it getal hoe heech de beam boppe de knoop útstekt.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Nim tydlik in oare, ûnferoarlike ferwizing nei itselde knooppunt út.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bleatstelt it blêddiel fan elk blêd of ynterne knooppunt.
    ///
    /// Jout in rauwe ptr om foar te kommen dat oare ferwizings nei dizze knooppunt ûnjildich wurde.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // It knooppunt moat jildich wêze foar teminsten it LeafNode-diel.
        // Dit is gjin referinsje yn it NodeRef-type, om't wy net witte as it unyk of dield wêze moat.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Fynt de âlder fan it hjoeddeistige knooppunt.
    /// Jout `Ok(handle)` werom as it hjoeddeistige knooppunt eins in âlder hat, wêr't `handle` wiist op 'e edge fan' e âlder dy't wiist nei it hjoeddeiske knooppunt.
    ///
    /// Jout `Err(self)` werom as it hjoeddeistige knooppunt gjin âlder hat, en jout de orizjinele `NodeRef` werom.
    ///
    /// De metoadenamme giet derfan út dat jo beammen ôfbylde mei de rootknooppunt boppe.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` moatte beide, nei sukses, neat dwaan.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Wy moatte rauwe oanwizings brûke foar knooppunten, om't, as BorrowType marker::ValMut is, der miskien útsûnderlike feroarbere ferwizingen binne nei wearden dy't wy net unjildich moatte.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Tink derom dat `self` net frij moat wêze.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Tink derom dat `self` net frij moat wêze.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Bleatstelt it blêddiel fan elk blêd of ynterne knooppunt yn in ûnferoarlike beam.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // VEILIGHEID: d'r kinne gjin feroarbere referinsjes wêze yn dizze beam lien as `Immut`.
        unsafe { &*ptr }
    }

    /// Leint in werjefte nei de kaaien dy't yn it knooppunt binne opslein.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Fergelykber mei `ascend`, krijt in referinsje nei it âlder knooppunt fan in knooppunt, mar dielt ek it hjoeddeistige knooppunt yn it proses.
    /// Dit is ûnfeilich, om't it hjoeddeiske knooppunt noch wol tagonklik wêze sil, nettsjinsteande dat it is ferdield.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Befestiget de stjoerder ûnfeilich de statyske ynformaasje dat dizze knooppunt in `Leaf` is.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Befestiget de statyske ynformaasje ûnfeilich dat dizze knooppunt in `Internal` is.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nim tydlik in oare, feroarbere ferwizing nei deselde knooppunt út.Pas op, om't dizze metoade heul gefaarlik is, dûbel sa, om't it miskien net direkt gefaarlik ferskynt.
    ///
    /// Om't mutabele oanwizings oeral om 'e beam kinne swalkje, kin de weromkommende oanwizer maklik wurde brûkt om de orizjinele oanwizer te hingjen, bûten de grinzen, of ûnjildich ûnder steapele lienregels.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) beskôgje noch in oare type parameter ta te foegjen oan `NodeRef` dy't it gebrûk fan navigaasjemethoden beheint op opnij lizzende oanwizers, wêrtroch dizze ûnfeiligens foarkomt.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leint eksklusive tagong ta it blêddiel fan elk blêd of ynterne knooppunt.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // VEILIGHEID: wy hawwe eksklusive tagong ta it heule knooppunt.
        unsafe { &mut *ptr }
    }

    /// Biedt eksklusive tagong ta it blêddiel fan elk blêd of ynterne knooppunt.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // VEILIGHEID: wy hawwe eksklusive tagong ta it heule knooppunt.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leent eksklusive tagong ta in elemint fan it kaai-opslachgebiet.
    ///
    /// # Safety
    /// `index` is yn grinzen fan 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // VEILIGHEID: de beller sil sels gjin fierdere metoaden kinne skilje
        // oant de kaaiferwizings foar slúten falt, om't wy unike tagong hawwe foar it libben fan 'e liening.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Leint eksklusive tagong ta in elemint of stikje fan it opslachgebiet fan 'e knooppunt.
    ///
    /// # Safety
    /// `index` is yn grinzen fan 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // VEILIGHEID: de beller sil sels gjin fierdere metoaden kinne skilje
        // oant de referinsje foar weardestek wurdt sakke, om't wy unike tagong hawwe foar it libben fan 'e liening.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leint eksklusive tagong ta in elemint of stikje fan it opslachgebiet fan 'e node foar edge-ynhâld.
    ///
    /// # Safety
    /// `index` is yn grinzen fan 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // VEILIGHEID: de beller sil sels gjin fierdere metoaden kinne skilje
        // oant de Slice-referinsje fan edge falt, om't wy unike tagong hawwe foar it libben fan 'e liening.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - It knooppunt hat mear as `idx` inisjalisearre eleminten.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Wy meitsje allinich in ferwizing nei it iene elemint wêryn wy ynteressearre binne, om aliasing te foarkommen mei treflike referinsjes nei oare eleminten, yn it bysûnder dyjingen dy't yn eardere iteraasjes werom binne nei de beller.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Wy moatte twinge oan net-grutte arraypointers fanwegen Rust-útjefte #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leint eksklusive tagong ta de lingte fan it knooppunt.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stelt de kepling fan de knooppunt yn nei syn âlder edge, sûnder dat oare ferwizings nei it knooppunt ûnjildich wurde.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Wisket de kepling fan 'e woartel nei syn âlder edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Foeget in kaai-weardepaar ta oan 'e ein fan' e knooppunt.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Elk item weromjûn troch `range` is in jildige edge-yndeks foar it knooppunt.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Foeget in kaai-weardepaar ta, en in edge om nei rjochts fan dat pear te gean, oan 'e ein fan' e knooppunt.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontroleart oft in knooppunt in `Internal`-knooppunt of in `Leaf`-knooppunt is.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// In ferwizing nei in spesifyk kaai-weardepaar of edge binnen in knooppunt.
/// De `Node`-parameter moat in `NodeRef` wêze, wylst de `Type` `KV` kin wêze (in hantlieding op in kaai-weardepaar betsjutte) of `Edge` (in hantlieding op in edge).
///
/// Tink derom dat sels `Leaf`-knooppunten `Edge`-hânfetten kinne hawwe.
/// Ynstee fan in oanwizer foar in berneknoop te fertsjintwurdigjen, fertsjintwurdigje dizze de spaasjes wêr't bernwizers tusken de kaai-weardepearen soene gean.
/// Bygelyks yn in knooppunt mei lingte 2 soene d'r 3 mooglike edge-lokaasjes wêze, ien lofts fan it knooppunt, ien tusken de twa pearen, en ien rjochts fan it knooppunt.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Wy hawwe de folsleine algemienens fan `#[derive(Clone)]` net nedich, om't de iennige kear dat `Node` 'Clone' is, is as it in ûnferoarlike referinsje is en dus `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Helpt it knooppunt dat it edge of kaai-weardepaar befettet wêr't dit hantel wiist.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Jout de posysje fan dit handgreep yn 'e knooppunt werom.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Makket in nij handgreep oan in kaai-weardepaar yn `node`.
    /// Unfeilich omdat de beller moat soargje dat `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kin in iepenbiere ymplemintaasje wêze fan PartialEq, mar allinich brûkt yn dizze module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Nim tydlik in oare, ûnferoarlike greep op deselde lokaasje út.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Wy kinne Handle::new_kv of Handle::new_edge net brûke, om't wy ús type net kenne
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Beweart de stjoerder ûnfeilich de statyske ynformaasje dat it knooppunt fan 'e handgreep in `Leaf` is.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Nim tydlik in oare, feroarbere hannel op deselde lokaasje út.
    /// Pas op, om't dizze metoade heul gefaarlik is, dûbel sa, om't it miskien net direkt gefaarlik ferskynt.
    ///
    ///
    /// Sjoch `NodeRef::reborrow_mut` foar details.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Wy kinne Handle::new_kv of Handle::new_edge net brûke, om't wy ús type net kenne
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Makket in nij handgreep oan in edge yn `node`.
    /// Unfeilich omdat de beller derfoar soargje moat dat `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Jûn in edge-yndeks wêr't wy wolle ynfoegje yn in knooppunt fol mei kapasiteit, berekent in ferstannige KV-yndeks fan in splitpunt en wêr't de ynfoeging út te fieren.
///
/// It doel fan it splitpunt is dat de kaai en de wearde yn in âlderknooppel einigje;
/// de toetsen, wearden en rânen links fan it splitpunt wurde it linker bern;
/// de toetsen, wearden en rânen rjochts fan it splitpunt wurde it juste bern.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust-útjefte #74834 besiket dizze symmetryske regels út te lizzen.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Foeget in nij kaai-weardepaar yn tusken de kaai-weardepearen rjochts en lofts fan dizze edge.
    /// Dizze metoade giet derfan út dat d'r genôch romte is yn it knooppunt foar it nije pear om te passen.
    ///
    /// De weromkommende oanwizer wiist nei de ynfoege wearde.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Foeget in nij kaai-weardepaar yn tusken de kaai-weardepearen rjochts en lofts fan dizze edge.
    /// Dizze metoade splitst it knooppunt as d'r net genôch romte is.
    ///
    /// De weromkommende oanwizer wiist nei de ynfoege wearde.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixet de âlderwizer en yndeks yn it berneknooppunt wêrnei't dizze edge keppelt.
    /// Dit is nuttich as de oarder fan kanten is feroare,
    fn correct_parent_link(self) {
        // Meitsje backpointer sûnder oare ferwizings nei it knooppunt te ûnjildigjen.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Foeget in nij kaai-weardepaar en in edge yn dat sil nei rjochts fan dat nije pear gean tusken dizze edge en it kaai-weardepaar rjochts fan dizze edge.
    /// Dizze metoade giet derfan út dat d'r genôch romte is yn it knooppunt foar it nije pear om te passen.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Foeget in nij kaai-weardepaar en in edge yn dat sil nei rjochts fan dat nije pear gean tusken dizze edge en it kaai-weardepaar rjochts fan dizze edge.
    /// Dizze metoade splitst it knooppunt as d'r net genôch romte is.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Foeget in nij kaai-weardepaar yn tusken de kaai-weardepearen rjochts en lofts fan dizze edge.
    /// Dizze metoade splitst it knooppunt as d'r net genôch romte is, en besiket it split-off-diel rekursyf yn it âlder knooppunt yn te foegjen, oant de root wurdt berikt.
    ///
    ///
    /// As it weromkommen resultaat in `Fit` is, kin it knooppunt fan syn handgreep dizze knooppunt fan edge wêze as in foarfaar.
    /// As it weromkommen resultaat in `Split` is, sil it `left`-fjild de rootknooppunt wêze.
    /// De weromkommende oanwizer wiist nei de ynfoege wearde.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Fynt it knooppunt oanwiisd troch dizze edge.
    ///
    /// De metoadenamme giet derfan út dat jo beammen ôfbylde mei de rootknooppunt boppe.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` moatte beide, nei sukses, neat dwaan.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Wy moatte rauwe oanwizings brûke foar knooppunten, om't, as BorrowType marker::ValMut is, der miskien útsûnderlike feroarbere ferwizingen binne nei wearden dy't wy net unjildich moatte.
        // D'r is gjin soargen foar tagong ta it hichtefjild, om't dizze wearde wurdt kopieare.
        // Tink derom dat, as de node-oanwizer ienris wurdt ferwidere, wy tagong krije ta de rânen-array mei in referinsje (Rust-útjefte #73987) en unjildige oare referinsjes nei of yn 'e array, as der rûn wêze soe.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Wy kinne gjin aparte kaai-en weardemethoden neame, om't it oproppen fan 'e twadde de referinsje ûnjildich makket troch de earste.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ferfang de kaai en wearde wêrnei't it KV-hannel ferwiist.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Helpt ymplemintaasjes fan `split` foar in bepaalde `NodeType`, troch it fersoargjen fan blêdgegevens.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Spalt de ûnderlizzende knooppunt yn trije dielen:
    ///
    /// - It knooppunt wurdt ôfkoarte om allinich de kaai-weardepearen oan 'e linkerkant fan dit hantlieding te befetsjen.
    /// - De kaai en de wearde dy't dizze hantlieding oanwiist, wurde útpakt.
    /// - Alle kaai-weardepearen rjochts fan dit handgreep wurde yn in nij tawiisd knooppunt set.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ferwideret it kaai-weardepaar oanwiisd troch dit hantel en retourneert it, tegearre mei de edge wêryn it kaai-weardepaar yn foel.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Spalt de ûnderlizzende knooppunt yn trije dielen:
    ///
    /// - It knooppunt wurdt ôfkoarte om allinich de rânen en kaai-weardepearen oan 'e linkerkant fan dit hânsel te befetsjen.
    /// - De kaai en de wearde dy't dizze hantlieding oanwiist, wurde útpakt.
    /// - Alle rânen en kaai-weardepearen rjochts fan dit handgreep wurde yn in nij tawiisd knooppunt set.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Fertsjintwurdiget in sesje foar evaluearjen en útfieren fan in balânsearjende operaasje om in ynterne kaai-weardepaar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kiest in balansearjende kontekst dy't de knooppunt omfettet as bern, dus tusken de KV fuortendaliks nei links of nei rjochts yn 'e âlderknoade.
    /// Jout in `Err` werom as d'r gjin âlder is.
    /// Panics as de âlder leech is.
    ///
    /// Foarkar de linkerkant, om optimaal te wêzen as it opjûne knooppunt op ien of oare manier underfull is, hjir betsjuttet allinich dat it minder eleminten hat dan syn linker broer en as syn rjochter broer, as se besteane.
    /// Yn dat gefal is fusearjen mei de linker broerke rapper, om't wy allinich de N-eleminten fan 'e node ferpleatse moatte, ynstee fan se nei rjochts te ferskowen en mear dan N-eleminten foarút te ferpleatsen.
    /// Stelje fan 'e lofter sibbe is ek typysk rapper, om't wy allinich de N-eleminten fan' e knooppunt nei rjochts moatte ferskowe, ynstee fan teminsten N fan 'e sibbe-eleminten nei lofts te ferskowen.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Jout werom oft fusearjen mooglik is, dus as d'r genôch romte is yn in knooppunt om de sintrale KV te kombinearjen mei beide neistlizzende berneknopen.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Fiert in fúzje út en lit in sluting beslute wat werom te jaan.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // VEILIGHEID: de hichte fan de knopen dy't wurde gearfoege is ien ûnder de hichte
                // fan 'e knooppunt fan dizze edge, dus boppe nul, sadat se ynterne binne.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Slút it kaai-weardepaar fan 'e âlder en beide neistlizzende berneknopen gear yn' e linker berneknoop en retourneert de krimpde âlderknooppunt.
    ///
    ///
    /// Panics útsein as wy `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Slút it kaai-weardepaar fan 'e âlder en beide neistlizzende berneknooppunten ta yn' e linker berneknoop en retourneert dat berneknoop.
    ///
    ///
    /// Panics útsein as wy `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Slút it kaai-weardepaar fan 'e âlder en beide neistlizzende berneknopen gear yn' e linker berneknoop en retourneert de edge-greep yn dat berneknooppunt wêr't it folge bern edge einige,
    ///
    ///
    /// Panics útsein as wy `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Ferwideret in kaai-weardepaar fan it linker bern en pleatst it yn 'e kaai-wearde-opslach fan' e âlder, wylst it âlde âlder-kaai-weardepaar yn it juste bern drukt.
    ///
    /// Jout in greep werom nei de edge yn it juste bern dat oerienkomt mei wêr't de orizjinele edge oantsjutte troch `track_right_edge_idx` einige.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Ferwideret in kaai-weardepaar fan it juste bern en pleatst it yn 'e kaai-wearde-opslach fan' e âlder, wylst it âlde kaai-weardepaar fan 'e âlder op it linker bern drukt.
    ///
    /// Jout in hânsel werom nei de edge yn it linker bern oantsjutte troch `track_left_edge_idx`, dat net bewege.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dit stiel lykwols fergelykber mei `steal_left`, mar stiel meardere eleminten tagelyk.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Soargje derfoar dat wy feilich stelle kinne.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Blêdgegevens ferpleatse.
            {
                // Meitsje romte foar stellen eleminten yn it juste bern.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Ferpleats eleminten fan it linker bern nei it juste.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ferpleats it stellen stellen linker nei de âlder.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ferpleats it kaai-weardepaar fan 'e âlder nei it juste bern.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Meitsje romte foar stellen rânen.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Rânen stellen.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// De symmetryske kloan fan `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Soargje derfoar dat wy feilich stelle kinne.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Blêdgegevens ferpleatse.
            {
                // Ferpleats it meast stellen stellen pear nei de âlder.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ferpleats it kaai-weardepaar fan 'e âlder nei it linker bern.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Ferpleats eleminten fan it rjochter bern nei it linker.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Gap ynfolje wêr't stellen eleminten wiene.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Rânen stellen.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Gap ynfolje wêr't stellen rânen eartiids wiene.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ferwideret alle statyske ynformaasje dy't beweart dat dizze knooppunt in `Leaf`-knooppunt is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ferwideret alle statyske ynformaasje dy't beweart dat dit knooppunt in `Internal`-knooppunt is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontroleart oft it ûnderlizzende knooppunt in `Internal`-knooppunt of in `Leaf`-knooppunt is.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Ferpleats it efterheaksel nei `self` fan it iene knooppunt nei it oare.`right` moat leech wêze.
    /// De earste edge fan `right` bliuwt net feroare.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultaat fan ynfoeging, doe't in knooppunt útwreidzje moast bûten syn kapasiteit.
pub struct SplitResult<'a, K, V, NodeType> {
    // Feroare knooppunt yn besteande beam mei eleminten en rânen dy't links fan `kv` hearre.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Guon kaai en wearde skieden ôf, om earne oars yn te foegjen.
    pub kv: (K, V),
    // Eigendom, unattached, nij knooppunt mei eleminten en rânen dy't hearre ta it rjocht fan `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Oft knooppuntreferinsjes fan dit liensoart tasteane nei oare knooppunten yn 'e beam.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal is net nedich, it bart mei it resultaat fan `borrow_mut`.
        // Troch traversal út te skeakeljen, en allinich nije ferwizings nei roots te meitsjen, wite wy dat elke referinsje fan it `Owned`-type is nei in rootknooppunt.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Foeget in wearde yn in stikje inisjalisearre eleminten folge troch ien net-inisjalisearre elemint.
///
/// # Safety
/// It stik hat mear dan `idx`-eleminten.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Ferwideret en retourneert in wearde fan in stik fan alle inisjalisearre eleminten, wêrtroch ien eftersteand net-inisjalisearre elemint efterlit.
///
///
/// # Safety
/// It stik hat mear dan `idx`-eleminten.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Ferpleatst de eleminten yn in stik `distance`-posysjes nei lofts.
///
/// # Safety
/// It stik hat teminsten `distance`-eleminten.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ferpleatst de eleminten yn in stik `distance`-posysjes nei rjochts.
///
/// # Safety
/// It stik hat teminsten `distance`-eleminten.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ferpleatst alle wearden fan in stikje inisjalisearre eleminten nei in stik uninitialisearre eleminten, wêrtroch `src` as alle uninitialisearre is.
///
/// Wurkt lykas `dst.copy_from_slice(src)`, mar `T` is net `Copy` nedich.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;