use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Nim tydlik in oar, ûnferoarlik ekwivalint fan itselde berik út.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Fynt de ûnderskate blêdkanten dy't in oantsjutte berik yn in beam ôfbrekke.
    /// Jout werom in pear ferskillende hânsels yn deselde beam as in pear lege opsjes.
    ///
    /// # Safety
    ///
    /// Behalven as `BorrowType` `Immut` is, brûk de dûbele hânfetten net om twa kear deselde KV te besykjen.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ekwivalint mei `(root1.first_leaf_edge(), root2.last_leaf_edge())` mar effisjinter.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Fynt it pear blêdrânen dy't in spesifyk berik yn in beam ôfbrekke.
    ///
    /// It resultaat is allinich betsjuttend as de beam op kaai is oardere, lykas de beam yn in `BTreeMap` is.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // VEILIGHEID: ús lienstype is ûnferoarlik.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Fynt it pear blêdrânen dy't in heule beam ôfbrekke.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Spalt in unike referinsje yn in pear blêdrânen dy't in oantsjutte berik ôfbrekke.
    /// It resultaat binne net-unike referinsjes dy't (some)-mutaasje tastean, dy't foarsichtich moatte wurde brûkt.
    ///
    /// It resultaat is allinich betsjuttend as de beam op kaai is oardere, lykas de beam yn in `BTreeMap` is.
    ///
    ///
    /// # Safety
    /// Brûk de dûbele hânfetten net om deselde KV twa kear te besykjen.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Spalt in unike referinsje yn in pear blêdrânen dy't it folsleine berik fan 'e beam ôfbrekke.
    /// De resultaten binne net-unike referinsjes dy't mutaasje tastean (allinich fan wearden), dus moatte mei soarch wurde brûkt.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Wy duplisearje de root NodeRef hjir-wy sille deselde KV noait twa kear besykje, en einigje noait mei oerlappende weardeferwizings.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Spalt in unike referinsje yn in pear blêdrânen dy't it folsleine berik fan 'e beam ôfbrekke.
    /// De resultaten binne net-unike referinsjes dy't massaal destruktive mutaasje tastean, moatte dus mei de grutste soarch wurde brûkt.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Wy duplisearje hjir de root NodeRef-wy sille it noait tagong krije op in manier dy't referinsjes krigen fan 'e root oerlappe.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Jûn in blêd edge-hantel, retourneert [`Result::Ok`] mei in hânsel nei de oanbuorjende KV oan 'e rjochterkant, dat is yn deselde blêdknooppunt of yn in foarfaarknooppunt.
    ///
    /// As it blêd edge de lêste yn 'e beam is, jout [`Result::Err`] werom mei de rootknooppunt.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Jûn in blêd edge-hantel, retourneert [`Result::Ok`] mei in hânsel nei de neistlizzende KV oan 'e linker kant, dat is yn deselde blêdknooppunt of yn in foarfaarknooppunt.
    ///
    /// As it blêd edge de earste is yn 'e beam, retourneert [`Result::Err`] mei de rootknooppunt.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Jûn in ynterne edge-handgreep, retourneert [`Result::Ok`] mei in handgreep nei de oanbuorjende KV oan 'e rjochterkant, dat is yn deselde ynterne node as yn in foarfaarknooppunt.
    ///
    /// As de ynterne edge de lêste yn 'e beam is, retourneert [`Result::Err`] mei de rootknooppunt.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Jûn in blêd edge-handgreep yn in stjerrende beam, retourneert it folgjende blêd edge oan 'e rjochterkant, en it kaai-weardepaar dertusken, dat is yn itselde blêdknooppunt, yn in foarfaarknooppunt, of net-besteand.
    ///
    ///
    /// Dizze metoade behannelt ek alle node(s) wêr't it ein berikt.
    /// Dit hâldt yn dat as d'r gjin mear kaai-weardepaar bestiet, de heule rest fan 'e beam ôfhannele is en d'r neat mear is om werom te jaan.
    ///
    /// # Safety
    /// De opjûne edge moat net earder werom west hawwe troch tsjinhinger `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Jûn in blêd edge-handgreep yn in stjerrende beam, retourneert it folgjende blêd edge oan 'e linker kant, en it kaai-weardepaar dertusken, dat is yn itselde blêdknooppunt, yn in foarfaarknooppunt, of net-besteand.
    ///
    ///
    /// Dizze metoade behannelt ek alle node(s) wêr't it ein berikt.
    /// Dit hâldt yn dat as d'r gjin mear kaai-weardepaar bestiet, de heule rest fan 'e beam ôfhannele is en d'r neat mear is om werom te jaan.
    ///
    /// # Safety
    /// De opjûne edge moat net earder werom west hawwe troch tsjinhinger `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallokeart in stapel knopen fan it blêd oant de woartel.
    /// Dit is de iennichste manier om de rest fan in beam te fertsjinjen neidat `deallocating_next` en `deallocating_next_back` oan beide kanten fan 'e beam knibbelje, en deselde edge hawwe rekke.
    /// Om't it allinich bedoeld is om te wurde neamd as alle toetsen en wearden binne weromjûn, wurdt gjin opromjen dien op ien fan 'e toetsen of wearden.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ferpleatst it blêd edge-greep nei it folgjende blêd edge en jout referinsjes werom nei de kaai en de wearde dertusken.
    ///
    ///
    /// # Safety
    /// D'r moat in oare KV wêze yn 'e rjochting reizge.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Ferpleatst it blêd edge-handgreep nei it foarige blêd edge en jout referinsjes werom nei de kaai en de wearde tusken.
    ///
    ///
    /// # Safety
    /// D'r moat in oare KV wêze yn 'e rjochting reizge.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ferpleatst it blêd edge-greep nei it folgjende blêd edge en jout referinsjes werom nei de kaai en de wearde dertusken.
    ///
    ///
    /// # Safety
    /// D'r moat in oare KV wêze yn 'e rjochting reizge.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Dit lêste dwaan is rapper, neffens benchmarks.
        kv.into_kv_valmut()
    }

    /// Ferpleatst it blêd edge-handgreep nei it foarige blêd en jout referinsjes werom nei de kaai en de wearde dertusken.
    ///
    ///
    /// # Safety
    /// D'r moat in oare KV wêze yn 'e rjochting reizge.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Dit lêste dwaan is rapper, neffens benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ferpleatst it blêd edge-handgreep nei it folgjende blêd edge en retourneert de kaai en de wearde dertusken, en pleatst elke efterbleaune knooppunt, wylst de oerienkommende edge yn syn haadknooppel hinget.
    ///
    /// # Safety
    /// - D'r moat in oare KV wêze yn 'e rjochting reizge.
    /// - Dy KV waard net earder weromjûn troch tsjinhinger `next_back_unchecked` op ien eksimplaar fan 'e hânsels dy't waarden brûkt om de beam troch te gean.
    ///
    /// De iennichste feilige manier om troch te gean mei it bywurke hantel is it te fergelykjen, te litten, dizze metoade opnij te neamen ûnder betingst fan har feilichheidsbetingsten, of belje tsjinpartij `next_back_unchecked` ûnder betingst fan har feilichheidsbetingsten.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Ferpleatst it blêd edge-handgreep nei it foarige blêd edge en retourneert de kaai en de wearde dertusken, en dielt elke efterbleaune knooppunt ôf, wylst de oerienkommende edge yn syn haadknooppel hinget.
    ///
    /// # Safety
    /// - D'r moat in oare KV wêze yn 'e rjochting reizge.
    /// - Dat blêd edge waard net earder weromjûn troch tsjinhinger `next_unchecked` op ien eksimplaar fan 'e hânsels dy't waarden brûkt om de beam troch te gean.
    ///
    /// De iennichste feilige manier om troch te gean mei it bywurke hantel is it te fergelykjen, te litten, dizze metoade opnij te neamen ûnder betingst fan har feilichheidsbetingsten, of belje tsjinpartij `next_unchecked` ûnder betingst fan har feiligensbetingsten.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Jout it lofterste lofter edge werom yn of ûnder in knooppunt, mei oare wurden, de edge dy't jo earst nedich binne as jo foarút navigearje (of lêst by efterút navigearje).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Jout it rjochterste blêd edge yn of ûnder in knooppunt, mei oare wurden, de edge dy't jo it lêst nedich binne as jo foarút navigearje (of earst as jo efterút navigearje).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besjocht bladknooppunten en ynterne KV's yn folchoarder fan opkommende kaaien, en besiket ek ynterne knooppunten as gehiel yn in djipte earste oarder, wat betsjut dat ynterne knooppunten foarôfgeane oan har yndividuele KV's en har bernknooppunten.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Berekkent it oantal eleminten yn in (sub) beam.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Jout it blêd edge it tichtst by in KV foar foarútnavigaasje.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Jout it blêd edge it tichtst by in KV foar efternei navigaasje.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}