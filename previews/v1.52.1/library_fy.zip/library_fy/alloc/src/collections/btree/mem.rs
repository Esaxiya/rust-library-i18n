use core::intrinsics;
use core::mem;
use core::ptr;

/// Dit ferfangt de wearde efter de `v` unike referinsje troch de relevante funksje te skiljen.
///
///
/// As in panic foarkomt yn 'e `change`-sluting, wurdt it heule proses ôfbrutsen.
#[allow(dead_code)] // bewarje as yllustraasje en foar future gebrûk
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dit ferfangt de wearde efter de unike `v`-referinsje troch de relevante funksje op te roppen, en jout in ûnderweis resultaat krigen.
///
///
/// As in panic foarkomt yn 'e `change`-sluting, wurdt it heule proses ôfbrutsen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}