//! In dûbele einige wachtrige ymplementeare mei in groeibere ringbuffer.
//!
//! Dizze wachtrige hat *O*(1) amortisearre ynfoegingen en ferwidering fan beide einen fan 'e kontener.
//! It hat ek *O*(1) yndeksearjend as in vector.
//! De befette eleminten moatte net kopieare wurde, en de wachtrige sil ferstjoere wurde as it befette type ferstjoerber is.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Grutste mooglike krêft fan twa

/// In dûbele einige wachtrige ymplementeare mei in groeibere ringbuffer.
///
/// It "default"-gebrûk fan dit type as wachtrige is it brûken fan [`push_back`] om ta te foegjen oan 'e wachtrige, en [`pop_front`] om út' e wachtrige te ferwiderjen.
///
/// [`extend`] en [`append`] triuwe op dizze manier op 'e rêch, en iterearjen oer `VecDeque` giet foarút nei efter.
///
/// Sûnt `VecDeque` in ringbuffer is, binne har eleminten net needsaaklik gearhingjend yn it ûnthâld.
/// As jo tagong wolle ta de eleminten as ien stik, lykas foar effisjint sortearjen, kinne jo [`make_contiguous`] brûke.
/// It draait de `VecDeque` sadat syn eleminten net wikkelje, en jout in feroarbere stik werom nei de no-oaniensletten elemintfolchoarder.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // sturt en holle binne oanwizings yn 'e buffer.
    // Sturt wiist altyd nei it earste elemint dat koe wurde lêzen, Head wiist altyd nei wêr't gegevens moatte wurde skreaun.
    //
    // As sturt==kop is de buffer leech.De lingte fan 'e ringbuffer wurdt definieare as de ôfstân tusken de twa.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Rint de destruktor foar alle items yn 'e slice as it falt (normaal as by it ûntspannen).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // brûk drop foar [T]
            ptr::drop_in_place(front);
        }
        // RawVec behannelet deallokaasje
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Makket in lege `VecDeque<T>` oan.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginaal handiger
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginaal handiger
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Foar nulgrutte soarten binne wy altyd op maksimale kapasiteit
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Meitsje ptr yn in plak
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Meitsje ptr yn in mut slach
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Ferpleatst in elemint út 'e buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Skriuwt in elemint yn 'e buffer, ferpleatst it.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Jout `true` werom as de buffer op folsleine kapasiteit is.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Jout de yndeks yn 'e ûnderlizzende buffer foar in opjûne logyske elemintyndeks.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Jout de yndeks yn 'e ûnderlizzende buffer foar in opjûne logyske elemint-yndeks + tafoeging.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Jout de yndeks yn 'e ûnderlizzende buffer foar in opjûne logyske elemint-yndeks, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kopieart in oanienslútend ûnthâldblok lang fan src nei dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopieart in oanienslútend ûnthâldblok lang fan src nei dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopieart in potinsjeel ynpakblok fan ûnthâld len lang fan src nei dest.
    /// (abs(dst - src) + len) mei net grutter wêze dan cap() (D'r moat op syn meast ien trochgeande oerlappende regio wêze tusken src en dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src wikkelt net, dst wikkelt net
                //
                //        S.,,
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst foar src, src wikkelt net, dst wikkelt
                //
                //
                //    S.,,
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src foar dst, src wikkelt net, dst wikkelt
                //
                //
                //              S.,,
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst foar src, src wraps, dst wikkelt net
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D.,,
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src foar dst, src wraps, dst wikkelt net
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D.,,
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst foar src, src wraps, dst wraps
                //
                //
                //    ,.. S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D.,
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src foar dst, src wraps, dst wraps
                //
                //
                //    .. S.,
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs de holle en sturt seksjes rûn om it feit te behanneljen dat wy gewoan wer tawiist.
    /// Unfeilich omdat it âlde_kapasiteit fertrout.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Ferpleats it koartste oaniensletten diel fan 'e ringbuffer TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [.,,ooooooo.,,,,,
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Makket in lege `VecDeque` oan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Makket in lege `VecDeque` mei romte foar teminsten `capacity`-eleminten.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 om't de ringbuffer altyd ien spaasje leech lit
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Jout in ferwizing nei it elemint by de opjûne yndeks.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Jout in feroarbere ferwizing nei it elemint by de opjûne yndeks.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ruilje eleminten op yndeksen `i` en `j`.
    ///
    /// `i` en `j` kinne gelyk wêze.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Panics
    ///
    /// Panics as ien fan 'e yndeks bûten de grinzen is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Jout it oantal eleminten werom dat de `VecDeque` kin hâlde sûnder opnij tawiizgjen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Reserveart de minimale kapasiteit foar presys `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `VecDeque`.
    /// Docht neat as de kapasiteit al genôch is.
    ///
    /// Tink derom dat de allocator de kolleksje mear romte kin jaan dan hy freget.
    /// Dêrom kin net op ferteld wurde dat se krekt minimal binne.
    /// Foarkar [`reserve`] as ynstekken fan future wurde ferwachte.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Reserveart kapasiteit foar teminsten `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `VecDeque`.
    /// De kolleksje kin mear romte reservearje om faak weryndielingen te foarkommen.
    ///
    /// # Panics
    ///
    /// Panics as de nije kapasiteit oerstreamt fan `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Besiket de minimale kapasiteit te reservearjen foar presys `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `VecDeque<T>`.
    ///
    /// Nei it oproppen fan `try_reserve_exact` sil de kapasiteit grutter wêze as of gelyk oan `self.len() + additional`.
    /// Docht neat as de kapasiteit al genôch is.
    ///
    /// Tink derom dat de allocator de kolleksje mear romte kin jaan dan hy freget.
    /// Dêrom kin net wurde fertrouwe op kapasiteit om krekt minimal te wêzen.
    /// Foarkar `reserve` as ynstekken fan future wurde ferwachte.
    ///
    /// # Errors
    ///
    /// As de kapasiteit `usize` oerslacht, as de allocator in mislearring rapporteart, dan wurdt in flater weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservearje it ûnthâld foarôf en gean út as wy net kinne
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // No wite wy dat dit net OOM(Out-Of-Memory) kin midden yn ús komplekse wurk
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // heul yngewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Besiket kapasiteit te reservearjen foar teminsten `additional` mear eleminten dy't wurde ynfoege yn 'e opjûne `VecDeque<T>`.
    /// De kolleksje kin mear romte reservearje om faak weryndielingen te foarkommen.
    /// Nei it oproppen fan `try_reserve` sil de kapasiteit grutter wêze as of gelyk oan `self.len() + additional`.
    /// Docht neat as kapasiteit al genôch is.
    ///
    /// # Errors
    ///
    /// As de kapasiteit `usize` oerslacht, as de allocator in mislearring rapporteart, dan wurdt in flater weromjûn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservearje it ûnthâld foarôf en gean út as wy net kinne
    ///     output.try_reserve(data.len())?;
    ///
    ///     // No wite wy dat dit net OOM kin midden yn ús komplekse wurk
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // heul yngewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Krimp de kapasiteit fan 'e `VecDeque` safolle mooglik.
    ///
    /// It sil sa ticht mooglik op 'e lingte falle, mar de allocator kin de `VecDeque` noch ynformearje dat d'r romte is foar in pear mear eleminten.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Krimpt de kapasiteit fan 'e `VecDeque` mei in legere grins.
    ///
    /// De kapasiteit sil op syn minst like grut bliuwe as sawol de lingte as de levere wearde.
    ///
    ///
    /// As de hjoeddeistige kapasiteit minder is dan de legere limyt, is dit in no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Wy hoege ús gjin soargen te meitsjen oer in oerstreaming, om't `self.len()` noch `self.capacity()` noait `usize::MAX` kinne wêze.
        // +1 as de ringbuffer altyd ien romte leech lit.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // D'r binne trije gefallen fan belang:
            //   Alle eleminten binne bûten de winske grinzen Eleminten binne oanswettend, en de kop is bûten de winske grinzen Eleminten binne ûndúdlik, en de sturt is bûten de winske grinzen
            //
            //
            // Op alle oare tiden wurde elemintposysjes net beynfloede.
            //
            // Jout oan dat eleminten oan 'e kop moatte wurde ferpleatst.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Eleminten ferpleatse fanút de winske grinzen (posysjes nei target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Koartet de `VecDeque`, hâldt de earste `len`-eleminten en lit de rest falle.
    ///
    ///
    /// As `len` grutter is dan de hjoeddeistige lingte fan 'VecDeque', hat dit gjin effekt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Rint de destruktor foar alle items yn 'e slice as it falt (normaal as by it ûntspannen).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Feilich omdat:
        //
        // * Elts stikje dat wurdt oerdroegen oan `drop_in_place` is jildich;it twadde gefal hat `len <= front.len()` en it weromkommen op `len > self.len()` soarget foar `begin <= back.len()` yn it earste gefal
        //
        // * De holle fan 'e VecDeque wurdt ferpleatst foardat `drop_in_place` wurdt neamd, sadat gjin wearde twa kear falt as `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Soargje derfoar dat de twadde helte wurdt sakke, sels as in destruktor yn 'e earste panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Jout in front-to-back iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Jout in front-to-back iterator dy't mutabele referinsjes retourneert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // VEILIGHEID: De ynterne `IterMut` feiligens-invariant is oprjochte om't de
        // `ring` wy kreëarje is in derefereneze plak foar it libben '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Jout in pear slúten werom dy't yn folchoarder de ynhâld fan 'e `VecDeque` befetsje.
    ///
    /// As [`make_contiguous`] earder waard neamd, sille alle eleminten fan 'e `VecDeque` yn' e earste slice wêze en de twadde slach sil leech wêze.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Jout in pear slúten werom dy't yn folchoarder de ynhâld fan 'e `VecDeque` befetsje.
    ///
    /// As [`make_contiguous`] earder waard neamd, sille alle eleminten fan 'e `VecDeque` yn' e earste slice wêze en de twadde slach sil leech wêze.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Jout it oantal eleminten yn 'e `VecDeque` werom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Jout `true` werom as de `VecDeque` leech is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Makket in iterator dy't it oantsjutte berik yn 'e `VecDeque` behannelt.
    ///
    /// # Panics
    ///
    /// Panics as it begjinpunt grutter is dan it einpunt of as it einpunt grutter is dan de lingte fan 'e vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // In folslein berik omfettet alle ynhâld
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // De dielde referinsje dy't wy hawwe yn &self wurdt ûnderhâlden yn '_ fan Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Makket in iterator oan dy't it oantsjutte feroarbere berik yn 'e `VecDeque` behannelt.
    ///
    /// # Panics
    ///
    /// Panics as it begjinpunt grutter is dan it einpunt of as it einpunt grutter is dan de lingte fan 'e vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // In folslein berik omfettet alle ynhâld
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // VEILIGHEID: De ynterne `IterMut` feiligens-invariant is oprjochte om't de
        // `ring` wy kreëarje is in derefereneze plak foar it libben '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Makket in drainerende iterator dy't it oantsjutte berik yn 'e `VecDeque` fuortsmyt en de ferwidere items opsmyt.
    ///
    /// Opmerking 1: It elemintberik wurdt fuorthelle, sels as de iterator oant it ein net wurdt konsumeare.
    ///
    /// Opmerking 2: It is net oantsjutte hoefolle eleminten wurde fuortsmiten fan 'e deque, as de `Drain`-wearde net falt, mar de liening dy't hy hat ferrint (bgl. Fanwege `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics as it begjinpunt grutter is dan it einpunt of as it einpunt grutter is dan de lingte fan 'e vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // In folslein berik wisket alle ynhâld
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Memory feiligens
        //
        // As de Drain foar it earst wurdt oanmakke, wurdt de boarne deque ynkoarte om derfoar te soargjen dat gjin uninitialisearre of ferpleatste fan eleminten hielendal tagonklik binne as de destruktor fan 'e Drain noait rint.
        //
        //
        // Drain sil de wearden te ferwiderjen ptr::read útfiere.
        // As jo klear binne, wurde de oerbleaune gegevens werom kopieare om it gat te dekken, en de head/tail-wearden wurde korrekt wersteld.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // De eleminten fan 'e deque binne ferdield yn trije segminten:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Wy bewarje drain_tail as self.head, en drain_head en self.head respektivelik as after_tail en after_head op 'e Drain.
        // Dit trunet ek de effektive array sa dat as de Drain lekt wurdt, binne wy de potensjele ferpleatste wearden nei it begjin fan 'e drain fergetten.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" oer de wearden nei it begjin fan 'e drain oant nei de drain foltôge is en de Drain-destruktor wurdt útfierd.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Wichtich meitsje wy hjir allinich dielde referinsjes fan `self` en lêze derút.
                // Wy skriuwe net nei `self`, noch opnij nei in feroarbere referinsje.
                // Hjirtroch bliuwt de rauwe oanwizer dy't wy hjirboppe hawwe makke, foar `deque`, jildich.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Wisket de `VecDeque`, ferwideret alle wearden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Jout `true` werom as de `VecDeque` in elemint befettet dat gelyk is oan de opjûne wearde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Jout in ferwizing nei it foarste elemint, of `None` as de `VecDeque` leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Jout in feroarbere ferwizing nei it foarste elemint, of `None` as de `VecDeque` leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Jout in ferwizing nei it efterste elemint, of `None` as de `VecDeque` leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Jout in feroarbere ferwizing nei it efterste elemint, of `None` as de `VecDeque` leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Ferwideret it earste elemint en jout it werom, as `None` as de `VecDeque` leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Ferwideret it lêste elemint fan 'e `VecDeque` en jout it werom, as `None` as it leech is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Foarkomt in elemint oan 'e `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Foeget in elemint ta oan 'e efterkant fan' e `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Moatte wy `head == 0` betsjutte as betsjutting?
        // dat `self` oangrinzjend is?
        self.tail <= self.head
    }

    /// Ferwideret in elemint fan oeral yn 'e `VecDeque` en retourneert it, ferfange troch it earste elemint.
    ///
    ///
    /// Dit behâldt net bestellen, mar is *O*(1).
    ///
    /// Jout `None` werom as `index` bûten de grinzen is.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Ferwideret in elemint fan oeral yn 'e `VecDeque` en retourneert it, ferfangt it troch it lêste elemint.
    ///
    ///
    /// Dit behâldt net bestellen, mar is *O*(1).
    ///
    /// Jout `None` werom as `index` bûten de grinzen is.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Stekt in elemint yn op `index` yn 'e `VecDeque`, ferskowt alle eleminten mei yndeksen grutter as of gelyk oan `index` nei efteren.
    ///
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Panics
    ///
    /// Panics as `index` grutter is dan de lingte fan 'VecDeque'
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Ferpleats it minste oantal eleminten yn 'e ringbuffer en ynfoegje it opjûne objekt
        //
        // Op syn meast len/2 wurde 1 eleminten ferpleatst. O(min(n, n-i))
        //
        // D'r binne trije gefallen:
        //  Eleminten binne oangrinzjend
        //      - spesjaal gefal as sturt 0 is Eleminten binne ûndúdlik en it ynfoeg is yn 'e sturt Seksje Eleminten binne ûndúdlik en it ynfoeg is yn' e kopstik
        //
        //
        // Foar elk dêrfan binne d'r noch twa gefallen:
        //  Ynfoegje is tichter by sturt Ynfoeging is tichter by kop
        //
        // Kaai: H, self.head
        //      T, self.tail o, Jildich elemint I, ynfoegingselemint A, It elemint dat nei it ynstekpunt M moat wêze, Jout oan dat it elemint is ferpleatst
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [In oooooo.,,,,,,
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // oangrinzjend, ynfoegje tichter by sturt:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // oangrinzjend, ynfoegje tichter by sturt en sturt is 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // De sturt al ferpleatst, dat wy kopiearje allinich `index - 1`-eleminten.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // oangrinzjend, ynfoegje tichter by kop:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, ynfoegje tichter by sturt, tail seksje:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ynfoegje tichter by kop, sturt seksje:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopiearje eleminten oant nije kop
                    self.copy(1, 0, self.head);

                    // kopiearje lêste elemint yn in leech plak ûnderoan buffer
                    self.copy(0, self.cap() - 1, 1);

                    // ferpleatse eleminten fan idx nei ein foarút sûnder ^ elemint
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, ynfoegje is tichter by sturt, holle seksje, en is op yndeks nul yn 'e ynterne buffer:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopiearje eleminten oant nije sturt
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopiearje lêste elemint yn in leech plak ûnderoan buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ynfoegje tichter by sturt, holle seksje:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopiearje eleminten oant nije sturt
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopiearje lêste elemint yn in leech plak ûnderoan buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // ferpleatse eleminten fan idx-1 nei ein foarút net ynklusyf ^ elemint
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ynfoegje tichter by kop, kop seksje:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // sturt is miskien feroare, dat wy moatte opnij berekkenje
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Ferwideret en retourneert it elemint op `index` fan 'e `VecDeque`.
    /// Hokker ein tichter by it ferwideringspunt is, sil wurde ferpleatst om romte te meitsjen, en alle oanbelangjende eleminten wurde ferpleatst nei nije posysjes.
    ///
    /// Jout `None` werom as `index` bûten de grinzen is.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // D'r binne trije gefallen:
        //  Eleminten binne oaniensletten Eleminten binne ûndúdlik en de ferwidering is yn 'e sturtdiel Eleminten binne ûndúdlik en de ferwidering is yn' e kop-seksje
        //
        //      - spesjaal gefal as eleminten technysk gearhingjend binne, mar self.head =0
        //
        // Foar elk dêrfan binne d'r noch twa gefallen:
        //  Ynfoegje is tichter by sturt Ynfoeging is tichter by kop
        //
        // Kaai: H, self.head
        //      T, self.tail o, Jildich elemint x, Element markearre foar ferwidering R, Jout oan elemint dat wurdt fuorthelle M, Jout oan dat elemint is ferpleatst
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // oangrinzjend, tichter by sturt fuortsmite:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // oangrinzjend, ferwiderje tichter by kop:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, ferwiderje tichter by sturt, tail seksje:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ferwiderje tichter by holle, holle seksje:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ferwiderje tichter by kop, sturt seksje:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // as quasi-ûndúdlik, fuortsmite neist kop, sturt seksje:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // tekenje eleminten yn 'e sturtdiel yn
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Foarkomt ûnderstream.
                    if self.head != 0 {
                        // kopiearje it earste elemint op in leech plak
                        self.copy(self.cap() - 1, 0, 1);

                        // ferpleatse eleminten yn 'e holle seksje efterút
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ferwiderje tichter by sturt, holle seksje:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // tekenje eleminten yn oant idx
                    self.copy(1, 0, idx);

                    // kopiearje lêste elemint yn in leech plak
                    self.copy(0, self.cap() - 1, 1);

                    // ferpleatse eleminten fan sturt nei ein foarút, útsein de lêste
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Spalt de `VecDeque` yn twaen by de opjûne yndeks.
    ///
    /// Jout in nij tawiisde `VecDeque`.
    /// `self` befettet eleminten `[0, at)`, en de werom `VecDeque` befettet eleminten `[at, len)`.
    ///
    /// Tink derom dat de kapasiteit fan `self` net feroaret.
    ///
    /// Element by yndeks 0 is de foarkant fan 'e wachtrige.
    ///
    /// # Panics
    ///
    /// Panics as `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` leit yn 'e earste helte.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // nim allinich de heule helte.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` leit yn 'e twadde helte, moatte faktorearje yn' e eleminten dy't wy yn 'e earste helte oerslaan.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Opromjen wêr't de einen fan de buffers binne
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Ferpleatst alle eleminten fan `other` nei `self`, wêrtroch `other` leech is.
    ///
    /// # Panics
    ///
    /// Panics as it nije oantal eleminten yn himsels in `usize` oerslacht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naïve ympl
        self.extend(other.drain(..));
    }

    /// Behâldt allinich de eleminten oantsjutte troch it predikaat.
    ///
    /// Mei oare wurden, ferwiderje alle eleminten `e` sadat `f(&e)` falsk weromkomt.
    /// Dizze metoade wurket te plak, besiket elk elemint presys ien kear yn 'e orizjinele folchoarder, en behâldt de oarder fan' e bewarre eleminten.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// De krekte folchoarder kin nuttich wêze foar folgjen fan eksterne steat, lykas in yndeks.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Dit kin panic of ôfbrekke
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Dûbelje de buffergrutte.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Modifiseart de `VecDeque` op it plak, sadat `len()` gelyk is oan `new_len`, troch oerstallige eleminten fan 'e efterkant te ferwiderjen, of troch eleminten oan te heakjen dy't generearre binne troch `generator` nei de efterkant te roppen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Herskikt de ynterne opslach fan dizze deque, sadat it ien oaniensletten stik is, dat dan werom wurdt.
    ///
    /// Dizze metoade alloceart net en feroaret de folchoarder fan 'e ynfoege eleminten net.As it in feroarbere stik werombringt, kin dit brûkt wurde om in deque te sortearjen.
    ///
    /// As de ynterne opslach oaniensletten is, sille de [`as_slices`]-en [`as_mut_slices`]-metoaden de folsleine ynhâld fan 'e `VecDeque` yn ien stik werombringe.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// De ynhâld fan in deque sortearje.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // sortearje de deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // it yn omkearde folchoarder te sortearjen
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Unferoarlike tagong krije ta de oaniensletten plak.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // wy kinne no wis wêze dat `slice` alle eleminten fan 'e deque befettet, wylst wy noch unferoarlike tagong hawwe ta `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // d'r is genôch frije romte om de sturt yn ien kear te kopiearjen, dit betsjut dat wy de holle earst efterút ferskowe, en dan de sturt nei de juste posysje kopiearje.
            //
            //
            // fan: DEFGH .... ABC
            // nei: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Wy beskôgje op it stuit net .... ABCDEFGH
            // oangrinzjend wêze om't `head` yn dit gefal `0` wêze soe.
            // Wylst wy dit wierskynlik wizigje wolle, is it net triviaal, om't in pear plakken ferwachtsje dat `is_contiguous` betsjuttet dat wy gewoan kinne brûke mei `buf[tail..head]`.
            //
            //

            // d'r is genôch frije romte om de kop yn ien kear te kopiearjen, dit betsjut dat wy de sturt earst nei foaren ferskowe, en dan de kop nei de juste posysje kopiearje.
            //
            //
            // fan: FGH .... ABCDE
            // oan: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // fergees is lytser dan sawol holle as sturt, dit betsjut dat wy de sturt en de holle stadichoan "swap" moatte.
            //
            //
            // fan: EFGHI ... ABCD as HIJK.ABCDEFG
            // nei: ABCDEFGHI ... of ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // It algemiene probleem sjocht der sa út as dizze GHIJKLM ... ABCDEF, foardat alle wiksels ABCDEFM ... GHIJKL, nei 1 pass fan swaps ABCDEFGHIJM ... KL, ruilje oant de linker edge de temp store berikt
                //                  - start it algoritme dan opnij mei in nije (smaller)-winkel Soms wurdt de tydlike winkel berikt as de juste edge oan 'e ein fan' e buffer is, dit wol sizze dat wy mei minder swaps de goeie folchoarder hawwe rekke!
                //
                // E.g
                // EF..ABCD ABCDEF .., nei fjouwer ienige wikselingen binne wy klear
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Roteart de dûbele einige wachtrige dy't `mid` nei links pleatst.
    ///
    /// Equivalently,
    /// - Roteart item `mid` nei de earste posysje.
    /// - Pops de earste `mid`-artikels en triuwt se oant it ein.
    /// - Roteart `len() - mid` plakken nei rjochts.
    ///
    /// # Panics
    ///
    /// As `mid` grutter is dan `len()`.
    /// Tink derom dat `mid == len()` _not_ panic docht en in no-op-rotaasje is.
    ///
    /// # Complexity
    ///
    /// Nimt `*O*(min(mid, len() - mid))` tiid en gjin ekstra romte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Roteart de dûbele einige wachtrige dy't `k` nei rjochts pleatst.
    ///
    /// Equivalently,
    /// - Roteart it earste item yn posysje `k`.
    /// - Pops de lêste `k`-artikels en triuwt se nei foaren.
    /// - Roteart `len() - k` plakken nei lofts.
    ///
    /// # Panics
    ///
    /// As `k` grutter is dan `len()`.
    /// Tink derom dat `k == len()` _not_ panic docht en in no-op-rotaasje is.
    ///
    /// # Complexity
    ///
    /// Nimt `*O*(min(k, len() - k))` tiid en gjin ekstra romte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // VEILIGHEID: de folgjende twa metoaden fereaskje dat it rotaasjebedrach is
    // minder dan de helte fan 'e deque wêze.
    //
    // `wrap_copy` fereasket dat `min(x, cap() - x) + copy_len <= cap()`, mar dan `min` is noait mear dan de helte fan 'e kapasiteit, ûnôfhinklik fan x, dus it is lûd om hjir te skiljen, om't wy skilje mei wat minder dan de helte fan' e lingte, dy't noait boppe de helte fan 'e kapasiteit is.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binêr siket dizze sorteare `VecDeque` nei in bepaald elemint.
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.
    /// As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op.
    /// De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// As jo in item wolle ynfoegje yn in sorteare `VecDeque`, mei behâld fan sortearfolchoarder:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binêr siket dizze sorteare `VecDeque` mei in komparatorfunksje.
    ///
    /// De komparatorfunksje moat in oarder ymplementearje yn oerienstimming mei de sortearfolchoarder fan 'e ûnderlizzende `VecDeque`, en in oardekoade weromjaan dy't oanjout as it argumint `Less`, `Equal` of `Greater` is dan it winske doel.
    ///
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op.De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binêr siket dizze sorteare `VecDeque` mei in funksje foar kaai-ekstraksje.
    ///
    /// Giet derfan út dat de `VecDeque` wurdt sorteare troch de kaai, bygelyks mei [`make_contiguous().sort_by_key()`](#method.make_contiguous) mei deselde ekstraksjefunksje foar kaaien.
    ///
    ///
    /// As de wearde wurdt fûn, wurdt [`Result::Ok`] weromjûn, mei de yndeks fan it oerienkommende elemint.
    /// As d'r meardere wedstriden binne, dan kin ien fan 'e wedstriden weromjûn wurde.
    /// As de wearde net wurdt fûn, wurdt [`Result::Err`] weromjûn, mei de yndeks wêryn in oerienkommende elemint koe wurde ynfoege mei behâld fan de sorteare folchoarder.
    ///
    /// # Examples
    ///
    /// Sjocht in searje fan fjouwer eleminten op yn in stik pearen sorteare op har twadde eleminten.
    /// De earste wurdt fûn, mei in unyk bepaalde posysje;it twadde en it tredde wurde net fûn;de fjirde koe oerienkomme mei elke posysje yn `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Feroaret de `VecDeque` op it plak, sadat `len()` gelyk is oan new_len, troch oerstallige eleminten fan 'e rêch te ferwiderjen of troch klonen fan `value` oan' e rêch ta te heakjen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Jout de yndeks yn 'e ûnderlizzende buffer foar in opjûne logyske elemintyndeks.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // grutte is altyd in krêft fan 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Berekkenje it oantal te lêzen eleminten yn 'e buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // grutte is altyd in krêft fan 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Altyd te dielen yn trije seksjes, bygelyks: sels: [a b c|d e f] oar: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // It is net mooglik om Hash::hash_slice te brûken op plakjes weromjûn troch de metoade as_slices, om't har lingte kin ferskille yn oars identike deques.
        //
        //
        // Hasher garandeart allinich lykweardigens foar de krekte selde set fan oproppen nei har metoaden.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ferbrûkt de `VecDeque` yn in front-to-back iterator dy't eleminten op wearde jout.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Dizze funksje moat it morele ekwivalint wêze fan:
        //
        //      foar item yn iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Meitsje in [`Vec<T>`] yn in [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dit foarkomt it werlokalisearjen wêr't mooglik is, mar de betingsten dêrfoar binne strikt en ûnderwerp fan feroaring, en soe dus net op fertrouwe moatte, útsein as de `Vec<T>` fan `From<VecDeque<T>>` kaam en net opnij is tawiisd.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // D'r is gjin feitlike tawizing foar ZST's om har soargen te meitsjen oer kapasiteit, mar `VecDeque` kin net safolle lingte behannelje as `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Wy moatte de grutte oanpasse as de kapasiteit gjin krêft is fan twa, te lyts as net teminsten ien frije romte hat.
            // Wy dogge dit wylst it noch yn 'e `Vec` is, sadat de items falle op panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Meitsje in [`VecDeque<T>`] yn in [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dit hoecht noait opnij te allocearjen, mar moat *O*(*n*) gegevensbeweging dwaan as de sirkulêre buffer net bart oan it begjin fan 'e allocaasje.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Dizze is *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Dizze hat gegevens opnij regele.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}