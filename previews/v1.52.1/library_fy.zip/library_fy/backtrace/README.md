# backtrace-rs

[Documentation](https://docs.rs/backtrace)

In bibleteek foar ferwervjen fan backtraces by runtime foar Rust.
Dizze bibleteek is fan doel de stipe fan 'e standertbibleteek te ferbetterjen troch in programmatyske ynterface te leverjen om mei te wurkjen, mar it stipet ek gewoan de hjoeddeiske backtrace ôfdrukke lykas libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Om gewoan in backtrace te feroverjen en it hanneljen dêrfan út te stellen oant in letter tiid, kinne jo it `Backtrace`-type op it boppeste nivo brûke.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

As jo lykwols mear rauwe tagong wolle ta de eigentlike tracefunksjonaliteit, kinne jo de funksjes `trace` en `resolve` direkt brûke.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Los dizze ynstruksjewizer op nei in symboalnamme
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // gean troch nei it folgjende frame
    });
}
```

# License

Dit projekt is lisinsje jûn ûnder ien fan beide

 * Apache lisinsje, Ferzje 2.0, ([LICENSE-APACHE](LICENSE-APACHE) of http://www.apache.org/licenses/LICENSE-2.0)
 * MIT lisinsje ([LICENSE-MIT](LICENSE-MIT) as http://opensource.org/licenses/MIT)

op jo opsje.

### Contribution

Behalven as jo oars eksplisyt oanjaan, sil elke bydrage dy't mei opsetsin wurdt yntsjinne foar opnimmen yn backtrace-rs troch jo, lykas definieare yn 'e Apache-2.0-lisinsje, dûbel lisinsje jûn lykas hjirboppe, sûnder ekstra betingsten of betingsten.







