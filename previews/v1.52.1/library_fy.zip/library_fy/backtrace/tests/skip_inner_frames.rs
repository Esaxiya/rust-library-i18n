use backtrace::Backtrace;

// Dizze test wurket allinich op platfoarms dy't in wurkjende `symbol_address`-funksje hawwe foar frames dy't it startadres fan in symboal rapportearje.
// As resultaat is it allinich ynskeakele op in pear platfoarms.
//
const ENABLED: bool = cfg!(all(
    // Windows is net echt hifke, en OSX stipet net it feitlik finen fan in ôfslutend frame, dus útskeakelje dit
    //
    target_os = "linux",
    // By ARM is it finen fan 'e ôfslutende funksje gewoan de ip sels werom.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}