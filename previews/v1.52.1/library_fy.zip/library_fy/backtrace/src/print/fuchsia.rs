use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr nimt in callback dy't in dl_phdr_info-oanwizer krijt foar elke DSO dy't yn it proses is keppele.
    // dl_iterate_phdr soarget der ek foar dat de dynamyske linker fan begjin oant ein fan 'e werhelling is beskoattele.
    // As de callback in net-nul-wearde jout, wurdt de iteraasje betiid beëinige.
    // 'data' sil wurde trochjûn as it tredde argumint foar de callback op elke oprop.
    // 'size' jout de grutte fan it dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Wy moatte de build-ID en wat basisprogramma-headergegevens analysearje, wat betsjut dat wy ek in bytsje guod nedich binne fan 'e ELF-spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// No moatte wy, bit foar bit, de struktuer fan it type dl_phdr_info replikearje brûkt troch de hjoeddeiske dynamyske linker fan fuchsia.
// Chromium hat ek dizze ABI-grins en ek crashpad.
// Uteinlik wolle wy dizze gefallen ferpleatse om elf-search te brûken, mar wy moatte dat yn 'e SDK leverje en dat is noch net dien.
//
// Sadwaande sitte wy (en sy) fêst mei dizze metoade te brûken dy't in strakke koppeling makket mei de fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Wy hawwe gjin manier om te witten te kontrolearjen oft e_phoff en e_phnum jildich binne.
    // libc moat dit lykwols foar ús soargje, dus it is feilich hjir in stik te foarmjen.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr fertsjintwurdiget in header fan 64-bit ELF-programma's yn 'e einigens fan' e doelargitektuer.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr fertsjintwurdiget in jildige header fan ELF-programma en de ynhâld derfan.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Wy hawwe gjin manier om te kontrolearjen oft p_addr of p_memsz jildich binne.
    // Fuchsia's libc parseart de notysjes earst lykwols, trochdat se hjir binne moatte dizze kopteksten jildich wêze.
    //
    // OpmerkingIter fereasket de ûnderlizzende gegevens net jildich, mar it fereasket dat de grinzen jildich binne.
    // Wy fertrouwe derop dat libc hat derfoar soarge dat dit hjir it gefal foar ús is.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// It notysjetype foar build-ID's.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr fertsjintwurdiget in koptekst fan 'e ELF-notysje yn' e einigens fan it doel.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Opmerking fertsjintwurdiget in ELF-notysje (koptekst + ynhâld).
// De namme wurdt efterlitten as in u8-stik, om't it net altyd null beëindige is en rust makket it maklik genôch om te kontrolearjen dat de bytes lykwols oerienkomme.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Op NoteIter kinne jo feilich itearje oer in notysegment.
// It beëindiget sadree't in flater optreedt as d'r gjin notysjes mear binne.
// As jo iterearje oer unjildige gegevens, dan sil it funksjonearje as wiene der gjin notysjes fûn.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // It is in invariant fan funksje dat de oantsjutte oanwizer en grutte in jildich berik oan bytes oantsjutte dat allegear kinne wurde lêzen.
    // De ynhâld fan dizze bytes kin alles wêze, mar it berik moat jildich wêze om dit feilich te wêzen.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to rjochtet 'x' út op 'to'-byte-opstelling, útgeande fan 'to' is in krêft fan 2.
// Dit folget in standert patroan yn C/C ++ ELF-parsingkoade wêr (x + oant, 1)&-to wurdt brûkt.
// Rust lit jo gjin gebrûk meitsje, dat ik brûk
// 2's-komplement konverzje om dat opnij te meitsjen.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 verbruikt num bytes fan 'e slice (as oanwêzich) en soarget derneist foar dat de definitive slúte goed oanpast is.
// As of it oantal frege bytes te grut is of as de sleat dernei net opnij kin wurde oanpast, om't d'r net genôch oerbleaune bytes binne, wurdt Gjin weromjûn en wurdt it stik net wizige.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Dizze funksje hat gjin echte invarianten dy't de beller oars moat hanthavenje dan miskien dat 'bytes' moatte wurde ôfstimd foar prestaasjes (en op guon arsjitekten korrektheid).
// De wearden yn 'e Elf_Nhdr-fjilden kinne ûnsin wêze, mar dizze funksje soarget net foar sa'n ding.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dit is feilich, salang't d'r genôch romte is en wy hawwe gewoan befestige dat yn 'e as-ferklearring hjirboppe, dus dit moat net ûnfeilich wêze.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Tink derom dat sice_of: :<Elf_Nhdr>() is altyd 4-byte rjochte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrolearje as wy it ein hawwe berikt.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Wy transmutearje in nhdr, mar wy beskôgje de resulterende struktuer mei soarch.
        // Wy fertrouwe de namesz of descsz net en wy meitsje gjin ûnfeilige besluten basearre op it type.
        //
        // Dat sels as wy folslein ôffal krije, soene wy noch altyd feilich moatte wêze.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Jout oan dat in segmint útfierber is.
const PERM_X: u32 = 0b00000001;
/// Jout oan dat in segmint skriuwber is.
const PERM_W: u32 = 0b00000010;
/// Jout oan dat in segmint lêsber is.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Fertsjintwurdiget in ELF-segmint by runtime.
struct Segment {
    /// Jout it firtuele adres fan 'e runtime fan' e ynhâld fan dit segmint.
    addr: usize,
    /// Jout de ûnthâldgrutte fan 'e ynhâld fan dit segmint.
    size: usize,
    /// Jout it virtuele adres fan 'e module fan dit segmint mei it ELF-bestân.
    mod_rel_addr: usize,
    /// Jout de tagongsrjochten fûn yn it ELF-bestân.
    /// Dizze tagongsrjochten binne lykwols net needsaaklik de tagongsrjochten oanwêzich by runtime.
    flags: Perm,
}

/// Lit ien itereerje oer Segminten fan in DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Fertsjintwurdiget in ELF DSO (Dynamic Shared Object).
/// Dit type ferwiist nei de gegevens opslein yn 'e eigentlike DSO ynstee fan in eigen kopy te meitsjen.
struct Dso<'a> {
    /// De dynamyske linker jout ús altyd in namme, sels as de namme leech is.
    /// Yn it gefal fan it haadútfierbere programma sil dizze namme leech wêze.
    /// Yn it gefal fan in dielde objekt sil it de soname wêze (sjoch DT_SONAME).
    name: &'a str,
    /// Op Fuchsia hawwe frijwol alle binearingen ID's boud, mar dit is gjin strang eask.
    /// D'r is gjin manier om DSO-ynformaasje oerien te meitsjen mei in echte ELF-bestân efterôf as d'r gjin build_id is, dat wy fereaskje dat elke DSO hjir ien hat.
    ///
    /// DSO's sûnder build_id wurde negeare.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Jout in iterator oer Segminten yn dizze DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Dizze flaters kodearje problemen dy't ûntsteane by it parsen fan ynformaasje oer elke DSO.
///
enum Error {
    /// NameError betsjut dat der in flater barde by it konvertearjen fan in C-styl string yn in rust string.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError betsjuttet dat wy gjin build-ID hawwe fûn.
    /// Dit kin wêze om't de DSO gjin build-ID hie, of om't it segmint mei de build-ID ferkeard wie.
    ///
    BuildIDError,
}

/// Ropt 'dso' as 'error' op foar elke DSO dy't keppele is oan it proses troch de dynamyske linker.
///
///
/// # Arguments
///
/// * `visitor` - In DsoPrinter dy't ien fan eatsmetoaden hat neamd foar elke DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr soarget derfoar dat info.name nei in jildige lokaasje wiist.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Dizze funksje drukt de Fuchsia symbolisearringsopmaak ôf foar alle ynformaasje befette yn in DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}