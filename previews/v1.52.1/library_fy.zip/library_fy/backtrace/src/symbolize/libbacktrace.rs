//! Symbolisaasjestrategy mei de DWARF-parsingkoade yn libbacktrace.
//!
//! De libbacktrace C-bibleteek, typysk ferspraat mei gcc, stipet net allinich it generearjen fan in backtrace (dy't wy eins net brûke), mar ek symbolisearje de backtrace en it behanneljen fan dwerch-debug-ynformaasje oer dingen lykas ynline frames en wat dan ek.
//!
//!
//! Dit is relatyf yngewikkeld fanwegen in protte ferskate soargen hjir, mar it basisidee is:
//!
//! * Earst neame wy `backtrace_syminfo`.Dit krijt symboalynformaasje fan 'e dynamyske symboaltabel as wy kinne.
//! * Folgjende neame wy `backtrace_pcinfo`.Dit sil debuginfo-tabellen analysearje as se beskikber binne en kinne ús ynformaasje herstelle oer ynline frames, bestânsnammen, rigelnûmers, ensfh.
//!
//! D'r is in soad trickery oer it krijen fan de dwerchtafels yn libbacktrace, mar hooplik is it net it ein fan 'e wrâld en is dúdlik genôch as jo hjirûnder lêze.
//!
//! Dit is de standert symbolisaasjestrategy foar net-MSVC-en net-OSX-platfoarms.Yn libstd is dit lykwols de standertstrategy foar OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // As mooglik de `function`-namme foarkomme dy't komt fan debuginfo en kin typysk krekter wêze foar bygelyks ynline frames.
                // As dat net oanwêzich is, falt dan werom nei de symboaltabelnamme oantsjutte yn `symname`.
                //
                // Tink derom dat `function` soms wat minder krekt kin fiele, bygelyks wurdt neamd as `try<i32,closure>` net foar `std::panicking::try::do_call`.
                //
                // It is net echt dúdlik wêrom, mar oer it algemien liket de `function`-namme krekter.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // doch no neat
}

/// Soart fan de `data`-oanwizer dy't wurdt trochjûn yn `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Sadree't dizze callback wurdt oproppen fan `backtrace_syminfo` as wy begjinne mei oplossen, geane wy fierder om `backtrace_pcinfo` te skiljen.
    // De `backtrace_pcinfo`-funksje sil debug-ynformaasje konsultearje en besykje om dingen te dwaan lykas file/line-ynformaasje te herstellen, lykas ynline frames.
    // Tink derom dat `backtrace_pcinfo` kin mislearje of net folle dwaan as d'r gjin ynfo-ynfo is, dus as dat bart, sille wy wis de callback neame mei op syn minst ien symboal fan 'e `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Soart fan de `data`-oanwizer dy't wurdt trochjûn yn `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// De libbacktrace API stipet it meitsjen fan in steat, mar it stipet gjin ferneatiging fan in steat.
// Ik nim dit persoanlik oan as betsjutting dat in steat bedoeld is oan te meitsjen en dan foar altyd te libjen.
//
// Ik soe graach in at_exit()-handler registrearje dy't dizze tastân opromt, mar libbacktrace biedt gjin manier om dit te dwaan.
//
// Mei dizze beheiningen hat dizze funksje in statysk cache tastân dy't wurdt berekkene de earste kear dat dit wurdt frege.
//
// Tink derom dat backtracing allegear serieus bart (ien globaal slot).
//
// Tink derom dat it gebrek oan syngronisaasje hjir komt troch de eask dat `resolve` ekstern syngronisearre is.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Brûk gjin threadsafe-mooglikheden fan libbacktrace, om't wy it altyd op in syngronisearre manier neame.
        //
        0,
        error_cb,
        ptr::null_mut(), // gjin ekstra gegevens
    );

    return STATE;

    // Tink derom dat foar libbacktrace om te operearjen it DWARF-debuginfo foar it hjoeddeistige útfierbere moat fine.It docht dat typysk fia in oantal meganismen, ynklusyf, mar net beheind ta:
    //
    // * /proc/self/exe op stipe platfoarms
    // * De bestânsnamme waard eksplisyt trochjûn by it meitsjen fan steat
    //
    // De libbacktrace bibleteek is in grut stik C-koade.Dit betsjut natuerlik dat it kwetsberens fan ûnthâldfeiligens hat, fral by it behanneljen fan misfoarme debuginfo.
    // Libstd hat histoarysk genôch hjirfan rekke.
    //
    // As /proc/self/exe wurdt brûkt, kinne wy dizze typysk negearje, om't wy oannimme dat libbacktrace "mostly correct" is en oars gjin rare dingen docht mei "attempted to be correct" dwerch-debuginfo.
    //
    //
    // As wy lykwols in bestânsnamme trochjaan, dan is it mooglik op guon platfoarms (lykas BSD's) wêr't in kwea-aardige akteur kin feroarsaakje dat in willekeurich bestân op dy lokaasje wurdt pleatst.
    // Dit betsjut dat as wy libbacktrace fertelle oer in bestânsnamme, kin it in willekeurich bestân brûke, en mooglik segfaults feroarsaakje.
    // As wy libbacktrace lykwols neat fertelle, dan sil it neat dwaan op platfoarms dy't paden lykas /proc/self/exe net stypje!
    //
    // Mei it each op alles besykje wy sa hurd mooglik *net* yn in bestânsnamme troch te jaan, mar wy moatte op platfoarms dy't /proc/self/exe hielendal net stypje.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Tink derom dat wy ideaal `std::env::current_exe` brûke, mar wy kinne `std` hjir net fereaskje.
            //
            // Brûk `_NSGetExecutablePath` om it hjoeddeistige útfierbere paad yn in statysk gebiet te laden (dat as it te lyts is gewoan opjaan).
            //
            //
            // Tink derom dat wy libbacktrace hjir serieus fertrouwe om net te stjerren op korrupte útfierbere bestannen, mar it docht wis ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows hat in modus foar it iepenjen fan bestannen wêrnei't it nei it iepenjen net kin wurde wiske.
            // Dat is yn 't algemien wat wy hjir wolle, om't wy wolle soargje dat ús útfierber net ûnder ús feroaret nei't wy it oerdrage oan libbacktrace, hopelik it ferminderjen fan' e mooglikheid om willekeurige gegevens yn libbacktrace troch te jaan (wat miskien mishannele wurdt).
            //
            //
            // Jûn dat wy hjir in bytsje dûnsje om te besykjen in soarte fan slot te krijen foar ús eigen ôfbylding:
            //
            // * Krij in hantlieding foar it hjoeddeiske proses, laad de bestânsnamme.
            // * Iepenje in bestân nei dy bestânsnamme mei de juste flaggen.
            // * Laad de bestânsnamme fan it hjoeddeiske proses opnij, en soargje derfoar dat it itselde is
            //
            // As dat alles trochgiet, hawwe wy yn teory it bestân fan ús proses yndie iepene en wy binne garandearre dat it net sil feroarje.FWIW in bosk hjirfan is histoarysk kopieare fan libstd, dus dit is myn bêste ynterpretaasje fan wat der barde.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dit libbet yn statysk ûnthâld, sadat wy it kinne werombringe ..
                static mut BUF: [i8; N] = [0; N];
                // ... en dit libbet op 'e stapel, om't it tydlik is
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // mei opsetsin `handle` hjir lekke, om't it hawwen fan dat iepen ús slot op dizze bestânsnamme moat behâlde.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Wy wolle in plak werombringe dat nul-beëindige is, dus as alles waard ynfold en it is gelyk oan de totale lingte, lykweardich dan oan mislearring.
                //
                //
                // Oars as jo by sukses weromkomme, soargje derfoar dat de nulbyte yn 'e sleat is opnaam.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace-flaters wurde op it stuit ûnder it kleed fage
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Rop de `backtrace_syminfo` API oan dy't (fan it lêzen fan 'e koade) `syminfo_cb` presys ienris skilje moat (of mislearret mei in flater nei alle gedachten).
    // Wy behannelje dan mear binnen de `syminfo_cb`.
    //
    // Tink derom dat wy dit dogge, om't `syminfo` de symboaltabel sil rieplachtsje, symboalnammen fine, sels as d'r gjin ynformaasje oer debuggen is yn it binêre.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}