// no allinich op Linux brûkt, dus tastean deade koade earne oars
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// In ienfâldige arena-allocator foar byte-buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Jout in buffer ta fan de oantsjutte grutte en retourneert in feroarbere referinsje.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // VEILIGHEID: dit is de iennige funksje dy't in mutabele konstrueart
        // ferwizing nei `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // VEILIGHEID: wy ferwiderje noait eleminten fan `self.buffers`, dus in referinsje
        // nei de gegevens yn elke buffer sil libje sa lang as `self` docht.
        &mut buffers[i]
    }
}