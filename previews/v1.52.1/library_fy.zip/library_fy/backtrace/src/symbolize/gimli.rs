//! Stipe foar symbolikaasje mei de `gimli` crate op crates.io
//!
//! Dit is de standert ymplemintaasje fan symbolikaasje foar Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statyske libbensdoer is in leagen om te hacken oer gebrek oan stipe foar selsferwizende structs.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konvertearje nei 'statyske libbensdagen, om't de symboalen allinich `map` en `stash` moatte liene en wy behâlde se hjirûnder.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Foar it laden fan native biblioteken op Windows, sjoch wat diskusje oer rust-lang/rust#71060 foar de ferskate strategyen hjir.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-biblioteken stypje op it stuit gjin ASLR (rust-lang/rust#16514), mar DLL's kinne noch altyd ferpleatst wurde yn 'e adresromte.
            // It docht bliken dat adressen yn debuginfo allegear binne as as dizze bibleteek waard laden op syn "image base", dat is in fjild yn har COFF-bestânkoppen.
            // Om't dit is wat debuginfo liket te listjen analysearje wy de symboaltabel en bewarje wy adressen as soe de biblioteek ek op "image base" laden wurde.
            //
            // De bibleteek hoecht lykwols net te laden by "image base".
            // (nei alle gedachten kin dêr wat oars wurde laden?) Dit is wêr't it `bias`-fjild yn 't spiel komt, en wy moatte hjir de wearde fan `bias` útfine.Spitigernôch is it lykwols net dúdlik hoe dit te krijen is fan in laden module.
            // Wat wy lykwols hawwe is it eigentlike laadadres (`modBaseAddr`).
            //
            // As in bytsje cop-out foar no mmapje wy it bestân, lêze de bestânkopynformaasje en falle dan de mmap.Dit is fergrieme, om't wy de mmap wierskynlik letter wer iepenje, mar dit moat no goed genôch wurkje.
            //
            // As wy ienris de `image_base` (winske laadlokaasje) en de `base_addr` (werklike lêstlokaasje) hawwe, kinne wy de `bias` ynfolje (ferskil tusken de eigentlike en winske) en dan is it oantsjutte adres fan elk segmint de `image_base`, om't dit is wat it bestân seit.
            //
            //
            // Foar no docht bliken dat wy yn tsjinstelling ta ELF/MachO mei ien segmint per biblioteek kinne dwaan, mei `modBaseSize` as de heule grutte.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS brûkt it Mach-O-bestânsformaat en brûkt DYLD-spesifike API's om in list mei native biblioteken te laden dy't diel útmeitsje fan 'e applikaasje.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Helje de namme fan dizze bibleteek dy't oerienkomt mei it paad wêr't jo it ek moatte laden.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Laad de koptekst fan dizze bibleteek en delegearje nei `object` om alle laadkommando's te analysearjen, sadat wy alle belutsen segminten hjir kinne útfine.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterearje oer de segminten en registrearje bekende regio's foar segminten dy't wy fine.
            // Dêrneist registrearje ynformaasje oer tekstsegminten foar letter ferwurking, sjoch opmerkingen hjirûnder.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bepale de "slide" foar dizze bibleteek, dy't úteinlik de foaroardielen is dy't wy brûke om út te finen wêr't yn it ûnthâld objekten binne laden.
            // Dit is wol in bytsje frjemde berekkening en is it resultaat fan it besykjen fan in pear dingen yn it wyld en sjen wat der stekt.
            //
            // It algemiene idee is dat de `bias` plus de `stated_virtual_memory_address` fan in segment sil wêze wêr't yn 'e wirklike adresromte it segmint wennet.
            // It oare ding wêr't wy lykwols op fertrouwe is dat in echt adres minus de `bias` de yndeks is om op te sykjen yn 'e symboaltabel en debuginfo.
            //
            // It docht lykwols bliken dat dizze berekkeningen foar systeem laden biblioteken ferkeard binne.Foar native útfierbere bestannen liket it lykwols korrekt.
            // As jo wat logika ophelje fan 'e boarne fan LLDB, hat it wat spesjale behuizing foar de earste `__TEXT`-seksje laden fan bestânsoarch 0 mei in net-nulgrutte.
            // Foar hokker reden as dit oanwêzich is, liket it te betsjutten dat de symboaltabel relatyf is oan gewoan de vmaddr-slide foar de biblioteek.
            // As it *net* oanwêzich is, dan is de symboaltabel relatyf oan 'e vmaddr-dia plus it oantsjutte adres fan it segmint.
            //
            // Om dizze situaasje te behanneljen as wy *gjin* seksje fine by bestân kompenseare nul, ferheegje wy de foaroardielen mei it adres fan 'e earste tekstseksjes en ferminderje ek alle oantsjutte adressen mei dat bedrach.
            //
            // Op dizze manier ferskynt de symboaltabel altyd relatyf oan it foaroardielbedrach fan 'e bibleteek.
            // Dit liket de juste resultaten te hawwen foar symboalisearjen fia de symboaltabel.
            //
            // Earlik sein bin ik net hielendal wis oft dit goed is of as d'r wat oars is dat oanjaan moat hoe dit te dwaan.
            // Foar no liket dit (?) lykwols goed genôch te wurkjen en moatte wy dit altyd oer tiid oanpasse kinne as it nedich is.
            //
            // Foar wat mear ynformaasje sjoch #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Oare Unix (bgl
        // Linux) platfoarms brûke ELF as in bestânformaat fan in objekt en implementearje typysk in API mei de namme `dl_iterate_phdr` om natuerlike biblioteken te laden.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` moatte in jildige oanwizings wêze.
        // `vec` moat in jildige oanwizer wêze foar in `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 stipet net native debuginfo, mar it buildsysteem sil debuginfo pleatse op it paad `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Al it oare moat ELF brûke, mar wyt net hoe't natuerlike biblioteken moatte wurde laden.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alle bekende dielde biblioteken dy't binne laden.
    libraries: Vec<Library>,

    /// Mappings-cache wêr't wy analyseare dwerchynformaasje bewarje.
    ///
    /// Dizze list hat in fêste kapasiteit foar har heule tiid dy't noait tanimt.
    /// It `usize`-elemint fan elk pear is in yndeks yn `libraries` boppe wêr't `usize::max_value()` it hjoeddeistige útfierber fertsjintwurdiget.
    ///
    /// De `Mapping` is oerienkommende analysearre dwerchynformaasje.
    ///
    /// Tink derom dat dit yn prinsipe in LRU-cache is en wy sille dingen hjiryn ferskowe as wy adressen symbolisearje.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segminten fan dizze bibleteek laden yn it ûnthâld, en wêr't se binne laden.
    segments: Vec<LibrarySegment>,
    /// De "bias" fan dizze bibleteek, typysk wêr't it yn it ûnthâld is laden.
    /// Dizze wearde wurdt tafoege oan it oantsjutte adres fan elk segmint om it eigentlike firtuele ûnthâldadres te krijen wêryn it segmint wurdt laden.
    /// Derneist wurdt dizze foaroardielen fan echte firtuele ûnthâldadressen ôflutsen om te yndeksearjen yn debuginfo en de symboaltabel.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// It opjûne adres fan dit segmint yn it objektbestân.
    /// Dit is net eins wêr't it segmint is laden, mar dit adres plus `bias` fan 'e bibleteek is wêr't it te finen is.
    ///
    stated_virtual_memory_address: usize,
    /// De grutte fan dit segment yn it ûnthâld.
    len: usize,
}

// ûnfeilich omdat dit ferplicht is om ekstern te syngronisearjen
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ûnfeilich omdat dit ferplicht is om ekstern te syngronisearjen
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // In heul lyts, heul ienfâldich LRU-cache foar ynfo-ynfo-feiligings.
        //
        // De hitrate moat heul heech wêze, om't de typyske stapel net tusken in protte dielde biblioteken trochkrúst.
        //
        // De `addr2line::Context`-struktueren binne frij djoer om te meitsjen.
        // De kosten dêrfan wurde ferwachte dat se wurde amortisearre troch folgjende `locate`-fragen, dy't de struktueren brûke dy't boud binne by it bouwen fan 'addr2line: : Context`s om leuke speedups te krijen.
        //
        // As wy dizze cache net hienen, soe dizze amortisaasje noait barre, en symboalisearjende backtraces soe ssssllllooooowwww wêze.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // As earste, test as dizze `lib` in segmint hat mei de `addr` (ôfhanneling behannelje).As dizze kontrôle trochgiet, kinne wy hjirûnder trochgean en it adres eins oersette.
                //
                // Tink derom dat wy `wrapping_add` hjir brûke om oerstreamingskontrôles te foarkommen.It is yn 't wyld sjoen dat de SVMA + bias-berekkening oerstreamt.
                // It liket in bytsje frjemd dat soe barre, mar d'r kinne wy net heul wat oars dwaan dan wierskynlik gewoan dizze segminten negearje, om't se wierskynlik nei de romte wize.
                //
                // Dit kaam oarspronklik yn rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // No't wy witte dat `lib` `addr` befettet, kinne wy kompensearje mei de foaroardielen om it oantsjutte virutale ûnthâldadres te finen.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Ynvariant: neidat dizze betingst foltôge is sûnder betiid werom te kommen
        // fanút in flater is de cache-yngong foar dit paad by yndeks 0.

        if let Some(idx) = idx {
            // As de mapping al yn 'e cache sit, ferpleatse it dan nei de foarkant.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // As de mapping net yn 'e cache sit, meitsje dan in nije mapping, ynfoegje dizze yn' e foarkant fan 'e cache, en ferwiderje de âldste cache-yngong as it nedich is.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // lit it `'static`-libben net lekke, soargje derfoar dat it allinich is foar ússels
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Ferlingje de libbensdoer fan `sym` nei `'static`, om't wy hjir spitigernôch ferplicht binne, mar it giet altyd út as referinsje, sadat gjin ferwizing dernei dan ek moat wurde trochholden.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // As lêste, krije in cache-mapping of meitsje in nije mapping foar dit bestân, en evaluearje de DWARF-ynfo om de file/line/name foar dit adres te finen.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Wy koenen frame-ynformaasje fine foar dit symboal, en it frame fan 'addr2line' hat yntern alle nitty gritty details.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Koe ynformaasje foar debuggen net fine, mar wy fûnen it yn 'e symboaltabel fan it útfierbere elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}