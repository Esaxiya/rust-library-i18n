use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Oplos in adres nei in symboal, en jou it symboal troch nei de oantsjutte sluting.
///
/// Dizze funksje sil it opjûne adres opsykje yn gebieten lykas de lokale symboaltabel, dynamyske symboaltabel, as DWARF-debuginfo (ôfhinklik fan 'e aktiveare ymplemintaasje) om symboalen te finen om te leverjen.
///
///
/// De sluting kin net wurde neamd as resolúsje net koe wurde útfierd, en it kin ek mear dan ien kear neamd wurde yn it gefal fan ynline funksjes.
///
/// Opjûn symboalen fertsjintwurdigje de útfiering op 'e oantsjutte `addr`, werom file/line pearen foar dat adres (as beskikber).
///
/// Tink derom dat as jo in `Frame` hawwe, dan wurdt it oanrikkemandearre de `resolve_frame`-funksje te brûken ynstee fan dizze.
///
/// # Ferplichte funksjes
///
/// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
///
/// # Panics
///
/// Dizze funksje stribbet nei panic nea, mar as de `cb` panics levere, sille guon platfoarms in dûbele panic twinge om it proses ôf te brekken.
/// Guon platfoarms brûke in C-bibleteek dy't yntern callbacks brûkt dy't net trochrûn wurde kinne, sadat panyk fan `cb` in proses kin ôfbrekke.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // sjoch allinich nei it boppeste frame
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Oplos in earder fêstlizzen fan frame nei in symboal, trochjaan fan it symboal nei de oantsjutte sluting.
///
/// Dizze funksje fiert deselde funksje út as `resolve`, útsein dat it in `Frame` nimt as argumint ynstee fan in adres.
/// Hjirmei kinne guon platfoarm-ymplementaasjes fan backtracing krekter symboalynformaasje of ynformaasje jaan oer bygelyks ynline frames.
///
/// It is oan te rieden dit te brûken as jo kinne.
///
/// # Ferplichte funksjes
///
/// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
///
/// # Panics
///
/// Dizze funksje stribbet nei panic nea, mar as de `cb` panics levere, sille guon platfoarms in dûbele panic twinge om it proses ôf te brekken.
/// Guon platfoarms brûke in C-bibleteek dy't yntern callbacks brûkt dy't net trochrûn wurde kinne, sadat panyk fan `cb` in proses kin ôfbrekke.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // sjoch allinich nei it boppeste frame
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-wearden fan stackframes binne typysk (always?) de ynstruksje *nei* de oprop dat it eigentlike stackspoar is.
// As jo dit symbolisearje, feroarsaket it filename/line-nûmer ien foarút en miskien yn 'e leechte as it tichtby it ein fan' e funksje is.
//
// Dit liket yn prinsipe altyd it gefal te wêzen op alle platfoarms, dus wy lûke ien altyd ôf fan in oplost ip om it op te lossen nei de foarige opropynstruksje yn stee fan dat de ynstruksje werom wurdt.
//
//
// Ideaal soene wy dit net dwaan.
// Ideaal soene wy bellers fan 'e `resolve` APIs hjir nedich hawwe om de -1 mei de hân te dwaan en te rekkenjen dat se lokaasjeynformaasje wolle foar de *foarige* ynstruksje, net de hjoeddeiske.
// Ideaal soene wy ek op `Frame` bleatstelle as wy yndie it adres binne fan 'e folgjende ynstruksje as de hjoeddeiske.
//
// Foar no is dit lykwols in moaie niche-oandwaning, dat wy lûke gewoan yntern altyd ien.
// Konsuminten moatte wurkje bliuwe en aardige goede resultaten krije, dus wy moatte goed genôch wêze.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Itselde as `resolve`, allinich ûnfeilich om't it net syngronisearre is.
///
/// Dizze funksje hat gjin syngronisaasjeboargers, mar is beskikber as de `std`-funksje fan dizze crate net is kompileare yn.
/// Sjoch de `resolve`-funksje foar mear dokumintaasje en foarbylden.
///
/// # Panics
///
/// Sjoch ynformaasje oer `resolve` foar behertigingen oer paniek yn `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Itselde as `resolve_frame`, allinich ûnfeilich om't it net syngronisearre is.
///
/// Dizze funksje hat gjin syngronisaasjeboargers, mar is beskikber as de `std`-funksje fan dizze crate net is kompileare yn.
/// Sjoch de `resolve_frame`-funksje foar mear dokumintaasje en foarbylden.
///
/// # Panics
///
/// Sjoch ynformaasje oer `resolve_frame` foar behertigingen oer paniek yn `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// In trait dy't de resolúsje fan in symboal yn in bestân fertsjintwurdiget.
///
/// Dizze trait wurdt levere as in trait-objekt foar de sluting jûn oan de `backtrace::resolve`-funksje, en it wurdt hast ferstjoerd, om't it ûnbekend is hokker útfiering der efter sit.
///
///
/// In symboal kin kontekstuele ynformaasje jaan oer in funksje, bygelyks de namme, bestânsnamme, rigelnûmer, presys adres, ensfh.
/// Net alle ynformaasje is lykwols altyd beskikber yn in symboal, dus alle metoaden jouwe in `Option` werom.
///
///
pub struct Symbol {
    // TODO: dizze libbenslange bân moat úteinlik oanhâlde wurde oant `Symbol`,
    // mar dat is op it stuit in brekende feroaring.
    // Foar no is dit feilich, om't `Symbol` allinich wurdt útrikt troch referinsje en net kin wurde kloneare.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Jout de namme fan dizze funksje werom.
    ///
    /// De weromkommende struktuer kin brûkt wurde om ferskate eigenskippen te ûndersiikjen oer de symboalnamme:
    ///
    ///
    /// * De `Display`-ymplemintaasje sil it ûntmangele symboal ôfdrukke.
    /// * De rauwe `str`-wearde fan it symboal is tagonklik (as it jildich utf-8 is).
    /// * De rauwe bytes foar de symboalnamme kinne tagong wurde.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Jout it begjinadres fan dizze funksje.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Jout de rûge bestânsnamme werom as in stik.
    /// Dit is benammen nuttich foar `no_std`-omjouwings.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Jout it kolomnûmer werom foar wêr't dit symboal op it stuit útfiert.
    ///
    /// Allinich gimli biedt op it stuit in wearde hjir en sels dan allinich as `filename` `Some` weromkomt, en dus is it dan ek ûnderwerp fan ferlykbere warskôgingen.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Jout it rigelnûmer werom wêr't dit symboal op it stuit útfiert.
    ///
    /// Dizze retoerwearde is typysk `Some` as `filename` `Some` weromkomt, en is sadwaande ûnderwerp fan ferlykbere warskôgingen.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Jout de bestânsnamme werom wêr't dizze funksje is definieare.
    ///
    /// Dit is op it stuit allinich beskikber as libbacktrace as gimli wurdt brûkt (bgl
    /// unix oare platfoarms) en as in binêre wurdt kompileare mei debuginfo.
    /// As oan gjin fan dizze betingsten is foldien, sil dit wierskynlik `None` werombringe.
    ///
    /// # Ferplichte funksjes
    ///
    /// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Miskien in parsed C++ -symboal, as it analysearjen fan it mangele symboal as Rust mislearre.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Soargje derfoar dat jo dizze nulgrutte hâlde, sadat de `cpp_demangle`-funksje gjin kosten hat as útskeakele.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// In omslach om in symboalnamme om ergonomyske tagongsrjochten te jaan oan de ûntmangele namme, de rauwe bytes, de rauwe tekenrige, ensfh.
///
// Deade koade tastean foar as de `cpp_demangle`-funksje net is ynskeakele.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Makket in nije symboalnamme oan fan 'e rauwe ûnderlizzende bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Jout de rauwe (mangled) symboalnamme as in `str` as it symboal jildich is utf-8.
    ///
    /// Brûk de `Display`-ymplemintaasje as jo de demangele ferzje wolle.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Jout de rûge symboalnamme werom as in list mei bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dit kin ôfdrukke as it ûntmangele symboal eins net jildich is, dus behannelje de flater hjir sierlik troch it net nei bûten te propagearjen.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Besykje opnij te ûnthâlden dat lytsûnthâld ûnthâld brûkt waard om adressen te symbolisearjen.
///
/// Dizze metoade sil besykje alle wrâldwide datastrukturen frij te jaan dy't oars wrâldwiid binne yn 'e cache of yn' e thread dy't typysk fertsjintwurdige DWARF-ynformaasje of ferlykber fertsjintwurdigje.
///
///
/// # Caveats
///
/// Hoewol dizze funksje altyd beskikber is, docht it eins neat op 'e measte ymplementaasjes.
/// Biblioteken lykas dbghelp as libbacktrace leverje gjin fasiliteiten om steat te fertsjinjen en it tawiisde ûnthâld te behearjen.
/// Foar no is de `gimli-symbolize`-funksje fan dizze crate de iennichste funksje wêr't dizze funksje effekt hat.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}