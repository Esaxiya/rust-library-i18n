//! Platfoarmôfhinklike typen.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// In platfoarm ûnôfhinklike fertsjintwurdiging fan in tekenrige.
/// As jo wurkje mei `std` ynskeakele, wurdt it oanrikkemandearre foar de gemaksmethoden foar it leverjen fan bekearing ta `std`-typen.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// In stikje, typysk levere op Unix-platfoarms.
    Bytes(&'a [u8]),
    /// Brede snaren typysk fan Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Ferlies konverteart nei in `Cow<str>`, sil allocearje as `Bytes` net jildich is UTF-8 of as `BytesOrWideString` `Wide` is.
    ///
    /// # Ferplichte funksjes
    ///
    /// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Jout in `Path`-foarstelling fan `BytesOrWideString`.
    ///
    /// # Ferplichte funksjes
    ///
    /// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}