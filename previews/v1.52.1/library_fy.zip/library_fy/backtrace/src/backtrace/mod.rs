use core::ffi::c_void;
use core::fmt;

/// Ynspektearret de hjoeddeistige opropstapel, en lit alle aktive frames trochjaan yn 'e ôfsluting foar it berekkenjen fan in stackspoar.
///
/// Dizze funksje is it wurkpaard fan dizze bibleteek by it berekkenjen fan de stackspoaren foar in programma.De opjûne sluting `cb` is ynstânsjes oplevere fan in `Frame` dy't ynformaasje fertsjintwurdigje oer dat opropframe op 'e stapel.
/// De sluting wurdt frames op in top-down-manier levere (earst neamd funksjes earst).
///
/// De weromwearde fan 'e sluting is in oantsjutting oft de backtrace trochgean moat.In retoerwearde fan `false` sil de backtrace beëindigje en direkt weromkomme.
///
/// As ienris in `Frame` is oanskaft, wolle jo wierskynlik `backtrace::resolve` skilje om de `ip` (ynstruksjewizer) as symboaladres te konvertearjen nei in `Symbol` wêrtroch de namme en/of bestânsnamme/rigelnûmer kin wurde leard.
///
///
/// Tink derom dat dit in relatyf leech nivo funksje is en as jo bygelyks in backtrace wolle fêstlizze om letter te wurde ynspekteare, dan kin it `Backtrace`-type mear passend wêze.
///
/// # Ferplichte funksjes
///
/// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
///
/// # Panics
///
/// Dizze funksje stribbet nei panic nea, mar as de `cb` panics levere, sille guon platfoarms in dûbele panic twinge om it proses ôf te brekken.
/// Guon platfoarms brûke in C-bibleteek dy't yntern callbacks brûkt dy't net trochrûn wurde kinne, sadat panyk fan `cb` in proses kin ôfbrekke.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // trochgean mei de efterútgong
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Itselde as `trace`, allinich ûnfeilich om't it net syngronisearre is.
///
/// Dizze funksje hat gjin syngronisaasjeboargers, mar is beskikber as de `std`-funksje fan dizze crate net is kompileare yn.
/// Sjoch de `trace`-funksje foar mear dokumintaasje en foarbylden.
///
/// # Panics
///
/// Sjoch ynformaasje oer `trace` foar behertigingen oer paniek yn `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// In trait dy't ien frame fan in backtrace fertsjintwurdiget, levere oan 'e `trace`-funksje fan dizze crate.
///
/// De sluting fan 'e trasearingsfunksje sil frames wurde levere, en it frame wurdt praktysk ferstjoerd, om't de ûnderlizzende ymplemintaasje net altyd bekend is oant runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Jout de hjoeddeiske ynstruksjewizer fan dit frame werom.
    ///
    /// Dit is normaal de folgjende ynstruksje om yn it frame út te fieren, mar net alle ymplementaasjes listje dit mei 100% krektens (mar it is oer it algemien frij ticht).
    ///
    ///
    /// It wurdt oanrikkemandearre dizze wearde troch te jaan oan `backtrace::resolve` om dizze yn in symboalnamme te meitsjen.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Jout de hjoeddeiske stackpointer fan dit frame werom.
    ///
    /// Yn it gefal dat in efterein de stackpointer foar dit frame net weromhelje kin, wurdt in nulpointer weromjûn.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Jout it startsymboladres werom fan it frame fan dizze funksje.
    ///
    /// Dit sil besykje de troch `ip` weromjûn ynstruksjewizer werom te spieljen nei it begjin fan 'e funksje, en dy wearde werom jaan.
    ///
    /// Yn guon gefallen sille eftergrûnen lykwols gewoan `ip` weromjaan fan dizze funksje.
    ///
    /// De weromkommende wearde kin soms brûkt wurde as `backtrace::resolve` mislearre op 'e hjirboppe opjûne `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Jout it basisadres fan 'e module wer't it frame ta heart.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dit moat earst komme, om te soargjen dat Miri foarrang nimt boppe it hostplatfoarm
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // allinich brûkt yn dbghelp symbolisearje
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}