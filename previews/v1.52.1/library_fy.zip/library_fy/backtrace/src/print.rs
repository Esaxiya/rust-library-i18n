#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// In formatter foar backtraces.
///
/// Dit type kin brûkt wurde om in backtrace ôf te drukken, ûnôfhinklik fan wêr't de backtrace sels weikomt.
/// As jo in `Backtrace`-type hawwe, brûkt de `Debug`-ymplemintaasje dit printformaat al.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// De stilen fan printsjen dy't wy kinne ôfdrukke
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Printsje in terser backtrace dy't ideaal allinich relevante ynformaasje befettet
    Short,
    /// Printsje in efterútgong dy't alle mooglike ynformaasje befettet
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Meitsje in nije `BacktraceFmt` dy't útfier sil skriuwe nei de levere `fmt`.
    ///
    /// It `format`-argumint sil de styl kontrolearje wêryn de backtrace wurdt ôfprinte, en it `print_path`-argumint sil wurde brûkt om de `BytesOrWideString`-eksimplaren fan bestânsnammen ôf te drukken.
    /// Dit type sels docht gjin ôfdruk fan bestânsnammen, mar dit werombeteljen is nedich om dat te dwaan.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Printset in oanhef foar de efterútgong dy't te drukken is.
    ///
    /// Dit is fereaske op guon platfoarms foar weromtraces om letter folslein te symbolisearjen, en oars soe dit gewoan de earste metoade moatte wêze dy't jo skilje nei it meitsjen fan in `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Foeget in kader ta oan de efterútgong.
    ///
    /// Dizze ferplichting retourneert in RAII-eksimplaar fan in `BacktraceFrameFmt` dy't kin wurde brûkt om in frame eins ôf te drukken, en by ferneatiging sil it de frame-teller ferheegje.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Fertelt de útfier fan weromtrace.
    ///
    /// Dit is op it stuit in no-op, mar wurdt tafoege foar future-kompatibiliteit mei backtrace-formaten.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Op it stuit in no-op-- ynklusyf dizze hook om future tafoegings ta te stean.
        Ok(())
    }
}

/// In formatter foar mar ien frame fan in backtrace.
///
/// Dit type is makke troch de `BacktraceFmt::frame`-funksje.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Printsje in `BacktraceFrame` mei dizze frame-opmaak.
    ///
    /// Dit sil alle `BacktraceSymbol`-eksimplaren yn 'e `BacktraceFrame` rekursyf ôfdrukke.
    ///
    /// # Ferplichte funksjes
    ///
    /// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Printsje in `BacktraceSymbol` binnen in `BacktraceFrame`.
    ///
    /// # Ferplichte funksjes
    ///
    /// Dizze funksje fereasket dat de `std`-funksje fan 'e `backtrace` crate is ynskeakele, en de `std`-funksje is standert ynskeakele.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dit is net geweldich dat wy net einigje mei it printsjen fan wat
            // mei net-utf8 bestânsnammen.
            // Gelokkich is hast alles utf8, dus dit moat net te min wêze.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Printset in rau opspoard `Frame` en `Symbol`, typysk fanút de rauwe callbacks fan dizze crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Foeget in rau frame ta oan 'e backtrace-útfier.
    ///
    /// Dizze metoade nimt, oars as de foarige, de rûge arguminten yn foar it gefal dat se boarne binne fan ferskate lokaasjes.
    /// Tink derom dat dit meardere kearen kin wurde neamd foar ien frame.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Foeget in rau frame ta oan 'e backtrace-útfier, ynklusyf kolomynformaasje.
    ///
    /// Dizze metoade nimt, lykas de foarige, de rûge arguminten yn 't gefal dat se boarne binne fan ferskate lokaasjes.
    /// Tink derom dat dit meardere kearen kin wurde neamd foar ien frame.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia is net yn steat om te symbolisearjen yn in proses, dat it hat in spesjaal formaat dat kin wurde brûkt om letter te symbolisearjen.
        // Druk hjir yn plak fan adressen yn ús eigen formaat ôf.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Gjin needsaak om "null"-frames ôf te drukken, it betsjuttet yn prinsipe gewoan dat de systeemtractrace in bytsje entûsjast wie om super fier werom te spoaren.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Om TCB-grutte yn Sgx-enklave te ferminderjen, wolle wy gjin funksjonaliteit fan symboalresolúsje ymplementearje.
        // Earder kinne wy de kompensaasje fan it adres hjirôfdrukke, wat letter kin wurde yn kaart brocht nei de juste funksje.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Printsje de yndeks fan it frame as de opsjonele ynstruksjewizer fan it frame.
        // As wy bûten it earste symboal fan dit frame binne, drukke wy gewoan de passende romte ôf.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Folgjende skriuw de symboalnamme op, mei de alternative opmaak foar mear ynformaasje as wy in folsleine backtrace binne.
        // Hjir behannelje wy ek symboalen dy't gjin namme hawwe,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // En as lêste, druk it filename/line-nûmer út as se beskikber binne.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line wurde op rigels ôfprinte ûnder de symboalnamme, dus druk wat gaadlike spaasjes ôf om ússels mei rjochts te rjochtsjen.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegearje nei ús ynterne callback om de bestânsnamme ôf te drukken en druk dan it rigelnûmer ôf.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Kolumnûmer tafoegje, as beskikber.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Wy jouwe allinich it earste symboal fan in frame
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}