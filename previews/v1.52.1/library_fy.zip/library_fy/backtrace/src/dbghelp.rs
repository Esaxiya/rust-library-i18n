//! In module om te helpen by it behearen fan dbghelp-binings op Windows
//!
//! Backtraces op Windows (teminsten foar MSVC) wurde foar in grut part oandreaun troch `dbghelp.dll` en de ferskate funksjes dy't it befettet.
//! Dizze funksjes binne op it stuit *dynamysk* laden ynstee fan statysk nei `dbghelp.dll` te keppeljen.
//! Dit wurdt op it stuit dien troch de standertbibleteek (en is dêr yn teory nedich), mar is in poging om te helpen de statyske dll-ôfhinklikens fan in biblioteek te ferminderjen, om't backtraces typysk frij opsjonele binne.
//!
//! Dat wurdt sein, `dbghelp.dll` wurdt hast altyd suksesfol laden op Windows.
//!
//! Tink derom dat om't wy al dizze stipe dynamysk laden, wy de rauwe definysjes yn `winapi` eins net kinne brûke, mar wy moatte de funksjes fan oanwizer sels definiearje en dat brûke.
//! Wy wolle net echt dwaande wêze mei it duplisearjen fan winapi, dat wy hawwe in Cargo-funksje `verify-winapi` dy't beweart dat alle binings oerienkomme mei dy yn winapi en dizze funksje is ynskeakele op CI.
//!
//! Uteinlik sille jo hjir opmerke dat de dll foar `dbghelp.dll` noait wurdt unload, en dat is op it stuit bewust.
//! It tinken is dat wy it globaal kinne cache en brûke kinne tusken petearen nei de API, en djoere loads/unloads foarkomme.
//! As dit in probleem is foar lekdetektoren of sokssawat, kinne wy de brêge oerstekke as wy dêr komme.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Wurkje om `SymGetOptions` en `SymSetOptions` net oanwêzich yn winapi sels.
// Oars wurdt dit allinich brûkt as wy soarten dûbel kontrolearje tsjin winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Noch net definieare yn winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dit is definieare yn winapi, mar it is ferkeard (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Noch net definieare yn winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Dizze makro wurdt brûkt om in `Dbghelp`-struktuer te definiearjen dy't yntern alle funksjewizers befettet dy't wy kinne lade.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// De laden DLL foar `dbghelp.dll`
            dll: HMODULE,

            // Elke funksjewizer foar elke funksje kinne wy brûke
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Yn 't earstoan hawwe wy de DLL net laden
            dll: 0 as *mut _,
            // Initiearje alle funksjes binne op nul ynsteld om te sizzen dat se dynamysk moatte wurde laden.
            //
            $($name: 0,)*
        };

        // Gemak typedef foar elk funksjetype.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Besiket `dbghelp.dll` te iepenjen.
            /// Jout sukses werom as it wurket of flater as `LoadLibraryW` mislearret.
            ///
            /// Panics as bibleteek al laden is.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funksje foar elke metoade dy't wy wolle brûke.
            // As it wurdt neamd, sil it de cache-funksje-oanwizer lêze of lade en de laden wearde weromjaan.
            // Loads wurde beweard om te slagjen.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Gemaksproxy om de opromingsslûzen te brûken om dbghelpfunksjes te ferwizen.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inisjalisearje alle nedige stipe om tagong te krijen ta `dbghelp` API-funksjes fan dizze crate.
///
///
/// Tink derom dat dizze funksje **feilich is**, hy hat yntern syn eigen syngronisaasje.
/// Tink derom dat it feilich is dizze funksje meardere kearen rekursyf te neamen.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // As earste moatte wy dizze funksje syngronisearje.Dit kin tagelyk wurde neamd fan oare threads of rekursyf binnen ien thread.
        // Tink derom dat it lestiger is dan dat, om't wat wy hjir brûke, `dbghelp`,*ek* moatte wurde syngronisearre mei alle oare bellers nei `dbghelp` yn dit proses.
        //
        // Typysk binne d'r net itselde safolle oproppen nei `dbghelp` binnen itselde proses, en wy kinne wierskynlik feilich oannimme dat wy de iennigen binne dy't tagong hawwe.
        // D'r is lykwols ien oare oare brûker wêr't wy ús soargen oer meitsje moatte, dat is iroanysk ússels, mar yn 'e standertbibleteek.
        // De Rust standertbibleteek is ôfhinklik fan dizze crate foar backtrace-stipe, en dizze crate bestiet ek op crates.io.
        // Dit betsjuttet dat as de standertbibleteek in panic-backtrace drukt, kin se race mei dizze crate dy't komt fan crates.io, wêrtroch segfouten feroarsaakje.
        //
        // Om dit syngronisaasjeprobleem op te lossen brûke wy hjir in Windows-spesifike trúk (it is ommers in Windows-spesifike beheining oer syngronisaasje).
        // Wy meitsje in *sesje-lokaal* neamd mutex om dizze oprop te beskermjen.
        // De bedoeling hjir is dat de standertbibleteek en dizze crate gjin API's fan Rust-nivo hoege te dielen om hjir te syngronisearjen, mar kinne ynstee efter de skermen wurkje om te soargjen dat se mei-inoar syngronisearje.
        //
        // Op dizze manier as dizze funksje wurdt neamd fia de standertbibleteek of fia crates.io, kinne wy der wis fan wêze dat deselde mutex wurdt oernommen.
        //
        // Dat alles is dus te sizzen dat it earste wat wy hjir dogge is dat wy atomysk in `HANDLE` meitsje dy't in neamde mutex is op Windows.
        // Wy syngronisearje in bytsje mei oare threads dy't dizze funksje spesifyk diele en soargje derfoar dat mar ien handgreep wurdt oanmakke per eksimplaar fan dizze funksje.
        // Tink derom dat it hantel noait is sletten as it ienris yn 'e wrâld opslein is.
        //
        // Nei't wy it slot eins hawwe gien, krije wy it gewoan oan, en ús `Init`-hantlieding dy't wy útdiele sille ferantwurdlik wêze foar it falle.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!No dat wy allegear feilich syngronisearre binne, litte wy alles eins ferwurkje.
        // As earste moatte wy derfoar soargje dat `dbghelp.dll` eins wurdt laden yn dit proses.
        // Wy dogge dit dynamysk om in statyske ôfhinklikens te foarkommen.
        // Dit is histoarysk dien om rare ferbiningsproblemen te wurkjen en is bedoeld om binaries wat draachbaarder te meitsjen, om't dit foar in grut part gewoan in feilsûkerprogramma is.
        //
        //
        // As wy ienris `dbghelp.dll` hawwe iepene, moatte wy wat inisjalisaasjefunksjes dêryn neame, en dat wurdt hjirûnder mear detaillearre.
        // Wy dogge dit mar ien kear, hoewol, dus hawwe wy in wrâldwide booleaanske oanjûn dy't oanjout as wy al dien binne of net.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Soargje derfoar dat de `SYMOPT_DEFERRED_LOADS`-flagge is ynsteld, om't neffens MSVC's eigen dokuminten dêroer: "This is the fastest, most efficient way to use the symbol handler.", dus litte wy dat dwaan!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Inisjalisearje eins symboalen mei MSVC.Tink derom dat dit kin mislearje, mar wy negearje it.
        // D'r is per se net in ton foarôfgeande keunst foar, mar LLVM liket hjir de returnwearde te negearjen en ien fan 'e sanitizerbiblioteken yn LLVM drukt in eng warskôging ôf as dit mislearret, mar yn' e lange termyn negeart.
        //
        //
        // Ien gefal dat dit in soad opkomt foar Rust is dat de standertbibleteek en dizze crate op crates.io beide wolle konkurrearje foar `SymInitializeW`.
        // De standertbibleteek woe histoarysk inisjalisearje dan meast skjinmeitsjen, mar no't it dizze crate brûkt, betsjuttet it dat ien earst nei inisjalisaasje sil komme en de oare sil dizze inisjalisaasje ophelje.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}