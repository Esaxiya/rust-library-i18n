#![feature(no_core)]
#![no_core]

// Sjoch rustc-std-wurkromte-kearn foar wêrom dizze crate nedich is.

// Rename de crate om konflikt mei de allocaasjemodule yn liballoc te foarkommen.
extern crate alloc as foo;

pub use foo::*;