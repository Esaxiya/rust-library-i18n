#![feature(no_core)]
#![no_core]

// આ crate શા માટે જરૂરી છે તે માટે rustc-std-workpace-core જુઓ.

// લિબોલોકમાં ફાળવણી મોડ્યુલ સાથે વિરોધાભાસી ટાળવા માટે ઝેડ 0 ક્રેટ 0 ઝેડનું નામ બદલો.
extern crate alloc as foo;

pub use foo::*;