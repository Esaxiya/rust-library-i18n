//! `#[assert_instr]` મેક્રોનો અમલ
//!
//! આ મેક્રોનો ઉપયોગ `stdarch` crate ની ચકાસણી કરતી વખતે થાય છે અને પરીક્ષણના કિસ્સાઓ પેદા કરવા માટે વપરાય છે તે ખાતરી કરવા માટે કે વિધેયોમાં ખરેખર તે સૂચનો શામેલ છે જેની અમે અપેક્ષા રાખીએ છીએ તે સમાવે છે.
//!
//! પ્રોસેસીશનલ મેક્રો અહીં પ્રમાણમાં સરળ છે, તે ફક્ત `#[test]` ફંક્શનને મૂળ token પ્રવાહમાં જોડે છે જે ભારપૂર્વક જણાવે છે કે આ કાર્ય પોતે સંબંધિત સૂચના ધરાવે છે.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // એએક્સએક્સ સક્ષમ સાથે કમ્પાઈલ કરેલા x86 લક્ષ્યો માટે assert_instr અક્ષમ કરો, જેના કારણે LLVM જુદી જુદી અંતર્ગત પેદા કરે છે જેના માટે આપણે પરીક્ષણ કરી રહ્યા છીએ.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // જો સૂચના પરીક્ષણો અક્ષમ કરવામાં આવ્યાં છે તો આ શિમ કા .વાનું બિલકુલ ટાળવું, ફક્ત અમારા લક્ષણ વિના મૂળ વસ્તુ પરત કરો.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // આ નામ તે પછીથી વિસર્જનમાં શોધવા માટે અમારા માટે પૂરતું અનન્ય હોવું જોઈએ:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // ડિફ defaultલ્ટ રૂપે, Unix (મને લાગે છે?) પર શું થાય છે, જેમ કે રજિસ્ટરમાં સીએમડી મૂલ્યોને પસાર કરનારા Windows પર એબીઆઇનો ઉપયોગ કરો.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ડિફ defaultલ્ટ રૂપે optimપ્ટિમાઇઝ મોડમાંનું કમ્પાઇલર "mergefunc" નામનો પાસ ચલાવે છે જ્યાં તે સમાન દેખાતા કાર્યોને મર્જ કરશે.
            // બહાર નીકળે છે કેટલાક અંતર્ગત સમાન કોડ ઉત્પન્ન કરે છે અને તે એક સાથે બંધ થઈ જાય છે, એટલે કે એક માત્ર બીજામાં કૂદી જાય છે.
            // આ આ કાર્યને છૂટા કરવાના અમારા નિરીક્ષણને અવ્યવસ્થિત કરે છે અને અમે તેનો મોટો ચાહક નથી.
            //
            // આ પાસને નિષ્ફળ બનાવવા અને વિધેયોને મર્જ થવાથી અટકાવવા અમે કેટલાક કોડ જનરેટ કરીએ છીએ જે આસ્થાપૂર્વક કોડજેનની દ્રષ્ટિએ ખૂબ જ ચુસ્ત છે પરંતુ કોડને ફોલ્ડ થવાથી અટકાવવા માટે અન્યથા અનન્ય છે.
            //
            //
            // હમણાં Wasm32 પર આ ટાળી શકાય છે કારણ કે આ વિધેયો ઇનલાઇનમાં નથી જે અમારા પરીક્ષણોને તોડે છે કારણ કે દરેક આંતરિક એવું લાગે છે કે તે વિધેયોને બોલાવે છે.
            // બહાર કા functionsે છે કાર્યો કોઈપણ રીતે wasm32 પર મર્જ થવા માટે પૂરતા સમાન નથી.
            // આ ભૂલ rust-lang/rust#74320 પર ટ્રેક કરવામાં આવી છે.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}