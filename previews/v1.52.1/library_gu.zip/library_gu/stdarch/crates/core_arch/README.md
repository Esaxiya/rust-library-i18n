`core::arch` - ઝેડ રસ્ટ0 ઝેડની મુખ્ય પુસ્તકાલય આર્કિટેક્ચર-વિશિષ્ટ આંતરિક
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` મોડ્યુલ આર્કિટેક્ચર-આધારિત ઇન્ટિન્સિક્સ (દા.ત. સી.એમ.ડી.) ને લાગુ કરે છે.

# Usage 

`core::arch` `libcore` ના ભાગ રૂપે ઉપલબ્ધ છે અને તે `libstd` દ્વારા ફરીથી નિકાસ કરવામાં આવે છે.આ crate દ્વારા `core::arch` અથવા `std::arch` દ્વારા તેનો ઉપયોગ કરવાનું પસંદ કરો.
અસ્થિર સુવિધાઓ ઘણીવાર `feature(stdsimd)` દ્વારા રાત્રિના ઝેડ રસ્ટ 0 ઝેડમાં ઉપલબ્ધ હોય છે.

આ ઝેડ 0 ક્રેટ 0 ઝેડ દ્વારા `core::arch` નો ઉપયોગ કરવા માટે રાત્રિના ઝેડ રસ્ટ 0 ઝેડની જરૂર છે, અને તે ઘણીવાર તૂટી (અને કરે છે).ફક્ત આ કેસો કે જેમાં તમારે આ ઝેડ ક્રેટ 0 ઝેડ દ્વારા તેનો ઉપયોગ કરવાનું વિચારવું જોઈએ:

* જો તમારે જાતે `core::arch` ફરીથી કમ્પાઇલ કરવાની જરૂર હોય, દા.ત., વિશિષ્ટ લક્ષ્ય-સુવિધાઓ સાથે સક્ષમ છે જે `libcore`/`libstd` માટે સક્ષમ નથી.
Note: જો તમારે તેને બિન-માનક લક્ષ્ય માટે ફરીથી કમ્પાઈલ કરવાની જરૂર હોય, તો કૃપા કરીને આ ઝેડ 0 ક્રેટ 0 ઝેડને બદલે `xargo` નો ઉપયોગ કરવાનું પસંદ કરો અને `libcore`/`libstd` ને ફરીથી કમ્પાઈલ કરો.
  
* કેટલીક સુવિધાઓનો ઉપયોગ કરીને જે કદાચ અસ્થિર Rust સુવિધાઓ પાછળ પણ ઉપલબ્ધ ન હોય.અમે આને ઓછામાં ઓછું રાખવાનો પ્રયત્ન કરીએ છીએ.
જો તમારે આમાંની કેટલીક સુવિધાઓનો ઉપયોગ કરવાની જરૂર હોય, તો કૃપા કરીને કોઈ મુદ્દો ખોલો જેથી અમે તેમને રાત્રિના ઝેડ 0 રસ્ટ0 ઝેડમાં છીનવી શકીએ અને તમે ત્યાંથી તેનો ઉપયોગ કરી શકો.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` મુખ્યત્વે એમઆઈટી લાઇસન્સ અને ઝેડ 0 એપાચે0 ઝેડ લાઈસન્સ (સંસ્કરણ 2.0) બંનેની શરતો હેઠળ વિતરિત કરવામાં આવે છે, જેમાં વિવિધ BSD જેવા લાઇસેંસિસનો સમાવેશ થાય છે.

વિગતો માટે લાઇસન્સ-ઝેડ .0 એપીએચઝેડઝ અને લાઇસેંસ-એમઆઈટી જુઓ.

# Contribution

જ્યાં સુધી તમે સ્પષ્ટ રીતે અન્યથા જણાવશો નહીં ત્યાં સુધી, Apache-2.0 લાઇસન્સમાં વ્યાખ્યાયિત કર્યા મુજબ તમારા દ્વારા `core_arch` માં સમાવેશ કરવા માટે જાણી જોઈને રજૂ કરાયેલ કોઈપણ ફાળો, કોઈપણ વધારાની શરતો અથવા શરતો વિના, ઉપર મુજબ બેવડા પરવાનો રહેશે.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












