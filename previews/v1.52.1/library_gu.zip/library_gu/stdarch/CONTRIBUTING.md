# સ્ટdડાર્ચમાં ફાળો આપવો

`stdarch` crate એ યોગદાન સ્વીકારવા માટે તૈયાર કરતાં વધુ છે!પ્રથમ તમે સંભવત rep ભંડાર તપાસો અને ખાતરી કરો કે પરીક્ષણો તમારા માટે પસાર થાય છે:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

જ્યાં `<your-target-arch>` એ `rustup`, દા.ત. `x86_x64-unknown-linux-gnu` (કોઈપણ પૂર્વવર્તી `nightly-` અથવા સમાન વિના) ના ઉપયોગમાં લેવાતું લક્ષ્ય ટ્રિપલ છે.
એ પણ યાદ રાખો કે આ ભંડારને Rust ની રાત્રિ ચેનલની જરૂર છે!
ઉપરોક્ત પરીક્ષણો હકીકતમાં રાત્રિના ઝેડ ર્રસ્ટ0 ઝેડને તમારી સિસ્ટમ પર ડિફ defaultલ્ટ હોવું જરૂરી છે, તે સેટ કરવા માટે કે જે `rustup default nightly` (અને `rustup default stable` પાછું લાવવા માટે) નો ઉપયોગ કરે.

જો ઉપરનાં કોઈપણ પગલાં કામ ન કરે, [please let us know][new]!

આગળ તમે [find an issue][issues] ને સહાય માટે કરી શકો છો, અમે [`help wanted`][help] અને [`impl-period`][impl] ટsગ્સથી થોડા પસંદ કર્યા છે જે ખાસ કરીને થોડીક સહાયનો ઉપયોગ કરી શકે છે. 
તમને [#40][vendor] માં સૌથી વધુ રસ હોઈ શકે, x86 પરના તમામ વિક્રેતા ઇન્ટિન્સિક્સને અમલમાં મૂકશો.તે મુદ્દાને ક્યાંથી પ્રારંભ કરવું તે વિશેના કેટલાક સારા નિર્દેશકો મળ્યાં છે!

જો તમને સામાન્ય પ્રશ્નો મળી આવ્યા હોય તો મફતમાં [join us on gitter][gitter] અને આસપાસ પૂછો!પ્રશ્નો સાથે@બર્ન્ટસુશી અથવા@alexcrichton ક્યાં પિંગ નહીં કરો.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# સ્ટાર્ડ ઇન્ટર્નિક્સ માટે ઉદાહરણો કેવી રીતે લખવા

ત્યાં કેટલીક સુવિધાઓ છે જે આપેલ અંતર્ગતને યોગ્ય રીતે કાર્ય કરવા માટે સક્ષમ હોવી આવશ્યક છે અને જ્યારે સુવિધા સીપીયુ દ્વારા સપોર્ટેડ હોય ત્યારે ઉદાહરણ ફક્ત `cargo test --doc` દ્વારા ચલાવવું આવશ્યક છે.

પરિણામે, `rustdoc` દ્વારા પેદા થયેલ ડિફ defaultલ્ટ `fn main` કામ કરશે નહીં (મોટાભાગના કિસ્સાઓમાં).
અપેક્ષા મુજબ તમારું ઉદાહરણ કાર્ય કરે છે તેની ખાતરી કરવા માટે નીચે આપેલ માર્ગદર્શિકા તરીકે ઉપયોગ કરવાનો વિચાર કરો.

```rust
/// # // ફક્ત ઉદાહરણ છે તે સુનિશ્ચિત કરવા માટે અમને cfg_target_feचर જોઈએ
/// # // જ્યારે સીપીયુ સુવિધાને સપોર્ટ કરે છે ત્યારે `cargo test --doc` દ્વારા ચલાવવામાં આવે છે
/// # #![feature(cfg_target_feature)]
/// # // અમારે આંતરિક કામ કરવા માટે લક્ષ્ય_સુચિની જરૂર છે
/// # #![feature(target_feature)]
/// #
/// # // મૂળભૂત રીતે રસ્ટડોક `extern crate stdarch` નો ઉપયોગ કરે છે, પરંતુ અમને આની જરૂર છે
/// # // `#[macro_use]`
/// # # [મેક્રો_યુઝ] બાહ્ય ઝેડક્રેટ 0 ઝેડ સ્ટાર્ડચ;
/// #
/// # // વાસ્તવિક મુખ્ય કાર્ય
/// # fn main() {
/// #     // ફક્ત આ ચલાવો જો `<target feature>` સપોર્ટેડ છે
/// #     જો cfg_feचर_enabled! ("<target feature>"){
/// #         // એક `worker` ફંક્શન બનાવો કે જે ફક્ત ત્યારે જ ચલાવવામાં આવશે જો લક્ષ્ય સુવિધા હોય
/// #         // સમર્થિત છે અને ખાતરી કરો કે `target_feature` તમારા કાર્યકર માટે સક્ષમ છે
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         અસુરક્ષિત FN worker() {
/// // તમારા ઉદાહરણ અહીં લખો.વિશેષ વિશિષ્ટ અંતર્ગત અહીં કાર્ય કરશે!જંગલી જાઓ!
///
/// #         }
///
/// #         અસુરક્ષિત { worker(); }
/// #     }
/// # }
```

જો ઉપરના કેટલાક વાક્યરચનાને પરિચિત લાગતું નથી, તો [Rust Book] નો [Documentation as tests] વિભાગ `rustdoc` વાક્યરચનાને ખૂબ સારી રીતે વર્ણવે છે.
હંમેશની જેમ, [join us on gitter][gitter] માટે નિ feelસંકોચ અને અમને પૂછો કે તમે કોઈ સ્નેગ્સને ફટકો છો, અને `stdarch` ના દસ્તાવેજીકરણને સુધારવામાં મદદ કરવા બદલ આભાર!

# વૈકલ્પિક પરીક્ષણ સૂચનાઓ

સામાન્ય રીતે ભલામણ કરવામાં આવે છે કે તમે પરીક્ષણો ચલાવવા માટે `ci/run.sh` નો ઉપયોગ કરો.
જો કે આ તમારા માટે કામ કરશે નહીં, દા.ત. જો તમે Windows પર છો.

તે કિસ્સામાં તમે કોડ જનરેશનના પરીક્ષણ માટે `cargo +nightly test` અને `cargo +nightly test --release -p core_arch` ચલાવવા માટે પાછા પડી શકો છો.
નોંધો કે આને માટે રાત્રિના ટૂલચેન ઇન્સ્ટોલ કરવાની અને `rustc` માટે તમારા લક્ષ્ય ટ્રિપલ અને તેના સીપીયુ વિશે જાણવા જરૂરી છે.
ખાસ કરીને તમારે `TARGET` પર્યાવરણ ચલ સેટ કરવાની જરૂર છે જેમ તમે `ci/run.sh` માટે કરો છો.
આ ઉપરાંત લક્ષ્ય સુવિધાઓ સૂચવવા માટે તમારે `RUSTCFLAGS` (`C` ની જરૂર છે) સેટ કરવાની જરૂર છે, દા.ત. `RUSTCFLAGS="-C -target-features=+avx2"`.
જો તમે તમારા વર્તમાન સીપીયુની વિરુદ્ધ "just" વિકાસ કરી રહ્યાં છો તો તમે `-C -target-cpu=native` પણ સેટ કરી શકો છો.

ચેતવણી આપો કે જ્યારે તમે આ વૈકલ્પિક સૂચનાઓનો ઉપયોગ કરો છો, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], દા.ત.
સૂચના જનરેશન પરીક્ષણો નિષ્ફળ થઈ શકે છે કારણ કે ડિસએસેમ્બલરે તેમને નામ જુદા પાડ્યા, દા.ત.
તે સમાન વર્તન કરવા છતાં `aesenc` સૂચનોને બદલે `vaesenc` પેદા કરી શકે છે.
આ સૂચનાઓ સામાન્ય રીતે કરવામાં આવે તેના કરતા ઓછા પરીક્ષણો ચલાવે છે, તેથી આશ્ચર્ય થશો નહીં કે જ્યારે તમે છેવટે પુલ-વિનંતી કરો છો ત્યારે અહીં આવરી લેવામાં આવતી પરીક્ષણો માટે કેટલીક ભૂલો દેખાઈ શકે છે.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






