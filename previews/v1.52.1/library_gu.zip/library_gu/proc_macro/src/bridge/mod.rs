//! `proc_macro` ક્લાયન્ટ (પ્રોક મેક્રો ઝેડ 0 ક્રેટ 0 ઝેડ) અને એક્સ01 એક્સ સર્વર (કમ્પાઇલર ફ્રન્ટ-એન્ડ) વચ્ચે વાતચીત કરવા માટેનો આંતરિક ઇન્ટરફેસ.
//!
//! સંભવિત મેળ ખાતા Rust ABIs (દા.ત., stage0/bin/rustc વિ stage1/bin/rustc બુટસ્ટ્રેપ દરમિયાન) સાથેના વિવિધ કમ્પાઇલરો દ્વારા `proc_macro` ની બે નકલો (સમાન સ્ત્રોતમાંથી) ની સુરક્ષિત રીતે ઇન્ટરફેસિંગને મંજૂરી આપવા સીરીલાઇઝેશન (સી ABI બફર સાથે) અને અનન્ય પૂર્ણાંક હેન્ડલ્સ કાર્યરત છે.
//!
//!
//!
//!

#![deny(unsafe_code)]

use crate::{Delimiter, Level, LineColumn, Spacing};
use std::fmt;
use std::hash::Hash;
use std::marker;
use std::mem;
use std::ops::Bound;
use std::panic;
use std::sync::atomic::AtomicUsize;
use std::sync::Once;
use std::thread;

/// સર્વર RPC API નું વર્ણન કરતા હાયર-ઓર્ડર મેક્રો, ટાઇપ-સેફ Rust API ના સ્વચાલિત પે generationીને, ક્લાયંટ-સાઇડ અને સર્વર-સાઇડ બંનેને મંજૂરી આપે છે.
///
/// `with_api!(MySelf, my_self, my_macro)` આમાં વિસ્તરે છે:
///
/// ```rust,ignore (pseudo-code)
/// my_macro! {
///     // ...
///     Literal {
///         // ...
///         fn character(ch: char) -> MySelf::Literal;
///         // ...
///         fn span(my_self: &MySelf::Literal) -> MySelf::Span;
///         fn set_span(my_self: &mut MySelf::Literal, span: MySelf::Span);
///     },
///     // ...
/// }
/// ```
///
/// પ્રથમ બે દલીલો ઘણા જુદા જુદા ઉપયોગકેસને સક્ષમ કરવા માટે, દલીલોનાં નામ અને argument/return પ્રકારોને કસ્ટમાઇઝ કરવા માટે આપે છે:
///
/// જો `my_self` ફક્ત `self` છે, તો પછી દરેક `fn` હસ્તાક્ષર એક પદ્ધતિ માટે જેમ વાપરી શકાય છે.
/// જો તે બીજું કંઇ પણ છે (વ્યવહારમાં `self_`), તો પછી સહીઓ પર કોઈ વિશેષ `self` દલીલ હોતી નથી, અને તેથી, તે રજૂ કરી શકે છે તેનાથી અલગ રજૂઆત થઈ શકે છે.
///
///
/// જો `MySelf` ફક્ત `Self` છે, તો પછી પ્રકારો ફક્ત trait અથવા trait ઇમ્પ્લની અંદર માન્ય છે, જ્યાં trait એ દરેક API પ્રકારો સાથે સંકળાયેલ પ્રકારો છે.
/// જો બિન-સંકળાયેલ પ્રકારો ઇચ્છિત હોય, તો `Self` ને બદલે મોડ્યુલ નામ (વ્યવહારમાં `self`) નો ઉપયોગ કરી શકાય છે.
///
///
///
///
macro_rules! with_api {
    ($S:ident, $self:ident, $m:ident) => {
        $m! {
            FreeFunctions {
                fn drop($self: $S::FreeFunctions);
                fn track_env_var(var: &str, value: Option<&str>);
            },
            TokenStream {
                fn drop($self: $S::TokenStream);
                fn clone($self: &$S::TokenStream) -> $S::TokenStream;
                fn new() -> $S::TokenStream;
                fn is_empty($self: &$S::TokenStream) -> bool;
                fn from_str(src: &str) -> $S::TokenStream;
                fn to_string($self: &$S::TokenStream) -> String;
                fn from_token_tree(
                    tree: TokenTree<$S::Group, $S::Punct, $S::Ident, $S::Literal>,
                ) -> $S::TokenStream;
                fn into_iter($self: $S::TokenStream) -> $S::TokenStreamIter;
            },
            TokenStreamBuilder {
                fn drop($self: $S::TokenStreamBuilder);
                fn new() -> $S::TokenStreamBuilder;
                fn push($self: &mut $S::TokenStreamBuilder, stream: $S::TokenStream);
                fn build($self: $S::TokenStreamBuilder) -> $S::TokenStream;
            },
            TokenStreamIter {
                fn drop($self: $S::TokenStreamIter);
                fn clone($self: &$S::TokenStreamIter) -> $S::TokenStreamIter;
                fn next(
                    $self: &mut $S::TokenStreamIter,
                ) -> Option<TokenTree<$S::Group, $S::Punct, $S::Ident, $S::Literal>>;
            },
            Group {
                fn drop($self: $S::Group);
                fn clone($self: &$S::Group) -> $S::Group;
                fn new(delimiter: Delimiter, stream: $S::TokenStream) -> $S::Group;
                fn delimiter($self: &$S::Group) -> Delimiter;
                fn stream($self: &$S::Group) -> $S::TokenStream;
                fn span($self: &$S::Group) -> $S::Span;
                fn span_open($self: &$S::Group) -> $S::Span;
                fn span_close($self: &$S::Group) -> $S::Span;
                fn set_span($self: &mut $S::Group, span: $S::Span);
            },
            Punct {
                fn new(ch: char, spacing: Spacing) -> $S::Punct;
                fn as_char($self: $S::Punct) -> char;
                fn spacing($self: $S::Punct) -> Spacing;
                fn span($self: $S::Punct) -> $S::Span;
                fn with_span($self: $S::Punct, span: $S::Span) -> $S::Punct;
            },
            Ident {
                fn new(string: &str, span: $S::Span, is_raw: bool) -> $S::Ident;
                fn span($self: $S::Ident) -> $S::Span;
                fn with_span($self: $S::Ident, span: $S::Span) -> $S::Ident;
            },
            Literal {
                fn drop($self: $S::Literal);
                fn clone($self: &$S::Literal) -> $S::Literal;
                fn debug_kind($self: &$S::Literal) -> String;
                fn symbol($self: &$S::Literal) -> String;
                fn suffix($self: &$S::Literal) -> Option<String>;
                fn integer(n: &str) -> $S::Literal;
                fn typed_integer(n: &str, kind: &str) -> $S::Literal;
                fn float(n: &str) -> $S::Literal;
                fn f32(n: &str) -> $S::Literal;
                fn f64(n: &str) -> $S::Literal;
                fn string(string: &str) -> $S::Literal;
                fn character(ch: char) -> $S::Literal;
                fn byte_string(bytes: &[u8]) -> $S::Literal;
                fn span($self: &$S::Literal) -> $S::Span;
                fn set_span($self: &mut $S::Literal, span: $S::Span);
                fn subspan(
                    $self: &$S::Literal,
                    start: Bound<usize>,
                    end: Bound<usize>,
                ) -> Option<$S::Span>;
            },
            SourceFile {
                fn drop($self: $S::SourceFile);
                fn clone($self: &$S::SourceFile) -> $S::SourceFile;
                fn eq($self: &$S::SourceFile, other: &$S::SourceFile) -> bool;
                fn path($self: &$S::SourceFile) -> String;
                fn is_real($self: &$S::SourceFile) -> bool;
            },
            MultiSpan {
                fn drop($self: $S::MultiSpan);
                fn new() -> $S::MultiSpan;
                fn push($self: &mut $S::MultiSpan, span: $S::Span);
            },
            Diagnostic {
                fn drop($self: $S::Diagnostic);
                fn new(level: Level, msg: &str, span: $S::MultiSpan) -> $S::Diagnostic;
                fn sub(
                    $self: &mut $S::Diagnostic,
                    level: Level,
                    msg: &str,
                    span: $S::MultiSpan,
                );
                fn emit($self: $S::Diagnostic);
            },
            Span {
                fn debug($self: $S::Span) -> String;
                fn def_site() -> $S::Span;
                fn call_site() -> $S::Span;
                fn mixed_site() -> $S::Span;
                fn source_file($self: $S::Span) -> $S::SourceFile;
                fn parent($self: $S::Span) -> Option<$S::Span>;
                fn source($self: $S::Span) -> $S::Span;
                fn start($self: $S::Span) -> LineColumn;
                fn end($self: $S::Span) -> LineColumn;
                fn join($self: $S::Span, other: $S::Span) -> Option<$S::Span>;
                fn resolved_at($self: $S::Span, at: $S::Span) -> $S::Span;
                fn source_text($self: $S::Span) -> Option<String>;
            },
        }
    };
}

// FIXME(eddyb) આ દરેક દલીલ માટે `encode` ને ક fromલ કરે છે, પરંતુ વિપરીત, `&mut` દલીલો દ્વારા શરૂ કરાયેલા ઉધારથી ઉધ્ધારથી બચવા માટે.
//
macro_rules! reverse_encode {
    ($writer:ident;) => {};
    ($writer:ident; $first:ident $(, $rest:ident)*) => {
        reverse_encode!($writer; $($rest),*);
        $first.encode(&mut $writer, &mut ());
    }
}

// FIXME(eddyb) આ દરેક દલીલ માટે `decode` ને ક fromલ કરે છે, પરંતુ વિપરીત, `&mut` દલીલો દ્વારા શરૂ કરાયેલા ઉધારથી ઉધ્ધારથી બચવા માટે.
//
macro_rules! reverse_decode {
    ($reader:ident, $s:ident;) => {};
    ($reader:ident, $s:ident; $first:ident: $first_ty:ty $(, $rest:ident: $rest_ty:ty)*) => {
        reverse_decode!($reader, $s; $($rest: $rest_ty),*);
        let $first = <$first_ty>::decode(&mut $reader, $s);
    }
}

#[allow(unsafe_code)]
mod buffer;
#[forbid(unsafe_code)]
pub mod client;
#[allow(unsafe_code)]
mod closure;
#[forbid(unsafe_code)]
mod handle;
#[macro_use]
#[forbid(unsafe_code)]
mod rpc;
#[allow(unsafe_code)]
mod scoped_cell;
#[forbid(unsafe_code)]
pub mod server;

use buffer::Buffer;
pub use rpc::PanicMessage;
use rpc::{Decode, DecodeMut, Encode, Reader, Writer};

/// સર્વર અને ક્લાયંટ વચ્ચે સક્રિય જોડાણ.
/// સર્વર બ્રિજ બનાવે છે (`Bridge::run_server` માં `Bridge::run_server`), પછી તેને `client::Client` ના `run` ક્ષેત્રમાં ફંક્શન પોઇન્ટર દ્વારા ક્લાયંટને પહોંચાડે છે.
/// ક્લાયંટ તેની એક્ઝેક્યુશન દરમિયાન XLX માં તેની `Bridge` ની નકલ રાખે છે (`client.rs` માં `Bridge::{enter, with}`).
///
///
#[repr(C)]
pub struct Bridge<'a> {
    /// ફરીથી વાપરી શકાય તેવું બફર (ફક્ત `સ્પષ્ટ edડ, ક્યારેય સંકોચતું નથી), મુખ્યત્વે વિનંતીઓ કરવા માટે, પણ ક્લાયંટને ઇનપુટ પસાર કરવા માટે પણ વપરાય છે.
    ///
    cached_buffer: Buffer<u8>,

    /// સર્વર-સાઇડ ફંક્શન કે જે ક્લાયંટ વિનંતીઓ કરવા માટે વાપરે છે.
    dispatch: closure::Closure<'a, Buffer<u8>, Buffer<u8>>,

    /// જો 'true', હંમેશાં ડિફ defaultલ્ટ panic hook પર વિનંતી કરો
    force_show_panics: bool,
}

impl<'a> !Sync for Bridge<'a> {}
impl<'a> !Send for Bridge<'a> {}

#[forbid(unsafe_code)]
#[allow(non_camel_case_types)]
mod api_tags {
    use super::rpc::{DecodeMut, Encode, Reader, Writer};

    macro_rules! declare_tags {
        ($($name:ident {
            $(fn $method:ident($($arg:ident: $arg_ty:ty),* $(,)?) $(-> $ret_ty:ty)*;)*
        }),* $(,)?) => {
            $(
                pub(super) enum $name {
                    $($method),*
                }
                rpc_encode_decode!(enum $name { $($method),* });
            )*


            pub(super) enum Method {
                $($name($name)),*
            }
            rpc_encode_decode!(enum Method { $($name(m)),* });
        }
    }
    with_api!(self, self, declare_tags);
}

/// trait ઇમ્પ્લ રવાનગીને મંજૂરી આપવા માટે સંકળાયેલ પ્રકારોને લપેટવામાં સહાયક.
/// તે છે, સામાન્ય રીતે `T::Foo` અને `T::Bar` માટે ઇમ્પલ્સની જોડી ઓવરલેપ થઈ શકે છે, પરંતુ જો ઇમ્પ્લ્સ, તેના બદલે, `Marked<T::Foo, Foo>` અને `Marked<T::Bar, Bar>` જેવા પ્રકારો પર હોય, તો તેઓ કરી શકતા નથી.
///
///
trait Mark {
    type Unmarked;
    fn mark(unmarked: Self::Unmarked) -> Self;
}

/// `Mark::mark` દ્વારા વીંટાળેલા પ્રકારો અનwવરપ કરો (વિગતો માટે `Mark` જુઓ)
trait Unmark {
    type Unmarked;
    fn unmark(self) -> Self::Unmarked;
}

#[derive(Copy, Clone, PartialEq, Eq, Hash)]
struct Marked<T, M> {
    value: T,
    _marker: marker::PhantomData<M>,
}

impl<T, M> Mark for Marked<T, M> {
    type Unmarked = T;
    fn mark(unmarked: Self::Unmarked) -> Self {
        Marked { value: unmarked, _marker: marker::PhantomData }
    }
}
impl<T, M> Unmark for Marked<T, M> {
    type Unmarked = T;
    fn unmark(self) -> Self::Unmarked {
        self.value
    }
}
impl<T, M> Unmark for &'a Marked<T, M> {
    type Unmarked = &'a T;
    fn unmark(self) -> Self::Unmarked {
        &self.value
    }
}
impl<T, M> Unmark for &'a mut Marked<T, M> {
    type Unmarked = &'a mut T;
    fn unmark(self) -> Self::Unmarked {
        &mut self.value
    }
}

impl<T: Mark> Mark for Option<T> {
    type Unmarked = Option<T::Unmarked>;
    fn mark(unmarked: Self::Unmarked) -> Self {
        unmarked.map(T::mark)
    }
}
impl<T: Unmark> Unmark for Option<T> {
    type Unmarked = Option<T::Unmarked>;
    fn unmark(self) -> Self::Unmarked {
        self.map(T::unmark)
    }
}

macro_rules! mark_noop {
    ($($ty:ty),* $(,)?) => {
        $(
            impl Mark for $ty {
                type Unmarked = Self;
                fn mark(unmarked: Self::Unmarked) -> Self {
                    unmarked
                }
            }
            impl Unmark for $ty {
                type Unmarked = Self;
                fn unmark(self) -> Self::Unmarked {
                    self
                }
            }
        )*
    }
}
mark_noop! {
    (),
    bool,
    char,
    &'a [u8],
    &'a str,
    String,
    Delimiter,
    Level,
    LineColumn,
    Spacing,
    Bound<usize>,
}

rpc_encode_decode!(
    enum Delimiter {
        Parenthesis,
        Brace,
        Bracket,
        None,
    }
);
rpc_encode_decode!(
    enum Level {
        Error,
        Warning,
        Note,
        Help,
    }
);
rpc_encode_decode!(struct LineColumn { line, column });
rpc_encode_decode!(
    enum Spacing {
        Alone,
        Joint,
    }
);

#[derive(Clone)]
pub enum TokenTree<G, P, I, L> {
    Group(G),
    Punct(P),
    Ident(I),
    Literal(L),
}

impl<G: Mark, P: Mark, I: Mark, L: Mark> Mark for TokenTree<G, P, I, L> {
    type Unmarked = TokenTree<G::Unmarked, P::Unmarked, I::Unmarked, L::Unmarked>;
    fn mark(unmarked: Self::Unmarked) -> Self {
        match unmarked {
            TokenTree::Group(tt) => TokenTree::Group(G::mark(tt)),
            TokenTree::Punct(tt) => TokenTree::Punct(P::mark(tt)),
            TokenTree::Ident(tt) => TokenTree::Ident(I::mark(tt)),
            TokenTree::Literal(tt) => TokenTree::Literal(L::mark(tt)),
        }
    }
}
impl<G: Unmark, P: Unmark, I: Unmark, L: Unmark> Unmark for TokenTree<G, P, I, L> {
    type Unmarked = TokenTree<G::Unmarked, P::Unmarked, I::Unmarked, L::Unmarked>;
    fn unmark(self) -> Self::Unmarked {
        match self {
            TokenTree::Group(tt) => TokenTree::Group(tt.unmark()),
            TokenTree::Punct(tt) => TokenTree::Punct(tt.unmark()),
            TokenTree::Ident(tt) => TokenTree::Ident(tt.unmark()),
            TokenTree::Literal(tt) => TokenTree::Literal(tt.unmark()),
        }
    }
}

rpc_encode_decode!(
    enum TokenTree<G, P, I, L> {
        Group(tt),
        Punct(tt),
        Ident(tt),
        Literal(tt),
    }
);