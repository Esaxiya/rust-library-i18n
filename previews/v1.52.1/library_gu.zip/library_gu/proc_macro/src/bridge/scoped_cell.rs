//! `Cell` (scoped) અસ્તિત્વમાંના જીવનકાળ માટેનો પ્રકાર

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// જીવનકાળ સાથે લેમ્બડા એપ્લિકેશન લખો.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// જીવનપદ્ધતિ લેમ્બેડા લખો, એટલે કે, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) X0Nwtype0Z FIXME(#52812) `&'a mut <T as ApplyL<'b>>::Out` સાથે બદલો સાથે પ્રક્ષેપણ મર્યાદાઓ આસપાસ કામ કરો
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` ચલાવતા સમયે `self` માં `replacement` નું મૂલ્ય સુયોજિત કરે છે, જે પરસ્પર, જૂની કિંમત મેળવે છે.
    /// `f` બહાર નીકળ્યા પછી, X0 `f` દ્વારા કરવામાં આવેલા ફેરફારો સહિત, panic દ્વારા પણ જૂની કિંમત પુન restoredસ્થાપિત કરવામાં આવશે.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// રેપર જે સુનિશ્ચિત કરે છે કે સેલ હંમેશા ભરાઈ જાય છે (મૂળ સ્થિતિ સાથે, વૈકલ્પિક રૂપે `f` દ્વારા બદલાયેલ છે), પછી ભલે `f` ગભરાઈ ગયો હોય.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` ચલાવતા સમયે `self` માં મૂલ્ય `value` પર સેટ કરે છે.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}