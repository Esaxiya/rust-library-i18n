//! નવા મેક્રોની વ્યાખ્યા કરતી વખતે મેક્રો લેખકો માટે સપોર્ટ લાઇબ્રેરી.
//!
//! આ લાઇબ્રેરી, પ્રમાણભૂત વિતરણ દ્વારા પૂરું પાડવામાં આવેલ છે, જેમ કે ફંક્શન જેવા મેક્રોઝ `#[proc_macro]`, મેક્રો એટ્રિબ્યુટીઝ `#[proc_macro_attribute]` અને કસ્ટમ ડેરિવેટ એટ્રિબ્યુટ્સ`#[પ્રો_મેક્રો_ડેરિવ] as જેવા પ્રોસેસીયલીલી રીતે વ્યાખ્યાયિત મેક્રો વ્યાખ્યાઓના ઇંટરફેસમાં ઉપયોગમાં લેવાય છે.
//!
//!
//! વધુ માટે [the book] જુઓ.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// નક્કી કરે છે કે પ્રોક_મેક્રો હાલમાં ચાલી રહેલા પ્રોગ્રામમાં accessક્સેસિબલ બનાવવામાં આવ્યો છે કે કેમ.
///
/// પ્રોક_મેક્રો ઝેડ 0 ક્રેટ 0 ઝેડ ફક્ત પ્રોસેસ્શનલ મેક્રોના અમલીકરણની અંદર ઉપયોગ માટે છે.જો આ બિલ્ડ સ્ક્રિપ્ટ અથવા એકમ પરીક્ષણ અથવા સામાન્ય ઝેડ રસ્ટ0 ઝેડ દ્વિસંગી જેવા પ્રોસેસીશનલ મેક્રોની બહારથી જો આ ઝેડ 0 ક્રેટેટ ઝેડ ઝેડ 0 પicનિક 0 ઝેડમાંના તમામ કાર્યો.
///
/// ઝેડ રસ્ટ0 ઝેડ લાઇબ્રેરીઓ માટે વિચારણા સાથે કે જે બંને મેક્રો અને નોન-મ casesક્રો ઉપયોગના કેસોને ટેકો આપવા માટે રચાયેલ છે, `proc_macro::is_available()` એ શોધી કા toવાનો બિન-ગભરાટ રસ્તો પૂરો પાડે છે કે પ્રોક_મેક્રોના API નો ઉપયોગ કરવા માટે જરૂરી ઇન્ફ્રાસ્ટ્રક્ચર હાલમાં ઉપલબ્ધ છે કે નહીં.
/// જો પ્રક્રિયાગત મેક્રોની અંદરથી માંગ કરવામાં આવે તો સાચું પરત કરે છે, જો બીજા કોઈપણ બાઈનરીથી માંગ કરવામાં આવે તો ખોટું.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// આ crate દ્વારા પ્રદાન થયેલ મુખ્ય પ્રકાર, tokens ના અમૂર્ત પ્રવાહનું પ્રતિનિધિત્વ કરે છે, અથવા, ખાસ કરીને, token વૃક્ષોનો ક્રમ.
/// પ્રકાર તે token વૃક્ષો પર પુનરાવર્તિત કરવા માટે ઇન્ટરફેસો પ્રદાન કરે છે અને તેનાથી વિપરિત, ઘણા ઝેડ ટોકન ઝેડ ઝાડને એક પ્રવાહમાં એકત્રિત કરે છે.
///
///
/// આ બંને `#[proc_macro]`, `#[proc_macro_attribute]` અને `#[proc_macro_derive]` વ્યાખ્યાઓનું ઇનપુટ અને આઉટપુટ છે.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` થી ભૂલ પાછા આવી.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ઝાડ ધરાવતા ખાલી `TokenStream` પરત કરે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// તપાસો કે જો આ `TokenStream` ખાલી છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// tokens માં શબ્દમાળા તોડવા અને તે tokens ને token પ્રવાહમાં પાર્સ કરવાના પ્રયાસો.
/// અસંખ્ય કારણોસર નિષ્ફળ થઈ શકે છે, ઉદાહરણ તરીકે, જો શબ્દમાળામાં અસંતુલિત ડિલિમિટર અથવા ભાષામાં અસ્તિત્વમાં નથી તેવા અક્ષરો શામેલ છે.
///
/// વિશ્લેષિત પ્રવાહમાંના બધા ઝેડ 0 ટોકન્સ 0 ઝેડને `Span::call_site()` સ્પાન્સ મળે છે.
///
/// NOTE: કેટલીક ભૂલો `LexError` પરત કરવાને બદલે panics નું કારણ બની શકે છે.અમે પછીથી આ ભૂલોને `LexError` માં બદલવાનો અધિકાર અનામત રાખીએ છીએ.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// ઝેડ ટોકન0 ઝેડ પ્રવાહને એક તાર તરીકે છાપે છે જે સંભવતen en ટોકનટ્રી: : જૂથ` સિવાય, `Delimiter::None` સીમાંકક અને નકારાત્મક આંકડાકીય અક્ષરો સિવાય, સમાન ઝેડ ટોકન ઝેડ પ્રવાહ (મોડ્યુલો સ્પાન્સ) માં કમળ વિના બદલી શકાય તેવું માનવામાં આવે છે.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ડિબગીંગ માટે અનુકૂળ ફોર્મમાં ઝેડ ટtoકન 0 ઝેડ છાપે છે.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// એક token વૃક્ષ ધરાવતો token પ્રવાહ બનાવે છે.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// એક જ પ્રવાહમાં સંખ્યાબંધ token વૃક્ષો એકત્રિત કરે છે.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// ઝેડ ટોકટોન ઝેડ સ્ટ્રીમ્સ પરનું એક "flattening" ,પરેશન, બહુવિધ token સ્ટ્રીમ્સમાંથી token વૃક્ષોને એક જ પ્રવાહમાં એકઠા કરે છે.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) શક્ય optimપ્ટિમાઇઝ્ડ અમલીકરણ if/when નો ઉપયોગ કરો.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ઇટરેટર્સ જેવા `TokenStream` પ્રકાર માટે જાહેર અમલીકરણ વિગતો.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `ટોકનસ્ટ્રીમ`` ટોકનટ્રીઝ ઉપર એક ઇરેટર.
    /// પુનરાવર્તન એ "shallow" છે, દા.ત., પુનરાવર્તિત સીમાંકિત જૂથોમાં ફરી આવતું નથી, અને સંપૂર્ણ જૂથોને token વૃક્ષો તરીકે આપે છે.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` મનસ્વી tokens સ્વીકારે છે અને ઇનપુટનું વર્ણન કરતી `TokenStream` માં વિસ્તરે છે.
/// ઉદાહરણ તરીકે, `quote!(a + b)` એક અભિવ્યક્તિ પેદા કરશે, જેનું મૂલ્યાંકન કરવામાં આવે ત્યારે, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// અનક્વોટીંગ એ `$` સાથે કરવામાં આવે છે, અને અવગણના કરાયેલ શબ્દ તરીકે એકલ આગામી ઓળખાવીને કામ કરે છે.
/// ખુદ `$` ને ટાંકવા માટે, `$$` નો ઉપયોગ કરો.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// મેક્રો વિસ્તરણ માહિતી સાથે સ્રોત કોડનો એક ક્ષેત્ર.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// સ્પેન `self` પર આપેલ `message` સાથે એક નવું `Diagnostic` બનાવે છે.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// મ spક્રો ડેફિનેશન સાઇટ પર ઉકેલાતી ગાળો.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// વર્તમાન પ્રક્રિયાગત મેક્રોના વિનંતીનો સમયગાળો.
    /// આ ગાળા સાથે બનાવેલ ઓળખકારો ઉકેલાઈ જશે જાણે કે તેઓ સીધા મેક્રો ક locationલ સ્થાન (ક-લ-સાઇટ સ્વચ્છતા) અને મેક્રો ક callલ સાઇટ પરનો અન્ય કોડ લખવામાં આવ્યાં છે.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// એક સ્પેન જે `macro_rules` સ્વચ્છતાનું પ્રતિનિધિત્વ કરે છે, અને કેટલીકવાર મેક્રો ડેફિનેશન સાઇટ (સ્થાનિક ચલો, લેબલ્સ, `$crate`) અને ક્યારેક મેક્રો ક callલ સાઇટ (બાકીનું બધું) પર ઉકેલે છે.
    ///
    /// સ્પાન સ્થાન ક callલ-સાઇટથી લેવામાં આવ્યું છે.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// મૂળ સ્રોત ફાઇલ જેમાં આ ગાળો નિર્દેશ કરે છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// અગાઉના મેક્રો વિસ્તરણમાં ઝેડ ટોકન્સ0 ઝેડ માટેનું `Span`, જેમાંથી `self` જનરેટ થયું હતું, જો કોઈ હોય તો.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// મૂળ સ્રોત કોડ માટેનો સમયગાળો જે `self` જનરેટ થયો હતો.
    /// જો આ `Span` અન્ય મેક્રો વિસ્તરણમાંથી પેદા કરવામાં આવ્યો ન હતો, તો વળતર મૂલ્ય `*self` જેટલું જ છે.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// આ ગાળા માટે સ્રોત ફાઇલમાં પ્રારંભિક line/column મેળવે છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// આ ગાળા માટે સ્રોત ફાઇલમાં સમાપ્ત થતા line/column મળે છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` અને `other` ને શામેલ કરીને એક નવી સ્પ spન બનાવે છે.
    ///
    /// જો `self` અને `other` વિવિધ ફાઇલોમાંથી હોય તો `None` આપે છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` જેવી જ line/column માહિતી સાથે એક નવું સ્પanન બનાવે છે પરંતુ તે પ્રતીકોનું નિરાકરણ કરે છે જાણે તે `other` પર હતું.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` જેવી જ નામના રીઝોલ્યુશન વર્તણૂક સાથે પરંતુ `other` ની line/column માહિતી સાથે એક નવી સ્પanન બનાવે છે.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// તે સરખું છે કે નહીં તે જોવા માટે તુલના કરો.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ગાળા પાછળનો સ્રોત ટેક્સ્ટ પાછો આપે છે.
    /// આ જગ્યાઓ અને ટિપ્પણીઓ સહિત મૂળ સ્રોત કોડને સાચવે છે.
    /// તે ફક્ત ત્યારે જ પરિણામ આપે છે જો ગાળો વાસ્તવિક સ્રોત કોડને અનુરૂપ હોય.
    ///
    /// Note: મેક્રોનું અવલોકનયોગ્ય પરિણામ ફક્ત tokens પર આધાર રાખવો જોઈએ, આ સ્રોત ટેક્સ્ટ પર નહીં.
    ///
    /// આ કાર્યનું પરિણામ એ માત્ર ડાયગ્નોસ્ટિક્સ માટે વાપરવાનો શ્રેષ્ઠ પ્રયાસ છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ડિબગીંગ માટે અનુકૂળ ફોર્મમાં સ્પanન છાપે છે.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// એક લાઇન-ક columnલમ જોડી જે `Span` ના પ્રારંભ અથવા અંતને રજૂ કરે છે.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// સ્રોત ફાઇલમાં 1 અનુક્રમિત લાઇન, જેના પર ગાળો શરૂ થાય છે અથવા (inclusive) સમાપ્ત થાય છે.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// સ્રોત ફાઇલમાં 0-અનુક્રમિત ક columnલમ (UTF-8 અક્ષરોમાં) જેના પર ગાળો શરૂ થાય છે અથવા (inclusive) સમાપ્ત થાય છે.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// આપેલ `Span` ની સ્રોત ફાઇલ.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// આ સ્રોત ફાઇલનો માર્ગ મેળવે છે.
    ///
    /// ### Note
    /// જો આ `SourceFile` સાથે સંકળાયેલ કોડ સ્પેન બાહ્ય મcક્રો, આ મેક્રો દ્વારા જનરેટ કરવામાં આવ્યો હતો, તો તે ફાઇલસિસ્ટમ પરનો વાસ્તવિક પાથ નહીં હોય.
    /// તપાસવા માટે [`is_real`] નો ઉપયોગ કરો.
    ///
    /// એ પણ નોંધો કે જો `is_real` `true` પરત કરે છે, તો પણ જો `--remap-path-prefix` કમાન્ડ લાઇન પર પસાર થયો હોય, તો આપેલ પાથ ખરેખર માન્ય નથી.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// જો આ સ્રોત ફાઇલ એક વાસ્તવિક સ્રોત ફાઇલ છે અને બાહ્ય મcક્રોના વિસ્તરણ દ્વારા જનરેટ થયેલ નથી, તો `true` આપે છે.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ઇન્ટરક્રેટ સ્પાન્સ લાગુ ન થાય ત્યાં સુધી આ એક હેક છે અને બાહ્ય મેક્રોઝમાં પેદા થયેલા સ્પાન્સ માટે અમારી પાસે વાસ્તવિક સ્રોત ફાઇલો હોઈ શકે છે.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// એક જ ઝેડ ટોકટોન0 ઝેડ અથવા ઝેડ ટોકન ઝેડ ઝાડ (જેમ કે, X01 એક્સ) નો સીમિત ક્રમ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// કૌંસ સીમાદાતાઓથી ઘેરાયેલ એક token પ્રવાહ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ઓળખકર્તા.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// એક જ વિરામચિત્ર પાત્ર (`+`, `,`, `$`, વગેરે).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// શાબ્દિક અક્ષર (`'a'`), શબ્દમાળા (`"hello"`), નંબર (`2.3`), વગેરે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// સમાયેલ ઝેડ ટોકટોન ઝેડ અથવા સીમિત પ્રવાહની `span` પદ્ધતિને સોંપીને, આ વૃક્ષના ગાળાને પરત આપે છે.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *ફક્ત આ token* માટે સ્પાન ગોઠવે છે.
    ///
    /// નોંધ લો કે જો આ ઝેડ ટુટેન0 ઝેડ એક X00 એક્સ છે, તો પછી આ પદ્ધતિ આંતરિક ઝેડ ટોટોકેન્સેઝેડના દરેકના ક્ષેત્રને ગોઠવશે નહીં, આ દરેક ચલની `set_span` પદ્ધતિને સોંપશે.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ડિબગીંગ માટે અનુકૂળ ફોર્મમાં ઝેડ ટtoકન 0 ઝેડ ટ્રી છાપે છે.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // આમાંથી દરેકનું ઉદ્દભવેલું ડિબગમાં સ્ટ્રક્ટ પ્રકારનું નામ છે, તેથી વધારાના સ્તરની રીતથી કંટાળો નહીં
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// ઝેડ ટોકન 0 ઝેડ ટ્રીને એક તાર તરીકે છાપે છે જે સંભવત` en ટોકનટ્રી: : જૂથ-સિવાય `Delimiter::None` સીમાંકક અને નકારાત્મક આંકડાકીય અક્ષરો સિવાય, સમાન ઝેડ ટુટેન 0 ઝેડ ટ્રી (મોડ્યુલો સ્પાન્સ) માં કમળ વિના બદલી શકાય તેવું માનવામાં આવે છે.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// સીમાંકિત token પ્રવાહ.
///
/// એક `Group` આંતરિકમાં એક `TokenStream` સમાવે છે જે surrounded ડિલિમિટર દ્વારા ઘેરાયેલું છે.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token ઝાડનો ક્રમ કેવી રીતે સીમાંકિત થાય છે તેનું વર્ણન કરે છે.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// એક ગર્ભિત ડિલિમિટર, જે, ઉદાહરણ તરીકે, "macro variable" `$var` માંથી આવતા tokens ની આસપાસ દેખાઈ શકે છે.
    /// `$var * 3` જેવા કેસોમાં `$var` `1 + 2` હોય તેવા કિસ્સામાં ઓપરેટરની પ્રાથમિકતાઓને સાચવવી મહત્વપૂર્ણ છે.
    /// ગર્ભિત સીમાંકક શબ્દમાળા દ્વારા token પ્રવાહની રાઉન્ડટ્રીપમાં ટકી શકશે નહીં.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// આપેલ ડિલિમિટર અને token સ્ટ્રીમ સાથે એક નવું `Group` બનાવે છે.
    ///
    /// આ કન્સ્ટ્રક્ટર આ જૂથ માટેનો સમયગાળો `Span::call_site()` પર સેટ કરશે.
    /// ગાળો બદલવા માટે તમે નીચેની `set_span` પદ્ધતિનો ઉપયોગ કરી શકો છો.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// આ `Group` નો સીમાંકક પરત કરે છે
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// આ `Group` માં સીમાંકિત થયેલ tokens ના `TokenStream` પરત કરે છે.
    ///
    /// નોંધ લો કે પરત થયેલ token પ્રવાહમાં ઉપર આપેલ સીમાંકક શામેલ નથી.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// આ token પ્રવાહના સીમાદાતાઓ માટેનો સમયગાળો પાછો આપે છે, સમગ્ર `Group` ફેલાયેલો છે.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// આ જૂથના પ્રારંભિક સીમાંકક તરફ ઇશારો કરીને ગાળો આપે છે.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// આ જૂથના બંધ ડિલિમિટર તરફ પોઇન્ટ કરીને ગાળો આપે છે.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// આ `ગ્રુપ'ના સીમાંકકો માટેનો સમય ગોઠવે છે, પરંતુ તેના આંતરિક ઝેડ ટોકન્સ 0 ઝેડ નહીં.
    ///
    /// આ પદ્ધતિ **નહીં** આ જૂથ દ્વારા ફેલાયેલી બધી આંતરિક ઝેડ ટtoકન્સ0 ઝેડનો વિસ્તાર સેટ કરશે, પરંતુ તેનાથી તે ફક્ત `Group` ના સ્તરે સીમાંકિત ઝેડટોકensન્સ0 ઝેડનો વિસ્તાર સેટ કરશે.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// જૂથને એક શબ્દમાળા તરીકે છાપે છે જે સંભવત`en ટોકનટ્રી: : જૂથ` સિવાય `Delimiter::None` ડિલિમિટર્સ સાથેના જૂથ (મોડ્યુલો સ્પેન્સ) માં વિના મૂલ્યે રૂપાંતરિત થવું જોઈએ.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` એ `+`, `-` અથવા `#` જેવા એક જ વિરામચિત્ર પાત્ર છે.
///
/// `+=` જેવા મલ્ટિ-કેરેક્ટર operaપરેટર્સ `Punct` ના બે દાખલા તરીકે રજૂ થાય છે, `Spacing` ના વિવિધ સ્વરૂપો સાથે.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// શું `Punct` તરત જ બીજા `Punct` દ્વારા અનુસરવામાં આવે છે અથવા બીજા token અથવા ગોરા સ્પેસ દ્વારા અનુસરે છે.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// દા.ત., `+` એ `+ =`, `+ident` અથવા `+()` માં `Alone` છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// દા.ત., `+` એ `+=` અથવા `'#` માં `Joint` છે.
    /// આ ઉપરાંત, સિંગલ ક્વોટ `'` ઓળખકર્તાઓ સાથે જોડાવા માટે લાઇફટાઇમ `'ident` બનાવે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// આપેલ પાત્ર અને અંતરથી એક નવું `Punct` બનાવે છે.
    /// `ch` દલીલ એ ભાષા દ્વારા અનુમતિ આપેલ માન્ય વિરામચિત્ર પાત્ર હોવું આવશ્યક છે, નહીં તો કાર્ય panic કરશે.
    ///
    /// પરત આવેલા `Punct` માં `Span::call_site()` નો ડિફ defaultલ્ટ સમયગાળો હશે જે નીચે આપેલ `set_span` પદ્ધતિથી આગળ ગોઠવી શકાય છે.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// આ વિરામચિત્ર પાત્રનું મૂલ્ય `char` તરીકે આપે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// આ વિરામચિત્ર પાત્રનું અંતર પાછું આપે છે, તે સૂચવે છે કે ઝેડ ટોકન ઝેડ પ્રવાહમાં તે પછી બીજા `Punct` દ્વારા તુરંત જ અનુસરવામાં આવે છે, જેથી તેઓ સંભવિત રૂપે મલ્ટિ-કેરેક્ટર operatorપરેટર (`Joint`) માં જોડાઈ શકે, અથવા તે પછી કેટલાક અન્ય ઝેડ ટોકન ઝેડ અથવા વ્હાઇટસ્પેસ (`Alone`) આવે છે જેથી ઓપરેટર ચોક્કસપણે અંત.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// આ વિરામચિત્ર પાત્ર માટેનો સમય પાછો આપે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// આ વિરામચિહ્ન પાત્ર માટે સ્પાનને ગોઠવો.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// વિરામચિહ્ન પાત્રને એક શબ્દમાળા તરીકે છાપે છે જે એક સમાન પાત્રમાં વિના મૂલ્યે રૂપાંતરિત થવું જોઈએ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// એક ઓળખકર્તા (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// આપેલ `string` તેમજ ઉલ્લેખિત `span` સાથે એક નવું `Ident` બનાવે છે.
    /// `string` દલીલ ભાષા દ્વારા માન્ય માન્ય ઓળખકર્તા હોવી આવશ્યક છે (કીવર્ડ્સ સહિત, દા.ત. `self` અથવા `fn`)નહિંતર, કાર્ય panic કરશે.
    ///
    /// નોંધ લો કે હાલમાં X0rustc0Z માં `span`, આ ઓળખકર્તા માટેની સ્વચ્છતા માહિતીને ગોઠવે છે.
    ///
    /// આ સમય મુજબ, `Span::call_site()` સ્પષ્ટપણે "call-site" સ્વચ્છતાને પસંદ કરે છે એટલે કે આ ગાળા સાથે બનાવેલ ઓળખકર્તાઓ ઉકેલાઈ જશે જાણે કે તેઓ મેક્રો ક callલના સ્થાન પર સીધા જ લખેલા હતા, અને મેક્રો ક callલ સાઇટ પરનો અન્ય કોડ સંદર્ભ આપી શકશે. તેમને પણ.
    ///
    ///
    /// પાછળથી `Span::def_site()` જેવા સ્પેન્સ "definition-site" સ્વચ્છતાને પસંદ કરવા દેશે એટલે કે આ ગાળા સાથે બનાવેલ ઓળખકર્તાઓ મ theક્રો વ્યાખ્યાના સ્થાન પર ઉકેલાઈ જશે અને મેક્રો ક callલ સાઇટ પરનો અન્ય કોડ તેમનો સંદર્ભ આપી શકશે નહીં.
    ///
    /// સ્વચ્છતાના વર્તમાન મહત્વને કારણે આ કન્સ્ટ્રક્ટર, અન્ય ઝેડ ટtoકન્સ0 ઝેડથી વિપરીત, બાંધકામમાં `Span` નો ઉલ્લેખ કરવો જરૂરી છે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` જેવું જ છે, પરંતુ કાચો ઓળખકર્તા (`r#ident`) બનાવે છે.
    /// `string` દલીલ ભાષા દ્વારા માન્ય માન્ય ઓળખકર્તા હોઈ શકે છે (કીવર્ડ્સ સહિત, દા.ત. `fn`).
    /// કીવર્ડ્સ કે જે પાથ સેગમેન્ટમાં ઉપયોગી છે (દા.ત.
    /// `self`, `સુપર`) સપોર્ટેડ નથી, અને ઝેડ 0 સ્પેનિક0 ઝેડનું કારણ બનશે.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) દ્વારા પરત કરેલ સંપૂર્ણ શબ્દમાળાને સમાવીને, આ `Ident` નો ગાળો આપે છે.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// આ `Ident` ના ગાળાને ગોઠવે છે, સંભવત its તેના આરોગ્યપ્રદ સંદર્ભમાં ફેરફાર કરે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ઓળખકર્તાને એક શબ્દમાળા તરીકે છાપે છે જે નિ lossસહિત રૂપે સમાન ઓળખકર્તામાં પાછા ફેરવવું જોઈએ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// એક શાબ્દિક શબ્દમાળા (`"hello"`), બાઇટ શબ્દમાળા (`b"hello"`), અક્ષર (`'a'`), બાઇટ અક્ષર (`b'a'`), પ્રત્યય સાથે અથવા વગર પૂર્ણાંક અથવા ફ્લોટિંગ પોઇન્ટ નંબર (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` અને `false` જેવા બુલિયન લિટરલ્સ અહીંનાં નથી, તે `ઓળખ છે.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// નિર્દિષ્ટ મૂલ્ય સાથે એક નવી પ્રત્યય સાથે પૂર્ણાંક પૂર્ણાંક બનાવે છે.
        ///
        /// આ ફંક્શન, `1u32` જેવું પૂર્ણાંક બનાવશે જ્યાં નિર્દિષ્ટ પૂર્ણાંક મૂલ્ય એ token નો પહેલો ભાગ છે અને અંતિમ ભાગમાં પણ ઇન્ટિગ્રલ પ્રત્યય બને છે.
        /// નકારાત્મક સંખ્યાઓમાંથી બનાવેલ લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રાઉન્ડ-ટ્રિપ્સમાં ટકી શકશે નહીં અને બે ઝેડ ટtoકન0 ઝેડ (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
        ///
        ///
        /// આ પદ્ધતિ દ્વારા બનાવવામાં આવેલા લિટરલ્સમાં ડિફ defaultલ્ટ રૂપે `Span::call_site()` સ્પાન હોય છે, જે નીચે `set_span` પદ્ધતિથી ગોઠવી શકાય છે.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// નિર્દિષ્ટ મૂલ્ય સાથે એક નવો અસફિક્સ્ડ પૂર્ણાંક શાબ્દિક બનાવે છે.
        ///
        /// આ ફંક્શન `1` જેવું પૂર્ણાંક બનાવશે જ્યાં નિર્દિષ્ટ પૂર્ણાંક મૂલ્ય એ token નો પ્રથમ ભાગ છે.
        /// આ token પર પ્રત્યયનો ઉલ્લેખ કરવામાં આવ્યો નથી, એટલે કે `Literal::i8_unsuffixed(1)` જેવા વિનંતીઓ `Literal::u32_unsuffixed(1)` ની સમકક્ષ છે.
        /// નકારાત્મક નંબરોથી બનાવેલા લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રોસ્ટ્રિપ્સમાં ટકી શકશે નહીં અને બે tokens (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
        ///
        ///
        /// આ પદ્ધતિ દ્વારા બનાવવામાં આવેલા લિટરલ્સમાં ડિફ defaultલ્ટ રૂપે `Span::call_site()` સ્પાન હોય છે, જે નીચે `set_span` પદ્ધતિથી ગોઠવી શકાય છે.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// નવું અનફિક્સિડ ફ્લોટિંગ-પોઇન્ટ શાબ્દિક બનાવે છે.
    ///
    /// આ કન્સ્ટ્રક્ટર `Literal::i8_unsuffixed` જેવું જ છે જ્યાં ફ્લોટનું મૂલ્ય સીધા token માં બહાર કા .વામાં આવે છે પરંતુ કોઈ પ્રત્યયનો ઉપયોગ થતો નથી, તેથી તે કમ્પાઇલરમાં પાછળથી `f64` હોવાનું અનુમાન લગાવી શકાય છે.
    ///
    /// નકારાત્મક નંબરોથી બનાવેલા લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રોસ્ટ્રિપ્સમાં ટકી શકશે નહીં અને બે tokens (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
    ///
    /// # Panics
    ///
    /// આ ફંક્શન માટે જરૂરી છે કે ઉલ્લેખિત ફ્લોટ મર્યાદિત છે, ઉદાહરણ તરીકે જો તે અનંત અથવા નાએન છે, તો આ કાર્ય ઝેડપેનિક0 ઝેડ કરશે.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// એક નવો પ્રત્યય ફ્લોટિંગ-પોઇન્ટ શાબ્દિક બનાવે છે.
    ///
    /// આ કન્સ્ટ્રક્ટર `1.0f32` જેવા શાબ્દિક બનાવશે જ્યાં નિર્દિષ્ટ મૂલ્ય એ token નો પૂર્વવર્તી ભાગ છે અને `f32` એ token નો પ્રત્યય છે.
    /// આ token હંમેશાં કમ્પાઇલરમાં `f32` હોવાનું અનુમાન લગાવવામાં આવશે.
    /// નકારાત્મક નંબરોથી બનાવેલા લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રોસ્ટ્રિપ્સમાં ટકી શકશે નહીં અને બે tokens (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
    ///
    ///
    /// # Panics
    ///
    /// આ ફંક્શન માટે જરૂરી છે કે ઉલ્લેખિત ફ્લોટ મર્યાદિત છે, ઉદાહરણ તરીકે જો તે અનંત અથવા નાએન છે, તો આ કાર્ય ઝેડપેનિક0 ઝેડ કરશે.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// નવું અનફિક્સિડ ફ્લોટિંગ-પોઇન્ટ શાબ્દિક બનાવે છે.
    ///
    /// આ કન્સ્ટ્રક્ટર `Literal::i8_unsuffixed` જેવું જ છે જ્યાં ફ્લોટનું મૂલ્ય સીધા token માં બહાર કા .વામાં આવે છે પરંતુ કોઈ પ્રત્યયનો ઉપયોગ થતો નથી, તેથી તે કમ્પાઇલરમાં પાછળથી `f64` હોવાનું અનુમાન લગાવી શકાય છે.
    ///
    /// નકારાત્મક નંબરોથી બનાવેલા લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રોસ્ટ્રિપ્સમાં ટકી શકશે નહીં અને બે tokens (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
    ///
    /// # Panics
    ///
    /// આ ફંક્શન માટે જરૂરી છે કે ઉલ્લેખિત ફ્લોટ મર્યાદિત છે, ઉદાહરણ તરીકે જો તે અનંત અથવા નાએન છે, તો આ કાર્ય ઝેડપેનિક0 ઝેડ કરશે.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// એક નવો પ્રત્યય ફ્લોટિંગ-પોઇન્ટ શાબ્દિક બનાવે છે.
    ///
    /// આ કન્સ્ટ્રક્ટર `1.0f64` જેવા શાબ્દિક બનાવશે જ્યાં નિર્દિષ્ટ મૂલ્ય એ token નો પૂર્વવર્તી ભાગ છે અને `f64` એ token નો પ્રત્યય છે.
    /// આ token હંમેશાં કમ્પાઇલરમાં `f64` હોવાનું અનુમાન લગાવવામાં આવશે.
    /// નકારાત્મક નંબરોથી બનાવેલા લિટરલ્સ, `TokenStream` અથવા શબ્દમાળાઓ દ્વારા રોસ્ટ્રિપ્સમાં ટકી શકશે નહીં અને બે tokens (`-` અને સકારાત્મક શાબ્દિક) માં વિભાજિત થઈ શકે છે.
    ///
    ///
    /// # Panics
    ///
    /// આ ફંક્શન માટે જરૂરી છે કે ઉલ્લેખિત ફ્લોટ મર્યાદિત છે, ઉદાહરણ તરીકે જો તે અનંત અથવા નાએન છે, તો આ કાર્ય ઝેડપેનિક0 ઝેડ કરશે.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// શબ્દમાળા શબ્દમાળા.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// અક્ષર શાબ્દિક.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// બાઇટ શબ્દમાળા શાબ્દિક.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// આ શાબ્દિક શામેલ ગાળો પાછો આપે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// આ શાબ્દિક સાથે સંકળાયેલ સ્પાનને ગોઠવે છે.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` પરત કરે છે જે `self.span()` નો ઉપગણ છે જે ફક્ત `range` શ્રેણીમાં સ્રોત બાઇટ્સ ધરાવે છે.
    /// `None` પરત કરે છે જો સુવિધાયુક્ત ગાળો `self` ની સીમાની બહાર હોય તો.
    ///
    // FIXME(SergioBenitez): તપાસો કે બાઇટ શ્રેણી સ્રોતની UTF-8 સીમાથી શરૂ થાય છે અને સમાપ્ત થાય છે.
    // નહિંતર, સંભવ છે કે સ્રોત ટેક્સ્ટ છાપવામાં આવે ત્યારે ઝેડપpanનિક 80 ઝેડ બીજે ક્યાંક થાય.
    // FIXME(SergioBenitez): વપરાશકર્તાને જાણવાનો કોઈ રસ્તો નથી કે `self.span()` ખરેખર નકશામાં શું છે, તેથી આ પદ્ધતિ હાલમાં ફક્ત આંખ આડા કાન કરી શકાય છે.
    // ઉદાહરણ તરીકે, 'c' પાત્ર માટે `to_string()`, "'\u{63}'" આપે છે;સ્રોત ટેક્સ્ટ 'c' હતો કે નહીં તે '\u{63}' છે કે નહીં તે જાણવાની વપરાશકર્તા માટે કોઈ રીત નથી.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` જેવું કંઈક છે, પરંતુ `Bound<&T>` માટે.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// એનબી, બ્રિજ ફક્ત `to_string` પૂરો પાડે છે, તેના આધારે `fmt::Display` લાગુ કરો (બંને વચ્ચેના સામાન્ય સંબંધનું વિપરીત).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// શાબ્દિક શબ્દમાળાને છાપે છે જે તે જ શાબ્દિક (ફ્લોટિંગ પોઇન્ટ લિટરલ્સ માટેના શક્ય ગોળાકાર સિવાય) માં દોષરહિત રૂપાંતરિત હોવું જોઈએ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// પર્યાવરણ ચલોની toક્સેસ
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// પર્યાવરણ ચલ પ્રાપ્ત કરો અને પરાધીનતા માહિતી બનાવવા માટે તેને ઉમેરો.
    /// કમ્પાઇલર ચલાવનાર બિલ્ડ સિસ્ટમ જાણશે કે સંકલન દરમ્યાન વેરીએબલ cesક્સેસ કરવામાં આવ્યું હતું, અને જ્યારે તે વેરીએબલના મૂલ્યમાં ફેરફાર થાય ત્યારે બિલ્ડ ફરીથી ચાલુ કરવામાં સમર્થ હશે.
    ///
    /// આ ફંક્શનને ટ્રેકિંગ કરવામાં અવલંબન ઉપરાંત માનક લાઇબ્રેરીમાંથી `env::var` ની બરાબર હોવી જોઈએ, સિવાય કે દલીલ UTF-8 હોવી જોઈએ.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}