use backtrace::Backtrace;

// આ પરીક્ષણ ફક્ત પ્લેટફોર્મ પર કાર્ય કરે છે જેમાં ફ્રેમ્સ માટે કાર્યરત `symbol_address` ફંક્શન હોય છે જે પ્રતીકના પ્રારંભિક સરનામાંની જાણ કરે છે.
// પરિણામે તે ફક્ત થોડા પ્લેટફોર્મ્સ પર જ સક્ષમ છે.
//
const ENABLED: bool = cfg!(all(
    // Windows ખરેખર પરીક્ષણ કરવામાં આવ્યું નથી, અને OSX ખરેખર એક બંધ ફ્રેમ શોધવામાં સમર્થન આપતું નથી, તેથી આને અક્ષમ કરો
    //
    target_os = "linux",
    // એઆરએમ પર એન્ક્લોઝિંગ ફંક્શન શોધવાનું સરળ રીતે આઇપીને પરત કરી રહ્યું છે.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}