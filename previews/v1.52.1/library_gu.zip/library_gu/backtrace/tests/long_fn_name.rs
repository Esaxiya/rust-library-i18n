use backtrace::Backtrace;

// 50-અક્ષર મોડ્યુલ નામ
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-અક્ષર સ્ટ્રક્ટ નામ
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// લાંબા ફંક્શન નામો (MAX_SYM_NAME, 1) અક્ષરો પર કાપવા જ જોઈએ.
// ફક્ત આ પરીક્ષણને એમએસવીસી માટે ચલાવો, કારણ કે ઝેડ 0gnu0Z બધા ફ્રેમ્સ માટે "<no info>" છાપે છે.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // સ્ટ્રક્ટ નામની 10 પુનરાવર્તનો, તેથી સંપૂર્ણ રીતે લાયક કાર્યનું નામ ઓછામાં ઓછું 10 *(50 + 50)* 2=2000 અક્ષરો લાંબું છે.
    //
    // તે ખરેખર લાંબું છે કારણ કે તેમાં `::`, `<>` અને વર્તમાન મોડ્યુલનું નામ શામેલ છે
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}