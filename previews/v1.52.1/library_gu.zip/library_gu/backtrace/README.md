# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ઝેડ રસ્ટ0 ઝેડ માટે રનટાઇમ પર બેકટ્રેસ પ્રાપ્ત કરવા માટેની એક લાઇબ્રેરી.
આ લાઇબ્રેરીનો હેતુ પ્રોગ્રામમેટિક ઇન્ટરફેસ સાથે કામ કરવા માટે પ્રમાણભૂત લાઇબ્રેરીના ટેકોને વધારવાનો છે, પરંતુ તે લીબસ્ટેડની ઝેડ 0 સ્પેનિક્સ0 ઝેડ જેવા વર્તમાન બેકટ્રેસને સરળતાથી પ્રિંટ કરવાને પણ સપોર્ટ કરે છે.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

પછીના સમય સુધી તેની સાથે વ્યવહાર કરવા માટે બેકટ્રેસ અને ડિફરન્સને ખાલી કરવા માટે, તમે ઉચ્ચ-સ્તરના `Backtrace` પ્રકારનો ઉપયોગ કરી શકો છો.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

જો, તેમ છતાં, તમે વાસ્તવિક ટ્રેસિંગ વિધેયમાં વધુ કાચી accessક્સેસ કરવા માંગતા હો, તો તમે સીધા `trace` અને `resolve` કાર્યોનો ઉપયોગ કરી શકો છો.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // પ્રતીક નામના આ સૂચના નિર્દેશકનું ઉકેલો
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // આગળની ફ્રેમમાં જતા રહો
    });
}
```

# License

આ પ્રોજેક્ટ બંનેમાંથી કોઈપણ હેઠળ લાઇસન્સ પ્રાપ્ત છે

 * Apache લાઇસેંસ, સંસ્કરણ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) અથવા http://www.apache.org/licenses/LICENSE-2.0)
 * એમઆઈટી લાઇસેંસ ([LICENSE-MIT](LICENSE-MIT) અથવા http://opensource.org/licenses/MIT)

તમારા વિકલ્પ પર.

### Contribution

જ્યાં સુધી તમે સ્પષ્ટ રીતે અન્યથા જણાવશો નહીં ત્યાં સુધી, Apache-2.0 લાઇસન્સમાં વ્યાખ્યાયિત કર્યા મુજબ, તમે દ્વારા બેકટ્રેસ-આરએસમાં સમાવેશ કરવા માટે જાણી જોઈને રજૂ કરાયેલ કોઈપણ ફાળો, કોઈપણ વધારાની શરતો અથવા શરતો વિના, ઉપર મુજબ બેવડા પરવાનો રહેશે.







