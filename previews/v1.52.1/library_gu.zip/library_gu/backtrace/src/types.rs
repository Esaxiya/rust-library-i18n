//! પ્લેટફોર્મ આશ્રિત પ્રકારો.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// એક મંચનું પ્લેટફોર્મ સ્વતંત્ર રજૂઆત.
/// `std` સક્ષમ સાથે કામ કરતી વખતે `std` પ્રકારોને રૂપાંતર પ્રદાન કરવાની સુવિધા સુવિધાઓની ભલામણ કરવામાં આવે છે.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// એક સ્લાઇસ, ખાસ કરીને Unix પ્લેટફોર્મ પર પ્રદાન કરવામાં આવે છે.
    Bytes(&'a [u8]),
    /// Windows થી ખાસ કરીને વિશાળ શબ્દમાળાઓ.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// લોસી `Cow<str>` માં રૂપાંતરિત કરે છે, જો `Bytes` માન્ય UTF-8 માન્ય નથી અથવા `BytesOrWideString` `Wide` હોય તો ફાળવણી કરશે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` નું `Path` રજૂઆત પ્રદાન કરે છે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}