//! crates.io પર `gimli` crate નો ઉપયોગ કરીને પ્રતીક માટે સપોર્ટ
//!
//! ઝેડ 0 રસ્ટ0 ઝેડ માટે આ મૂળભૂત પ્રતીક અમલીકરણ છે.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'સ્થિર જીવનકાળ એ સ્વ-રેફરન્શિયલ સ્ટ્રક્ટ્સના ટેકાના અભાવની આસપાસ હેક કરવાનું જૂઠું છે.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'સ્થિર જીવનકાળમાં કન્વર્ટ કરો કારણ કે પ્રતીકોએ ફક્ત `map` અને `stash` લેવું જોઈએ અને અમે તેને નીચે સાચવી રહ્યાં છીએ.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows પર મૂળ પુસ્તકાલયો લોડ કરવા માટે, વિવિધ વ્યૂહરચનાઓ માટે અહીં rust-lang/rust#71060 પર થોડી ચર્ચા જુઓ.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // મિનડબ્લ્યુ લાઇબ્રેરીઓ હાલમાં ASLR (rust-lang/rust#16514) ને સમર્થન આપતી નથી, પરંતુ DLLs હજી પણ સરનામાંની જગ્યામાં સ્થાનાંતરિત કરી શકાય છે.
            // એવું લાગે છે કે ડિબગ માહિતીમાંના સરનામાં બધા જ હોય છે જો આ લાઇબ્રેરી તેના "image base" પર લોડ કરવામાં આવી હતી, જે તેના સીએફએફ ફાઇલ હેડર્સનું ક્ષેત્ર છે.
            // કારણ કે ડિબગિન્ફો સૂચિબદ્ધ કરે તેવું લાગે છે અમે પ્રતીક કોષ્ટક અને સ્ટોર સરનામાંઓને વિશ્લેષણ કરીએ છીએ જાણે કે લાઇબ્રેરી પણ "image base" પર લોડ થયેલ છે.
            //
            // જોકે, "image base" પર લાઇબ્રેરી લોડ થઈ શકશે નહીં.
            // (સંભવત there ત્યાં કંઈક બીજું લોડ થઈ શકે છે?) આ તે છે જ્યાં `bias` ક્ષેત્ર રમતમાં આવે છે, અને આપણે અહીં `bias` નું મૂલ્ય શોધવાની જરૂર છે.દુર્ભાગ્ય છતાં, ભરેલા મોડ્યુલથી આ કેવી રીતે મેળવવું તે સ્પષ્ટ નથી.
            // અમારી પાસે જે છે, તે છે, વાસ્તવિક લોડ સરનામું (`modBaseAddr`).
            //
            // હમણાં માટે ક copપ-આઉટના થોડા ભાગરૂપે, અમે ફાઇલને એમએમએપ કરીએ છીએ, ફાઇલ હેડર માહિતી વાંચીએ, પછી એમએમએપ છોડો.આ નકામું છે કારણ કે આપણે પછીથી એમએમએપ ફરીથી ખોલીશું, પરંતુ આ માટે હવે પૂરતું કામ કરવું જોઈએ.
            //
            // એકવાર અમારી પાસે `image_base` (ઇચ્છિત લોડ સ્થાન) અને `base_addr` (વાસ્તવિક લોડ સ્થાન) અમે `bias` (વાસ્તવિક અને ઇચ્છિત વચ્ચેનો તફાવત) ભરી શકીએ અને પછી દરેક સેગમેન્ટનો ઉલ્લેખિત સરનામું `image_base` છે કારણ કે ફાઇલ શું કહે છે.
            //
            //
            // હવે માટે એવું લાગે છે કે ELF/MachO થી વિપરીત, અમે આખા કદના રૂપે `modBaseSize` નો ઉપયોગ કરીને, લાઇબ્રેરી દીઠ એક ભાગ સાથે કરી શકીએ છીએ.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS માચ-ઓ ફાઇલ ફોર્મેટનો ઉપયોગ કરે છે અને એપ્લિકેશનનો ભાગ છે તેવા મૂળ પુસ્તકાલયોની સૂચિને લોડ કરવા માટે ડીવાયએલડી-વિશિષ્ટ API નો ઉપયોગ કરે છે.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // આ પુસ્તકાલયનું નામ લાવો જે તેને ક્યાંથી લોડ કરવું તે પાથને અનુરૂપ છે.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // આ લાઇબ્રેરીના ઇમેજ હેડરને લોડ કરો અને બધા લોડ આદેશોનું વિશ્લેષણ કરવા માટે `object` ને રજૂ કરો જેથી આપણે અહીં શામેલ બધા સેગમેન્ટ્સ શોધી શકીએ.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // સેગમેન્ટ્સની તપાસ કરો અને અમને લાગેલા સેગમેન્ટો માટે જાણીતા પ્રદેશોની નોંધણી કરો.
            // પાછળથી પ્રક્રિયા કરવા માટે લખાણ વિભાગો વિશેની માહિતીને રેકોર્ડ કરો, નીચે ટિપ્પણીઓ જુઓ.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // આ લાઇબ્રેરી માટે "slide" નક્કી કરો કે જે મેમરી inબ્જેક્ટ્સ ક્યાં લોડ થાય છે તે શોધવા માટે આપણે જે પૂર્વગ્રહ રાખીએ છીએ તેનો અંત થાય છે.
            // આ થોડું વિચિત્ર ગણતરી છે અને જંગલીમાં થોડી વસ્તુઓનો પ્રયાસ કરવા અને શું લાકડીઓ વડે જોવાનું પરિણામ છે.
            //
            // સામાન્ય વિચાર એ છે કે `bias` વત્તા એક સેગમેન્ટનો `stated_virtual_memory_address` તે હશે જ્યાં વાસ્તવિક સરનામાંની જગ્યામાં સેગમેન્ટ રહે છે.
            // બીજી વસ્તુ જેનો આપણે નિર્ભર કરીએ છીએ તે એ છે કે એક વાસ્તવિક સરનામું `bias` એ પ્રતીક કોષ્ટક અને ડિબગિન્ફોમાં જોવાનું અનુક્રમણિકા છે.
            //
            // તે તારણ આપે છે, સિસ્ટમ લોડ થયેલ પુસ્તકાલયો માટે આ ગણતરીઓ ખોટી છે.મૂળ એક્ઝેક્યુટેબલ માટે, જો કે, તે યોગ્ય લાગે છે.
            // એલએલડીબીના સ્રોતમાંથી થોડું તર્ક ઉઠાવવું તેમાં ન nonઝેરો કદ સાથે ફાઇલ setફસેટ 0 થી લોડ થયેલ પ્રથમ `__TEXT` વિભાગ માટે કેટલાક વિશેષ-કેસિંગ છે.
            // કોઈપણ કારણોસર જ્યારે આ હાજર હોય ત્યારે તેનો અર્થ એ થાય છે કે પ્રતીક કોષ્ટક લાઇબ્રેરી માટેના ફક્ત vmaddr સ્લાઇડ સાથે સંબંધિત છે.
            // જો તે *હાજર નથી* તો પ્રતીક કોષ્ટક vmaddr સ્લાઇડ વત્તા સેગમેન્ટના જણાવેલ સરનામાં સાથે સંબંધિત છે.
            //
            // આ સ્થિતિને હેન્ડલ કરવા માટે જો આપણે ફાઈલ zeroફસેટ શૂન્ય પર કોઈ ટેક્સ્ટ વિભાગ શોધી શકતા નથી, તો પછી આપણે પહેલા ટેક્સ્ટ સેક્શનના જણાવેલ સરનામાં દ્વારા પૂર્વગ્રહ વધારીએ છીએ અને તે જ પ્રમાણે બધા જણાવેલ સરનામાં પણ ઘટાડીએ છીએ.
            //
            // તે રીતે પ્રતીક કોષ્ટક હંમેશાં પુસ્તકાલયની પૂર્વગ્રહ રકમની તુલનામાં દેખાય છે.
            // પ્રતીક કોષ્ટક દ્વારા પ્રતીક માટે આનાં યોગ્ય પરિણામો હોવાનું જણાય છે.
            //
            // પ્રામાણિકપણે મને સંપૂર્ણ ખાતરી નથી કે આ યોગ્ય છે કે નહીં અથવા જો બીજું કંઇક છે જે સૂચવે છે કે આ કેવી રીતે કરવું.
            // હમણાં માટે તેમ છતાં, તે પૂરતું (?) કાર્ય કરે છે અને જો જરૂરી હોય તો આપણે સમય જતાં આને ઝટકો આપવું જોઈએ.
            //
            // કેટલીક વધુ માહિતી માટે જુઓ #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // અન્ય Unix (દા.ત.
        // લિનક્સ) પ્લેટફોર્મ Lબ્જેક્ટ ફાઇલ ફોર્મેટ તરીકે ELF નો ઉપયોગ કરે છે અને સામાન્ય રીતે મૂળ લાઇબ્રેરીઓ લોડ કરવા માટે `dl_iterate_phdr` નામનું એક API લાગુ કરે છે.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` માન્ય પોઇન્ટર હોવા જોઈએ.
        // `vec` `std::Vec` નો માન્ય પોઇન્ટર હોવો જોઈએ.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 મૂળભૂત રીતે ડિબગ માહિતીને ટેકો આપતું નથી, પરંતુ બિલ્ડ સિસ્ટમ ડિબગ માહિતીને પાથ `romfs:/debug_info.elf` પર મૂકશે.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // બાકીની દરેક વસ્તુએ ELF નો ઉપયોગ કરવો જોઈએ, પરંતુ મૂળ લાઇબ્રેરીઓ કેવી રીતે લોડ કરવી તે ખબર નથી.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// બધી જાણીતી શેર કરેલી લાઇબ્રેરીઓ કે જે લોડ થઈ ગઈ છે.
    libraries: Vec<Library>,

    /// મેપ્સિંગ્સ કેશ જ્યાં આપણે પાર્સડ વામન માહિતી જાળવીએ છીએ.
    ///
    /// આ સૂચિમાં તેના સમગ્ર જીવનકાળ માટે નિશ્ચિત ક્ષમતા છે જે ક્યારેય વધતી નથી.
    /// દરેક જોડીનું `usize` તત્વ ઉપર `libraries` માં અનુક્રમણિકા છે જ્યાં `usize::max_value()` વર્તમાન એક્ઝેક્યુટેબલને રજૂ કરે છે.
    ///
    /// `Mapping` અનુસરેલ વામન માહિતીને અનુરૂપ છે.
    ///
    /// નોંધ લો કે આ મૂળભૂત રીતે LRU કેશ છે અને અમે સરનામાંઓને પ્રતીક કરતી વખતે અહીં વસ્તુઓ ફેરવીશું.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// આ લાઇબ્રેરીના ભાગો મેમરીમાં ભરેલા છે, અને જ્યાં તેઓ લોડ થયા છે.
    segments: Vec<LibrarySegment>,
    /// આ લાઇબ્રેરીનો "bias", ખાસ કરીને જ્યાં તે મેમરીમાં લોડ થાય છે.
    /// સેગમેન્ટમાં લોડ થયેલ છે તે વાસ્તવિક વર્ચુઅલ મેમરી સરનામું મેળવવા માટે આ મૂલ્ય દરેક સેગમેન્ટના જણાવેલા સરનામાંમાં ઉમેરવામાં આવે છે.
    /// વધુમાં, આ પૂર્વગ્રહ વાસ્તવિક વર્ચુઅલ મેમરી સરનામાંઓથી અનુક્રમણિકામાં ડિબગિન્ફો અને પ્રતીક કોષ્ટકમાં બાદબાકી કરવામાં આવે છે.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Seબ્જેક્ટ ફાઇલમાં આ સેગમેન્ટનું જણાવેલ સરનામું.
    /// આ તે ભાગમાં નથી જ્યાં સેગમેન્ટ લોડ થયેલ છે, પરંતુ આ સરનામાં વત્તા ગ્રંથાલયનોનું `bias` છે જ્યાં તેને શોધવા માટે છે.
    ///
    stated_virtual_memory_address: usize,
    /// મેમરીમાં ths સેગમેન્ટનું કદ.
    len: usize,
}

// અસુરક્ષિત કારણ કે આને બાહ્યરૂપે સિંક્રનાઇઝ કરવું જરૂરી છે
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // અસુરક્ષિત કારણ કે આને બાહ્યરૂપે સિંક્રનાઇઝ કરવું જરૂરી છે
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ડિબગ માહિતી મેપિંગ્સ માટે ખૂબ જ નાનો, ખૂબ સરળ LRU કેશ.
        //
        // હિટ રેટ ખૂબ beંચો હોવો જોઈએ, કારણ કે લાક્ષણિક સ્ટેક ઘણી શેર કરેલી લાઇબ્રેરીઓ વચ્ચે ઓળંગી નથી.
        //
        // `addr2line::Context` સ્ટ્રક્ચર્સ બનાવવા માટે ખૂબ ખર્ચાળ છે.
        // તેની કિંમત અનુગામી `locate` ક્વેરીઝ દ્વારા orણમુક્ત થવાની અપેક્ષા છે, જે સરસ સ્પીડઅપ્સ મેળવવા માટે `addr2line: : Context`s બાંધતી વખતે બનાવેલ સ્ટ્રક્ચર્સને લાભ આપે છે.
        //
        // જો અમારી પાસે આ કેશ ન હોત, તો તે orણમુક્તિ ક્યારેય નહીં થાય, અને બેકટ્રેસનું પ્રતીક કરવું ssssllllooooowwww હશે.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // પહેલા, પરીક્ષણ કરો કે શું આ `lib` માં `addr` (હેન્ડલિંગ રિલોકેશન) ધરાવતો કોઈ ભાગ છે.જો આ ચેક પસાર થાય છે, તો અમે નીચે ચાલુ રાખી શકીએ છીએ અને સરનામાંનું ખરેખર ભાષાંતર કરી શકીએ છીએ.
                //
                // નોંધ કરો કે અમે અહીં ઓવરફ્લો ચકાસણી ટાળવા માટે `wrapping_add` નો ઉપયોગ કરી રહ્યા છીએ.તે જંગલીમાં જોવામાં આવ્યું છે કે SVMA + પૂર્વગ્રહ ગણતરી ઓવરફ્લો થાય છે.
                // લાગે છે કે તે થોડું વિચિત્ર લાગે છે, પરંતુ તે વિશે કોઈ મોટી રકમ નથી જે આપણે તેના વિશે કરી શકીએ, સિવાય કે ફક્ત તે ભાગોને અવગણશો કારણ કે તેઓ સંભવિત અવકાશ તરફ નિર્દેશ કરે છે.
                //
                // આ મૂળ rust-lang/backtrace-rs#329 માં આવ્યું.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // હવે જ્યારે આપણે જાણીએ છીએ કે `lib` માં `addr` શામેલ છે, તો અમે જણાવેલ વાયરલ મેમરી સરનામું શોધવા પૂર્વગ્રહ સાથે સરભર કરી શકીએ છીએ.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // અવિવેક: પ્રારંભિક પાછા ફર્યા વિના આ શરતી પૂર્ણ થયા પછી
        // ભૂલથી, આ પાથ માટે કેશ પ્રવેશ સૂચકાંક 0 પર છે.

        if let Some(idx) = idx {
            // જ્યારે મેપિંગ પહેલેથી જ કેશમાં હોય, ત્યારે તેને આગળની તરફ ખસેડો.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // જ્યારે મppingપિંગ કેશમાં નથી, ત્યારે નવું મેપિંગ બનાવો, તેને કેશની આગળના ભાગમાં દાખલ કરો, અને જો જરૂરી હોય તો સૌથી જૂની કેશ પ્રવેશને બાકાત કરો.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` જીવનકાળને લીક ન કરો, ખાતરી કરો કે તે ફક્ત પોતાને માટે જ છે
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // દુર્ભાગ્યે અહીં આપણને જરૂરી હોવાને કારણે `sym` ના જીવનકાળને `'static` સુધી લંબાવો, પરંતુ તે એકદમ એક સંદર્ભ તરીકે બહાર નીકળી રહ્યું છે, તેથી કોઈપણ રીતે આ ફ્રેમની બહાર તેનો સંદર્ભ ન રાખવો જોઈએ.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // આખરે, કેશ મેપિંગ મેળવો અથવા આ ફાઇલ માટે નવું મેપિંગ બનાવો અને આ સરનામાં માટે file/line/name શોધવા માટે DWARF માહિતીનું મૂલ્યાંકન કરો.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// અમે આ પ્રતીક માટેની ફ્રેમ માહિતીને શોધી શક્યાં હતાં, અને `એડ્રર 2લાઇન`ની ફ્રેમમાં આંતરિક રીતે બધી વિચિત્ર વિગતો છે.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ડિબગ માહિતી શોધી શકી નથી, પરંતુ અમને તે એક્ઝેક્યુટેબલ એક નાની પરીના પ્રતીક કોષ્ટકમાં મળી છે.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}