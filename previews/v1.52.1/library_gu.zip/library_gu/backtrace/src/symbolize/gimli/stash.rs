// ફક્ત હમણાં જ Linux પર વપરાય છે, તેથી અન્યત્ર ડેડ કોડને મંજૂરી આપો
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// બાઇટ બફર માટે એક સરળ ક્ષેત્ર ફાળવણીકાર.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// ઉલ્લેખિત કદના બફરને ફાળવે છે અને તેના માટે પરિવર્તનશીલ સંદર્ભ આપે છે.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // સલામતી: આ એકમાત્ર કાર્ય છે જે ક્યારેય પરિવર્તનીય બનાવે છે
        // `self.buffers` નો સંદર્ભ.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // સલામતી: અમે ક્યારેય `self.buffers` માંથી તત્વો કા removeતા નથી, તેથી સંદર્ભ
        // કોઈપણ બફરની અંદરના ડેટામાં, જ્યાં સુધી `self` થાય ત્યાં સુધી જીવંત રહેશે.
        &mut buffers[i]
    }
}