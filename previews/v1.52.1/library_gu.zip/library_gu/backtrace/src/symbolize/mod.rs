use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// પ્રતીકના સરનામાંનું નિરાકરણ, પ્રતીકને નિર્ધારિત અંતમાં પસાર કરો.
///
/// આ કાર્ય આપેલ સરનામાં શોધવા માટે સ્થાનિક પ્રતીક કોષ્ટક, ગતિશીલ પ્રતીક કોષ્ટક અથવા ડિવર ડિબગ માહિતી (સક્રિય કરેલ અમલીકરણના આધારે) જેવા ક્ષેત્રોમાં આપેલ સરનામું શોધી શકશે.
///
///
/// જો રિઝોલ્યુશન થઈ શક્યું ન હોત તો ક્લોઝર કહેવાશે નહીં, અને ઇનલેન્ડેડ ફંક્શન્સના કિસ્સામાં તેને એક કરતા વધુ વાર કહેવાશે.
///
/// પ્રાપ્ત થયેલા પ્રતીકો, તે સરનામાં (જો ઉપલબ્ધ હોય તો) માટે file/line જોડીઓ પરત કરીને, ઉલ્લેખિત `addr` પર એક્ઝેક્યુશનનું પ્રતિનિધિત્વ કરે છે.
///
/// નોંધો કે જો તમારી પાસે `Frame` છે તો પછી આને બદલે `resolve_frame` ફંક્શનનો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
/// # Panics
///
/// આ ફંક્શન ક્યારેય ઝેડપેનિનીક ઝેડ ઝેડ માટે પ્રયત્ન કરે છે, પરંતુ જો `cb` panics પ્રદાન કરે છે, તો કેટલાક પ્લેટફોર્મ પ્રક્રિયાને અવગણવા માટે ડબલ panic ને દબાણ કરશે.
/// કેટલાક પ્લેટફોર્મ્સ સી લાઇબ્રેરીનો ઉપયોગ કરે છે જે આંતરિક રીતે ક callલબbacક્સનો ઉપયોગ કરે છે કે જેના દ્વારા અવાહક ન થઈ શકે, તેથી `cb` થી ગભરાઈને પ્રક્રિયાને છોડી દેવી પડશે.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ફક્ત ટોચની ફ્રેમ જુઓ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// અગાઉના કેપ્ચર ફ્રેમને સિમ્બોલમાં ઠીક કરો, નિશાનીને સ્પષ્ટ કરેલ બંધ પર પસાર કરો.
///
/// આ ફંકટિન `resolve` જેટલું જ કાર્ય કરે છે સિવાય કે તે સરનામાંને બદલે `Frame` ને દલીલ તરીકે લે છે.
/// આ બેકટ્રેસીંગના કેટલાક પ્લેટફોર્મ અમલીકરણોને ઉદાહરણ તરીકે ઇનલાઇન ફ્રેમ્સ વિશે વધુ સચોટ પ્રતીક માહિતી અથવા માહિતી પ્રદાન કરવાની મંજૂરી આપી શકે છે.
///
/// જો તમે કરી શકો તો આનો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
/// # Panics
///
/// આ ફંક્શન ક્યારેય ઝેડપેનિનીક ઝેડ ઝેડ માટે પ્રયત્ન કરે છે, પરંતુ જો `cb` panics પ્રદાન કરે છે, તો કેટલાક પ્લેટફોર્મ પ્રક્રિયાને અવગણવા માટે ડબલ panic ને દબાણ કરશે.
/// કેટલાક પ્લેટફોર્મ્સ સી લાઇબ્રેરીનો ઉપયોગ કરે છે જે આંતરિક રીતે ક callલબbacક્સનો ઉપયોગ કરે છે કે જેના દ્વારા અવાહક ન થઈ શકે, તેથી `cb` થી ગભરાઈને પ્રક્રિયાને છોડી દેવી પડશે.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ફક્ત ટોચની ફ્રેમ જુઓ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// સ્ટેક ફ્રેમ્સના આઇપી મૂલ્યો સામાન્ય રીતે સૂચના *એક્સ* પછી સૂચના છે * ક stલ પછી જે વાસ્તવિક સ્ટેક ટ્રેસ છે.
// આનું પ્રતીકકરણ કરવાથી filename/line નંબર એક આગળ આવે છે અને સંભવત: જો તે ફંક્શનના અંતની નજીક હોય તો તે રદબાતલ થઈ જાય છે.
//
// આ મૂળભૂત રીતે હંમેશાં બધા પ્લેટફોર્મ્સ પર દેખાય છે, તેથી સૂચના પરત કરવાને બદલે પાછલા ક callલ ઇન્સ્ટ્રક્શન પર તેને હલ કરવા માટે અમે હંમેશાં એક ઉકેલાયેલા આઇપીમાંથી બાદ કરીએ છીએ.
//
//
// આદર્શરીતે આપણે આ નહીં કરીએ.
// આદર્શરીતે, અમે `resolve` API નો ક calલર્સ મેન્યુઅલી -1 કરવા અને એકાઉન્ટ કે તેઓ પહેલાની * સૂચના માટે સ્થાનની માહિતી ઇચ્છે છે, વર્તમાન માટે નહીં.
// જો આપણે ખરેખર આગલી સૂચનાનું સરનામું અથવા વર્તમાન હોઇએ તો આદર્શરીતે અમે `Frame` પર પણ છતી કરીશું.
//
// હમણાં માટે જોકે આ એક સુંદર વિશિષ્ટ ચિંતા છે તેથી આપણે ફક્ત આંતરિક રીતે હંમેશા તેને બાદ કરીએ છીએ.
// ઉપભોક્તાઓએ કાર્યરત રહેવું જોઈએ અને સારા સારા પરિણામ મેળવવું જોઈએ, તેથી આપણે પૂરતા સારા હોવા જોઈએ.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` ની જેમ જ, અસુરક્ષિત હોવાથી તે ફક્ત અસુરક્ષિત છે.
///
/// આ ફંક્શનમાં સિંક્રોનાઇઝેશન ગેરેંટીઝ નથી પરંતુ તે ત્યારે ઉપલબ્ધ છે જ્યારે આ ઝેડ 0 ક્રેટેટઝેડની `std` સુવિધા કમ્પાઈલ નથી.
/// વધુ દસ્તાવેજીકરણ અને ઉદાહરણો માટે `resolve` ફંક્શન જુઓ.
///
/// # Panics
///
/// ગભરાટ ભર્યા `cb` પર ચેતવણીઓ માટે `resolve` પરની માહિતી જુઓ.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` ની જેમ જ, અસુરક્ષિત હોવાથી તે ફક્ત અસુરક્ષિત છે.
///
/// આ ફંક્શનમાં સિંક્રોનાઇઝેશન ગેરેંટીઝ નથી પરંતુ તે ત્યારે ઉપલબ્ધ છે જ્યારે આ ઝેડ 0 ક્રેટેટઝેડની `std` સુવિધા કમ્પાઈલ નથી.
/// વધુ દસ્તાવેજીકરણ અને ઉદાહરણો માટે `resolve_frame` ફંક્શન જુઓ.
///
/// # Panics
///
/// ગભરાટ ભર્યા `cb` પર ચેતવણીઓ માટે `resolve_frame` પરની માહિતી જુઓ.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ફાઇલમાં પ્રતીકના ઠરાવનું પ્રતિનિધિત્વ કરતું એક trait.
///
/// આ trait એ X0Xit ફંક્શનને આપવામાં આવેલા બંધને trait asબ્જેક્ટ તરીકે અપાયું છે, અને તે વર્ચ્યુઅલ રીતે રવાના કરવામાં આવ્યું છે કારણ કે તે અજ્ unknownાત છે જે તેની પાછળનું અમલીકરણ છે.
///
///
/// પ્રતીક કાર્ય વિશે સંદર્ભિત માહિતી આપી શકે છે, ઉદાહરણ તરીકે નામ, ફાઇલનામ, રેખા નંબર, ચોક્કસ સરનામું, વગેરે.
/// બધી માહિતી હંમેશાં પ્રતીકમાં ઉપલબ્ધ હોતી નથી, તેમ છતાં, તેથી બધી પદ્ધતિઓ `Option` પરત આપે છે.
///
///
pub struct Symbol {
    // TODO: આ આજીવન બાઉન્ડ, આખરે `Symbol` સુધી ચાલુ રાખવાની જરૂર છે,
    // પરંતુ તે હાલમાં એક તૂટક પરિવર્તન છે.
    // હમણાં માટે આ સલામત છે કારણ કે `Symbol` ફક્ત સંદર્ભ દ્વારા જ આપવામાં આવે છે અને ક્લોન કરી શકાતું નથી.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// આ ફંક્શનનું નામ આપે છે.
    ///
    /// પરત થયેલ રચનાનો ઉપયોગ પ્રતીકના નામ વિશે વિવિધ ગુણધર્મોને પૂછવા માટે કરી શકાય છે:
    ///
    ///
    /// * `Display` અમલીકરણ ડીમેન્ગ્લ્ડ પ્રતીકને છાપશે.
    /// * પ્રતીકનું કાચો `str` મૂલ્ય cesક્સેસ કરી શકાય છે (જો તે માન્ય utf-8 છે).
    /// * પ્રતીક નામ માટેના કાચા બાઇટ્સ cesક્સેસ કરી શકાય છે.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// આ કાર્યનું પ્રારંભિક સરનામું આપે છે.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// કાચા ફાઇલનામને સ્લાઈસ તરીકે પરત કરે છે.
    /// આ મુખ્યત્વે `no_std` વાતાવરણ માટે ઉપયોગી છે.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// આ પ્રતીક હાલમાં ચલાવવામાં આવી રહ્યું છે તે માટે ક theલમ નંબર પરત કરે છે.
    ///
    /// ફક્ત ગિમલી અહીં અહિ મૂલ્ય પ્રદાન કરે છે અને તે પછી પણ જો `filename` `Some` પરત કરે છે, અને તેથી તે પરિણામે સમાન ચેતવણીઓને આધિન છે.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// આ પ્રતીક હાલમાં ચલાવવામાં આવી રહ્યું છે તે માટેનો લાઇન નંબર પરત કરે છે.
    ///
    /// આ રીટર્ન મૂલ્ય સામાન્ય રીતે `Some` છે જો `filename` `Some` આપે છે, અને પરિણામે સમાન ચેતવણીઓને આધિન છે.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ફાઇલનું નામ પરત કરે છે જ્યાં આ કાર્ય વ્યાખ્યાયિત કરવામાં આવ્યું હતું.
    ///
    /// આ હાલમાં ફક્ત ત્યારે જ ઉપલબ્ધ છે જ્યારે લિબબેટટ્રેસ અથવા ગિમ્લીનો ઉપયોગ કરવામાં આવે છે (દા.ત.
    /// unix પ્લેટફોર્મ અન્ય) અને જ્યારે બાઈનરી ડિબગિન્ફો સાથે કમ્પાઈલ કરવામાં આવે છે.
    /// જો આમાંથી કોઈપણ શરતોને પૂર્ણ કરવામાં ન આવે તો આ સંભવત `None` પરત કરશે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // કદાચ વિશ્લેષિત C++ પ્રતીક, જો Rust તરીકે માંગેલા પ્રતીકનું વિશ્લેષણ નિષ્ફળ થયું.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // આ શૂન્ય કદનું રાખવાનું ધ્યાન રાખો, જેથી અક્ષમ થાય ત્યારે `cpp_demangle` સુવિધાની કોઈ કિંમત ન હોય.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ડિમેન્ગલ્ડ નામ, કાચા બાઇટ્સ, કાચા શબ્દમાળા, વગેરેને અર્ગનોમિક્સ એક્સેસર્સ પ્રદાન કરવા માટે પ્રતીક નામની આસપાસનો આવરણ.
///
// જ્યારે `cpp_demangle` સુવિધા સક્ષમ ન હોય ત્યારે ડેડ કોડને મંજૂરી આપો.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// કાચા અંતર્ગત બાઇટ્સથી એક નવું પ્રતીક નામ બનાવે છે.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// જો પ્રતીક માન્ય utf-8 હોય તો કાચા (mangled) પ્રતીકનું નામ `str` તરીકે આપે છે.
    ///
    /// જો તમને ડિમેંગ્ડ સંસ્કરણ જોઈએ તો `Display` અમલીકરણનો ઉપયોગ કરો.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// બાઇટ્સની સૂચિ તરીકે કાચા પ્રતીકનું નામ આપે છે
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // આ છાપવા માટે હોઈ શકે છે જો ડિમેન્ગ્લ્ડ પ્રતીક ખરેખર માન્ય ન હોય, તો ભૂલને બહારથી આગળ ન આગળ કરીને અહીં નિયંત્રિત કરો.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ફરી દાવો કરવાનો પ્રયાસ કે કેશ્ડ મેમરી સરનામાંઓને પ્રતીક કરવા માટે વપરાય છે.
///
/// આ પદ્ધતિ કોઈપણ વૈશ્વિક ડેટા સ્ટ્રક્ચર્સને રિલીઝ કરવાનો પ્રયત્ન કરશે કે જે વૈશ્વિક સ્તરે અથવા થ્રેડમાં કેશ કરવામાં આવી છે જે સામાન્ય રીતે વિશ્લેષિત DWARF માહિતી અથવા સમાન રજૂ કરે છે.
///
///
/// # Caveats
///
/// જ્યારે આ કાર્ય હંમેશાં ઉપલબ્ધ હોય છે, પરંતુ તે મોટાભાગના અમલીકરણો પર ખરેખર કંઈપણ કરતું નથી.
/// Dbghelp અથવા libbacktrace જેવી લાઇબ્રેરીઓ રાજ્યને ઘટાડવાની અને ફાળવેલ મેમરીને સંચાલિત કરવાની સુવિધા પ્રદાન કરતી નથી.
/// હમણાં માટે આ ઝેડ 0 ક્રેટ 0 ઝેડની `gimli-symbolize` સુવિધા એકમાત્ર સુવિધા છે જ્યાં આ કાર્યની કોઈ અસર હોય છે.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}