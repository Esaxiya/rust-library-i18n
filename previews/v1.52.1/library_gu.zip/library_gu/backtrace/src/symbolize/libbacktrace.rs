//! લિબબેટટ્રેસમાં DWARF-પાર્સિંગ કોડનો ઉપયોગ કરીને પ્રતીક વ્યૂહરચના.
//!
//! લિબબેકટ્રેસ સી લાઇબ્રેરી, સામાન્ય રીતે ઝેડજીસીસી 0 ઝેડ સાથે વિતરિત, ફક્ત બેકટ્રેસ જનરેટ કરવાનું સમર્થન નથી (જે આપણે ખરેખર ઉપયોગમાં નથી), પણ બેકટ્રેસનું પ્રતીક છે અને ઇનલાઇન ઇન ફ્રેમ્સ અને વnotટનnotટ જેવી વસ્તુઓ વિશે વામન ડિબગ માહિતીને હેન્ડલ કરે છે.
//!
//!
//! અહીં વિવિધ પ્રકારની ચિંતાઓને લીધે આ પ્રમાણમાં જટિલ છે, પરંતુ મૂળ વિચાર આ છે:
//!
//! * પહેલા આપણે `backtrace_syminfo` કહીએ છીએ.જો આપણે કરી શકીએ તો આ ગતિશીલ પ્રતીક કોષ્ટકમાંથી પ્રતીક માહિતી મેળવે છે.
//! * આગળ આપણે `backtrace_pcinfo` કહીએ છીએ.આ ડિબગિંફો કોષ્ટકોને વિશ્લેષિત કરશે જો તે ઉપલબ્ધ હોય અને અમને ઇનલાઇન ફ્રેમ્સ, ફાઇલનામો, લાઇન નંબરો, વગેરે વિશેની માહિતીને પુન recoverપ્રાપ્ત કરવાની મંજૂરી આપે.
//!
//! વામન કોષ્ટકોને લિબબેટટ્રેસમાં પ્રવેશવા વિશે ઘણી બધી યુક્તિઓ છે, પરંતુ આશા છે કે તે વિશ્વનો અંત નથી અને નીચે વાંચતી વખતે તે સ્પષ્ટ છે.
//!
//! આ નોન-એમએસવીસી અને નોન-ઓએસએક્સ પ્લેટફોર્મ માટે ડિફોલ્ટ પ્રતીક વ્યૂહરચના છે.Libstd માં જોકે OSX માટેની આ મૂળભૂત વ્યૂહરચના છે.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // જો શક્ય હોય તો `function` નામ પસંદ કરો કે જે ડિબગિન્ફોમાંથી આવે છે અને ઉદાહરણ તરીકે ઇનલાઇન ફ્રેમ્સ માટે સામાન્ય રીતે વધુ સચોટ હોઈ શકે છે.
                // જો તે હાજર ન હોય તો પણ `symname` માં ઉલ્લેખિત પ્રતીક કોષ્ટકના નામ પર પાછા આવો.
                //
                // નોંધ લો કે કેટલીકવાર `function` થોડુંક ઓછું સચોટ અનુભવી શકે છે, ઉદાહરણ તરીકે, `std::panicking::try::do_call` ની `try<i32,closure>` એસ્ટેન્ડેટ તરીકે સૂચિબદ્ધ થવું.
                //
                // તે શા માટે છે તે ખરેખર સ્પષ્ટ નથી, પરંતુ એકંદરે `function` નામ વધુ સચોટ લાગે છે.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // હમણાં માટે કંઇ કરવું નહીં
}

/// `data` પોઇન્ટરનો પ્રકાર `syminfo_cb` માં પસાર થયો
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // એકવાર જ્યારે આ કbackલબેક `backtrace_syminfo` થી શરૂ થાય છે, જ્યારે અમે નિરાકરણ શરૂ કરીએ છીએ ત્યારે અમે `backtrace_pcinfo` પર ક callલ કરવા માટે આગળ જઈશું.
    // `backtrace_pcinfo` ફંક્શન ડીબગ માહિતીની સલાહ લેશે અને file/line માહિતી તેમજ ઇનલાઇન કરેલા ફ્રેમ્સને પુન recoverપ્રાપ્ત કરવા જેવી બાબતો કરવા પ્રયાસ કરશે.
    // નોંધ કરો કે `backtrace_pcinfo` નિષ્ફળ થઈ શકે છે અથવા ઘણું બધું કરી શકશે નહીં જો ત્યાં ડિબગ માહિતી નથી, તેથી જો તે થાય તો આપણે `syminfo_cb` ના ઓછામાં ઓછા એક પ્રતીક સાથે ક callલબbackક ક callલ કરવાની ખાતરી કરીશું.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` પોઇન્ટરનો પ્રકાર `pcinfo_cb` માં પસાર થયો
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// લિબબેટ્રેસ એપીઆઈ રાજ્ય બનાવવાનું સમર્થન કરે છે, પરંતુ તે રાજ્યને નષ્ટ કરવાને ટેકો આપતું નથી.
// હું આનો અર્થ અંગત રીતે લેઉં છું કે કોઈ રાજ્ય બનાવવાનો છે અને પછી કાયમ રહે છે.
//
// હું એક at_exit() હેન્ડલરને રજિસ્ટર કરવાનું પસંદ કરું છું જે આ રાજ્યને સાફ કરે છે, પરંતુ લિબબેટટ્રેસે આવું કરવાની કોઈ રીત પ્રદાન કરી નથી.
//
// આ અવરોધો સાથે, આ ફંક્શનમાં સ્થિર રીતે કેશ્ડ રાજ્ય છે જેની વિનંતી કરવામાં આવે ત્યારે પ્રથમ વખત ગણતરી કરવામાં આવે છે.
//
// યાદ રાખો કે બ backકટ્રેસીંગ એ ક્રમશ happens થાય છે (એક વૈશ્વિક લોક)
//
// નોંધ લો કે અહીં સુમેળની અભાવ એ `resolve` બાહ્ય રીતે સિંક્રનાઇઝ થયેલ આવશ્યકતાને કારણે છે.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // લિબબેટ્રેસની થ્રેડોસેફ ક્ષમતાઓનો ઉપયોગ ન કરો કારણ કે આપણે તેને હંમેશાં સિંક્રનાઇઝ્ડ ફેશનમાં કહીએ છીએ.
        //
        0,
        error_cb,
        ptr::null_mut(), // કોઈ વધારાનો ડેટા નથી
    );

    return STATE;

    // નોંધ લો કે લિબબેટ્રેસને ચલાવવા માટે વર્તમાન એક્ઝેક્યુટેબલ માટે DWARF ડિબગ માહિતી શોધવાની જરૂર છે.તે સામાન્ય રીતે આ સહિત અનેક પદ્ધતિઓ દ્વારા કરે છે, પરંતુ તે મર્યાદિત નથી:
    //
    // * /proc/self/exe આધારભૂત પ્લેટફોર્મ પર
    // * રાજ્ય બનાવતી વખતે ફાઇલનામ સ્પષ્ટ રીતે પસાર થયું
    //
    // લિબબેટ્રેસ લાઇબ્રેરી એ સી કોડનો મોટો વadડ છે.આનો સ્વાભાવિક અર્થ થાય છે કે તેને મેમરી સલામતીની નબળાઈઓ મળી છે, ખાસ કરીને જ્યારે દૂષિત ડિબગિનોફોને હેન્ડલ કરવું.
    // Libતિહાસિક રીતે લિબસ્ટ્ડ એ પુષ્કળ પ્રમાણમાં ચાલ્યું છે.
    //
    // જો /proc/self/exe નો ઉપયોગ થાય છે, તો આપણે સામાન્ય રીતે આને અવગણી શકીએ છીએ કારણ કે આપણે ધારીએ છીએ કે લિબબેટ્રેસ એ "mostly correct" છે અને અન્યથા "attempted to be correct" દ્વાર્ફ ડિબગ માહિતી સાથે વિચિત્ર વસ્તુઓ નથી કરતા.
    //
    //
    // જો આપણે ફાઇલનામમાં પાસ કરીએ, તોપણ, પછી તે કેટલાક પ્લેટફોર્મ્સ (જેમ કે બીએસડી) પર શક્ય છે જ્યાં દૂષિત અભિનેતા તે સ્થાન પર મનસ્વી ફાઇલ મૂકી શકે છે.
    // આનો અર્થ એ છે કે જો આપણે ફાઇલનામ વિશે લિબબેટટ્રેસ કહીએ તો તે મનસ્વી ફાઇલનો ઉપયોગ કરી શકે છે, સંભવત se સેગફોલ્ટનું કારણ બને છે.
    // જો આપણે લિબબેટટ્રેસ કંઈપણ ન કહીએ તો પણ તે પ્લેટફોર્મ્સ પર કશું કરશે નહીં જે /proc/self/exe જેવા પાથને ટેકો આપતું નથી!
    //
    // ફાઇલનામમાં * પાસ ન થવા માટે આપણે શક્ય તેટલા સખત પ્રયત્નો કરીએ છીએ, પરંતુ આપણે પ્લેટફોર્મ પર હોવા જોઈએ જે /proc/self/exe નું બિલકુલ સમર્થન આપતા નથી.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // નોંધ લો કે આદર્શરૂપે અમે `std::env::current_exe` નો ઉપયોગ કરીશું, પરંતુ અમને અહીં `std` ની જરૂર નથી.
            //
            // વર્તમાન એક્ઝેક્યુટેબલ પાથને સ્થિર ક્ષેત્રમાં લોડ કરવા માટે `_NSGetExecutablePath` નો ઉપયોગ કરો (જો તે ખૂબ નાનો હોય તો છોડી દે છે).
            //
            //
            // નોંધ લો કે આપણે અહીં ભ્રષ્ટ એક્ઝેક્યુટેબલ પર મરી ન જવા માટે લિબબેટટ્રેસ પર ગંભીરતાથી વિશ્વાસ કરી રહ્યાં છીએ, પરંતુ તે ચોક્કસપણે કરે છે ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ફાઇલો ખોલવાનો એક મોડ છે જ્યાં તે ખોલ્યા પછી તેને કા beી શકાતી નથી.
            // આપણે અહીં જે જોઈએ છે તે સામાન્ય છે કારણ કે આપણે ખાતરી કરવા માગીએ છીએ કે લિબબેટ્રેસ પર હાથ મૂક્યા પછી આપણું એક્ઝેક્યુટેબલ આપણા હેઠળથી બદલાતું નથી, આશા છે કે મનસ્વી ડેટાને લિબબેટટ્રેસમાં (જે ખોટી રીતે લગાડવામાં આવી શકે છે) માં પસાર કરવાની ક્ષમતા ઘટાડે છે.
            //
            //
            // આપેલ છે કે અમે અમારી પોતાની છબી પર એક પ્રકારનો લોક મેળવવાનો પ્રયાસ કરવા અહીં થોડો નૃત્ય કરીએ છીએ:
            //
            // * વર્તમાન પ્રક્રિયા માટે હેન્ડલ મેળવો, તેનું ફાઇલનામ લોડ કરો.
            // * જમણી ફ્લેગો સાથે તે ફાઇલનામ પર ફાઇલ ખોલો.
            // * વર્તમાન પ્રક્રિયાના ફાઇલનામ ફરીથી લોડ કરો, ખાતરી કરો કે તે સમાન છે
            //
            // જો તે બધા પાસ થાય તો આપણે સિદ્ધાંતમાં ખરેખર આપણી પ્રક્રિયાની ફાઇલ ખોલી છે અને અમને ખાતરી છે કે તે બદલાશે નહીં.FWIW નો આ સમૂહ bતિહાસિક રીતે લિબ્સ્ટ્ડ પરથી નકલ કરવામાં આવ્યો છે, તેથી જે બન્યું હતું તેનું આ મારા શ્રેષ્ઠ અર્થઘટન છે.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // આ સ્થિર મેમરીમાં રહે છે જેથી અમે તેને પાછા આપી શકીએ ..
                static mut BUF: [i8; N] = [0; N];
                // ... અને આ અસ્થાયી હોવાથી સ્ટેક પર જીવે છે
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ઇરાદાપૂર્વક અહીં `handle` લીક કરો કારણ કે તે ખુલ્લા હોવાને કારણે આ ફાઇલ નામ પર અમારું લ lockક સાચવવું જોઈએ.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // અમે એક સ્લાઇસ પરત કરવા માગીએ છીએ જે નલ-ટર્મિનેટેડ છે, તેથી જો બધું ભરાઈ ગયું હોય અને તે કુલ લંબાઈ બરાબર હોય તો તેને નિષ્ફળતા સમાન.
                //
                //
                // અન્યથા જ્યારે સફળતા પરત આવે ત્યારે સુનિશ્ચિત કરો કે નલ બાઇટ સ્લાઈસમાં શામેલ છે.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // બેકટ્રેસ ભૂલો હાલમાં ગાદલા હેઠળ અધીરા છે
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API ને ક Callલ કરો (કોડ વાંચીને) એકવાર `syminfo_cb` પર ક shouldલ કરવો જોઈએ (અથવા સંભવત or ભૂલથી નિષ્ફળ થવું જોઈએ).
    // તે પછી અમે `syminfo_cb` ની અંદર વધુ હેન્ડલ કરીએ છીએ.
    //
    // નોંધ લો કે અમે આ કરી રહ્યા છીએ ત્યારથી `syminfo` પ્રતીક કોષ્ટકની સલાહ લેશે, દ્વિસંગીમાં કોઈ ડિબગ માહિતી ન હોય તો પણ પ્રતીક નામો શોધશે.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}