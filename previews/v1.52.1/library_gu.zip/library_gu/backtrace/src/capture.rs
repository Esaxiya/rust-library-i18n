use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// માલિકીની અને આત્મનિર્ભર બેકટ્રેસનું પ્રતિનિધિત્વ.
///
/// આ સ્ટ્રક્ચરનો ઉપયોગ પ્રોગ્રામના વિવિધ પોઇન્ટ્સ પર બેકટ્રેસને કેપ્ચર કરવા માટે થઈ શકે છે અને તે સમયે તે બેકટ્રેસ શું હતું તે તપાસવા માટે ઉપયોગમાં લઈ શકાય છે.
///
///
/// `Backtrace` તેના `Debug` અમલીકરણ દ્વારા બેકટ્રેસના સુંદર પ્રિન્ટિંગને સમર્થન આપે છે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // અહીં ફ્રેમ્સ સ્ટેકની ઉપરથી નીચેથી સૂચિબદ્ધ છે
    frames: Vec<BacktraceFrame>,
    // જે સૂચકાંકને આપણે માનીએ છીએ તે બેકટ્રેસની વાસ્તવિક શરૂઆત છે, `Backtrace::new` અને `backtrace::trace` જેવા ફ્રેમ્સને બાદ કરતાં.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// બેકટ્રેસમાં ફ્રેમનું કબજે કરેલું સંસ્કરણ.
///
/// આ પ્રકારને `Backtrace::frames` ની સૂચિ તરીકે પરત કરવામાં આવે છે અને કબજે કરેલા બેકટ્રેસમાં એક સ્ટેક ફ્રેમ રજૂ કરે છે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// બેકટ્રેસમાં પ્રતીકનું કબજે કરેલું સંસ્કરણ.
///
/// આ પ્રકાર `BacktraceFrame::symbols` ની સૂચિ તરીકે પરત કરવામાં આવ્યો છે અને બેકટ્રેસમાં પ્રતીક માટે મેટાડેટા રજૂ કરે છે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// આ ફંક્શનની કiteલસાઇટ પર બેકટ્રેસ મેળવે છે, માલિકીની રજૂઆત પરત કરે છે.
    ///
    /// આ કાર્ય Rust માં બેકટ્રેસને objectબ્જેક્ટ તરીકે રજૂ કરવા માટે ઉપયોગી છે.આ પરત કરેલ મૂલ્ય થ્રેડો પર મોકલી શકાય છે અને બીજે ક્યાંય છાપવામાં આવી શકે છે, અને આ મૂલ્યનો હેતુ સંપૂર્ણ સ્વયં છે.
    ///
    /// નોંધ લો કે કેટલાક પ્લેટફોર્મ પર સંપૂર્ણ બેકટ્રેસ પ્રાપ્ત કરવું અને તેનું નિરાકરણ કરવું તે ખૂબ જ ખર્ચાળ હોઈ શકે છે.
    /// જો તમારી એપ્લિકેશન માટે ખર્ચ ખૂબ વધારે છે, તો તેને બદલે `Backtrace::new_unresolved()` નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે જે પ્રતીક રીઝોલ્યુશન પગલું (જે સામાન્ય રીતે લાંબો સમય લે છે) ને અવગણે છે અને તે પછીની તારીખ સુધી સ્થગિત કરવાની મંજૂરી આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ખાતરી કરવા માંગો છો કે અહીં કોઈ ફ્રેમ દૂર કરવા છે
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` જેવું જ આ સિવાય કે આ કોઈપણ પ્રતીકોનું નિરાકરણ લાવશે નહીં, આ ફક્ત સરનામાંની સૂચિ તરીકે બેકટ્રેસને મેળવે છે.
    ///
    /// પછીના સમયે, `resolve` ફંક્શનને આ બેકટ્રેસના ચિહ્નોને વાંચવા યોગ્ય નામોમાં હલ કરવા માટે કહી શકાય.
    /// આ કાર્ય અસ્તિત્વમાં છે કારણ કે રીઝોલ્યુશન પ્રક્રિયા કેટલીકવાર નોંધપાત્ર સમય લે છે જ્યારે કોઈ એક બેકટ્રેસ ભાગ્યે જ છાપવામાં આવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // કોઈ પ્રતીક નામો
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // પ્રતીક નામો હવે હાજર
    /// ```
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    ///
    #[inline(never)] // ખાતરી કરવા માંગો છો કે અહીં કોઈ ફ્રેમ દૂર કરવા છે
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// જ્યારે આ બેકટ્રેસ કબજે કરવામાં આવી ત્યારે ફ્રેમ્સ પરત કરે છે.
    ///
    /// આ સ્લાઈસની પ્રથમ એન્ટ્રી સંભવત `Backtrace::new` નું કાર્ય છે, અને આ થ્રેડ અથવા મુખ્ય કાર્ય કેવી રીતે શરૂ થયું તે વિશે છેલ્લું ફ્રેમ કંઈક છે.
    ///
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// જો આ બેકટ્રેસ `new_unresolved` થી બનાવવામાં આવી હતી, તો પછી આ ફંક્શન બેકટ્રેસના બધા સરનામાંઓને તેમના પ્રતીકાત્મક નામોમાં ઠીક કરશે.
    ///
    ///
    /// જો આ બેકટ્રેસ અગાઉ ઉકેલાઈ ગઈ હોય અથવા `new` દ્વારા બનાવવામાં આવી હોય, તો આ કાર્ય કશું જ કરતું નથી.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// આ ફ્રેમ અનુરૂપ પ્રતીકોની સૂચિ પરત કરે છે.
    ///
    /// સામાન્ય રીતે ફ્રેમ દીઠ માત્ર એક જ પ્રતીક હોય છે, પરંતુ કેટલીકવાર જો સંખ્યાબંધ કાર્યો એક ફ્રેમમાં શામેલ કરવામાં આવે છે, તો બહુવિધ પ્રતીકો પરત આવશે.
    /// સૂચિબદ્ધ પ્રથમ પ્રતીક એ "innermost function" છે, જ્યારે છેલ્લું પ્રતીક બાહ્યતમ (છેલ્લું કlerલર) છે.
    ///
    /// નોંધ લો કે જો આ ફ્રેમ વણઉકેલાયેલા બેકટ્રેસમાંથી આવ્યો છે, તો પછી આ ખાલી સૂચિ પરત આવશે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` ની જેમ
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // જ્યારે પાથ છાપતા હોય ત્યારે આપણે સીડબ્લ્યુડીને છીનવી લેવાનો પ્રયત્ન કરીએ જો તે અસ્તિત્વમાં હોય, નહીં તો આપણે ફક્ત જે રીતે છે તે પાત્ર છાપીએ છીએ.
        // નોંધ લો કે અમે આ ફક્ત ટૂંકા બંધારણ માટે જ કરીએ છીએ, કારણ કે જો તે પૂર્ણ હોય તો આપણે સંભવત everything બધું છાપવા માંગીએ છીએ.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}