//! Windows પર dbghelp જોડાણને સંચાલિત કરવામાં સહાય માટે એક મોડ્યુલ
//!
//! Windows પર બેકટ્રેસિસ (ઓછામાં ઓછા એમએસવીસી માટે) મોટાભાગે `dbghelp.dll` અને તેમાં સમાવિષ્ટ વિવિધ કાર્યો દ્વારા સંચાલિત થાય છે.
//! આ કાર્યો હાલમાં સ્થિર રીતે `dbghelp.dll` ને લિંક કરવાને બદલે *ગતિશીલ રીતે* લોડ કરવામાં આવ્યા છે.
//! આ હાલમાં પ્રમાણભૂત પુસ્તકાલય દ્વારા કરવામાં આવ્યું છે (અને ત્યાં સિદ્ધાંતરૂપે જરૂરી છે), પરંતુ લાઇબ્રેરીની સ્થિર dll અવલંબનને ઘટાડવામાં મદદ કરવાનો પ્રયાસ છે કારણ કે બેકટ્રેસેસ સામાન્ય રીતે ખૂબ વૈકલ્પિક હોય છે.
//!
//! એવું કહેવાતું, `dbghelp.dll` હંમેશાં સફળતાપૂર્વક Windows પર લોડ થાય છે.
//!
//! નોંધ લો કે આપણે આ તમામ સપોર્ટને ગતિશીલરૂપે લોડ કરી રહ્યાં હોવાથી આપણે ખરેખર `winapi` માં કાચી વ્યાખ્યાઓનો ઉપયોગ કરી શકતા નથી, પરંતુ તેના બદલે આપણે ફંક્શન પોઇન્ટર પ્રકારોને જાતે વ્યાખ્યાયિત કરવાની અને તેનો ઉપયોગ કરવાની જરૂર છે.
//! અમે ખરેખર ડુપ્લિકેટ વિનાપીના બિઝનેસમાં રહેવા માંગતા નથી, તેથી અમારી પાસે ઝેડ 0 કાર્ગો 0 ઝેડ સુવિધા છે `verify-winapi` જે ભારપૂર્વક જણાવે છે કે તમામ જોડાણો વિનાપીમાંની સાથે મેળ ખાય છે અને આ સુવિધા સીઆઈ પર સક્ષમ છે.
//!
//! અંતે, તમે અહીં નોંધ લેશો કે `dbghelp.dll` માટે dll ક્યારેય અનલોડ થયેલ નથી, અને તે હાલમાં હેતુસર છે.
//! વિચારસરણી એ છે કે આપણે તેને વૈશ્વિક સ્તરે કેશ કરી શકીએ છીએ અને તેને ખર્ચાળ loads/unloads ને અવગણીને, API માં ક .લ કરવા માટે વાપરી શકીએ છીએ.
//! જો આ લીક ડિટેક્ટર્સ માટે સમસ્યા છે અથવા એવું કંઈક છે કે જ્યારે આપણે ત્યાં પહોંચીએ ત્યારે આપણે પુલને પાર કરી શકીએ છીએ.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` અને `SymSetOptions` ની આસપાસ કામ કરો, વિનાપીમાં જ હાજર નથી.
// અન્યથા આ ત્યારે જ ઉપયોગમાં લેવાય છે જ્યારે આપણે વિનાપી સામેના પ્રકારોને બે વાર ચકાસી રહ્યા છીએ.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // વિનાપીમાં હજી સુધી વ્યાખ્યાયિત નથી
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // આ વિનાપીમાં વ્યાખ્યાયિત થયેલ છે, પરંતુ તે ખોટું છે (FIXME winapi-##768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // વિનાપીમાં હજી સુધી વ્યાખ્યાયિત નથી
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// આ મેક્રોનો ઉપયોગ `Dbghelp` સ્ટ્રક્ચરને વ્યાખ્યાયિત કરવા માટે થાય છે જેમાં આંતરિક રીતે તમામ ફંક્શન પોઇંટર હોય છે જે આપણે લોડ કરી શકીએ છીએ.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` માટે લોડ થયેલ DLL
            dll: HMODULE,

            // અમે ઉપયોગ કરીશું તે દરેક ફંક્શન માટેનું દરેક ફંક્શન પોઇન્ટર
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // શરૂઆતમાં અમે DLL લોડ કર્યું નથી
            dll: 0 as *mut _,
            // પ્રારંભિક તમામ કાર્યોને ગતિશીલ રીતે લોડ કરવાની જરૂર છે તે કહેવા માટે શૂન્ય પર સેટ કરેલ છે.
            //
            $($name: 0,)*
        };

        // દરેક કાર્ય પ્રકાર માટે અનુકૂળ ટાઇપડેફ.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ખોલવાના પ્રયાસો.
            /// સફળતા મળે કે જો તે કાર્ય કરે અથવા `LoadLibraryW` નિષ્ફળ થાય તો ભૂલ.
            ///
            /// Panics જો પુસ્તકાલય પહેલેથી લોડ થયેલ છે.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // અમે ઉપયોગ કરવા માંગીએ છીએ તે દરેક પદ્ધતિ માટેનું કાર્ય.
            // જ્યારે કહેવામાં આવે છે તે કાં તો કેશ્ડ ફંક્શન પોઇન્ટર વાંચશે અથવા તેને લોડ કરશે અને લોડ કરેલું મૂલ્ય પાછું આપશે.
            // લોડ્સ સફળ થવા ભારપૂર્વક કહેવામાં આવે છે.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // ક્લિનઅપ લksક્સનો ઉપયોગ કરવા માટે સુવિધા dbghelp કાર્યો સંદર્ભ માટે પ્રોક્સી.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// આ crate થી `dbghelp` API કાર્યોને accessક્સેસ કરવા માટે જરૂરી બધા સપોર્ટ પ્રારંભ કરો.
///
///
/// નોંધ લો કે આ કાર્ય **સલામત** છે, તે આંતરિક રીતે તેનું પોતાનું સમન્વયન છે.
/// આ પણ ધ્યાનમાં લો કે આ ફંક્શનને ઘણી વખત વારંવાર કહેવું સલામત છે.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // આપણે જે કરવાની જરૂર છે તે છે આ ફંકશનને સિંક્રનાઇઝ કરવું.આને અન્ય થ્રેડોમાંથી એક સાથે અથવા એક થ્રેડની અંદર વારંવાર કહી શકાય.
        // નોંધો કે તે આના કરતાં મુશ્કેલ છે કારણ કે આપણે અહીં જેનો ઉપયોગ કરી રહ્યા છીએ, `dbghelp`,*પણ* આ પ્રક્રિયામાં અન્ય બધા કlersલર્સ સાથે સિંક્રનાઇઝ કરવાની જરૂર છે.
        //
        // સામાન્ય રીતે તે જ પ્રક્રિયામાં `dbghelp` પર ઘણા બધા ક callsલ્સ આવતા નથી અને અમે સંભવત રૂપે ધારણ કરી શકીએ છીએ કે અમે ફક્ત તેને જ એક્સેસ કરી રહ્યા છીએ.
        // જોકે, ત્યાં એક પ્રાથમિક બીજા વપરાશકર્તાની ચિંતા કરવાની છે કે જે આપણી જાતની છે, પરંતુ માનક પુસ્તકાલયમાં છે.
        // Rust માનક લાઇબ્રેરી બેકટ્રેસ સપોર્ટ માટે આ crate પર આધારિત છે, અને આ crate પણ crates.io પર અસ્તિત્વમાં છે.
        // આનો અર્થ એ છે કે જો માનક લાઇબ્રેરી ઝેડ 0 પicનિકિક ઝેડ બેકટ્રેસ છાપતી હોય તો તે આ ઝેડ 0 ક્રેટ 0 ઝેડ crates.io થી આવતા, દોડવી શકે છે, જેનાથી સેગફોલ્ટ થાય છે.
        //
        // આ સિંક્રોનાઇઝેશન સમસ્યાને હલ કરવામાં મદદ માટે અમે અહીં વિંડોઝ-વિશિષ્ટ યુક્તિ કાર્યરત કરીએ છીએ (તે છેવટે, સિંક્રોનાઇઝેશન વિશે વિંડોઝ-વિશિષ્ટ પ્રતિબંધ છે).
        // અમે આ ક callલને સુરક્ષિત કરવા માટે મ્યુટેક્સ નામનો એક સત્ર-સ્થાનિક * બનાવીએ છીએ.
        // અહીં ઉદ્દેશ એ છે કે માનક લાઇબ્રેરી અને આ ઝેડ 0 ક્રેટ 0 ઝેડને અહીં સિંક્રનાઇઝ કરવા માટે ઝેડ રસ્ટ 0 ઝેડ-લેવલ એપીઆઇ શેર કરવાની જરૂર નથી પરંતુ તેના બદલે તે એક બીજા સાથે સુમેળ કરી રહ્યાં છે તેની ખાતરી કરવા પડદા પાછળ કામ કરી શકે છે.
        //
        // આ રીતે જ્યારે આ ફંક્શનને સ્ટાન્ડર્ડ લાઇબ્રેરી દ્વારા અથવા crates.io દ્વારા બોલાવવામાં આવે છે ત્યારે અમે ખાતરી કરી શકીએ છીએ કે તે જ મ્યુટેક્સ હસ્તગત કરવામાં આવી રહ્યું છે.
        //
        // તેથી તે બધા કહેવાનું છે કે આપણે અહીં જે કરીએ છીએ તે પ્રથમ વસ્તુ છે આપણે પરમાણુરૂપે એક `HANDLE` બનાવીએ છીએ જે Windows પર નામવાળી મ્યુટેક્સ છે.
        // અમે અન્ય થ્રેડો સાથે આ કાર્યને વિશેષ રૂપે શેર કરવા માટે થોડું સુમેળ કરીએ છીએ અને ખાતરી કરીએ છીએ કે આ કાર્યના દાખલા મુજબ ફક્ત એક હેન્ડલ બનાવવામાં આવ્યું છે.
        // નોંધ લો કે હેન્ડલ ગ્લોબલમાં સંગ્રહિત થઈ જાય તે પછી ક્યારેય બંધ થતું નથી.
        //
        // આપણે ખરેખર તે લોકમાં ગયા પછી આપણે તેને સરળતાથી મેળવીએ છીએ, અને અમારું `Init` હેન્ડલ જે હાથમાં લેવાય છે તે તેને આખરે છોડવા માટે જવાબદાર રહેશે.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ઓકે, ફાઉ!હવે જ્યારે આપણે બધા સુરક્ષિત રીતે સુમેળ કરીશું, ચાલો આપણે ખરેખર બધું જ પ્રક્રિયા કરવાનું શરૂ કરીએ.
        // પહેલા આપણે ખાતરી કરવાની જરૂર છે કે આ પ્રક્રિયામાં `dbghelp.dll` ખરેખર લોડ થયેલ છે.
        // અમે સ્થિર પરાધીનતા ટાળવા માટે આ ગતિશીલ રીતે કરીએ છીએ.
        // આ historતિહાસિક રીતે વિચિત્ર જોડાણના મુદ્દાઓ પર કામ કરવા માટે કરવામાં આવ્યું છે અને બાઈનરીઓને થોડું વધુ પોર્ટેબલ બનાવવાનો હેતુ છે કારણ કે આ મોટે ભાગે ફક્ત ડિબગીંગ યુટિલિટી છે.
        //
        //
        // એકવાર અમે `dbghelp.dll` ખોલ્યા પછી આપણે તેમાં કેટલાક પ્રારંભિક કાર્યો ક callલ કરવાની જરૂર છે, અને તે નીચે વધુ વિગતવાર છે.
        // અમે ફક્ત એક જ વાર આ કરીએ છીએ, તેથી, અમને વૈશ્વિક બુલિયન મળ્યો છે જે દર્શાવે છે કે આપણે હજી પૂર્ણ કર્યું છે કે નહીં.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ખાતરી કરો કે `SYMOPT_DEFERRED_LOADS` ધ્વજ સેટ કરેલો છે, કારણ કે આ વિશે એમએસવીસીના પોતાના ડsક્સ અનુસાર: "This is the fastest, most efficient way to use the symbol handler.", તેથી ચાલો આપણે તે કરીએ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // ખરેખર એમએસવીસી સાથે પ્રતીકો પ્રારંભ કરો.નોંધ કરો કે આ નિષ્ફળ થઈ શકે છે, પરંતુ અમે તેને અવગણીએ છીએ.
        // આ દીઠ સે માટે એક ટન પૂર્વી કલા નથી, પરંતુ એલએલવીએમ આંતરિક રીતે અહીં વળતરની અવગણના કરે છે અને એલએલવીએમની એક સેનિટાઇઝર લાઇબ્રેરી એક ભયાનક ચેતવણી છાપે છે જો આ નિષ્ફળ થાય પણ મૂળભૂત રીતે લાંબાગાળે અવગણવું.
        //
        //
        // એક કેસ જે ઝેડ રસ્ટ0 ઝેડ માટે ઘણું આગળ આવે છે તે એ છે કે માનક લાઇબ્રેરી અને crates.io પરનું આ ઝેડ ક્રેકટઝેડ બંને `SymInitializeW` માટે સ્પર્ધા કરવા માગે છે.
        // Libraryતિહાસિક ધોરણે લાઇબ્રેરી મોટાભાગે તે સમયે સફાઇ શરૂ કરવા ઇચ્છતી હતી, પરંતુ હવે તે આ ઝેડ 0 ક્રેટ 0 ઝેડનો ઉપયોગ કરી રહી છે તેનો અર્થ એ કે કોઈકને પહેલા આરંભ આપશે અને બીજો તે પ્રારંભિક પસંદગી કરશે.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}