use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr એક ક callલબbackક લે છે જે પ્રક્રિયામાં જોડાયેલ દરેક DSO માટે dl_phdr_info પોઇન્ટર પ્રાપ્ત કરશે.
    // dl_iterate_phdr એ પણ સુનિશ્ચિત કરે છે કે ગતિશીલ લિંકર પુનરાવર્તનની સમાપ્તિથી પ્રારંભથી લ isક થયેલ છે.
    // જો ક callલબbackક, બિન-શૂન્ય મૂલ્ય પાછું આપે છે તો પુનરાવર્તિત પ્રારંભિક સમાપ્ત થાય છે.
    // 'data' દરેક ક callલ પર ક callલબbackકની ત્રીજી દલીલ તરીકે પસાર કરવામાં આવશે.
    // 'size' dl_phdr_info નું કદ આપે છે.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// અમારે બિલ્ડ આઈડી અને કેટલાક મૂળભૂત પ્રોગ્રામ હેડર ડેટાને વિશ્લેષિત કરવાની જરૂર છે, જેનો અર્થ છે કે અમને પણ ELF સ્પેકમાંથી થોડી સામગ્રીની જરૂર છે.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// હવે આપણે ફુચિયાના હાલના ડાયનેમિક લિન્કર દ્વારા વપરાયેલ dl_phdr_info પ્રકારનું સ્ટ્રક્ચર, બીટ બીટ બીટ, નકલ કરવું પડશે.
// ક્રોમિયમ પાસે આ ABI બાઉન્ડ્રી તેમજ ક્રેશપેડ પણ છે.
// આખરે અમે આ કેસોને પિશાચ-શોધનો ઉપયોગ કરવા માટે ખસેડવા માગીએ છીએ, પરંતુ અમારે તે એસડીકેમાં આપવાની જરૂર છે અને તે હજી સુધી થયું નથી.
//
// આમ આપણે (અને તેઓ) આ પદ્ધતિનો ઉપયોગ કરવામાં અટકીએ છીએ જે ફ્યુચિયા લિબસી સાથે ચુસ્ત યુગલ કરે છે.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff અને e_phnum માન્ય છે કે નહીં તે તપાસવાની અમારી પાસે કોઈ રીત નથી.
    // libc એ આપણા માટે આ સુનિશ્ચિત કરવું જોઈએ જેથી અહીં ટુકડો બનાવવો સલામત છે.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr લક્ષ્ય આર્કિટેક્ચરના અંતમાં 64-બીટ ઇએલએફ પ્રોગ્રામ હેડરનું પ્રતિનિધિત્વ કરે છે.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// પીએચડીઆર એ માન્ય ઇએલએફ પ્રોગ્રામ હેડર અને તેના સમાવિષ્ટોને રજૂ કરે છે.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // અમારી પાસે p_addr અથવા p_memsz માન્ય છે કે નહીં તે તપાસવાની કોઈ રીત નથી.
    // ફુચિયાનો લિબસી નોંધોને પ્રથમ પાર્સ કરે છે જો કે અહીં હોવાને કારણે આ હેડરો માન્ય હોવું આવશ્યક છે.
    //
    // નોંધ ઇંટરને અંતર્ગત ડેટા માન્ય હોવાની આવશ્યકતા નથી પરંતુ તેને માન્યતા આવશ્યક નથી.
    // અમને વિશ્વાસ છે કે લિબસીએ ખાતરી આપી છે કે આ અહીં અમારા માટે કેસ છે.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// બિલ્ડ આઈડી માટેનો નોંધનો પ્રકાર.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr લક્ષ્યની અંતમાં એક ELF નોટ હેડરનું પ્રતિનિધિત્વ કરે છે.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// નોંધ એક ઇએલએફ નોંધ (હેડર + સમાવિષ્ટો) રજૂ કરે છે.
// નામ એક u8 સ્લાઇસ તરીકે બાકી છે કારણ કે તે હંમેશા નલ ટર્મિનેટ થતું નથી અને ઝેડ 0 ર્રસ્ટ0 ઝેડ તે તપાસવાનું પૂરતું સરળ બનાવે છે કે બાઇટ્સ ક્યાંય પણ મેળ ખાય છે.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// નોટિએટર તમને નોંધ સેગમેન્ટ પર સુરક્ષિત રીતે પુનરાવર્તિત કરવા દે છે.
// ભૂલ થાય કે તરત જ સમાપ્ત થાય છે અથવા વધુ નોંધો નથી.
// જો તમે અમાન્ય ડેટા પર પુનરાવર્તન કરો છો તો તે કોઈ નોંધો મળી ન હોવાના આધારે કાર્ય કરશે.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // તે ફંક્શનનું એક અવિવેકી છે કે જે આપેલ પોઇન્ટર અને કદ એ બાઇટ્સની માન્ય શ્રેણી સૂચવે છે જે બધા વાંચી શકાય છે.
    // આ બાઇટ્સની સામગ્રી કંઈપણ હોઈ શકે છે પરંતુ આ સલામત રહેવા માટે તે શ્રેણી માન્ય હોવી આવશ્યક છે.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' ને 'to'-byte ગોઠવણીમાં 'to' એ 2 ની શક્તિ માનીને સંરેખિત કરે છે.
// આ સી/સી ++ ઇએલએફ પાર્સિંગ કોડમાં એક ધોરણની પેટર્નને અનુસરે છે જ્યાં (x + થી, 1) અને -to નો ઉપયોગ થાય છે.
// ઝેડ રસ્ટ0 ઝેડ તમને ઉપયોગમાં નકારવા દેતું નથી જેથી હું ઉપયોગ કરું
// તેને ફરીથી બનાવવા માટે 2 નું પૂરક રૂપાંતર.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 સ્લાઇસમાંથી નંબરો બાઇટ્સ વાપરે છે (જો હાજર હોય) અને વધુમાં ખાતરી કરે છે કે અંતિમ સ્લાઇસ યોગ્ય રીતે ગોઠવાયેલ છે.
// જો વિનંતી કરેલા બાઇટ્સની સંખ્યા ખૂબ મોટી હોય અથવા તો બાકીના બાઇટ્સ અસ્તિત્વમાં ન હોવાને કારણે સ્લાઇસ પછીથી માન્ય કરી શકાતી નથી, કંઈ પાછું નથી મળ્યું અને સ્લાઇસ સુધારી નથી.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// આ ફંક્શનમાં કોઈ વાસ્તવિક આક્રમણો નથી, કlerલરને અન્ય કોઈને સમર્થન આપવું જોઈએ નહીં કે 'bytes' પ્રભાવ માટે ગોઠવાયેલ હોવું જોઈએ (અને કેટલાક આર્કિટેક્ચર સચોટતા પર).
// Elf_Nhdr ફીલ્ડ્સના મૂલ્યો બકવાસ હોઈ શકે છે પરંતુ આ ફંક્શન આવી કોઈ વસ્તુની ખાતરી કરતું નથી.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // જ્યાં સુધી ત્યાં પૂરતી જગ્યા હોય ત્યાં સુધી આ સલામત છે અને અમે ફક્ત પુષ્ટિ કરી છે કે ઉપરના જો નિવેદનમાં આ અસુરક્ષિત હોવું જોઈએ નહીં.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // નોંધ કરો કે sice_of: :<Elf_Nhdr>() હંમેશાં 4-બાઇટ ગોઠવાયેલ હોય છે.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // અમે અંત પર પહોંચી ગયા છે કે કેમ તે તપાસો.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // અમે એનએચડીઆર સ્થાનાંતરિત કરીએ છીએ પરંતુ અમે પરિણામી સ્ટ્રક્ટને કાળજીપૂર્વક ધ્યાનમાં લઈએ છીએ.
        // અમને નામોઝે અથવા ડેસકેઝ પર વિશ્વાસ નથી અને અમે પ્રકારનાં આધારે કોઈ અસુરક્ષિત નિર્ણય લેતા નથી.
        //
        // તેથી જો આપણે સંપૂર્ણ કચરો બહાર કા .ીએ તો પણ આપણે સુરક્ષિત રહેવું જોઈએ.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// સૂચવે છે કે સેગમેન્ટ એક્ઝેક્યુટેબલ છે.
const PERM_X: u32 = 0b00000001;
/// સૂચવે છે કે સેગમેન્ટ લખી શકાય તેવું છે.
const PERM_W: u32 = 0b00000010;
/// સૂચવે છે કે સેગમેન્ટ વાંચવા યોગ્ય છે.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// રનટાઈમ પર ઇએલએફ સેગમેન્ટને રજૂ કરે છે.
struct Segment {
    /// આ સેગમેન્ટની સામગ્રીનું રનટાઇમ વર્ચુઅલ સરનામું આપે છે.
    addr: usize,
    /// આ સેગમેન્ટની સામગ્રીનું મેમરી કદ આપે છે.
    size: usize,
    /// ઇએલએફ ફાઇલ સાથે આ સેગમેન્ટનું મોડ્યુલ વર્ચુઅલ સરનામું આપે છે.
    mod_rel_addr: usize,
    /// ઇએલએફ ફાઇલમાં મળેલ પરવાનગી આપે છે.
    /// આ મંજૂરીઓ જરૂરી નથી જો કે તે સમયે રન ટાઇમ પર હાજર હોય.
    flags: Perm,
}

/// ડીએસઓમાંથી સેગમેન્ટ્સ પર એક પુનરાવર્તિત થવા દે.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ઇએલએફ ડીએસઓ (ગતિશીલ વહેંચાયેલ jectબ્જેક્ટ) નું પ્રતિનિધિત્વ કરે છે.
/// આ પ્રકાર તેની પોતાની ક makingપિ બનાવવાને બદલે વાસ્તવિક DSO માં સંગ્રહિત ડેટાનો સંદર્ભ આપે છે.
struct Dso<'a> {
    /// ગતિશીલ લિંકર હંમેશાં નામ આપે છે, ભલે નામ ખાલી હોય.
    /// મુખ્ય એક્ઝેક્યુટેબલના કિસ્સામાં આ નામ ખાલી હશે.
    /// શેર કરેલી objectબ્જેક્ટના કિસ્સામાં તે સોનામ હશે (જુઓ DT_SONAME).
    name: &'a str,
    /// ફુચિયા પર વર્ચ્યુઅલ રીતે તમામ બાઈનરીમાં બિલ્ડ આઈડી હોય છે પરંતુ આ કડક જરૂરી નથી.
    /// ડીએસઓ માહિતીને પછીની ઇએલએફ ફાઇલ સાથે મેળ ખાવાનો કોઈ રસ્તો નથી પછી જો ત્યાં બિલ્ડ_આઈડી નથી તેથી અમને જરૂરી છે કે દરેક ડીએસઓ પાસે અહીં એક છે.
    ///
    /// બિલ્ડ_આઇડ વિના ડીએસઓ અવગણવામાં આવે છે.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// આ ડીએસઓ માં સેગમેન્ટ્સ ઉપર ઇરેટર આપે છે.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// આ ભૂલો એ દરેક ડીએસઓ વિશેની માહિતીને વિશ્લેષણ કરતી વખતે ઉદ્ભવતા મુદ્દાઓને એન્કોડ કરે છે.
///
enum Error {
    /// નેમઅરર એટલે કે સી શૈલીના શબ્દમાળાને rust શબ્દમાળામાં રૂપાંતરિત કરતી વખતે ભૂલ આવી.
    ///
    NameError(core::str::Utf8Error),
    /// બિલ્ડ આઇરર એટલે કે અમને બિલ્ડ આઈડી મળી નથી.
    /// આ ક્યાં તો હોઈ શકે છે કારણ કે ડીએસઓ પાસે બિલ્ડ આઈડી નથી અથવા બિલ્ડ આઈડી ધરાવતો સેગમેન્ટ દૂષિત હતો.
    ///
    BuildIDError,
}

/// ગતિશીલ લિન્કર દ્વારા પ્રક્રિયામાં કડી થયેલ દરેક ડીએસઓ માટે 'dso' અથવા 'error' ક Cલ કરો.
///
///
/// # Arguments
///
/// * `visitor` - ડીસોપ્રિન્ટર કે જેમાં ખાવાની એક પદ્ધતિ હશે જેમાં ફોરachચ ડીએસઓ કહેવાય છે.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ખાતરી કરે છે કે info.name માન્ય સ્થાન તરફ નિર્દેશ કરશે.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// આ ફંક્શન ડીએસઓમાં સમાવિષ્ટ બધી માહિતી માટે ફુચિયા સિમ્બિલાઇઝર માર્કઅપને છાપે છે.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}