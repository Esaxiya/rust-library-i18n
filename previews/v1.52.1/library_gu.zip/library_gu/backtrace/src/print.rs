#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// બેકટ્રેસ માટેનું ફોર્મેટર.
///
/// આ પ્રકારનો ઉપયોગ બેકટ્રેસને છાપવા માટે થઈ શકે છે, જ્યાં સુધી બેકટ્રેસ પોતે આવે છે.
/// જો તમારી પાસે `Backtrace` પ્રકાર છે, તો તેનું `Debug` અમલીકરણ પહેલાથી આ પ્રિન્ટિંગ ફોર્મેટનો ઉપયોગ કરે છે.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// પ્રિન્ટિંગની શૈલીઓ જે આપણે છાપી શકીએ છીએ
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// એક આદર્શ બેકટ્રેસ છાપે છે જેમાં આદર્શ રીતે ફક્ત સંબંધિત માહિતી શામેલ છે
    Short,
    /// એક બેકટ્રેસ છાપે છે જેમાં બધી સંભવિત માહિતી શામેલ છે
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// એક નવું `BacktraceFmt` બનાવો જે પ્રદાન કરેલા `fmt` પર આઉટપુટ લખશે.
    ///
    /// `format` દલીલ તે શૈલીને નિયંત્રિત કરશે કે જેમાં બેકટ્રેસ છાપવામાં આવશે, અને `print_path` દલીલ ફાઇલનામોના `BytesOrWideString` ઉદાહરણો છાપવા માટે ઉપયોગમાં લેવામાં આવશે.
    /// આ પ્રકાર પોતે ફાઇલનામોનું કોઈ છાપકામ કરતું નથી, પરંતુ આવું કરવા માટે આ ક .લબbackક આવશ્યક છે.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// લગભગ બેકટ્રેસ છાપવા માટે પ્રિડેબલ પ્રિન્ટ કરે છે.
    ///
    /// પાછળથી સંપૂર્ણ નિશાની માટે બેટટ્રેસેસ માટે કેટલાક પ્લેટફોર્મ્સ પર આ જરૂરી છે, અને અન્યથા, `BacktraceFmt` બનાવ્યા પછી તમે ક callલ કરો છો તે આ પ્રથમ પદ્ધતિ હોવી જોઈએ.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// બેકટ્રેસ આઉટપુટમાં એક ફ્રેમ ઉમેરે છે.
    ///
    /// આ પ્રતિબદ્ધતા, `BacktraceFrameFmt` નો RAII દાખલો આપે છે જેનો ઉપયોગ ખરેખર કોઈ ફ્રેમ છાપવા માટે થઈ શકે છે, અને વિનાશ પર તે ફ્રેમ કાઉન્ટરને વધારશે.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// બેકટ્રેસ આઉટપુટ પૂર્ણ કરે છે.
    ///
    /// આ હાલમાં નો-isપ છે પરંતુ બેકટ્રેસ ફોર્મેટ્સ સાથે ઝેડ 0 ફ્યુચર0 ઝેડ સુસંગતતા માટે ઉમેરવામાં આવ્યું છે.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // ઝેડ 0 ફ્યુચર0 ઝેડ ઉમેરાઓને મંજૂરી આપવા માટે હાલમાં આ ઝેડ00 ઝૂ ઝેડ સહિતનો કોઈ વિકલ્પ નથી.
        Ok(())
    }
}

/// બેકટ્રેસના ફક્ત એક ફ્રેમ માટેનું ફોર્મેટર.
///
/// આ પ્રકાર `BacktraceFmt::frame` ફંક્શન દ્વારા બનાવવામાં આવ્યો છે.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// આ ફ્રેમ ફોર્મેટરથી `BacktraceFrame` છાપે છે.
    ///
    /// આ `BacktraceFrame` માં ફરીથી બધા `BacktraceSymbol` ઉદાહરણો છાપશે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// એક `BacktraceFrame` અંદર `BacktraceSymbol` છાપે છે.
    ///
    /// # જરૂરી સુવિધાઓ
    ///
    /// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: આ મહાન નથી કે આપણે કંઈપણ છાપવાનું સમાપ્ત કરતા નથી
            // બિન-utf8 ફાઇલનામો સાથે.
            // આભાર કે લગભગ બધું જ utf8 છે તેથી આ બહુ ખરાબ ન હોવું જોઈએ.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// આ crate ના કાચા કોલબેક્સની અંદરથી, કાચા ટ્રેસ કરેલા `Frame` અને `Symbol` છાપે છે.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// બેકટ્રેસ આઉટપુટમાં કાચો ફ્રેમ ઉમેરશે.
    ///
    /// આ પદ્ધતિ, અગાઉના વિપરીત, કાચા દલીલો લે છે જો તેઓ જુદા જુદા સ્થળોના સ્ત્રોત છે.
    /// નોંધ લો કે આને એક ફ્રેમ માટે ઘણી વખત કહી શકાય.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// ક columnલમ માહિતી સહિત બેકટ્રેસ આઉટપુટમાં કાચી ફ્રેમ ઉમેરશે.
    ///
    /// આ પદ્ધતિ, પહેલાની જેમ, કાચા દલીલો લે છે, જો તેઓ જુદા જુદા સ્થળોમાંથી સ્રોત છે.
    /// નોંધ લો કે આને એક ફ્રેમ માટે ઘણી વખત કહી શકાય.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ફુચિયા પ્રક્રિયામાં પ્રતીક બનાવવામાં અસમર્થ છે તેથી તેનું વિશિષ્ટ ફોર્મેટ છે જેનો ઉપયોગ પછીથી પ્રતીક બનાવવા માટે થઈ શકે છે.
        // અહીં આપણા પોતાના ફોર્મેટમાં સરનામાં છાપવાને બદલે છાપો.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" ફ્રેમ્સને છાપવાની જરૂર નથી, તેનો મૂળભૂત અર્થ એ છે કે સિસ્ટમ બેકટ્રેસ થોડોક પાછળ સુપર ટ્રેસ કરવા માટે ઉત્સુક હતી.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // એસજીએક્સ એન્ક્લેવમાં ટીસીબીનું કદ ઘટાડવા માટે, અમે પ્રતીક રીઝોલ્યુશન વિધેયને લાગુ કરવા માંગતા નથી.
        // તેના બદલે, અમે અહીં સરનામાંની setફસેટ છાપી શકીએ છીએ, જે પછીથી કાર્યને સુધારવા માટે મેપ કરી શકાશે.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ફ્રેમનું અનુક્રમણિકા તેમજ ફ્રેમના વૈકલ્પિક સૂચના નિર્દેશકને છાપો.
        // જો આપણે આ ફ્રેમના પ્રથમ પ્રતીકથી આગળ હોવા છતાં આપણે ફક્ત યોગ્ય વ્હાઇટ સ્પેસ છાપીએ છીએ.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // આગળ જો આપણે સંપૂર્ણ બેકટ્રેસ હોઈએ તો વધુ માહિતી માટે વૈકલ્પિક ફોર્મેટિંગનો ઉપયોગ કરીને, પ્રતીક નામ લખો.
        // અહીં આપણે એવા પ્રતીકોને પણ હેન્ડલ કરીએ છીએ જેમાં નામ નથી,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // અને છેલ્લે, જો ઉપલબ્ધ હોય તો filename/line નંબર છાપો.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line પ્રતીક નામ હેઠળ લીટીઓ પર છાપવામાં આવે છે, તેથી જાતને જમણી ગોઠવવા માટે અમુક યોગ્ય વ્હાઇટ સ્પેસ છાપો.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ફાઇલનામ છાપવા માટે અમારા આંતરિક ક callલબbackકને સોંપો અને પછી લાઇન નંબર છાપો.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // જો ઉપલબ્ધ હોય તો, ક columnલમ નંબર ઉમેરો.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // અમે ફક્ત કોઈ ફ્રેમના પ્રથમ પ્રતીકની કાળજી રાખીએ છીએ
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}