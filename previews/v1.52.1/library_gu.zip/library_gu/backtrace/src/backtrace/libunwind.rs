//! libunwind/gcc_s/etc API નો ઉપયોગ કરીને બેકટ્રેસ સપોર્ટ.
//!
//! આ મોડ્યુલમાં લિબનવિન્ડ-સ્ટાઇડ API નો ઉપયોગ કરીને સ્ટેકને અનવindન્ડ કરવાની ક્ષમતા શામેલ છે.
//! નોંધ લો કે લિબનવિન્ડ જેવા એપીઆઈના અમલીકરણનો આખું સમૂહ છે, અને આ ફક્ત તેમાંથી મોટા ભાગના પીકી થવાને બદલે એક સાથે સુસંગત બનવાનો પ્રયાસ કરી રહ્યો છે.
//!
//!
//! લિબનવિન્ડ એપીઆઈ `_Unwind_Backtrace` દ્વારા સંચાલિત છે અને વ્યવહારમાં તે બેકટ્રેસ ઉત્પન્ન કરવામાં ખૂબ જ વિશ્વસનીય છે.
//! તે સંપૂર્ણ રીતે સ્પષ્ટ નથી કે તે કેવી રીતે કરે છે (ફ્રેમ પોઇન્ટર? એ_ફ્રેમ માહિતી? બંને?) પરંતુ તે કાર્ય કરે છે તેવું લાગે છે!
//!
//! આ મોડ્યુલની મોટાભાગની જટિલતા વિવિધ પ્લેટફોર્મ તફાવતોને લીબુનવિન્ડ અમલીકરણમાં સંભાળી રહી છે.
//! નહીં તો આ એક સરળ સીધું ઝેડ રસ્ટ 0 ઝેડ છે જે લિબનવિન્ડ એપીઆઇ માટે બંધનકર્તા છે.
//!
//! આ હાલમાં બધાં નોન-વિન્ડોઝ પ્લેટફોર્મ માટે ડિફોલ્ટ અનઇન્ડિંગ API છે.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// કાચા લિબુનવિન્ડ પોઇન્ટર સાથે, તે ફક્ત ફક્ત વાંચવા માટે થ્રેડોસેફ ફેશનમાં જ હોવું જોઈએ, તેથી તે `Sync` છે.
// જ્યારે `Clone` દ્વારા અન્ય થ્રેડોને મોકલતા હોય ત્યારે અમે હંમેશાં એવા સંસ્કરણ પર સ્વિચ કરીએ છીએ જે આંતરિક પોઇંટર જાળવી શકતું નથી, તેથી આપણે `Send` પણ હોવા જોઈએ.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // એવું લાગે છે કે OSX U_Uwwind_FindEnclosingFunction` પર ... એક પોઇન્ટર પાછું આપે છે ... કંઈક અસ્પષ્ટ છે.
        // તે ચોક્કસ કારણોસર હંમેશાં બંધ કાર્ય નથી.
        // અહીં જે ચાલી રહ્યું છે તે મારા માટે સંપૂર્ણરૂપે સ્પષ્ટ નથી, તેથી હમણાં માટે આને નિરાશ કરો અને હંમેશાં આઇપી પાછા આપો.
        //
        // નોંધો કે આ કલમને કારણે `skip_inner_frames.rs` પરીક્ષણ OSX પર અવગણવામાં આવ્યું છે, અને જો આ ઠીક કરવામાં આવ્યું છે કે સિદ્ધાંતમાં પરીક્ષણ OSX પર ચલાવી શકાય છે!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// બેકટ્રેસેસ માટે વપરાયેલ લાઇબ્રેરી ઇંટરફેસ ખોલો
///
/// નોંધ કરો કે ડેડ કોડને મંજૂરી છે કારણ કે અહીં ફક્ત બાંધી છે iOS તે બધા તેનો ઉપયોગ કરતું નથી પરંતુ વધુ પ્લેટફોર્મ-વિશિષ્ટ રૂપરેખાંકનો ઉમેરવાથી કોડ ખૂબ પ્રદૂષિત થાય છે
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ફક્ત એઆરએમ ઇએબીઆઈ દ્વારા વપરાય છે
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // આઇઓએસ પર કોઈ મૂળ _ અનવિન્ડ_બેકટ્રેસ નથી
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 થી ઉપલબ્ધ, અમારા ઉદ્દેશ્ય માટે સારું હોવું જોઈએ
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // આ ફંક્શન ખોટો લખનાર છે: આ ફ્રેમનું કેનોનિકલ ફ્રેમ સરનામું (ઉર્ફ કlerલર ફ્રેમનો એસપી) મેળવવાને બદલે તે આ ફ્રેમનો એસપી પાછો આપે છે.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x પક્ષપાતી સીએફએ મૂલ્યનો ઉપયોગ કરે છે, તેથી આપણે _Uwwind_GetCFA પર આધાર રાખવાને બદલે સ્ટેક પોઇંટર રજિસ્ટર (%r15) મેળવવા માટે _Unwind_GetGR નો ઉપયોગ કરવાની જરૂર છે.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android અને હાથ પર, ફંક્શન `_Unwind_GetIP` અને અન્યનો સમૂહ મેક્રોઝ છે, તેથી અમે મેક્રોઝના વિસ્તરણવાળા કાર્યોને વ્યાખ્યાયિત કરીએ છીએ.
    //
    //
    // TODO: જો તમને તે મળી શકે તો, આ મ maક્રોઝને વ્યાખ્યાયિત કરતી હેડર ફાઇલ સાથે લિંક કરો.
    // (હું, ફિટ્ઝેન, આ મ someક્રો વિસ્તરણમાંથી કેટલાક મૂળ રૂપે ઉધાર લીધેલી હેડર ફાઇલ શોધી શક્યા નથી.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 હાથ પર સ્ટેક પોઇન્ટર છે.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // આ ફંક્શન પણ Android અથવા ARM/Linux પર અસ્તિત્વમાં નથી, તેથી તેને નો-opપ બનાવો.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}