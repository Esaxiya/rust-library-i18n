use core::ffi::c_void;
use core::fmt;

/// સ્ટેક ટ્રેસની ગણતરી કરવા માટે પૂરા પાડવામાં આવેલ બંધમાં તમામ સક્રિય ફ્રેમ્સને પસાર કરીને, વર્તમાન ક callલ-સ્ટેકનું નિરીક્ષણ કરે છે.
///
/// પ્રોગ્રામ માટેનાં સ્ટેક ટ્રેસની ગણતરીમાં આ ફંક્શન એ આ લાઇબ્રેરીનો વર્કહોર્સ છે.આપેલ ક્લોઝર `cb` ને `Frame` ના દાખલા મળે છે જે સ્ટેક પરની તે ક callલ ફ્રેમ વિશેની માહિતી રજૂ કરે છે.
/// બંધને ટોચ-ડાઉન ફેશનમાં ફ્રેમ્સ પ્રાપ્ત થાય છે (તાજેતરમાં કાર્યોને પહેલા કહેવામાં આવે છે).
///
/// બંધનું વળતર મૂલ્ય એ સંકેત છે કે શું બેકટ્રેસ ચાલુ રાખવું જોઈએ.`false` નું વળતર મૂલ્ય બેકટ્રેસને સમાપ્ત કરશે અને તરત જ પાછા આવશે.
///
/// એકવાર `Frame` પ્રાપ્ત થઈ જાય પછી તમે સંભવત. `backtrace::resolve` પર ક theલ કરવા માંગતા હોવ કે `ip` (સૂચના નિર્દેશક) અથવા પ્રતીક સરનામાંને `Symbol` પર કન્વર્ટ કરો, જેના દ્વારા નામ અને/અથવા ફાઇલનામ/લાઇન નંબર શીખી શકાય.
///
///
/// નોંધ લો કે આ પ્રમાણમાં નીચું-સ્તરનું કાર્ય છે અને જો તમે, ઉદાહરણ તરીકે, નિરીક્ષણ કરવા માટેના બેકટ્રેસને કેપ્ચર કરવા માંગતા હો, તો `Backtrace` પ્રકાર વધુ યોગ્ય હશે.
///
/// # જરૂરી સુવિધાઓ
///
/// આ ફંક્શન માટે `backtrace` crate નું `std` સુવિધા સક્ષમ કરવું આવશ્યક છે, અને `std` સુવિધા ડિફ defaultલ્ટ રૂપે સક્ષમ થયેલ છે.
///
/// # Panics
///
/// આ ફંક્શન ક્યારેય ઝેડપેનિનીક ઝેડ ઝેડ માટે પ્રયત્ન કરે છે, પરંતુ જો `cb` panics પ્રદાન કરે છે, તો કેટલાક પ્લેટફોર્મ પ્રક્રિયાને અવગણવા માટે ડબલ panic ને દબાણ કરશે.
/// કેટલાક પ્લેટફોર્મ્સ સી લાઇબ્રેરીનો ઉપયોગ કરે છે જે આંતરિક રીતે ક callલબbacક્સનો ઉપયોગ કરે છે કે જેના દ્વારા અવાહક ન થઈ શકે, તેથી `cb` થી ગભરાઈને પ્રક્રિયાને છોડી દેવી પડશે.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // બેકટ્રેસ ચાલુ રાખો
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` ની જેમ જ, અસુરક્ષિત હોવાથી તે ફક્ત અસુરક્ષિત છે.
///
/// આ ફંક્શનમાં સિંક્રોનાઇઝેશન ગેરેંટીઝ નથી પરંતુ તે ત્યારે ઉપલબ્ધ છે જ્યારે આ ઝેડ 0 ક્રેટેટઝેડની `std` સુવિધા કમ્પાઈલ નથી.
/// વધુ દસ્તાવેજીકરણ અને ઉદાહરણો માટે `trace` ફંક્શન જુઓ.
///
/// # Panics
///
/// ગભરાટ ભર્યા `cb` પર ચેતવણીઓ માટે `trace` પરની માહિતી જુઓ.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// એક trait, જે બેકટ્રેસના એક ફ્રેમનું પ્રતિનિધિત્વ કરે છે, આ crate ના `trace` ફંક્શનને મળ્યો છે.
///
/// ટ્રેસિંગ ફંક્શનના બંધ થવાથી ફ્રેમ્સ પ્રાપ્ત થશે, અને ફ્રેમ વર્ચ્યુઅલ રૂપે મોકલવામાં આવશે કારણ કે અંતર્ગત અમલીકરણ હંમેશા રનટાઇમ સુધી જાણીતું નથી.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// આ ફ્રેમના વર્તમાન સૂચના નિર્દેશકને પરત કરે છે.
    ///
    /// આ ફ્રેમમાં અમલ કરવાની સામાન્ય રીતે આગળની સૂચના છે, પરંતુ તમામ અમલીકરણો 100% ચોકસાઈ સાથે આ સૂચિબદ્ધ કરતા નથી (પરંતુ તે સામાન્ય રીતે ખૂબ નજીક છે).
    ///
    ///
    /// તેને પ્રતીકના નામમાં ફેરવવા માટે આ મૂલ્યને `backtrace::resolve` પર પસાર કરવાની ભલામણ કરવામાં આવે છે.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// આ ફ્રેમનો વર્તમાન સ્ટેક પોઇન્ટર પાછો આપે છે.
    ///
    /// એવા કિસ્સામાં કે બેકએન્ડ આ ફ્રેમ માટે સ્ટેક પોઇન્ટરને ફરીથી પ્રાપ્ત કરી શકશે નહીં, એક નલ પોઇન્ટર પાછું આવે છે.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// આ ફંક્શનના ફ્રેમનો પ્રારંભિક પ્રતીક સરનામું આપે છે.
    ///
    /// આ, `ip` દ્વારા ફંક્શનની શરૂઆતમાં પાછા ફરતા સૂચના નિર્દેશકને ફરીથી વાળવાનો પ્રયાસ કરશે, તે મૂલ્ય પરત કરશે.
    ///
    /// કેટલાક કિસ્સાઓમાં, જોકે, બેકએન્ડ ફક્ત આ કાર્યથી `ip` પરત કરશે.
    ///
    /// જો આપેલ `ip` પર `backtrace::resolve` નિષ્ફળ થયું હોય તો પરત કરેલ મૂલ્યનો ઉપયોગ કેટલીકવાર થઈ શકે છે.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// મોડ્યુલનો આધાર સરનામું આપે છે કે જેમાં ફ્રેમ અનુલક્ષે છે.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // મીરી હોસ્ટ પ્લેટફોર્મ પર અગ્રતા લે છે તેની ખાતરી કરવા માટે આ પહેલા આવવાની જરૂર છે
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ફક્ત dbghelp પ્રતીકમાં વપરાય છે
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}