//! એમએસવીસી પ્લેટફોર્મ માટે બેકટ્રેસ વ્યૂહરચના.
//!
//! આ મોડ્યુલમાં એમએસવીસી પર બે શક્ય પદ્ધતિઓમાંથી એકનો ઉપયોગ કરીને બેકટ્રેસ જનરેટ કરવાની ક્ષમતા શામેલ છે.
//! `StackWalkEx` ફંક્શન મુખ્યત્વે જો શક્ય હોય તો ઉપયોગમાં લેવાય છે, પરંતુ બધી સિસ્ટમોમાં તે નથી.
//! નિષ્ફળ થવું કે તેના બદલે `StackWalk64` ફંક્શનનો ઉપયોગ થાય છે.
//! નોંધ લો કે `StackWalkEx` તરફેણ કરવામાં આવ્યું છે કારણ કે તે આંતરિક રીતે ડિબગિન્ફોને સંભાળે છે અને ઇનલાઇન ફ્રેમ માહિતી આપે છે.
//!
//!
//! નોંધ લો કે તમામ dbghelp સપોર્ટ ગતિશીલ રીતે લોડ થયેલ છે, તે વિશે વધુ માહિતી માટે `src/dbghelp.rs` જુઓ.
//!

#![allow(bad_style)]

use super::super::{dbghelp, windows::*};
use core::ffi::c_void;
use core::mem;

#[derive(Clone, Copy)]
pub enum StackFrame {
    New(STACKFRAME_EX),
    Old(STACKFRAME64),
}

#[derive(Clone, Copy)]
pub struct Frame {
    pub(crate) stack_frame: StackFrame,
    base_address: *mut c_void,
}

// અમે ફક્ત કાચા નિર્દેશકોની આસપાસ મોકલી રહ્યાં છીએ અને તેમને વાંચીએ છીએ, તેમનું અર્થઘટન ક્યારેય કરતા નથી જેથી આ થ્રેડોમાં મોકલવા અને શેર કરવા બંને માટે સલામત હોવું જોઈએ.
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        self.addr_pc().Offset as *mut _
    }

    pub fn sp(&self) -> *mut c_void {
        self.addr_stack().Offset as *mut _
    }

    pub fn symbol_address(&self) -> *mut c_void {
        self.ip()
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        Some(self.base_address)
    }

    fn addr_pc(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrPC,
            StackFrame::Old(ref old) => &old.AddrPC,
        }
    }

    fn addr_pc_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrPC,
            StackFrame::Old(ref mut old) => &mut old.AddrPC,
        }
    }

    fn addr_frame_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrFrame,
            StackFrame::Old(ref mut old) => &mut old.AddrFrame,
        }
    }

    fn addr_stack(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrStack,
            StackFrame::Old(ref old) => &old.AddrStack,
        }
    }

    fn addr_stack_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrStack,
            StackFrame::Old(ref mut old) => &mut old.AddrStack,
        }
    }
}

#[repr(C, align(16))] // `CONTEXT` દ્વારા આવશ્યક, અત્યારે વિનાપીમાં એક FIXME છે
struct MyContext(CONTEXT);

#[inline(always)]
pub unsafe fn trace(cb: &mut dyn FnMut(&super::Frame) -> bool) {
    // સ્ટેક વ walkક કરવા માટે જરૂરી રચનાઓ ફાળવો
    let process = GetCurrentProcess();
    let thread = GetCurrentThread();

    let mut context = mem::zeroed::<MyContext>();
    RtlCaptureContext(&mut context.0);

    // ખાતરી કરો કે આ પ્રક્રિયાના પ્રતીકો પ્રારંભ થયા છે
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // હા સારું...
    };

    // x86_64 અને ARM64 પર આપણે ફંક્શન ટેબલ અને મોડ્યુલ બેઝ મેળવવા માટે dbghelp માંથી મૂળભૂત `Sym*` ફંક્શનનો ઉપયોગ ન કરવાનું પસંદ કરીએ છીએ.
    // તેના બદલે અમે kernel32 માં `RtlLookupFunctionEntry` ફંક્શનનો ઉપયોગ કરીએ છીએ જે જેઆઈટી કમ્પાઈલર ફ્રેમ્સ માટે પણ જવાબદાર છે.
    // આ બરાબર હોવા જોઈએ, પરંતુ `Rtl*` નો ઉપયોગ અમને JIT ફ્રેમ્સ દ્વારા બેકટ્રેસ કરવાની મંજૂરી આપે છે.
    //
    // નોંધ લો કે `RtlLookupFunctionEntry` ફક્ત પ્રક્રિયામાં બેકટ્રેસ માટે જ કામ કરે છે, પરંતુ તે આપણે બધાને સમર્થન આપીએ છીએ, તેથી તે બધી લાઇન સારી રીતે વધે છે.
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(target_pointer_width = "64")] {
            use core::ptr;

            unsafe extern "system" fn function_table_access(_process: HANDLE, addr: DWORD64) -> PVOID {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut()).cast()
            }

            unsafe extern "system" fn get_module_base(_process: HANDLE, addr: DWORD64) -> DWORD64 {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut());
                base
            }
        } else {
            let function_table_access = dbghelp.SymFunctionTableAccess64();
            let get_module_base = dbghelp.SymGetModuleBase64();
        }
    }

    let process_handle = GetCurrentProcess();

    // જો આપણે કરી શકીએ તો `StackWalkEx` નો ઉપયોગ કરવાનો પ્રયાસ કરો, પરંતુ `StackWalk64` પર પાછા ફરો કારણ કે તે વધુ સિસ્ટમો પર સૈદ્ધાંતિક રીતે સપોર્ટેડ છે.
    //
    match (*dbghelp.dbghelp()).StackWalkEx() {
        Some(StackWalkEx) => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::New(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::New(ptr) => ptr as *mut STACKFRAME_EX,
                _ => unreachable!(),
            };

            while StackWalkEx(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
                0,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
        None => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::Old(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::Old(ptr) => ptr as *mut STACKFRAME64,
                _ => unreachable!(),
            };

            while dbghelp.StackWalk64()(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
    }
}

#[cfg(target_arch = "x86_64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Rip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Rsp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Rbp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_AMD64
}

#[cfg(target_arch = "x86")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Eip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Esp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Ebp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_I386
}

#[cfg(target_arch = "aarch64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.u.s().Fp as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARM64
}

#[cfg(target_arch = "arm")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.R11 as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARMNT
}