//! પ્રક્રિયા વિતરિત દ્વારા Rust panics નું અમલીકરણ
//!
//! જ્યારે અનઇન્ડિંગ દ્વારા અમલીકરણની તુલના કરવામાં આવે છે, ત્યારે આ ઝેડ 0 ક્રેટેઝેડ *ખૂબ* સરળ છે!એવું કહેવામાં આવે છે, તે એકદમ બહુમુખી નથી, પરંતુ અહીં જાય છે!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" પેલોડ અને પ્રશ્નમાં પ્લેટફોર્મ પર સંબંધિત ગર્ભપાત માટે શિમ.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ક00લ કરો std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows પર, પ્રોસેસર-વિશિષ્ટ __feldfail મિકેનિઝમનો ઉપયોગ કરો.Windows 8 અને પછીના સમયમાં, આ પ્રક્રિયામાં કોઈ અપવાદ હેન્ડલર્સ ચલાવ્યા વિના તરત જ પ્રક્રિયાને સમાપ્ત કરશે.
            // Windows ના પહેલાનાં સંસ્કરણોમાં, સૂચનોનો આ ક્રમ anક્સેસના ઉલ્લંઘન તરીકે ગણવામાં આવશે, પ્રક્રિયાને સમાપ્ત કરીને પરંતુ બધા અપવાદ હેન્ડલર્સને બાયપાસ કર્યા વિના.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: આ તે જ અમલ છે જે લિબસ્ટ્ડના `abort_internal` માં છે
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// આ ... થોડી વિચિત્રતા છે.ટીએલ; ડ dr;તે છે કે આને યોગ્ય રીતે લિંક કરવા માટે જરૂરી છે, લાંબી સ્પષ્ટતા નીચે છે.
//
// હમણાં libcore/libstd ની બાઈનરીઓ જે આપણે વહાવીએ છીએ તે બધા `-C panic=unwind` સાથે કમ્પાઇલ કરેલ છે.આ સુનિશ્ચિત કરવા માટે કરવામાં આવે છે કે શક્ય તેટલી પરિસ્થિતિઓમાં દ્વિસંગીઓ મહત્તમ સુસંગત છે.
// કમ્પાઈલર, જો કે, `-C panic=unwind` સાથે કમ્પાઇલ કરેલા બધા કાર્યો માટે "personality function" ની જરૂર છે.આ વ્યક્તિત્વ કાર્ય `rust_eh_personality` પ્રતીક પર હાર્ડકોડ થયેલ છે અને `eh_personality` લ langંગ આઇટમ દ્વારા વ્યાખ્યાયિત થયેલ છે.
//
// So...
// અહીં માત્ર તે લ langંગ વસ્તુની વ્યાખ્યા શા માટે નથી?સારો પ્રશ્ન!જે રીતે ઝેડપેનિનીક ઝેડ રનટાઈમ્સ સાથે જોડાયેલ છે તે ખરેખર થોડું સૂક્ષ્મ છે જેમાં તે કમ્પાઇલરના ઝેડ ક્રેટ0 ઝેડ સ્ટોરમાં "sort of" છે, પરંતુ જો ખરેખર અન્ય કડી થયેલ ન હોય તો ફક્ત તે ખરેખર જોડાયેલ છે.
//
// આનો અર્થ એ થાય છે કે આ ઝેડ 0 ક્રેટ 0 ઝેડ અને પેનિક_યુનવિન્ડ ઝેડ 0 ક્રેટ0 ઝેડ બંને કમ્પાઇલરની ઝેડક્રેટ 0 ઝેડ સ્ટોરમાં દેખાઈ શકે છે, અને જો બંને `eh_personality` લ itemંગ વસ્તુને વ્યાખ્યાયિત કરે છે, તો તે ભૂલને ફટકો પડશે.
//
// આ કમ્પાઇલરને હેન્ડલ કરવા માટે ફક્ત `eh_personality` ને નિર્ધારિત કરવું જરૂરી છે જો panic રનટાઇમ કનેક્ટ થવું એ અનઇન્ડિંગ રનટાઈમ છે, અને નહીં તો તે વ્યાખ્યાયિત કરવાની જરૂર નથી (યોગ્ય રીતે તેથી).
// આ કિસ્સામાં, જો કે, આ લાઇબ્રેરી ફક્ત આ પ્રતીકને વ્યાખ્યાયિત કરે છે જેથી ઓછામાં ઓછું ક્યાંક વ્યક્તિત્વ હોય.
//
// અનિવાર્યપણે આ પ્રતીક ફક્ત libcore/libstd બાઈનરી સુધી વાયર મેળવવા માટે વ્યાખ્યાયિત થયેલ છે, પરંતુ તે ક્યારેય બોલાવવું જોઈએ નહીં કારણ કે આપણે અનઇન્ડિંગ રનટાઇમ સાથે બધાને જોડતા નથી.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-Windows-gnu પર આપણે આપણી પોતાની પર્સનાલિટી ફંક્શનનો ઉપયોગ કરીએ છીએ જેને `ExceptionContinueSearch` પાછા આપવાની જરૂર છે કારણ કે આપણે આપણા બધા ફ્રેમ્સ પર જઈ રહ્યા છીએ.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ઉપરની જેમ, આ `eh_catch_typeinfo` લ itemંગ આઇટમને અનુરૂપ છે જે હાલમાં ફક્ત ઇમ્સ્ક્રિપ્ટન પર વપરાય છે.
    //
    // panics અપવાદો ઉત્પન્ન કરતું નથી અને વિદેશી અપવાદો હાલમાં -C panic=અવગણના સાથે યુબી છે (જોકે આ બદલાવને પાત્ર હોઈ શકે છે), કોઈપણ કેચ_વિનવિન્ડ ક callsલ્સ ક્યારેય આ ટાઇપનોફાનો ઉપયોગ કરશે નહીં.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // આ બંનેને અમારા સ્ટાર્ટઅપ objectsબ્જેક્ટ્સ દ્વારા i686-pc-Windows-gnu પર કહેવામાં આવે છે, પરંતુ તેમને કંઇપણ કરવાની જરૂર નથી જેથી લાશો opsભી થઈ ગઈ.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}