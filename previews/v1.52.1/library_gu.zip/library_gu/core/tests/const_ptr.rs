// બે બાઇટ્સ સાથે ગોઠવાયેલ
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // DATA.as_ptr() બે બાઇટ્સ સાથે ગોઠવાયેલ હોવાથી, તેમાં 1 બાઇટ ઉમેરીને અનલિઇન્ડ * ક constન્ટ u16 ઉત્પન્ન કરે છે
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// fn write() X core::ptr નો ઉપયોગ કરો;
//
//    const fn write_aligned()-> i32 mut ચાલો મ્યુટ રેઝ=0;
//        અસુરક્ષિત {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        રેઝ} કન્સ્ટ ALIGNED: i32 = write_aligned();
//    assert_eq! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] mut ચાલો mut two_aligned= [0u16; 2];
//        અસુરક્ષિત {દો અનલિઇન્ડ_પ્ટર= (two_aligned.as_mut_ptr() તરીકે *મ્યુટ એક્સ02 એક્સ તરીકે* મ્યુટ એક્સ 100 એક્સ;
//            ptr: : write_unaligned (unalign_ptr, u16::from_ne_bytes([0x23, 0x45]));} two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 {ચાલો મ્યુટ રેઝ=0;
//        અસલામત { (&mut res as *mut i32).write(42); } રેઝ} કન્સ્ટ ALIGNED: i32 = aligned();
//
//    assert_eq! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] mut ચાલો mut two_aligned= [0u16; 2];
//        અસુરક્ષિત {દો અનલિઇન્ડ_પ્ટર= (two_aligned.as_mut_ptr() તરીકે *મ્યુટ એક્સ02 એક્સ તરીકે* મ્યુટ એક્સ 100 એક્સ;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//
//