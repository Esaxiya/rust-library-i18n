use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // મીરી ખૂબ ધીમી છે
fn exact_sanity_test() {
    // આ પરીક્ષણ એ ચાલવાનું સમાપ્ત થાય છે જે હું ફક્ત ધારી શકું છું તે `exp2` લાઇબ્રેરી ફંક્શનનો કેટલાક ખૂણો ઇશ કેસ છે, આપણે જે પણ સી રનટાઇમ વાપરી રહ્યા છીએ તેમાં વ્યાખ્યાયિત છે.
    // વીએસ 2013 માં, આ કાર્યમાં દેખીતી રીતે ભૂલ આવી હતી કારણ કે કડી થયેલ હોય ત્યારે આ પરીક્ષણ નિષ્ફળ જાય છે, પરંતુ વી.એસ. 2015 સાથે બગ નિશ્ચિત દેખાય છે કારણ કે પરીક્ષણ ફક્ત સરસ રીતે ચાલે છે.
    //
    // બગ `exp2(-1057)` ના વળતર મૂલ્યમાં તફાવત લાગે છે, જ્યાં વીએસ 2013 માં તે બીટ પેટર્ન 0x2 સાથે ડબલ આપે છે અને વીએસ 2015 માં તે 0x20000 પાછું આપે છે.
    //
    //
    // હવે ફક્ત આ પરીક્ષણને સંપૂર્ણપણે એમએસવીસી પર અવગણો કારણ કે તેનું પરીક્ષણ બીજે ક્યાંય પણ કરવામાં આવ્યું છે અને અમે દરેક પ્લેટફોર્મના exp2 અમલીકરણનું પરીક્ષણ કરવામાં વધુ રસ ધરાવતા નથી.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}