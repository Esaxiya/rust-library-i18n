use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // આ સ્થિર સપાટીનું ક્ષેત્રફળ નથી, પરંતુ તેમની વચ્ચે `?` સસ્તી રાખવામાં મદદ કરે છે, ભલે LLVM હમણાં હમણાં તેનો લાભ ન લઈ શકે.
    //
    // (દુર્ભાગ્યે પરિણામ અને વિકલ્પ અસંગત છે, તેથી કંટ્રોલફ્લો બંને સાથે મેળ ખાતો નથી.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}