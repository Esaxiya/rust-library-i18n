//! આ મોડ્યુલ, `Any` trait લાગુ કરે છે, જે રન ટાઇમ રિફ્લેક્શન દ્વારા કોઈપણ `'static` પ્રકારનું ગતિશીલ ટાઇપિંગ સક્ષમ કરે છે.
//!
//! `Any` પોતે `TypeId` મેળવવા માટે ઉપયોગમાં લઈ શકાય છે, અને જ્યારે trait asબ્જેક્ટ તરીકે ઉપયોગમાં લેવાય છે ત્યારે તેમાં વધુ સુવિધાઓ છે.
//! `&dyn Any` (ઉધાર લીધેલી trait)બ્જેક્ટ) તરીકે, તેમાં `is` અને `downcast_ref` પદ્ધતિઓ છે, જો સમાવેલ મૂલ્ય આપેલ પ્રકારનું છે કે નહીં તે ચકાસવા માટે, અને પ્રકાર તરીકે આંતરિક મૂલ્યનો સંદર્ભ મેળવવા માટે.
//! `&mut dyn Any` તરીકે, આંતરિક મૂલ્યના પરિવર્તનશીલ સંદર્ભ મેળવવા માટે, `downcast_mut` પદ્ધતિ પણ છે.
//! `Box<dyn Any>` `downcast` પદ્ધતિ ઉમેરશે, જે `Box<T>` માં રૂપાંતરિત કરવાનો પ્રયાસ કરે છે.
//! સંપૂર્ણ વિગતો માટે [`Box`] દસ્તાવેજીકરણ જુઓ.
//!
//! નોંધ લો કે `&dyn Any` એ મૂલ્ય નિર્દિષ્ટ કોંક્રિટ પ્રકારનું છે કે કેમ તે ચકાસણી સુધી મર્યાદિત છે, અને તેનો ઉપયોગ trait ને પ્રકાર લાગુ કરે છે કે કેમ તે ચકાસવા માટે ઉપયોગમાં લઈ શકાતો નથી.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # સ્માર્ટ પોઇંટર્સ અને `dyn Any`
//!
//! `Any` ને trait asબ્જેક્ટ તરીકે, ખાસ કરીને `Box<dyn Any>` અથવા `Arc<dyn Any>` જેવા પ્રકારોનો ઉપયોગ કરતી વખતે ધ્યાનમાં રાખવાની વર્તણૂકનો એક ભાગ, તે છે કે ફક્ત કિંમત પર `.type_id()` ક callingલ કરવાથી *કન્ટેનર* ના `TypeId` ઉત્પન્ન થાય છે, અંતર્ગત trait objectબ્જેક્ટ નહીં.
//!
//! તેના બદલે સ્માર્ટ પોઇન્ટરને `&dyn Any` માં રૂપાંતરિત કરીને ટાળી શકાય છે, જે objectબ્જેક્ટના `TypeId` પરત કરશે.
//! દાખ્લા તરીકે:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // તમે આ ઇચ્છે તેવી સંભાવના વધુ છે:
//! let actual_id = (&*boxed).type_id();
//! // ... આના કરતાં:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! એવી સ્થિતિનો વિચાર કરો કે જ્યાં આપણે કોઈ ફંકશનમાં પસાર થયેલી કિંમતને લ logગઆઉટ કરવા માગીએ છીએ.
//! અમે અમલીકરણો ડીબગ પર કામ કરી રહ્યાં છે તે મૂલ્ય આપણે જાણીએ છીએ, પરંતુ અમે તેનો નક્કર પ્રકાર જાણતા નથી.અમે અમુક પ્રકારના વિશેષ સારવાર આપવાની ઇચ્છા રાખીએ છીએ: આ કિસ્સામાં શબ્દમાળાના મૂલ્યોની લંબાઈને તેના મૂલ્ય પહેલાં છાપવા.
//! કમ્પાઇલ સમયે અમારા મૂલ્યના નક્કર પ્રકારને આપણે જાણતા નથી, તેથી તેના બદલે આપણે રનટાઈમ પ્રતિબિંબનો ઉપયોગ કરવાની જરૂર છે.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // કોઈપણ પ્રકાર માટે લgerગર ફંક્શન કે જે ડીબગને લાગુ કરે છે.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // અમારી કિંમતને `String` માં રૂપાંતરિત કરવાનો પ્રયાસ કરો.
//!     // જો સફળ થાય, તો અમે સ્ટ્રિંગની લંબાઈ તેમજ તેની કિંમતને આઉટપુટ કરવા માંગીએ છીએ.
//!     // જો નહીં, તો તે એક અલગ પ્રકાર છે: ફક્ત તેને અજાણ્યા છાપો.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // આ ફંક્શન તેની સાથે કામ કરતા પહેલા તેના પરિમાણને લ logગ આઉટ કરવા માંગે છે.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... બીજા કોઈ કામ કરો
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// કોઈપણ trait
///////////////////////////////////////////////////////////////////////////////

/// ગતિશીલ ટાઇપનું અનુકરણ કરવા માટે એક ઝેડટ્રેટ 0 ઝેડ.
///
/// મોટાભાગના પ્રકારો `Any` અમલમાં મૂકે છે.જો કે, કોઈપણ પ્રકાર કે જેમાં બિન-સ્ટેટિક સંદર્ભ શામેલ નથી.
/// વધુ વિગતો માટે [module-level documentation][mod] જુઓ.
///
/// [mod]: crate::any
// આ trait અસુરક્ષિત નથી, જોકે અમે અસુરક્ષિત કોડ (દા.ત., `downcast`) માં તેના એકમાત્ર ઇમ્પ્લના `type_id` ફંક્શનની વિશિષ્ટતાઓ પર આધાર રાખીએ છીએ.સામાન્ય રીતે, તે સમસ્યા હશે, પરંતુ કારણ કે `Any` નો એક માત્ર પ્રોમ્પ્ટ એ ધાબળાનો અમલ છે, અન્ય કોઈ કોડ `Any` અમલમાં મૂકી શકશે નહીં.
//
// અમે આ trait ને અસંભવિત રૂપે બનાવી શકીએ છીએ-તે તમામ અમલીકરણોને નિયંત્રિત કરતા હોવાથી તે તૂટવાનું કારણ બનશે નહીં-પરંતુ અમે તે બંનેને ખરેખર જરૂરી નથી તેવું પસંદ કરતા નથી અને વપરાશકર્તાઓને અસુરક્ષિત traits અને અસુરક્ષિત પદ્ધતિઓના તફાવત વિશે મૂંઝવણમાં મૂકી શકો છો (એટલે કે, `type_id` હજી પણ ક callલ કરવા માટે સલામત રહેશે, પરંતુ અમે સંભવિત દસ્તાવેજોમાં સૂચવવા માંગીએ છીએ).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` ના `TypeId` મેળવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// કોઈપણ trait forબ્જેક્ટ્સ માટે વિસ્તરણ પદ્ધતિઓ.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// સુનિશ્ચિત કરો કે દા.ત. સાથે જોડાતા દા.ત.નું પરિણામ છાપવામાં આવી શકે છે અને તેથી તેનો ઉપયોગ `unwrap` સાથે કરવામાં આવશે
// જો રવાનગી અપકાસ્ટિંગ સાથે કામ કરે છે તો આખરે હવે જરૂર રહેશે નહીં.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// જો બedક્સ્ડ પ્રકાર `T` જેવું જ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // આ કાર્ય સાથે ઇન્સ્ટન્ટ કરેલા પ્રકારનાં `TypeId` મેળવો.
        let t = TypeId::of::<T>();

        // trait objectબ્જેક્ટ (`self`) માં પ્રકારનો `TypeId` મેળવો.
        let concrete = self.type_id();

        // સમાનતા પર બંને `ટાઇપ આઈડીઝની તુલના કરો.
        t == concrete
    }

    /// જો તે `T` પ્રકારનો હોય તો, અથવા જો તે ન હોય તો `None`, બedક્સવાળા મૂલ્યનો કેટલાક સંદર્ભ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // સલામતી: હમણાં જ ચકાસાયેલ છે કે શું આપણે સાચા પ્રકાર તરફ ધ્યાન આપી રહ્યા છીએ, અને આપણે તેના પર આધાર રાખી શકીએ છીએ
            // કે મેમરી સલામતી માટે તપાસો કારણ કે અમે કોઈપણ પ્રકાર માટે અમલમાં મૂક્યા છે;કોઈ અન્ય ઇમ્પલ્સ અસ્તિત્વમાં હોઈ શકશે નહીં કારણ કે તે અમારી પ્રોમ્પ્લ સાથે વિરોધાભાસી છે.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// જો તે `T` પ્રકારનો હોય તો, અથવા જો તે ન હોય તો `None`, બedક્સવાળા મૂલ્યનો કેટલાક પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // સલામતી: હમણાં જ ચકાસાયેલ છે કે શું આપણે સાચા પ્રકાર તરફ ધ્યાન આપી રહ્યા છીએ, અને આપણે તેના પર આધાર રાખી શકીએ છીએ
            // કે મેમરી સલામતી માટે તપાસો કારણ કે અમે કોઈપણ પ્રકાર માટે અમલમાં મૂક્યા છે;કોઈ અન્ય ઇમ્પલ્સ અસ્તિત્વમાં હોઈ શકશે નહીં કારણ કે તે અમારી પ્રોમ્પ્લ સાથે વિરોધાભાસી છે.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` પ્રકાર પર નિર્ધારિત પદ્ધતિ તરફ આગળ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ટાઇપઆઈડી અને તેની પદ્ધતિઓ
///////////////////////////////////////////////////////////////////////////////

/// એક `TypeId` પ્રકાર માટે વૈશ્વિક સ્તરે અનન્ય ઓળખકર્તા રજૂ કરે છે.
///
/// દરેક `TypeId` એક અપારદર્શક isબ્જેક્ટ છે જે અંદરની તપાસની મંજૂરી આપતી નથી પરંતુ ક્લોનીંગ, સરખામણી, છાપવા અને બતાવવા જેવા મૂળભૂત કામગીરીને મંજૂરી આપતું નથી.
///
///
/// એક `TypeId` હાલમાં ફક્ત એવા પ્રકારો માટે ઉપલબ્ધ છે કે જે `'static` નો સમાવેશ કરે છે, પરંતુ આ મર્યાદા ઝેડ ફ્યુચર0 ઝેડમાં દૂર થઈ શકે છે.
///
/// જ્યારે `TypeId` એ `Hash`, `PartialOrd` અને `Ord` લાગુ કરે છે, તે નોંધવું યોગ્ય છે કે હેશેશ અને orderર્ડરિંગ Rust પ્રકાશન વચ્ચે બદલાશે.
/// તમારા કોડની અંદર તેમના પર આધાર રાખતા સાવચેત રહો!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// આ જેનરિક ફંક્શન દ્વારા ઇન્સ્ટન્ટ કરવામાં આવ્યું છે તેના પ્રકારનું `TypeId` પરત આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// કોઈ પ્રકારનું નામ શબ્દમાળા કાપી નાંખે છે.
///
/// # Note
///
/// આ ડાયગ્નોસ્ટિક ઉપયોગ માટે છે.
/// પરત શબ્દમાળાઓનું ચોક્કસ વિષયવસ્તુ અને ફોર્મેટ ઉલ્લેખિત નથી, પ્રકારનાં શ્રેષ્ઠ પ્રયત્નોનું વર્ણન હોવા ઉપરાંત.
/// ઉદાહરણ તરીકે, `type_name::<Option<String>>()` પાછા આવી શકે તેવા શબ્દમાળાઓ વચ્ચે, `"Option<String>"` અને `"std::option::Option<std::string::String>"` છે.
///
///
/// પરત થયેલ શબ્દમાળાને પ્રકારનો અનોખો ઓળખકર્તા માનવો જોઇએ નહીં કારણ કે ઘણા પ્રકારો સમાન પ્રકારનાં નામ પર નકશા કરી શકે છે.
/// એ જ રીતે, કોઈ બાંયધરી નથી કે પ્રકારનાં તમામ ભાગો પરત થયેલ શબ્દમાળામાં દેખાશે: ઉદાહરણ તરીકે, આજીવન સ્પષ્ટકર્તાઓ હાલમાં શામેલ નથી.
/// આ ઉપરાંત, કમ્પાઇલરનાં સંસ્કરણો વચ્ચે આઉટપુટ બદલાઈ શકે છે.
///
/// વર્તમાન અમલીકરણ કમ્પાઇલર ડાયગ્નોસ્ટિક્સ અને ડિબગિન્ફો જેવા સમાન ઇન્ફ્રાસ્ટ્રક્ચરનો ઉપયોગ કરે છે, પરંતુ આ બાંહેધરી આપતું નથી.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// શબ્દમાળાની ટુકડા તરીકે પોઇંટ-ટુ મૂલ્યના પ્રકારનું નામ આપે છે.
/// આ `type_name::<T>()` જેવું જ છે, પરંતુ જ્યાં ચલનો પ્રકાર સરળતાથી ઉપલબ્ધ ન હોય ત્યાં ઉપયોગમાં લઈ શકાય છે.
///
/// # Note
///
/// આ ડાયગ્નોસ્ટિક ઉપયોગ માટે બનાવાયેલ છે.પ્રકારનાં શ્રેષ્ઠ પ્રયત્નોનું વર્ણન હોવા સિવાય, શબ્દમાળાઓનું ચોક્કસ સમાવિષ્ટો અને ફોર્મેટ ઉલ્લેખિત નથી.
/// ઉદાહરણ તરીકે, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` અથવા `"std::option::Option<std::string::String>"` પરત કરી શકે છે, પરંતુ `"foobar"` નહીં.
///
/// આ ઉપરાંત, કમ્પાઇલરનાં સંસ્કરણો વચ્ચે આઉટપુટ બદલાઈ શકે છે.
///
/// આ કાર્ય trait itબ્જેક્ટ્સને હલ કરતું નથી, એટલે કે `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` પરત કરી શકે છે, પરંતુ `"u32"` નહીં.
///
/// પ્રકારનાં નામને પ્રકારનો અનન્ય ઓળખકર્તા માનવો જોઈએ નહીં;
/// બહુવિધ પ્રકારો સમાન પ્રકારનું નામ શેર કરી શકે છે.
///
/// વર્તમાન અમલીકરણ કમ્પાઇલર ડાયગ્નોસ્ટિક્સ અને ડિબગિન્ફો જેવા સમાન ઇન્ફ્રાસ્ટ્રક્ચરનો ઉપયોગ કરે છે, પરંતુ આ બાંહેધરી આપતું નથી.
///
/// # Examples
///
/// ડિફ defaultલ્ટ પૂર્ણાંકો અને ફ્લોટ પ્રકારો છાપે છે.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}