//! પ્રકારો માટે `Default` trait જેમાં અર્થપૂર્ણ ડિફ defaultલ્ટ મૂલ્યો હોઈ શકે છે.

#![stable(feature = "rust1", since = "1.0.0")]

/// પ્રકારને ઉપયોગી ડિફ defaultલ્ટ મૂલ્ય આપવા માટે એક ઝેડટ્રેટ 0 ઝેડ.
///
/// કેટલીકવાર, તમે અમુક પ્રકારના મૂળભૂત મૂલ્ય પર પાછા આવવા માંગો છો, અને ખાસ કરીને તે શું છે તેની કાળજી લેશો નહીં.
/// આ `સ્ટ્રેક્ચ્સ સાથે વારંવાર આવે છે જે વિકલ્પોના સમૂહને વ્યાખ્યાયિત કરે છે:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// આપણે કેટલાક મૂળભૂત મૂલ્યો કેવી રીતે વ્યાખ્યાયિત કરી શકીએ?તમે `Default` નો ઉપયોગ કરી શકો છો:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// હવે, તમે બધા ડિફ defaultલ્ટ મૂલ્યો મેળવો.ઝેડ 0 રસ્ટ0 ઝેડ વિવિધ આદિમ પ્રકારના માટે `Default` લાગુ કરે છે.
///
/// જો તમે કોઈ વિશિષ્ટ વિકલ્પને ફરીથી લખવા માંગતા હો, પરંતુ હજી પણ અન્ય ડિફોલ્ટને જાળવી રાખો:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// જો આ પ્રકારનાં બધા ક્ષેત્રો `Default` લાગુ કરે છે, તો આ ઝેડ 0 ટ્રાઈટ0 ઝેડનો ઉપયોગ `#[derive]` સાથે થઈ શકે છે.
/// જ્યારે નિષ્કર્ષ કા ,વામાં આવે છે, ત્યારે તે દરેક ક્ષેત્રના પ્રકાર માટે મૂળભૂત મૂલ્યનો ઉપયોગ કરશે.
///
/// ## હું `Default` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// `default()` પદ્ધતિ માટે અમલ પ્રદાન કરો કે જે તમારા પ્રકારનું મૂલ્ય મૂળભૂત હોવું જોઈએ.
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// એક પ્રકાર માટે "default value" પરત કરે છે.
    ///
    /// ડિફaultલ્ટ મૂલ્યો હંમેશાં અમુક પ્રકારનાં પ્રારંભિક મૂલ્ય, ઓળખ મૂલ્ય અથવા બીજું કંઈપણ હોય છે જે ડિફોલ્ટ તરીકે સમજાય છે.
    ///
    ///
    /// # Examples
    ///
    /// બિલ્ટ-ઇન ડિફ defaultલ્ટ મૂલ્યોનો ઉપયોગ:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// તમારા પોતાના બનાવો:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait મુજબના પ્રકારનું ડિફ defaultલ્ટ મૂલ્ય પાછા ફરો.
///
/// પાછા ફરવાનો પ્રકાર સંદર્ભથી અનુમાન લગાવવામાં આવે છે;આ `Default::default()` ની બરાબર છે પરંતુ ટૂંકમાં ટૂંકું છે.
///
/// દાખ્લા તરીકે:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }