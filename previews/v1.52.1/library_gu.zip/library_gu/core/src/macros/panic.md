વર્તમાન થ્રેડ Panics.

આ પ્રોગ્રામને તરત જ સમાપ્ત કરવાની અને પ્રોગ્રામના કlerલરને પ્રતિસાદ પ્રદાન કરવાની મંજૂરી આપે છે.
`panic!` જ્યારે કોઈ પ્રોગ્રામ પ્રાપ્ત ન થઈ શકે તેવી સ્થિતિમાં પહોંચે ત્યારે તેનો ઉપયોગ કરવો જોઈએ.

આ મેક્રો એ ઉદાહરણ કોડમાં અને પરીક્ષણોમાં શરતોનો સંપૂર્ણ માર્ગ છે.
`panic!` [`Option`][ounwrap] અને [`Result`][runwrap] બંને enums ની `unwrap` પદ્ધતિ સાથે ગા closely રીતે બંધાયેલ છે.
બંને અમલીકરણો `panic!` ને ક callલ કરે છે જ્યારે તેઓ [`None`] અથવા [`Err`] ચલો પર સેટ હોય છે.

`panic!()` નો ઉપયોગ કરતી વખતે, તમે શબ્દમાળા પેલોડને સ્પષ્ટ કરી શકો છો, જે [`format!`] સિન્ટેક્સનો ઉપયોગ કરીને બનાવવામાં આવ્યો છે.
તે પેલોડનો ઉપયોગ ક0લિંગ ઝેડ રસ્ટ0 ઝેડ થ્રેડમાં ઝેડ 0 પicનિકિક ઝેડને ઇન્જેક્શન આપતી વખતે થાય છે, થ્રેડને સંપૂર્ણપણે ઝેડપpanનિકિક ઝેડમાં પરિણમે છે.

મૂળભૂત `std` hook ની વર્તણૂક, એટલે કે
કોડ કે જે સીધી ઝેડપpanનિક 80 ઝેડ પછી ચાલે છે, તે `panic!()` ક ofલની file/line/column માહિતી સાથે, `stderr` પર સંદેશ પેલોડ છાપવા માટે છે.

તમે [`std::panic::set_hook()`] નો ઉપયોગ કરીને panic hook પર ફરીથી લખી શકો છો.
ઝેડહૂક0 ઝેડની અંદર એક ઝેડ 0 પicનીક્સ 0 ઝેડને એક્સ 100 એક્સ તરીકે .ક્સેસ કરી શકાય છે, જેમાં નિયમિત `panic!()` આમંત્રણો માટે `&str` અથવા `String` શામેલ છે.
બીજા પ્રકારનાં મૂલ્ય સાથે ઝેડપpanનિક 80 ઝેડ સુધી, [`panic_any`] નો ઉપયોગ કરી શકાય છે.

[`Result`] `panic!` મcક્રોનો ઉપયોગ કરતાં ભૂલોમાંથી પુનingપ્રાપ્ત કરવા માટે enum એ ઘણી વાર સારો ઉપાય છે.
આ મેક્રોનો ઉપયોગ બાહ્ય સ્રોતો જેવા ખોટા મૂલ્યોનો ઉપયોગ કરીને આગળ વધવાનું ટાળવા માટે થવું જોઈએ.
ભૂલ નિયંત્રણ વિશે વિગતવાર માહિતી [book] માં મળી છે.

સંકલન દરમિયાન ભૂલો વધારવા માટે, મેક્રો [`compile_error!`] પણ જુઓ.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# વર્તમાન અમલીકરણ

જો મુખ્ય થ્રેડ panics તે તમારા બધા થ્રેડોને સમાપ્ત કરશે અને કોડ `101` સાથે તમારા પ્રોગ્રામનો અંત કરશે.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





