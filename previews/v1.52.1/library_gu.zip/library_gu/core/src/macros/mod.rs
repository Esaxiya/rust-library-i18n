#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // કlerલરની આવૃત્તિના આધારે ક્યાં તો `$crate::panic::panic_2015` અથવા `$crate::panic::panic_2021` સુધી વિસ્તૃત થાય છે.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ભારપૂર્વક જણાવે છે કે બે અભિવ્યક્તિઓ એકબીજાની સમાન છે ([`PartialEq`] નો ઉપયોગ કરીને).
///
/// ઝેડ 0 પicનિક 80 ઝેડ પર, આ મેક્રો અભિવ્યક્તિઓના મૂલ્યોને તેમની ડિબગ રજૂઆતોથી છાપશે.
///
///
/// [`assert!`] ની જેમ, આ મેક્રોનું બીજું સ્વરૂપ છે, જ્યાં એક કસ્ટમ panic સંદેશ પ્રદાન કરી શકાય છે.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // નીચેના રેબોરોઝ ઇરાદાપૂર્વકના છે.
                    // તેમના વિના, valuesણ માટેના સ્ટેક સ્લોટ મૂલ્યોની તુલના કરવામાં આવે તે પહેલાં જ શરૂ કરવામાં આવે છે, જે નોંધપાત્ર ધીમી તરફ દોરી જાય છે.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // નીચેના રેબોરોઝ ઇરાદાપૂર્વકના છે.
                    // તેમના વિના, valuesણ માટેના સ્ટેક સ્લોટ મૂલ્યોની તુલના કરવામાં આવે તે પહેલાં જ શરૂ કરવામાં આવે છે, જે નોંધપાત્ર ધીમી તરફ દોરી જાય છે.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ભારપૂર્વક જણાવે છે કે બે અભિવ્યક્તિઓ એકબીજાની સમાન નથી ([`PartialEq`] નો ઉપયોગ કરીને).
///
/// ઝેડ 0 પicનિક 80 ઝેડ પર, આ મેક્રો અભિવ્યક્તિઓના મૂલ્યોને તેમની ડિબગ રજૂઆતોથી છાપશે.
///
///
/// [`assert!`] ની જેમ, આ મેક્રોનું બીજું સ્વરૂપ છે, જ્યાં એક કસ્ટમ panic સંદેશ પ્રદાન કરી શકાય છે.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // નીચેના રેબોરોઝ ઇરાદાપૂર્વકના છે.
                    // તેમના વિના, valuesણ માટેના સ્ટેક સ્લોટ મૂલ્યોની તુલના કરવામાં આવે તે પહેલાં જ શરૂ કરવામાં આવે છે, જે નોંધપાત્ર ધીમી તરફ દોરી જાય છે.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // નીચેના રેબોરોઝ ઇરાદાપૂર્વકના છે.
                    // તેમના વિના, valuesણ માટેના સ્ટેક સ્લોટ મૂલ્યોની તુલના કરવામાં આવે તે પહેલાં જ શરૂ કરવામાં આવે છે, જે નોંધપાત્ર ધીમી તરફ દોરી જાય છે.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ભારપૂર્વક જણાવે છે કે રનટાઇમ પર બુલિયન અભિવ્યક્તિ `true` છે.
///
/// જો XTX એક્સ મેક્રોનો પ્રારંભ કરશે જો પૂરા પાડવામાં આવેલા અભિવ્યક્તિનું મૂલ્યાંકન રનટાઈમ સમયે `true` પર ન કરી શકાય.
///
/// [`assert!`] ની જેમ, આ મેક્રોનું પણ બીજું સંસ્કરણ છે, જ્યાં કસ્ટમ panic સંદેશ પ્રદાન કરી શકાય છે.
///
/// # Uses
///
/// [`assert!`] થી વિપરીત, `debug_assert!` સ્ટેટમેન્ટ્સ ફક્ત ડિફ defaultલ્ટ રૂપે બિન-izedપ્ટિમાઇઝ બિલ્ડ્સમાં જ સક્ષમ છે.
/// 0પ્ટિમાઇઝ બિલ્ડ `debug_assert!` સ્ટેટમેન્ટને અમલમાં મૂકશે નહીં સિવાય કે `-C debug-assertions` કમ્પાઇલરને પસાર કરવામાં આવે.
/// આ `debug_assert!` ને ચકાસણી માટે ઉપયોગી બનાવે છે જે પ્રકાશન બિલ્ડમાં હાજર રહેવું ખૂબ ખર્ચાળ છે પરંતુ વિકાસ દરમિયાન તે મદદરૂપ થઈ શકે છે.
/// એક્સ00 એક્સના વિસ્તરણનું પરિણામ હંમેશાં પ્રકાર ચકાસાયેલ હોય છે.
///
/// અનચેક કરેલું નિવેદન અસંગત સ્થિતિમાં પ્રોગ્રામને ચાલુ રાખવાની મંજૂરી આપે છે, જેના અનપેક્ષિત પરિણામો હોઈ શકે છે પરંતુ જ્યાં સુધી આ ફક્ત સલામત કોડમાં થાય ત્યાં સુધી અસુવિધા રજૂ કરતું નથી.
///
/// નિવેદનોની કામગીરીની કિંમત, જો કે, સામાન્ય રીતે માપવા યોગ્ય નથી.
/// [`assert!`] ને `debug_assert!` સાથે બદલવાનું આમ માત્ર સંપૂર્ણ પ્રોફાઇલિંગ પછી પ્રોત્સાહિત કરવામાં આવે છે, અને વધુ મહત્ત્વની વાત તો એ છે કે ફક્ત સલામત કોડમાં જ!
///
/// # Examples
///
/// ```
/// // આ નિવેદનો માટે panic સંદેશ એ આપેલ અભિવ્યક્તિનું સ્ટ્રિનાઇઝ્ડ મૂલ્ય છે.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ખૂબ જ સરળ કાર્ય
/// debug_assert!(some_expensive_computation());
///
/// // વૈવિધ્યપૂર્ણ સંદેશ સાથે ભાર મૂકો
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// દાવો કરે છે કે બે અભિવ્યક્તિઓ એકબીજાના સમાન છે.
///
/// ઝેડ 0 પicનિક 80 ઝેડ પર, આ મેક્રો અભિવ્યક્તિઓના મૂલ્યોને તેમની ડિબગ રજૂઆતોથી છાપશે.
///
/// [`assert_eq!`] થી વિપરીત, `debug_assert_eq!` સ્ટેટમેન્ટ્સ ફક્ત ડિફ defaultલ્ટ રૂપે બિન-izedપ્ટિમાઇઝ બિલ્ડ્સમાં જ સક્ષમ છે.
/// 0પ્ટિમાઇઝ બિલ્ડ `debug_assert_eq!` સ્ટેટમેન્ટને અમલમાં મૂકશે નહીં સિવાય કે `-C debug-assertions` કમ્પાઇલરને પસાર કરવામાં આવે.
/// આ `debug_assert_eq!` ને ચકાસણી માટે ઉપયોગી બનાવે છે જે પ્રકાશન બિલ્ડમાં હાજર રહેવું ખૂબ ખર્ચાળ છે પરંતુ વિકાસ દરમિયાન તે મદદરૂપ થઈ શકે છે.
///
/// એક્સ00 એક્સના વિસ્તરણનું પરિણામ હંમેશાં પ્રકાર ચકાસાયેલ હોય છે.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// દાવો કરે છે કે બે અભિવ્યક્તિઓ એકબીજાની સમાન નથી.
///
/// ઝેડ 0 પicનિક 80 ઝેડ પર, આ મેક્રો અભિવ્યક્તિઓના મૂલ્યોને તેમની ડિબગ રજૂઆતોથી છાપશે.
///
/// [`assert_ne!`] થી વિપરીત, `debug_assert_ne!` સ્ટેટમેન્ટ્સ ફક્ત ડિફ defaultલ્ટ રૂપે બિન-izedપ્ટિમાઇઝ બિલ્ડ્સમાં જ સક્ષમ છે.
/// 0પ્ટિમાઇઝ બિલ્ડ `debug_assert_ne!` સ્ટેટમેન્ટને અમલમાં મૂકશે નહીં સિવાય કે `-C debug-assertions` કમ્પાઇલરને પસાર કરવામાં આવે.
/// આ `debug_assert_ne!` ને ચકાસણી માટે ઉપયોગી બનાવે છે જે પ્રકાશન બિલ્ડમાં હાજર રહેવું ખૂબ ખર્ચાળ છે પરંતુ વિકાસ દરમિયાન તે મદદરૂપ થઈ શકે છે.
///
/// એક્સ00 એક્સના વિસ્તરણનું પરિણામ હંમેશાં પ્રકાર ચકાસાયેલ હોય છે.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// આપેલ અભિવ્યક્તિ આપેલ કોઈપણ નમૂનાઓ સાથે મેળ ખાય છે કે કેમ તે પરત કરે છે.
///
/// `match` અભિવ્યક્તિની જેમ, પેટર્નને વૈકલ્પિક રૂપે `if` અને ગાર્ડ અભિવ્યક્તિ દ્વારા અનુસરી શકાય છે જેમાં પેટર્ન દ્વારા બંધાયેલા નામોની accessક્સેસ હોય છે.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// કોઈ પરિણામ અનપ્રેપ કરે છે અથવા તેની ભૂલનો પ્રચાર કરે છે.
///
/// `?` એક્સને બદલવા માટે `?` operatorપરેટર ઉમેર્યું હતું અને તેના બદલે તેનો ઉપયોગ થવો જોઈએ.
/// તદુપરાંત, ઝેડ રસ્ટ0 ઝેડ 2018 માં `try` એ આરક્ષિત શબ્દ છે, તેથી જો તમારે તેનો ઉપયોગ કરવો જ જોઇએ, તો તમારે [raw-identifier syntax][ris] નો ઉપયોગ કરવો પડશે: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` આપેલ [`Result`] સાથે મેળ ખાય છે.`Ok` વેરિઅન્ટના કિસ્સામાં, અભિવ્યક્તિમાં આવરિત મૂલ્યનું મૂલ્ય છે.
///
/// `Err` વેરિઅન્ટના કિસ્સામાં, તે આંતરિક ભૂલને ફરીથી પ્રાપ્ત કરે છે.`try!` પછી `From` નો ઉપયોગ કરીને રૂપાંતર કરે છે.
/// આ વિશિષ્ટ ભૂલો અને વધુ સામાન્ય લોકો વચ્ચે આપમેળે રૂપાંતર પ્રદાન કરે છે.
/// ત્યારબાદ પરિણામી ભૂલ તરત જ પરત આવે છે.
///
/// પ્રારંભિક વળતરને કારણે, `try!` નો ઉપયોગ ફક્ત તે કાર્યોમાં થઈ શકે છે જે [`Result`] પાછા આપે છે.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ઝડપી પાછા ફરતી ભૂલોની પસંદગીની પદ્ધતિ
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ઝડપી પાછા આપવાની ભૂલોની પાછલી પદ્ધતિ
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // આ બરાબર છે:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// બફરમાં ફોર્મેટેડ ડેટા લખે છે.
///
/// આ મેક્રો 'writer', ફોર્મેટ શબ્દમાળા અને દલીલોની સૂચિ સ્વીકારે છે.
/// દલીલો નિર્દિષ્ટ બંધારણના શબ્દમાળા અનુસાર ફોર્મેટ કરવામાં આવશે અને પરિણામ લેખકને આપવામાં આવશે.
/// `write_fmt` પદ્ધતિ સાથે લેખકનું કોઈ મૂલ્ય હોઈ શકે છે;સામાન્ય રીતે આ [`fmt::Write`] અથવા [`io::Write`] trait ક્યાં તો અમલીકરણથી આવે છે.
/// `write_fmt` પદ્ધતિ જે પણ આપે છે તે મેક્રો આપે છે;સામાન્ય રીતે [`fmt::Result`], અથવા [`io::Result`].
///
/// ફોર્મેટ શબ્દમાળા વાક્યરચના પર વધુ માહિતી માટે [`std::fmt`] જુઓ.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// એક મોડ્યુલ, `std::fmt::Write` અને `std::io::Write` બંને આયાત કરી શકે છે અને ક્યાં અમલીકરણ કરનારા objectsબ્જેક્ટ્સ પર `write!` પર ક .લ કરી શકે છે, કારણ કે objectsબ્જેક્ટ સામાન્ય રીતે બંનેને અમલમાં મૂકતા નથી.
///
/// તેમ છતાં, મોડ્યુલને traits લાયક લાયક આયાત કરવી આવશ્યક છે જેથી તેમના નામો વિરોધાભાસી ન આવે:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt નો ઉપયોગ કરે છે
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt નો ઉપયોગ કરે છે
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: આ મેક્રોનો ઉપયોગ `no_std` સેટઅપ્સમાં પણ થઈ શકે છે.
/// `no_std` સેટઅપમાં તમે ઘટકોના અમલીકરણની વિગતો માટે જવાબદાર છો.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// નવી લાઇન જોડાયેલ સાથે, બફરમાં ફોર્મેટ કરેલ ડેટા લખો.
///
/// બધા પ્લેટફોર્મ પર, નવી લાઇન એ એકલા લાઈન ફીડ અક્ષર (`\n`/`U+000A`) છે (કોઈ વધારાની કેરેજ રીટર્ન (`\r`/`U+000D`) નથી.
///
/// વધુ માહિતી માટે, [`write!`] જુઓ.ફોર્મેટ શબ્દમાળા વાક્યરચના પરની માહિતી માટે, [`std::fmt`] જુઓ.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// એક મોડ્યુલ, `std::fmt::Write` અને `std::io::Write` બંને આયાત કરી શકે છે અને ક્યાં અમલીકરણ કરનારા objectsબ્જેક્ટ્સ પર `write!` પર ક .લ કરી શકે છે, કારણ કે objectsબ્જેક્ટ સામાન્ય રીતે બંનેને અમલમાં મૂકતા નથી.
/// તેમ છતાં, મોડ્યુલને traits લાયક લાયક આયાત કરવી આવશ્યક છે જેથી તેમના નામો વિરોધાભાસી ન આવે:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt નો ઉપયોગ કરે છે
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt નો ઉપયોગ કરે છે
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// પહોંચ ન શકાય તેવો કોડ સૂચવે છે.
///
/// આ કોઈપણ સમયે ઉપયોગી છે કે કમ્પાઇલર એ નિર્ધારિત કરી શકતું નથી કે કેટલાક કોડ પહોંચ ન કરી શકાય તેવું છે.દાખ્લા તરીકે:
///
/// * રક્ષકની સ્થિતિ સાથે શસ્ત્ર મેળવો.
/// * ગતિશીલ રૂપે સમાપ્ત થતી આંટીઓ.
/// * ગતિશીલ રીતે સમાપ્ત થતા અલ્ટર.
///
/// જો નિર્ધારણ છે કે કોડ પહોંચી શકાય તેવા નથી તે ખોટી સાબિત થાય છે, તો પ્રોગ્રામ તરત જ એક [`panic!`] સાથે સમાપ્ત થાય છે.
///
/// આ મcક્રોનો અસુરક્ષિત કાઉન્ટર પાર્ટ એ [`unreachable_unchecked`] ફંક્શન છે, જે કોડ પહોંચે તો અસ્પષ્ટ વર્તનનું કારણ બનશે.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// આ હંમેશા [`panic!`] રહેશે.
///
/// # Examples
///
/// હથિયારો સાથે મેચ કરો:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // જો ટિપ્પણી થયેલ હોય તો કમ્પાઇલ ભૂલ
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 ના ગરીબ અમલીકરણોમાંથી એક
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" ના સંદેશથી ગભરાઈને અમલ વિનાનો કોડ સૂચવે છે.
///
/// આ તમારા કોડને ટાઇપ-ચેક કરવાની મંજૂરી આપે છે, જે ઉપયોગી છે જો તમે trait પ્રોટોટાઇપ કરી રહ્યાં છો અથવા લાગુ કરી રહ્યા છો કે જેમાં બહુવિધ પદ્ધતિઓની જરૂર છે જેનો તમે બધા ઉપયોગ કરવાની યોજના નથી કરી.
///
/// `unimplemented!` અને [`todo!`] વચ્ચેનો તફાવત એ છે કે જ્યારે `todo!` પાછળથી વિધેયને લાગુ કરવાનો ઇરાદો આપે છે અને સંદેશ "not yet implemented" છે, `unimplemented!` આવા કોઈ દાવા કરતું નથી.
/// તેનો સંદેશ "not implemented" છે.
/// પણ કેટલાક IDEs `todo!` ને ચિહ્નિત કરશે.
///
/// # Panics
///
/// આ હંમેશાં [`panic!`] રહેશે કારણ કે `unimplemented!` એ એક નિશ્ચિત, વિશિષ્ટ સંદેશ સાથે `panic!` માટેનો શોર્ટહેન્ડ છે.
///
/// `panic!` ની જેમ, આ મેક્રો પાસે વૈવિધ્યપૂર્ણ મૂલ્યો પ્રદર્શિત કરવા માટેનું બીજું ફોર્મ છે.
///
/// # Examples
///
/// કહો કે અમારી પાસે trait `Foo` છે:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// અમે 'MyStruct' માટે `Foo` ને અમલમાં મૂકવા માંગીએ છીએ, પરંતુ કેટલાક કારણોસર તે `bar()` ફંક્શનને અમલમાં મૂકવા માટે માત્ર અર્થપૂર્ણ છે.
/// `baz()` અને `qux()` ને હજી પણ અમારા `Foo` ના અમલીકરણમાં નિર્ધારિત કરવાની જરૂર રહેશે, પરંતુ અમે અમારા કોડને કમ્પાઇલ કરવા માટે, તેમની વ્યાખ્યાઓમાં `unimplemented!` નો ઉપયોગ કરી શકીએ છીએ.
///
/// જો અમલ વિનાની પદ્ધતિઓ પહોંચી જાય તો અમારું પ્રોગ્રામ ચાલુ થવાનું બંધ રાખવું છે.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // તે `baz` ને `MyStruct` નો અર્થપૂર્ણ નથી, તેથી અમારી પાસે અહીં કોઈ તર્ક નથી.
/////
///         // આ "thread 'main' panicked at 'not implemented'" પ્રદર્શિત કરશે.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // અમારી પાસે અહીં થોડું તર્ક છે, અમે અમલ વિના સંદેશ ઉમેરી શકીએ છીએ!અમારી અવગણના દર્શાવવા માટે.
///         // આ પ્રદર્શિત કરશે: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// અપૂર્ણ કોડ સૂચવે છે.
///
/// જો તમે પ્રોટોટાઇપ કરી રહ્યાં છો અને તમારો કોડ ટાઇપચેક શોધી રહ્યા છો, તો આ ઉપયોગી થઈ શકે છે.
///
/// [`unimplemented!`] અને `todo!` વચ્ચેનો તફાવત એ છે કે જ્યારે `todo!` પાછળથી વિધેયને લાગુ કરવાનો ઇરાદો આપે છે અને સંદેશ "not yet implemented" છે, `unimplemented!` આવા કોઈ દાવા કરતું નથી.
/// તેનો સંદેશ "not implemented" છે.
/// પણ કેટલાક IDEs `todo!` ને ચિહ્નિત કરશે.
///
/// # Panics
///
/// આ હંમેશા [`panic!`] રહેશે.
///
/// # Examples
///
/// અહીં કેટલાક પ્રગતિ કોડનું ઉદાહરણ છે.અમારી પાસે trait `Foo` છે:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// અમે અમારા પ્રકારોમાંથી કોઈ એક પર `Foo` અમલમાં મૂકવા માંગીએ છીએ, પરંતુ અમે ફક્ત `bar()` પર પણ પ્રથમ કાર્ય કરવા માંગીએ છીએ.અમારા કોડને કમ્પાઇલ કરવા માટે, અમારે `baz()` લાગુ કરવાની જરૂર છે, તેથી અમે `todo!` નો ઉપયોગ કરી શકીએ:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // અમલીકરણ અહીં જાય છે
///     }
///
///     fn baz(&self) {
///         // ચાલો હવે માટે baz() લાગુ કરવા વિશે ચિંતા ન કરીએ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // અમે baz() નો ઉપયોગ પણ કરી રહ્યા નથી, તેથી આ સારું છે.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// બિલ્ટ-ઇન મેક્રોઝની વ્યાખ્યા.
///
/// મોટાભાગના મેક્રો ગુણધર્મો (સ્થિરતા, દ્રશ્યતા, વગેરે) અહીંના સ્રોત કોડમાંથી લેવામાં આવ્યા છે, વિસ્તરણ કાર્યો સિવાયના મેક્રો ઇનપુટ્સને આઉટપુટમાં રૂપાંતરિત કરે છે, તે કાર્યો કમ્પાઇલર દ્વારા પ્રદાન કરવામાં આવે છે.
///
///
pub(crate) mod builtin {

    /// જ્યારે આપણને મળેલ ભૂલ સંદેશ સાથે સંકલનમાં નિષ્ફળ થવાનું કારણ બને છે.
    ///
    /// આ મેક્રોનો ઉપયોગ જ્યારે ઝેડ 0 ક્રેટ 0 ઝેન્ડ ભૂલભરેલી પરિસ્થિતિઓ માટે વધુ સારા ભૂલ સંદેશાઓ પ્રદાન કરવા માટે શરતી સંકલન વ્યૂહરચનાનો ઉપયોગ કરે છે ત્યારે થવો જોઈએ.
    ///
    /// તે [`panic!`] નું કમ્પાઈલર-સ્તરનું સ્વરૂપ છે, પરંતુ *કટિલેશન* દરમ્યાન *રનટાઈમ* કરતા ભૂલ કાitsે છે.
    ///
    /// # Examples
    ///
    /// આવા બે ઉદાહરણો છે મેક્રોઝ અને `#[cfg]` વાતાવરણ.
    ///
    /// જો મેક્રો અમાન્ય મૂલ્યોને પસાર કરે તો વધુ સારી રીતે કમ્પાઇલર ભૂલ બહાર કા .ો.
    /// અંતિમ ઝેડબ્રાંચ0 ઝેડ વિના, કમ્પાઇલર હજી પણ ભૂલ બહાર કા .શે, પરંતુ ભૂલનો સંદેશ બે માન્ય મૂલ્યોનો ઉલ્લેખ કરશે નહીં.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// જો સંખ્યાબંધ સુવિધાઓમાંથી કોઈ એક ઉપલબ્ધ ન હોય તો કમ્પાઇલર ભૂલ બહાર કાmitો.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// અન્ય સ્ટ્રિંગ-ફોર્મેટિંગ મેક્રો માટે પરિમાણો બનાવે છે.
    ///
    /// આ વધારાના દરેક દલીલ માટે `{}` ધરાવતા ફોર્મેટિંગ શબ્દમાળાને શામેલ કરીને આ મેક્રો કાર્ય કરે છે.
    /// `format_args!` વધારાના પરિમાણો તૈયાર કરે છે તેની ખાતરી કરવા માટે કે આઉટપુટને શબ્દમાળા તરીકે અર્થઘટન કરી શકાય અને દલીલોને એક જ પ્રકારમાં માન્ય કરી શકાય.
    /// કોઈપણ મૂલ્ય કે જે [`Display`] trait ને લાગુ કરે છે તે `format_args!` માં પસાર થઈ શકે છે, કારણ કે કોઈપણ [`Debug`] અમલીકરણ ફોર્મેટિંગ સ્ટ્રિંગની અંદર `{:?}` પર પસાર થઈ શકે છે.
    ///
    ///
    /// આ મેક્રો [`fmt::Arguments`] પ્રકારનું મૂલ્ય ઉત્પન્ન કરે છે.ઉપયોગીતા રીડાયરેક્શન કરવા માટે, આ મૂલ્ય [`std::fmt`] ની અંદર મેક્રોઝને આપી શકાય છે.
    /// અન્ય તમામ ફોર્મેટિંગ મેક્રો ([`ફોર્મેટ!`], [`write!`], [`println!`], વગેરે) આના દ્વારા પ્રોક્સી કરેલા છે.
    /// `format_args!`, તેના મેળવેલા મેક્રોથી વિપરીત, apગલા ફાળવણીને ટાળે છે.
    ///
    /// તમે [`fmt::Arguments`] મૂલ્યનો ઉપયોગ કરી શકો છો જે `format_args!` `Debug` અને `Display` સંદર્ભમાં આપે છે તે નીચે આપેલી છે.
    /// ઉદાહરણ એ પણ બતાવે છે કે તે જ વસ્તુ માટે `Debug` અને `Display` ફોર્મેટ: `format_args!` માં ઇન્ટરપોલેટેડ ફોર્મેટ શબ્દમાળા.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// વધુ માહિતી માટે, [`std::fmt`] માં દસ્તાવેજો જુઓ.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` જેવું જ છે, પરંતુ અંતે એક નવી લાઇન ઉમેરશે.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// કમ્પાઇલ સમયે પર્યાવરણ ચલની તપાસ કરે છે.
    ///
    /// આ મેક્રો સંકલન સમયે નામવાળી પર્યાવરણ ચલના મૂલ્યમાં વિસ્તૃત થશે, જે `&'static str` પ્રકારનું અભિવ્યક્તિ પ્રાપ્ત કરશે.
    ///
    ///
    /// જો પર્યાવરણ ચલ વ્યાખ્યાયિત થયેલ નથી, તો પછી સંકલન ભૂલ બહાર આવશે.
    /// સંકલન ભૂલને બહાર ન કાmitવા માટે, તેના બદલે [`option_env!`] મેક્રોનો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// તમે બીજા પરિમાણ તરીકે શબ્દમાળા પસાર કરીને ભૂલ સંદેશને કસ્ટમાઇઝ કરી શકો છો:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// જો `documentation` પર્યાવરણ ચલ વ્યાખ્યાયિત નથી, તો તમને નીચેની ભૂલ મળશે:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// કમ્પાઇલ સમયે પર્યાવરણ ચલનું વૈકલ્પિક નિરીક્ષણ કરો.
    ///
    /// જો નામવાળી પર્યાવરણ ચલ કમ્પાઇલ સમયે હાજર હોય, તો તે પ્રકાર `Option<&'static str>` ની અભિવ્યક્તિમાં વિસ્તૃત થશે જેનું મૂલ્ય પર્યાવરણ ચલના મૂલ્યનું `Some` છે.
    /// જો પર્યાવરણ ચલ હાજર ન હોય, તો પછી આ વિસ્તૃત થશે `None`.
    /// આ પ્રકાર પર વધુ માહિતી માટે [`Option<T>`][Option] જુઓ.
    ///
    /// પર્યાવરણ ચલ હાજર છે કે કેમ તે ધ્યાનમાં લીધા વિના આ મેક્રોનો ઉપયોગ કરતી વખતે કમ્પાઈલ સમય ભૂલ ક્યારેય બહાર કા .તી નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ઓળખકર્તાઓને એક ઓળખકર્તામાં જોડે છે.
    ///
    /// આ મેક્રો ઘણાં અલ્પવિરામથી વિભાજિત ઓળખકર્તાઓ લે છે, અને તે બધાને એકમાં જોડે છે, એક અભિવ્યક્તિ આપે છે જે નવી ઓળખકર્તા છે.
    /// નોંધ લો કે સ્વચ્છતા તેને એવું બનાવે છે કે આ મેક્રો સ્થાનિક ચલોને પકડી શકશે નહીં.
    /// ઉપરાંત, સામાન્ય નિયમ તરીકે, મેક્રોઝને ફક્ત આઇટમ, વિધાન અથવા અભિવ્યક્તિની સ્થિતિમાં જ મંજૂરી છે.
    /// તેનો અર્થ એ કે જ્યારે તમે હાલના ચલો, કાર્યો અથવા મોડ્યુલો વગેરેનો સંદર્ભ લેવા માટે આ મેક્રોનો ઉપયોગ કરી શકો છો, તો તમે તેની સાથે નવું વ્યાખ્યાયિત કરી શકતા નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ निवासी! (નવું, આનંદ, નામ) { }//આ રીતે ઉપયોગી નથી!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// સ્થિર શબ્દમાળાની ટુકડામાં શાબ્દિક પદાર્થને જોડો.
    ///
    /// આ મેક્રો કોઈપણ સંખ્યામાં અલ્પવિરામથી વિભાજિત શાબ્દિક પદાર્થો લે છે, જે `&'static str` પ્રકારનો અભિવ્યક્તિ આપે છે જે તમામ અક્ષરને ડાબેથી જમણે જોડીને રજૂ કરે છે.
    ///
    ///
    /// પૂર્ણાંક અને ફ્લોટિંગ પોઇન્ટ લિટરલ્સને કatenન્કનેટ કરવા માટે ક્રમમાં ગોઠવવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// તે લાઈન નંબર પર વિસ્તૃત થાય છે જેના પર તે બોલાવવામાં આવ્યું હતું.
    ///
    /// [`column!`] અને [`file!`] સાથે, આ મેક્રો સ્રોતની અંદરના સ્થાન વિશે વિકાસકર્તાઓ માટે ડિબગીંગ માહિતી પ્રદાન કરે છે.
    ///
    /// વિસ્તૃત અભિવ્યક્તિમાં પ્રકાર `u32` હોય છે અને તે 1-આધારિત હોય છે, તેથી દરેક ફાઇલમાં પ્રથમ લીટી 1, બીજીથી 2, વગેરે મૂલ્યાંકન કરે છે.
    /// આ સામાન્ય કમ્પાઇલર્સ અથવા લોકપ્રિય સંપાદકો દ્વારા ભૂલ સંદેશાઓ સાથે સુસંગત છે.
    /// પરત લીટી * એ જરૂરી નથી કે તે `line!` વિનંતીની લાઇન પોતે જ હોય, પરંતુ `line!` મ maક્રોની વિનંતી સુધી દોરી જનાર પ્રથમ મેક્રો વિનંતી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ક theલમ નંબર પર વિસ્તૃત થાય છે જ્યાં તેને બોલાવવામાં આવ્યો હતો.
    ///
    /// [`line!`] અને [`file!`] સાથે, આ મેક્રો સ્રોતની અંદરના સ્થાન વિશે વિકાસકર્તાઓ માટે ડિબગીંગ માહિતી પ્રદાન કરે છે.
    ///
    /// વિસ્તૃત અભિવ્યક્તિમાં પ્રકાર `u32` હોય છે અને તે 1-આધારિત હોય છે, તેથી દરેક લાઇનમાં પ્રથમ ક columnલમ 1, બીજાથી 2, વગેરેનું મૂલ્યાંકન કરે છે.
    /// આ સામાન્ય કમ્પાઇલર્સ અથવા લોકપ્રિય સંપાદકો દ્વારા ભૂલ સંદેશાઓ સાથે સુસંગત છે.
    /// પરત થયેલ ક columnલમ * એ જરૂરી નથી કે તે `column!` વિનંતીની લાઇન પોતે જ હોય, પરંતુ `column!` મેક્રોની વિનંતી તરફ દોરી જતા પ્રથમ મેક્રો વિનંતી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ફાઇલ નામમાં વિસ્તૃત થાય છે જેમાં તે બોલાવવામાં આવ્યું હતું.
    ///
    /// [`line!`] અને [`column!`] સાથે, આ મેક્રો સ્રોતની અંદરના સ્થાન વિશે વિકાસકર્તાઓ માટે ડિબગીંગ માહિતી પ્રદાન કરે છે.
    ///
    /// વિસ્તૃત અભિવ્યક્તિમાં પ્રકાર `&'static str` હોય છે, અને પરત ફાઇલ `file!` મેક્રોની જાતે વિનંતી નથી, બલ્કે `file!` મેક્રોની વિનંતી તરફ દોરી જતા પ્રથમ મેક્રો વિનંતી છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// તેની દલીલોને મજબૂત કરે છે.
    ///
    /// આ મેક્રો પ્રકાર `&'static str` ની અભિવ્યક્તિ પેદા કરશે જે મ Zક્રોને પસાર કરેલા બધા tokens નું શબ્દમાળા છે.
    /// જાતે જ મ invક્રો મંત્રણાના વાક્યરચના પર કોઈ નિયંત્રણો મૂકવામાં આવ્યાં નથી.
    ///
    /// નોંધ લો કે tokens ઇનપુટના વિસ્તૃત પરિણામો future માં બદલાઈ શકે છે.જો તમે આઉટપુટ પર આધાર રાખતા હોવ તો તમારે સાવચેત રહેવું જોઈએ.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// એક શબ્દમાળા તરીકે UTF-8 એન્કોડ કરેલી ફાઇલ શામેલ છે.
    ///
    /// ફાઇલ વર્તમાન ફાઇલની સમાન સ્થિત છે (મોડ્યુલો કેવી રીતે મળે છે તે જ રીતે).
    /// આપેલા પાથનું સંકલન સમયે પ્લેટફોર્મ-વિશિષ્ટ રીતે અર્થઘટન કરવામાં આવે છે.
    /// તેથી, દાખલા તરીકે, બેકસ્લેશ્સ `\` ધરાવતા Windows પાથ સાથેની એક વિનંતી, Unix પર યોગ્ય રીતે કમ્પાઇલ કરશે નહીં.
    ///
    ///
    /// આ મેક્રો `&'static str` પ્રકારનું અભિવ્યક્તિ પેદા કરશે જે ફાઇલની સામગ્રી છે.
    ///
    /// # Examples
    ///
    /// માની લો કે નીચેની સામગ્રી સાથે એક જ ડિરેક્ટરીમાં બે ફાઇલો છે:
    ///
    /// ફાઇલ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ફાઇલ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ને કમ્પાઇલ કરીને અને પરિણામી દ્વિસંગી ચલાવવાથી "adiós" છાપવામાં આવશે.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// બાઇટ એરેના સંદર્ભ તરીકે ફાઇલ શામેલ છે.
    ///
    /// ફાઇલ વર્તમાન ફાઇલની સમાન સ્થિત છે (મોડ્યુલો કેવી રીતે મળે છે તે જ રીતે).
    /// આપેલા પાથનું સંકલન સમયે પ્લેટફોર્મ-વિશિષ્ટ રીતે અર્થઘટન કરવામાં આવે છે.
    /// તેથી, દાખલા તરીકે, બેકસ્લેશ્સ `\` ધરાવતા Windows પાથ સાથેની એક વિનંતી, Unix પર યોગ્ય રીતે કમ્પાઇલ કરશે નહીં.
    ///
    ///
    /// આ મેક્રો `&'static [u8; N]` પ્રકારનું અભિવ્યક્તિ પ્રાપ્ત કરશે જે ફાઇલની સામગ્રી છે.
    ///
    /// # Examples
    ///
    /// માની લો કે નીચેની સામગ્રી સાથે એક જ ડિરેક્ટરીમાં બે ફાઇલો છે:
    ///
    /// ફાઇલ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ફાઇલ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ને કમ્પાઇલ કરીને અને પરિણામી દ્વિસંગી ચલાવવાથી "adiós" છાપવામાં આવશે.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// શબ્દમાળા સુધી વિસ્તૃત થાય છે જે વર્તમાન મોડ્યુલ પાથનું પ્રતિનિધિત્વ કરે છે.
    ///
    /// વર્તમાન મોડ્યુલ પાથ crate root તરફ પાછા ફરતા મોડ્યુલોના વંશવેલો તરીકે વિચારી શકાય છે.
    /// પરત થયેલ પાથનો પ્રથમ ઘટક એ હાલમાં સંગ્રહિત થયેલ ઝેડક્રેટ 0 ઝેડનું નામ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// કમ્પાઇલ સમયે રૂપરેખાંકન ફ્લેગોના બુલિયન સંયોજનોનું મૂલ્યાંકન કરે છે.
    ///
    /// `#[cfg]` એટ્રીબ્યુટી ઉપરાંત, આ મેક્રો ગોઠવણી ફ્લેગોના બુલિયન અભિવ્યક્તિ મૂલ્યાંકનને મંજૂરી આપવા માટે પ્રદાન કરવામાં આવે છે.
    /// આ વારંવાર ઓછા ડુપ્લિકેટ કોડ તરફ દોરી જાય છે.
    ///
    /// આ મેક્રોને આપેલ વાક્યરચના એ [`cfg`] લક્ષણ જેટલું જ વાક્યરચના છે.
    ///
    /// `cfg!`, `#[cfg]` થી વિપરીત, કોઈપણ કોડને દૂર કરતું નથી અને ફક્ત સાચા કે ખોટાનું મૂલ્યાંકન કરે છે.
    /// ઉદાહરણ તરીકે,if/else એક્સ મૂલ્યાંકન કરે છે તે ધ્યાનમાં લીધા વિના, `cfg!` શરત માટે વપરાય છે ત્યારે if/else અભિવ્યક્તિના બધા બ્લોક્સને માન્ય હોવું જરૂરી છે.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// સંદર્ભ અનુસાર ફાઇલને અભિવ્યક્તિ અથવા આઇટમ તરીકે વિશ્લેષણ કરે છે.
    ///
    /// ફાઇલ વર્તમાન ફાઇલની સમાન સ્થિત છે (મોડ્યુલો કેવી રીતે મળે છે તે જ રીતે).આપેલા પાથનું સંકલન સમયે પ્લેટફોર્મ-વિશિષ્ટ રીતે અર્થઘટન કરવામાં આવે છે.
    /// તેથી, દાખલા તરીકે, બેકસ્લેશ્સ `\` ધરાવતા Windows પાથ સાથેની એક વિનંતી, Unix પર યોગ્ય રીતે કમ્પાઇલ કરશે નહીં.
    ///
    /// આ મેક્રોનો ઉપયોગ કરવો હંમેશાં ખરાબ વિચાર છે, કારણ કે જો ફાઇલને અભિવ્યક્તિ તરીકે વિશ્લેષિત કરવામાં આવી છે, તો તે આસપાસના કોડમાં બિનઆરોગ્યપ્રદ રીતે મૂકવામાં આવશે.
    /// આના પરિણામ સ્વરૂપ ચલ અથવા કાર્યો જે ફાઇલમાં અપેક્ષા કરતા અલગ હોઇ શકે છે જો વર્તમાન ફાઇલમાં સમાન નામ ધરાવતા ચલો અથવા કાર્યો હોય તો.
    ///
    ///
    /// # Examples
    ///
    /// માની લો કે નીચેની સામગ્રી સાથે એક જ ડિરેક્ટરીમાં બે ફાઇલો છે:
    ///
    /// ફાઇલ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ફાઇલ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ને કમ્પાઇલ કરીને અને પરિણામી દ્વિસંગી ચલાવવાથી "🙈🙊🙉🙈🙊🙉" છાપવામાં આવશે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ભારપૂર્વક જણાવે છે કે રનટાઇમ પર બુલિયન અભિવ્યક્તિ `true` છે.
    ///
    /// જો XTX એક્સ મેક્રોનો પ્રારંભ કરશે જો પૂરા પાડવામાં આવેલા અભિવ્યક્તિનું મૂલ્યાંકન રનટાઈમ સમયે `true` પર ન કરી શકાય.
    ///
    /// # Uses
    ///
    /// દાવા હંમેશાં બંને ડીબગ અને પ્રકાશન બિલ્ડ્સમાં તપાસવામાં આવે છે, અને અક્ષમ કરી શકાતા નથી.
    /// મૂળભૂત રીતે પ્રકાશન બિલ્ડ્સમાં સક્ષમ નથી તેવા નિવેદનો માટે [`debug_assert!`] જુઓ.
    ///
    /// અસુરક્ષિત કોડ રન-ટાઇમ આક્રમણકારોને લાગુ કરવા માટે `assert!` પર આધાર રાખે છે કે, જો ઉલ્લંઘન કરવામાં આવ્યું તો તે અસુરક્ષિત થઈ શકે છે.
    ///
    /// `assert!` ના અન્ય ઉપયોગ-કેસોમાં સલામત કોડમાં રન-ટાઇમ આક્રમણકારોનું પરીક્ષણ અને અમલ કરવો શામેલ છે (જેનું ઉલ્લંઘન અસફળ પરિણમી શકતું નથી).
    ///
    ///
    /// # કસ્ટમ સંદેશા
    ///
    /// આ મેક્રોનું બીજું સ્વરૂપ છે, જ્યાં ફોર્મેટિંગ માટે દલીલો સાથે અથવા વગર કસ્ટમ panic સંદેશ પ્રદાન કરી શકાય છે.
    /// આ ફોર્મ માટે સિંટેક્સ માટે [`std::fmt`] જુઓ.
    /// ફોર્મેટ દલીલો તરીકે ઉપયોગમાં લેવાતા અભિવ્યક્તિઓનું મૂલ્યાંકન ફક્ત ત્યારે જ કરવામાં આવશે જો નિવેશ નિષ્ફળ જાય.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // આ નિવેદનો માટે panic સંદેશ એ આપેલ અભિવ્યક્તિનું સ્ટ્રિનાઇઝ્ડ મૂલ્ય છે.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ખૂબ જ સરળ કાર્ય
    ///
    /// assert!(some_computation());
    ///
    /// // વૈવિધ્યપૂર્ણ સંદેશ સાથે ભાર મૂકો
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ઇનલાઇન એસેમ્બલી.
    ///
    /// વપરાશ માટે [unstable book] વાંચો.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// એલએલવીએમ-શૈલીની ઇનલાઇન એસેમ્બલી.
    ///
    /// વપરાશ માટે [unstable book] વાંચો.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// મોડ્યુલ-સ્તરની ઇનલાઇન વિધાનસભા.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// પ્રિન્ટ્સ tokens ને પ્રમાણભૂત આઉટપુટમાં પસાર કરે છે.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// અન્ય મેક્રોને ડિબગ કરવા માટે વપરાયેલી ટ્રેસીંગ વિધેયને સક્ષમ અથવા અક્ષમ કરે છે.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// એટ્રિબ્યુટ મેક્રો, ડેરિવેટ મેક્રો લાગુ કરવા માટે વપરાય છે.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ફંક્શનને એકમ પરીક્ષણમાં ફેરવવા માટે એટ્રિબ્યુટ મેક્રો લાગુ પડે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ફંક્શનને બેંચમાર્ક પરીક્ષણમાં ફેરવવા માટે એટ્રિબ્યુટ મેક્રો લાગુ પડે છે.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` અને `#[bench]` મેક્રોઝના અમલીકરણની વિગત.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// વૈશ્વિક ફાળવણીકાર તરીકે નોંધણી કરવા માટે સ્થિર પર એટ્રિબ્યુટ મેક્રો લાગુ પડે છે.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) પણ જુઓ.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// જો પસાર કરેલો રસ્તો accessક્સેસિબલ હોય તો જે વસ્તુ લાગુ પડે છે તે રાખે છે, અને અન્યથા તેને દૂર કરે છે.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// તે લાગુ પડેલા કોડ ટુકડામાંના બધા `#[cfg]` અને `#[cfg_attr]` લક્ષણો વિસ્તૃત કરે છે.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` કમ્પાઈલરની અસ્થિર અમલીકરણ વિગત, ઉપયોગ કરશો નહીં.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` કમ્પાઈલરની અસ્થિર અમલીકરણ વિગત, ઉપયોગ કરશો નહીં.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}