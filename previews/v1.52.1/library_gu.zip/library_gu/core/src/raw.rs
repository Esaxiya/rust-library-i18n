#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! બિલ્ટ-ઇન પ્રકારનાં કમ્પાઇલરનાં લેઆઉટ માટે સ્ટ્રક્ટ વ્યાખ્યાઓ શામેલ છે.
//!
//! કાચા રજૂઆતોને સીધી રીતે ચાલાકી કરવા માટે અસુરક્ષિત કોડમાં ટ્રાન્સમ્યુટ્સના લક્ષ્યાંક તરીકે તેનો ઉપયોગ કરી શકાય છે.
//!
//!
//! તેમની વ્યાખ્યા હંમેશાં `rustc_middle::ty::layout` માં વ્યાખ્યાયિત ABI સાથે મેળ ખાવી જોઈએ.
//!

/// `&dyn SomeTrait` જેવા trait ofબ્જેક્ટનું પ્રતિનિધિત્વ.
///
/// આ સ્ટ્રક્ટમાં `&dyn SomeTrait` અને `Box<dyn AnotherTrait>` જેવા પ્રકારોનું લેઆઉટ સમાન છે.
///
/// `TraitObject` લેઆઉટને મેચ કરવાની બાંયધરી આપવામાં આવે છે, પરંતુ તે ઝેડટ્રેટ 0 ઝેડ objectsબ્જેક્ટ્સનો પ્રકાર નથી (દા.ત., ક્ષેત્રો સીધા `&dyn SomeTrait` પર સુલભ નથી) અથવા તે લેઆઉટને નિયંત્રિત કરે છે (વ્યાખ્યા બદલીને `&dyn SomeTrait` ના લેઆઉટને બદલશે નહીં).
///
/// તે ફક્ત અસુરક્ષિત કોડ દ્વારા ઉપયોગમાં લેવા માટે બનાવવામાં આવ્યું છે જેને નીચા-સ્તરની વિગતોની ચાલાકી કરવાની જરૂર છે.
///
/// બધા ઝેડટ્રેટ 0 ઝેડ objectsબ્જેક્ટ્સનો સામાન્ય રીતે સંદર્ભ લેવાનો કોઈ રસ્તો નથી, તેથી આ પ્રકારનાં મૂલ્યો બનાવવાનો એકમાત્ર રસ્તો [`std::mem::transmute`][transmute] જેવા કાર્યો સાથે છે.
/// એ જ રીતે, `TraitObject` મૂલ્યમાંથી સાચી ઝેડટ્રેટ 0 ઝેડ objectબ્જેક્ટ બનાવવાનો એકમાત્ર રસ્તો `transmute` છે.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait objectબ્જેક્ટને મેળ ન ખાતા પ્રકારો સાથે સંશ્લેષણ કરવું-એક જ્યાં vtable મૂલ્યના પ્રકારને અનુરૂપ નથી, જેમાં ડેટા નિર્દેશક નિર્દેશ કરે છે-અસ્પષ્ટ વર્તન તરફ દોરી જાય તેવી સંભાવના છે.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // trait ઉદાહરણ
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // કમ્પાઇલરને trait objectબ્જેક્ટ બનાવવા દો
/// let object: &dyn Foo = &value;
///
/// // કાચી રજૂઆત જુઓ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ડેટા પોઇન્ટર એ `value` નું સરનામું છે
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` માંથી `i32` vtable નો ઉપયોગ કરવા માટે સાવચેતી રાખીને, એક અલગ 0બ્જેક્ટ બનાવો
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // તે એ રીતે કાર્ય કરવું જોઈએ કે જેમ કે અમે સીધા `other_value` માંથી trait constructedબ્જેક્ટ બનાવ્યું છે
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}