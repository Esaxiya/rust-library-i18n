use crate::{iter::FusedIterator, ops::Try};

/// એક પુનરાવર્તક કે જે અનંતપણે પુનરાવર્તન કરે છે.
///
/// આ `struct`, [`Iterator`] પર [`cycle`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // ચક્ર પુનરાવર્તક કાં તો ખાલી અથવા અનંત છે
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // વર્તમાન પુનરાવર્તકને સંપૂર્ણ રીતે પુનરાવર્તિત કરો.
        // આ આવશ્યક છે કારણ કે `self.iter` એક્સ ન હોવા છતાં પણ `self.iter` ખાલી હોઈ શકે છે
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // સાયકલવાળા ઇરેટર ખાલી છે કે કેમ તેનો ટ્ર trackક રાખીને સંપૂર્ણ ચક્ર પૂર્ણ કરો.
        // અનંત લૂપને રોકવા માટે અમને ખાલી પુનરાવર્તકના કિસ્સામાં વહેલા પાછા આવવાની જરૂર છે
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // કોઈ `fold` ઓવરરાઇડ નહીં, કારણ કે `fold` `Cycle` માટે વધુ અર્થમાં નથી, અને અમે ડિફોલ્ટ કરતા વધુ કંઇ સારી રીતે કરી શકતા નથી.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}