use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Successબ્જેક્ટ્સ કે જેમાં *અનુગામી* અને *પુરોગામી* કામગીરીની કલ્પના છે.
///
/// *અનુગામી* ઓપરેશન મૂલ્યો તરફ આગળ વધે છે જે વધુની તુલના કરે છે.
/// *પુરોગામી* ઓપરેશન એવા મૂલ્યો તરફ આગળ વધે છે જે ઓછાની તુલના કરે છે.
///
/// # Safety
///
/// આ trait એ `unsafe` છે કારણ કે `unsafe trait TrustedLen` અમલીકરણની સલામતી માટે તેનું અમલીકરણ યોગ્ય હોવું આવશ્યક છે, અને આ ઝેડટ્રેટ 0 ઝેડનો ઉપયોગ કરવાના પરિણામો અન્યથા `unsafe` કોડ દ્વારા વિશ્વાસ કરી શકાય છે અને યોગ્ય સૂચિબદ્ધ જવાબદારીઓને પૂર્ણ કરે છે.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` થી `end` પર જવા માટે *અનુગામી* પગલાઓની સંખ્યા પરત કરે છે.
    ///
    /// `None` પરત કરે છે જો પગલાઓની સંખ્યા `usize` ઓવરફ્લો થાય (અથવા અનંત છે, અથવા જો `end` ક્યારેય પહોંચી શકાતી નથી).
    ///
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a`, `b` અને `n` માટે:
    ///
    /// * `steps_between(&a, &b) == Some(n)` જો અને માત્ર જો `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` જો અને માત્ર જો `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` ફક્ત જો `a <= b`
    ///   * વિરોધી: `steps_between(&a, &b) == Some(0)` જો અને માત્ર જો `a == b`
    ///   * નોંધ લો કે `a <= b` એ _not_ સૂચવે છે `steps_between(&a, &b) != None`;
    ///     આ તે સ્થિતિ છે જ્યારે તેને `b` પર જવા માટે `usize::MAX` પગલાઓની વધુ જરૂર હોય
    /// * `steps_between(&a, &b) == None` જો `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` વખતનો *અનુગામી* લઈને મેળવી શકાય તે મૂલ્ય પરત કરે છે.
    ///
    /// જો આ `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરશે, તો `None` આપે છે.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a`, `n` અને `m` માટે:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// કોઈપણ `a`, `n` અને `m` માટે જ્યાં `n + m` ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// કોઈપણ `a` અને `n` માટે:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` વખતનો *અનુગામી* લઈને મેળવી શકાય તે મૂલ્ય પરત કરે છે.
    ///
    /// જો આ `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરશે, તો આ ફંક્શનને panic, લપેટી અથવા સંતૃપ્ત કરવાની મંજૂરી છે.
    ///
    /// જ્યારે ડિબગ નિવેશ સક્ષમ કરવામાં આવે ત્યારે સૂચિબદ્ધ વર્તન ઝેડપpanનપિસેઝ ઝેડ માટે છે, અને અન્યથા લપેટી અથવા સંતૃપ્ત કરવું.
    ///
    /// અસુરક્ષિત કોડ ઓવરફ્લો પછી વર્તનની સાચીતા પર આધાર રાખવો જોઈએ નહીં.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a`, `n` અને `m` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// કોઈપણ `a` અને `n` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` વખતનો *અનુગામી* લઈને મેળવી શકાય તે મૂલ્ય પરત કરે છે.
    ///
    /// # Safety
    ///
    /// `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરવા માટે આ ક્રિયા માટે અસ્પષ્ટ વર્તન છે.
    /// જો તમે ખાતરી આપી શકતા નથી કે આ ઓવરફ્લો થશે નહીં, તો તેના બદલે `forward` અથવા `forward_checked` નો ઉપયોગ કરો.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a` માટે:
    ///
    /// * જો ત્યાં `b` જેમ કે `b > a` હોય, તો તે `Step::forward_unchecked(a, 1)` ને ક callલ કરવા માટે સલામત છે
    /// * જો ત્યાં `b`, `n` જેમ કે `steps_between(&a, &b) == Some(n)` અસ્તિત્વમાં છે, તો કોઈપણ `m <= n` માટે `Step::forward_unchecked(a, m)` પર ક .લ કરવો સલામત છે.
    ///
    ///
    /// કોઈપણ `a` અને `n` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` ની બરાબર છે
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` વખત * * પુરોગામી * લઈને મેળવી લેવાનું મૂલ્ય આપે છે.
    ///
    /// જો આ `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરશે, તો `None` આપે છે.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a`, `n` અને `m` માટે:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// કોઈપણ `a` અને `n` માટે:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` વખત * * પુરોગામી * લઈને મેળવી લેવાનું મૂલ્ય આપે છે.
    ///
    /// જો આ `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરશે, તો આ ફંક્શનને panic, લપેટી અથવા સંતૃપ્ત કરવાની મંજૂરી છે.
    ///
    /// જ્યારે ડિબગ નિવેશ સક્ષમ કરવામાં આવે ત્યારે સૂચિબદ્ધ વર્તન ઝેડપpanનપિસેઝ ઝેડ માટે છે, અને અન્યથા લપેટી અથવા સંતૃપ્ત કરવું.
    ///
    /// અસુરક્ષિત કોડ ઓવરફ્લો પછી વર્તનની સાચીતા પર આધાર રાખવો જોઈએ નહીં.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a`, `n` અને `m` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// કોઈપણ `a` અને `n` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` વખત * * પુરોગામી * લઈને મેળવી લેવાનું મૂલ્ય આપે છે.
    ///
    /// # Safety
    ///
    /// `Self` દ્વારા સપોર્ટેડ મૂલ્યોની શ્રેણીને ઓવરફ્લો કરવા માટે આ ક્રિયા માટે અસ્પષ્ટ વર્તન છે.
    /// જો તમે ખાતરી આપી શકતા નથી કે આ ઓવરફ્લો થશે નહીં, તો તેના બદલે `backward` અથવા `backward_checked` નો ઉપયોગ કરો.
    ///
    /// # Invariants
    ///
    /// કોઈપણ `a` માટે:
    ///
    /// * જો ત્યાં `b` જેમ કે `b < a` હોય, તો તે `Step::backward_unchecked(a, 1)` ને ક callલ કરવા માટે સલામત છે
    /// * જો ત્યાં `b`, `n` જેમ કે `steps_between(&b, &a) == Some(n)` અસ્તિત્વમાં છે, તો કોઈપણ `m <= n` માટે `Step::backward_unchecked(a, m)` પર ક .લ કરવો સલામત છે.
    ///
    ///
    /// કોઈપણ `a` અને `n` માટે, જ્યાં કોઈ ઓવરફ્લો થતો નથી:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` ની બરાબર છે
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// આ હજી પણ મેક્રો-જનરેટેડ છે કારણ કે પૂર્ણાંક શાબ્દિક જુદા જુદા પ્રકારોમાં ઉકેલે છે.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // સલામતી: ક calલરને ખાતરી આપી છે કે `start + n` ઓવરફ્લો થતો નથી.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // સલામતી: ક calલરને ખાતરી આપી છે કે `start - n` ઓવરફ્લો થતો નથી.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ડિબગ બિલ્ડ્સમાં, ઓવરફ્લો પર panic ટ્રિગર કરો.
            // આને રિલીઝ બિલ્ડ્સમાં સંપૂર્ણપણે optimપ્ટિમાઇઝ કરવું જોઈએ.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // દા.ત.ને મંજૂરી આપવા માટે રેપિંગ ગણિત કરો `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ડિબગ બિલ્ડ્સમાં, ઓવરફ્લો પર panic ટ્રિગર કરો.
            // આને રિલીઝ બિલ્ડ્સમાં સંપૂર્ણપણે optimપ્ટિમાઇઝ કરવું જોઈએ.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // દા.ત.ને મંજૂરી આપવા માટે રેપિંગ ગણિત કરો `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // આ $u_narrower <=usize પર નિર્ભર છે
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // જો n રેંજની બહાર છે, તો `unsigned_start + n` પણ છે
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // જો n રેંજની બહાર છે, તો `unsigned_start - n` પણ છે
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // આ $i_narrower <=usize પર નિર્ભર છે
                        //
                        // આઇસાઇઝ કાસ્ટ કરવાથી પહોળાઈ લંબાય છે પરંતુ નિશાની સાચવે છે.
                        // ઇસાઇડની જગ્યામાં રેપિંગ_સબનો ઉપયોગ કરો અને ઇઝાઇઝની રેન્જની અંદર ફિટ ન થઈ શકે તેવા તફાવતની ગણતરી માટે યુઝ કરવા કાસ્ટ કરો.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // રેપિંગ `Step::forward(-120_i8, 200) == Some(80_i8)` જેવા કિસ્સાઓને સંભાળે છે, તેમ છતાં 200 i8 ની મર્યાદાથી બહાર છે.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // ઉમેરો ઓવરફ્લો થયો
                            }
                        }
                        // જો n દા.ત.ની શ્રેણીની બહાર હોય તો
                        // u8, પછી તે i8 માટેની સંપૂર્ણ શ્રેણી કરતાં વિશાળ છે તેથી `any_i8 + n` આવશ્યકપણે i8 ઓવરફ્લો કરે છે.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // રેપિંગ `Step::forward(-120_i8, 200) == Some(80_i8)` જેવા કિસ્સાઓને સંભાળે છે, તેમ છતાં 200 i8 ની મર્યાદાથી બહાર છે.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // બાદબાકી ઓવરફ્લો થઈ ગઈ
                            }
                        }
                        // જો n દા.ત.ની શ્રેણીની બહાર હોય તો
                        // u8, પછી તે i8 માટેની સંપૂર્ણ શ્રેણી કરતાં વિશાળ છે તેથી `any_i8 - n` આવશ્યકપણે i8 ઓવરફ્લો કરે છે.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // જો તફાવત દા.ત. માટે ખૂબ મોટો હોય
                            // i128, ઓછા બિટ્સ સાથે યુઝ કરવા માટે તે ખૂબ મોટું હશે.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // સલામતી: રેઝ એ માન્ય યુનિકોડ સ્કેલર છે
            // (0x110000 ની નીચે અને 0xD800..0xE000 માં નથી)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // સલામતી: રેઝ એ માન્ય યુનિકોડ સ્કેલર છે
        // (0x110000 ની નીચે અને 0xD800..0xE000 માં નથી)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // સલામતી: કlerલરને ખાતરી આપવી આવશ્યક છે કે આ ઓવરફ્લો થતો નથી
        // ચાર્ માટે મૂલ્યોની શ્રેણી.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // સલામતી: કlerલરને ખાતરી આપવી આવશ્યક છે કે આ ઓવરફ્લો થતો નથી
            // ચાર્ માટે મૂલ્યોની શ્રેણી.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // સલામતી: અગાઉના કરારને કારણે, આ બાંયધરી આપવામાં આવી છે
        // કlerલર દ્વારા માન્ય ચેર બનવા માટે.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // સલામતી: કlerલરને ખાતરી આપવી આવશ્યક છે કે આ ઓવરફ્લો થતો નથી
        // ચાર્ માટે મૂલ્યોની શ્રેણી.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // સલામતી: કlerલરને ખાતરી આપવી આવશ્યક છે કે આ ઓવરફ્લો થતો નથી
            // ચાર્ માટે મૂલ્યોની શ્રેણી.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // સલામતી: અગાઉના કરારને કારણે, આ બાંયધરી આપવામાં આવી છે
        // કlerલર દ્વારા માન્ય ચેર બનવા માટે.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// આ મેક્રોઝ વિવિધ શ્રેણીના પ્રકારો માટે `ExactSizeIterator` ઇમ્પલ્સ ઉત્પન્ન કરે છે.
//
// * `ExactSizeIterator::len` હંમેશાં સચોટ `usize` પરત ફરવું જરૂરી છે, તેથી કોઈ પણ શ્રેણી `usize::MAX` કરતા લાંબી હોઇ શકે નહીં.
//
// * `Range<_>` માં પૂર્ણાંકોના પ્રકારો માટે, `usize` કરતા વધુ ટૂંકા અથવા વિશાળ પ્રકારનાં આ કેસ છે.
//   `RangeInclusive<_>` માં પૂર્ણાંકોના પ્રકારો માટે, ઉદાહરણ તરીકે `usize` કરતા *સખત રીતે ટૂંકાવી શકાય તેવા* પ્રકારો માટે આ કેસ છે
//   `(0..=u64::MAX).len()` `u64::MAX + 1` હશે.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // આ ઉપરના તર્ક મુજબ અસંગત છે, પરંતુ તેમને દૂર કરવાથી તોડવામાં પરિવર્તન થશે કારણ કે તેઓ ઝેડ રસ્ટ0 ઝેડ X00 એક્સમાં સ્થિર થયા હતા.
    // તેથી દા.ત.
    // `(0..66_000_u32).len()` ઉદાહરણ તરીકે, 16-બીટ પ્લેટફોર્મ્સ પર ભૂલ અથવા ચેતવણી વિના કમ્પાઇલ કરશે, પરંતુ ખોટું પરિણામ આપવાનું ચાલુ રાખશે.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // આ ઉપરના તર્ક મુજબ અસંગત છે, પરંતુ તેમને દૂર કરવાથી તોડવામાં પરિવર્તન થશે કારણ કે તેઓ ઝેડ રસ્ટ0 ઝેડ X00 એક્સમાં સ્થિર થયા હતા.
    // તેથી દા.ત.
    // `(0..=u16::MAX).len()` ઉદાહરણ તરીકે, 16-બીટ પ્લેટફોર્મ્સ પર ભૂલ અથવા ચેતવણી વિના કમ્પાઇલ કરશે, પરંતુ ખોટું પરિણામ આપવાનું ચાલુ રાખશે.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // સલામતી: હમણાં જ પૂર્વસત્તા ચકાસી લીધી
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}