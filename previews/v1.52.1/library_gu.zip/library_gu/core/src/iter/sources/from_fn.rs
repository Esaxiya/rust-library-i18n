use crate::fmt;

/// એક નવું પુનરાવર્તક બનાવે છે જ્યાં દરેક પુનરાવર્તિત પ્રદાન કરેલ ક્લોઝરને `F: FnMut() -> Option<T>` કહે છે.
///
/// આ સમર્પિત પ્રકાર બનાવવા અને તેના માટે [`Iterator`] trait અમલીકરણના વધુ વર્બોઝ સિન્ટેક્સનો ઉપયોગ કર્યા વિના કોઈપણ વર્તન સાથે કસ્ટમ ઇટરેટર બનાવવા માટે પરવાનગી આપે છે.
///
/// નોંધ લો કે `FromFn` પુનરાવર્તક બંધની વર્તણૂક વિશે કલ્પનાઓ કરતું નથી, અને તેથી રૂ conિચુસ્તપણે [`FusedIterator`] લાગુ કરતું નથી, અથવા તેના મૂળભૂત `(0, None)` થી [`Iterator::size_hint()`] ને ઓવરરાઇડ કરતું નથી.
///
///
/// આ બંધારણ એ પુનરાવર્તનોની સ્થિતિને ટ્રેક કરવા માટે કેપ્ચર્સ અને તેના પર્યાવરણનો ઉપયોગ કરી શકે છે.ઇરેટરનો ઉપયોગ કેવી રીતે થાય છે તેના આધારે, આને બંધ થવા પર [`move`] કીવર્ડ સ્પષ્ટ કરવાની જરૂર પડી શકે છે.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// ચાલો [module-level documentation] માંથી કાઉન્ટર ઇરેટરને ફરીથી અમલમાં મૂકીએ:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // અમારી ગણતરીમાં વધારો.આથી જ આપણે શૂન્યથી શરૂઆત કરી.
///     count += 1;
///
///     // અમે ગણતરી પૂર્ણ કરી છે કે નહીં તે જોવા માટે તપાસો.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// એક પુનરાવર્તક જ્યાં દરેક પુનરાવર્તિત પૂરા પાડવામાં આવેલ ક્લોઝરને `F: FnMut() -> Option<T>` કહે છે.
///
/// આ `struct` એ [`iter::from_fn()`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}