use crate::iter::{FusedIterator, TrustedLen};

/// એક નવું પુનરાવર્તક બનાવે છે જે પૂરા પાડવામાં આવેલ ક્લોઝર, રીપીટરને લાગુ કરીને અવિરત `A` ના તત્વોનું પુનરાવર્તન કરે છે, `F: FnMut() -> A`.
///
/// `repeat_with()` ફંક્શન ફરીથી અને ફરીથી પુનરાવર્તકને ક callsલ કરે છે.
///
/// મર્યાદિત બનાવવા માટે, `repeat_with()` જેવા અનંત પુનરાવર્તનોનો ઉપયોગ ઘણીવાર [`Iterator::take()`] જેવા એડેપ્ટરો સાથે થાય છે.
///
/// જો ઇરેટરનો તત્વ પ્રકાર તમને [`Clone`] લાગુ કરવાની જરૂર છે, અને સ્ત્રોત તત્વને મેમરીમાં રાખવું તે બરાબર છે, તમારે તેના બદલે [`repeat()`] ફંક્શનનો ઉપયોગ કરવો જોઈએ.
///
///
/// `repeat_with()` દ્વારા ઉત્પાદિત ઇટરેટર એ [`DoubleEndedIterator`] નથી.
/// જો તમારે [`DoubleEndedIterator`] પરત આપવા માટે `repeat_with()` ની જરૂર હોય, તો કૃપા કરીને તમારા ઉપયોગના કેસનો ખુલાસો કરતા ગિટહબ ઇશ્યૂ ખોલો.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::iter;
///
/// // ચાલો ધારીએ કે આપણી પાસે એવા પ્રકારનું મૂલ્ય છે જે `Clone` નથી અથવા જે મોંઘા હોવાને લીધે હજી મેમરીમાં નથી માંગતું:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ચોક્કસ મૂલ્ય કાયમ:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// પરિવર્તનનો ઉપયોગ કરીને અને મર્યાદિત રીતે જવું:
///
/// ```rust
/// use std::iter;
///
/// // ઝીરોથથી લઈને બેની ત્રીજી શક્તિ સુધી:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... અને હવે અમે પૂર્ણ કરી લીધું છે
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// એક પુનરાવર્તક જે પૂરા પાડવામાં આવેલ ક્લોઝર `F: FnMut() -> A` લાગુ કરીને અવિરતપણે `A` પ્રકારનાં તત્વોનું પુનરાવર્તન કરે છે.
///
///
/// આ `struct` એ [`repeat_with()`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}