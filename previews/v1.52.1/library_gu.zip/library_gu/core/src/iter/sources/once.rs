use crate::iter::{FusedIterator, TrustedLen};

/// એક ઇરેટર બનાવે છે જે બરાબર એકવાર તત્વ આપે છે.
///
/// આ સામાન્ય રીતે એકલ મૂલ્યને અન્ય પ્રકારની પુનરાવૃત્તિના [`chain()`] માં અનુરૂપ બનાવવા માટે વપરાય છે.
/// કદાચ તમારી પાસે એક ઇરેટર હશે જે લગભગ દરેક વસ્તુને આવરી લે છે, પરંતુ તમારે વધારાના વિશેષ કેસની જરૂર છે.
/// કદાચ તમારી પાસે ફંક્શન છે જે પુનરાવર્તકો પર કાર્ય કરે છે, પરંતુ તમારે ફક્ત એક મૂલ્ય પર પ્રક્રિયા કરવાની જરૂર છે.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::iter;
///
/// // એક એકલવાયા નંબર છે
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // માત્ર એક જ, આપણે જે મેળવીએ છીએ
/// assert_eq!(None, one.next());
/// ```
///
/// બીજા ઇરેટર સાથે મળીને ચેઇનિંગ.
/// ચાલો આપણે કહીએ કે આપણે `.foo` ડિરેક્ટરીની દરેક ફાઇલ પર પુનરાવર્તિત કરવા માંગીએ છીએ, પણ એક ગોઠવણી ફાઇલ પણ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // આપણને ડીરીએન્ટ્રી-એસના ઇરેટરથી પાથબફ્સના ઇરેટરમાં રૂપાંતરિત કરવાની જરૂર છે, તેથી આપણે નકશાનો ઉપયોગ કરીએ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // હવે, ફક્ત આપણી રૂપરેખા ફાઇલ માટે આપણું ઇરેટર
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // બે ઇટરેટર્સને એક સાથે મોટા ઇરેટરમાં સાંકળો
/// let files = dirs.chain(config);
///
/// // આ આપણને .foo ની બધી ફાઇલો તેમજ .foorc આપશે
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// એક પુનરાવર્તક કે જે તત્વને બરાબર એકવાર પ્રાપ્ત કરે છે.
///
/// આ `struct` એ [`once()`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}