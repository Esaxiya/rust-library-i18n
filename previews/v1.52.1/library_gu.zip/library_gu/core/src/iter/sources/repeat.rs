use crate::iter::{FusedIterator, TrustedLen};

/// એક નવું પુનરાવર્તક બનાવે છે જે અનંતપણે એક તત્વનું પુનરાવર્તન કરે છે.
///
/// `repeat()` ફંક્શન એક પછી એક મૂલ્યનું પુનરાવર્તન કરે છે.
///
/// મર્યાદિત બનાવવા માટે, `repeat()` જેવા અનંત પુનરાવર્તનોનો ઉપયોગ ઘણીવાર [`Iterator::take()`] જેવા એડેપ્ટરો સાથે થાય છે.
///
/// જો તમને આવશ્યક ઇરેટરનો તત્વ પ્રકાર `Clone` લાગુ કરતું નથી, અથવા જો તમે પુનરાવર્તિત તત્વને મેમરીમાં રાખવા માંગતા નથી, તો તમે તેના બદલે [`repeat_with()`] ફંક્શનનો ઉપયોગ કરી શકો છો.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::iter;
///
/// // નંબર ચાર 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // હા, હજી ચાર
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] સાથે મર્યાદિત જવું:
///
/// ```
/// use std::iter;
///
/// // તે છેલ્લા ઉદાહરણમાં ઘણા ચોગ્ગા હતા.ચાલો ફક્ત ચાર ચોગ્ગા કરીએ.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... અને હવે અમે પૂર્ણ કરી લીધું છે
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// એક પુનરાવર્તક કે જે તત્વને અનંતપણે પુનરાવર્તિત કરે છે.
///
/// આ `struct` એ [`repeat()`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}