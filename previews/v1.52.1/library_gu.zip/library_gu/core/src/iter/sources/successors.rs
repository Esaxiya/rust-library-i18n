use crate::{fmt, iter::FusedIterator};

/// એક નવું પુનરાવર્તક બનાવે છે જ્યાં દરેક ક્રમિક આઇટમ અગાઉના એકના આધારે ગણવામાં આવે છે.
///
/// પુનરાવર્તક આપેલ પ્રથમ આઇટમ (જો કોઈ હોય તો) થી શરૂ થાય છે અને દરેક આઇટમના અનુગામીની ગણતરી માટે આપેલ `FnMut(&T) -> Option<T>` બંધને ક callsલ કરે છે.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // જો આ ફંક્શન `impl Iterator<Item=T>` પરત આવ્યું છે, તો તે `unfold` પર આધારિત હોઈ શકે છે અને સમર્પિત પ્રકારની જરૂર નથી.
    //
    // જો કે નામવાળી `Successors<T, F>` પ્રકાર હોવાને કારણે જ્યારે `T` અને `F` હોય ત્યારે તે `Clone` થવા દે છે.
    Successors { next: first, succ }
}

/// એક નવું પુનરાવર્તક જ્યાં દરેક ક્રમિક આઇટમ અગાઉના એકના આધારે ગણવામાં આવે છે.
///
/// આ `struct` એ [`iter::successors()`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}