//! કમ્પોઝેબલ બાહ્ય પુનરાવૃત્તિ.
//!
//! જો તમને કોઈ જાતનો સંગ્રહ મળ્યો હોય, અને કહ્યું સંગ્રહના તત્વો પર performપરેશન કરવાની જરૂર હોય, તો તમે ઝડપથી 'iterators' માં દોડશો.
//! આઇડેટમેટર્સ ઝેડ રસ્ટ 0 ઝેડ કોડમાં ઇટરેટર્સનો ભારે ઉપયોગ થાય છે, તેથી તે તેમનાથી પરિચિત થવું યોગ્ય છે.
//!
//! વધુ સમજાવતા પહેલા, ચાલો આ મોડ્યુલની રચના કેવી રીતે થાય છે તે વિશે વાત કરીએ:
//!
//! # Organization
//!
//! આ મોડ્યુલ મોટા ભાગે પ્રકાર દ્વારા ગોઠવાયેલ છે:
//!
//! * [Traits] મુખ્ય ભાગ છે: આ ઝેડટ્રેટ 0 ઝેડ નિર્ધારિત કરે છે કે કયા પ્રકારનાં ઇટરેટર્સ અસ્તિત્વમાં છે અને તમે તેમની સાથે શું કરી શકો છો.આ ઝેડ 0 ટ્રાઇટ્સ 0 ઝેડની પદ્ધતિઓ કેટલાક વધારાના અભ્યાસ સમયને મૂકવા યોગ્ય છે.
//! * [Functions] કેટલાક મૂળભૂત ઇટરેટર્સ બનાવવા માટે કેટલીક સહાયક રીતો પ્રદાન કરો.
//! * [Structs] આ મોડ્યુલના traits પર ઘણીવાર વિવિધ પદ્ધતિઓના રીટર્ન પ્રકારો હોય છે.તમે સામાન્ય રીતે `struct` ને બદલે `struct` બનાવે છે તે પદ્ધતિ તરફ ધ્યાન આપશો.
//! કેમ તે વિશે વધુ વિગત માટે, '[અમલીકરણ કરનાર][#અમલીકરણ-પુનરાવર્તક)' જુઓ.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! બસ આ જ!ચાલો પુનરાવર્તકો ખોદીએ.
//!
//! # Iterator
//!
//! આ મોડ્યુલનું હૃદય અને આત્મા એ [`Iterator`] trait છે.[`Iterator`] નો મુખ્ય ભાગ આના જેવો દેખાય છે:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ઇટિરેટર પાસે એક પદ્ધતિ છે, એક્સ00 એક્સ, જેને કહેવા પર, [`વિકલ્પ`]`આપે છે<Item>`.
//! [`next`] ત્યાં સુધી તત્વો હોય ત્યાં સુધી [`Some(Item)`] પરત કરશે, અને એકવાર તે બધા થાકી ગયા પછી, `None` પરત કરશે કે જે પુનરાવર્તિત સમાપ્ત થઈ ગયું છે તે દર્શાવવા માટે.
//! વ્યક્તિગત પુનરાવર્તનો પુનરાવર્તિત કરવાનું ફરી પસંદ કરવાનું પસંદ કરી શકે છે, અને તેથી [`next`] ને ફરીથી ક someલ કરવો તે આખરે [`Some(Item)`] ને કેટલાક તબક્કે પાછા ફરવાનું શરૂ કરી શકે છે અથવા ઉદાહરણ તરીકે, જુઓ [`TryIter`]).
//!
//!
//! [Te ઇટરેટર`] ની સંપૂર્ણ વ્યાખ્યામાં સંખ્યાબંધ અન્ય પદ્ધતિઓ શામેલ છે, પરંતુ તે મૂળભૂત પદ્ધતિઓ છે, જે [`next`] ની ટોચ પર બનાવવામાં આવી છે, અને તેથી તમે તેને મફતમાં મેળવો.
//!
//! ઇટરેટર્સ પણ કંપોઝ કરવા યોગ્ય છે, અને પ્રક્રિયાના વધુ જટિલ સ્વરૂપો કરવા માટે તેમને સાંકળવાનું સામાન્ય છે.વધુ વિગતો માટે નીચેનો [Adapters](#adapters) વિભાગ જુઓ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # પુનરાવૃત્તિના ત્રણ સ્વરૂપો
//!
//! ત્યાં ત્રણ સામાન્ય પદ્ધતિઓ છે જે સંગ્રહમાંથી પુનરાવર્તિત બનાવી શકે છે:
//!
//! * `iter()`, જે `&T` ઉપર પુનરાવર્તિત થાય છે.
//! * `iter_mut()`, જે `&mut T` ઉપર પુનરાવર્તિત થાય છે.
//! * `into_iter()`, જે `T` ઉપર પુનરાવર્તિત થાય છે.
//!
//! માનક લાઇબ્રેરીની વિવિધ વસ્તુઓ, જ્યાં યોગ્ય હોય ત્યાં ત્રણમાંથી એક અથવા વધુને લાગુ કરી શકે છે.
//!
//! # અમલીકરણ કરનાર
//!
//! તમારા પોતાના ઇરેટર બનાવવા માટે બે પગલાં શામેલ છે: પુનરાવર્તકની સ્થિતિને રાખવા માટે એક `struct` બનાવવું, અને પછી તે `struct` માટે [`Iterator`] અમલમાં મૂકવું.
//! આ જ કારણે આ મોડ્યુલમાં ઘણા બધા `ાંચા છે: દરેક પુનરાવર્તક અને પુનરાવર્તક એડેપ્ટર માટે એક છે.
//!
//! ચાલો `Counter` નામનું એક ઇરેટર બનાવીએ જે `1` થી `5` સુધીની ગણાય છે:
//!
//! ```
//! // પ્રથમ, સ્ટ્રક્ટ:
//!
//! /// એક પુનરાવર્તક જે એકથી પાંચ સુધીની ગણતરી કરે છે
//! struct Counter {
//!     count: usize,
//! }
//!
//! // અમે ઇચ્છીએ છીએ કે અમારી ગણતરી એકથી શરૂ થાય, તેથી ચાલો સહાય માટે એક new() પદ્ધતિ ઉમેરીએ.
//! // આ કડક રીતે જરૂરી નથી, પરંતુ અનુકૂળ છે.
//! // નોંધ લો કે આપણે `count` ને શૂન્યથી શરૂ કરીએ છીએ, અમે નીચે શા માટે `next()`'s અમલીકરણમાં જોશું.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // તે પછી, અમે અમારા `Counter` માટે `Iterator` લાગુ કરીએ છીએ:
//!
//! impl Iterator for Counter {
//!     // અમે usize સાથે ગણતરી કરીશું
//!     type Item = usize;
//!
//!     // next() એકમાત્ર આવશ્યક પદ્ધતિ છે
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // અમારી ગણતરીમાં વધારો.આથી જ આપણે શૂન્યથી શરૂઆત કરી.
//!         self.count += 1;
//!
//!         // અમે ગણતરી પૂર્ણ કરી છે કે નહીં તે જોવા માટે તપાસો.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // અને હવે આપણે તેનો ઉપયોગ કરી શકીએ છીએ!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] ને આ રીતે કલ કરવો પુનરાવર્તિત થાય છે.ઝેડ રસ્ટ0 ઝેડમાં એક કન્સ્ટ્રકટ છે જે તમારા ઇટરેટર પર [`next`] ક canલ કરી શકે છે, ત્યાં સુધી તે `None` સુધી પહોંચે નહીં.ચાલો તે આગળ જઈએ.
//!
//! એ પણ નોંધો કે `Iterator` `nth` અને `fold` જેવી પદ્ધતિઓનું ડિફ defaultલ્ટ અમલીકરણ પ્રદાન કરે છે જે `next` ને આંતરિક રૂપે ક callલ કરે છે.
//! જો કે, જો કોઈ ઇરેટર `next` ને ક withoutલ કર્યા વિના વધુ અસરકારક રીતે તેની ગણતરી કરી શકે તો `nth` અને `fold` જેવી પદ્ધતિઓનો વૈવિધ્યપૂર્ણ અમલીકરણ લખવાનું પણ શક્ય છે.
//!
//! # `for` આંટીઓ અને `IntoIterator`
//!
//! ઝેડ ર્રસ્ટ0 ઝેડનો એક્સ01 એક્સ લૂપ સિન્ટેક્સ ખરેખર પુનરાવર્તકો માટે ખાંડ છે.અહીં `for` નું મૂળ ઉદાહરણ છે:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! આ દરેકને તેમની પોતાની લાઇન પર એકથી પાંચ સુધી નંબરો છાપશે.પરંતુ તમે અહીં કંઇક નોંધશો: પુનરાવર્તક ઉત્પાદન માટે અમે અમારા ઝેડ 0 વેક્ટર 0 ઝેડ પર ક્યારેય કશું બોલાવ્યું નહીં.શું આપે છે?
//!
//! કોઈ વસ્તુને ઇરેટરમાં રૂપાંતરિત કરવા માટે માનક લાઇબ્રેરીમાં એક ઝેડટ્રેટ 0 ઝેડ છે: [`IntoIterator`].
//! આ trait પાસે એક પદ્ધતિ છે, [`into_iter`], જે [`IntoIterator`] લાગુ કરતી વસ્તુને ઇરેટરમાં ફેરવે છે.
//! ચાલો તે `for` લૂપ પર ફરી એક નજર નાખો, અને કમ્પાઇલર તેને શેમાં ફેરવે છે:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ઝેડ રસ્ટ0 ઝેડ આને આમાં સુગર કરે છે:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! પ્રથમ, અમે કિંમત પર `into_iter()` કહીએ છીએ.તે પછી, અમે ઇરેટર પર મેચ કરીએ છીએ જે પાછું આપે છે, જ્યાં સુધી આપણે `None` ન જોીએ ત્યાં સુધી [`next`] ને ક callingલ કરો.
//! તે સમયે, અમે લૂપમાંથી `break` કરીએ છીએ, અને અમે પુનરાવર્તિત થઈ ગયા છીએ.
//!
//! અહીં એક વધુ સૂક્ષ્મ બીટ છે: માનક પુસ્તકાલયમાં [`IntoIterator`] નું રસિક અમલીકરણ શામેલ છે:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! બીજા શબ્દોમાં કહીએ તો, બધા [te Iterator`] ફક્ત પોતાને પરત કરીને [`IntoIterator`] અમલમાં મૂક્યા છે.આનો અર્થ બે વસ્તુઓ છે:
//!
//! 1. જો તમે [`Iterator`] લખી રહ્યાં છો, તો તમે તેનો ઉપયોગ `for` લૂપથી કરી શકો છો.
//! 2. જો તમે કોઈ સંગ્રહ બનાવી રહ્યા છો, તો તેના માટે [`IntoIterator`] લાગુ કરવાથી તમારા સંગ્રહને `for` લૂપ સાથે ઉપયોગ કરવાની મંજૂરી મળશે.
//!
//! # સંદર્ભ દ્વારા Iterating
//!
//! [`into_iter()`] કિંમતે `self` લે છે, તેથી સંગ્રહ પર પુનરાવર્તિત થવા માટે `for` લૂપનો ઉપયોગ કરીને તે સંગ્રહ વાપરે છે.ઘણીવાર, તમે કોઈ સંગ્રહ લીધા વિના પુનરાવર્તન કરી શકો છો.
//! ઘણા સંગ્રહો પદ્ધતિઓ પ્રદાન કરે છે જે સંદર્ભો પર પુનરાવર્તિત પ્રદાન કરે છે, જેને પરંપરાગત રીતે અનુક્રમે `iter()` અને `iter_mut()` કહેવામાં આવે છે:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` હજી પણ આ કાર્યની માલિકી છે.
//! ```
//!
//! જો સંગ્રહ પ્રકાર `C` `iter()` પૂરો પાડે છે, તો તે સામાન્ય રીતે `&C` માટે `IntoIterator` પણ અમલમાં મૂકે છે, જેને ફક્ત `iter()` કહે છે.
//! તેવી જ રીતે, `C` સંગ્રહ પૂરો પાડે છે જે `iter_mut()` પ્રદાન કરે છે સામાન્ય રીતે `&mut C` માટે `iter_mut()` ને સોંપીને `IntoIterator` લાગુ કરે છે.આ અનુકૂળ શોર્ટહેન્ડને સક્ષમ કરે છે:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` જેટલું જ
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` જેટલું જ
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! જ્યારે ઘણા સંગ્રહ `iter()` ની ઓફર કરે છે, બધા ઓફર કરે છે `iter_mut()`.
//! ઉદાહરણ તરીકે, [`HashSet<T>`] અથવા [`HashMap<K, V>`] ની કીઓ પરિવર્તિત કરવાથી જો કી હેશ્સ બદલાઈ જાય તો સંગ્રહને અસંગત સ્થિતિમાં મૂકી શકાય છે, તેથી આ સંગ્રહો ફક્ત `iter()` આપે છે.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] લે છે અને બીજો [`Iterator`] પાછું આપે છે તેવા કાર્યોને ઘણીવાર 'ઇટરેટર એડેપ્ટર્સ' કહેવામાં આવે છે, કારણ કે તે 'એડેપ્ટર'નું સ્વરૂપ છે
//! pattern'.
//!
//! સામાન્ય ઇટરેટર એડેપ્ટર્સમાં [`map`], [`take`] અને [`filter`] શામેલ છે.
//! વધુ માટે, તેમના દસ્તાવેજીકરણ જુઓ.
//!
//! જો ઇટરેટર એડેપ્ટર panics, તો પુનરાવર્તક અનિશ્ચિત (પરંતુ મેમરી સલામત) સ્થિતિમાં હશે.
//! આ રાજ્યમાં ઝેડ રસ્ટ0 ઝેડનાં સમાન સંસ્કરણોમાં સમાન રહેવાની બાંયધરી પણ નથી, તેથી તમારે ગભરાવનારા પુનરાવર્તિત દ્વારા પાછા ફરતા ચોક્કસ મૂલ્યો પર આધાર રાખવાનું ટાળવું જોઈએ.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ઇટરેટર્સ (અને ઇરેટર X01 એક્સ *આળસુ* છે. આનો અર્થ એ કે ફક્ત એક ઇરેટર બનાવવું એ આખું _do_ નથી કરતું. જ્યાં સુધી તમે [`next`] ને ક .લ નહીં કરો ત્યાં સુધી કંઈ જ થતું નથી.
//! ફક્ત તેની આડઅસરો માટે ઇરેટર બનાવતી વખતે આ મૂંઝવણનું કારણ બને છે.
//! ઉદાહરણ તરીકે, [`map`] પધ્ધતિ તેના પર પુનરાવર્તિત થતા દરેક તત્વ પર બંધ કહે છે:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! આ કોઈપણ કિંમતોને છાપશે નહીં, કારણ કે આપણે તેનો ઉપયોગ કરવાને બદલે ફક્ત એક ઇરેટર બનાવ્યો છે.કમ્પાઇલર અમને આ પ્રકારના વર્તન વિશે ચેતવણી આપશે:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! તેની આડઅસરો માટે [`map`] લખવાની મૂર્ખામીનો માર્ગ એ `for` લૂપનો ઉપયોગ કરવો અથવા [`for_each`] પદ્ધતિને ક callલ કરવો:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ઇટરેટરનું મૂલ્યાંકન કરવાની બીજી સામાન્ય રીત એ છે કે નવું સંગ્રહ ઉત્પન્ન કરવા માટે [`collect`] પદ્ધતિનો ઉપયોગ કરવો.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ઇટરેટર્સને મર્યાદિત હોવું જરૂરી નથી.ઉદાહરણ તરીકે, ખુલ્લી-અંતિમ શ્રેણી એ અનંત પુનરાવર્તક છે:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! અનંત પુનરાવર્તકને મર્યાદિત રૂપે ફેરવવા માટે [`take`] ઇટરેટર એડેપ્ટરનો ઉપયોગ કરવો સામાન્ય છે:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! આ `4` દ્વારા `0` નંબરો, દરેકને તેમની પોતાની લાઇન પર છાપશે.
//!
//! ધ્યાનમાં રાખો કે અનંત પુનરાવર્તકો પરની પદ્ધતિઓ, તે પણ કે જેના માટે પરિણામ ગાણિતિક રીતે મર્યાદિત સમયમાં નક્કી કરી શકાય છે, સમાપ્ત થઈ શકશે નહીં.
//! ખાસ કરીને, [`min`] જેવી પદ્ધતિઓ, જેને સામાન્ય સ્થિતિમાં પુનરાવર્તકમાં દરેક તત્વને પસાર કરવાની જરૂર હોય છે, તે કોઈપણ અનંત પુનરાવર્તકો માટે સફળતાપૂર્વક પાછા ન આવે તેવી સંભાવના છે.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // અરે નહિ!અનંત લૂપ!
//! // `ones.min()` અનંત લૂપનું કારણ બને છે, તેથી અમે આ તબક્કે પહોંચશું નહીં!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;