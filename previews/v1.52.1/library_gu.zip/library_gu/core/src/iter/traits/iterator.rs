// અવગણો-વ્યવસ્થિત-ફાઇલલેન્થ આ ફાઇલમાં લગભગ સંપૂર્ણપણે `Iterator` ની વ્યાખ્યા શામેલ છે.
// અમે તેને બહુવિધ ફાઇલોમાં વિભાજીત કરી શકતા નથી.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// પુનરાવર્તકો સાથેના વ્યવહાર માટેનું ઇન્ટરફેસ.
///
/// આ મુખ્ય ઇટરેટર trait છે.
/// સામાન્ય રીતે પુનરાવર્તકોની વિભાવના વિશે વધુ માટે, કૃપા કરીને [module-level documentation] જુઓ.
/// ખાસ કરીને, તમે [implement `Iterator`][impl] કેવી રીતે કરવું તે જાણી શકો છો.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// તત્વોનો પ્રકાર પુનરાવર્તિત થઈ રહ્યો છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// પુનરાવર્તકને આગળ વધારશે અને આગળનું મૂલ્ય આપે છે.
    ///
    /// જ્યારે ઇટરેશન સમાપ્ત થાય ત્યારે [`None`] આપે છે.
    /// વ્યક્તિગત પુનરાવર્તિત અમલીકરણો પુનરાવર્તિત કરવાનું ફરી પસંદ કરવાનું પસંદ કરી શકે છે, અને તેથી `next()` ને ફરીથી ક .લ કરવો એ અમુક સમયે ફરીથી [`Some(Item)`] પાછા આપવાનું શરૂ કરી શકે છે અથવા નહીં.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() પર ક callલ આગલું મૂલ્ય આપે છે ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... અને પછી એકવાર તે પૂર્ણ થઈ જાય.
    /// assert_eq!(None, iter.next());
    ///
    /// // વધુ ક callsલ્સ `None` પાછા આપી શકે છે અથવા નહીં.અહીં, તેઓ હંમેશા કરશે.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ઇરેટરની બાકીની લંબાઈ પરની સીમાઓ પરત કરે છે.
    ///
    /// ખાસ કરીને, `size_hint()` એક ટુપલ આપે છે જ્યાં પ્રથમ તત્વ નીચલું બાઉન્ડ હોય છે, અને બીજો તત્વ ઉપલા બાઉન્ડ હોય છે.
    ///
    /// પાછું આપેલ ટ્યુપલનો બીજો ભાગ એ એક [`વિકલ્પ`]`<`[`યુઝાઇઝ]]`>` છે.
    /// અહીં એક [`None`] નો અર્થ છે કે કાં તો ત્યાં કોઈ ઉપલા બાઉન્ડ નથી, અથવા ઉપલા બાઉન્ડ [`usize`] કરતા મોટા છે.
    ///
    /// # અમલીકરણની નોંધ
    ///
    /// તે લાગુ કરવામાં આવતું નથી કે ઇરેટર અમલીકરણ તત્વોની ઘોષિત સંખ્યા પ્રાપ્ત કરે છે.બગડેલ ઇટિરેટર નીચલા બાઉન્ડ કરતા ઓછા અથવા તત્વોના ઉપરના બાઉન્ડ કરતા વધુ પ્રાપ્ત કરી શકે છે.
    ///
    /// `size_hint()` મુખ્યત્વે પુનરાવર્તક તત્વો માટે જગ્યા બચાવવા જેવા optimપ્ટિમાઇઝેશન માટે વાપરવા માટે બનાવાયેલ છે, પરંતુ દા.ત. પર વિશ્વાસ કરવો જોઇએ નહીં, અસુરક્ષિત કોડમાં બાઉન્ડ્સ ચેક છોડી દેવું જોઈએ.
    /// `size_hint()` ના ખોટા અમલીકરણથી મેમરી સલામતી ઉલ્લંઘન તરફ દોરી જવી જોઈએ નહીં.
    ///
    /// તેણે કહ્યું કે, અમલીકરણએ સાચો અંદાજ પૂરો પાડવો જોઈએ, કારણ કે અન્યથા તે ઝેડટ્રેટ 0 ઝેડના પ્રોટોકોલનું ઉલ્લંઘન હશે.
    ///
    /// ડિફ defaultલ્ટ અમલીકરણ returns (0, `[` કંઈ નહીં]] `) returns આપે છે જે કોઈપણ પુનરાવર્તક માટે યોગ્ય છે.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// એક વધુ જટિલ ઉદાહરણ:
    ///
    /// ```
    /// // શૂન્યથી દસ સુધીની સમાન સંખ્યા.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // આપણે શૂન્યથી દસ વખત પુનરાવર્તિત થઈ શકીએ છીએ.
    /// // તે જાણવું કે તે પાંચ બરાબર filter() ચલાવ્યા વિના શક્ય નથી.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // ચાલો chain() સાથે વધુ પાંચ સંખ્યાઓ ઉમેરીએ
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // હવે બંને સીમામાં પાંચનો વધારો થયો છે
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ઉપલા બાઉન્ડ માટે `None` પરત આપવું:
    ///
    /// ```
    /// // અનંત પુનરાવર્તક પાસે કોઈ ઉપલા બાઉન્ડ અને મહત્તમ શક્ય નીચલા બાઉન્ડ નથી
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// પુનરાવર્તકનો ઉપયોગ કરે છે, પુનરાવર્તનોની સંખ્યાની ગણતરી કરીને અને તેને પાછા આપી રહ્યા છે.
    ///
    /// [`None`] ન આવે ત્યાં સુધી આ પદ્ધતિ [`next`] ને વારંવાર ક willલ કરશે, [`Some`] જેટલા વખત જોયું તેની સંખ્યા પરત કરશે.
    /// નોંધ લો કે ઇરેટરમાં કોઈ તત્વો ન હોવા છતાં પણ, [`next`] ને ઓછામાં ઓછા એક વખત ક calledલ કરવો પડશે.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ઓવરફ્લો વર્તન
    ///
    /// પદ્ધતિ ઓવરફ્લો સામે કોઈ રક્ષણ આપતી નથી, તેથી [`usize::MAX`] કરતાં વધુ તત્વોવાળા ઇટરેટરના ઘટકોની ગણતરી કાં તો ખોટું પરિણામ અથવા ઝેડ 0 સ્પેનિક્સ0 ઝેડ ઉત્પન્ન કરે છે.
    ///
    /// જો ડિબગ નિવેદનોને સક્ષમ કરવામાં આવે છે, તો ઝેડપૈનિક 0 ઝેડની ખાતરી આપવામાં આવે છે.
    ///
    /// # Panics
    ///
    /// જો ઇરેટરમાં [`usize::MAX`] કરતાં વધુ તત્વો હોય તો આ ફંક્શન panic શકે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// પુનરાવર્તક લે છે, છેલ્લા તત્વ પરત.
    ///
    /// જ્યાં સુધી તે [`None`] પરત નહીં આપે ત્યાં સુધી આ પદ્ધતિ પુનરાવર્તકનું મૂલ્યાંકન કરશે.
    /// આમ કરતી વખતે, તે વર્તમાન તત્વનો ટ્ર ofક રાખે છે.
    /// [`None`] પરત આવ્યા પછી, `last()` પછી જોયું તે છેલ્લું તત્વ પાછું આપશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` તત્વો દ્વારા ઇરેટરને આગળ વધે છે.
    ///
    /// જ્યાં સુધી [`None`] નો સામનો ન થાય ત્યાં સુધી આ પદ્ધતિ [`next`] સુધી [`next`] સુધી ફોન કરીને `n` તત્વોને આતુરતાથી છોડશે.
    ///
    /// `advance_by(n)` જો ઇરેટર `n` તત્વો દ્વારા સફળતાપૂર્વક આગળ વધે છે, અથવા જો [`None`] નો સામનો કરવો પડે તો [`Err(k)`][Err],[`Ok(())`][Ok] પરત આપશે, જ્યાં `k` એ તત્વોની સંખ્યા છે જે તત્વોની બહાર ચાલતા પહેલા ઇરેટર દ્વારા આગળ વધવામાં આવે છે (એટલે કે
    /// પુનરાવર્તકની લંબાઈ).
    /// નોંધ લો કે `k` હંમેશાં `n` કરતા ઓછું હોય છે.
    ///
    /// ક0લ કરો X01 એક્સ એ કોઈપણ તત્વોનો વપરાશ કરતો નથી અને હંમેશાં [`Ok(())`][Ok] આપે છે.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // ફક્ત `&4` અવગણવામાં આવ્યું હતું
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// પુનરાવર્તકનું element n` તત્વ પરત કરે છે.
    ///
    /// મોટાભાગના અનુક્રમણિકાત્મક કામગીરીની જેમ, ગણતરી શૂન્યથી શરૂ થાય છે, તેથી `nth(0)` પ્રથમ મૂલ્ય, `nth(1)` બીજું, અને તેથી વધુ આપે છે.
    ///
    /// નોંધ કરો કે બધા પહેલાનાં તત્વો, તેમજ પરત તત્વો, ઇટરેટરમાંથી ખાવામાં આવશે.
    /// તેનો અર્થ એ કે અગાઉના તત્વોને કાedી નાખવામાં આવશે, અને તે પણ કે એક જ પુનરાવર્તક પર ઘણીવાર `nth(0)` ક callingલ કરવાથી વિવિધ તત્વો પાછા આવશે.
    ///
    ///
    /// `nth()` જો X01 એક્સ પુનરાવર્તકની લંબાઈ કરતા વધારે અથવા તેના બરાબર હોય તો [`None`] પરત કરશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// બહુવિધ વખત `nth()` ક Callલ કરવાથી પુનરાવર્તક ફરી વળતું નથી:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// જો `n + 1` કરતા ઓછા તત્વો હોય તો `None` પરત આપવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// એ જ બિંદુથી પ્રારંભ થતો એક ઇરેટર બનાવે છે, પરંતુ દરેક પુનરાવૃત્તિ પર આપેલ રકમ દ્વારા પગલું ભરવું.
    ///
    /// નોંધ 1: આપેલા પગલાને ધ્યાનમાં લીધા વિના, પુનરાવર્તકનું પ્રથમ તત્વ હંમેશાં પરત આવશે.
    ///
    /// નોંધ 2: અવગણના કરાયેલા તત્વો ખેંચવાનો સમય નિશ્ચિત નથી.
    /// `StepBy` સિક્વન્સ `next(), nth(step-1), nth(step-1),…` ની જેમ વર્તે છે, પણ સિક્વેન્સની જેમ વર્તે પણ મફત છે
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// પ્રદર્શનના કારણોસર કેટલીક પુનરાવર્તકો માટે કઈ રીતનો ઉપયોગ થઈ શકે છે.
    /// બીજી રીત પુનરાવર્તકને અગાઉ બનાવશે અને વધુ વસ્તુઓનો વપરાશ કરી શકે છે.
    ///
    /// `advance_n_and_return_first` ની સમકક્ષ છે:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// જો આપેલું પગલું `0` છે, તો પદ્ધતિ panic કરશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// બે પુનરાવર્તક લે છે અને અનુક્રમે બંને ઉપર એક નવું પુનરાવર્તક બનાવે છે.
    ///
    /// `chain()` નવું પુનરાવર્તક આપશે જે પ્રથમ પુનરાવર્તકનાં મૂલ્યો ઉપર અને પછી બીજા પુનરાવર્તકનાં મૂલ્યો ઉપર પુનરાવર્તન કરશે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, તે સાંકળમાં, બે પુનરાવર્તકોને એક સાથે જોડે છે.🔗
    ///
    /// [`once`] સામાન્ય રીતે એકલ મૂલ્યને અન્ય પ્રકારની પુનરાવૃત્તિની સાંકળમાં અનુરૂપ બનાવવા માટે વપરાય છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` માટેની દલીલ [`IntoIterator`] નો ઉપયોગ કરે છે, તેથી આપણે [`Iterator`] માં રૂપાંતરિત કરી શકાય તેવી કોઈપણ વસ્તુને પાસ કરી શકીએ છીએ, ફક્ત [`Iterator`] જ નહીં.
    /// ઉદાહરણ તરીકે, કટકાઓ (`&[T]`), [`IntoIterator`] ને લાગુ કરે છે, અને તેથી સીધા `chain()` પર પસાર કરી શકાય છે:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// જો તમે Windows API સાથે કામ કરો છો, તો તમે [`OsStr`] ને `Vec<u16>` માં કન્વર્ટ કરી શકો છો:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// જોડીના એક જ પુનરાવર્તકમાં બે ઇટરેટર્સને 'ઝિપ્સ અપ' કરો.
    ///
    /// `zip()` એક નવું પુનરાવર્તક આપે છે જે બે અન્ય પુનરાવર્તકો પર પુનરાવર્તિત થાય છે, ટ્યુપલ પાછું આપે છે જ્યાં પ્રથમ તત્વ પ્રથમ પુનરાવર્તકમાંથી આવે છે, અને બીજો તત્વ બીજા પુનરાવર્તકમાંથી આવે છે.
    ///
    ///
    /// બીજા શબ્દોમાં કહીએ તો, તે એક સાથે બે પુનરાવર્તકોને એક સાથે ઝિપ કરે છે.
    ///
    /// જો ક્યાં તો પુનરાવર્તક [`None`] આપે છે, ઝિપ ઇટરેટરમાંથી [`next`] [`None`] પરત કરશે.
    /// જો પ્રથમ પુનરાવર્તક [`None`] આપે છે, તો `zip` શોર્ટ-સર્કિટ કરશે અને બીજા પુનરાવર્તક પર `next` કહેવામાં આવશે નહીં.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` માટેની દલીલ [`IntoIterator`] નો ઉપયોગ કરે છે, તેથી આપણે [`Iterator`] માં રૂપાંતરિત કરી શકાય તેવી કોઈપણ વસ્તુને પાસ કરી શકીએ છીએ, ફક્ત [`Iterator`] જ નહીં.
    /// ઉદાહરણ તરીકે, કટકાઓ (`&[T]`), [`IntoIterator`] ને લાગુ કરે છે, અને તેથી સીધા `zip()` પર પસાર કરી શકાય છે:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` અનંત પુનરાવર્તકને ઘણીવાર મર્યાદિત માટે ઝિપ કરવા માટે વપરાય છે.
    /// આ કામ કરે છે કારણ કે મર્યાદિત પુનરાવર્તક આખરે [`None`] પરત કરશે, ઝીપરને સમાપ્ત કરશે.`(0..)` સાથે ઝિપ કરવું એ [`enumerate`] જેવા ઘણા દેખાશે:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// એક નવું પુનરાવર્તક બનાવે છે જે મૂળ પુનરાવર્તકની અડીને વસ્તુઓ વચ્ચે `separator` ની નકલ મૂકે છે.
    ///
    /// `separator` એ [`Clone`] લાગુ કરતું નથી અથવા દર વખતે ગણતરી કરવાની જરૂર હોય તો, [`intersperse_with`] નો ઉપયોગ કરો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` માંથી પ્રથમ તત્વ.
    /// assert_eq!(a.next(), Some(&100)); // વિભાજક.
    /// assert_eq!(a.next(), Some(&1));   // `a` થી આગળનું તત્વ.
    /// assert_eq!(a.next(), Some(&100)); // વિભાજક.
    /// assert_eq!(a.next(), Some(&2));   // `a` નું છેલ્લું તત્વ.
    /// assert_eq!(a.next(), None);       // પુનરાવર્તક સમાપ્ત થાય છે.
    /// ```
    ///
    /// `intersperse` સામાન્ય તત્વનો ઉપયોગ કરીને ઇરેટરની આઇટમ્સમાં જોડાવા માટે ખૂબ ઉપયોગી થઈ શકે છે:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// એક નવું પુનરાવર્તક બનાવે છે જે મૂળ પુનરાવર્તકની અડીને વસ્તુઓ વચ્ચે `separator` દ્વારા પેદા કરેલી આઇટમ મૂકે છે.
    ///
    /// અંતર્ગત પુનરાવર્તકમાંથી બે સંલગ્ન વસ્તુઓની વચ્ચે કોઈ વસ્તુ મૂકવામાં આવે ત્યારે દર વખતે બરાબર એક વખત આ ક્લોઝર કહેવામાં આવશે;
    /// ખાસ કરીને, જો અંતર્ગત પુનરાવર્તક બે કરતાં ઓછી આઇટમ્સ મેળવે છે અને છેલ્લી વસ્તુ પ્રાપ્ત થાય છે, તો ક્લોઝર કહેવાતું નથી.
    ///
    ///
    /// જો ઇરેટરની આઇટમ [`Clone`] લાગુ કરે છે, તો [`intersperse`] નો ઉપયોગ કરવો વધુ સરળ હશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` માંથી પ્રથમ તત્વ.
    /// assert_eq!(it.next(), Some(NotClone(99))); // વિભાજક.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` થી આગળનું તત્વ.
    /// assert_eq!(it.next(), Some(NotClone(99))); // વિભાજક.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` નું છેલ્લું તત્વ.
    /// assert_eq!(it.next(), None);               // પુનરાવર્તક સમાપ્ત થાય છે.
    /// ```
    ///
    /// `intersperse_with` વિભાગોની ગણતરી કરવાની જરૂર હોય ત્યાં પરિસ્થિતિઓમાં ઉપયોગ કરી શકાય છે:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // બંધ કરવું પરસ્પર કોઈ વસ્તુ પેદા કરવા માટે તેના સંદર્ભમાં ઉધાર લે છે.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// બંધ લે છે અને એક ઇરેટર બનાવે છે જે તે દરેક તત્વ પરના બંધને કહે છે.
    ///
    /// `map()` તેના દલીલ દ્વારા, એક ઇરેટરને બીજામાં ફેરવે છે:
    /// કંઈક જે [`FnMut`] લાગુ કરે છે.તે એક નવું પુનરાવર્તક ઉત્પન્ન કરે છે જે મૂળ પુનરાવર્તકના દરેક તત્વ પર આ બંધને કહે છે.
    ///
    /// જો તમે પ્રકારોમાં વિચારવામાં સારા છો, તો તમે `map()` વિશે આ રીતે વિચારી શકો છો:
    /// જો તમારી પાસે ઇરેટર છે જે તમને અમુક પ્રકારનાં `A` ના તત્વો આપે છે, અને તમને કોઈ બીજા પ્રકારનાં `B` નું પુનરાવર્તક જોઈએ છે, તો તમે `map()` નો ઉપયોગ કરી શકો છો, એક ક્લોઝર પસાર કરીને જે `A` લે છે અને `B` આપે છે.
    ///
    ///
    /// `map()` [`for`] લૂપ જેવું છે.જો કે, `map()` આળસુ હોવાથી, જ્યારે તમે પહેલાથી અન્ય ઇટરેટર્સ સાથે કામ કરી રહ્યાં હોવ ત્યારે તેનો શ્રેષ્ઠ ઉપયોગ થાય છે.
    /// જો તમે આડઅસર માટે અમુક પ્રકારની લૂપિંગ કરી રહ્યાં છો, તો `map()` કરતા [`for`] નો ઉપયોગ કરવો વધુ મૂર્ખામીભર્યું માનવામાં આવે છે.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// જો તમે કોઈ પ્રકારની આડઅસર કરી રહ્યાં છો, તો [`for`] થી `map()` ને પ્રાધાન્ય આપો:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // આ ન કરો:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // તે અમલ પણ નહીં કરે, કેમ કે તે આળસુ છે.Rust તમને આ વિશે ચેતવણી આપશે.
    ///
    /// // તેના બદલે, આનો ઉપયોગ કરો:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// પુનરાવર્તકના દરેક તત્વ પર એક બંધ કallsલ કરો.
    ///
    /// આ પુનરાવર્તક પર [`for`] લૂપનો ઉપયોગ કરવા બરાબર છે, જોકે બંધ થવાથી `break` અને `continue` શક્ય નથી.
    /// તે સામાન્ય રીતે `for` લૂપનો ઉપયોગ કરવા માટે વધુ મૂર્ખામીભર્યું છે, પરંતુ લાંબી પુનરાવર્તક સાંકળોના અંતમાં આઇટમ્સ પર પ્રક્રિયા કરતી વખતે `for_each` વધુ સુવાચ્ય હોઈ શકે.
    ///
    /// કેટલાક કેસમાં `for_each` લૂપ કરતા પણ ઝડપી હોઈ શકે છે, કારણ કે તે `Chain` જેવા એડેપ્ટરો પર આંતરિક પુનરાવર્તનનો ઉપયોગ કરશે.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// આવા નાના ઉદાહરણ માટે, `for` લૂપ ક્લીનર હોઈ શકે છે, પરંતુ લાંબી પુનરાવર્તકો સાથે કાર્યાત્મક શૈલી રાખવાનું `for_each` વધુ સારું છે:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ઇટિરેટર બનાવે છે જે કોઈ તત્વ આપવું જોઈએ કે કેમ તે નિર્ધારિત કરવા માટે બંધનો ઉપયોગ કરે છે.
    ///
    /// એક તત્વ આપ્યું છે કે બંધ થવું જોઈએ `true` અથવા `false`.પરત ફરનાર ફક્ત તે જ તત્વો પ્રાપ્ત કરશે કે જેના માટે બંધ થવું સાચું.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// કારણ કે `filter()` માં બંધ થયેલ સંદર્ભ લે છે, અને ઘણાં પુનરાવર્તકો સંદર્ભો પર પુનરાવર્તન કરે છે, આ સંભવત conf મૂંઝવણભર્યા પરિસ્થિતિ તરફ દોરી જાય છે, જ્યાં બંધનો પ્રકાર ડબલ સંદર્ભ છે:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // બે * ઓ જરૂર છે!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// તેને દૂર કરવા માટે દલીલ પર વિનાશક ઉપયોગ કરવો સામાન્ય છે:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // બન્ને અને *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// અથવા બંને:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // બે &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// આ સ્તરો છે.
    ///
    /// નોંધ લો કે `iter.filter(f).next()` એ `iter.find(f)` ની સમકક્ષ છે.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// એક ઇરેટર બનાવે છે જે ફિલ્ટર્સ અને નકશા બંને છે.
    ///
    /// પરત કરેલ પુનરાવર્તક માત્ર `મૂલ્ય પ્રાપ્ત કરે છે જેના માટે પૂરા પાડવામાં આવેલ ક્લોઝર `Some(value)` આપે છે.
    ///
    /// `filter_map` [`filter`] અને [`map`] ની સાંકળો બનાવવા માટે વધુ સંક્ષિપ્ત બનાવવા માટે ઉપયોગ કરી શકાય છે.
    /// નીચેનું ઉદાહરણ બતાવે છે કે કેવી રીતે X001 ને એક જ ક callલમાં `map().filter().map()` ટૂંકાવી શકાય છે.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// અહીં તે જ ઉદાહરણ છે, પરંતુ [`filter`] અને [`map`] સાથે:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// એક પુનરાવર્તક બનાવે છે જે વર્તમાન પુનરાવૃત્તિ ગણતરી તેમજ આગામી મૂલ્ય આપે છે.
    ///
    /// પુનરાવર્તિતકર્તાએ `(i, val)` ની ઉપજ જોડી દીધી, જ્યાં `i` એ પુનરાવૃત્તિનું વર્તમાન અનુક્રમણિકા છે અને `val` એ પુનરાવર્તક દ્વારા પરત કરાયેલ મૂલ્ય છે.
    ///
    ///
    /// `enumerate()` તેની ગણતરી [`usize`] તરીકે રાખે છે.
    /// જો તમે કોઈ અલગ કદના પૂર્ણાંક દ્વારા ગણતરી કરવા માંગતા હો, તો [`zip`] ફંક્શન સમાન વિધેય પ્રદાન કરે છે.
    ///
    /// # ઓવરફ્લો વર્તન
    ///
    /// પદ્ધતિ ઓવરફ્લો સામે કોઈ રક્ષા કરી શકતી નથી, તેથી [`usize::MAX`] કરતાં વધુ તત્વોની ગણતરી કાં તો ખોટું પરિણામ અથવા panics ઉત્પન્ન કરે છે.
    /// જો ડિબગ નિવેદનોને સક્ષમ કરવામાં આવે છે, તો ઝેડપૈનિક 0 ઝેડની ખાતરી આપવામાં આવે છે.
    ///
    /// # Panics
    ///
    /// પરત કરેલ ઇટરેટર panic શકે જો પાછા આપેલ અનુક્રમણિકા એક [`usize`] ઓવરફ્લો કરશે.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// એક ઇરેટર બનાવે છે જે ઇટરરેટરના આગલા તત્વને ખાધા વિના [`peek`] નો ઉપયોગ કરી શકે છે.
    ///
    /// ઇરેટરમાં એક [`peek`] પદ્ધતિ ઉમેરો.વધુ માહિતી માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// નોંધ કરો કે અંતર્ગત પુનરાવર્તક હજી પણ અદ્યતન છે જ્યારે [`peek`] ને પ્રથમ વખત બોલાવવામાં આવે છે: આગલા ઘટકને પાછું મેળવવા માટે, [`next`] ને અંતર્ગત પુનરાવર્તક પર કહેવામાં આવે છે, તેથી કોઈપણ આડઅસર (દા.ત.
    ///
    /// [`next`] પદ્ધતિનું આગલું મૂલ્ય મેળવવામાં સિવાય બીજું કંઈપણ થશે.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ચાલો આપણે ઝેડ ફ્યુચર0 ઝેડમાં જોઈએ
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // અમે ઘણી વખત peek() કરી શકીએ છીએ, પુનરાવર્તક આગળ વધશે નહીં
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ઇરેટર સમાપ્ત થયા પછી, તેથી peek() છે
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// એક ઇરેટર બનાવે છે જે એક પૂર્વધારણા પર આધારિત [a અવગણો] તત્વો બનાવે છે.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` દલીલ તરીકે બંધ લે છે.તે આ બંધને પુનરાવર્તકના દરેક તત્વ પર ક callલ કરશે અને જ્યાં સુધી તે `false` નહીં આપે ત્યાં સુધી તત્વોની અવગણના કરશે.
    ///
    /// `false` પરત આવ્યા પછી, `skip_while()`'s જોબ સમાપ્ત થઈ, અને બાકીના તત્વો પ્રાપ્ત થયા.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// કારણ કે `skip_while()` માં બંધ થયેલ સંદર્ભ લે છે, અને ઘણાં પુનરાવર્તકો સંદર્ભો પર પુનરાવર્તન કરે છે, આ સંભવત conf મૂંઝવણભર્યા પરિસ્થિતિ તરફ દોરી જાય છે, જ્યાં બંધ દલીલનો પ્રકાર ડબલ સંદર્ભ છે:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // બે * ઓ જરૂર છે!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// પ્રારંભિક `false` પછી રોકો:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // જ્યારે આ ખોટું હોત, કારણ કે આપણે પહેલેથી જ ખોટું બનાવ્યું છે, skip_while() નો વધુ ઉપયોગ થતો નથી
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// એક ઇરેટર બનાવે છે જે પૂર્વાનુમાનના આધારે તત્વો આપે છે.
    ///
    /// `take_while()` દલીલ તરીકે બંધ લે છે.તે આ બંધને પુનરાવર્તકનાં દરેક તત્વ પર ક callલ કરશે અને જ્યારે તે `true` આપે ત્યારે તત્વોનું ઉત્પાદન કરશે.
    ///
    /// `false` પાછા આવ્યા પછી, `take_while()`'s જોબ સમાપ્ત થઈ ગઈ છે, અને બાકીના તત્વોને અવગણવામાં આવશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// કારણ કે `take_while()` માં બંધ થયેલ સંદર્ભ લે છે, અને ઘણાં પુનરાવર્તકો સંદર્ભો પર પુનરાવર્તન કરે છે, આ સંભવત conf મૂંઝવણભર્યા પરિસ્થિતિ તરફ દોરી જાય છે, જ્યાં બંધનો પ્રકાર ડબલ સંદર્ભ છે:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // બે * ઓ જરૂર છે!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// પ્રારંભિક `false` પછી રોકો:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // આપણી પાસે વધુ તત્વો છે જે શૂન્યથી ઓછા છે, પરંતુ અમને પહેલેથી જ ખોટું મળ્યું હોવાથી, take_while() નો વધુ ઉપયોગ થતો નથી
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// કારણ કે `take_while()` એ મૂલ્ય તરફ ધ્યાન આપવાની જરૂર છે કે કેમ તે જોવા માટે કે કેમ તે શામેલ હોવું જોઈએ કે નહીં, વપરાશકાર પુનરાવર્તિત જોશે કે તે દૂર થઈ ગયું છે:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` હવે નથી, કારણ કે તે પુનરાવર્તિત થવું બંધ થવું જોઈએ કે કેમ તે જોવા માટે તેનો વપરાશ કરવામાં આવ્યો હતો, પરંતુ તેને પુનરાવર્તકમાં મૂક્યો ન હતો.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// એક પુનરાવર્તક બનાવે છે જે બંને પૂર્વનિર્ધારક અને નકશાઓના આધારે તત્વો મેળવે છે.
    ///
    /// `map_while()` દલીલ તરીકે બંધ લે છે.
    /// તે આ બંધને પુનરાવર્તકનાં દરેક તત્વ પર ક callલ કરશે અને જ્યારે તે [`Some(_)`][`Some`] આપે ત્યારે તત્વોનું ઉત્પાદન કરશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// અહીં તે જ ઉદાહરણ છે, પરંતુ [`take_while`] અને [`map`] સાથે:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// પ્રારંભિક [`None`] પછી રોકો:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // અમારી પાસે વધુ તત્વો છે જે u32 (4, 5) માં ફિટ થઈ શકે છે, પરંતુ `map_while` `-3` પર `None` પરત ફર્યો (જેમ કે `predicate` `None` પરત ફર્યો) અને `collect` એ પહેલા `None` નો સામનો કરવો પડ્યો.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// કારણ કે `map_while()` એ મૂલ્ય તરફ ધ્યાન આપવાની જરૂર છે કે કેમ તે જોવા માટે કે કેમ તે શામેલ હોવું જોઈએ કે નહીં, વપરાશકાર પુનરાવર્તિત જોશે કે તે દૂર થઈ ગયું છે:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` હવે નથી, કારણ કે તે પુનરાવર્તિત થવું બંધ થવું જોઈએ કે કેમ તે જોવા માટે તેનો વપરાશ કરવામાં આવ્યો હતો, પરંતુ તેને પુનરાવર્તકમાં મૂક્યો ન હતો.
    ///
    /// નોંધ લો કે [`take_while`] થી વિપરીત આ પુનરાવર્તક **નથી** ફ્યુઝ થયેલ છે.
    /// પ્રથમ [`None`] પાછા આવ્યા પછી આ ઇટરેટર શું આપે છે તે પણ ઉલ્લેખિત નથી.
    /// જો તમને ફ્યુઝ્ડ ઇટરેટરની જરૂર હોય, તો [`fuse`] નો ઉપયોગ કરો.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// એક ઇરેટર બનાવે છે જે પહેલા `n` તત્વોને અવગણે છે.
    ///
    /// તેનો વપરાશ કર્યા પછી, બાકીના તત્વો પ્રાપ્ત થાય છે.
    /// આ પદ્ધતિને સીધી overવરરાઇડ કરવાને બદલે, `nth` પદ્ધતિને ફરીથી લખવા.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// એક ઇરેટર બનાવે છે જે તેના પ્રથમ `n` તત્વો આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` તેને અનંત પુનરાવર્તિત કરવા માટે, તેનો ઉપયોગ મર્યાદિત બનાવવા માટે વારંવાર થાય છે:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// જો `n` કરતા ઓછા તત્વો ઉપલબ્ધ હોય, તો `take` પોતાને અંતર્ગત પુનરાવર્તકના કદ સુધી મર્યાદિત કરશે:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] જેવું ઇટિરેટર એડેપ્ટર જે આંતરિક સ્થિતિ ધરાવે છે અને એક નવું ઇરેટર ઉત્પન્ન કરે છે.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` બે દલીલો લે છે: પ્રારંભિક મૂલ્ય જે આંતરિક રાજ્યને બીજ આપે છે, અને બે દલીલો સાથે સમાપ્ત થાય છે, પ્રથમ આંતરિક સ્થિતિનો પરિવર્તનશીલ સંદર્ભ અને બીજો એક ઇરેટર તત્વ.
    ///
    /// બંધ થવું એ પુનરાવર્તનો વચ્ચેની સ્થિતિને શેર કરવા માટે આંતરિક સ્થિતિને સોંપી શકે છે.
    ///
    /// ઇટરેશન પર, ક્લોઝર ઇટરેટરના દરેક તત્વ પર લાગુ કરવામાં આવશે અને ક્લોઝરમાંથી વળતર મૂલ્ય, એક એક્સ 100 એક્સ, ઇટરેટર દ્વારા પ્રાપ્ત થાય છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // દરેક પુનરાવર્તન, અમે તત્વ દ્વારા રાજ્ય ગુણાકાર કરીશું
    ///     *state = *state * x;
    ///
    ///     // તે પછી, અમે રાજ્યની અવગણના લાવીશું
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// એક ઇરેટર બનાવે છે જે નકશાની જેમ કાર્ય કરે છે, પરંતુ માળખાની રચનાને ચપળતાથી બનાવે છે.
    ///
    /// [`map`] એડેપ્ટર ખૂબ ઉપયોગી છે, પરંતુ માત્ર ત્યારે જ જ્યારે ક્લોઝર દલીલ મૂલ્યો ઉત્પન્ન કરે છે.
    /// જો તેના બદલે તે ઇરેટર ઉત્પન્ન કરે છે, તો ત્યાં ઇન્ડિરેશનનો એક વધારાનો સ્તર છે.
    /// `flat_map()` આ વધારાના સ્તરને જાતે જ દૂર કરશે.
    ///
    /// તમે `flat_map(f)` ને [`map`] પિંગના સિમેન્ટીક સમકક્ષ અને પછી [`સપાટ`] `map(f).flatten()` ની જેમ વિચારી શકો છો.
    ///
    /// `flat_map()` વિશે વિચારવાનો બીજો રસ્તો: [`map '] નું બંધ થવું એ દરેક તત્વ માટે એક આઇટમ આપે છે, અને `flat_map()`'s બંધ દરેક તત્વ માટે પુનરાવર્તિત વળતર આપે છે.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() એક ઇરેટર આપે છે
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// પુનરાવર્તિત રચના બનાવે છે જે નેસ્ડ સ્ટ્રક્ચરને ફ્લેટ કરે છે.
    ///
    /// આ ઉપયોગી છે જ્યારે તમારી પાસે પુનરાવર્તકોનો પુનરાવર્તક હોય અથવા વસ્તુઓનો પુનરાવર્તક હોય કે જે પુનરાવર્તિત થઈ શકે અને તમે એક સ્તરનું નિર્દેશન દૂર કરવા માંગતા હો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// મેપિંગ અને પછી ફ્લેટિંગ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() એક ઇરેટર આપે છે
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// તમે આને [`flat_map()`] ની દ્રષ્ટિએ ફરીથી લખી શકો છો, જે આ કિસ્સામાં વધુ પ્રાધાન્યવાળું છે કારણ કે તે વધુ સ્પષ્ટ રીતે હેતુ રજૂ કરે છે:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() એક ઇરેટર આપે છે
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ફ્લેટ્ટનિંગ એક સમયે માળાના એક સ્તરને દૂર કરે છે:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// અહીં આપણે જોઈએ છીએ કે `flatten()` "deep" ફ્લેટન કરતું નથી.
    /// તેના બદલે, માળાના માત્ર એક સ્તરને દૂર કરવામાં આવે છે.તે જ છે, જો તમે ત્રિ-પરિમાણીય એરે `flatten()` કરો છો, તો પરિણામ એક પરિમાણીય નહીં, પરંતુ, દ્વિપરિક હશે.
    /// એક પરિમાણીય માળખું મેળવવા માટે, તમારે ફરીથી `flatten()` કરવું પડશે.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// એક ઇરેટર બનાવે છે જે પ્રથમ [`None`] પછી સમાપ્ત થાય છે.
    ///
    /// ઇટરેટરએ [`None`] પરત કર્યા પછી, ઝેડ 0 ફ્યુચર0 ઝેડ ક callsલ્સ ફરીથી [`Some(T)`] પેદા કરી શકે છે અથવા નહીં.
    /// `fuse()` એક ઇરેટરને અનુકૂળ કરે છે, તેની ખાતરી કરીને કે [`None`] આપવામાં આવે છે, તે હંમેશાં [`None`] કાયમ માટે પાછો આવશે.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // એક ઇરેટર જે કેટલાક અને કોઈની વચ્ચે વૈકલ્પિક થાય છે
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // જો તે સમાન છે, Some(i32), બીજું કંઈ નહીં
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // આપણે જોઈ શકીએ છીએ કે આપણા ઇટરેટર આગળ અને પાછળ જતા રહે છે
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // જો કે, એકવાર આપણે તેને ફ્યૂઝ કરીશું ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // તે હંમેશાં પ્રથમ વખત પછી `None` પરત આવશે.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// મૂલ્યને આગળ વધારીને, ઇરેટરના દરેક તત્વ સાથે કંઈક કરે છે.
    ///
    /// ઇટરેટર્સનો ઉપયોગ કરતી વખતે, તમે ઘણીવાર તેમાંથી ઘણાને એક સાથે સાંકળ કરશો.
    /// આવા કોડ પર કામ કરતી વખતે, તમે પાઇપલાઇનના વિવિધ ભાગોમાં શું થઈ રહ્યું છે તે તપાસી શકો છો.તે કરવા માટે, `inspect()` પર ક callલ દાખલ કરો.
    ///
    /// તમારા અંતિમ કોડમાં હોવા કરતાં ડિબગીંગ ટૂલ તરીકે `inspect()` નો ઉપયોગ કરવો વધુ સામાન્ય છે, પરંતુ જ્યારે ભૂલોને કાedી નાખતા પહેલા લ loggedગ ઇન કરવાની જરૂર હોય ત્યારે એપ્લિકેશનોને તે ચોક્કસ પરિસ્થિતિઓમાં ઉપયોગી લાગે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // આ પુનરાવર્તક ક્રમ જટિલ છે.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ચાલો શું થઈ રહ્યું છે તેની તપાસ કરવા કેટલાક inspect() ક addલ્સ ઉમેરીએ
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// આ છાપશે:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ભૂલોને કા discી નાખતા પહેલા તેને લ Logગ ઇન કરો:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// આ છાપશે:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ઇટરેટર ઉધાર લેતા, તેનો વપરાશ કરતા કરતા.
    ///
    /// મૂળ પુનરાવર્તકની માલિકી હજી પણ જાળવી રાખતી વખતે પુનરાવર્તિત એડેપ્ટરો લાગુ કરવા માટે આ ઉપયોગી છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // જો આપણે ફરીથી તેનો ઉપયોગ કરવાનો પ્રયાસ કરીએ, તો તે કામ કરશે નહીં.
    /// // નીચેની લીટી "ભૂલ આપે છે: ખસેડવામાં આવેલા મૂલ્યનો ઉપયોગ: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ચાલો તે ફરીથી પ્રયાસ કરીએ
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // તેના બદલે, અમે એક .by_ref() માં ઉમેરીએ છીએ
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // હવે આ બરાબર છે:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// પુનરાવર્તકને સંગ્રહમાં પરિવર્તિત કરે છે.
    ///
    /// `collect()` પુનરાવર્તિત કંઈપણ લઈ શકે છે અને તેને સંબંધિત સંગ્રહમાં ફેરવી શકે છે.
    /// આ પ્રમાણભૂત પુસ્તકાલયની એક વધુ શક્તિશાળી પદ્ધતિ છે, જે વિવિધ સંદર્ભોમાં વપરાય છે.
    ///
    /// એક `collect()` નો ઉપયોગ થતો સૌથી મૂળભૂત પેટર્ન એ છે કે એક સંગ્રહને બીજામાં ફેરવો.
    /// તમે સંગ્રહ લો, તેના પર [`iter`] ક callલ કરો, રૂપાંતરનો સમૂહ કરો, અને પછી અંતમાં `collect()`.
    ///
    /// `collect()` એવા પ્રકારનાં ઉદાહરણો પણ બનાવી શકે છે જે લાક્ષણિક સંગ્રહ નથી.
    /// ઉદાહરણ તરીકે, એક [`String`] [`char`] s થી બનાવી શકાય છે, અને [`Result<T, E>`][`Result`] આઇટમ્સનો પુનરાવર્તક `Result<Collection<T>, E>` માં એકત્રિત કરી શકાય છે.
    ///
    /// વધુ માટે નીચેનાં ઉદાહરણો જુઓ.
    ///
    /// કારણ કે `collect()` એટલું સામાન્ય છે, તે પ્રકાર અનુમાન સાથે સમસ્યા causeભી કરી શકે છે.
    /// જેમ કે, `collect()` એ થોડી વારમાંનું એક છે જ્યારે તમે સિંટેક્સને પ્રેમથી 'turbofish' તરીકે ઓળખાય છે: `::<>`.
    /// આ અનુમાન એલ્ગોરિધમને ખાસ કરીને તે સમજવામાં સહાય કરે છે કે તમે કયા સંગ્રહમાં સંગ્રહ કરવાનો પ્રયાસ કરી રહ્યાં છો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// નોંધ લો કે અમને ડાબી બાજુએ `: Vec<i32>` ની જરૂર હતી.આ એટલા માટે છે કારણ કે આપણે તેના બદલે, એક [`VecDeque<T>`] માં એકત્રિત કરી શકીએ:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` ને ટિપ્પણી કરવાને બદલે 'turbofish' નો ઉપયોગ કરો:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// કારણ કે `collect()` ફક્ત તમે જ એકત્રિત કરી રહ્યાં છો તેની કાળજી રાખે છે, તો પણ તમે ટર્બોફિશ સાથે આંશિક પ્રકારનો સંકેત, `_` નો ઉપયોગ કરી શકો છો:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] બનાવવા માટે `collect()` નો ઉપયોગ:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// જો તમારી પાસે [`પરિણામની સૂચિ છે<T, E>`][`પરિણામ`], તમે તેમાંથી કોઈપણ નિષ્ફળ થયું છે તે જોવા માટે તમે `collect()` નો ઉપયોગ કરી શકો છો:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // આપણને પ્રથમ ભૂલ આપે છે
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // અમને જવાબોની સૂચિ આપે છે
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// પુનરાવર્તક લે છે, તેમાંથી બે સંગ્રહ બનાવે છે.
    ///
    /// `partition()` પર પસાર કરાયેલ પ્રિડિકેટ `true` અથવા `false` પાછા આપી શકે છે.
    /// `partition()` એક જોડી આપે છે, તે બધા તત્વો કે જેના માટે તે `true` પરત આપે છે, અને તે બધા તત્વો કે જેના માટે તે `false` પરત આપે છે.
    ///
    ///
    /// [`is_partitioned()`] અને [`partition_in_place()`] પણ જુઓ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// આ પુનરાવર્તકના તત્વોને *ઇન-પ્લેસ* આપેલ પૂર્વધારણા અનુસાર ફરીથી ગોઠવે છે, જેમ કે `true` પાછા આપનારા બધા `false` પરત ફરતા બધા પહેલાંના છે.
    ///
    /// મળેલા `true` તત્વોની સંખ્યા પરત કરે છે.
    ///
    /// પાર્ટીશન કરેલી વસ્તુઓનો સંબંધિત ક્રમ જાળવવામાં આવતો નથી.
    ///
    /// [`is_partitioned()`] અને [`partition()`] પણ જુઓ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // સાંજ અને અવરોધો વચ્ચેની જગ્યાએ પાર્ટીશન
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: શું આપણે કાઉન્ટ ઓવરફ્લો થવાની ચિંતા કરવી જોઈએ?કરતા વધારેનો એકમાત્ર રસ્તો
        // `usize::MAX` પરિવર્તનશીલ સંદર્ભો ઝેડએસટી સાથે છે, જે પાર્ટીશન માટે ઉપયોગી નથી ...

        // `Self` માં ઉદારતા ટાળવા માટે આ બંધ "factory" કાર્યો અસ્તિત્વમાં છે.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // વારંવાર પ્રથમ `false` શોધો અને તેને છેલ્લા `true` સાથે અદલાબદલ કરો.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// આ પુનરાવર્તકનાં તત્વો આપેલ પૂર્વધારણા અનુસાર પાર્ટીશન થયેલ છે કે કેમ તે ચકાસે છે, જેમ કે `true` પાછા આપનારા બધા `false` પરત ફરતા બધા પહેલાંના છે.
    ///
    ///
    /// [`partition()`] અને [`partition_in_place()`] પણ જુઓ.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // કાં બધી વસ્તુઓ `true` નું પરીક્ષણ કરે છે, અથવા પ્રથમ કલમ `false` પર અટકે છે અને અમે તપાસ કરીએ છીએ કે તેના પછી હવે કોઈ `true` આઇટમ્સ નથી.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// એક પુનરાવર્તક પદ્ધતિ જે એક કાર્ય, જ્યાં સુધી તે સફળતાપૂર્વક પરત આવે છે ત્યાં સુધી લાગુ કરે છે, એકલ, અંતિમ મૂલ્ય ઉત્પન્ન કરે છે.
    ///
    /// `try_fold()` બે દલીલો લે છે: પ્રારંભિક મૂલ્ય, અને બે દલીલો સાથે બંધ: એક 'accumulator', અને એક તત્વ.
    /// બંધ પછી કાં તો સફળતાપૂર્વક પાછો આવે છે, આગળના પુનરાવર્તનો માટે સંચયકર્તા પાસેના મૂલ્ય સાથે અથવા તે નિષ્ફળતાને પાછો આપે છે, એક ભૂલ મૂલ્ય સાથે, જે ક theલરને તરત જ (short-circuiting) પર પાછા ફેલાવવામાં આવે છે.
    ///
    ///
    /// પ્રારંભિક મૂલ્ય એ મૂલ્ય છે જે પ્રથમ કulatorલમાં સંચયકર્તાનું હશે.જો ક્લોઝરને લાગુ કરવાથી પુનરાવર્તકનાં દરેક તત્વ સામે સફળ થાય છે, તો `try_fold()` અંતિમ સંચયકને સફળતા તરીકે પાછું આપે છે.
    ///
    /// જ્યારે પણ તમારી પાસે કોઈ વસ્તુનો સંગ્રહ હોય ત્યારે ફોલ્ડિંગ ઉપયોગી છે, અને તેમાંથી એક જ મૂલ્ય ઉત્પન્ન કરવા માંગો છો.
    ///
    /// # અમલકર્તાઓને નોંધ
    ///
    /// અન્ય ઘણી (forward) પદ્ધતિઓમાં આના સંદર્ભમાં ડિફોલ્ટ અમલીકરણો છે, તેથી જો તે ડિફ Xલ્ટ `for` લૂપ અમલીકરણ કરતાં કંઈક સારું કરી શકે તો સ્પષ્ટ રૂપે આનો અમલ કરવાનો પ્રયાસ કરો.
    ///
    /// ખાસ કરીને, આંતરિક ભાગો પર આ ક callલ `try_fold()` કરવાનો પ્રયત્ન કરો કે જ્યાંથી આ પુનરાવર્તક બનેલું છે.
    /// જો બહુવિધ ક callsલ્સની જરૂર હોય, તો `?` operatorપરેટર સંચયક મૂલ્યની સાંકળ માટે અનુકૂળ હોઈ શકે છે, પરંતુ પ્રારંભિક વળતર પહેલાં કોઈપણ આક્રમણકારોને સમર્થન આપવું જરૂરી છે.
    /// આ એક `&mut self` પદ્ધતિ છે, તેથી અહીં ભૂલને ફટકાર્યા પછી પુનરાવૃત્તિને ફરીથી શરૂ કરવાની જરૂર છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // એરેના બધા તત્વોની તપાસિત રકમ
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 ઘટક ઉમેરતી વખતે આ રકમ ઓવરફ્લો થાય છે
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // કારણ કે તે ટૂંકા રૂપાંતરિત છે, બાકીના તત્વો હજી પણ પુનરાવર્તક દ્વારા ઉપલબ્ધ છે.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// એક પુનરાવર્તક પદ્ધતિ કે જે પુનરાવર્તકની દરેક આઇટમ પર ફાલિબલ ફંક્શન લાગુ કરે છે, તે પ્રથમ ભૂલ પર રોકાય છે અને તે ભૂલ પાછો આપે છે.
    ///
    ///
    /// આને [`for_each()`] ના પડતા સ્વરૂપ તરીકે અથવા [`try_fold()`] ના સ્ટેટલેસ સંસ્કરણ તરીકે પણ વિચારી શકાય છે.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // તે ટૂંકા રૂપાંતરિત છે, તેથી બાકીની આઇટમ્સ હજી પણ પુનરાવર્તકમાં છે:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Applyingપરેશન લાગુ કરીને, અંતિમ પરિણામ પરત કરીને, દરેક તત્વને એક સંચયકમાં ફોલ્ડ કરે છે.
    ///
    /// `fold()` બે દલીલો લે છે: પ્રારંભિક મૂલ્ય, અને બે દલીલો સાથે બંધ: એક 'accumulator', અને એક તત્વ.
    /// બંધ થવું તે મૂલ્ય પાછું આપે છે જે સંચયકર્તાને આગામી પુનરાવૃત્તિ માટે હોવું જોઈએ.
    ///
    /// પ્રારંભિક મૂલ્ય એ મૂલ્ય છે જે પ્રથમ કulatorલમાં સંચયકર્તાનું હશે.
    ///
    /// આ ક્લોઝરને ઇટરેટરના દરેક તત્વ પર લાગુ કર્યા પછી, `fold()` સંચયકર્તાને પરત કરે છે.
    ///
    /// આ કામગીરીને કેટલીકવાર 'reduce' અથવા 'inject' કહેવામાં આવે છે.
    ///
    /// જ્યારે પણ તમારી પાસે કોઈ વસ્તુનો સંગ્રહ હોય ત્યારે ફોલ્ડિંગ ઉપયોગી છે, અને તેમાંથી એક જ મૂલ્ય ઉત્પન્ન કરવા માંગો છો.
    ///
    /// Note: `fold()`, અને સમાન પદ્ધતિઓ કે જે સંપૂર્ણ પુનરાવર્તકને પસાર કરે છે, અનંત પુનરાવર્તકો માટે સમાપ્ત કરી શકશે નહીં, ઝેડટ્રેટ 0 ઝેડ પર પણ જેના માટે પરિણામ મર્યાદિત સમયમાં નિર્ધારનીય છે.
    ///
    /// Note: પ્રારંભિક મૂલ્ય તરીકે પ્રથમ તત્વનો ઉપયોગ કરવા માટે [`reduce()`] નો ઉપયોગ કરી શકાય છે, જો સંચયકર્તા પ્રકાર અને આઇટમ પ્રકાર સમાન હોય તો.
    ///
    /// # અમલકર્તાઓને નોંધ
    ///
    /// અન્ય ઘણી (forward) પદ્ધતિઓમાં આના સંદર્ભમાં ડિફોલ્ટ અમલીકરણો છે, તેથી જો તે ડિફ Xલ્ટ `for` લૂપ અમલીકરણ કરતાં કંઈક સારું કરી શકે તો સ્પષ્ટ રૂપે આનો અમલ કરવાનો પ્રયાસ કરો.
    ///
    ///
    /// ખાસ કરીને, આંતરિક ભાગો પર આ ક callલ `fold()` કરવાનો પ્રયત્ન કરો કે જ્યાંથી આ પુનરાવર્તક બનેલું છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // એરેના બધા તત્વોનો સરવાળો
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ચાલો અહીં પુનરાવર્તનના દરેક પગલાથી ચાલીએ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// અને તેથી, અમારું અંતિમ પરિણામ, `6`.
    ///
    /// તે લોકો માટે સામાન્ય છે કે જેમણે પરિણામ બનાવવા માટે વસ્તુઓની સૂચિ સાથે `for` લૂપનો ઉપયોગ કરવા માટે ઇટરેટર્સનો વધુ ઉપયોગ કર્યો નથી.તેને `fold()`s માં ફેરવી શકાય છે:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // લૂપ માટે:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // તેઓ સમાન છે
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// વારંવાર ઘટાડવાની કામગીરી લાગુ કરીને, તત્વોને એકમાં ઘટાડે છે.
    ///
    /// જો ઇરેટર ખાલી છે, તો [`None`] આપે છે;નહિંતર, ઘટાડો પરિણામ આપે છે.
    ///
    /// ઓછામાં ઓછા એક તત્વવાળા પુનરાવર્તકો માટે, આ પ્રારંભિક મૂલ્ય જેટલા પુનરાવર્તકના પ્રથમ તત્વ સાથેના [`fold()`] જેટલું જ છે, તેમાં દરેક અનુગામી તત્વને ફોલ્ડ કરવું.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// મહત્તમ મૂલ્ય શોધો:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// પરીક્ષણો જો પુનરાવર્તકનું દરેક તત્વ કોઈ અનુમાન સાથે મેળ ખાય છે.
    ///
    /// `all()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.તે આ બંધને ઇરેટરના દરેક તત્વ પર લાગુ કરે છે, અને જો તે બધા `true` પરત કરે છે, તો પછી `all()` પણ કરે છે.
    /// જો તેમાંના કોઈપણ `false` પરત કરે છે, તો તે `false` પરત કરે છે.
    ///
    /// `all()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, `false` મળતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે, જો કે બીજું શું થાય છે, પરિણામ પણ `false` હશે.
    ///
    ///
    /// ખાલી પુનરાવર્તિત કરનાર `true` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// પ્રથમ `false` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// પરીક્ષણો જો પુનરાવર્તકનું કોઈપણ તત્વ કોઈ પૂર્વશાસ્ત્ર સાથે મેળ ખાય છે.
    ///
    /// `any()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.તે આ ક્લોઝરને ઇટરેટરના દરેક તત્વ પર લાગુ કરે છે, અને જો તેમાંના કોઈપણ `true` પરત કરે છે, તો પછી `any()` પણ કરે છે.
    /// જો તે બધા `false` પાછા આપે છે, તો તે `false` પરત આપે છે.
    ///
    /// `any()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, `true` મળતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે, જો કે બીજું શું થાય છે, પરિણામ પણ `true` હશે.
    ///
    ///
    /// ખાલી પુનરાવર્તિત કરનાર `false` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// પ્રથમ `true` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// પુનરાવર્તકના તત્વની શોધ કરે છે જે કોઈ શિકારીને સંતુષ્ટ કરે છે.
    ///
    /// `find()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.
    /// તે આ ક્લોઝરને ઇટરેટરના દરેક તત્વ પર લાગુ કરે છે, અને જો તેમાંના કોઈપણ `true` પરત કરે છે, તો પછી `find()` [`Some(element)`] પરત કરે છે.
    /// જો તે બધા `false` પાછા આપે છે, તો તે [`None`] પરત આપે છે.
    ///
    /// `find()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, ક્લોઝર `true` પરત આપતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે.
    ///
    /// કારણ કે `find()` સંદર્ભ લે છે, અને ઘણાં પુનરાવર્તકો સંદર્ભો દ્વારા પુનરાવર્તિત થાય છે, આ સંભવિત મૂંઝવણભર્યા પરિસ્થિતિ તરફ દોરી જાય છે જ્યાં દલીલ ડબલ સંદર્ભ છે.
    ///
    /// તમે `&&x` સાથે, નીચેના ઉદાહરણોમાં આ અસર જોઈ શકો છો.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// પ્રથમ `true` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// નોંધ લો કે `iter.find(f)` એ `iter.filter(f).next()` ની સમકક્ષ છે.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// પુનરાવર્તકના તત્વોને ફંક્શન લાગુ પડે છે અને પ્રથમ ન noneન-પરિણામ નહીં આપે.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` ની બરાબર છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// પુનરાવર્તકના તત્વોને કાર્ય લાગુ કરે છે અને પ્રથમ સાચું પરિણામ અથવા પ્રથમ ભૂલ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// પુનરાવર્તકના તત્વની શોધ કરે છે, તેનું અનુક્રમણિકા પાછું આપે છે.
    ///
    /// `position()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.
    /// તે આ ક્લોઝરને ઇરેટરના દરેક તત્વ પર લાગુ કરે છે, અને જો તેમાંથી કોઈ એક `true` આપે છે, તો પછી `position()` [`Some(index)`] આપે છે.
    /// જો તે બધા `false` પરત કરે છે, તો તે [`None`] આપે છે.
    ///
    /// `position()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, તે `true` મળતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે.
    ///
    /// # ઓવરફ્લો વર્તન
    ///
    /// પદ્ધતિ ઓવરફ્લો સામે કોઈ રક્ષણ આપતી નથી, તેથી જો ત્યાં [`usize::MAX`] કરતા વધુ ન મળતા તત્વો હોય, તો તે કાં તો ખોટું પરિણામ અથવા ઝેડ 0 સ્પેનિક્સ0 ઝેડ ઉત્પન્ન કરે છે.
    ///
    /// જો ડિબગ નિવેદનોને સક્ષમ કરવામાં આવે છે, તો ઝેડપૈનિક 0 ઝેડની ખાતરી આપવામાં આવે છે.
    ///
    /// # Panics
    ///
    /// જો ઇટરેટરમાં `usize::MAX` કરતા વધુ બિન-મેળ ખાતા તત્વો હોય તો આ ફંક્શન panic શકે છે.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// પ્રથમ `true` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // પરત કરેલ અનુક્રમણિકા પુનરાવર્તિત સ્થિતિ પર આધારિત છે
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// જમણેથી ઇરેટરમાં તત્વની શોધ કરે છે, તેનું અનુક્રમણિકા પાછું આપે છે.
    ///
    /// `rposition()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.
    /// તે આ અંતને ઇટરેટરના દરેક તત્વ પર લાગુ કરે છે, અંતથી શરૂ કરીને, અને જો તેમાંથી કોઈ `true` આપે છે, તો `rposition()` [`Some(index)`] પરત કરે છે.
    ///
    /// જો તે બધા `false` પરત કરે છે, તો તે [`None`] આપે છે.
    ///
    /// `rposition()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, તે `true` મળતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// પ્રથમ `true` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // અહીં ઓવરફ્લો તપાસવાની જરૂર નથી, કારણ કે `ExactSizeIterator` સૂચવે છે કે તત્વોની સંખ્યા `usize` માં બંધબેસે છે.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ઇરેટરનો મહત્તમ તત્વ પરત કરે છે.
    ///
    /// જો ઘણા તત્વો સમાનરૂપે મહત્તમ હોય, તો છેલ્લું તત્વ પરત કરવામાં આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ઇરેટરનું ન્યૂનતમ તત્વ પરત કરે છે.
    ///
    /// જો ઘણા તત્વો સમાન ન્યુનત્તમ હોય, તો પ્રથમ તત્વ પરત આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// તે ઘટક પરત કરે છે જે ઉલ્લેખિત કાર્યથી મહત્તમ મૂલ્ય આપે છે.
    ///
    ///
    /// જો ઘણા તત્વો સમાનરૂપે મહત્તમ હોય, તો છેલ્લું તત્વ પરત કરવામાં આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ઉલ્લેખિત તુલના કાર્યને ધ્યાનમાં રાખીને મહત્તમ મૂલ્ય આપતું તત્વ પરત કરે છે.
    ///
    ///
    /// જો ઘણા તત્વો સમાનરૂપે મહત્તમ હોય, તો છેલ્લું તત્વ પરત કરવામાં આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// તે ઘટક પરત કરે છે જે નિર્ધારિત કાર્યમાંથી ન્યૂનતમ મૂલ્ય આપે છે.
    ///
    ///
    /// જો ઘણા તત્વો સમાન ન્યુનત્તમ હોય, તો પ્રથમ તત્વ પરત આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ઉલ્લેખિત તુલના કાર્યને ધ્યાનમાં રાખીને ન્યુનત્તમ મૂલ્ય આપતું તત્વ પરત કરે છે.
    ///
    ///
    /// જો ઘણા તત્વો સમાન ન્યુનત્તમ હોય, તો પ્રથમ તત્વ પરત આવે છે.
    /// જો ઇરેટર ખાલી હોય, તો [`None`] પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// પુનરાવર્તકની દિશાને વિરુદ્ધ કરે છે.
    ///
    /// સામાન્ય રીતે, ઇટરેટર્સ ડાબેથી જમણે પુનરાવર્તિત થાય છે.
    /// `rev()` નો ઉપયોગ કર્યા પછી, એક પુનરાવર્તક તેની જગ્યાએ જમણેથી ડાબેથી પુનરાવર્તિત થશે.
    ///
    /// આ ફક્ત ત્યારે જ શક્ય છે જો ઇરેટરનો અંત હોય, તેથી `rev()` ફક્ત [`DoubleEidedIterator`] s પર કાર્ય કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// જોડીના પુનરાવર્તકને કન્ટેનરની જોડીમાં ફેરવે છે.
    ///
    /// `unzip()` જોડીના સંપૂર્ણ ઇરેટરનો વપરાશ કરે છે, બે સંગ્રહ ઉત્પન્ન કરે છે: એક જોડીના ડાબા તત્વોમાંથી અને એક જમણા તત્વોમાંથી.
    ///
    ///
    /// આ કાર્ય, અમુક અર્થમાં, [`zip`] ની વિરુદ્ધ છે.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// એક ઇરેટર બનાવે છે જે તેના તમામ ઘટકોની નકલ કરે છે.
    ///
    /// જ્યારે તમારી પાસે `&T` ઉપર ઇરેટર હોય, ત્યારે આ ઉપયોગી છે, પરંતુ તમારે `T` કરતા વધારે ઇરેટરની જરૂર છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // કiedપિ કરેલું એ .map(|&x| x) જેવું જ છે
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// એક ઇરેટર બનાવે છે જે [`ક્લોન`] તેના બધા તત્વો છે.
    ///
    /// જ્યારે તમારી પાસે `&T` ઉપર ઇરેટર હોય, ત્યારે આ ઉપયોગી છે, પરંતુ તમારે `T` કરતા વધારે ઇરેટરની જરૂર છે.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // પૂર્ણાંકો માટે ક્લોન થયેલ, .map(|&x| x) જેટલું જ છે
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// પુનરાવર્તિત અનંતપણે પુનરાવર્તિત.
    ///
    /// [`None`] પર રોકવાને બદલે, પુનરાવર્તક તેના બદલે ફરી શરૂઆત કરશે.ફરીથી પુનરાવર્તન કર્યા પછી, તે ફરી શરૂઆતમાં શરૂ થશે.અને ફરીથી.
    /// અને ફરીથી.
    /// Forever.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// ઇરેટરના તત્વોનો સરવાળો.
    ///
    /// દરેક તત્વ લે છે, તેમને એકસાથે ઉમેરે છે, અને પરિણામ આપે છે.
    ///
    /// ખાલી પુનરાવર્તક એ પ્રકારનું શૂન્ય મૂલ્ય આપે છે.
    ///
    /// # Panics
    ///
    /// જ્યારે `sum()` ને ક callingલ કરો અને આદિમ પૂર્ણાંકો પ્રકાર પરત કરવામાં આવે ત્યારે, જો ગણતરી ઓવરફ્લો અને ડિબગ નિવેશને સક્ષમ કરવામાં આવે તો આ પદ્ધતિ panic કરશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// બધા તત્વો ગુણાકાર, સમગ્ર પુનરાવર્તક પર ફેરવે છે
    ///
    /// ખાલી પુનરાવર્તક એ પ્રકારનું એક મૂલ્ય આપે છે.
    ///
    /// # Panics
    ///
    /// જ્યારે `product()` ને ક callingલ કરો અને પ્રાચીન પૂર્ણાંક પ્રકાર પરત કરવામાં આવે છે, ત્યારે ગણતરી ઓવરફ્લો અને ડિબગ નિવેશને સક્ષમ કરવામાં આવે છે, તો પદ્ધતિ panic કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) આ [`Iterator`] ના તત્વોની તુલના બીજા લોકો સાથે કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) આ [`Iterator`] ના તત્વોની ઉલ્લેખિત તુલના કાર્યને ધ્યાનમાં રાખીને અન્ય સાથે સરખાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) આ [`Iterator`] ના તત્વોની તુલના બીજા લોકો સાથે કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) આ [`Iterator`] ના તત્વોની ઉલ્લેખિત તુલના કાર્યને ધ્યાનમાં રાખીને અન્ય સાથે સરખાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો બીજાના સમાન છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// નિર્ધારિત કરે છે કે શું આ [`Iterator`] ના તત્વો સ્પષ્ટ સમાનતા કાર્યને ધ્યાનમાં રાખીને બીજાના સમાન છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો અન્ય લોકો સાથે અસમાન છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો અન્ય કરતા [lexicographically](Ord#lexicographical-comparison) ઓછા છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો [lexicographically](Ord#lexicographical-comparison) ઓછા અથવા બીજાના સમાન છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો અન્ય કરતા [lexicographically](Ord#lexicographical-comparison) વધારે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// નક્કી કરે છે કે શું આ [`Iterator`] ના તત્વો [lexicographically](Ord#lexicographical-comparison) કરતા વધારે છે અથવા બીજાની સમાન છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// જો આ પુનરાવર્તકના ઘટકો ગોઠવવામાં આવે છે કે કેમ તે તપાસે છે.
    ///
    /// તે છે, દરેક તત્વ `a` અને તેના નીચેના તત્વ `b` માટે, `a <= b` હોવું આવશ્યક છે.જો ઇટરેટર બરાબર શૂન્ય અથવા એક તત્વ આપે છે, તો `true` પરત આવે છે.
    ///
    /// નોંધ લો કે જો `Self::Item` એ ફક્ત `PartialOrd` છે, પરંતુ `Ord` નથી, તો ઉપરોક્ત વ્યાખ્યા સૂચવે છે કે જો કોઈ પણ સતત બે વસ્તુઓ તુલનાત્મક ન હોય તો આ ફંક્શન `false` આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// આપેલ કમ્પેરેટર ફંક્શનનો ઉપયોગ કરીને આ ઇટરેટરના તત્વોને સortedર્ટ કરવામાં આવ્યા છે કે કેમ તે તપાસો.
    ///
    /// `PartialOrd::partial_cmp` નો ઉપયોગ કરવાને બદલે, બે તત્વોનો ક્રમ નક્કી કરવા માટે આ કાર્ય આપેલ `compare` ફંક્શનનો ઉપયોગ કરે છે.
    /// તે સિવાય, તે [`is_sorted`] ની બરાબર છે;વધુ માહિતી માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// આપેલ કી નિષ્કર્ષણ વિધેયનો ઉપયોગ કરીને આ પુનરાવર્તકના ઘટકો ગોઠવવામાં આવ્યા છે કે કેમ તે તપાસો.
    ///
    /// ઇરેટરના તત્વોની સીધી સરખામણી કરવાને બદલે, આ ફંક્શન, તત્વોની કીઓની તુલના કરે છે, જે `f` દ્વારા નિર્ધારિત છે.
    /// તે સિવાય, તે [`is_sorted`] ની બરાબર છે;વધુ માહિતી માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] જુઓ
    // અસામાન્ય નામ એ છે કે મેથડ રિઝોલ્યુશનમાં નામની ટકરાણોને ટાળવું એ #76479 જુઓ.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}