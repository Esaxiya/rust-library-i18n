use crate::ops::{ControlFlow, Try};

/// એક પુનરાવર્તક બંને છેડેથી તત્વો પેદા કરવા માટે સક્ષમ.
///
/// જે કંઈક `DoubleEndedIterator` ને અમલમાં મૂકે છે તેની પાસે એક [`Iterator`] ને લાગુ કરવાની એક વધારાની ક્ષમતા હોય છે: પાછળથી `આઇટમ` લેવાની ક્ષમતા, તેમજ આગળની બાજુ.
///
///
/// એ નોંધવું અગત્યનું છે કે આગળ અને પાછળ બંને સમાન શ્રેણી પર કામ કરે છે, અને તે ક્રોસ કરતા નથી: જ્યારે તેઓ મધ્યમાં મળે ત્યારે પુનરાવર્તન સમાપ્ત થાય છે.
///
/// [`Iterator`] પ્રોટોકોલ જેવી જ ફેશનમાં, એકવાર `DoubleEndedIterator`, [`next_back()`] માંથી [`None`] પાછો ફરે છે, તેને ફરીથી ક callingલ કરીને [`Some`] ફરીથી પાછો આપી શકે છે અથવા નહીં કરે છે.
/// [`next()`] અને [`next_back()`] આ હેતુ માટે વિનિમયક્ષમ છે.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// પુનરાવર્તકના અંતથી કોઈ તત્વ દૂર કરે છે અને આપે છે.
    ///
    /// જ્યારે કોઈ વધુ તત્વો ન હોય ત્યારે `None` પરત કરે છે.
    ///
    /// [trait-level] ડsક્સમાં વધુ વિગતો શામેલ છે.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEenderIteratorI ની પદ્ધતિઓ દ્વારા પ્રાપ્ત તત્વો [` Iterator`] ની પદ્ધતિઓ દ્વારા મેળવવામાં આવતા ઘટકોથી ભિન્ન હોઈ શકે છે:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` તત્વો દ્વારા પાછળથી ઇરેટરને આગળ વધારશે.
    ///
    /// `advance_back_by` [`advance_by`] નું વિપરીત સંસ્કરણ છે.[`None`] નો સામનો ન થાય ત્યાં સુધી આ પદ્ધતિ [`next_back`] સુધી [`next_back`] સુધી ક callingલ કરીને પાછળથી શરૂ થતા `n` તત્વોને આતુરતાથી છોડી દેશે.
    ///
    /// `advance_back_by(n)` જો ઇરેટર `n` તત્વો દ્વારા સફળતાપૂર્વક આગળ વધે છે, અથવા જો [`None`] નો સામનો કરવો પડે તો [`Err(k)`],[`Ok(())`] પરત આપશે, જ્યાં `k` એ તત્વોની સંખ્યા છે જે તત્વોની બહાર ચાલતા પહેલા ઇરેટર દ્વારા આગળ વધવામાં આવે છે (દા.ત.
    /// પુનરાવર્તકની લંબાઈ).
    /// નોંધ લો કે `k` હંમેશાં `n` કરતા ઓછું હોય છે.
    ///
    /// ક0લ કરો X01 એક્સ એ કોઈપણ તત્વોનો વપરાશ કરતો નથી અને હંમેશાં [`Ok(())`] આપે છે.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ફક્ત `&3` અવગણવામાં આવ્યું હતું
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// પુનરાવર્તકના અંતથી `n` મી તત્વ પરત કરે છે.
    ///
    /// આ અનિવાર્યપણે [`Iterator::nth()`] નું ઉલટું સંસ્કરણ છે.
    /// જોકે મોટાભાગના અનુક્રમણિકાત્મક કામગીરીની જેમ, ગણતરી શૂન્યથી શરૂ થાય છે, તેથી `nth_back(0)` અંતથી પ્રથમ મૂલ્ય, `nth_back(1)` બીજું, અને તેથી વધુ આપે છે.
    ///
    ///
    /// નોંધ લો કે પાછલા ઘટક સહિત અંત અને પાછા ફરતા તત્વ વચ્ચેના બધા તત્વોનો વપરાશ કરવામાં આવશે.
    /// આનો અર્થ એ પણ છે કે એક જ પુનરાવર્તક પર `nth_back(0)` ને ઘણી વખત ક callingલ કરવાથી વિવિધ તત્વો પાછા આવશે.
    ///
    /// `nth_back()` જો X01 એક્સ પુનરાવર્તકની લંબાઈ કરતા વધારે અથવા તેના બરાબર હોય તો [`None`] પરત કરશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// બહુવિધ વખત `nth_back()` ક Callલ કરવાથી પુનરાવર્તક ફરી વળતું નથી:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// જો `n + 1` કરતા ઓછા તત્વો હોય તો `None` પરત આપવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// આ [`Iterator::try_fold()`] નું વિપરીત સંસ્કરણ છે: તે ઇરેટરની પાછળથી શરૂ થતા તત્વો લે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // કારણ કે તે ટૂંકા રૂપાંતરિત છે, બાકીના તત્વો હજી પણ પુનરાવર્તક દ્વારા ઉપલબ્ધ છે.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// એક પુનરાવર્તક પદ્ધતિ જે પાછલા ભાગથી શરૂ કરીને, પુનરાવર્તક તત્વોને એકલ, અંતિમ મૂલ્યમાં ઘટાડે છે.
    ///
    /// આ [`Iterator::fold()`] નું વિપરીત સંસ્કરણ છે: તે ઇરેટરની પાછળથી શરૂ થતા તત્વો લે છે.
    ///
    /// `rfold()` બે દલીલો લે છે: પ્રારંભિક મૂલ્ય, અને બે દલીલો સાથે બંધ: એક 'accumulator', અને એક તત્વ.
    /// બંધ થવું તે મૂલ્ય પાછું આપે છે જે સંચયકર્તાને આગામી પુનરાવૃત્તિ માટે હોવું જોઈએ.
    ///
    /// પ્રારંભિક મૂલ્ય એ મૂલ્ય છે જે પ્રથમ કulatorલમાં સંચયકર્તાનું હશે.
    ///
    /// આ ક્લોઝરને ઇટરેટરના દરેક તત્વ પર લાગુ કર્યા પછી, `rfold()` સંચયકર્તાને પરત કરે છે.
    ///
    /// આ કામગીરીને કેટલીકવાર 'reduce' અથવા 'inject' કહેવામાં આવે છે.
    ///
    /// જ્યારે પણ તમારી પાસે કોઈ વસ્તુનો સંગ્રહ હોય ત્યારે ફોલ્ડિંગ ઉપયોગી છે, અને તેમાંથી એક જ મૂલ્ય ઉત્પન્ન કરવા માંગો છો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // તમામ તત્વોનો સરવાળો
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// આ ઉદાહરણ સ્ટ્રિંગ બનાવે છે, પ્રારંભિક મૂલ્યથી પ્રારંભ કરીને અને પાછળથી આગળ સુધી દરેક તત્વ સાથે ચાલુ રાખીને:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// પાછળના ભાગમાંથી ઇરેટરના તત્વની શોધ કરે છે જે કોઈ શિકારીને સંતુષ્ટ કરે છે.
    ///
    /// `rfind()` `true` અથવા `false` પરત કરે છે તે બંધ લે છે.
    /// તે આ ક્લોઝરને અંતથી શરૂ કરીને, ઇરેટરના દરેક તત્વ પર લાગુ કરે છે, અને જો તેમાંના કોઈપણ `true` પાછા આપે છે, તો `rfind()` [`Some(element)`] આપે છે.
    /// જો તે બધા `false` પાછા આપે છે, તો તે [`None`] પરત આપે છે.
    ///
    /// `rfind()` ટૂંકા પરિભ્રમણ છે;બીજા શબ્દોમાં કહીએ તો, ક્લોઝર `true` પરત આપતાંની સાથે જ તે પ્રક્રિયા કરવાનું બંધ કરશે.
    ///
    /// કારણ કે `rfind()` સંદર્ભ લે છે, અને ઘણાં પુનરાવર્તકો સંદર્ભો દ્વારા પુનરાવર્તિત થાય છે, આ સંભવિત મૂંઝવણભર્યા પરિસ્થિતિ તરફ દોરી જાય છે જ્યાં દલીલ ડબલ સંદર્ભ છે.
    ///
    /// તમે `&&x` સાથે, નીચેના ઉદાહરણોમાં આ અસર જોઈ શકો છો.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// પ્રથમ `true` પર રોકાવું:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // અમે હજી પણ `iter` નો ઉપયોગ કરી શકીએ છીએ, કારણ કે ત્યાં વધુ તત્વો છે.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}