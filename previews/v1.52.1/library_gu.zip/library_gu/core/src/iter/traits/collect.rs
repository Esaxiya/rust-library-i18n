/// [`Iterator`] થી રૂપાંતર.
///
/// એક પ્રકાર માટે `FromIterator` લાગુ કરીને, તમે વ્યાખ્યાયિત કરો છો કે તે ઇટરેટરમાંથી કેવી રીતે બનાવવામાં આવશે.
/// આ તે પ્રકારો માટે સામાન્ય છે જે કોઈ પ્રકારનાં સંગ્રહનું વર્ણન કરે છે.
///
/// [`FromIterator::from_iter()`] ભાગ્યે જ સ્પષ્ટ રીતે કહેવામાં આવે છે, અને તેનો ઉપયોગ [`Iterator::collect()`] પદ્ધતિ દ્વારા થાય છે.
///
/// વધુ ઉદાહરણો માટે [`Iterator::collect()`]'s દસ્તાવેજીકરણ જુઓ.
///
/// આ પણ જુઓ: [`IntoIterator`].
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// સ્પષ્ટપણે `FromIterator` નો ઉપયોગ કરવા માટે [`Iterator::collect()`] નો ઉપયોગ:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// તમારા પ્રકાર માટે `FromIterator` અમલમાં મૂકવું:
///
/// ```
/// use std::iter::FromIterator;
///
/// // એક નમૂના સંગ્રહ, તે ફક્ત વી.સી. ઉપર એક આવરણ છે<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ચાલો તેને કેટલીક પદ્ધતિઓ આપીએ જેથી આપણે એક બનાવી શકીએ અને તેમાં વસ્તુઓ ઉમેરી શકીએ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // અને અમે ફ્રોઇટેરેટરનો અમલ કરીશું
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // હવે આપણે નવું પુનરાવર્તિત કરી શકીએ છીએ ...
/// let iter = (0..5).into_iter();
///
/// // ... અને તેમાંથી માય કલેક્શન બનાવો
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // કામ પણ એકત્રિત!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ઇરેટરથી મૂલ્ય બનાવે છે.
    ///
    /// વધુ માટે [module-level documentation] જુઓ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// એક [`Iterator`] માં રૂપાંતર.
///
/// એક પ્રકાર માટે `IntoIterator` અમલમાં મૂકીને, તમે વ્યાખ્યાયિત કરો છો કે તે ઇટિરેટરમાં કેવી રીતે રૂપાંતરિત થશે.
/// આ તે પ્રકારો માટે સામાન્ય છે જે કોઈ પ્રકારનાં સંગ્રહનું વર્ણન કરે છે.
///
/// `IntoIterator` અમલમાં લાવવાનો એક ફાયદો એ છે કે તમારો પ્રકાર [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) થશે.
///
///
/// આ પણ જુઓ: [`FromIterator`].
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// તમારા પ્રકાર માટે `IntoIterator` અમલમાં મૂકવું:
///
/// ```
/// // એક નમૂના સંગ્રહ, તે ફક્ત વી.સી. ઉપર એક આવરણ છે<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ચાલો તેને કેટલીક પદ્ધતિઓ આપીએ જેથી આપણે એક બનાવી શકીએ અને તેમાં વસ્તુઓ ઉમેરી શકીએ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // અને અમે ઇન્ટિએટરેટરનો અમલ કરીશું
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // હવે અમે એક નવું સંગ્રહ કરી શકીએ છીએ ...
/// let mut c = MyCollection::new();
///
/// // ... તેમાં થોડી સામગ્રી ઉમેરો ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... અને પછી તેને એક આઇટરરેટરમાં ફેરવો:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ને trait bound તરીકે વાપરવું સામાન્ય છે.આ ઇનપુટ સંગ્રહ પ્રકારને બદલાવાની મંજૂરી આપે છે, તેથી તે હજી સુધી પુનરાવર્તક છે.
/// અતિરિક્ત સીમાઓ પર પ્રતિબંધ દ્વારા સ્પષ્ટ કરી શકાય છે
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// તત્વોનો પ્રકાર પુનરાવર્તિત થઈ રહ્યો છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// કયા પ્રકારનાં ઇટરેટર આપણે આમાં ફેરવી રહ્યા છીએ?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// મૂલ્યથી ઇરેટર બનાવે છે.
    ///
    /// વધુ માટે [module-level documentation] જુઓ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// પુનરાવર્તકની સામગ્રી સાથે સંગ્રહમાં વધારો.
///
/// ઇટરેટર્સ મૂલ્યોની શ્રેણી ઉત્પન્ન કરે છે, અને સંગ્રહ પણ મૂલ્યોની શ્રેણી તરીકે વિચારી શકાય છે.
/// `Extend` trait આ અંતરને દૂર કરે છે, તમને તે પુનરાવર્તકની સામગ્રીનો સમાવેશ કરીને સંગ્રહને વિસ્તૃત કરવાની મંજૂરી આપે છે.
/// પહેલેથી જ અસ્તિત્વમાંની કી સાથે સંગ્રહને વિસ્તૃત કરતી વખતે, તે એન્ટ્રી અપડેટ કરવામાં આવે છે અથવા, સમાન કીઓ સાથે બહુવિધ એન્ટ્રીઓને મંજૂરી આપતા સંગ્રહના કિસ્સામાં, તે એન્ટ્રી શામેલ કરવામાં આવે છે.
///
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// // તમે કેટલાક અક્ષરો સાથે શબ્દમાળા લંબાવી શકો છો:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` અમલમાં મૂકવું:
///
/// ```
/// // એક નમૂના સંગ્રહ, તે ફક્ત વી.સી. ઉપર એક આવરણ છે<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ચાલો તેને કેટલીક પદ્ધતિઓ આપીએ જેથી આપણે એક બનાવી શકીએ અને તેમાં વસ્તુઓ ઉમેરી શકીએ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // માય કલેક્શનમાં આઇ 32 ની સૂચિ છે, તેથી અમે એક્સ 100 એક્સ માટે એક્સટેન્ડ લાગુ કરીએ છીએ
/// impl Extend<i32> for MyCollection {
///
///     // આ કોંક્રિટ પ્રકારનાં સહી સાથે થોડું સરળ છે: અમે કોઈ પણ વસ્તુ પર વિસ્તૃત ક callલ કરી શકીએ છીએ જે ઇટરરેટરમાં ફેરવી શકાય છે જે અમને i32s આપે છે.
///     // કારણ કે માય કલેક્શનમાં મૂકવા માટે અમને આઇ 32 ની જરૂર છે.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // અમલીકરણ ખૂબ સીધું છે: પુનરાવર્તક દ્વારા લૂપ કરો, અને દરેક તત્વોને પોતાને add() X કરો.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ચાલો અમારો સંગ્રહ વધુ ત્રણ સંખ્યાઓ સાથે વધારીએ
/// c.extend(vec![1, 2, 3]);
///
/// // અમે આ તત્વોને અંતમાં ઉમેર્યા છે
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// પુનરાવર્તકની સામગ્રી સાથેનો સંગ્રહ વિસ્તરે છે.
    ///
    /// કારણ કે આ ઝેડટ્રેટ 0 ઝેડ માટે આ એકમાત્ર આવશ્યક પદ્ધતિ છે, [trait-level] ડsક્સમાં વધુ વિગતો શામેલ છે.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // તમે કેટલાક અક્ષરો સાથે શબ્દમાળા લંબાવી શકો છો:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// બરાબર એક તત્વ સાથે સંગ્રહ લંબાવે છે.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// વધારાના તત્વોની આપેલ સંખ્યા માટે સંગ્રહમાં ક્ષમતા અનામત છે.
    ///
    /// ડિફ defaultલ્ટ અમલીકરણ કશું કરતું નથી.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}