/// એક ઇરેટર જે તેની સચોટ લંબાઈ જાણે છે.
///
/// ઘણા [te Iterator`] s ને ખબર નથી કે તેઓ કેટલી વાર પુનરાવર્તિત થશે, પરંતુ કેટલાક કરે છે.
/// જો કોઈ પુનરાવર્તક વ્યક્તિ જાણે છે કે તે કેટલી વાર પુનરાવર્તિત થઈ શકે છે, તો તે માહિતીની providingક્સેસ પ્રદાન કરવી ઉપયોગી થઈ શકે છે.
/// ઉદાહરણ તરીકે, જો તમે પાછળની બાજુએ પુનરાવર્તિત થવું હોય, તો એક સારી શરૂઆત એ છે કે અંત ક્યાં છે તે જાણવાનું છે.
///
/// `ExactSizeIterator` ને અમલમાં મૂકતી વખતે, તમારે [`Iterator`] પણ અમલમાં મૂકવું આવશ્યક છે.
/// આવું કરતી વખતે, [`Iterator::size_hint`]*ના અમલીકરણને* પુનરાવર્તકનું ચોક્કસ કદ પાછું કરવું આવશ્યક છે.
///
/// [`len`] પદ્ધતિનો ડિફોલ્ટ અમલ છે, તેથી તમારે સામાન્ય રીતે તેનો અમલ કરવો જોઈએ નહીં.
/// જો કે, તમે ડિફ defaultલ્ટ કરતાં વધુ પ્રદર્શનત્મક અમલીકરણ પ્રદાન કરી શકશો, તેથી આ કિસ્સામાં તેને ફરીથી લખવાનું અર્થપૂર્ણ છે.
///
///
/// નોંધ લો કે આ trait એ સલામત trait છે અને જેમ કે *નથી* અને * * ખાતરી આપી શકતા નથી કે પરત થયેલ લંબાઈ સાચી છે.
/// આનો અર્થ એ કે `unsafe` કોડ ** **[`Iterator::size_hint`] ની સાચીતા પર આધાર રાખવો જોઈએ નહીં.
/// અસ્થિર અને અસુરક્ષિત [`TrustedLen`](super::marker::TrustedLen) trait આ વધારાની બાંયધરી આપે છે.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// // મર્યાદિત શ્રેણી કેટલી વાર પુનરાવર્તન કરશે તે બરાબર જાણે છે
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] માં, અમે [`Iterator`] લાગુ કર્યું, `Counter`.
/// ચાલો તેના માટે પણ `ExactSizeIterator` લાગુ કરીએ:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // આપણે બાકીની સંખ્યાઓની પુનરાવૃત્તિની ગણતરી સરળતાથી કરી શકીએ છીએ.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // અને હવે આપણે તેનો ઉપયોગ કરી શકીએ છીએ!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// પુનરાવર્તકની ચોક્કસ લંબાઈ પરત કરે છે.
    ///
    /// અમલીકરણ સુનિશ્ચિત કરે છે કે પુનરાવર્તક [`None`] પરત પહેલાં, [`Some(T)`] મૂલ્ય કરતાં વધુ વખત `len()` પાછા આવશે.
    ///
    /// આ પદ્ધતિમાં ડિફોલ્ટ અમલીકરણ છે, તેથી તમારે સામાન્ય રીતે તેનો સીધો અમલ કરવો જોઈએ નહીં.
    /// જો કે, જો તમે વધુ કાર્યક્ષમ અમલીકરણ પ્રદાન કરી શકો છો, તો તમે આમ કરી શકો છો.
    /// ઉદાહરણ માટે [trait-level] ડsક્સ જુઓ.
    ///
    /// આ ફંક્શનમાં [`Iterator::size_hint`] ફંક્શનની જેમ સલામતીની બાંયધરી છે.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // મર્યાદિત શ્રેણી કેટલી વાર પુનરાવર્તન કરશે તે બરાબર જાણે છે
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: આ નિવેદનો વધુ પડતા રક્ષણાત્મક છે, પરંતુ તે આક્રમણકારીને તપાસે છે
        // trait દ્વારા ખાતરી આપી.
        // જો આ trait rust-આંતરિક હોત, તો અમે ડિબગ_સ્સારતનો ઉપયોગ કરી શકીએ છીએ ;;assert_eq!બધા ઝેડ રસ્ટ 0 ઝેડ વપરાશકર્તા અમલીકરણોને પણ તપાસશે.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// જો ઇરેટર ખાલી હોય તો `true` આપે છે.
    ///
    /// આ પદ્ધતિમાં [`ExactSizeIterator::len()`] નો ઉપયોગ કરીને ડિફ defaultલ્ટ અમલીકરણ છે, તેથી તમારે તેને જાતે અમલમાં મૂકવાની જરૂર નથી.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}