//! આ મોડ્યુલ ઉપયોગની મંજૂરી આપવા માટે પ્રાચીન પ્રકારનો રિપોર્ટપોર્ટ કરે છે જે સંભવત other અન્ય ઘોષિત પ્રકારો દ્વારા પડછાયો નથી.
//!
//! આ સામાન્ય રીતે ફક્ત મેક્રો જનરેટેડ કોડમાં જ ઉપયોગી છે.
//!
//! આનો દાખલો ત્યારે છે જ્યારે કોઈ નવું સ્ટ્રક્ટ ઉત્પન્ન થાય છે અને તેના માટે પ્રોમ્પ્લ કરો:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! નોંધ લો કે `SOME_PROPERTY` સંકળાયેલ સ્થિર સંકલન કરશે નહીં, કારણ કે તેનો પ્રકાર `bool` પ્રાચીન ઝેડબૂલ0 ઝેડ પ્રકારને બદલે સ્ટ્ર toક્ટનો સંદર્ભ આપે છે.
//!
//!
//! સાચો અમલ આના જેવો હોઈ શકે છે:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;