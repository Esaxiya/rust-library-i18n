//! બાઇટ્સ સ્લાઈસથી `str` બનાવવાની રીતો.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// બાઇટ્સની સ્લાઇસને સ્ટ્રિંગ સ્લાઈસમાં રૂપાંતરિત કરે છે.
///
/// એક સ્ટ્રિંગ સ્લાઈસ ([`&str`]) બાઇટ્સ ([`u8`]) ની બનેલી છે, અને બાઇટ સ્લાઈસ ([`&[u8]`][byteslice]) બાઇટ્સથી બનેલી છે, તેથી આ ફંક્શન બંને વચ્ચે ફેરવાય છે.
/// બધી બાઇટ કાપી નાંખવાની માન્ય સ્ટ્રિંગ કાપી નાંખવા નથી, તેમ છતાં: [`&str`] એ આવશ્યક છે કે તે માન્ય UTF-8 છે.
/// `from_utf8()` બાઇટ્સ માન્ય UTF-8 છે તેની ખાતરી કરવા માટે ચકાસે છે, અને પછી રૂપાંતર કરે છે.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// જો તમને ખાતરી છે કે બાઇટ સ્લાઈસ માન્ય UTF-8 છે, અને તમે માન્યતા તપાસોના ઓવરહેડ પર ન આવવા માંગતા હો, તો ત્યાં આ ફંક્શનનું અસુરક્ષિત સંસ્કરણ છે, [`from_utf8_unchecked`], જેવું જ વર્તન છે પણ ચેક અવગણો છે.
///
///
/// જો તમને `&str` ને બદલે `String` ની જરૂર હોય, તો [`String::from_utf8`][string] ને ધ્યાનમાં લો.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// કારણ કે તમે એક `[u8; N]` ને સ્ટેક-ફાળવી શકો છો, અને તમે તેનો [`&[u8]`][byteslice] લઈ શકો છો, આ કાર્ય સ્ટેક-ફાળવેલ શબ્દમાળાઓ માટેની એક રીત છે.નીચે ઉદાહરણ વિભાગમાં આનું ઉદાહરણ છે.
///
/// [byteslice]: slice
///
/// # Errors
///
/// જો પ્રદાન કરેલી સ્લાઇસ UTF-8 કેમ નથી તે વર્ણન સાથે સ્લાઈસ UTF-8 ન હોય તો `Err` આપે છે.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::str;
///
/// // vector માં કેટલાક બાઇટ્સ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // અમે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી ફક્ત `unwrap()` નો ઉપયોગ કરો.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ખોટો બાઇટ્સ:
///
/// ```
/// use std::str;
///
/// // vector માં કેટલાક અમાન્ય બાઇટ્સ
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// પાછા આવી શકે તેવા પ્રકારની ભૂલો પર વધુ વિગતો માટે ડ forક્સને [`Utf8Error`] જુઓ.
///
/// એક "stack allocated string":
///
/// ```
/// use std::str;
///
/// // કેટલાક બાઇટ્સ, સ્ટેક ફાળવેલ એરેમાં
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // અમે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી ફક્ત `unwrap()` નો ઉપયોગ કરો.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // સલામતી: ચાલ્યું માન્યતા.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// બાઇટ્સની પરિવર્તનીય સ્લાઇસને પરિવર્તનીય શબ્દમાળાની કટકમાં રૂપાંતરિત કરે છે.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" પરિવર્તનીય vector તરીકે
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // આપણે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી અમે `unwrap()` નો ઉપયોગ કરી શકીએ છીએ
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ખોટો બાઇટ્સ:
///
/// ```
/// use std::str;
///
/// // પરિવર્તનીય vector માં કેટલાક અમાન્ય બાઇટ્સ
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// પાછા આવી શકે તેવા પ્રકારની ભૂલો પર વધુ વિગતો માટે ડ forક્સને [`Utf8Error`] જુઓ.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // સલામતી: ચાલ્યું માન્યતા.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// બાઇટ્સની સ્લાઇસને શબ્દમાળાની સ્લાઇસમાં રૂપાંતરિત કર્યા વિના તપાસો કે શબ્દમાળામાં માન્ય UTF-8 છે.
///
/// વધુ માહિતી માટે સલામત સંસ્કરણ, [`from_utf8`] જુઓ.
///
/// # Safety
///
/// આ ફંક્શન અસુરક્ષિત છે કારણ કે તે તપાસતું નથી કે તેમાં પસાર કરેલા બાઇટ્સ માન્ય UTF-8 છે.
/// જો આ અવરોધનું ઉલ્લંઘન કરવામાં આવે છે, તો અનિશ્ચિત વર્તનનાં પરિણામો, જેમ કે બાકીના ઝેડ રસ્ટ0 ઝેડ ધારે છે કે [`&str`] એ માન્ય UTF-8 છે.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::str;
///
/// // vector માં કેટલાક બાઇટ્સ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // સલામતી: ક calલરને બાંયધરી આપવી આવશ્યક છે કે બાઇટ્સ `v` માન્ય UTF-8 છે.
    // સમાન લેઆઉટ ધરાવતા `&str` અને `&[u8]` પર પણ આધાર રાખે છે.
    unsafe { mem::transmute(v) }
}

/// બાઇટ્સની સ્લાઇસને શબ્દમાળાની સ્લાઇસમાં રૂપાંતરિત કર્યા વિના તપાસો કે શબ્દમાળામાં માન્ય UTF-8 છે;પરિવર્તનશીલ આવૃત્તિ
///
///
/// વધુ માહિતી માટે પરિવર્તનશીલ આવૃત્તિ, [`from_utf8_unchecked()`] જુઓ.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // સલામતી: કlerલરને બાંયધરી આપવી આવશ્યક છે કે બાઇટ્સ `v`
    // માન્ય UTF-8 છે, આમ `*mut str` પરની કાસ્ટ સલામત છે.
    // ઉપરાંત, પોઇન્ટર ડિરેફરન્સ સલામત છે કારણ કે તે નિર્દેશક સંદર્ભમાંથી આવે છે જે લેખકોને માન્ય હોવાની બાંયધરી આપે છે.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}