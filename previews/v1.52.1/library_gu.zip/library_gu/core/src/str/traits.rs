//! `str` માટે Trait અમલીકરણ.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// શબ્દમાળાઓનો ક્રમ લાવવાનો અમલ કરે છે.
///
/// સ્ટ્રીંગ્સને તેમના બાઇટ મૂલ્યો દ્વારા [lexicographically](Ord#lexicographical-comparison) મંગાવવામાં આવે છે.
/// આ કોડ ચાર્ટમાં તેમની સ્થિતિના આધારે યુનિકોડ કોડ પોઇન્ટ્સ ordersર્ડર કરે છે.
/// આ જરૂરી નથી કે "alphabetical" ઓર્ડર જેવું જ હોય, જે ભાષા અને સ્થાન દ્વારા બદલાય છે.
/// સાંસ્કૃતિક રૂપે સ્વીકૃત ધોરણો અનુસાર સortર્ટ કરવા માટે લોકેલ-વિશિષ્ટ ડેટાની આવશ્યકતા છે જે `str` પ્રકારનાં અવકાશની બહાર છે.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// શબ્દમાળાઓ પર તુલનાત્મક ક્રિયાઓ લાગુ કરે છે.
///
/// સ્ટ્રીંગ્સની તુલના તેમના બાઇટ મૂલ્યો દ્વારા [lexicographically](Ord#lexicographical-comparison) સાથે કરવામાં આવે છે.
/// આ કોડ ચાર્ટમાં તેમની સ્થિતિના આધારે યુનિકોડ કોડ પોઇન્ટની તુલના કરે છે.
/// આ જરૂરી નથી કે "alphabetical" ઓર્ડર જેવું જ હોય, જે ભાષા અને સ્થાન દ્વારા બદલાય છે.
/// સાંસ્કૃતિક-સ્વીકૃત ધોરણો અનુસાર તારની તુલના કરવા માટે લોકેલ-વિશિષ્ટ ડેટાની જરૂર છે જે `str` પ્રકારનાં અવકાશની બહાર છે.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// સિન્ટેક્ષ `&self[..]` અથવા `&mut self[..]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// સંપૂર્ણ શબ્દમાળાની એક ટુકડો પાછો આપે છે, એટલે કે, `&self` અથવા `&mut self` આપે છે.`અને સ્વ [0 ..] ની સમાન
/// લેન] `અથવા`&સ્વયં બદલો [0 ..
/// len]`.
/// અન્ય અનુક્રમણિકા ક્રિયાઓથી વિપરીત, આ ક્યારેય ઝેડપેનિક0 ઝેડ કરી શકતું નથી.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// 1.20.0 પહેલાં, આ અનુક્રમણિકા કામગીરી હજી પણ `Index` અને `IndexMut` ના સીધા અમલીકરણ દ્વારા સમર્થિત હતી.
///
/// `&self[0 .. len]` અથવા `&mut self[0 .. len]` ની સમકક્ષ.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// સિન્ટેક્ષ `&self[begin .. end]` અથવા `&mut self[begin .. end]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// બાઇટ શ્રેણી [`પ્રારંભ`, `end`) માંથી આપેલ સ્ટ્રિંગની ટુકડો પાછો આપે છે.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// 1.20.0 પહેલાં, આ અનુક્રમણિકા કામગીરી હજી પણ `Index` અને `IndexMut` ના સીધા અમલીકરણ દ્વારા સમર્થિત હતી.
///
/// # Panics
///
/// Panics જો `begin` અથવા `end` અક્ષરની પ્રારંભિક બાઇટ setફસેટ (`is_char_boundary` દ્વારા વ્યાખ્યાયિત કર્યા મુજબ) તરફ નિર્દેશ કરતું નથી, જો `begin > end`, અથવા જો `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // આ panic કરશે:
/// // બાઇટ 2 `ö` ની અંદર આવેલું છે:
/// // &s [2 ..3];
///
/// // બાઇટ 8 `老` અને s ની અંદર છે [1 ..
/// // 8];
///
/// // બાઇટ 100 એ શબ્દમાળાની બહાર છે [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // સલામતી: હમણાં જ તપાસો કે `start` અને `end` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            // અમે ચેર સીમાઓની પણ તપાસ કરી, તેથી આ માન્ય UTF-8 છે.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // સલામતી: હમણાં જ તપાસો કે `start` અને `end` ચારની સીમા પર છે.
            // અમે જાણીએ છીએ કે નિર્દેશક અનન્ય છે કારણ કે અમને તે `slice` માંથી મળ્યું છે.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // સલામતી: કlerલર ખાતરી આપે છે કે `self` `slice` ની સીમમાં છે
        // જે `add` માટેની બધી શરતોને સંતોષે છે.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // સલામત: `get_unchecked` માટે ટિપ્પણીઓ જુઓ.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary તપાસ કરે છે કે અનુક્રમણિકા [0, .len()], XL X ને ઉપર મુજબ ફરીથી વાપરી શકતી નથી, NLL મુશ્કેલીને કારણે
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // સલામતી: હમણાં જ તપાસો કે `start` અને `end` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// સિન્ટેક્ષ `&self[.. end]` અથવા `&mut self[.. end]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// બાઇટ રેન્જ [`0`, `end`) માંથી આપેલ સ્ટ્રિંગની ટુકડો પાછો આપે છે.
/// `&self[0 .. end]` અથવા `&mut self[0 .. end]` ની સમકક્ષ.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// 1.20.0 પહેલાં, આ અનુક્રમણિકા કામગીરી હજી પણ `Index` અને `IndexMut` ના સીધા અમલીકરણ દ્વારા સમર્થિત હતી.
///
/// # Panics
///
/// Panics જો `end` એ અક્ષરના પ્રારંભિક બાઇટ setફસેટ (`is_char_boundary` દ્વારા વ્યાખ્યાયિત કર્યા મુજબ) તરફ નિર્દેશ કરતું નથી, અથવા જો `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // સલામતી: હમણાં જ તપાસ્યું કે `end` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // સલામતી: હમણાં જ તપાસ્યું કે `end` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // સલામતી: હમણાં જ તપાસ્યું કે `end` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// સિન્ટેક્ષ `&self[begin ..]` અથવા `&mut self[begin ..]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// બાઇટ શ્રેણી [`પ્રારંભ`, `len`) માંથી આપેલ સ્ટ્રિંગની ટુકડો પાછો આપે છે.Self અને સ્વ [સમાન .. માટે સમાન]
/// લેન] `અથવા` અને સ્વયં પરિવર્તન કરો [પ્રારંભ કરો ..
/// len]`.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// 1.20.0 પહેલાં, આ અનુક્રમણિકા કામગીરી હજી પણ `Index` અને `IndexMut` ના સીધા અમલીકરણ દ્વારા સમર્થિત હતી.
///
/// # Panics
///
/// Panics જો `begin` એ અક્ષરના પ્રારંભિક બાઇટ setફસેટ (`is_char_boundary` દ્વારા વ્યાખ્યાયિત કર્યા મુજબ) તરફ નિર્દેશ કરતું નથી, અથવા જો `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // સલામતી: હમણાં જ તપાસ્યું કે `start` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // સલામતી: હમણાં જ તપાસ્યું કે `start` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // સલામતી: કlerલર ખાતરી આપે છે કે `self` `slice` ની સીમમાં છે
        // જે `add` માટેની બધી શરતોને સંતોષે છે.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // સલામત: `get_unchecked` ની સમાન.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // સલામતી: હમણાં જ તપાસ્યું કે `start` ચારની સીમા પર છે,
            // અને અમે સલામત સંદર્ભમાં પસાર થઈ રહ્યા છીએ, તેથી વળતર મૂલ્ય પણ એક હશે.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// સિન્ટેક્ષ `&self[begin ..= end]` અથવા `&mut self[begin ..= end]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// [`begin`, `end`] બાઇટ રેંજમાંથી આપેલી સ્ટ્રિંગની ટુકડા પરત કરે છે.`&self [begin .. end + 1]` અથવા `&mut self[begin .. end + 1]` ની સમકક્ષ, સિવાય કે જો `end` માં `usize` નું મહત્તમ મૂલ્ય છે.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// # Panics
///
/// ઝેડ પanનિક્સ 0 ઝેડ જો એક્સ 0 2 એક્સ અક્ષરની પ્રારંભિક બાઇટ offફસેટ તરફ નિર્દેશ કરતું નથી (`is_char_boundary` દ્વારા વ્યાખ્યાયિત થયેલ છે), જો `end` અક્ષરની અંત બાઇટ setફસેટ તરફ નિર્દેશ ન કરે (`end + 1` ક્યાં તો પ્રારંભિક બાઇટ setફસેટ અથવા `len` ની બરાબર છે), જો `begin > end`, અથવા જો `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // સલામતી: કlerલરને `get_unchecked` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // સલામતી: કlerલરને `get_unchecked_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// સિન્ટેક્ષ `&self[..= end]` અથવા `&mut self[..= end]` સાથે કાપતા સબસ્ટ્રિંગને અમલમાં મૂકે છે.
///
/// [0, `end`] બાઇટ રેંજમાંથી આપેલ સ્ટ્રિંગની ટુકડા પરત કરે છે.
/// `&self [0 .. end + 1]` ની સમકક્ષ, સિવાય કે `end` માં `usize` નું મહત્તમ મૂલ્ય છે.
///
/// આ ઓપરેશન *ઓ*(1) છે.
///
/// # Panics
///
/// Panics જો `end` એ કોઈ અક્ષરના અંત બાઇટ offફસેટ તરફ નિર્દેશ કરતું નથી (`end + 1` ક્યાં તો `is_char_boundary` દ્વારા વ્યાખ્યાયિત કરેલ પ્રારંભિક બાઇટ offફસેટ છે, અથવા `len` ની બરાબર છે), અથવા જો `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // સલામતી: કlerલરને `get_unchecked` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // સલામતી: કlerલરને `get_unchecked_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// શબ્દમાળામાંથી કોઈ મૂલ્યનું વિશ્લેષણ કરો
///
/// `ફ્રાસ્ટ્રની [`from_str`] પદ્ધતિ [[str`] ની [`parse`] પદ્ધતિ દ્વારા, ઘણીવાર ગર્ભિત રીતે વપરાય છે.
/// ઉદાહરણો માટે [ars પાર્સી] ના દસ્તાવેજો જુઓ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` આજીવન પરિમાણ નથી, અને તેથી તમે ફક્ત એવા પ્રકારોનું વિશ્લેષણ કરી શકો છો જેમાં આજીવન પરિમાણ પોતાને સમાવતું નથી.
///
/// બીજા શબ્દોમાં કહીએ તો, તમે `FromStr` સાથે `i32` નું વિશ્લેષણ કરી શકો છો, પરંતુ `&i32` નહીં.
/// તમે `i32` ધરાવતા સ્ટ્રક્ટનું વિશ્લેષણ કરી શકો છો, પરંતુ તેમાં એક `&i32` શામેલ નથી.
///
/// # Examples
///
/// `Point` પ્રકાર પરના `FromStr` નું મૂળભૂત અમલીકરણ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// સંકળાયેલ ભૂલ જે વિશ્લેષણમાંથી પરત આવી શકે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// આ પ્રકારનાં મૂલ્યને પરત કરવા માટે શબ્દમાળા `s` નું વિશ્લેષણ કરે છે.
    ///
    /// જો પદચ્છેદન સફળ થાય છે, તો [`Ok`] ની અંદરની કિંમત પરત કરો, નહીં તો જ્યારે શબ્દમાળા ખોટી ફોર્મેટ થયેલ હોય ત્યારે અંદરની [`Err`] ને લગતી ભૂલ આપે છે.
    /// ભૂલનો પ્રકાર trait ના અમલીકરણ માટે વિશિષ્ટ છે.
    ///
    /// # Examples
    ///
    /// [`i32`] સાથેનો મૂળ વપરાશ, એક પ્રકાર જે `FromStr` લાગુ કરે છે:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// શબ્દમાળાથી એક `bool` નું વિશ્લેષણ કરો.
    ///
    /// `Result<bool, ParseBoolError>` ની ઉપજ આપે છે, કારણ કે `s` ખરેખર વિશ્લેષણ કરી શકે છે અથવા નહીં.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// નોંધ, ઘણા કિસ્સાઓમાં, `str` પરની `.parse()` પદ્ધતિ વધુ યોગ્ય છે.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}