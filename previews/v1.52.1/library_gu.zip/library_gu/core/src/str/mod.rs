//! શબ્દમાળાની હેરફેર.
//!
//! વધુ વિગતો માટે, [`std::str`] મોડ્યુલ જુઓ.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. હદ બહાર
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. પ્રારંભ <=અંત
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. પાત્રની સીમા
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // પાત્ર શોધો
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` લેન કરતા ઓછી અને ચારની સીમા હોવી આવશ્યક છે
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` ની લંબાઈ પરત કરે છે.
    ///
    /// આ લંબાઈ બાઇટ્સમાં છે, [`ચાર્જ] સે અથવા ગ્રાફિમ્સમાં નહીં.
    /// બીજા શબ્દોમાં કહીએ તો, તે શબ્દ તે નથી હોતું જે માણસ શબ્દમાળાની લંબાઈને ધ્યાનમાં લે છે.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ફેન્સી એફ!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// જો `self` ની લંબાઈ શૂન્ય બાઇટ્સ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// તપાસો કે `અનુક્રમણિકા-મી બાઇટ એ UTF-8 કોડ પોઇન્ટ ક્રમ અથવા શબ્દમાળાના અંતનો પ્રથમ બાઇટ છે.
    ///
    ///
    /// સ્ટ્રિંગની શરૂઆત અને અંત (જ્યારે `અનુક્રમણિકા== self.len()`) એ સીમાઓ માનવામાં આવે છે.
    ///
    /// જો `index` `self.len()` કરતા વધારે હોય તો `false` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ની શરૂઆત
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` નું બીજું બાઇટ
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` ની ત્રીજી બાઇટ
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 અને લેન હંમેશાં બરાબર છે.
        // 0 માટે સ્પષ્ટ રીતે પરીક્ષણ કરો જેથી તે ચેકને સરળતાથી optimપ્ટિમાઇઝ કરી શકે અને તે કેસ માટે સ્ટ્રિંગ ડેટા વાંચવાનું છોડી શકે.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // આ બીટ જાદુ સમાન છે: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// સ્ટ્રિંગ સ્લાઈસને બાઇટ સ્લાઈસમાં રૂપાંતરિત કરે છે.
    /// બાઇટ સ્લાઈસને સ્ટ્રિંગ સ્લાઈસમાં પાછું કન્વર્ટ કરવા માટે, [`from_utf8`] ફંક્શનનો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // સલામતી: કોન્સ્ટ અવાજ કારણ કે અમે એક જ લેઆઉટ સાથે બે પ્રકારનાં ટ્રાન્સમ્યુટ કરીએ છીએ
        unsafe { mem::transmute(self) }
    }

    /// પરિવર્તનીય શબ્દમાળા સ્લાઇસને પરિવર્તનીય બાઇટ સ્લાઇસમાં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// કlerલરને ખાતરી કરવી આવશ્યક છે કે orrowણ સમાપ્ત થાય અને અંતર્ગત `str` નો ઉપયોગ થાય તે પહેલાં સ્લાઇસની સામગ્રી માન્ય UTF-8 છે.
    ///
    ///
    /// એક `str` નો ઉપયોગ જેની સમાવિષ્ટો માન્ય નથી UTF-8 એ અસ્પષ્ટ વર્તન છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // સલામત: `&str` થી `&[u8]` સુધીની કાસ્ટ `str` પછીથી સલામત છે
        // `&[u8]` જેવું જ લેઆઉટ ધરાવે છે (ફક્ત લિબ્સ્ટડી આ બાંયધરી આપી શકે છે).
        // પોઇન્ટર ડિરેફરન્સ સલામત છે કારણ કે તે પરિવર્તનશીલ સંદર્ભમાંથી આવે છે જે લેખકોને માન્ય હોવાની બાંયધરી આપે છે.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// સ્ટ્રિંગ સ્લાઈસને કાચા પોઇન્ટરમાં ફેરવે છે.
    ///
    /// જેમ કે શબ્દમાળાના ટુકડા એ બાઇટ્સની સ્લાઇસ છે, કાચા નિર્દેશક એક [`u8`] તરફ નિર્દેશ કરે છે.
    /// આ પોઇન્ટર શબ્દમાળા સ્લાઇસના પ્રથમ બાઇટ તરફ પોઇન્ટ કરશે.
    ///
    /// ક calલરે ખાતરી કરવી આવશ્યક છે કે પાછો ફર્યો નિર્દેશક ક્યારેય લખાયો નથી.
    /// જો તમારે સ્ટ્રિંગ સ્લાઈસની સામગ્રીને પરિવર્તિત કરવાની જરૂર હોય, તો [`as_mut_ptr`] નો ઉપયોગ કરો.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// પરિવર્તનીય શબ્દમાળા સ્લાઇસને કાચા પોઇન્ટરમાં રૂપાંતરિત કરે છે.
    ///
    /// જેમ કે શબ્દમાળાના ટુકડા એ બાઇટ્સની સ્લાઇસ છે, કાચા નિર્દેશક એક [`u8`] તરફ નિર્દેશ કરે છે.
    /// આ પોઇન્ટર શબ્દમાળા સ્લાઇસના પ્રથમ બાઇટ તરફ પોઇન્ટ કરશે.
    ///
    /// તે સુનિશ્ચિત કરવાની તમારી જવાબદારી છે કે શબ્દમાળાની કટકા ફક્ત તે રીતે સંશોધિત થાય કે તે માન્ય UTF-8 રહે.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` ની સબસ્લાઇસ પરત કરે છે.
    ///
    /// આ `str` ને અનુક્રમણિકા આપવાનો બિન-ગભરાટ ભરવાનો વિકલ્પ છે.
    /// જ્યારે પણ સમકક્ષ અનુક્રમણિકા કામગીરી panic થાય ત્યારે [`None`] આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // સૂચકાંકો, UTF-8 અનુક્રમ સીમાઓ પર નથી
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // હદ બહાર
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` ની પરિવર્તનશીલ સબસ્લાઇસ પરત કરે છે.
    ///
    /// આ `str` ને અનુક્રમણિકા આપવાનો બિન-ગભરાટ ભરવાનો વિકલ્પ છે.
    /// જ્યારે પણ સમકક્ષ અનુક્રમણિકા કામગીરી panic થાય ત્યારે [`None`] આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // યોગ્ય લંબાઈ
    /// assert!(v.get_mut(0..5).is_some());
    /// // હદ બહાર
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` ની અનચેક કરેલ સબસ્લાઇસ પરત કરે છે.
    ///
    /// `str` ને અનુક્રમણિકા આપવાનો આ એક અનચેક વિકલ્પ છે.
    ///
    /// # Safety
    ///
    /// આ કાર્યના કlersલર્સ જવાબદાર છે કે આ પૂર્વવર્તીતાઓ સંતોષાય છે:
    ///
    /// * પ્રારંભિક અનુક્રમણિકા અંતિમ અનુક્રમણિકાથી વધુ ન હોવી જોઈએ;
    /// * અનુક્રમણિકા મૂળ સ્લાઇસની સીમાની અંદર હોવી જોઈએ;
    /// * અનુક્રમણિકાઓ UTF-8 અનુક્રમ સીમાઓ પર આવેલા હોવા જોઈએ.
    ///
    /// નિષ્ફળ થવામાં, પરત થયેલ સ્ટ્રિંગ સ્લાઈસ અમાન્ય મેમરીનો સંદર્ભ આપી શકે છે અથવા `str` પ્રકાર દ્વારા સંદેશિત આક્રમણોનું ઉલ્લંઘન કરી શકે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // સલામતી: કlerલરને `get_unchecked` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` ની પરિવર્તનીય, અનચેક કરેલ સબસ્લાઇસ પરત કરે છે.
    ///
    /// `str` ને અનુક્રમણિકા આપવાનો આ એક અનચેક વિકલ્પ છે.
    ///
    /// # Safety
    ///
    /// આ કાર્યના કlersલર્સ જવાબદાર છે કે આ પૂર્વવર્તીતાઓ સંતોષાય છે:
    ///
    /// * પ્રારંભિક અનુક્રમણિકા અંતિમ અનુક્રમણિકાથી વધુ ન હોવી જોઈએ;
    /// * અનુક્રમણિકા મૂળ સ્લાઇસની સીમાની અંદર હોવી જોઈએ;
    /// * અનુક્રમણિકાઓ UTF-8 અનુક્રમ સીમાઓ પર આવેલા હોવા જોઈએ.
    ///
    /// નિષ્ફળ થવામાં, પરત થયેલ સ્ટ્રિંગ સ્લાઈસ અમાન્ય મેમરીનો સંદર્ભ આપી શકે છે અથવા `str` પ્રકાર દ્વારા સંદેશિત આક્રમણોનું ઉલ્લંઘન કરી શકે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // સલામતી: કlerલરને `get_unchecked_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// સલામતી ચકાસણોને બાયપાસ કરીને બીજી સ્ટ્રિંગ સ્લાઈસમાંથી સ્ટ્રિંગ સ્લાઈસ બનાવે છે.
    ///
    /// આ સામાન્ય રીતે આગ્રહણીય નથી, સાવધાની સાથે વાપરો!સલામત વિકલ્પ માટે [`str`] અને [`Index`] જુઓ.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// આ નવી સ્લાઈસ `begin` થી `end` સુધી જાય છે, જેમાં `begin` નો સમાવેશ થાય છે પરંતુ `end` સિવાય.
    ///
    /// તેના બદલે પરિવર્તનશીલ શબ્દમાળાની સ્લાઈસ મેળવવા માટે, [`slice_mut_unchecked`] પદ્ધતિ જુઓ.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// આ કાર્યના ક ofલર્સ જવાબદાર છે કે ત્રણ પૂર્વવર્તીતાઓ સંતોષાય:
    ///
    /// * `begin` `end` કરતાં વધુ ન હોવું જોઈએ.
    /// * `begin` અને `end` બાઇટ પોઝિશન શબ્દમાળાની ટુકડામાં હોવી આવશ્યક છે.
    /// * `begin` અને `end` એ UTF-8 અનુક્રમ સીમાઓ પર રહેવું આવશ્યક છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // સલામતી: કlerલરને `get_unchecked` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// સલામતી ચકાસણોને બાયપાસ કરીને બીજી સ્ટ્રિંગ સ્લાઈસમાંથી સ્ટ્રિંગ સ્લાઈસ બનાવે છે.
    /// આ સામાન્ય રીતે આગ્રહણીય નથી, સાવધાની સાથે વાપરો!સલામત વિકલ્પ માટે [`str`] અને [`IndexMut`] જુઓ.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// આ નવી સ્લાઈસ `begin` થી `end` સુધી જાય છે, જેમાં `begin` નો સમાવેશ થાય છે પરંતુ `end` સિવાય.
    ///
    /// તેના બદલે અવ્યવસ્થિત શબ્દમાળાની સ્લાઈસ મેળવવા માટે, [`slice_unchecked`] પદ્ધતિ જુઓ.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// આ કાર્યના ક ofલર્સ જવાબદાર છે કે ત્રણ પૂર્વવર્તીતાઓ સંતોષાય:
    ///
    /// * `begin` `end` કરતાં વધુ ન હોવું જોઈએ.
    /// * `begin` અને `end` બાઇટ પોઝિશન શબ્દમાળાની ટુકડામાં હોવી આવશ્યક છે.
    /// * `begin` અને `end` એ UTF-8 અનુક્રમ સીમાઓ પર રહેવું આવશ્યક છે.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // સલામતી: કlerલરને `get_unchecked_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ઇન્ડેક્સ પર એક સ્ટ્રિંગ સ્લાઈસને બે ભાગમાં વહેંચો.
    ///
    /// દલીલ, `mid`, શબ્દમાળાની શરૂઆતથી બાઇટ setફસેટ હોવી જોઈએ.
    /// તે UTF-8 કોડ પોઇન્ટની સીમા પર પણ હોવું આવશ્યક છે.
    ///
    /// પરત થયેલ બંને કટકાઓ શબ્દમાળાની શરૂઆતથી લઈને `mid` પર, અને `mid` થી શબ્દમાળાના ટુકડાના અંત સુધી જાય છે.
    ///
    /// તેના બદલે પરિવર્તનીય શબ્દમાળા કાપી નાંખવા માટે, [`split_at_mut`] પદ્ધતિ જુઓ.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// ઝેડ પPનિક્સ 0 ઝેડ જો `mid` એ UTF-8 કોડ પોઇન્ટ બાઉન્ડ્રી પર નથી, અથવા જો તે શબ્દમાળાની સ્લાઇસના છેલ્લા કોડ પોઇન્ટના અંતની છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_ બાઉન્ડ્રી તપાસ કરે છે કે અનુક્રમણિકા [0, .len()]
        if self.is_char_boundary(mid) {
            // સલામતી: હમણાં જ તપાસ્યું કે `mid` ચારની સીમા પર છે.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// એક પરિવર્તનીય શબ્દમાળાની સ્લાઇસને અનુક્રમણિકામાં બેમાં વહેંચો.
    ///
    /// દલીલ, `mid`, શબ્દમાળાની શરૂઆતથી બાઇટ setફસેટ હોવી જોઈએ.
    /// તે UTF-8 કોડ પોઇન્ટની સીમા પર પણ હોવું આવશ્યક છે.
    ///
    /// પરત થયેલ બંને કટકાઓ શબ્દમાળાની શરૂઆતથી લઈને `mid` પર, અને `mid` થી શબ્દમાળાના ટુકડાના અંત સુધી જાય છે.
    ///
    /// તેના બદલે બદલી ન શકાય તેવી શબ્દમાળા કાપી નાંખવા માટે, [`split_at`] પદ્ધતિ જુઓ.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// ઝેડ પPનિક્સ 0 ઝેડ જો `mid` એ UTF-8 કોડ પોઇન્ટ બાઉન્ડ્રી પર નથી, અથવા જો તે શબ્દમાળાની સ્લાઇસના છેલ્લા કોડ પોઇન્ટના અંતની છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_ બાઉન્ડ્રી તપાસ કરે છે કે અનુક્રમણિકા [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // સલામતી: હમણાં જ તપાસ્યું કે `mid` ચારની સીમા પર છે.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// શબ્દમાળાની સ્લાઇસનાં [`ચાર્જ] ઓ પર પુનરાવર્તક પરત કરે છે.
    ///
    /// સ્ટ્રિંગની સ્લાઇસમાં માન્ય UTF-8 શામેલ હોવાથી, અમે [`char`] દ્વારા સ્ટ્રિંગ સ્લાઈસ દ્વારા ફરી શકીએ છીએ.
    /// આ પદ્ધતિ આવા ઇરેટરને આપે છે.
    ///
    /// તે યાદ રાખવું અગત્યનું છે કે [`char`] એ યુનિકોડ સ્કેલેર મૂલ્યનું પ્રતિનિધિત્વ કરે છે, અને 'character' શું છે તેના તમારા વિચાર સાથે મેળ ખાતું નથી.
    ///
    /// ગ્રાફાઇમ ક્લસ્ટરો પરની શોધ એ તમે ખરેખર કરવા માંગો છો તે હોઈ શકે છે.
    /// આ કાર્યક્ષમતા Rust ની માનક લાઇબ્રેરી દ્વારા પ્રદાન કરવામાં આવી નથી, તેના બદલે crates.io તપાસો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// યાદ રાખો, [`char`] s અક્ષરો વિશેની તમારી અંતર્જ્itionાન સાથે મેળ ખાતું નથી:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' નથી
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// શબ્દમાળાની કટકા [`ચાર્જ] ઓ પર ઇટરેટર અને તેમની સ્થિતિ પરત કરે છે.
    ///
    /// સ્ટ્રિંગની સ્લાઇસમાં માન્ય UTF-8 શામેલ હોવાથી, અમે [`char`] દ્વારા સ્ટ્રિંગ સ્લાઈસ દ્વારા ફરી શકીએ છીએ.
    /// આ પદ્ધતિ આ બંને [`ચ`ર] ઓના પુનરાવર્તક, તેમજ તેમની બાઇટ સ્થિતિને આપે છે.
    ///
    /// પુનરાવર્તક ટ્યુપલ્સ આપે છે.સ્થિતિ પ્રથમ છે, [`char`] બીજો છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// યાદ રાખો, [`char`] s અક્ષરો વિશેની તમારી અંતર્જ્itionાન સાથે મેળ ખાતું નથી:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // (0, 'y̆') નથી
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // અહીં 3 ની નોંધ લો, છેલ્લા પાત્રમાં બે બાઇટ્સ મળ્યાં હતાં
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// સ્ટ્રિંગ સ્લાઈસના બાઇટ્સ ઉપર એક ઇટરેટર.
    ///
    /// જેમ કે શબ્દમાળાની સ્લાઇસમાં બાઇટ્સનો ક્રમ હોય છે, આપણે બાઇટ દ્વારા સ્ટ્રિંગ સ્લાઈસ દ્વારા ફરી શકીએ છીએ.
    /// આ પદ્ધતિ આવા ઇરેટરને આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// વ્હાઇટ સ્પેસ દ્વારા સ્ટ્રિંગ સ્લાઈસને વિભાજિત કરે છે.
    ///
    /// પાછલા ઇટરેટર શબ્દમાળા કાપી નાંખશે જે મૂળ શબ્દમાળાની કટકાની પેટા-ટુકડાઓ છે, કોઈપણ ખાલી જગ્યાથી અલગ પડે છે.
    ///
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    /// જો તમે તેના બદલે ફક્ત ASCII વ્હાઇટ સ્પેસ પર વિભાજીત કરવા માંગતા હો, તો [`split_ascii_whitespace`] નો ઉપયોગ કરો.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// તમામ પ્રકારના ગોરા સ્થાનને ધ્યાનમાં લેવામાં આવે છે:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII વ્હાઇટ સ્પેસ દ્વારા સ્ટ્રિંગ સ્લાઈસને વિભાજિત કરે છે.
    ///
    /// પાછલા ઇટરેટર એ સ્ટ્રિંગ કાપી નાંખશે જે મૂળ શબ્દમાળાની કટકાની પેટા-ટુકડાઓ છે, કોઈપણ રકમ ASCII વ્હાઇટ સ્પેસથી અલગ પડે છે.
    ///
    ///
    /// તેના બદલે યુનિકોડ `Whitespace` દ્વારા વિભાજીત કરવા માટે, [`split_whitespace`] નો ઉપયોગ કરો.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// તમામ પ્રકારની એએસસીઆઈઆઈ વ્હાઇટ સ્પેસ માનવામાં આવે છે:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// શબ્દમાળાના ટુકડાઓ તરીકે, શબ્દમાળાની લાઇનો ઉપર પુનરાવર્તક.
    ///
    /// લાઇન્સ કાં તો નવી લાઇન X01 એક્સ અથવા લાઇન ફીડ (`\r\n`) સાથે કેરેજ રીટર્ન સાથે સમાપ્ત થાય છે.
    ///
    /// અંતિમ લાઇન અંત એ વૈકલ્પિક છે.
    /// એક શબ્દમાળા જે અંતિમ રેખાના અંત સાથે સમાપ્ત થાય છે તે સમાન રેખાઓને અંતિમ લાઇન સમાપ્ત કર્યા વિના અન્યથા સમાન શબ્દમાળાની જેમ પાછો આપશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// અંતિમ વાક્ય સમાપ્ત કરવું આવશ્યક નથી:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// શબ્દમાળાની રેખાઓ પર એક ઇરેટર.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 તરીકે એન્કોડ કરેલા શબ્દમાળાની ઉપર `u16` નો ઇરેટર આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// જો આપેલ પેટર્ન આ સ્ટ્રિંગ સ્લાઈસની પેટા-ટુકડાથી મેળ ખાય છે તો `true` પરત કરે છે.
    ///
    /// જો તે ન થાય તો `false` આપે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// જો આપેલ પેટર્ન આ શબ્દમાળાની કટકાના ઉપસર્ગ સાથે મેળ ખાય છે તો `true` આપે છે.
    ///
    /// જો તે ન થાય તો `false` આપે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// જો આપેલ પેટર્ન આ શબ્દમાળાની કટકાના પ્રત્યય સાથે મેળ ખાય તો `true` આપે છે.
    ///
    /// જો તે ન થાય તો `false` આપે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// પેટર્ન સાથે મેળ ખાતી આ સ્ટ્રિંગ સ્લાઈસના પહેલા પાત્રના બાઇટ ઇન્ડેક્સ પરત કરે છે.
    ///
    /// જો પેટર્ન મેચ ન થાય તો [`None`] પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// પોઇન્ટ-ફ્રી શૈલી અને સમાપ્તિઓનો ઉપયોગ કરીને વધુ જટિલ દાખલાઓ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// પેટર્ન શોધી નથી:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// આ સ્ટ્રિંગ સ્લાઈસમાં પેટર્નની સૌથી જમણી મેચના પ્રથમ પાત્ર માટે બાઇટ અનુક્રમણિકા પરત કરે છે.
    ///
    /// જો પેટર્ન મેચ ન થાય તો [`None`] પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// બંધ સાથે વધુ જટિલ દાખલાઓ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// પેટર્ન શોધી નથી:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// આ સ્ટ્રિંગ સ્લાઈસના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, દાખલા દ્વારા મેળ ખાતા અક્ષરો દ્વારા અલગ પડે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ઇટરેટર એક [`DoubleEndedIterator`] હશે જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે અને forward/reverse શોધ સમાન તત્વો આપે છે.
    /// આ [`char`] માટે, ઉદાહરણ તરીકે સાચું છે, પરંતુ `&str` માટે નહીં.
    ///
    /// જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે પરંતુ તેના પરિણામો આગળની શોધથી અલગ હોઈ શકે છે, તો [`rsplit`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// જો પેટર્ન એ અક્ષરોની કટકા હોય, તો કોઈપણ પાત્રોની દરેક ઘટના પર વિભાજીત કરો:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// જો કોઈ શબ્દમાળામાં અનેક સુસંગત વિભાજકો હોય, તો તમે આઉટપુટમાં ખાલી શબ્દમાળાઓ સાથે સમાપ્ત થશો:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// કોન્ટિગ્યુસ વિભાજક ખાલી શબ્દમાળા દ્વારા અલગ પડે છે.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// કોઈ શબ્દમાળાની શરૂઆતમાં અથવા અંતમાં વિભાજક ખાલી તાર દ્વારા પડોશી હોય છે.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// જ્યારે ખાલી શબ્દમાળા વિભાજક તરીકે ઉપયોગમાં લેવાય છે, ત્યારે તે શબ્દમાળાના દરેક પાત્રને સ્ટ્રિંગની શરૂઆત અને અંતની સાથે અલગ પાડે છે.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// જ્યારે વિભાજક તરીકે વ્હાઇટ સ્પેસનો ઉપયોગ કરવામાં આવે ત્યારે સંલગ્ન વિભાજકો કદાચ આશ્ચર્યજનક વર્તન તરફ દોરી જાય છે.આ કોડ સાચો છે:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// તે તમને _not_ આપે છે:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// આ વર્તણૂક માટે [`split_whitespace`] નો ઉપયોગ કરો.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// આ સ્ટ્રિંગ સ્લાઈસના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, દાખલા દ્વારા મેળ ખાતા અક્ષરો દ્વારા અલગ પડે છે.
    /// તે `split_inclusive` માં `split` દ્વારા ઉત્પાદિત ઇટરેટરથી અલગ પડે છે અને મેચિંગ ભાગને સબસ્ટ્રેંગના ટર્મિનેટર તરીકે છોડી દે છે.
    ///
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// જો શબ્દમાળાના છેલ્લા તત્વનો મેળ ખાય છે, તો તે તત્વ પહેલાના સબસ્ટ્રિંગનો ટર્મિનેટર માનવામાં આવશે.
    /// તે સબસ્ટ્રેંગ એ ઇટરેટર દ્વારા પરત કરવામાં આવેલી છેલ્લી આઇટમ હશે.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// આપેલ શબ્દમાળા કટકાના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, જે પેટર્નથી મેળ ખાતા અક્ષરો દ્વારા અલગ પડે છે અને વિપરીત ક્રમમાં પ્રાપ્ત થાય છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારને આવશ્યક છે કે પેટર્ન એક વિપરીત શોધને સમર્થન આપે છે, અને જો forward/reverse શોધ સમાન ઘટકો મેળવે તો તે એક [`DoubleEndedIterator`] હશે.
    ///
    ///
    /// સામેથી પુનરાવર્તિત કરવા માટે, [`split`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// આપેલ સ્ટ્રિંગ સ્લાઈસના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, જે પેટર્ન દ્વારા મેળ ખાતા અક્ષરો દ્વારા અલગ પડે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ની સમકક્ષ, સિવાય કે ખાલી હોય તો પાછળનો સબસ્ટ્રિંગ છોડવામાં આવે છે.
    ///
    /// [`split`]: str::split
    ///
    /// આ પદ્ધતિનો ઉપયોગ સ્ટ્રિંગ ડેટા માટે કરી શકાય છે જે _terminated_ છે, પેટર્ન દ્વારા _separated_ કરતાં.
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ઇટરેટર એક [`DoubleEndedIterator`] હશે જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે અને forward/reverse શોધ સમાન તત્વો આપે છે.
    /// આ [`char`] માટે, ઉદાહરણ તરીકે સાચું છે, પરંતુ `&str` માટે નહીં.
    ///
    /// જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે પરંતુ તેના પરિણામો આગળની શોધથી અલગ હોઈ શકે છે, તો [`rsplit_terminator`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` ની સબસ્ટ્રિંગ્સ પર એક પુનરાવર્તક, એક દાખલા દ્વારા મેળ ખાતા અક્ષરો દ્વારા અલગ પડે છે અને વિપરીત ક્રમમાં પ્રાપ્ત થાય છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ની સમકક્ષ, સિવાય કે ખાલી હોય તો પાછળનો સબસ્ટ્રિંગ છોડવામાં આવે છે.
    ///
    /// [`split`]: str::split
    ///
    /// આ પદ્ધતિનો ઉપયોગ સ્ટ્રિંગ ડેટા માટે કરી શકાય છે જે _terminated_ છે, પેટર્ન દ્વારા _separated_ કરતાં.
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારને આવશ્યક છે કે પેટર્ન એક વિપરીત શોધને સમર્થન આપે છે, અને જો કોઈ forward/reverse શોધ સમાન તત્વો આપે તો તે ડબલ સમાપ્ત થશે.
    ///
    ///
    /// સામેથી પુનરાવર્તિત કરવા માટે, [`split_terminator`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// આપેલ સ્ટ્રિંગ સ્લાઈસના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, પેટર્નથી અલગ, મોટાભાગની `n` આઇટમ્સ પર પાછા આવવા માટે પ્રતિબંધિત.
    ///
    /// જો `n` સબસ્ટ્રિંગ્સ પરત આવે છે, તો છેલ્લા સબસ્ટ્રિંગ (`n`th સબસ્ટ્રિંગ) શબ્દમાળાના બાકીના ભાગને સમાવશે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારનું ડબલ અંત થશે નહીં, કારણ કે તે ટેકો આપવા માટે કાર્યક્ષમ નથી.
    ///
    /// જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે, તો [`rsplitn`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// આ શબ્દમાળાની સ્લાઇસના સબસ્ટ્રિંગ્સ ઉપર એક ઇટરેટર, એક પેટર્નથી અલગ, શબ્દમાળાના અંતથી શરૂ કરીને, મોટાભાગની `n` વસ્તુઓ પર પાછા ફરવા માટે પ્રતિબંધિત છે.
    ///
    ///
    /// જો `n` સબસ્ટ્રિંગ્સ પરત આવે છે, તો છેલ્લા સબસ્ટ્રિંગ (`n`th સબસ્ટ્રિંગ) શબ્દમાળાના બાકીના ભાગને સમાવશે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારનું ડબલ અંત થશે નહીં, કારણ કે તે ટેકો આપવા માટે કાર્યક્ષમ નથી.
    ///
    /// આગળથી વિભાજીત કરવા માટે, [`splitn`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// ઉલ્લેખિત ડિલિમિટરની પ્રથમ ઘટના પર શબ્દમાળાને વિભાજિત કરે છે અને ડિલિમિટર પહેલાં ઉપસર્ગ અને સીમાંકક પછી પ્રત્યય પાછો આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// ઉલ્લેખિત ડિલિમિટરની છેલ્લી ઘટના પર શબ્દમાળાને વિભાજિત કરે છે અને ડિલિમિટર પહેલાં ઉપસર્ગ અને સીમાંકક પછી પ્રત્યય પાછો આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// આપેલ શબ્દમાળાની ટુકડામાં પેટર્નની વિખેરી મેચો ઉપર એક ઇટરેટર.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ઇટરેટર એક [`DoubleEndedIterator`] હશે જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે અને forward/reverse શોધ સમાન તત્વો આપે છે.
    /// આ [`char`] માટે, ઉદાહરણ તરીકે સાચું છે, પરંતુ `&str` માટે નહીં.
    ///
    /// જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે પરંતુ તેના પરિણામો આગળની શોધથી અલગ હોઈ શકે છે, તો [`rmatches`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// આ શબ્દમાળાની ટુકડાની અંદરની પેટર્નની વિખેરી મેચો ઉપર એક પુનરાવર્તક, વિપરીત ક્રમમાં પ્રાપ્ત થાય છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારને આવશ્યક છે કે પેટર્ન એક વિપરીત શોધને સમર્થન આપે છે, અને જો forward/reverse શોધ સમાન ઘટકો મેળવે તો તે એક [`DoubleEndedIterator`] હશે.
    ///
    ///
    /// સામેથી પુનરાવર્તિત કરવા માટે, [`matches`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// આ સ્ટ્રિંગ સ્લાઈસની અંદરની કોઈ પેટર્નની વિરોધાભાસી મેચો સાથે મેચની શરૂઆત થનાર ઇન્ડેક્સ સાથે ઇટરેટર.
    ///
    /// ઓવરલેપ થતા `pat` X ની અંદરના `pat` ની મેચ માટે, ફક્ત પ્રથમ મેચને અનુરૂપ સૂચકાંકો જ પાછા ફર્યા છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ઇટરેટર એક [`DoubleEndedIterator`] હશે જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે અને forward/reverse શોધ સમાન તત્વો આપે છે.
    /// આ [`char`] માટે, ઉદાહરણ તરીકે સાચું છે, પરંતુ `&str` માટે નહીં.
    ///
    /// જો પેટર્ન વિપરીત શોધને મંજૂરી આપે છે પરંતુ તેના પરિણામો આગળની શોધથી અલગ હોઈ શકે છે, તો [`rmatch_indices`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ફક્ત પ્રથમ `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` ની અંદરની પેટર્નની વિખેરી નાખેલી મેચો પર એક પુનરાવર્તક, મેચની અનુક્રમણિકા સાથે વિપરીત ક્રમમાં મળ્યો.
    ///
    /// ઓવરલેપ થતા `self` ની અંદરના `pat` ની મેચો માટે, ફક્ત છેલ્લી મેચને અનુરૂપ સૂચકાંકો જ પાછા ફર્યા છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ઇટરેટર વર્તન
    ///
    /// પરત ફરનારને આવશ્યક છે કે પેટર્ન એક વિપરીત શોધને સમર્થન આપે છે, અને જો forward/reverse શોધ સમાન ઘટકો મેળવે તો તે એક [`DoubleEndedIterator`] હશે.
    ///
    ///
    /// સામેથી પુનરાવર્તિત કરવા માટે, [`match_indices`] પદ્ધતિનો ઉપયોગ કરી શકાય છે.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ફક્ત છેલ્લા `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// અગ્રણી અને પાછળની વ્હાઇટ સ્પેસ દૂર કરેલી સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// અગ્રણી વ્હાઇટ સ્પેસ દૂર કરેલી સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// `start` આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની પ્રથમ સ્થિતિ;અંગ્રેજી અથવા રશિયન જેવી ડાબી-થી-જમણી ભાષા માટે, આ ડાબી બાજુ હશે, અને અરબી અથવા હીબ્રુ જેવી જમણી-થી-ડાબી ભાષાઓ માટે, આ જમણી બાજુ હશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ટ્રાયલિંગ વ્હાઇટ સ્પેસ સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// `end` આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની છેલ્લી સ્થિતિ;અંગ્રેજી અથવા રશિયન જેવી ડાબી-થી-જમણી ભાષા માટે, આ જમણી બાજુ હશે, અને અરબી અથવા હીબ્રુ જેવી જમણી-થી-ડાબી ભાષાઓ માટે, આ ડાબી બાજુ હશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// અગ્રણી વ્હાઇટ સ્પેસ દૂર કરેલી સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// 'Left' આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની પ્રથમ સ્થિતિ;અરબી અથવા હીબ્રુ જેવી ભાષા માટે કે જે 'ડાબેથી જમણે' બદલે 'જમણેથી ડાબે' હોય છે, આ _right_ બાજુ હશે, ડાબી બાજુ નહીં.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ટ્રાયલિંગ વ્હાઇટ સ્પેસ સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// 'Whitespace' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `White_Space` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// 'Right' આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની છેલ્લી સ્થિતિ;અરબી અથવા હીબ્રુ જેવી ભાષા માટે કે જે 'ડાબેથી જમણે' બદલે 'જમણેથી ડાબે' છે, તે _left_ બાજુ હશે, નહીં કે જમણી.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// વારંવાર દૂર કરાયેલ પેટર્ન સાથે મેળ ખાતા તમામ ઉપસર્ગો અને પ્રત્યય સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// [pattern] એ [`char`] હોઈ શકે છે, [`ચેર] ની કટકા, અથવા કોઈ ફંક્શન અથવા બંધ જે તે નક્કી કરે છે કે કોઈ પાત્ર મેળ ખાય છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // વહેલી તકે જાણીતી મેચ યાદ રાખો, જો તેને નીચેથી સુધારો
            // છેલ્લી મેચ જુદી છે
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // સલામતી: `Searcher` માન્ય સૂચકાંકો પરત કરવા માટે જાણીતું છે.
        unsafe { self.get_unchecked(i..j) }
    }

    /// વારંવાર દૂર કરાયેલ પેટર્ન સાથે મેળ ખાતી તમામ ઉપસર્ગો સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// `start` આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની પ્રથમ સ્થિતિ;અંગ્રેજી અથવા રશિયન જેવી ડાબી-થી-જમણી ભાષા માટે, આ ડાબી બાજુ હશે, અને અરબી અથવા હીબ્રુ જેવી જમણી-થી-ડાબી ભાષાઓ માટે, આ જમણી બાજુ હશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // સલામતી: `Searcher` માન્ય સૂચકાંકો પરત કરવા માટે જાણીતું છે.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ઉપસર્ગને દૂર કર્યાની સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// જો શબ્દમાળા `prefix` પેટર્નથી શરૂ થાય છે, તો `Some` માં આવરિત, ઉપસર્ગ પછી સબસ્ટ્રિંગ આપે છે.
    /// `trim_start_matches` થી વિપરીત, આ પદ્ધતિ એક વાર બરાબર ઉપસર્ગને દૂર કરે છે.
    ///
    /// જો શબ્દમાળા `prefix` થી પ્રારંભ થતો નથી, તો `None` આપે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// પ્રત્યયને દૂર કર્યાની સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// જો શબ્દમાળા `suffix` પેટર્ન સાથે સમાપ્ત થાય છે, તો `Some` માં લપેટેલા પ્રત્યય પહેલાં સબસ્ટ્રિંગ આપે છે.
    /// `trim_end_matches` થી વિપરીત, આ પદ્ધતિ પ્રત્યેક વાર એક વાર પ્રત્યય દૂર કરે છે.
    ///
    /// જો શબ્દમાળા `suffix` સાથે સમાપ્ત થતી નથી, તો `None` આપે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// વારંવાર દૂર કરાયેલ પેટર્ન સાથે મેળ ખાતા તમામ પ્રત્યયો સાથે એક સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// `end` આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની છેલ્લી સ્થિતિ;અંગ્રેજી અથવા રશિયન જેવી ડાબી-થી-જમણી ભાષા માટે, આ જમણી બાજુ હશે, અને અરબી અથવા હીબ્રુ જેવી જમણી-થી-ડાબી ભાષાઓ માટે, આ ડાબી બાજુ હશે.
    ///
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // સલામતી: `Searcher` માન્ય સૂચકાંકો પરત કરવા માટે જાણીતું છે.
        unsafe { self.get_unchecked(0..j) }
    }

    /// વારંવાર દૂર કરાયેલ પેટર્ન સાથે મેળ ખાતી તમામ ઉપસર્ગો સાથે સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// 'Left' આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની પ્રથમ સ્થિતિ;અરબી અથવા હીબ્રુ જેવી ભાષા માટે કે જે 'ડાબેથી જમણે' બદલે 'જમણેથી ડાબે' હોય છે, આ _right_ બાજુ હશે, ડાબી બાજુ નહીં.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// વારંવાર દૂર કરાયેલ પેટર્ન સાથે મેળ ખાતા તમામ પ્રત્યયો સાથે એક સ્ટ્રિંગ સ્લાઈસ પરત કરે છે.
    ///
    /// [pattern] એ `&str`, [`char`], [`ચ`ર] s ની સ્લાઇસ, અથવા કોઈ ફંક્શન અથવા ક્લોઝર હોઈ શકે છે જે નિર્ધારિત કરે છે કે પાત્ર મેચ કરે છે કે નહીં.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ટેક્સ્ટ દિશાત્મકતા
    ///
    /// શબ્દમાળા એ બાઇટ્સનો ક્રમ છે.
    /// 'Right' આ સંદર્ભમાં અર્થ એ છે કે તે બાઇટ શબ્દમાળાની છેલ્લી સ્થિતિ;અરબી અથવા હીબ્રુ જેવી ભાષા માટે કે જે 'ડાબેથી જમણે' બદલે 'જમણેથી ડાબે' છે, તે _left_ બાજુ હશે, નહીં કે જમણી.
    ///
    ///
    /// # Examples
    ///
    /// સરળ દાખલાઓ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// બંધનો ઉપયોગ કરીને એક વધુ જટિલ પેટર્ન:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// આ સ્ટ્રિંગ સ્લાઈસને બીજા પ્રકારમાં પાર્સ કરે છે.
    ///
    /// કારણ કે `parse` એટલું સામાન્ય છે, તે પ્રકાર અનુમાન સાથે સમસ્યા causeભી કરી શકે છે.
    /// જેમ કે, `parse` એ થોડી વારમાંનું એક છે જ્યારે તમે સિંટેક્સને પ્રેમથી 'turbofish' તરીકે ઓળખાય છે: `::<>`.
    ///
    /// આ અનુમાન અલ્ગોરિધમનો ખાસ કરીને તે સમજવામાં સહાય કરે છે કે તમે કયા પ્રકારનું વિશ્લેષણ કરવાનો પ્રયાસ કરી રહ્યાં છો.
    ///
    /// `parse` [`FromStr`] trait ને લાગુ કરે તેવા કોઈપણ પ્રકારનું વિશ્લેષણ કરી શકે છે.
    ///

    /// # Errors
    ///
    /// જો આ પ્રકારની સ્ટ્રિંગ સ્લાઈસને ઇચ્છિત પ્રકારમાં વિશ્લેષણ કરવું શક્ય ન હોય તો [`Err`] પરત કરશે.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ને ટિપ્પણી કરવાને બદલે 'turbofish' નો ઉપયોગ કરો:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// વિશ્લેષણ કરવામાં નિષ્ફળ:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// તપાસો કે જો આ શબ્દમાળાના બધા પાત્રો ASCII શ્રેણીની અંદર છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // આપણે અહીં દરેક બાઇટને પાત્રની જેમ સારવાર કરી શકીએ છીએ: બધા મલ્ટિબાઇટ અક્ષરો બાઇટથી શરૂ થાય છે જે એસ્કી રેન્જમાં નથી, તેથી આપણે ત્યાં પહેલાથી જ રોકાઈ જઈશું.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// તપાસ કરે છે કે બે તાર એ એએસસીઆઈઆઈ કેસ-સંવેદનશીલ મેચ છે.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ની જેમ જ, પરંતુ કામચલાઉ ફાળવણી અને ક copપિ કર્યા વિના.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// આ શબ્દમાળાને તેના ASCII અપર કેસમાં સમાન સ્થાને રૂપાંતરિત કરે છે.
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું અપરકેસ્ડ મૂલ્ય પાછું આપવા માટે, [`to_ascii_uppercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // સલામત: સલામત કારણ કે અમે એક જ લેઆઉટ સાથે બે પ્રકારનાં ટ્રાન્સમ્યુટ કરીએ છીએ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// આ શબ્દમાળાને તેના ASCII લોઅર કેસમાં સમાન સ્થાને રૂપાંતરિત કરે છે.
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું નીચલું મૂલ્ય પાછું આપવા માટે, [`to_ascii_lowercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // સલામત: સલામત કારણ કે અમે એક જ લેઆઉટ સાથે બે પ્રકારનાં ટ્રાન્સમ્યુટ કરીએ છીએ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// એક પુનરાવર્તક પાછા ફરો જે `self` માં દરેક ચારમાંથી [`char::escape_debug`] સાથે નીકળી જાય છે.
    ///
    ///
    /// Note: ફક્ત વિસ્તૃત ગ્રાફીમ કોડિપોઇન્ટ્સ કે જે શબ્દમાળા શરૂ થાય છે તે છટકી જશે.
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// એક પુનરાવર્તક પાછા ફરો જે `self` માં દરેક ચારમાંથી [`char::escape_default`] સાથે નીકળી જાય છે.
    ///
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// એક પુનરાવર્તક પાછા ફરો જે `self` માં દરેક ચારમાંથી [`char::escape_unicode`] સાથે નીકળી જાય છે.
    ///
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ખાલી સ્ટ્રિટ બનાવે છે
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ખાલી પરિવર્તનીય સ્ટ્રિફ બનાવે છે
    #[inline]
    fn default() -> Self {
        // સલામત: ખાલી શબ્દમાળા માન્ય UTF-8 છે.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// નામવાળું, ક્લોન કરવા યોગ્ય એફ.એન. પ્રકાર
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // સલામત: સલામત નથી
        unsafe { from_utf8_unchecked(bytes) }
    };
}