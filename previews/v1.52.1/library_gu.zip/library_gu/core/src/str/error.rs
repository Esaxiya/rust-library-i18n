//! utf8 ભૂલ પ્રકાર વ્યાખ્યાયિત કરે છે.

use crate::fmt;

/// ક્ષમતાઓ જે [`u8`] ના ક્રમને શબ્દમાળા તરીકે અર્થઘટન કરવાનો પ્રયાસ કરતી વખતે થઈ શકે છે.
///
/// જેમ કે, [`સ્ટ્રિંગ] અને [`&str`] બંને માટે વિધેયો અને પદ્ધતિઓનો `from_utf8` કુટુંબ આ ભૂલનો ઉપયોગ કરે છે, ઉદાહરણ તરીકે.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// આ ભૂલ પ્રકારની પદ્ધતિઓ heગલો મેમરી ફાળવ્યા વિના `String::from_utf8_lossy` જેવી વિધેય બનાવવા માટે વાપરી શકાય છે:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// આપેલ સ્ટ્રિંગમાં અનુક્રમણિકા આપે છે જેમાં માન્ય UTF-8 ચકાસાયેલ હતું.
    ///
    /// તે મહત્તમ અનુક્રમણિકા છે જે `from_utf8(&input[..index])` `Ok(_)` પરત કરશે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector માં કેટલાક અમાન્ય બાઇટ્સ
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 એક Utf8Error આપે છે
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // બીજો બાઇટ અહીં અમાન્ય છે
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// નિષ્ફળતા વિશે વધુ માહિતી પ્રદાન કરે છે:
    ///
    /// * `None`: ઇનપુટનો અંત અણધારી રીતે પહોંચ્યો હતો.
    ///   `self.valid_up_to()` ઇનપુટના અંતથી 1 થી 3 બાઇટ્સ છે.
    ///   જો બાઇટ સ્ટ્રીમ (જેમ કે ફાઇલ અથવા નેટવર્ક સોકેટ) ને વધતી જતી ડીકોડ કરવામાં આવી રહી છે, તો આ એક માન્ય `char` હોઈ શકે છે, જેનો UTF-8 બાઇટ ક્રમ બહુવિધ ટુકડાઓ પર ફેલાયેલો છે.
    ///
    ///
    /// * `Some(len)`: એક અનપેક્ષિત બાઇટ આવી હતી.
    ///   પ્રદાન કરેલી લંબાઈ એ અમાન્ય બાઇટ અનુક્રમની છે જે `valid_up_to()` દ્વારા આપેલ અનુક્રમણિકાથી પ્રારંભ થાય છે.
    ///   નુકસાનકારક ડીકોડિંગના કિસ્સામાં તે અનુક્રમ પછી (એક [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] દાખલ કર્યા પછી) ડીકોડિંગ ફરી શરૂ થવું જોઈએ.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] નો ઉપયોગ કરીને `bool` ને વિશ્લેષણ કરવામાં નિષ્ફળ થવામાં ભૂલ આવી
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}