//! UTF-8 માન્યતાને લગતી કામગીરી

use crate::mem;

use super::Utf8Error;

/// પ્રથમ બાઇટ માટે પ્રારંભિક કોડપointઇન્ટ સંચયક પરત કરે છે.
/// પ્રથમ બાઇટ વિશેષ છે, ફક્ત પહોળાઈ 2 માટે નીચે 5 બિટ્સ, પહોળાઈ 3 માટે 4 બિટ્સ અને પહોળાઈ 4 માટે 3 બિટ્સ જોઈએ છે.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// `byte` બાઈટ `byte` સાથે અપડેટ થયેલ `ch` નું મૂલ્ય આપે છે.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// બાઇટ એ UTF-8 સાતત્ય બાઇટ છે કે નહીં તેની તપાસ કરે છે (એટલે કે, બિટ્સ `10` થી પ્રારંભ થાય છે).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// બાઇટ ઇટરેટર (યુટીએફ-8-જેવા એન્કોડિંગ ધારીને) આગળનો કોડ પોઇન્ટ વાંચે છે.
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ડીકોડ UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // મલ્ટિબાઇટ કેસ બાઇટ સંયોજનમાંથી ડીકોડને અનુસરે છે: [[[x y] z] w]
    //
    // NOTE: પ્રદર્શન અહીં ચોક્કસ રચના માટે સંવેદનશીલ છે
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] ડબલ્યુ] કેસ
        // 0xE0 માં 5 મી બીટ .. 0xEF હંમેશા સ્પષ્ટ હોય છે, તેથી `init` હજી પણ માન્ય છે
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] કેસ ફક્ત `init` નીચલા 3 બીટ્સનો ઉપયોગ કરે છે
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// બાઇટ ઇટરેટર (યુટીએફ-8 જેવા એન્કોડિંગને ધારીને) ના છેલ્લા કોડ પોઇન્ટ વાંચે છે.
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ડીકોડ UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // મલ્ટિબાઇટ કેસ બાઇટ સંયોજનમાંથી ડીકોડને અનુસરે છે: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// ઉપયોગમાં u64 ફિટ કરવા માટે કાપવાનો ઉપયોગ કરો
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// જો `x` શબ્દમાં કોઈ બાઇટ નોનસિસી (>=128) હોય તો `true` આપે છે.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` તપાસવામાં ચાલે છે કે તે માન્ય UTF-8 અનુક્રમ છે, તે કિસ્સામાં `Ok(())` પરત કરે છે, અથવા, જો તે અમાન્ય છે, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // અમને ડેટાની જરૂર હતી, પરંતુ ત્યાં કંઈ નહોતું: ભૂલ!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-બાઇટ એન્કોડિંગ કોડિપોઇન્ટ્સ\u {0080} થી\u {07ff} પ્રથમ C2 80 છેલ્લું DF BF માટે છે
            // 3-બાઇટ એન્કોડિંગ કોડિપોઇન્ટ્સ\u {0800} થી\u {ffff} માટે છે પ્રથમ E0 A0 80 છેલ્લું EF BF BF સરોગેટ્સ કોડિપોઇન્ટ lud u {d800} થી\u {dfff} ED A0 80 થી ED BF BF સિવાય
            // 4-બાઇટ એન્કોડિંગ કોડિપોઇન્ટ્સ માટે છે\u {1000} 0 થી\u ff 10ff} ff પ્રથમ F0 90 80 80 છેલ્લું F4 8F BF BF
            //
            // આરએફસીમાંથી UTF-8 સિન્ટેક્સનો ઉપયોગ કરો
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-પૂંછડી UTF8-3= %xE0% xA0-BF UTF8-પૂંછડી/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-પૂંછડી/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // એસ્કી કેસ, ઝડપથી આગળ જવાનો પ્રયાસ કરો.
            // જ્યારે નિર્દેશક ગોઠવાયેલ હોય, ત્યાં સુધી પુનરાવર્તિત ડેટાના 2 શબ્દો વાંચો જ્યાં સુધી અમને નોન-એસ્કી બાઇટવાળી કોઈ શબ્દ ન મળે.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // સલામત: `align - index` અને `ascii_block_size` હોવાથી
                    // `usize_bytes`, `block = ptr.add(index)` નો ગુણોત્તર હંમેશા `usize` સાથે ગોઠવાયેલ હોય છે તેથી તે `block` અને `block.offset(1)` બંનેનો સંદર્ભ લેવાનું સલામત છે.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // જો ત્યાં nonascii બાઇટ છે તોડી
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // જ્યાંથી શબ્દવાળો લૂપ અટકી ગયો ત્યાંથી પગલું ભરે છે
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// પ્રથમ બાઇટ આપવામાં, આ UTF-8 અક્ષરમાં કેટલા બાઇટ્સ છે તે નક્કી કરે છે.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// ચાલુ બાઇટના મૂલ્ય બિટ્સનો માસ્ક.
const CONT_MASK: u8 = 0b0011_1111;
/// એક ચાલુ બાઇટના ટ tagગ બિટ્સ (ટેગ માસ્ક !CONT_MASK છે) નું મૂલ્ય.
const TAG_CONT_U8: u8 = 0b1000_0000;

// જો કાપવામાં આવ્યાં હોય, અને નવું સ્ટ્રંટ, `true` પરત કરો, તો મોટા ભાગે `max` ની લંબાઈ સુધી લંબાઈમાં કાપવું.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}