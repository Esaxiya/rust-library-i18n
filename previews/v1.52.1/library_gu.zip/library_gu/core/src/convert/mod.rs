//! પ્રકારો વચ્ચેના રૂપાંતરણો માટે Traits.
//!
//! આ મોડ્યુલમાં traits એ એક પ્રકારથી બીજા પ્રકારમાં કન્વર્ટ કરવાની રીત પ્રદાન કરે છે.
//! દરેક ઝેડટ્રેટ 0 ઝેડ એક અલગ હેતુ પ્રદાન કરે છે:
//!
//! - સસ્તા સંદર્ભ-થી-સંદર્ભ રૂપાંતરણો માટે [`AsRef`] trait લાગુ કરો
//! - સસ્તા પરિવર્તનીય-થી-પરિવર્તનીય રૂપાંતરણો માટે [`AsMut`] trait લાગુ કરો
//! - મૂલ્ય-થી-મૂલ્ય રૂપાંતરણો માટે [`From`] trait લાગુ કરો
//! - વર્તમાન crate ની બહારના પ્રકારોમાં મૂલ્ય-થી-મૂલ્ય રૂપાંતરણો વપરાશ માટે [`Into`] trait લાગુ કરો.
//! - [`TryFrom`] અને [`TryInto`] traits [`From`] અને [`Into`] ની જેમ વર્તે છે, પરંતુ જ્યારે રૂપાંતર નિષ્ફળ થઈ શકે ત્યારે તેનો અમલ થવો જોઈએ.
//!
//! આ મોડ્યુલમાં traits નો ઉપયોગ સામાન્ય રીતે trait bounds તરીકે સામાન્ય કાર્યો માટે થાય છે જેમ કે ઘણા પ્રકારનાં દલીલોને ટેકો આપવામાં આવે છે.ઉદાહરણો માટે દરેક ઝેડટ્રેટ 0 ઝેડના દસ્તાવેજીકરણ જુઓ.
//!
//! એક લાઇબ્રેરી લેખક તરીકે, તમારે હંમેશા [`Into<U>`][`Into`] અથવા [`TryInto<U>`][`TryInto`] ને બદલે [`From<T>`][`From`] અથવા [`TryFrom<T>`][`TryFrom`] લાગુ કરવાનું પસંદ કરવું જોઈએ, કારણ કે [`From`] અને [`TryFrom`] વધુ સુગમતા પ્રદાન કરે છે અને મફતમાં સમાન [`Into`] અથવા [`TryInto`] અમલીકરણો પ્રદાન કરે છે, માનક લાઇબ્રેરીમાં ધાબળા અમલીકરણને આભારી છે.
//! જ્યારે ઝેડ રસ્ટ0 ઝેડ X00 એક્સ પહેલાંની આવૃત્તિને લક્ષ્યમાં લેતા હો ત્યારે, વર્તમાન ઝેડક્રેટ 0 ઝેડની બહારના પ્રકારમાં રૂપાંતરિત કરતી વખતે સીધા [`Into`] અથવા [`TryInto`] ને અમલમાં મૂકવાની જરૂર હોઇ શકે.
//!
//! # સામાન્ય અમલીકરણો
//!
//! - [`AsRef`] અને [`AsMut`] સ્વત is-સંદર્ભ જો આંતરિક પ્રકારનો સંદર્ભ હોય તો
//! - [`થી`]`<U>માટે સૂચિત [`ઇનટ`]`</u><T><U>U` માટે</u>
//! - [`ટ્રાયફોર્મ`]`<U>એ સૂચવે છે [`ટ્રાયઇંટો]`માટે</u><T><U>U` માટે</u>
//! - [`From`] અને [`Into`] રીફ્લેક્સિવ છે, જેનો અર્થ છે કે બધા પ્રકારો જાતે `into` અને `from` જાતે કરી શકે છે
//!
//! વપરાશનાં ઉદાહરણો માટે દરેક ઝેડટ્રેટ 0 ઝેડ જુઓ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ઓળખ કાર્ય.
///
/// આ કાર્ય વિશે બે બાબતો ધ્યાનમાં લેવી મહત્વપૂર્ણ છે:
///
/// - તે હંમેશાં `|x| x` જેવા ક્લોઝરની સમકક્ષ હોતું નથી, કારણ કે ક્લોઝર `x` ને જુદા જુદા પ્રકારમાં દબાણ કરે છે.
///
/// - તે ફંક્શનમાં પસાર કરેલા ઇનપુટ `x` ને ખસેડે છે.
///
/// જ્યારે ફંક્શન હોય તેવું વિચિત્ર લાગે છે જે ફક્ત ઇનપુટ પાછું આપે છે, ત્યાં કેટલાક રસપ્રદ ઉપયોગો છે.
///
///
/// # Examples
///
/// અન્ય, રસપ્રદ, કાર્યોના ક્રમમાં કંઇ ન કરવા માટે `identity` નો ઉપયોગ:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ચાલો ડોળ કરીએ કે એક ઉમેરવું એ એક રસપ્રદ કાર્ય છે.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// શરતીમાં `identity` ને "do nothing" બેઝ કેસ તરીકે ઉપયોગ કરવો:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // વધુ રસપ્રદ સામગ્રી કરો ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` ના પુનરાવર્તકનાં `Some` ચલો રાખવા `identity` નો ઉપયોગ:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// સસ્તા સંદર્ભ થી સંદર્ભ રૂપાંતર કરવા માટે વપરાય છે.
///
/// આ trait [`AsMut`] જેવું જ છે જે પરિવર્તનીય સંદર્ભો વચ્ચે રૂપાંતરિત કરવા માટે વપરાય છે.
/// જો તમારે મોંઘા રૂપાંતર કરવાની જરૂર હોય તો `&T` પ્રકાર સાથે [`From`] લાગુ કરવું અથવા કસ્ટમ ફંક્શન લખવું વધુ સારું છે.
///
/// `AsRef` [`Borrow`] જેવી જ હસ્તાક્ષર ધરાવે છે, પરંતુ [`Borrow`] થોડા પાસાઓમાં અલગ છે:
///
/// - `AsRef` થી વિપરીત, [`Borrow`] કોઈપણ `T` માટે ધાબળો પ્રોમ્પ્ટ ધરાવે છે, અને તે સંદર્ભ અથવા મૂલ્યને સ્વીકારવા માટે વાપરી શકાય છે.
/// - [`Borrow`] [`Hash`], [`Eq`] અને [`Ord`] પણ ઉધાર આપેલા મૂલ્ય માટેના માલિકીના મૂલ્યની સમાન હોવું આવશ્યક છે.
/// આ કારણોસર, જો તમે કોઈ સ્ટ્ર ofક્ટના ફક્ત એક જ ક્ષેત્રને ઉધાર લેવા માંગતા હો, તો તમે `AsRef` લાગુ કરી શકો છો, પરંતુ [`Borrow`] નહીં.
///
/// **Note: આ trait નિષ્ફળ થવું જોઈએ નહીં **.જો રૂપાંતર નિષ્ફળ થઈ શકે છે, તો એક સમર્પિત પદ્ધતિનો ઉપયોગ કરો જે [`Option<T>`] અથવા [`Result<T, E>`] આપે છે.
///
/// # સામાન્ય અમલીકરણો
///
/// - `AsRef` જો આંતરિક પ્રકાર સંદર્ભ અથવા પરિવર્તનશીલ સંદર્ભ હોય તો સ્વત--સંદર્ભો (દા.ત.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds નો ઉપયોગ કરીને અમે ત્યાં સુધી વિવિધ પ્રકારનાં દલીલો સ્વીકારી શકીએ ત્યાં સુધી તેઓ નિર્દિષ્ટ પ્રકાર `T` માં રૂપાંતરિત થઈ શકે.
///
/// ઉદાહરણ તરીકે: એક સામાન્ય કાર્ય કે જે `AsRef<str>` લે છે તે બનાવીને આપણે વ્યક્ત કરીએ છીએ કે આપણે બધા સંદર્ભોને સ્વીકારવા માંગીએ છીએ જેને [`&str`] માં દલીલ રૂપે રૂપાંતરિત કરી શકાય છે.
/// [`String`] અને [`&str`] બંને `AsRef<str>` લાગુ કરે છે તેથી અમે બંને ઇનપુટ દલીલ તરીકે સ્વીકારી શકીએ છીએ.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// રૂપાંતર કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// સસ્તા પરિવર્તનીય-થી-પરિવર્તનીય સંદર્ભ રૂપાંતર કરવા માટે વપરાય છે.
///
/// આ trait [`AsRef`] જેવું જ છે પરંતુ પરિવર્તનીય સંદર્ભોમાં રૂપાંતરિત કરવા માટે વપરાય છે.
/// જો તમારે મોંઘા રૂપાંતર કરવાની જરૂર હોય તો `&mut T` પ્રકાર સાથે [`From`] લાગુ કરવું અથવા કસ્ટમ ફંક્શન લખવું વધુ સારું છે.
///
/// **Note: આ trait નિષ્ફળ થવું જોઈએ નહીં **.જો રૂપાંતર નિષ્ફળ થઈ શકે છે, તો એક સમર્પિત પદ્ધતિનો ઉપયોગ કરો જે [`Option<T>`] અથવા [`Result<T, E>`] આપે છે.
///
/// # સામાન્ય અમલીકરણો
///
/// - `AsMut` જો આંતરિક પ્રકાર પરિવર્તનશીલ સંદર્ભ હોય તો સ્વત de-સંદર્ભો (દા.ત.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// સામાન્ય કાર્ય માટે `AsMut` નો ઉપયોગ trait bound તરીકે આપણે બધા પરિવર્તનીય સંદર્ભોને સ્વીકારી શકીએ છીએ જે `&mut T` ને ટાઇપમાં રૂપાંતરિત કરી શકાય છે.
/// કારણ કે [`Box<T>`], `AsMut<T>` ને લાગુ કરે છે અમે એક ફંક્શન `add_one` લખી શકીએ છીએ જે બધી દલીલો લે છે જે `&mut u64` માં રૂપાંતરિત થઈ શકે છે.
/// કારણ કે [`Box<T>`], `AsMut<T>` ને લાગુ કરે છે, `add_one` `&mut Box<u64>` પ્રકારની દલીલો પણ સ્વીકારે છે:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// રૂપાંતર કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// એક મૂલ્યથી મૂલ્યનું રૂપાંતર જે ઇનપુટ મૂલ્યનો ઉપયોગ કરે છે.[`From`] ની વિરુદ્ધ.
///
/// કોઈએ [`Into`] લાગુ કરવાનું ટાળવું જોઈએ અને તેના બદલે [`From`] લાગુ કરવું જોઈએ.
/// [`From`] નું અમલીકરણ આપમેળે [`Into`] ના અમલીકરણ સાથે પ્રમાણભૂત પુસ્તકાલયમાં ધાબળા અમલીકરણ માટે પ્રદાન કરે છે.
///
/// [`Into`] પર [`Into`] નો ઉપયોગ કરવાનું પસંદ કરો જ્યારે trait bounds ને સામાન્ય કાર્ય પર સ્પષ્ટ કરો કે જે ફક્ત [`Into`] ને લાગુ કરે છે તેવા પ્રકારો પણ વાપરી શકાય તે સુનિશ્ચિત કરવા માટે.
///
/// **Note: આ trait નિષ્ફળ થવું જોઈએ નહીં **.જો રૂપાંતર નિષ્ફળ થઈ શકે છે, તો [`TryInto`] નો ઉપયોગ કરો.
///
/// # સામાન્ય અમલીકરણો
///
/// - [`થી`]`<T>U` સૂચિત `Into<U> for T` માટે
/// - [`Into`] રીફ્લેક્સિવ છે, જેનો અર્થ છે કે `Into<T> for T` અમલમાં છે
///
/// # ઝેડ રસ્ટ0 ઝેડના જૂના સંસ્કરણોમાં બાહ્ય પ્રકારોમાં રૂપાંતર માટે [`Into`] અમલમાં મૂકવું
///
/// Rust 1.41 પહેલાં, જો ગંતવ્ય પ્રકાર વર્તમાન crate નો ભાગ ન હોત, તો તમે સીધા [`From`] ને અમલમાં મૂકી શક્યા નહીં.
/// ઉદાહરણ તરીકે, આ કોડ લો:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// આ ભાષાના જૂના સંસ્કરણોનું સંકલન કરવામાં નિષ્ફળ જશે કારણ કે ઝેડ રસ્ટ 0 ઝેડના અનાથ નિયમો થોડો વધારે કડક હતા.
/// આને બાયપાસ કરવા માટે, તમે સીધા [`Into`] ને અમલમાં મૂકી શકો છો:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// તે સમજવું અગત્યનું છે કે [`Into`] [`From`] અમલીકરણ પ્રદાન કરતું નથી (જેમ કે [`From`] [`Into`] સાથે કરે છે).
/// તેથી, તમારે હંમેશાં [`From`] ને અમલમાં મૂકવાનો પ્રયત્ન કરવો જોઈએ અને પછી જો [`From`] અમલમાં ન લાવી શકાય તો [`Into`] પર પાછા ફરો.
///
/// # Examples
///
/// [`String`] અમલીકરણો [`ઇનટ`]`<`[`વેકા]`<`[`u8`]` >> `:
///
/// તે દર્શાવવા માટે કે આપણે જેરેનિક ફંકશન જોઈએ તે તમામ દલીલો લેવી કે જેને નિર્દિષ્ટ પ્રકાર `T` માં રૂપાંતરિત કરી શકાય છે, અમે [`ઇનટ`] of ના trait bound નો ઉપયોગ કરી શકીએ છીએ.<T>`.
///
/// ઉદાહરણ તરીકે: ફંક્શન `is_hello` એ બધી દલીલો લે છે જે [`Vec`]`<`[`u8`] `>` માં રૂપાંતરિત થઈ શકે છે.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// રૂપાંતર કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ઇનપુટ મૂલ્યનો વપરાશ કરતી વખતે મૂલ્ય-થી-મૂલ્ય રૂપાંતર કરવા માટે વપરાય છે.તે [`Into`] નું પારસ્પરિક છે.
///
/// કોઈએ હંમેશા `From` ને [`Into`] પર અમલ કરવાનું પસંદ કરવું જોઈએ કારણ કે `From` અમલીકરણ આપમેળે એક [`Into`] ના અમલીકરણ સાથે પ્રદાન કરે છે માનક પુસ્તકાલયમાં ધાબળા અમલીકરણ માટે આભાર.
///
///
/// Rust 1.41 પહેલાંની આવૃત્તિને લક્ષ્યમાં રાખીને અને વર્તમાન crate ની બહારના પ્રકારમાં રૂપાંતરિત કરતી વખતે ફક્ત [`Into`] લાગુ કરો.
/// `From` Rust ના અનાથ નિયમોને કારણે અગાઉના સંસ્કરણોમાં આ પ્રકારનાં રૂપાંતરણો કરવામાં સમર્થ નથી.
/// વધુ વિગતો માટે [`Into`] જુઓ.
///
/// સામાન્ય કાર્ય પર trait bounds નો ઉલ્લેખ કરતી વખતે `From` નો ઉપયોગ કરતા [`Into`] નો ઉપયોગ કરવાનું પસંદ કરો.
/// આ રીતે, [`Into`] સીધા અમલમાં મૂકતા પ્રકારોનો ઉપયોગ દલીલો તરીકે પણ થઈ શકે છે.
///
/// ભૂલ નિયંત્રણ કરતી વખતે `From` પણ ખૂબ ઉપયોગી છે.નિષ્ફળ થવા માટે સક્ષમ એવા ફંક્શનનું નિર્માણ કરતી વખતે, રીટર્નનો પ્રકાર સામાન્ય રીતે `Result<T, E>` સ્વરૂપનો હશે.
/// `From` trait એ ફંક્શનને એકલ એરર ટાઇપ પરત કરવાની મંજૂરી આપીને એરલ હેન્ડલિંગને સરળ બનાવે છે જે બહુવિધ ભૂલ પ્રકારોને સમાવે છે.વધુ વિગતો માટે "Examples" વિભાગ અને [the book][book] જુઓ.
///
/// **Note: આ trait નિષ્ફળ થવું જોઈએ નહીં **.જો રૂપાંતર નિષ્ફળ થઈ શકે છે, તો [`TryFrom`] નો ઉપયોગ કરો.
///
/// # સામાન્ય અમલીકરણો
///
/// - `From<T> for U` સૂચવે છે [`ઇનટ`]`<U>માટે T`</u>
/// - `From` રીફ્લેક્સિવ છે, જેનો અર્થ છે કે `From<T> for T` અમલમાં છે
///
/// # Examples
///
/// [`String`] એક્સ 100 એક્સ લાગુ કરે છે:
///
/// `&str` થી સ્ટ્રિંગમાં સ્પષ્ટ રૂપાંતર નીચે મુજબ કરવામાં આવે છે:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ભૂલ સંચાલન કરતી વખતે તે તમારા પોતાના ભૂલ પ્રકાર માટે `From` લાગુ કરવા માટે ઘણીવાર ઉપયોગી છે.
/// અંતર્ગત ભૂલ પ્રકારોને સમાવિષ્ટ કરેલા આપણા પોતાના કસ્ટમ ભૂલ પ્રકારમાં અંતર્ગત ભૂલના પ્રકારોને રૂપાંતરિત કરીને, આપણે અંતર્ગત કારણોની માહિતી ગુમાવ્યા વિના એક ભૂલ પ્રકાર પરત આપી શકીએ છીએ.
/// '?' operatorપરેટર `Into<CliError>::into` ને ક callingલ કરીને અંતર્ગત અંતર્ગત પ્રકારને અમારા કસ્ટમ ભૂલ પ્રકારમાં રૂપાંતરિત કરે છે જે `From` લાગુ કરતી વખતે આપમેળે પૂરા પાડવામાં આવે છે.
/// કમ્પાઇલર પછી કલ્પના કરે છે કે `Into` નો અમલ કયા ઉપયોગમાં લેવો જોઈએ.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// રૂપાંતર કરે છે.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// એક પ્રયાસ કરેલ રૂપાંતર જે `self` લે છે, જે ખર્ચાળ હોઈ શકે છે અથવા નહીં પણ.
///
/// લાઇબ્રેરી લેખકોએ સામાન્ય રીતે આ trait ને સીધી રીતે અમલમાં મૂકવું જોઈએ નહીં, પરંતુ [`TryFrom`] trait ને લાગુ કરવાનું પસંદ કરવું જોઈએ, જે વધારે સુગમતા આપે છે અને પ્રમાણભૂત પુસ્તકાલયમાં ધાબળા અમલીકરણને આભારી, મફતમાં સમાન `TryInto` અમલીકરણ પ્રદાન કરે છે.
/// આ વિશે વધુ માહિતી માટે, [`Into`] માટેના દસ્તાવેજીકરણ જુઓ.
///
/// # `TryInto` અમલીકરણ
///
/// આ [`Into`] લાગુ કરવા જેવા જ નિયંત્રણો અને તર્કથી પીડાય છે, વિગતો માટે અહીં જુઓ.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// પ્રકાર રૂપાંતર ભૂલની ઘટનામાં પરત ફર્યો.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// રૂપાંતર કરે છે.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// સરળ અને સલામત પ્રકારનાં રૂપાંતર જે કેટલાક સંજોગોમાં નિયંત્રિત રીતે નિષ્ફળ થઈ શકે છે.તે [`TryInto`] નું પારસ્પરિક છે.
///
/// જ્યારે તમે કોઈ પ્રકારનું રૂપાંતર કરી રહ્યાં હોવ ત્યારે તે ઉપયોગી છે જે તુચ્છ રૂપે સફળ થાય છે પણ તેને ખાસ સંભાળવાની પણ જરૂર પડી શકે છે.
/// ઉદાહરણ તરીકે, [`From`] trait નો ઉપયોગ કરીને કોઈ [`i64`] ને [`i32`] માં રૂપાંતરિત કરવાની કોઈ રીત નથી, કારણ કે [`i64`] માં એવું મૂલ્ય હોઇ શકે છે કે જે [`i32`] રજૂ કરી શકતું નથી અને તેથી રૂપાંતર ડેટા ગુમાવશે.
///
/// [`i64`] ને [`i32`] (આવશ્યકપણે [`i64`] નું મૂલ્ય મોડ્યુલો [`i32::MAX`] આપીને) આપીને અથવા ખાલી [`i32::MAX`] પરત કરીને અથવા કોઈ અન્ય પદ્ધતિ દ્વારા આ નિયંત્રિત થઈ શકે છે.
/// [`From`] trait સંપૂર્ણ રૂપાંતરણો માટે બનાવાયેલ છે, તેથી જ્યારે કોઈ પ્રકારનું રૂપાંતર ખરાબ થઈ શકે ત્યારે `TryFrom` trait પ્રોગ્રામરને જાણ કરે છે અને તેને કેવી રીતે હેન્ડલ કરવું તે નક્કી કરવા દે છે.
///
/// # સામાન્ય અમલીકરણો
///
/// - `TryFrom<T> for U` સૂચિત [`TryInto`]`<U>T` માટે</u>
/// - [`try_from`] રીફ્લેક્સિવ છે, જેનો અર્થ એ કે `TryFrom<T> for T` અમલમાં મૂકાયો છે અને નિષ્ફળ થઈ શકતો નથી-`T` પ્રકારનાં મૂલ્ય પર `T::try_from()` પર ક callingલ કરવા માટે સંકળાયેલ `Error` પ્રકાર એ [`Infallible`] છે.
/// જ્યારે [`!`] પ્રકાર સ્થિર થાય છે ત્યારે [`Infallible`] અને [`!`] સમાન હશે.
///
/// `TryFrom<T>` નીચે મુજબ અમલ કરી શકાય છે:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// વર્ણવ્યા પ્રમાણે, [`i32`] `ટ્રાયફ્રોમ <` [`i64`]`>`લાગુ કરે છે:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // શાંતિથી `big_number` કાપવામાં, હકીકત પછી કાપણીને શોધી કા detectવા અને સંચાલન કરવું જરૂરી છે.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // ભૂલ પરત કરે છે કારણ કે `big_number` `i32` માં ફિટ થવા માટે ખૂબ મોટી છે.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` પરત આપે છે.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// પ્રકાર રૂપાંતર ભૂલની ઘટનામાં પરત ફર્યો.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// રૂપાંતર કરે છે.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// સામાન્ય IMPLS
////////////////////////////////////////////////////////////////////////////////

// ઉપર અને લિફ્ટ તરીકે
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// જેમ કે &mut ઉપર લિફ્ટ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// ફિક્સ (#45742): &/&પરિવર્તન માટે ઉપરના ઇમ્પ્લેસને નીચેના વધુ સામાન્ય સાથે બદલો:
// // ડેરેફ ઉપર લિફ્ટ તરીકે
// પ્રોમ્પ્ટ <D: ?Sized + Deref<Target: AsRef<U>>, યુ:? કદમાં> <U>ડી {</u> ફન એક્સ00 એક્સ <U>માટેના રેફ-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut ઉપર લિફ્ટ કરે છે
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// ફિક્સ (#45742): &mut માટે ઉપરના પ્રોમ્પ્લને નીચેના વધુ સામાન્ય સાથે બદલો:
// // AsMut ડેરેફટ ઉપર લિફ્ટ કરે છે
// પ્રોમ્પ્ટ <D: ?Sized + Deref<Target: AsMut<U>>, યુ:? કદ:> <U>ડી {</u> એફએન as_mut(&mut self) <U>માટે અસમટ-> &mut યુ</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// માં સૂચિત
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// પ્રતિ (અને આમ માં) પ્રતિબિંબિત છે
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **સ્થિરતા નોંધ:** આ પ્રોમ્પ્લ હજી અસ્તિત્વમાં નથી, પરંતુ અમે તેને ઝેડ ફ્યુચર0 ઝેડમાં ઉમેરવા માટે "reserving space" છીએ.
/// વિગતો માટે [rust-lang/rust#64715][#64715] જુઓ.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): તેના બદલે એક સિદ્ધાંત ઠીક કરો.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ટ્રાયફ્રોમ સૂચવે છે ટ્રાયન્ટો
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ઇનફિલેબલ રૂપાંતર એ નિર્જન ભૂલના પ્રકાર સાથે અર્થપૂર્ણ રીતે પડતા રૂપાંતરણો સમાન છે.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// આઇ.એમ.પી.એલ.નું જોડાણ કરો
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// કોઈ ભૂલ ભૂલ ભૂલ નથી
////////////////////////////////////////////////////////////////////////////////

/// ભૂલો માટે ભૂલનો પ્રકાર જે ક્યારેય ન થઈ શકે.
///
/// કેમ કે આ ઇનોમમાં કોઈ પ્રકાર નથી, તેથી આ પ્રકારનું મૂલ્ય ખરેખર અસ્તિત્વમાં નથી હોતું.
/// આ જેનરિક એપીઆઇ માટે ઉપયોગી થઈ શકે છે જે [`Result`] નો ઉપયોગ કરે છે અને ભૂલ પ્રકારને પરિમાણિત કરે છે, તે સૂચવવા માટે કે પરિણામ હંમેશા [`Ok`] છે.
///
/// ઉદાહરણ તરીકે, [`TryFrom`] trait (રૂપાંતર જે [`Result`] આપે છે) નો ધાબળો અમલીકરણ તમામ પ્રકારના હોય છે જ્યાં વિપરીત [`Into`] અમલીકરણ અસ્તિત્વમાં છે.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # ઝેડ 0 ફ્યુચર0 ઝેડ સુસંગતતા
///
/// આ એનમની [the `!`“never”type][never] જેવી જ ભૂમિકા છે, જે Rust ના આ સંસ્કરણમાં અસ્થિર છે.
/// જ્યારે `!` સ્થિર થાય છે, ત્યારે અમે `Infallible` ને તેના માટે પ્રકારનો ઉપનામ બનાવવાની યોજના બનાવીએ છીએ:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …અને છેવટે `Infallible` ને અવમૂલ્યન કરો.
///
/// જો કે ત્યાં એક કેસ છે જ્યાં એક્સ 100 એક્સ સિન્ટેક્સનો ઉપયોગ `!` સંપૂર્ણ સુવિધાયુક્ત પ્રકાર તરીકે સ્થિર થાય તે પહેલાં થઈ શકે છે: ફંક્શનના રીટર્ન પ્રકારની સ્થિતિમાં.
/// ખાસ કરીને, તે બે અલગ અલગ ફંક્શન પોઇન્ટર પ્રકારો માટે શક્ય અમલીકરણો છે:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` એ enum હોવા સાથે, આ કોડ માન્ય છે.
/// જો કે જ્યારે `Infallible` એ never type માટે ઉપનામ બનશે, ત્યારે બે ઇમ્પલ્સ ઓવરલેપ થવાનું શરૂ થશે અને તેથી ભાષાના trait સુસંગતતા નિયમો દ્વારા તેને મંજૂરી આપવામાં આવશે નહીં.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}