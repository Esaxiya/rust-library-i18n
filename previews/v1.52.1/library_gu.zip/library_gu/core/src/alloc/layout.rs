use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// જ્યારે આ ફંક્શનનો ઉપયોગ એક જગ્યાએ કરવામાં આવે છે અને તેનો અમલ ઇનલાઈન થઈ શકે છે, આમ કરવાના પહેલાંના પ્રયત્નોએ ઝેડ ર્રસ્ટક0 ઝેડને ધીમું બનાવ્યું:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// મેમરીના બ્લોકનો લેઆઉટ.
///
/// `Layout` નો દાખલો મેમરીના ચોક્કસ લેઆઉટને વર્ણવે છે.
/// ફાળવણીકારને આપવા માટે તમે ઇનપુટ તરીકે એક `Layout` બનાવો.
///
/// બધા લેઆઉટમાં એક સંકળાયેલ કદ અને પાવર-ટુ-બે ગોઠવણી હોય છે.
///
/// (નોંધ લો કે લેઆઉટને * બિન-શૂન્ય કદ હોવું જરૂરી નથી, તેમ છતાં `GlobalAlloc` એ જરૂરી છે કે બધી મેમરી વિનંતીઓ કદમાં શૂન્ય ન હોય.
/// ક calલરને ક્યાં તેની ખાતરી કરવી આવશ્યક છે કે આ જેવી પરિસ્થિતિઓ પૂરી થાય છે, allocીલી આવશ્યકતાઓ સાથે વિશિષ્ટ ફાળવણીકારોનો ઉપયોગ કરો અથવા વધુ આરામદાયક `Allocator` ઇન્ટરફેસનો ઉપયોગ કરો.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // બાઇટ્સમાં માપેલ મેમરીના વિનંતી કરેલ બ્લોકનું કદ.
    size_: usize,

    // બાઇટ્સમાં માપેલા મેમરીના વિનંતી કરેલ બ્લોકનું સંરેખણ.
    // અમે સુનિશ્ચિત કરીએ છીએ કે આ હંમેશા પાવર twoફ-ટુ હોય છે, કારણ કે API ની જેમ `posix_memalign` ને તેની આવશ્યકતા હોય છે અને લેઆઉટ કન્સ્ટ્રકટરો પર લાદવું તે વાજબી અવરોધ છે.
    //
    //
    // (જો કે, અમને સમાનરૂપે `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) ની જરૂર નથી
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// આપેલ `size` અને `align` માંથી `Layout` બનાવે છે, અથવા જો નીચેની શરતોમાંથી કોઈ પણ પૂર્ણ ન થાય તો `LayoutError` આપે છે:
    ///
    /// * `align` શૂન્ય ન હોવો જોઈએ,
    ///
    /// * `align` બેની શક્તિ હોવી જ જોઇએ,
    ///
    /// * `size`, જ્યારે નજીકના બહુવિધ `align` સુધી ગોળાકાર હોય ત્યારે, ઓવરફ્લો ન થવો જોઈએ (એટલે કે, ગોળાકાર મૂલ્ય `usize::MAX` કરતા ઓછું અથવા તેના જેટલું હોવું જોઈએ).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (બેમાંથી પાવર એ સંરેખિત થાય છે!=0.)

        // ગોળાકાર અપ કદ છે:
        //   કદ_માળા_ઉપ=(કદ + સંરેખિત, 1)&! (સંરેખિત કરો, 1);
        //
        // આપણે ઉપરથી જાણીએ છીએ કે ગોઠવાયેલ છે!=0
        // જો ઉમેરવું (સંરેખિત કરો, 1) ઓવરફ્લો થતો નથી, તો પછી રાઉન્ડ અપ કરવું સારું રહેશે.
        //
        // તેનાથી ,લટું, અને-માસ્કિંગ! (સંરેખિત કરો, 1) ફક્ત નીચા-ઓર્ડર-બીટ્સને બાદબાકી કરશે.
        // આમ જો સરવાળો સાથે ઓવરફ્લો થાય છે, અને-માસ્ક તે ઓવરફ્લોને પૂર્વવત્ કરવા માટે પૂરતા બાદબાકી કરી શકશે નહીં.
        //
        //
        // ઉપર સૂચવે છે કે સારાંશના ઓવરફ્લો માટે તપાસવું એ બંને જરૂરી અને પૂરતા છે.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // સલામત: `from_size_align_unchecked` માટેની શરતો રહી છે
        // ઉપર તપાસ્યું.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// બધા તપાસોને બાયપાસ કરીને લેઆઉટ બનાવે છે.
    ///
    /// # Safety
    ///
    /// આ ફંક્શન અસુરક્ષિત છે કારણ કે તે [`Layout::from_size_align`] તરફથી પૂર્વતર્તાઓની ચકાસણી કરતું નથી.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // સલામતી: ક calલરે ખાતરી કરવી આવશ્યક છે કે `align` શૂન્ય કરતા વધારે છે.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// આ લેઆઉટના મેમરી બ્લોક માટે બાઇટ્સમાં ન્યૂનતમ કદ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// આ લેઆઉટના મેમરી બ્લોક માટે ન્યૂનતમ બાઇટ ગોઠવણી.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// પ્રકાર `T` ની કિંમત રાખવા માટે યોગ્ય `Layout` બનાવે છે.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // સલામતી: સંરેખનની ઝેડ 0 રસ્ટ0 ઝેડ દ્વારા બે અને ની શક્તિ હોવાની ખાતરી આપવામાં આવી છે
        // કદ + સંરેખિત ક comમ્બોની ખાતરી અમારી સરનામાંની જગ્યામાં ફિટ છે.
        // પરિણામે અહીં અનચેક કરેલા કન્સ્ટ્રક્ટરનો ઉપયોગ કરીને કોડ દાખલ કરવાનું ટાળવા માટે કે ઝેડપpanનિક્સ 0 ઝેડ જો તે સારી રીતે optimપ્ટિમાઇઝ થયેલ નથી.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (જે trait અથવા કોઈ સ્લાઇસ જેવા અન્ય બિનઆકાર્યક્ત પ્રકારનું હોઈ શકે છે) માટેનું બેકિંગ માળખું ફાળવવા માટે ઉપયોગમાં લેવાતા રેકોર્ડનું વર્ણન કરતી લેઆઉટનું ઉત્પાદન કરે છે.
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // સલામત: શા માટે આ અસુરક્ષિત ચલનો ઉપયોગ કરવામાં આવે છે તે માટે `new` માં તર્કસંગત જુઓ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (જે trait અથવા કોઈ સ્લાઇસ જેવા અન્ય બિનઆકાર્યક્ત પ્રકારનું હોઈ શકે છે) માટેનું બેકિંગ માળખું ફાળવવા માટે ઉપયોગમાં લેવાતા રેકોર્ડનું વર્ણન કરતી લેઆઉટનું ઉત્પાદન કરે છે.
    ///
    /// # Safety
    ///
    /// જો નીચેની શરતો હોલ્ડ કરે છે તો આ ફંક્શન ફક્ત ક callલ કરવા માટે સલામત છે:
    ///
    /// - જો `T` એ `Sized` છે, તો આ કાર્ય ક callલ કરવા માટે હંમેશા સલામત છે.
    /// - જો `T` ની અનઇસીઝ્ડ પૂંછડી છે:
    ///     - એક X01 એક્સ, પછી સ્લાઈસ પૂંછડીની લંબાઈ એક અંતર્ગત પૂર્ણાંક હોવી આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
    ///     - એક [trait object], પછી પોઇન્ટરનો વtટેબલ ભાગ કોઈ અનઇઝાઇઝિંગ કersર્સિઅન દ્વારા હસ્તગત `T` પ્રકાર માટે માન્ય વtટેબલ તરફ નિર્દેશ કરવો આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
    ///
    ///     - એક (unstable) [extern type], તો પછી આ ફંક્શન હંમેશાં ક callલ કરવા માટે સલામત છે, પરંતુ બાહ્ય પ્રકારનું લેઆઉટ જાણીતું ન હોવાથી, panic અથવા અન્યથા ખોટી કિંમત પરત કરી શકે છે.
    ///     બાહ્ય પ્રકારની પૂંછડીના સંદર્ભમાં [`Layout::for_value`] જેવું જ આ વર્તન છે.
    ///     - નહિંતર, રૂ conિચુસ્ત રીતે આ ફંક્શનને ક .લ કરવાની મંજૂરી નથી.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // સલામતી: અમે ક functionsલરને આ વિધેયોની પૂર્વજરૂરીયાતો સાથે પસાર કરીએ છીએ
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // સલામત: શા માટે આ અસુરક્ષિત ચલનો ઉપયોગ કરવામાં આવે છે તે માટે `new` માં તર્કસંગત જુઓ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ઝગઝગતું હોય તેવું એક `NonNull` બનાવે છે, પરંતુ આ લેઆઉટ માટે સારી રીતે ગોઠવાયેલ છે.
    ///
    /// નોંધ લો કે પોઇન્ટર મૂલ્ય સંભવિત રૂપે માન્ય પોઇન્ટરનું પ્રતિનિધિત્વ કરી શકે છે, જેનો અર્થ છે કે આનો ઉપયોગ "not yet initialized" સેન્ટિનેલ મૂલ્ય તરીકે થવો જોઈએ નહીં.
    /// પ્રકારો કે જે આળસુધીથી ફાળવે છે તે કેટલાક અન્ય માધ્યમથી પ્રારંભિકરણને ટ્ર trackક કરવું જોઈએ.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // સલામતી: સંરેખણ એ શૂન્ય નહીં હોવાની ખાતરી આપવામાં આવે છે
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` જેવા સમાન લેઆઉટનું મૂલ્ય રાખી શકે તેવા રેકોર્ડનું વર્ણન કરતી એક લેઆઉટ બનાવે છે, પરંતુ તે સંરેખણ `align` (બાઇટ્સમાં માપવામાં આવે છે) માટે પણ ગોઠવાયેલ છે.
    ///
    ///
    /// જો `self` પહેલાથી સૂચવેલ ગોઠવણીને પૂર્ણ કરે છે, તો પછી `self` આપે છે.
    ///
    /// નોંધ કરો કે પરત લેઆઉટને અલગ ગોઠવણી છે કે કેમ તે ધ્યાનમાં લીધા વિના, આ પદ્ધતિ એકંદર કદમાં કોઈ પેડિંગ ઉમેરતી નથી.
    /// બીજા શબ્દોમાં કહીએ તો, જો `K` નું કદ 16 છે, તો `K.align_to(32)`*હજી પણ* કદ 16 હશે.
    ///
    /// જો `self.size()` અને આપેલ `align` નું સંયોજન [`Layout::from_size_align`] માં સૂચિબદ્ધ શરતોનું ઉલ્લંઘન કરે તો ભૂલ આપે છે.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// નીચે આપેલ સરનામું `align` (બાઇટ્સમાં માપવામાં આવે છે) ને સંતોષશે તેની ખાતરી કરવા માટે અમે `self` પછી ઉમેરવું આવશ્યક છે તે પેડિંગની રકમ પરત કરે છે.
    ///
    /// દા.ત., જો `self.size()` 9 છે, તો `self.padding_needed_for(4)` 3 આપે છે, કારણ કે તે 4-ગોઠવાયેલ સરનામું મેળવવા માટે જરૂરી પેડિંગના બાઇટ્સની ન્યૂનતમ સંખ્યા છે (ધારે છે કે અનુરૂપ મેમરી બ્લ blockક 4-ગોઠવાયેલા સરનામાંથી પ્રારંભ થાય છે).
    ///
    ///
    /// જો `align` એ પાવર-ઓફ-ટુ ન હોય તો આ ફંક્શનના વળતર મૂલ્યનો કોઈ અર્થ નથી.
    ///
    /// નોંધ લો કે પરત કરેલ મૂલ્યની ઉપયોગિતાએ મેમરીના આખા ફાળવેલ બ્લોક માટે પ્રારંભિક સરનામાંની ગોઠવણી કરતા `align` નીચી અથવા ઓછી હોવી જરૂરી છે.આ અવરોધને સંતોષવાની એક રીત છે `align <= self.align()` ની ખાતરી કરવી.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // રાઉન્ડ અપ વેલ્યુ છે:
        //   len_rounded_up=(len + align, 1)&! (સંરેખિત કરો, 1);
        // અને પછી અમે પેડિંગનો તફાવત પાછો આપીશું: `len_rounded_up - len`.
        //
        // અમે દરમ્યાન મોડ્યુલર અંકગણિતનો ઉપયોગ કરીએ છીએ:
        //
        // 1. સંરેખિત>> 0 હોવાની ખાતરી આપવામાં આવે છે, તેથી સંરેખિત કરો, 1 હંમેશાં માન્ય છે.
        //
        // 2.
        // `len + align - 1` વધુમાં વધુ `align - 1` દ્વારા ઓવરફ્લો થઈ શકે છે, તેથી `!(align - 1)` સાથે&-માસ્ક ખાતરી કરશે કે ઓવરફ્લોના કિસ્સામાં, `len_rounded_up` પોતે 0 હશે.
        //
        //    આમ પાછા ફરતા ગાદી, જ્યારે એક્સ 01 એક્સમાં ઉમેરવામાં આવે છે, ત્યારે 0 મળે છે, જે ક્ષણિક ગોઠવણી `align` ને સંતોષે છે.
        //
        // (અલબત્ત, મેમરીના બ્લોક્સની ફાળવણીના પ્રયત્નો જેના કદ અને પેડિંગ ઓવરફ્લો ઉપરની રીતમાં ફાળવણીકારને કોઈપણ રીતે ભૂલ પેદા કરવા જોઈએ.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// આ લેઆઉટના કદને લેઆઉટના ગોઠવણીના બહુવિધ સુધી ગોળાકાર કરીને એક લેઆઉટ બનાવે છે.
    ///
    ///
    /// આ લેઆઉટના વર્તમાન કદમાં `padding_needed_for` નું પરિણામ ઉમેરવા સમાન છે.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // આ ઓવરફ્લો થઈ શકશે નહીં.લેઆઉટના આક્રમણક તરફથી અવતરણ:
        // > `size`, જ્યારે `align` ની નજીકના બહુવિધ સુધીનો ગોળાકાર હોય,
        // > ઓવરફ્લો ન થવું જોઈએ (દા.ત., ગોળાકાર મૂલ્ય કરતા ઓછું હોવું જોઈએ
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` ના `n` દાખલાઓ માટેના રેકોર્ડનું વર્ણન કરતું લેઆઉટ બનાવે છે, દરેકની વચ્ચે યોગ્ય પ્રમાણમાં પેડિંગ તેની ખાતરી કરવા માટે કે દરેક દાખલાને તેના વિનંતી કરેલ કદ અને ગોઠવણી આપવામાં આવે છે.
    /// સફળતા પર, `(k, offs)` આપે છે જ્યાં `k` એ એરેનું લેઆઉટ છે અને `offs` એ એરેમાંના દરેક તત્વની શરૂઆત વચ્ચેનું અંતર છે.
    ///
    /// અંકગણિત ઓવરફ્લો પર, `LayoutError` આપે છે.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // આ ઓવરફ્લો થઈ શકશે નહીં.લેઆઉટના આક્રમણક તરફથી અવતરણ:
        // > `size`, જ્યારે `align` ની નજીકના બહુવિધ સુધીનો ગોળાકાર હોય,
        // > ઓવરફ્લો ન થવું જોઈએ (દા.ત., ગોળાકાર મૂલ્ય કરતા ઓછું હોવું જોઈએ
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // સલામતી: self.align પહેલેથી જ માન્ય હોવાનું માનવામાં આવે છે અને એલાયક_સાઇઝ કરવામાં આવ્યું છે
        // ગાદીવાળાં.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` પછીના રેકોર્ડનું વર્ણન આપતું લેઆઉટ બનાવે છે, ત્યારબાદ `next` યોગ્ય રીતે ગોઠવાયેલ છે તેની ખાતરી કરવા માટે કોઈપણ આવશ્યક પેડિંગનો સમાવેશ થાય છે, પરંતુ *કોઈ પાછળનું પેડિંગ નથી*.
    ///
    /// સી રજૂઆત લેઆઉટ `repr(C)` સાથે મેળ કરવા માટે, તમારે બધા ક્ષેત્રો સાથે લેઆઉટને વિસ્તૃત કર્યા પછી `pad_to_align` પર ક callલ કરવો જોઈએ.
    /// (ડિફ defaultલ્ટ Rust પ્રતિનિધિત્વ લેઆઉટ `repr(Rust)`, as it is unspecified.) સાથે મેળ કરવાની કોઈ રીત નથી
    ///
    /// નોંધો કે બંને ભાગોની ગોઠવણી સુનિશ્ચિત કરવા માટે પરિણામી લેઆઉટની ગોઠવણી એ `self` અને `next` ની મહત્તમ હશે.
    ///
    /// `Ok((k, offset))` આપે છે, જ્યાં `k` એ કatenન્ક્ટેટેડ રેકોર્ડનું લેઆઉટ છે અને `offset` એ ક relativeંકેટેડ રેકોર્ડમાં જડિત `next` ની શરૂઆતનું સંબંધિત સ્થાન છે, (ધારે છે કે રેકોર્ડ પોતે offફસેટ 0 થી શરૂ થાય છે).
    ///
    ///
    /// અંકગણિત ઓવરફ્લો પર, `LayoutError` આપે છે.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` સ્ટ્રક્ચરના લેઆઉટ અને તેના ફીલ્ડ્સના લેઆઉટમાંથી ફીલ્ડ્સના seફસેટ્સની ગણતરી કરવા માટે:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` સાથે અંતિમ બનાવવાનું યાદ રાખો!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // પરીક્ષણ કરો કે તે કામ કરે છે
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` ના `n` દાખલાઓ માટેના રેકોર્ડનું વર્ણન કરતું લેઆઉટ બનાવે છે, જેમાં દરેક ઘટક વચ્ચે કોઈ ગાદી નથી.
    ///
    /// નોંધ લો કે, `repeat` થી વિપરીત, `repeat_packed` એ બાંહેધરી આપતું નથી કે `self` નાં પુનરાવર્તિત ઉદાહરણો યોગ્ય રીતે ગોઠવવામાં આવશે, પછી ભલે `self` નું આપેલ દાખલો યોગ્ય રીતે ગોઠવાયેલ હોય.
    /// બીજા શબ્દોમાં કહીએ તો, જો `repeat_packed` દ્વારા પરત થયેલ લેઆઉટનો ઉપયોગ એરે ફાળવવા માટે કરવામાં આવે છે, તો એ બાંયધરી આપવામાં આવતી નથી કે એરેમાંના બધા ઘટકો યોગ્ય રીતે ગોઠવવામાં આવશે.
    ///
    /// અંકગણિત ઓવરફ્લો પર, `LayoutError` આપે છે.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// બંને વચ્ચે કોઈ વધારાના ગાદી વગર `next` પછી `self` નો રેકોર્ડ વર્ણવતા લેઆઉટ બનાવે છે.
    /// કોઈ પેડિંગ શામેલ કરવામાં આવતું ન હોવાથી, `next` નું સંરેખણ અપ્રસ્તુત છે, અને પરિણામી લેઆઉટમાં * ** સમાયેલું નથી.
    ///
    ///
    /// અંકગણિત ઓવરફ્લો પર, `LayoutError` આપે છે.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` માટેના રેકોર્ડનું વર્ણન કરતી લેઆઉટ બનાવે છે.
    ///
    /// અંકગણિત ઓવરફ્લો પર, `LayoutError` આપે છે.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` અથવા કેટલાક અન્ય `Layout` કન્સ્ટ્રક્ટરને આપેલા પરિમાણો તેની દસ્તાવેજીકરણની મર્યાદાઓને સંતોષતા નથી.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ઝેડટ્રેટ0 ઝેડ ભૂલના ડાઉનસ્ટ્રીમ પ્રોમ્પ્લ માટે અમને આની જરૂર છે)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}