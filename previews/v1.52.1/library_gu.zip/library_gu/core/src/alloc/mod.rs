//! મેમરી ફાળવણી API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` ભૂલ એ ફાળવણી નિષ્ફળતાને સૂચવે છે જે આ ફાળવણીકાર સાથે આપેલ ઇનપુટ દલીલોને સંયોજિત કરતી વખતે સંસાધન થાકને લીધે અથવા કંઈક ખોટું થઈ શકે છે.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ઝેડટ્રેટ0 ઝેડ ભૂલના ડાઉનસ્ટ્રીમ પ્રોમ્પ્લ માટે અમને આની જરૂર છે)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` નું અમલીકરણ, [`Layout`][] દ્વારા વર્ણવેલ ડેટાના મનસ્વી બ્લોક્સને ફાળવણી, વૃદ્ધિ, સંકોચન અને ડિલવોકેટ કરી શકે છે.
///
/// `Allocator` ઝેડએસટીએસ, સંદર્ભો અથવા સ્માર્ટ પોઇંટર્સ પર અમલ કરવા માટે રચાયેલ છે કારણ કે ફાળવવામાં આવેલી મેમરીમાં પોઇંટર્સને અપડેટ કર્યા વિના, `MyAlloc([u8; N])` જેવા ફાળવણીકારને ખસેડી શકાતા નથી.
///
/// [`GlobalAlloc`][] થી વિપરીત, `Allocator` માં શૂન્ય કદના ફાળવણીની મંજૂરી છે.
/// જો અંતર્ગત ફાળવણીકાર આને (જેમલ્લોકની જેમ) ટેકો આપતું નથી અથવા નલ પોઇન્ટર (જેમ કે `libc::malloc`) પાછું આપતું નથી, તો આ અમલીકરણ દ્વારા પકડવું આવશ્યક છે.
///
/// ### હાલમાં ફાળવેલ મેમરી
///
/// કેટલીક પદ્ધતિઓ માટે જરૂરી છે કે ફાળવણીકાર દ્વારા મેમરી બ્લોક *હાલમાં ફાળવવામાં આવે*.આનો અર્થ એ છે કે:
///
/// * તે મેમરી બ્લ blockક માટે પ્રારંભિક સરનામું પહેલાં [`allocate`], [`grow`], અથવા [`shrink`], અને દ્વારા પરત કરવામાં આવ્યું હતું
///
/// * પછીથી મેમરી બ્લ subseકને ડીલોલિકેટ કરવામાં આવ્યું નથી, જ્યાં બ્લોક્સ કાં તો સીધા [`deallocate`] પર પસાર કરીને ડિલોલિકેટ થઈ જાય છે અથવા [`grow`] અથવા [`shrink`] પર પસાર કરીને બદલાયા હતા જે `Ok` આપે છે.
///
/// જો `grow` અથવા `shrink` એ `Err` પાછા ફર્યા છે, તો પસાર કરેલો પોઇન્ટર માન્ય રહેશે.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### મેમરી ફિટિંગ
///
/// કેટલીક પદ્ધતિઓ માટે લેઆઉટ *ફીટ* મેમરી બ્લોક આવશ્યક છે.
/// "fit" ના લેઆઉટ માટે મેમરી બ્લ aકનો અર્થ શું છે (અથવા સમાન રીતે, "fit" પર મેમરી બ્લ blockક માટે લેઆઉટ) એ નીચેની શરતો હોવી આવશ્યક છે:
///
/// * [`layout.align()`] ની સમાન ગોઠવણી સાથે અવરોધિત થવું આવશ્યક છે, અને
///
/// * પ્રદાન થયેલ [`layout.size()`] એ `min ..= max` ની રેન્જમાં આવવું જોઈએ, જ્યાં:
///   - `min` બ્લોક ફાળવવા માટે તાજેતરમાં વપરાયેલ લેઆઉટનું કદ છે, અને
///   - `max` [`allocate`], [`grow`], અથવા [`shrink`] થી પરત થયેલ નવીનતમ વાસ્તવિક કદ છે.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ફાળવણીકાર પાસેથી પરત થયેલ મેમરી બ્લોક્સએ માન્ય મેમરી તરફ નિર્દેશ કરવો આવશ્યક છે અને દાખલા અને તેના બધા ક્લોન્સને ન પડે ત્યાં સુધી તેમની માન્યતા જાળવી રાખવી જોઈએ,
///
/// * ક્લોનીંગ અથવા ફાળવણીકારને ખસેડવું આ ફાળવણીકારમાંથી પાછા ફરતા મેમરી બ્લોક્સને અમાન્ય કરતું નથીક્લોન ફાળવણી કરનારને સમાન ફાળવણીકારની જેમ વર્તવું જોઈએ, અને
///
/// * મેમરી બ્લોક પરનો કોઈપણ નિર્દેશક જે [*currently allocated*] છે તે ફાળવણીકારની કોઈપણ અન્ય પદ્ધતિમાં પસાર થઈ શકે છે.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// મેમરીનો બ્લોક ફાળવવાનો પ્રયાસ.
    ///
    /// સફળતા પર, `layout` ની કદ અને સંરેખણ બાંયધરીઓને પૂર્ણ કરતા [`NonNull<[u8]>`][NonNull] આપે છે.
    ///
    /// પરત કરેલ બ્લોકમાં `layout.size()` દ્વારા ઉલ્લેખિત કરતા મોટો કદ હોઈ શકે છે, અને તેની સમાવિષ્ટ શરૂ થઈ શકે છે અથવા હોઈ શકે છે.
    ///
    /// # Errors
    ///
    /// રીટર્નિંગ `Err` સૂચવે છે કે કાં તો મેમરી ખલાસ થઈ ગઈ છે અથવા `layout` ફાળવણીકારના કદ અથવા ગોઠવણી અવરોધોને પૂર્ણ કરતું નથી.
    ///
    /// અમલીકરણોને ગભરાવવા અથવા ગર્ભપાત કરવાને બદલે મેમરી ખાલી થવા પર `Err` પાછા આપવાનું પ્રોત્સાહન આપવામાં આવે છે, પરંતુ આ કડક આવશ્યકતા નથી.
    /// (વિશિષ્ટરૂપે: મેમરી ઝંખના પર બંધ મૂકેલા અંતર્ગત મૂળ ફાળવણી લાઇબ્રેરીની ઉપર આ ઝેડટ્રેટ 0 ઝેડનો અમલ કરવો *કાનૂની* છે.)
    ///
    /// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા માંગતા ગ્રાહકોએ સીધા `panic!` અથવા તેના જેવા જ સીધા આયોગને બદલે [`handle_alloc_error`] ફંક્શનને ક callલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` જેવા વર્તન કરે છે, પણ ખાતરી કરે છે કે પરત થયેલ મેમરી શૂન્ય-પ્રારંભિક છે.
    ///
    /// # Errors
    ///
    /// રીટર્નિંગ `Err` સૂચવે છે કે કાં તો મેમરી ખલાસ થઈ ગઈ છે અથવા `layout` ફાળવણીકારના કદ અથવા ગોઠવણી અવરોધોને પૂર્ણ કરતું નથી.
    ///
    /// અમલીકરણોને ગભરાવવા અથવા ગર્ભપાત કરવાને બદલે મેમરી ખાલી થવા પર `Err` પાછા આપવાનું પ્રોત્સાહન આપવામાં આવે છે, પરંતુ આ કડક આવશ્યકતા નથી.
    /// (વિશિષ્ટરૂપે: મેમરી ઝંખના પર બંધ મૂકેલા અંતર્ગત મૂળ ફાળવણી લાઇબ્રેરીની ઉપર આ ઝેડટ્રેટ 0 ઝેડનો અમલ કરવો *કાનૂની* છે.)
    ///
    /// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા માંગતા ગ્રાહકોએ સીધા `panic!` અથવા તેના જેવા જ સીધા આયોગને બદલે [`handle_alloc_error`] ફંક્શનને ક callલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // સલામતી: `alloc` માન્ય મેમરી બ્લ blockક આપે છે
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` દ્વારા સંદર્ભિત મેમરીને ડિલોક કરે છે.
    ///
    /// # Safety
    ///
    /// * `ptr` આ ફાળવણીકાર દ્વારા મેમરી [*currently allocated*] નો અવરોધ દર્શાવવો આવશ્યક છે, અને
    /// * `layout` [*fit*] હોવું જોઈએ કે જે મેમરીનો અવરોધે છે.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// મેમરી બ્લ blockકને વધારવાનો પ્રયાસ.
    ///
    /// નિર્દેશક અને ફાળવેલ મેમરીનું વાસ્તવિક કદ ધરાવતું નવું [`NonNull<[u8]>`][NonNull] આપે છે.`new_layout` દ્વારા વર્ણવેલ ડેટાને રાખવા માટે નિર્દેશક યોગ્ય છે.
    /// આ પરિપૂર્ણ કરવા માટે, ફાળવણીકાર નવા લેઆઉટને ફિટ કરવા માટે `ptr` દ્વારા સંદર્ભિત ફાળવણીમાં વધારો કરી શકે છે.
    ///
    /// જો આ `Ok` આપે છે, તો `ptr` દ્વારા સંદર્ભિત મેમરી બ્લોકની માલિકી આ ફાળવણીકારને સ્થાનાંતરિત કરવામાં આવી છે.
    /// મેમરી મુક્ત થઈ શકે છે અથવા ન હોઈ શકે, અને આ પદ્ધતિના વળતર મૂલ્ય દ્વારા ફરીથી કlerલરને સ્થાનાંતરિત ન કરવામાં આવે ત્યાં સુધી તેને બિનઉપયોગી માનવું જોઈએ.
    ///
    /// જો આ પદ્ધતિ `Err` પરત કરે છે, તો પછી મેમરી બ્લોકની માલિકી આ ફાળવણીકારને સ્થાનાંતરિત કરવામાં આવી નથી, અને મેમરી બ્લોકની સામગ્રી અનલિટર થયેલ છે.
    ///
    /// # Safety
    ///
    /// * `ptr` આ ફાળવણીકાર દ્વારા મેમરી [*currently allocated*] નો બ્લોક સૂચવો આવશ્યક છે.
    /// * `old_layout` [*fit*] એ મેમરીનું અવરોધિત કરવું આવશ્યક છે (`new_layout` દલીલ તેને ફીટ કરવાની જરૂર નથી.)
    /// * `new_layout.size()` `old_layout.size()` કરતા વધારે અથવા બરાબર હોવું જોઈએ.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// જો નવું લેઆઉટ ફાળવણીકારના કદ અને ગોઠવણીની મર્યાદાઓને પૂર્ણ કરતું નથી, અથવા વધતી અન્યથા નિષ્ફળ જાય તો `Err` આપે છે.
    ///
    /// અમલીકરણોને ગભરાવવા અથવા ગર્ભપાત કરવાને બદલે મેમરી ખાલી થવા પર `Err` પાછા આપવાનું પ્રોત્સાહન આપવામાં આવે છે, પરંતુ આ કડક આવશ્યકતા નથી.
    /// (વિશિષ્ટરૂપે: મેમરી ઝંખના પર બંધ મૂકેલા અંતર્ગત મૂળ ફાળવણી લાઇબ્રેરીની ઉપર આ ઝેડટ્રેટ 0 ઝેડનો અમલ કરવો *કાનૂની* છે.)
    ///
    /// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા માંગતા ગ્રાહકોએ સીધા `panic!` અથવા તેના જેવા જ સીધા આયોગને બદલે [`handle_alloc_error`] ફંક્શનને ક callલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // સલામતી: કારણ કે `new_layout.size()` તેના કરતા વધારે અથવા સમાન હોવું આવશ્યક છે
        // `old_layout.size()`, બંને જૂની અને નવી મેમરી ફાળવણી `old_layout.size()` બાઇટ્સ માટે વાંચવા અને લખવા માટે માન્ય છે.
        // ઉપરાંત, કારણ કે જૂની ફાળવણી હજી ડિલોડેક્ટેડ નહોતી, તે `new_ptr` ને ઓવરલેપ કરી શકશે નહીં.
        // આમ, `copy_nonoverlapping` પર ક callલ સલામત છે.
        // ક00લર દ્વારા `dealloc` માટે સલામતી કરાર હોવો જ જોઇએ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` જેવા વર્તન કરે છે, પણ ખાતરી કરે છે કે પરત આવે તે પહેલાં નવી સામગ્રી સમાવિષ્ટ થઈ છે.
    ///
    /// સફળ ક callલ કર્યા પછી મેમરી બ્લ blockકમાં નીચેની સામગ્રી શામેલ હશે
    /// `grow_zeroed`:
    ///   * બાઇટ્સ `0..old_layout.size()` એ મૂળ ફાળવણીથી સુરક્ષિત છે.
    ///   * બાઇટ્સ `old_layout.size()..old_size` ક્યાં તો સાચવેલ અથવા શૂન્ય રહેશે, ફાળવણીકારના અમલીકરણના આધારે.
    ///   `old_size` `grow_zeroed` ક callલ પહેલાં મેમરી બ્લોકના કદનો સંદર્ભ આપે છે, જે ફાળવણી કરવામાં આવી ત્યારે મૂળ વિનંતી કરાયેલ કદ કરતા વધારે હોઈ શકે.
    ///   * બાઇટ્સ `old_size..new_size` શૂન્ય છે.`new_size` એ `grow_zeroed` ક callલ દ્વારા પરત કરેલા મેમરી બ્લોકના કદનો સંદર્ભ આપે છે.
    ///
    /// # Safety
    ///
    /// * `ptr` આ ફાળવણીકાર દ્વારા મેમરી [*currently allocated*] નો બ્લોક સૂચવો આવશ્યક છે.
    /// * `old_layout` [*fit*] એ મેમરીનું અવરોધિત કરવું આવશ્યક છે (`new_layout` દલીલ તેને ફીટ કરવાની જરૂર નથી.)
    /// * `new_layout.size()` `old_layout.size()` કરતા વધારે અથવા બરાબર હોવું જોઈએ.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// જો નવું લેઆઉટ ફાળવણીકારના કદ અને ગોઠવણીની મર્યાદાઓને પૂર્ણ કરતું નથી, અથવા વધતી અન્યથા નિષ્ફળ જાય તો `Err` આપે છે.
    ///
    /// અમલીકરણોને ગભરાવવા અથવા ગર્ભપાત કરવાને બદલે મેમરી ખાલી થવા પર `Err` પાછા આપવાનું પ્રોત્સાહન આપવામાં આવે છે, પરંતુ આ કડક આવશ્યકતા નથી.
    /// (વિશિષ્ટરૂપે: મેમરી ઝંખના પર બંધ મૂકેલા અંતર્ગત મૂળ ફાળવણી લાઇબ્રેરીની ઉપર આ ઝેડટ્રેટ 0 ઝેડનો અમલ કરવો *કાનૂની* છે.)
    ///
    /// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા માંગતા ગ્રાહકોએ સીધા `panic!` અથવા તેના જેવા જ સીધા આયોગને બદલે [`handle_alloc_error`] ફંક્શનને ક callલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // સલામતી: કારણ કે `new_layout.size()` તેના કરતા વધારે અથવા સમાન હોવું આવશ્યક છે
        // `old_layout.size()`, બંને જૂની અને નવી મેમરી ફાળવણી `old_layout.size()` બાઇટ્સ માટે વાંચવા અને લખવા માટે માન્ય છે.
        // ઉપરાંત, કારણ કે જૂની ફાળવણી હજી ડિલોડેક્ટેડ નહોતી, તે `new_ptr` ને ઓવરલેપ કરી શકશે નહીં.
        // આમ, `copy_nonoverlapping` પર ક callલ સલામત છે.
        // ક00લર દ્વારા `dealloc` માટે સલામતી કરાર હોવો જ જોઇએ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// મેમરી બ્લોકને સંકોચો કરવાનો પ્રયાસ.
    ///
    /// નિર્દેશક અને ફાળવેલ મેમરીનું વાસ્તવિક કદ ધરાવતું નવું [`NonNull<[u8]>`][NonNull] આપે છે.`new_layout` દ્વારા વર્ણવેલ ડેટાને રાખવા માટે નિર્દેશક યોગ્ય છે.
    /// આને પરિપૂર્ણ કરવા માટે, નવા લેઆઉટને ફિટ કરવા માટે, ફાળવણીકાર `ptr` દ્વારા સંદર્ભિત ફાળવણીને સંકોચાઈ શકે છે.
    ///
    /// જો આ `Ok` આપે છે, તો `ptr` દ્વારા સંદર્ભિત મેમરી બ્લોકની માલિકી આ ફાળવણીકારને સ્થાનાંતરિત કરવામાં આવી છે.
    /// મેમરી મુક્ત થઈ શકે છે અથવા ન હોઈ શકે, અને આ પદ્ધતિના વળતર મૂલ્ય દ્વારા ફરીથી કlerલરને સ્થાનાંતરિત ન કરવામાં આવે ત્યાં સુધી તેને બિનઉપયોગી માનવું જોઈએ.
    ///
    /// જો આ પદ્ધતિ `Err` પરત કરે છે, તો પછી મેમરી બ્લોકની માલિકી આ ફાળવણીકારને સ્થાનાંતરિત કરવામાં આવી નથી, અને મેમરી બ્લોકની સામગ્રી અનલિટર થયેલ છે.
    ///
    /// # Safety
    ///
    /// * `ptr` આ ફાળવણીકાર દ્વારા મેમરી [*currently allocated*] નો બ્લોક સૂચવો આવશ્યક છે.
    /// * `old_layout` [*fit*] એ મેમરીનું અવરોધિત કરવું આવશ્યક છે (`new_layout` દલીલ તેને ફીટ કરવાની જરૂર નથી.)
    /// * `new_layout.size()` `old_layout.size()` કરતા નાનું અથવા તેના જેટલું હોવું જોઈએ.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// જો નવું લેઆઉટ ફાળવણીકારના કદ અને ગોઠવણીની મર્યાદાઓને પૂર્ણ કરતું નથી, અથવા જો સંકોચો તો નિષ્ફળ જાય તો `Err` પરત કરે છે.
    ///
    /// અમલીકરણોને ગભરાવવા અથવા ગર્ભપાત કરવાને બદલે મેમરી ખાલી થવા પર `Err` પાછા આપવાનું પ્રોત્સાહન આપવામાં આવે છે, પરંતુ આ કડક આવશ્યકતા નથી.
    /// (વિશિષ્ટરૂપે: મેમરી ઝંખના પર બંધ મૂકેલા અંતર્ગત મૂળ ફાળવણી લાઇબ્રેરીની ઉપર આ ઝેડટ્રેટ 0 ઝેડનો અમલ કરવો *કાનૂની* છે.)
    ///
    /// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા માંગતા ગ્રાહકોએ સીધા `panic!` અથવા તેના જેવા જ સીધા આયોગને બદલે [`handle_alloc_error`] ફંક્શનને ક callલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // સલામતી: કારણ કે `new_layout.size()` તેના કરતા નીચું અથવા સમાન હોવું આવશ્યક છે
        // `old_layout.size()`, બંને જૂની અને નવી મેમરી ફાળવણી `new_layout.size()` બાઇટ્સ માટે વાંચવા અને લખવા માટે માન્ય છે.
        // ઉપરાંત, કારણ કે જૂની ફાળવણી હજી ડિલોડેક્ટેડ નહોતી, તે `new_ptr` ને ઓવરલેપ કરી શકશે નહીં.
        // આમ, `copy_nonoverlapping` પર ક callલ સલામત છે.
        // ક00લર દ્વારા `dealloc` માટે સલામતી કરાર હોવો જ જોઇએ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` ના આ દાખલા માટે "by reference" એડેપ્ટર બનાવે છે.
    ///
    /// પરત થયેલ એડેપ્ટર પણ `Allocator` લાગુ કરે છે અને આ ઉધાર લેશે.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // સલામતી: સલામતી કરાર ક .લર દ્વારા સમર્થન આપવું આવશ્યક છે
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // સલામતી: સલામતી કરાર ક .લર દ્વારા સમર્થન આપવું આવશ્યક છે
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // સલામતી: સલામતી કરાર ક .લર દ્વારા સમર્થન આપવું આવશ્યક છે
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // સલામતી: સલામતી કરાર ક .લર દ્વારા સમર્થન આપવું આવશ્યક છે
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}