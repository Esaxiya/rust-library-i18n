//! ફોર્મેટિંગ અને પ્રિન્ટિંગ તાર માટેની ઉપયોગિતાઓ.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// સંભવિત ગોઠવણીઓ `Formatter::align` દ્વારા પરત આવી
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// સૂચવે છે કે સમાવિષ્ટો ડાબી બાજુ ગોઠવાયેલ હોવી જોઈએ.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// સૂચવે છે કે સમાવિષ્ટો જમણી બાજુ ગોઠવાયેલી હોવી જોઈએ.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// સૂચવે છે કે સમાવિષ્ટો કેન્દ્રમાં ગોઠવાયેલ હોવા જોઈએ.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// પ્રકાર ફોર્મેટર પદ્ધતિઓ દ્વારા પાછો ફર્યો.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ભૂલનો પ્રકાર જે સંદેશને પ્રવાહમાં ફોર્મેટ કરવાથી પરત આવે છે.
///
/// આ પ્રકાર ભૂલ હોવા સિવાયની ભૂલના ટ્રાન્સમિશનને ટેકો આપતો નથી.
/// કોઈપણ અતિરિક્ત માહિતીને કેટલાક અન્ય માધ્યમથી પ્રસારિત કરવાની ગોઠવણ કરવી આવશ્યક છે.
///
/// યાદ રાખવાની એક અગત્યની બાબત એ છે કે પ્રકાર `fmt::Error` એ [`std::io::Error`] અથવા [`std::error::Error`] સાથે મૂંઝવણમાં ન હોવો જોઈએ, જે તમારી અવકાશમાં પણ હોઈ શકે છે.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// યુનિકોડ સ્વીકારતા બફર્સ અથવા સ્ટ્રીમ્સમાં લખવા અથવા ફોર્મેટિંગ કરવા માટેનું એક ઝેડ 0 ટ્રેટ 0 ઝેડ.
///
/// આ trait ફક્ત UTF-8 - એન્કોડ કરેલા ડેટાને સ્વીકારે છે અને [flushable] નથી.
/// જો તમે ફક્ત યુનિકોડ સ્વીકારવા માંગો છો અને તમારે ફ્લશિંગની જરૂર નથી, તો તમારે આ ઝેડ 0 ટ્રેટ 0 ઝેડ અમલમાં મૂકવું જોઈએ;
/// અન્યથા તમારે [`std::io::Write`] લાગુ કરવું જોઈએ.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// આ લેખકની એક શબ્દમાળાની કટકો લખી આપે છે, લખાણ સફળ થયું કે કેમ તે પરત.
    ///
    /// આ પદ્ધતિ ફક્ત ત્યારે જ સફળ થઈ શકે છે જો સંપૂર્ણ શબ્દમાળાની કટકા સફળતાપૂર્વક લખવામાં આવી હોય, અને જ્યાં સુધી તમામ ડેટા લખવામાં ન આવે અથવા ભૂલ ન થાય ત્યાં સુધી આ પદ્ધતિ પાછા આવશે નહીં.
    ///
    ///
    /// # Errors
    ///
    /// આ કાર્ય ભૂલ પર [`Error`] નો દાખલો પાછો આપશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// આ લેખકમાં [`char`] લખે છે, લખાણ સફળ થયું કે કેમ તે પરત ફર્યા.
    ///
    /// એકલ [`char`] એક કરતા વધુ બાઇટ્સ તરીકે એન્કોડ થઈ શકે છે.
    /// આ પદ્ધતિ ફક્ત ત્યારે જ સફળ થઈ શકે છે જો સંપૂર્ણ બાઇટ અનુક્રમ સફળતાપૂર્વક લખવામાં આવ્યો હોય, અને જ્યાં સુધી તમામ ડેટા લખવામાં ન આવે અથવા ભૂલ ન થાય ત્યાં સુધી આ પદ્ધતિ પાછા આવશે નહીં.
    ///
    ///
    /// # Errors
    ///
    /// આ કાર્ય ભૂલ પર [`Error`] નો દાખલો પાછો આપશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// આ trait ના અમલીકરણ સાથે [`write!`] મેક્રોના ઉપયોગ માટે ગુંદર.
    ///
    /// આ પદ્ધતિને સામાન્ય રીતે જાતે જ બોલાવવી જોઈએ નહીં, પરંતુ પોતે [`write!`] મેક્રો દ્વારા.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ફોર્મેટિંગ માટે રૂપરેખાંકન.
///
/// એક `Formatter` ફોર્મેટિંગથી સંબંધિત વિવિધ વિકલ્પોનું પ્રતિનિધિત્વ કરે છે.
/// વપરાશકર્તાઓ `ફોર્મેટર્સ સીધા બાંધતા નથી;એકનો પરિવર્તનીય સંદર્ભ, [`Debug`] અને [`Display`] જેવા, બધા ફોર્મેટિંગ traits ની `fmt` પદ્ધતિમાં પસાર થાય છે.
///
///
/// `Formatter` સાથે ક્રિયાપ્રતિક્રિયા કરવા માટે, તમે ફોર્મેટિંગથી સંબંધિત વિવિધ વિકલ્પો બદલવા માટે વિવિધ પદ્ધતિઓનો ક callલ કરશો.
/// ઉદાહરણો માટે, કૃપા કરીને નીચે `Formatter` પર નિર્ધારિત પદ્ધતિઓનાં દસ્તાવેજીકરણ જુઓ.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// દલીલ એ અનિવાર્યપણે એક optimપ્ટિમાઇઝ આંશિક રીતે લાગુ ફોર્મેટિંગ ફંક્શન છે, જે `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ની સમકક્ષ છે.

extern "C" {
    type Opaque;
}

/// આ માળખું સામાન્ય "argument" નું પ્રતિનિધિત્વ કરે છે જે વિધેયોના એક્સપ્રિન્ટફ પરિવાર દ્વારા લેવામાં આવે છે.તેમાં આપેલ મૂલ્યને ફોર્મેટ કરવા માટે એક કાર્ય છે.
/// સંકલન સમયે, ખાતરી કરવામાં આવે છે કે ફંકશન અને મૂલ્યમાં યોગ્ય પ્રકારો છે, અને પછી આ સ્ટ્રક્ટનો ઉપયોગ એક પ્રકારમાં દલીલોને કેનોનિકલ બનાવવા માટે થાય છે.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ફોર્મેટિંગ ઇન્ફ્રાસ્ટ્રક્ચરમાં indices/counts સાથે સંકળાયેલ ફંક્શન પોઇન્ટર માટે આ એકલ સ્થિર મૂલ્યની બાંયધરી આપે છે.
//
// નોંધ કરો કે ફંક્શન જેમ કે વ્યાખ્યાયિત કરવામાં આવશે નહીં તે યોગ્ય રહેશે નહીં કારણ કે ફંક્શંસ હંમેશાં LLVM IR ને વર્તમાનમાં ઘટાડેલા સાથે અનામી_એડ્ડ્રને ટgedગ કરે છે, તેથી તેમનું સરનામું એલએલવીએમ માટે મહત્વપૂર્ણ નથી માનવામાં આવતું અને જેમ કે_યુસાઇઝ કાસ્ટની ખોટી જોડણી કરી શકાય છે.
//
// વ્યવહારમાં, અમે ક્યારેય નન-યુઝાઇઝવાળા ડેટા (ફોર્મેટિંગ દલીલોની સ્થિર જનરેશનની બાબત) પર as_usize કહીશું નહીં, તેથી આ ફક્ત એક વધારાનો ચેક છે.
//
// અમે મુખ્યત્વે સુનિશ્ચિત કરવા માંગીએ છીએ કે `USIZE_MARKER` પર ફંક્શન પોઇન્ટર પાસે ફંક્શનો માટે ફક્ત *ફક્ત* ને લગતું સરનામું છે જે `&usize` ને પણ તેની પ્રથમ દલીલ તરીકે લે છે.
// અહીં વાંચેલ_અસ્થિરતા સુનિશ્ચિત કરે છે કે આપણે પસાર સંદર્ભમાંથી યુઝાઇઝ સુરક્ષિત રીતે તૈયાર કરી શકીએ છીએ અને આ સરનામું નોન-યુઝાઇઝ લેવાની કામગીરી તરફ ધ્યાન આપતો નથી.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // સલામતી: પીટીઆર એ એક સંદર્ભ છે
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // સલામતી: `mem::transmute(x)` સલામત છે કારણ કે
        //     1. `&'b T` તે આજીવન `'b` થી ઉત્પન્ન કરે છે (જેથી અનબાઉન્ડ આયુષ્ય ન હોય)
        //     2.
        //     `&'b T` અને `&'b Opaque` સમાન મેમરી લેઆઉટ ધરાવે છે (જ્યારે `T` એ `Sized` છે, તે અહીં છે તેમ જ) `mem::transmute(f)` સલામત છે કારણ કે `fn(&T, &mut Formatter<'_>) -> Result` અને `fn(&Opaque, &mut Formatter<'_>) -> Result` સમાન એબીઆઇ (`T` `Sized` છે ત્યાં સુધી)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // સલામત: `formatter` ફીલ્ડ ફક્ત USIZE_MARKER પર સેટ કરેલું છે જો
            // મૂલ્ય એ યુઝાઇઝ છે, તેથી આ સલામત છે
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ફોર્મેટ_ર્ગ્સના v1 ફોર્મેટમાં ઉપલબ્ધ ફ્લેગો
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// ફોર્મેટ_ર્ગ્સ! () મેક્રોનો ઉપયોગ કરતી વખતે, આ ફંક્શનનો ઉપયોગ દલીલોની રચનાને બનાવવા માટે થાય છે.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// આ ફંક્શન નોન સ્ટેન્ડર્ડ ફોર્મેટિંગ પરિમાણોને નિર્દિષ્ટ કરવા માટે વપરાય છે.
    /// માન્ય દલીલો બંધારણ બનાવવા માટે `pieces` એરે ઓછામાં ઓછો `fmt` સુધી હોવો જોઈએ.
    /// ઉપરાંત, `fmt` ની અંતર્ગત કોઈપણ `Count` જે `CountIsParam` અથવા `CountIsNextParam` છે તે `argumentusize` સાથે બનેલી દલીલ તરફ નિર્દેશ કરે છે.
    ///
    /// જો કે, આમ કરવામાં નિષ્ફળ થવું એ અસુરક્ષિતનું કારણ બનતું નથી, પરંતુ અમાન્યની અવગણના કરશે.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ફોર્મેટ કરેલા ટેક્સ્ટની લંબાઈનો અંદાજ.
    ///
    /// `format!` નો ઉપયોગ કરતી વખતે પ્રારંભિક `String` ક્ષમતા સેટ કરવા માટે આનો હેતુ છે.
    /// Note: આ ન તો નીચું અથવા ઉપરનું બાઉન્ડ છે.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // જો ફોર્મેટ શબ્દમાળા દલીલથી શરૂ થાય છે, તો જ્યાં સુધી ટુકડાઓ લંબાઈ નોંધપાત્ર ન હોય ત્યાં સુધી કંઈપણ પૂર્વાનગુણ ન કરો
            //
            //
            0
        } else {
            // ત્યાં કેટલીક દલીલો છે, તેથી કોઈપણ વધારાના દબાણ શબ્દમાળાને ફરીથી ફેરવશે.
            //
            // તે ટાળવા માટે, અમે અહીં ક્ષમતા "pre-doubling" છીએ.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// આ સ્ટ્રક્ચર ફોર્મેટ સ્ટ્રિંગ અને તેની દલીલોનું સુરક્ષિત રીતે પૂર્ણાંકિત સંસ્કરણ રજૂ કરે છે.
/// આ રનટાઈમ પર જનરેટ કરી શકાતું નથી કારણ કે તે સુરક્ષિત રીતે થઈ શકતું નથી, તેથી કોઈ બાંધકામ આપવામાં આવતું નથી અને ફેરફારો અટકાવવા માટે ક્ષેત્રો ખાનગી છે.
///
///
/// [`format_args!`] મેક્રો સુરક્ષિત રીતે આ રચનાનો દાખલો બનાવશે.
/// મેક્રો કમ્પાઈલ-સમય પર ફોર્મેટ સ્ટ્રિંગને માન્ય કરે છે જેથી [`write()`] અને [`format()`] કાર્યોનો ઉપયોગ સુરક્ષિત રીતે થઈ શકે.
///
/// તમે `Arguments<'a>` નો ઉપયોગ કરી શકો છો જે [`format_args!`] નીચે આપેલી `Debug` અને `Display` સંદર્ભમાં આપે છે.
/// ઉદાહરણ એ પણ બતાવે છે કે તે જ વસ્તુ માટે `Debug` અને `Display` ફોર્મેટ: `format_args!` માં ઇન્ટરપોલેટેડ ફોર્મેટ શબ્દમાળા.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // છાપવા માટે શબ્દમાળાના ટુકડાઓ ફોર્મેટ કરો.
    pieces: &'a [&'static str],

    // પ્લેસહોલ્ડર સ્પેક્સ, અથવા જો બધા સ્પેક્સ ડિફોલ્ટ હોય તો `None` ("{}{}" મુજબ).
    fmt: Option<&'a [rt::v1::Argument]>,

    // ઇંટરપોલેશન માટે ગતિશીલ દલીલો, શબ્દમાળાના ટુકડા સાથે ઇન્ટરલીવ્ડ કરવા માટે.
    // (દરેક દલીલ શબ્દમાળા ભાગ દ્વારા આગળ હોય છે.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ફોર્મેટ કરેલ શબ્દમાળા મેળવો, જો તેમાં ફોર્મેટ કરવા માટે કોઈ દલીલો નથી.
    ///
    /// સૌથી નજીવી બાબતમાં ફાળવણી ટાળવા માટે તેનો ઉપયોગ કરી શકાય છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` પ્રોગ્રામર-ફેસિંગ, ડિબગીંગ સંદર્ભમાં આઉટપુટને ફોર્મેટ કરવું જોઈએ.
///
/// સામાન્ય રીતે કહીએ તો, તમારે ફક્ત `derive` એક `Debug` અમલીકરણ કરવું જોઈએ.
///
/// જ્યારે વૈકલ્પિક ફોર્મેટ સ્પષ્ટીકરણ `#?` સાથે વપરાય છે, ત્યારે આઉટપુટ સુંદર-છાપવામાં આવે છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// જો બધા ક્ષેત્રો `Debug` ને લાગુ કરે છે તો આ ઝેડ 0 ટ્રાઇટ0 ઝેડનો ઉપયોગ `#[derive]` સાથે કરી શકાય છે.
/// જ્યારે સ્ટ્રક્ટ્સ માટે ડેરિવેડ કરવામાં આવે છે, ત્યારે તે `struct`, પછી `{`, પછી દરેક ક્ષેત્રના નામ અને `Debug` મૂલ્યની અલ્પવિરામથી વિભાજિત સૂચિનો ઉપયોગ કરશે, પછી `}`.
/// `Enum`s માટે, તે વેરિઅન્ટના નામનો ઉપયોગ કરશે અને, જો લાગુ હોય તો, `(`, પછી ફીલ્ડ્સના `Debug` મૂલ્યો, પછી `)`.
///
/// # Stability
///
/// તારવેલા `Debug` ફોર્મેટ્સ સ્થિર નથી, અને તેથી future Rust સંસ્કરણોથી બદલાઈ શકે છે.
/// વધારામાં, માનક લાઇબ્રેરી (`libstd`, `libcore`, `liballoc`, વગેરે) દ્વારા પ્રદાન થયેલ પ્રકારોના `Debug` અમલીકરણ સ્થિર નથી, અને future Rust સંસ્કરણોથી પણ બદલાઈ શકે છે.
///
///
/// # Examples
///
/// અમલીકરણની શોધ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// જાતે અમલ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] જેવા મેન્યુઅલ અમલીકરણમાં તમને સહાય કરવા માટે [`Formatter`] સ્ટ્રક્ટ પર સંખ્યાબંધ સહાયક પદ્ધતિઓ છે.
///
/// `Debug` `derive` અથવા [`Formatter`] પર ડિબગ બિલ્ડર API નો ઉપયોગ કરીને અમલીકરણ વૈકલ્પિક ધ્વજની મદદથી સુંદર-છાપવાનું સમર્થન આપે છે: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` સાથે સુંદર પ્રિન્ટિંગ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` વગર ઝેડપ્રીઅલ 0 ઝેડથી મેક્રો `Debug` ના ફરીથી નિકાસ માટે મોડ્યુલને અલગ કરો.
pub(crate) mod macros {
    /// trait `Debug` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ખાલી ફોર્મેટ માટે trait ફોર્મેટ કરો, `{}`.
///
/// `Display` [`Debug`] જેવું જ છે, પરંતુ `Display` એ વપરાશકર્તા-સામનો કરેલા આઉટપુટ માટે છે, અને તેથી મેળવી શકાતું નથી.
///
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// એક પ્રકાર પર `Display` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait એ તેનું આઉટપુટ base-8 માં નંબર તરીકે ફોર્મેટ કરવું જોઈએ.
///
/// આદિમ સહી કરેલ પૂર્ણાંકો (`i8` થી `i128` અને `isize`) માટે, નકારાત્મક મૂલ્યો બંનેના પૂરક પ્રતિનિધિત્વ તરીકે ફોર્મેટ કરવામાં આવે છે.
///
///
/// વૈકલ્પિક ધ્વજ, `#`, આઉટપુટની સામે એક `0o` ઉમેરે છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42; // ક્ટોલમાં 42 એ '52' છે
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// એક પ્રકાર પર `Octal` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // આઇ 32 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait એ તેના આઉટપુટને બાઈનરીમાં નંબર તરીકે ફોર્મેટ કરવું જોઈએ.
///
/// આદિમ સહી કરેલ પૂર્ણાંકો ([`i8`] થી [`i128`] અને [`isize`]) માટે, નકારાત્મક મૂલ્યો બંનેના પૂરક પ્રતિનિધિત્વ તરીકે ફોર્મેટ કરવામાં આવે છે.
///
///
/// વૈકલ્પિક ધ્વજ, `#`, આઉટપુટની સામે એક `0b` ઉમેરે છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42; // બાઈનરીમાં 42 એ '101010' છે
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// એક પ્રકાર પર `Binary` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // આઇ 32 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait એ તેના આઉટપુટને હેક્સાડેસિમલમાં સંખ્યા તરીકે ફોર્મેટ કરવું જોઈએ, `a` દ્વારા `f` નીચલા કેસમાં.
///
/// આદિમ સહી કરેલ પૂર્ણાંકો (`i8` થી `i128` અને `isize`) માટે, નકારાત્મક મૂલ્યો બંનેના પૂરક પ્રતિનિધિત્વ તરીકે ફોર્મેટ કરવામાં આવે છે.
///
///
/// વૈકલ્પિક ધ્વજ, `#`, આઉટપુટની સામે એક `0x` ઉમેરે છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42; // હેક્સમાં 42 એ '2a' છે
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// એક પ્રકાર પર `LowerHex` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // આઇ 32 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait એ તેના આઉટપુટને હેક્સાડેસિમલની સંખ્યા તરીકે ફોર્મેટ કરવું જોઈએ, અપર કેસમાં `A` દ્વારા `A` સાથે.
///
/// આદિમ સહી કરેલ પૂર્ણાંકો (`i8` થી `i128` અને `isize`) માટે, નકારાત્મક મૂલ્યો બંનેના પૂરક પ્રતિનિધિત્વ તરીકે ફોર્મેટ કરવામાં આવે છે.
///
///
/// વૈકલ્પિક ધ્વજ, `#`, આઉટપુટની સામે એક `0x` ઉમેરે છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42; // હેક્સમાં 42 એ '2A' છે
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// એક પ્રકાર પર `UpperHex` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // આઇ 32 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait એ તેનું આઉટપુટ મેમરી સ્થાન તરીકે ફોર્મેટ કરવું જોઈએ.
/// આ સામાન્ય રીતે હેક્સાડેસિમલ તરીકે પ્રસ્તુત થાય છે.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // આ '0x7f06092ac6d0' જેવું કંઈક ઉત્પન્ન કરે છે
/// ```
///
/// એક પ્રકાર પર `Pointer` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` માં રૂપાંતરિત કરવા માટે `as` નો ઉપયોગ કરો, જે પોઇંટર લાગુ કરે છે, જેનો આપણે ઉપયોગ કરી શકીએ છીએ
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait એ તેના આઉટપુટને લોઅર-કેસ `e` સાથે વૈજ્ .ાનિક સંકેતમાં ફોર્મેટ કરવું જોઈએ.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42.0; // 42.0 વૈજ્ .ાનિક સંકેતમાં '4.2e1' છે
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// એક પ્રકાર પર `LowerExp` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait એ તેના આઉટપુટને અપર-કેસ `E` સાથે વૈજ્ .ાનિક સંકેતમાં ફોર્મેટ કરવું જોઈએ.
///
/// ફોર્મેટર્સ પર વધુ માહિતી માટે, [the module-level documentation][module] જુઓ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` સાથે મૂળભૂત ઉપયોગ:
///
/// ```
/// let x = 42.0; // 42.0 વૈજ્ .ાનિક સંકેતમાં '4.2E1' છે
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// એક પ્રકાર પર `UpperExp` અમલીકરણ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 ના અમલીકરણને સોંપવું
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// આપેલ ફોર્મેટરનો ઉપયોગ કરીને મૂલ્યનું બંધારણ કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ફંક્શન આઉટપુટ સ્ટ્રીમ લે છે, અને `Arguments` સ્ટ્ર .ક જે `format_args!` મcક્રોથી પૂર્વ કમ્પાઇલ કરી શકાય છે.
///
///
/// આપેલ આઉટપુટ પ્રવાહમાં નિર્દિષ્ટ ફોર્મેટ શબ્દમાળા અનુસાર દલીલોનું ફોર્મેટ કરવામાં આવશે.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// મહેરબાની કરીને નોંધ કરો કે [`write!`] નો ઉપયોગ કરવો વધુ સારું છે.ઉદાહરણ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // આપણે બધી દલીલો માટે ડિફ defaultલ્ટ ફોર્મેટિંગ પરિમાણોનો ઉપયોગ કરી શકીએ છીએ.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // દરેક સ્પેકમાં અનુરૂપ દલીલ હોય છે જે સ્ટ્રિંગ પીસ દ્વારા આગળ હોય છે.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // સલામતી: આર્ગ અને args.args સમાન દલીલોમાંથી આવે છે,
                // જે સૂચકાંકોની બાંયધરી આપે છે તે હંમેશાં હદમાં હોય છે.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ત્યાં ફક્ત એક જ પાછળનો શબ્દમાળા ભાગ બાકી હોઈ શકે છે.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // સલામતી: દલીલો અને દલીલો સમાન દલીલોથી આવે છે,
    // જે સૂચકાંકોની બાંયધરી આપે છે તે હંમેશાં હદમાં હોય છે.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // સાચો દલીલ કાractો
    debug_assert!(arg.position < args.len());
    // સલામતી: દલીલો અને દલીલો સમાન દલીલોથી આવે છે,
    // જે તેની અનુક્રમણિકાની બાંયધરી આપે છે તે હંમેશાં હદમાં હોય છે.
    let value = unsafe { args.get_unchecked(arg.position) };

    // પછી ખરેખર થોડી છાપકામ કરો
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // સલામતી: સી.એન.ટી. અને આર્ટ્સ એ જ દલીલોમાંથી આવે છે,
            // જે આ ઇન્ડેક્સની બાંયધરી આપે છે તે હંમેશાં હદમાં હોય છે.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// કંઇક અંત પછી ગાદી.`Formatter::padding` દ્વારા પરત.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// આ પોસ્ટ ગાદી લખો.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // આપણે આ બદલવા માંગીએ છીએ
            buf: wrap(self.buf),

            // અને આ સાચવો
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // પેડિંગ અને ફોર્મેટિંગ દલીલોની પ્રક્રિયા કરવા માટે ઉપયોગમાં લેવામાં આવતી સહાયક પદ્ધતિઓ જે બધા traits ફોર્મેટિંગ કરી શકે છે.
    //

    /// પૂર્ણાંકો માટે યોગ્ય પેડિંગ કરે છે જે પહેલાથી જ એક સ્ટ્રિટમાં બહાર નીકળી ગયું છે.
    /// આ સ્ટ્રીમમાં * પૂર્ણાંક માટેનું નિશાની હોવું જોઈએ નહીં, જે આ પદ્ધતિ દ્વારા ઉમેરવામાં આવશે.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, શું મૂળ પૂર્ણાંક ક્યાં ધન અથવા શૂન્ય હતું.
    /// * ઉપસર્ગ, જો '#' અક્ષર (Alternate) પ્રદાન થયેલ છે, તો નંબરની સામે મૂકવાનો આ ઉપસર્ગ છે.
    ///
    /// * બફ, બાઇટ એરે કે નંબર ફોર્મેટ થઈ ગયું છે
    ///
    /// આ ફંક્શન પ્રદાન કરેલા ફ્લેગોની સાથે સાથે ન્યૂનતમ પહોળાઈને યોગ્ય રીતે ધ્યાનમાં લેશે.
    /// તે ચોકસાઇ ધ્યાનમાં લેશે નહીં.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // આપણે સંખ્યા આઉટપુટમાંથી "-" દૂર કરવાની જરૂર છે.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // જો તે અસ્તિત્વમાં હોય તો ચિહ્ન લખો, અને પછી વિનંતી કરવામાં આવે તો ઉપસર્ગ
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` ક્ષેત્ર આ બિંદુએ એક `min-width` પરિમાણનું વધુ છે.
        match self.width {
            // જો ત્યાં લઘુત્તમ લંબાઈ આવશ્યકતાઓ નથી, તો અમે ફક્ત બાઇટ્સ લખી શકીએ છીએ.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // તપાસો કે આપણે લઘુત્તમ પહોળાઈ ઉપર છીએ કે નહીં, તો પછી આપણે ફક્ત બાઇટ્સ પણ લખી શકીએ.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // જો ભરણ અક્ષર શૂન્ય હોય તો સાઇન અને ઉપસર્ગ પેડિંગ પહેલાં જાય છે
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // નહિંતર, સાઇન અને ઉપસર્ગ પેડિંગ પછી જાય છે
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// આ ફંક્શન શબ્દમાળાની કટકા લે છે અને ઉલ્લેખિત સંબંધિત ફોર્મેટિંગ ફ્લેગો લાગુ કર્યા પછી તેને આંતરિક બફર પર બહાર કા .ે છે.
    /// સામાન્ય શબ્દમાળાઓ માટે માન્યતા આપેલા ધ્વજ છે:
    ///
    /// * પહોળાઈ, શું બહાર કા .વું તે ઓછામાં ઓછી પહોળાઈ
    /// * fill/align - જો સ્ટ્રિંગ પેડ કરવાની જરૂર હોય તો શું બહાર કા .વું અને તેને ક્યાં બહાર કા .વું
    /// * ચોકસાઇ, બહાર કા .વાની મહત્તમ લંબાઈ, જો આ લંબાઈ કરતા લાંબી હોય તો શબ્દમાળા કાપવામાં આવે છે
    ///
    /// નોંધનીય છે કે આ કાર્ય `flag` પરિમાણોને અવગણે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ખાતરી કરો કે આગળનો એક ઝડપી રસ્તો છે
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` ફીલ્ડને શબ્દમાળાના ફોર્મેટ થવા માટે `max-width` તરીકે અર્થઘટન કરી શકાય છે.
        //
        let s = if let Some(max) = self.precision {
            // જો અમારી શબ્દમાળા ચોકસાઇથી લાંબી છે, તો પછી આપણે કાપવું જોઈએ.
            // જો કે અન્ય ફ્લેગો જેમ કે `fill`, `width` અને `align` એ હંમેશાની જેમ કાર્ય કરવું આવશ્યક છે.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // અહીં LLVM એ સાબિત કરી શકતું નથી કે `..i` panic `&s[..i]` નહીં કરે, પરંતુ આપણે જાણીએ છીએ કે તે panic કરી શકતું નથી.
                // `unsafe` ને ટાળવા માટે `get` + `unwrap_or` નો ઉપયોગ કરો અને અન્યથા અહીં કોઈ ઝેડપpanનિક 0 ઝેડ-સંબંધિત કોડ ઉત્સર્જન ન કરો.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` ક્ષેત્ર આ બિંદુએ એક `min-width` પરિમાણનું વધુ છે.
        match self.width {
            // જો આપણે મહત્તમ લંબાઈ હેઠળ હોઈએ, અને લઘુત્તમ લંબાઈ આવશ્યકતાઓ ન હોય, તો અમે ફક્ત શબ્દમાળાને બહાર કા .ી શકીએ છીએ
            //
            None => self.buf.write_str(s),
            // જો આપણે મહત્તમ પહોળાઈ હેઠળ છીએ, તો તપાસો કે આપણે લઘુત્તમ પહોળાઈ ઉપર છીએ કે નહીં, જો તે શબ્દમાળા કા eવા જેટલું જ સરળ છે.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // જો આપણે મહત્તમ અને લઘુત્તમ પહોળાઈ બંને હેઠળ હોઈએ, તો પછી સ્પષ્ટ શબ્દમાળા + કેટલાક ગોઠવણી સાથે લઘુત્તમ પહોળાઈ ભરો.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// પ્રી-પેડિંગ લખો અને અલિખિત પોસ્ટ-પેડિંગ પરત કરો.
    /// પોસ્ટ કરનારા તેની ખાતરી કરવા માટે કdingલર્સ જવાબદાર છે કે જે વસ્તુ ગાદીવાળી હોય તે પછી લખેલી હોય.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ફોર્મેટ કરેલા ભાગો લે છે અને ગાદી લાગુ પડે છે.
    /// ધારે છે કે કlerલર પહેલાથી જ જરૂરી ચોકસાઇ સાથે ભાગોને રેન્ડર કરે છે, જેથી `self.precision` ને અવગણી શકાય.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // સાઇન-વાકેફ ઝીરો પેડિંગ માટે, અમે પહેલા સાઇન રેન્ડર કરીએ છીએ અને વર્તન કરીએ છીએ જેમ કે આપણી પાસે શરૂઆતથી કોઈ નિશાની નથી.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // નિશાની હંમેશાં પ્રથમ રહે છે
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ફોર્મેટ કરેલા ભાગોમાંથી સાઇન દૂર કરો
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // બાકીના ભાગો સામાન્ય પેડિંગ પ્રક્રિયામાંથી પસાર થાય છે.
            let len = formatted.len();
            let ret = if width <= len {
                // ગાદી નહીં
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // આ સામાન્ય બાબત છે અને અમે એક શોર્ટકટ લઈએ છીએ
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // સલામત: આનો ઉપયોગ `flt2dec::Part::Num` અને `flt2dec::Part::Copy` માટે થાય છે.
            // તે `flt2dec::Part::Num` નો ઉપયોગ કરવા માટે સલામત છે કારણ કે દરેક ચર `c` એ `b'0'` અને `b'9'` ની વચ્ચે હોય છે, જેનો અર્થ `s` માન્ય UTF-8 છે.
            // `flt2dec::Part::Copy(buf)` નો ઉપયોગ કરવો તે વ્યવહારમાં સંભવતરૂપે સલામત પણ છે કારણ કે `buf` એ સાદી ASCII હોવી જોઈએ, પરંતુ કોઈ વ્યક્તિ માટે `buf` માટે ખરાબ મૂલ્યમાં `flt2dec::to_shortest_str` માં પસાર થવું શક્ય છે કારણ કે તે જાહેર કાર્ય છે.
            //
            // FIXME: નક્કી કરો કે શું આનું પરિણામ યુબીમાં આવી શકે છે.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 શૂન્ય
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// આ ફોર્મેટરમાં સમાવિષ્ટ અંતર્ગત બફર માટે કેટલાક ડેટા લખે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // આ બરાબર છે:
    ///         // લખો! (ફોર્મેટર, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// આ દાખલા માટે કેટલીક ફોર્મેટ કરેલી માહિતી લખે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ફોર્મેટિંગ માટે ફ્લેગો
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// જ્યારે પણ ગોઠવણી હોય ત્યાં 'fill' તરીકે અક્ષરનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // અમે ">" સાથે જમણી તરફ ગોઠવણી સેટ કરી છે.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// કયા સંરેખણના ફોર્મની વિનંતી કરવામાં આવી હતી તે દર્શાવતો ફ્લેગ.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// વૈકલ્પિક રીતે પૂર્ણાંકોની સ્પષ્ટ પહોળાઈ જે આઉટપુટ હોવી જોઈએ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // જો અમને પહોળાઈ મળી છે, તો અમે તેનો ઉપયોગ કરીશું
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // અન્યથા આપણે કંઇ ખાસ કામ કરતા નથી
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// સંખ્યાત્મક પ્રકારો માટે વૈકલ્પિક રીતે સ્પષ્ટ કરેલ ચોકસાઇ.
    /// વૈકલ્પિક રીતે, શબ્દમાળાના પ્રકારો માટેની મહત્તમ પહોળાઈ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // જો અમને ચોકસાઇ મળી હોય, તો અમે તેનો ઉપયોગ કરીશું.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // અન્યથા આપણે મૂળભૂત 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// નક્કી કરે છે કે શું `+` ધ્વજ ઉલ્લેખિત હતો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// નક્કી કરે છે કે શું `-` ધ્વજ ઉલ્લેખિત હતો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // તમે માઇનસ સાઇન માંગો છો?એક છે!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// નક્કી કરે છે કે શું `#` ધ્વજ ઉલ્લેખિત હતો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// નક્કી કરે છે કે શું `0` ધ્વજ ઉલ્લેખિત હતો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // અમે ફોર્મેટરના વિકલ્પોને અવગણીએ છીએ.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: નક્કી કરો કે આ બે ફ્લેગો માટે અમને કયા જાહેર API જોઈએ છે.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// સ્ટ્રક્ટ્સ માટે [`fmt::Debug`] અમલીકરણો બનાવવા માટે સહાય કરવા માટે રચાયેલ એક [`DebugStruct`] બિલ્ડર બનાવે છે.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ટ્યુપલ સ્ટ્રક્ટ્સ માટે `fmt::Debug` અમલીકરણોના નિર્માણમાં સહાય માટે રચાયેલ એક `DebugTuple` બિલ્ડર બનાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// સૂચિ જેવા માળખાં માટે `fmt::Debug` અમલીકરણોના નિર્માણમાં સહાય માટે રચાયેલ એક `DebugList` બિલ્ડર બનાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// સેટ-જેવા સ્ટ્રક્ચર્સ માટે `fmt::Debug` અમલીકરણોના નિર્માણમાં સહાય માટે રચાયેલ એક `DebugSet` બિલ્ડર બનાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// આ વધુ જટિલ ઉદાહરણમાં, અમે મેચ હથિયારોની સૂચિ બનાવવા માટે [`format_args!`] અને `.debug_set()` નો ઉપયોગ કરીએ છીએ:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// નકશા જેવા માળખાં માટે `fmt::Debug` અમલીકરણોના નિર્માણમાં સહાય માટે રચાયેલ એક `DebugMap` બિલ્ડર બનાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// કોર ફોર્મેટિંગ traits ની અમલીકરણો

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // જો ચારને બહાર નીકળવાની જરૂર હોય, તો અત્યાર સુધી બેકલોગ ફ્લશ કરો અને લખો, નહીં તો અવગણો
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // લોઅરહેક્સ દ્વારા વૈકલ્પિક ધ્વજ પહેલાથી જ વિશેષ માનવામાં આવે છે-તે 0x સાથે ઉપસર્ગ બનાવવું કે નહીં તે સૂચવે છે.
        // આપણે તેનો ઉપયોગ શૂન્ય વિસ્તૃત કરવા કે નહીં તે કરવા માટે કરીએ છીએ, અને પછી ઉપસર્ગ મેળવવા માટે બિનશરતી તેને સેટ કરીએ છીએ.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// વિવિધ મૂળ પ્રકારો માટે Display/Debug નું અમલીકરણ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // રેફસેલ પરસ્પર ઉધાર લીધેલ છે તેથી અમે અહીં તેનું મૂલ્ય જોઈ શકતા નથી.
                // તેના બદલે પ્લેસહોલ્ડર બતાવો.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// જો તમને અપેક્ષાઓ અહીં હોવાની અપેક્ષા છે, તો તેના બદલે core/tests/fmt.rs ફાઇલને જુઓ, તે બધા rt::Piece સ્ટ્રક્ચર્સ બનાવવા કરતાં ઘણું સરળ છે.
//
// ફાળવણીની જરૂર હોય તેવા લોકો માટે ફાળવણી ઝેડક્રેટ 0 ઝેડમાં પણ પરીક્ષણો છે.