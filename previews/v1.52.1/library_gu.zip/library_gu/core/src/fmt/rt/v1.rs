//! આ ifmt દ્વારા વપરાયેલ આંતરિક મોડ્યુલ છે!રનટાઇમ.આ સ્ટ્રક્ચર્સ સમય પહેલા સ્ટેમ્પિક એરેમાં પૂર્વનિર્ધારણ બંધારણના શબ્દમાળાઓ માટે ઉત્સર્જિત થાય છે.
//!
//! આ વ્યાખ્યાઓ તેમના `ct` સમકક્ષ સમાન છે, પરંતુ આમાં સ્થિરતા ફાળવી શકાય છે અને રનટાઈમ માટે સહેજ optimપ્ટિમાઇઝ કરવામાં આવી છે તેનાથી અલગ છે
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// સંભવિત સંરેખણો કે જે ફોર્મેટિંગ ડિરેક્ટિવના ભાગ રૂપે વિનંતી કરી શકાય છે.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// સૂચવે છે કે સમાવિષ્ટો ડાબી બાજુ ગોઠવાયેલ હોવી જોઈએ.
    Left,
    /// સૂચવે છે કે સમાવિષ્ટો જમણી બાજુ ગોઠવાયેલી હોવી જોઈએ.
    Right,
    /// સૂચવે છે કે સમાવિષ્ટો કેન્દ્રમાં ગોઠવાયેલ હોવા જોઈએ.
    Center,
    /// કોઈ સંરેખણની વિનંતી કરવામાં આવી ન હતી.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) અને [precision](https://doc.rust-lang.org/std/fmt/#precision) સ્પષ્ટીકરણો દ્વારા ઉપયોગમાં લેવાય છે.
#[derive(Copy, Clone)]
pub enum Count {
    /// શાબ્દિક સંખ્યા સાથે ઉલ્લેખિત, મૂલ્ય સ્ટોર કરે છે
    Is(usize),
    /// `$` અને `*` સિન્ટેક્સનો ઉપયોગ કરીને ઉલ્લેખિત, અનુક્રમણિકાને `args` માં સ્ટોર કરે છે
    Param(usize),
    /// ઉલ્લેખ નથી
    Implied,
}