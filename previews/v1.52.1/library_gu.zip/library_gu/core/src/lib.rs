//! # Rust કોર લાઇબ્રેરી
//!
//! ઝેડ 0 રસ્ટ0 ઝેડ કોર લાઇબ્રેરી એ [The Rust Standard Library](../std/index.html) ની અવલંબન મુક્ત [^ નિ^શુલ્ક] પાયો છે.
//! તે ભાષા અને તેની લાઇબ્રેરીઓ વચ્ચેનો પોર્ટેબલ ગુંદર છે, જે બધા ઝેડ રસ્ટ0 ઝેડ કોડના આંતરિક અને પ્રાચીન બિલ્ડિંગ બ્લોક્સને વ્યાખ્યાયિત કરે છે.
//!
//! તે કોઈ અપસ્ટ્રીમ લાઇબ્રેરીઓ, કોઈ સિસ્ટમ લાઇબ્રેરીઓ અને કોઈ લિબીસી સાથે લિંક કરે છે.
//!
//! [^free]: Strictly બોલતા, કેટલાક પ્રતીકો હોય છે જેની જરૂર હોય છે પરંતુ
//!          તેઓ હંમેશા જરૂરી નથી.
//!
//! મુખ્ય લાઇબ્રેરી *ન્યૂનતમ* છે: તે apગલા ફાળવણી વિશે પણ જાગૃત નથી, અથવા તે સંવાદિતા અથવા I/O પ્રદાન કરતું નથી.
//! આ વસ્તુઓ માટે પ્લેટફોર્મ એકીકરણની જરૂર છે, અને આ લાઇબ્રેરી પ્લેટફોર્મ-અજ્nોસ્ત્રીય છે.
//!
//! # કોર લાઇબ્રેરીનો ઉપયોગ કેવી રીતે કરવો
//!
//! કૃપા કરીને નોંધો કે આ બધી વિગતો હાલમાં સ્થિર માનવામાં આવતી નથી.
//!
//!
//!
// FIXME: જ્યારે ઇન્ટરફેસ સ્થિર થાય ત્યારે મને વધુ વિગતવાર ભરો
//! આ લાઇબ્રેરી કેટલાક હાલના પ્રતીકોની ધારણા પર બનાવવામાં આવ્યું છે:
//!
//! * `memcpy`, `memcmp`, `memset`, આ કોર મેમરી રૂટીન છે જે ઘણીવાર એલએલવીએમ દ્વારા પેદા થાય છે.
//! આ ઉપરાંત, આ લાઇબ્રેરી આ કાર્યો માટે સ્પષ્ટ ક .લ કરી શકે છે.
//! તેમના હસ્તાક્ષરો સી જેવા જ મળ્યા છે.
//!   આ ફંક્શન્સ ઘણીવાર સિસ્ટમ લિબસી દ્વારા પ્રદાન કરવામાં આવે છે, પરંતુ તે [compiler-builtins crate](https://crates.io/crates/compiler_builtins) દ્વારા પણ પ્રદાન કરી શકાય છે.
//!
//!
//! * `rust_begin_panic` - આ ફંક્શન ચાર દલીલો લે છે, એક `fmt::Arguments`, એક `&'static str` અને બે `u32`.
//! આ ચાર દલીલો panic સંદેશ, તે ફાઇલ કે જેના પર panic માંગવામાં આવી હતી, અને ફાઇલની અંદરની લાઇન અને ક columnલમ સૂચવે છે.
//! આ ઝેડ 0 સ્પેનિક 0 ઝેડ ફંક્શનને વ્યાખ્યાયિત કરવા માટે આ મુખ્ય લાઇબ્રેરીના ગ્રાહકો પર છે;તે ક્યારેય પાછા ન આવે તે જરૂરી છે.
//! આને `panic_impl` નામના `lang` લક્ષણની જરૂર છે.
//!
//! * `rust_eh_personality` - કમ્પાઇલરની નિષ્ફળતા પદ્ધતિઓ દ્વારા વપરાય છે.
//! આ હંમેશા ઝેડ 0 જીસીસી 0 ઝેડના વ્યક્તિત્વ ફંક્શન પર મેપ કરવામાં આવે છે, પરંતુ ઝેડ 0 ક્રેટ્સ 0 ઝેડ જે ઝેડ 0 સ્પેનિક્સ 0 ઝેડને ટ્રિગર કરતું નથી તે ખાતરી આપી શકાય છે કે આ ફંક્શન ક્યારેય બોલાતું નથી.
//! `lang` લક્ષણને `eh_personality` કહેવામાં આવે છે.
//!
//!
//!

// લિબકોર ઘણી મૂળભૂત લ langંગ વસ્તુઓ વ્યાખ્યાયિત કરે છે, તેથી વિચિત્ર મુદ્દાઓ ટાળવા માટે, બધા પરીક્ષણો અલગ ઝેડ ક્રેકટ0 ઝેડ, લાઈબકોરેસ્ટમાં રહે છે.
//
// અહીં અમે સ્પષ્ટપણે#[cfg]-જ્યારે આ પરીક્ષણ દરમ્યાન આખા crate.
// જો આપણે આ ન કરીએ, તો જનરેટેડ પરીક્ષણ આર્ટિફેક્ટ અને લિંક્ડ લિબેટેસ્ટ (જેમાં ટ્રાંઝિટિવલી લિબકોર શામેલ છે) બંને લ langંગ વસ્તુઓનો સમાન સેટ વ્યાખ્યાયિત કરશે, અને આ E0152 "found duplicate lang item" ભૂલનું કારણ બનશે.
//
// વિગતો માટે #50466 માં ચર્ચા જુઓ.
//
// આ સીએફજી ડોક પરીક્ષણોને અસર કરશે નહીં.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 જુઓ
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: જાહેર કરવાની જરૂર નથી
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// સીધા લિબકોરમાં `core_arch` crate ખેંચો.`core_arch` ની સામગ્રી એક અલગ ભંડારમાં છે: rust-lang/stdarch.
//
// `core_arch` લિબકોર પર આધારીત છે, પરંતુ આ મોડ્યુલનાં સમાવિષ્ટો એવી રીતે ગોઠવવામાં આવી છે કે અહીં તેને સીધો ખેંચીને તે કામ કરે છે કે ઝેડ ક્રેટ 0 ઝેડ આ ઝેડ ક્રેટ 0 ઝેડને તેના લિબકોર તરીકે ઉપયોગ કરે છે.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: ક્લેશીંગ_એક્સ્ટર્ન_ડેક્લેરેશન્સ થયા પછી આ otનોટેશનને rust-lang/stdarch માં ખસેડવું જોઈએ
// મર્જતે હાલમાં કરી શકતું નથી કારણ કે બુટસ્ટ્રેપ નિષ્ફળ જાય છે કારણ કે ઝેડલિન્ટ 0 ઝેડ હજી સુધી વ્યાખ્યાયિત નથી.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;