//! `Clone` trait એવા પ્રકારો માટે કે જે 'સ્પષ્ટ રૂપે નકલ કરી શકાતા નથી'.
//!
//! ઝેડ રસ્ટ0 ઝેડમાં, કેટલાક સરળ પ્રકારો "implicitly copyable" હોય છે અને જ્યારે તમે તેમને સોંપો અથવા દલીલો તરીકે પસાર કરો ત્યારે રીસીવરને એક નકલ મળશે, મૂળ મૂલ્યને ત્યાં મૂકીને.
//! આ પ્રકારના કોપી કરવા માટે ફાળવણીની જરૂર હોતી નથી અને તેમાં ફાઇનિલાઇઝર્સ નથી (દા.ત., તેમાં માલિકીની બ boxesક્સ શામેલ નથી અથવા [`Drop`] અમલમાં નથી), તેથી કમ્પાઇલર તેમને સસ્તી અને નકલ કરવા માટે સલામત માને છે.
//!
//! [`Clone`] trait ને લાગુ કરીને અને [`clone`] પધ્ધતિને ક conventionલ કરીને અન્ય પ્રકારો માટે, નકલો સ્પષ્ટપણે બનાવવી આવશ્યક છે.
//!
//! [`clone`]: Clone::clone
//!
//! મૂળભૂત વપરાશ ઉદાહરણ:
//!
//! ```
//! let s = String::new(); // શબ્દમાળા પ્રકાર ક્લોન લાગુ કરે છે
//! let copy = s.clone(); // તેથી અમે તેને ક્લોન કરી શકીએ
//! ```
//!
//! ક્લોન trait ને સરળતાથી અમલમાં મૂકવા માટે, તમે `#[derive(Clone)]` નો પણ ઉપયોગ કરી શકો છો.ઉદાહરણ:
//!
//! ```
//! #[derive(Clone)] // અમે ક્લોન ઝેડટ્રેટ 0 ઝેડને મોર્ફિયસ સ્ટ્રક્ટમાં ઉમેરીએ છીએ
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // અને હવે અમે તેને ક્લોન કરી શકીએ છીએ!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Zબ્જેક્ટને સ્પષ્ટપણે ડુપ્લિકેટ કરવાની ક્ષમતા માટે એક સામાન્ય ઝેડટ્રેટ 0 ઝેડ.
///
/// તે [`Copy`] માં [`Copy`] થી અલગ છે તે ગર્ભિત અને અત્યંત સસ્તું છે, જ્યારે `Clone` હંમેશા સ્પષ્ટ હોય છે અને ખર્ચાળ પણ હોઈ શકે છે.
/// આ લાક્ષણિકતાઓને અમલમાં મૂકવા માટે, ઝેડ રસ્ટ0 ઝેડ તમને [`Copy`] રિઇમ્પિલેશન કરવાની મંજૂરી આપતું નથી, પરંતુ તમે એક્સ01 એક્સને ફરીથી લગાવી શકો છો અને મનસ્વી કોડ ચલાવી શકો છો.
///
/// `Clone` એ [`Copy`] કરતા વધારે સામાન્ય હોવાથી, તમે [`Copy`] ને પણ આપોઆપ [`Copy`] બનાવી શકો છો.
///
/// ## Derivable
///
/// જો બધા ક્ષેત્રો `Clone` હોય તો આ ઝેડ 0 ટ્રાઈટ0 ઝેડનો ઉપયોગ `#[derive]` સાથે કરી શકાય છે.[`Clone`] નું `પ્રાપ્તિ અમલીકરણ દરેક ક્ષેત્ર પર [`clone`] કહે છે.
///
/// [`clone`]: Clone::clone
///
/// સામાન્ય માળખા માટે, `#[derive]` સામાન્ય પરિમાણો પર બાઉન્ડ `Clone` ઉમેરીને `Clone` શરતે લાગુ કરે છે.
///
/// ```
/// // `derive` વાંચન માટે ક્લોન લાગુ કરે છે<T>જ્યારે ટી ક્લોન છે.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## હું `Clone` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// [`Copy`] ના પ્રકારોમાં `Clone` નો મામૂલી અમલીકરણ હોવો જોઈએ.વધુ formalપચારિક:
/// જો `T: Copy`, `x: T` અને `y: &T`, તો `let x = y.clone();`, `let x = *y;` ની સમકક્ષ છે.
/// મેન્યુઅલ અમલીકરણોએ આ આક્રમકને જાળવવા માટે ખૂબ કાળજી લેવી જોઈએ;તેમ છતાં, મેમરી સલામતી સુનિશ્ચિત કરવા માટે અસલામત કોડને તેના પર આધાર રાખવો જોઈએ નહીં.
///
/// ઉદાહરણ એ ફંક્શન પોઇન્ટર ધરાવતું સામાન્ય માળખું છે.આ કિસ્સામાં, `Clone` નું અમલીકરણ `પ્રાપ્ત કરી શકાતું નથી, પરંતુ આના જેવા અમલ કરી શકાય છે:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## વધારાના અમલકર્તાઓ
///
/// [implementors listed below][impls] ઉપરાંત, નીચેના પ્રકારો પણ `Clone` લાગુ કરે છે:
///
/// * ફંકશન આઇટમ પ્રકારો (એટલે કે, દરેક કાર્ય માટે અલગ અલગ પ્રકારો વ્યાખ્યાયિત)
/// * ફંક્શન પોઇન્ટર પ્રકારો (દા.ત., `fn() -> i32`)
/// * એરે પ્રકારો, બધા કદ માટે, જો આઇટમ પ્રકાર પણ `Clone` લાગુ કરે છે (દા.ત., `[i32; 123456]`)
/// * ટ્યુપલ પ્રકારો, જો દરેક ઘટક પણ `Clone` લાગુ કરે છે (દા.ત., `()`, `(i32, bool)`)
/// * બંધ કરવાનાં પ્રકારો, જો તેઓ પર્યાવરણમાંથી કોઈ મૂલ્ય મેળવે નહીં અથવા જો આવા બધા કબજે કરેલા મૂલ્યો પોતાને `Clone` લાગુ કરે છે.
///   નોંધ લો કે વહેંચાયેલ સંદર્ભ દ્વારા કબજે કરવામાં આવતા ચલો હંમેશા `Clone` ને લાગુ કરે છે (ભલે તે અલગ ન હોય), જ્યારે પરિવર્તનીય સંદર્ભ દ્વારા કબજે કરવામાં આવતા ચલો ક્યારેય `Clone` ને લાગુ કરતા નથી.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// મૂલ્યની એક ક Returnપિ પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ક્લોન લાગુ કરે છે
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` થી ક copyપિ-સોંપણી કરે છે.
    ///
    /// `a.clone_from(&b)` વિધેયમાં `a = b.clone()` ની બરાબર છે, પરંતુ બિનજરૂરી ફાળવણીને ટાળવા માટે `a` ના સ્રોતોનો ફરીથી ઉપયોગ કરવા માટે ઓવરરાઇડ કરી શકાય છે.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): આ સ્ટ્રક્ટ્સનો ઉપયોગ ફક્ત#[derive] દ્વારા થાય છે કે દરેક પ્રકારનાં ઘટક ક્લોન અથવા કોપી લાગુ કરે છે.
//
//
// આ સ્ટ્રક્ટ્સ ક્યારેય વપરાશકર્તા કોડમાં દેખાવા જોઈએ નહીં.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// આદિમ પ્રકારના માટે `Clone` ની અમલીકરણ.
///
/// ઝેડ રસ્ટ0 ઝેડમાં વર્ણવી ન શકાય તેવા અમલીકરણો, `rustc_trait_selection` માં `traits::SelectionContext::copy_clone_conditions()` માં લાગુ કરવામાં આવ્યા છે.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// વહેંચાયેલ સંદર્ભો ક્લોન કરી શકાય છે, પરંતુ પરિવર્તનશીલ સંદર્ભો *કરી શકતા નથી*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// વહેંચાયેલ સંદર્ભો ક્લોન કરી શકાય છે, પરંતુ પરિવર્તનશીલ સંદર્ભો *કરી શકતા નથી*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}