//! સ્લાઇસ સingર્ટિંગ
//!
//! આ મોડ્યુલમાં ઓર્સન પીટર્સની પેટર્ન-હરાવીને ક્વિક્કોર્ટ પર આધારિત સ sortર્ટિંગ અલ્ગોરિધમનો છે, જે અહીં પ્રકાશિત: <https://github.com/orlp/pdqsort>
//!
//!
//! અસ્થિર સ sortર્ટિંગ લિબકોર સાથે સુસંગત છે કારણ કે તે અમારા સ્થિર સingર્ટિંગ અમલીકરણથી વિપરીત મેમરીનું ફાળવણી કરતી નથી.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// જ્યારે છોડી દેવામાં આવે ત્યારે, `src` માંથી `dest` માંની નકલો.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // સલામતી: આ સહાયક વર્ગ છે.
        //          કૃપા કરીને સચોટતા માટે તેના ઉપયોગનો સંદર્ભ લો.
        //          જેમ કે, કોઈએ ખાતરી કરવી આવશ્યક છે કે `src` અને `dst`, `ptr::copy_nonoverlapping` દ્વારા જરૂરી મુજબ ઓવરલેપ થતો નથી.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// જ્યાં સુધી તે મોટા અથવા સમાન તત્વનો સામનો ન કરે ત્યાં સુધી પ્રથમ તત્વને જમણી તરફ સ્થાનાંતરિત કરો.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // સલામતી: નીચે અસુરક્ષિત કામગીરીમાં બાઉન્ડ ચેક (`get_unchecked` અને `get_unchecked_mut`) વગર અનુક્રમણિકા શામેલ છે.
    // અને મેમરી (`ptr::copy_nonoverlapping`) ને કyingપિ કરી રહ્યું છે.
    //
    // એ.અનુક્રમણિકા:
    //  1. અમે એરેનું કદ>=2 પર તપાસ્યું.
    //  2. અમે જે ઇન્ડેક્સિંગ કરીશું તે હંમેશાં વધુમાં વધુ {0 <= index < len} ની વચ્ચે હોય છે.
    //
    // બી.મેમરી કyingપિ
    //  1. અમે સંદર્ભોના નિર્દેશક પ્રાપ્ત કરી રહ્યા છીએ જે માન્ય હોવાની બાંયધરી છે.
    //  2. તેઓ ઓવરલેપ કરી શકતા નથી કારણ કે આપણે સ્લાઇસના સૂચકાંકોના તફાવત માટેના પોઇંટર પ્રાપ્ત કરીએ છીએ.
    //     એટલે કે, `i` અને `i-1`.
    //  3. જો સ્લાઇસ યોગ્ય રીતે ગોઠવાયેલ છે, તો તત્વો યોગ્ય રીતે ગોઠવાયેલ છે.
    //     સ્લાઇસ યોગ્ય રીતે ગોઠવાયેલ છે તેની ખાતરી કરવા માટે ક toલરની જવાબદારી છે.
    //
    // વધુ વિગત માટે નીચેની ટિપ્પણીઓ જુઓ.
    unsafe {
        // જો પ્રથમ બે તત્વો-ર્ડર-આઉટ-areર્ડર હોય તો ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // પ્રથમ તત્વને સ્ટેક-ફાળવેલ ચલમાં વાંચો.
            // જો નીચેની તુલનાત્મક કામગીરી panics, `hole` ઘટી જશે અને આપમેળે તત્વને ફરીથી કાપી નાંખશે.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // તત્વને એક જગ્યાએ ડાબી તરફ ખસેડો, આમ છિદ્રને જમણી તરફ સ્થાનાંતરિત કરો.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` છોડી દેવામાં આવે છે અને તેથી `v` ને બાકીના છિદ્રમાં `v` ની નકલ કરે છે.
        }
    }
}

/// જ્યાં સુધી તે નાના અથવા સમાન તત્વનો સામનો ન કરે ત્યાં સુધી છેલ્લા તત્વને ડાબી તરફ સ્થાનાંતરિત કરો.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // સલામતી: નીચે અસુરક્ષિત કામગીરીમાં બાઉન્ડ ચેક (`get_unchecked` અને `get_unchecked_mut`) વગર અનુક્રમણિકા શામેલ છે.
    // અને મેમરી (`ptr::copy_nonoverlapping`) ને કyingપિ કરી રહ્યું છે.
    //
    // એ.અનુક્રમણિકા:
    //  1. અમે એરેનું કદ>=2 પર તપાસ્યું.
    //  2. અમે જે ઇન્ડેક્સિંગ કરીશું તે હંમેશાં વધુમાં વધુ `0 <= index < len-1` ની વચ્ચે હોય છે.
    //
    // બી.મેમરી કyingપિ
    //  1. અમે સંદર્ભોના નિર્દેશક પ્રાપ્ત કરી રહ્યા છીએ જે માન્ય હોવાની બાંયધરી છે.
    //  2. તેઓ ઓવરલેપ કરી શકતા નથી કારણ કે આપણે સ્લાઇસના સૂચકાંકોના તફાવત માટેના પોઇંટર પ્રાપ્ત કરીએ છીએ.
    //     એટલે કે, `i` અને `i+1`.
    //  3. જો સ્લાઇસ યોગ્ય રીતે ગોઠવાયેલ છે, તો તત્વો યોગ્ય રીતે ગોઠવાયેલ છે.
    //     સ્લાઇસ યોગ્ય રીતે ગોઠવાયેલ છે તેની ખાતરી કરવા માટે ક toલરની જવાબદારી છે.
    //
    // વધુ વિગત માટે નીચેની ટિપ્પણીઓ જુઓ.
    unsafe {
        // જો છેલ્લા બે તત્વો ઓર્ડર-ઓફ-ઓર્ડર હોય તો ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // સ્ટેક ફાળવેલ ચલ માં છેલ્લા તત્વ વાંચો.
            // જો નીચેની તુલનાત્મક કામગીરી panics, `hole` ઘટી જશે અને આપમેળે તત્વને ફરીથી કાપી નાંખશે.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // તત્વને એક જગ્યાએ જમણી તરફ ખસેડો, આમ છિદ્રને ડાબી તરફ ખસેડો.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` છોડી દેવામાં આવે છે અને તેથી `v` ને બાકીના છિદ્રમાં `v` ની નકલ કરે છે.
        }
    }
}

/// આસપાસના ઘણા-ર્ડર તત્વોને સ્થાનાંતરિત કરીને આંશિક રીતે સ્લાઇસને ગોઠવે છે.
///
/// જો સ્લાઇસને અંતે સortedર્ટ કરવામાં આવે તો `true` આપે છે.આ ફંક્શન *ઓ*(*એન*) સૌથી ખરાબ કેસ છે.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Adjર્ડર-આઉટ-pairsર્ડર જોડીની મહત્તમ સંખ્યા કે જે સ્થળાંતરિત થશે.
    const MAX_STEPS: usize = 5;
    // જો સ્લાઇસ આ કરતા ટૂંકી હોય, તો કોઈપણ ઘટકોને પાળી ન કરો.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // સલામતી: અમે પહેલાથી જ સ્પષ્ટરૂપે `i < len` સાથે બાઉન્ડ ચેકિંગ કર્યું છે.
        // અમારા પછીના બધા અનુક્રમણિકા ફક્ત `0 <= index < len` રેન્જમાં છે
        unsafe {
            // Adjર્ડર તત્વોની નજીકની આગામી જોડી શોધો.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // અમારું થઈ ગયું?
        if i == len {
            return true;
        }

        // ટૂંકા એરે પર તત્વો સ્થળાંતર કરશો નહીં, જેનો પ્રભાવ ખર્ચ છે.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // તત્વોની જોડી અદલાબદલ કરો.આ તેમને યોગ્ય ક્રમમાં મૂકે છે.
        v.swap(i - 1, i);

        // નાના તત્વને ડાબી તરફ શિફ્ટ કરો.
        shift_tail(&mut v[..i], is_less);
        // મોટા તત્વને જમણી તરફ શિફ્ટ કરો.
        shift_head(&mut v[i..], is_less);
    }

    // મર્યાદિત સંખ્યામાં પગલાઓમાં સ્લાઇસને સ sortર્ટ કરવાનું મેનેજ કર્યું નથી.
    false
}

/// ઇનસેશન સ sortર્ટની મદદથી સ્લાઈસને સortsર્ટ કરે છે, જે *ઓ*(*એન*^ 2) સૌથી ખરાબ કેસ છે.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// હેપ્સોર્ટનો ઉપયોગ કરીને `v` ને ગોઠવે છે, જે *ઓ*(*એન*\*log(* n*)) ખરાબ-કેસની બાંયધરી આપે છે.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // આ દ્વિસંગી heગલો આક્રમક `parent >= child` નો આદર કરે છે.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` ના બાળકો:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // મોટા બાળકને પસંદ કરો.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // જો અતિકારી `node` ધરાવે છે તો રોકો.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // મોટા બાળક સાથે `node` સ્વેપ કરો, એક પગલું નીચે ખસેડો, અને ચાલવાનું ચાલુ રાખો.
            v.swap(node, greater);
            node = greater;
        }
    };

    // લાઇનનો સમય theગલો બનાવો.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Fromગલામાંથી મહત્તમ તત્વો પ Popપ કરો.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` કરતા નાના તત્વોમાં પાર્ટીશનો `v`, ત્યારબાદ `pivot` કરતા વધારે અથવા સમાન તત્વો દ્વારા.
///
///
/// `pivot` કરતા નાના તત્વોની સંખ્યા આપે છે.
///
/// વિભાજન કામગીરીના ખર્ચને ઘટાડવા માટે પાર્ટીશનિંગ બ્લોક-બાય-બ્લોક કરવામાં આવે છે.
/// આ વિચાર [BlockQuicksort][pdf] કાગળમાં રજૂ કરવામાં આવ્યો છે.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // લાક્ષણિક બ્લોકમાં તત્વોની સંખ્યા.
    const BLOCK: usize = 128;

    // પાર્ટીશનિંગ એલ્ગોરિધમ પૂર્ણ થવા સુધી નીચેના પગલાંને પુનરાવર્તિત કરે છે:
    //
    // 1. પીવટથી વધુ અથવા સમાન તત્વોને ઓળખવા માટે ડાબી બાજુથી એક બ્લોક ટ્રેસ કરો.
    // 2. ધરી કરતા નાના તત્વોને ઓળખવા માટે જમણી બાજુથી એક બ્લોકને ટ્રેસ કરો.
    // 3. ડાબી અને જમણી બાજુ વચ્ચે ઓળખાતા તત્વોની આપલે કરો.
    //
    // તત્વોના બ્લોક માટે અમે નીચેના ચલો રાખીએ છીએ:
    //
    // 1. `block` - બ્લોકમાં તત્વોની સંખ્યા.
    // 2. `start` - `offsets` એરેમાં પોઇન્ટર પ્રારંભ કરો.
    // 3. `end` - `offsets` એરેમાં અંત નિર્દેશક.
    // 4. se seફસેટ્સ, બ્લોકની અંદરના ઓર્ડર તત્વોના સૂચકાંકો.

    // ડાબી બાજુ પરનો વર્તમાન અવરોધ (`l` થી `l.add(block_l)`) સુધી).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // જમણી બાજુ પરનો વર્તમાન બ્લોક (`r.sub(block_r)` to `r`) થી.
    // સલામતી: .add() માટેના દસ્તાવેજોમાં ખાસ ઉલ્લેખિત છે કે `vec.as_ptr().add(vec.len())` હંમેશા સલામત છે`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: જ્યારે અમને VLA મળે છે, તેના બદલે, `min(v.len(), 2 * બ્લ lengthક) ની લંબાઈની એક એરે બનાવવાનો પ્રયાસ કરો
    // લંબાઈના `BLOCK` ની બે નિશ્ચિત-કદની એરેથી વધુ.VLAs વધુ કેશ-કાર્યક્ષમ હોઈ શકે છે.

    // `l` (inclusive) અને `r` (exclusive) વચ્ચેના તત્વોની સંખ્યા પરત આપે છે.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // જ્યારે `l` અને `r` ખૂબ નજીક આવે ત્યારે પાર્ટીશનિંગ બ્લોક-બાય-બ્લોક સાથે અમે પૂર્ણ કર્યું છે.
        // પછી અમે બાકીના તત્વોને વચ્ચેથી વિભાજીત કરવા માટે કેટલાક પેચ-અપ કાર્ય કરીએ છીએ.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // બાકી રહેલા તત્વોની સંખ્યા (હજી પણ મુખ્યની તુલનામાં નથી).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // બ્લોકના કદને સમાયોજિત કરો જેથી ડાબી અને જમણી બાજુનો બ્લોક ઓવરલેપ ન થાય, પરંતુ સંપૂર્ણ બાકીના અંતરને આવરી લેવા માટે સંપૂર્ણ રીતે ગોઠવાય.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ડાબી બાજુથી `block_l` તત્વોને ટ્રેસ કરો.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // સલામત: નીચેની અસફળ કામગીરીમાં `offset` નો ઉપયોગ શામેલ છે.
                //         ફંક્શન દ્વારા જરૂરી શરતો અનુસાર, અમે તેમને સંતોષીએ છીએ કારણ કે:
                //         1. `offsets_l` સ્ટેક ફાળવેલ છે, અને તેથી અલગ ફાળવેલ .બ્જેક્ટ માનવામાં આવે છે.
                //         2. ફંક્શન `is_less` એક `bool` આપે છે.
                //            `bool` કાસ્ટ કરવાથી `isize` ક્યારેય ઓવરફ્લો થશે નહીં.
                //         3. અમે બાંયધરી આપી છે કે `block_l` `<= BLOCK` હશે.
                //            ઉપરાંત, `end_l` શરૂઆતમાં `offsets_` ના પ્રારંભિક નિર્દેશક પર સેટ કરવામાં આવ્યું હતું જે સ્ટેક પર જાહેર કરાયું હતું.
                //            આમ, આપણે જાણીએ છીએ કે સૌથી ખરાબ કિસ્સામાં પણ (`is_less` ના બધા જ નિવેદનો ખોટા વળતર આપે છે) આપણે ફક્ત 1 બાઇટ અંતથી પસાર થઈશું.
                //        અહીં બીજું અસફળ operationપરેશન, `elem` ને ડિરેફરન્સ કરવું છે.
                //        જો કે, `elem` એ શરૂઆતમાં સ્લાઇસનો પ્રારંભિક નિર્દેશક હતો જે હંમેશા માન્ય છે.
                unsafe {
                    // શાખા વિનાની તુલના.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // જમણી બાજુથી `block_r` તત્વો શોધો.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // સલામત: નીચેની અસફળ કામગીરીમાં `offset` નો ઉપયોગ શામેલ છે.
                //         ફંક્શન દ્વારા જરૂરી શરતો અનુસાર, અમે તેમને સંતોષીએ છીએ કારણ કે:
                //         1. `offsets_r` સ્ટેક ફાળવેલ છે, અને તેથી અલગ ફાળવેલ .બ્જેક્ટ માનવામાં આવે છે.
                //         2. ફંક્શન `is_less` એક `bool` આપે છે.
                //            `bool` કાસ્ટ કરવાથી `isize` ક્યારેય ઓવરફ્લો થશે નહીં.
                //         3. અમે બાંયધરી આપી છે કે `block_r` `<= BLOCK` હશે.
                //            ઉપરાંત, `end_r` શરૂઆતમાં `offsets_` ના પ્રારંભિક નિર્દેશક પર સેટ કરવામાં આવ્યું હતું જે સ્ટેક પર જાહેર કરાયું હતું.
                //            આમ, આપણે જાણીએ છીએ કે સૌથી ખરાબ કિસ્સામાં પણ (`is_less` ના બધા જ આમંત્રણો સાચા વળતર આપે છે) આપણે ફક્ત 1 બાઇટ અંતમાં પસાર થઈશું.
                //        અહીં બીજું અસફળ operationપરેશન, `elem` ને ડિરેફરન્સ કરવું છે.
                //        જો કે, `elem` શરૂઆતમાં અંતથી `1 *sizeof(T)` હતું અને અમે તેને beforeક્સેસ કરતા પહેલા `1* sizeof(T)` દ્વારા તેને ઘટાડીએ છીએ.
                //        પ્લસ, `block_r` એ `BLOCK` કરતા ઓછું હોવાનું જણાવેલ હતું અને `elem` તેથી વધુની સ્લાઈસની શરૂઆત તરફ ધ્યાન દોરવામાં આવશે.
                unsafe {
                    // શાખા વિનાની તુલના.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // ડાબી અને જમણી બાજુ વચ્ચે અદલાબદલ કરવા માટેના ઓર્ડર-ઓર્ડર તત્વોની સંખ્યા.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // તે સમયે એક જોડી અદલાબદલ કરવાને બદલે, ચક્રીય ક્રમચય કરવા માટે તે વધુ કાર્યક્ષમ છે.
            // આ અદૃશ્ય રીતે અદલાબદલ કરવા સમાન નથી, પરંતુ ઓછા મેમરી operationsપરેશંસનો ઉપયોગ કરીને સમાન પરિણામ ઉત્પન્ન કરે છે.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // ડાબી બ્લોકમાં બધા outર્ડર .ફ તત્વો ખસેડવામાં આવ્યા હતા.આગલા બ્લોક પર ખસેડો.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // જમણા અવરોધમાંના બધા આઉટ-ઓર્ડર તત્વો ખસેડવામાં આવ્યા હતા.પાછલા બ્લોક પર ખસેડો.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // હમણાં જે બાકી છે તે ઓછામાં ઓછું એક બ્લોક છે (ક્યાં તો ડાબી કે જમણી) ઓર્ડર ofફ-ઓર્ડર તત્વો છે જેને ખસેડવાની જરૂર છે.
    // આવા બાકીના તત્વો સરળતાથી તેમના બ્લોકની અંતમાં સ્થાનાંતરિત કરી શકાય છે.
    //

    if start_l < end_l {
        // ડાબો અવરોધ બાકી છે.
        // તેના બાકીના આઉટ-.ર્ડર તત્વોને ખૂબ જ જમણે ખસેડો.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // જમણો બ્લોક બાકી છે.
        // તેના બાકીના આઉટ-orderર્ડર તત્વોને દૂર ડાબી તરફ ખસેડો.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // બીજું કંઇ કરવાનું નથી, અમે પૂર્ણ કરી લીધું છે.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` કરતા નાના તત્વોમાં પાર્ટીશનો `v`, ત્યારબાદ `v[pivot]` કરતા વધારે અથવા સમાન તત્વો દ્વારા.
///
///
/// આનો મોટો ભાગ આપે છે:
///
/// 1. `v[pivot]` કરતા નાના તત્વોની સંખ્યા.
/// 2. સાચું જો `v` પહેલાથી પાર્ટીશન કરેલું છે.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // સ્લાઈસની શરૂઆતમાં ધરીને મૂકો.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // કાર્યક્ષમતા માટે મુખ્યને સ્ટેક-ફાળવેલ ચલમાં વાંચો.
        // જો નીચે આપેલ તુલનાત્મક કામગીરી panics, તો પાઇવટ આપમેળે પાછા સ્લાઈસમાં લખવામાં આવશે.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ઓર્ડર-ઓર્ડર તત્વોની પ્રથમ જોડી શોધો.
        let mut l = 0;
        let mut r = v.len();

        // સલામતી: નીચે અસફળમાં એરેને અનુક્રમણિકા શામેલ છે.
        // પ્રથમ એક માટે: અમે પહેલાથી જ અહીં `l < r` સાથે બાઉન્ડિંગ્સ ચકાસી રહ્યા છીએ.
        // બીજા માટે: આપણી પાસે શરૂઆતમાં `l == 0` અને `r == v.len()` છે અને અમે દરેક ઇન્ડેક્સીંગ ઓપરેશનમાં તે `l < r` તપાસ્યું છે.
        //                     અહીંથી આપણે જાણીએ છીએ કે `r` ઓછામાં ઓછું `r == l` હોવું આવશ્યક છે જે પહેલાથી માન્ય હોવાનું દર્શાવવામાં આવ્યું હતું.
        unsafe {
            // પીવટ કરતા વધારે અથવા તેના સમાન બરાબર પ્રથમ તત્વ શોધો.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // મુખ્ય છેલ્લું તત્વ ઓછું શોધો.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` અવકાશની બહાર જાય છે અને પાઇવોટ લખે છે (જે સ્ટેક-ફાળવેલ ચલ છે) જે સ્લાઈસમાં તે મૂળ હતી ત્યાં પાછું લખે છે.
        // સલામતી સુનિશ્ચિત કરવા માટે આ પગલું મહત્વપૂર્ણ છે!
        //
    };

    // બે પાર્ટીશનો વચ્ચે ધરી મૂકો.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` ની સમાન તત્વોમાં `v` ને `v[pivot]` કરતા વધારે તત્વો દ્વારા પાર્ટીશનો.
///
/// પીવટ જેટલા તત્વોની સંખ્યા આપે છે.
/// એવું માનવામાં આવે છે કે `v` માં પીવટ કરતા નાના તત્વો નથી.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // સ્લાઈસની શરૂઆતમાં ધરીને મૂકો.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // કાર્યક્ષમતા માટે મુખ્યને સ્ટેક-ફાળવેલ ચલમાં વાંચો.
    // જો નીચે આપેલ તુલનાત્મક કામગીરી panics, તો પાઇવટ આપમેળે પાછા સ્લાઈસમાં લખવામાં આવશે.
    // સલામતી: અહીંનો નિર્દેશક માન્ય છે કારણ કે તે સ્લાઇસના સંદર્ભમાંથી પ્રાપ્ત થાય છે.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // હવે સ્લાઈસ પાર્ટીશન કરો.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // સલામતી: નીચે અસફળમાં એરેને અનુક્રમણિકા શામેલ છે.
        // પ્રથમ એક માટે: અમે પહેલાથી જ અહીં `l < r` સાથે બાઉન્ડિંગ્સ ચકાસી રહ્યા છીએ.
        // બીજા માટે: આપણી પાસે શરૂઆતમાં `l == 0` અને `r == v.len()` છે અને અમે દરેક ઇન્ડેક્સીંગ ઓપરેશનમાં તે `l < r` તપાસ્યું છે.
        //                     અહીંથી આપણે જાણીએ છીએ કે `r` ઓછામાં ઓછું `r == l` હોવું આવશ્યક છે જે પહેલાથી માન્ય હોવાનું દર્શાવવામાં આવ્યું હતું.
        unsafe {
            // ધરી કરતાં વધુ પ્રથમ તત્વ શોધો.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // ધરીની બરાબર છેલ્લું તત્વ શોધો.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // અમારું થઈ ગયું?
            if l >= r {
                break;
            }

            // ઓર્ડરનાં તત્વોની મળતી જોડી અદલાબદલ કરો.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // અમને `l` તત્વો પીવટ જેટલા મળ્યાં.મુખ્ય માટે ખાતામાં 1 ઉમેરો.
    l + 1

    // `_pivot_guard` અવકાશની બહાર જાય છે અને પાઇવોટ લખે છે (જે સ્ટેક-ફાળવેલ ચલ છે) જે સ્લાઈસમાં તે મૂળ હતી ત્યાં પાછું લખે છે.
    // સલામતી સુનિશ્ચિત કરવા માટે આ પગલું મહત્વપૂર્ણ છે!
}

/// પેટર્ન તોડવાના પ્રયાસમાં કેટલાક તત્વોને આસપાસમાં ફેલાવે છે જે ક્વિક્સર્ટમાં અસંતુલિત પાર્ટીશનોનું કારણ બની શકે છે.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // જ્યોર્જ માર્સાગલિયા દ્વારા "Xorshift RNGs" પેપરમાંથી સ્યુડોરન્ડોમ નંબર જનરેટર.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // આ નંબરના મોડ્યુલોને રેન્ડમ નંબરો લો.
        // સંખ્યા `usize` માં બંધબેસે છે કારણ કે `len` `isize::MAX` કરતા વધારે નથી.
        let modulus = len.next_power_of_two();

        // કેટલાક ધરી ઉમેદવારો આ અનુક્રમણિકાની નજીકમાં હશે.ચાલો તેમને રેન્ડમાઇઝ કરીએ.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // રેન્ડમ નંબર મોડ્યુલો `len` બનાવો.
            // જો કે, ખર્ચાળ કામગીરીને ટાળવા માટે, અમે પહેલા તેને બેની શક્તિનો મોડ્યુલો લઈએ છીએ, અને પછી તે `[0, len - 1]` રેન્જમાં બંધ ન થાય ત્યાં સુધી `len` દ્વારા ઘટાડે છે.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` કરતા ઓછી હોવાની બાંયધરી આપવામાં આવી છે.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` માં એક મુખ્ય પસંદ કરે છે અને જો સ્લાઇસ પહેલેથી સ .ર્ટ કરેલી હોય તો અનુક્રમણિકા અને `true` આપે છે.
///
/// પ્રક્રિયામાં `v` માં તત્વો ફરીથી ગોઠવવામાં આવી શકે છે.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // મધ્ય-ઓફ-મેડિઅન્સ પદ્ધતિ પસંદ કરવા માટે લઘુત્તમ લંબાઈ.
    // ટૂંકી કાપી નાંખ્યું ત્રણ સરળ પદ્ધતિનો ઉપયોગ કરે છે.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // આ કાર્યમાં કરી શકાય તેવા સ્વેપ્સની મહત્તમ સંખ્યા.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ત્રણ સૂચકાંકો કે જેની નજીક અમે મુખ્યને પસંદ કરવા જઈ રહ્યા છીએ.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // સૂચકાંકોની સingર્ટ કરતી વખતે અમે જે સ્વેપ કરવાના છીએ તે કુલ સંખ્યાની ગણતરી કરે છે.
    let mut swaps = 0;

    if len >= 8 {
        // સૂચકાંકો અદલાબદલી કરે છે જેથી `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // સૂચકાંકો અદલાબદલી કરે છે જેથી `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` ની મધ્યમ શોધે છે અને અનુક્રમણિકાને `a` માં સ્ટોર કરે છે.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` અને `c` ના પડોશમાં મધ્યસ્થીઓ શોધો.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` અને `c` વચ્ચેના મધ્યને શોધો.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // સ્વેપ્સની મહત્તમ સંખ્યા કરવામાં આવી હતી.
        // શક્યતા છે કે સ્લાઇસ ઉતરતી હોય અથવા મોટે ભાગે ઉતરતી હોય, તેથી વિપરીત થવું કદાચ તેને ઝડપથી સ sortર્ટ કરવામાં મદદ કરશે.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` ને વારંવાર ક્રમમાં ગોઠવે છે.
///
/// જો સ્લાઈસમાં મૂળ એરેમાં પૂર્વગામી હોય, તો તે `pred` તરીકે ઉલ્લેખિત છે.
///
/// `limit` `heapsort` પર સ્વિચ કરતા પહેલા માન્ય અસંતુલિત પાર્ટીશનોની સંખ્યા છે.
/// જો શૂન્ય છે, તો આ ફંક્શન તરત જ હીપ્સપોર્ટ પર સ્વિચ કરશે.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // આ લંબાઈ સુધીની કાપી નાંખવાના સ sortર્ટની મદદથી સ getર્ટ થાય છે.
    const MAX_INSERTION: usize = 20;

    // સાચું જો છેલ્લા પાર્ટીશન વ્યાજબી રીતે સંતુલિત હોત.
    let mut was_balanced = true;
    // સાચું જો છેલ્લા પાર્ટીશનમાં તત્વો શફલ ન થાય (સ્લાઇસ પહેલેથી પાર્ટીશન કરેલી છે).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // નિવેશ સ sortર્ટની મદદથી ખૂબ જ ટૂંકી ટુકડાઓ સortedર્ટ થાય છે.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // જો ઘણી બધી ખરાબ પાઇવોટ પસંદગીઓ કરવામાં આવી હોય, તો `O(n * log(n))` સૌથી ખરાબ કેસની બાંયધરી આપવા માટે હીપ્સોર્ટ પર પાછા ફરો.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // જો છેલ્લું પાર્ટીશન અસંતુલિત હતું, તો આસપાસના કેટલાક તત્વોને શફલિંગ કરીને સ્લાઈસમાં પેટર્ન તોડવાનો પ્રયાસ કરો.
        // આશા છે કે આ વખતે આપણે એક વધુ સારું ધ્રુવ પસંદ કરીશું.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // એક ધરી પસંદ કરો અને અનુમાન લગાવવાનો પ્રયાસ કરો કે સ્લાઇસ પહેલેથી સortedર્ટ થયેલ છે કે નહીં.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // જો છેલ્લું પાર્ટીશન યોગ્ય રીતે સંતુલિત હતું અને તત્વોને ફેરવતો ન હતો, અને જો પાઇવટ સિલેક્શનની આગાહી કરે છે કે સ્લાઇસ પહેલેથી જ સ isર્ટ થયેલ છે ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Severalર્ડરના ઘણા તત્વોને ઓળખવાનો પ્રયાસ કરો અને તેમને યોગ્ય સ્થાનો પર ખસેડો.
            // જો સ્લાઇસ સંપૂર્ણ રીતે સ .ર્ટ થાય છે, તો અમે પૂર્ણ કરી લીધું છે.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // જો પસંદ કરેલો પીવટ પૂરોગામી સમાન હોય, તો પછી તે સ્લાઇસમાં સૌથી નાનો તત્વ છે.
        // કટકાને સમાન તત્વો અને પાઇવટ કરતા વધારે તત્વોમાં પાર્ટીશન કરો.
        // આ કેસને સામાન્ય રીતે ફટકારવામાં આવે છે જ્યારે સ્લાઇસમાં ઘણાં ડુપ્લિકેટ તત્વો હોય છે.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // પીવટ કરતા વધારે તત્વોને સingર્ટ કરવાનું ચાલુ રાખો.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ભાગ કાપી નાંખ્યું.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // સ્લાઈસને `left`, `pivot` અને `right` માં વિભાજીત કરો.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // પુનરાવર્તિત ક callsલ્સની કુલ સંખ્યાને ઘટાડવા અને ઓછી સ્ટેક સ્પેસનો વપરાશ કરવા માટે માત્ર ટૂંકી બાજુએ જ પુનરાવર્તન કરો.
        // પછી ફક્ત લાંબી બાજુ ચાલુ રાખો (આ પૂંછડી પુનરાવર્તન સમાન છે).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// પેટર્નને હરાવવાવાળા ક્વિક્સોર્ટનો ઉપયોગ કરીને `v` ને ગોઠવે છે, જે *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ છે).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // સ zeroર્ટિંગમાં શૂન્ય-કદના પ્રકારો પર કોઈ અર્થપૂર્ણ વર્તણૂક નથી.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // અસંતુલિત પાર્ટીશનોની સંખ્યાને `floor(log2(len)) + 1` સુધી મર્યાદિત કરો.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // આ લંબાઈ સુધીના કાપી નાંખવા માટે, ફક્ત તેમને સ toર્ટ કરવું વધુ ઝડપી છે.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // એક ધરી પસંદ કરો
        let (pivot, _) = choose_pivot(v, is_less);

        // જો પસંદ કરેલો પીવટ પૂરોગામી સમાન હોય, તો પછી તે સ્લાઇસમાં સૌથી નાનો તત્વ છે.
        // કટકાને સમાન તત્વો અને પાઇવટ કરતા વધારે તત્વોમાં પાર્ટીશન કરો.
        // આ કેસને સામાન્ય રીતે ફટકારવામાં આવે છે જ્યારે સ્લાઇસમાં ઘણાં ડુપ્લિકેટ તત્વો હોય છે.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // જો આપણે અમારું અનુક્રમણિકા પસાર કરી દીધું હોય, તો અમે સારા છીએ.
                if mid > index {
                    return;
                }

                // નહિંતર, પીવટ કરતા વધારે તત્વોને સingર્ટ કરવાનું ચાલુ રાખો.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // સ્લાઈસને `left`, `pivot` અને `right` માં વિભાજીત કરો.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // જો મધ્ય==અનુક્રમણિકા હોય, તો પછી અમે પૂર્ણ કરી લીધું, કારણ કે partition() એ ખાતરી આપી છે કે મધ્ય પછીના બધા તત્વો મધ્ય કરતા મોટા અથવા સમાન છે.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // સ zeroર્ટિંગમાં શૂન્ય-કદના પ્રકારો પર કોઈ અર્થપૂર્ણ વર્તણૂક નથી.કઈ જ નહી.
    } else if index == v.len() - 1 {
        // મહત્તમ તત્વ શોધો અને તેને એરેની છેલ્લી સ્થિતિમાં મૂકો.
        // અમે અહીં `unwrap()` નો ઉપયોગ કરવા માટે મુક્ત છીએ કારણ કે આપણે જાણીએ છીએ કે v ખાલી ન હોવો જોઈએ.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // મિનિટ તત્વ શોધો અને તેને એરેની પ્રથમ સ્થાને મૂકો.
        // અમે અહીં `unwrap()` નો ઉપયોગ કરવા માટે મુક્ત છીએ કારણ કે આપણે જાણીએ છીએ કે v ખાલી ન હોવો જોઈએ.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}