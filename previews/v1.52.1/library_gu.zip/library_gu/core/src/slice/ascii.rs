//! ASCII `[u8]` પર કામગીરી.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// આ સ્લાઈસના તમામ બાઇટ્સ ASCII રેન્જમાં છે કે કેમ તે તપાસે છે.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// તપાસ કરે છે કે બે કાપી નાંખેલી એ ASCII કેસ-સંવેદનશીલ મેચ છે.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ની જેમ જ, પરંતુ કામચલાઉ ફાળવણી અને ક copપિ કર્યા વિના.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// આ સ્લાઈસને તેના ASCII અપર કેસમાં સમાન સ્થાને રૂપાંતરિત કરે છે.
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું અપરકેસ્ડ મૂલ્ય પાછું આપવા માટે, [`to_ascii_uppercase`] નો ઉપયોગ કરો.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// આ સ્લાઈસને તેના ASCII લોઅર કેસમાં સમાન જગ્યાએ રૂપાંતરિત કરે છે.
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું નીચલું મૂલ્ય પાછું આપવા માટે, [`to_ascii_lowercase`] નો ઉપયોગ કરો.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// જો `v` શબ્દમાં કોઈ બાઇટ નોનસિસી (>=128) હોય તો `true` આપે છે.
/// `../str/mod.rs` થી સ્નarર્ફedડ, જે utf8 માન્યતા માટે કંઈક આવું કરે છે.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ASપ્ટિમાઇઝ થયેલ એએસસીઆઈઆઈ પરીક્ષણ કે જે બાઇટ-એટ-એ-ટાઇમ (પરેશન્સ (જ્યારે શક્ય હોય ત્યારે) ને બદલે યુઝાઇઝ-એ-એ-ટાઇમ ઓપરેશન્સનો ઉપયોગ કરશે.
///
/// આપણે અહીં અલ્ગોરિધમનો ઉપયોગ કરીએ છીએ તે ખૂબ સરળ છે.જો `s` ખૂબ ટૂંકું છે, તો અમે ફક્ત દરેક બાઇટ તપાસીએ છીએ અને તેની સાથે થઈશું.અન્યથા:
///
/// - પહેલો શબ્દ અનલિએન્ડ લોડ સાથે વાંચો.
/// - પોઇન્ટરને સંરેખિત કરો, સંરેખિત લોડ્સ સાથે અંત સુધી અનુગામી શબ્દો વાંચો.
/// - અનલિએન્ડ લોડ સાથે `s` માંથી છેલ્લું `usize` વાંચો.
///
/// જો આમાંથી કોઈપણ લોડ કંઈક ઉત્પન્ન કરે છે જેના માટે `contains_nonascii` (above) સાચું વળતર આપે છે, તો આપણે જાણીએ છીએ કે જવાબ ખોટો છે.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // જો આપણે શબ્દ-સમયે-સમયના અમલીકરણથી કંઈ મેળવીશું નહીં, તો પાછા સ્કેલેર લૂપ પર આવી જાઓ.
    //
    // અમે આર્કિટેક્ચરો માટે પણ કરીએ છીએ જ્યાં `size_of::<usize>()` એ `usize` માટે પૂરતી ગોઠવણી નથી, કારણ કે તે એક વિચિત્ર edge કેસ છે.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // અમે હંમેશાં પહેલો શબ્દ અનલિએન્ડ વાંચ્યો, જેનો અર્થ `align_offset` છે
    // 0, અમે સંરેખિત વાંચવા માટે ફરીથી સમાન મૂલ્ય વાંચીશું.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // સલામતી: અમે ઉપરના `len < USIZE_SIZE` ને ચકાસીએ છીએ.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // આપણે આ ઉપરથી તપાસી હતી, કંઈક અંશે ગર્ભિત રીતે.
    // નોંધ લો કે `offset_to_aligned` એ ક્યાં તો `align_offset` અથવા `USIZE_SIZE` છે, બંને ઉપર સ્પષ્ટપણે તપાસવામાં આવી છે.
    //
    debug_assert!(offset_to_aligned <= len);

    // સલામતી: word_ptr એ (યોગ્ય રીતે ગોઠવાયેલ) વપરાશ ptr છે જે આપણે વાંચવા માટે વાપરીએ છીએ
    // સ્લાઈસનો મધ્ય ભાગ
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` લૂપ એન્ડ ચકાસણી માટે વપરાયેલ, `word_ptr` નું બાઇટ અનુક્રમણિકા છે.
    let mut byte_pos = offset_to_aligned;

    // પેરાનોઇયા ગોઠવણી વિશે તપાસો, કારણ કે અમે અનલિઇન્ડ લોડ્સનો સમૂહ કરવા જઇ રહ્યા છીએ.
    // વ્યવહારમાં તેમ છતાં `align_offset` માં ભૂલને અવગણવું અશક્ય હોવું જોઈએ.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // પછીની પૂંછડી તપાસમાં પૂરા પાડવામાં આવેલા શબ્દોને જાતે જ બાકાત રાખીને છેલ્લા સંરેખિત શબ્દ સુધી અનુગામી શબ્દો વાંચો, પૂંછડી હંમેશાં એક `usize` છે તે સુનિશ્ચિત કરવા માટે વધારાની ઝેડબ્રાન્ચ0 ઝેડ X00 એક્સ.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // સેનીટી તપાસો કે વાંચન મર્યાદામાં છે
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // અને તે `byte_pos` વિશેની અમારી ધારણાઓ ધરાવે છે.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // સલામતી: આપણે જાણીએ છીએ કે `word_ptr` યોગ્ય રીતે ગોઠવાયેલ છે (કારણ કે
        // `align_offset`), અને આપણે જાણીએ છીએ કે આપણી પાસે `word_ptr` અને અંતની વચ્ચે પૂરતા બાઇટ્સ છે
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // સલામતી: આપણે જાણીએ છીએ કે `byte_pos <= len - USIZE_SIZE`, જેનો અર્થ છે કે
        // આ `add` પછી, `word_ptr` એ એકથી વધુની ભૂતકાળમાં હશે.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ત્યાં ખરેખર એક જ `usize` બાકી છે તેની ખાતરી કરવા માટે સેનીટી તપાસો.
    // આ આપણી લૂપ સ્થિતિ દ્વારા બાંયધરી આપવી જોઈએ.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // સલામતી: આ `len >= USIZE_SIZE` પર આધાર રાખે છે, જેને આપણે શરૂઆતમાં તપાસીએ છીએ.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}