//! સ્લાઇસના પુનરાવર્તકો દ્વારા ઉપયોગમાં લેવામાં આવતા મેક્રોઝ.

// ઇનલાઈનિંગ ઇઝ એમ્પ્ટી અને લેન એક પ્રદર્શનમાં મોટો તફાવત બનાવે છે
macro_rules! is_empty {
    // જે રીતે અમે ઝેડએસટી ઇટરેટરની લંબાઈને એન્કોડ કરીએ છીએ, આ ઝેડએસટી અને નોન-ઝેડએસટી બંને માટે કાર્ય કરે છે.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// કેટલીક સીમાઓની તપાસમાંથી છૂટકારો મેળવવા માટે (`position` જુઓ), અમે લંબાઈને અણધારી રીતે ગણતરી કરીએ છીએ.
// (`કોડજેન/સ્લાઈસ-પોઝિશન-બાઉન્ડ્સ-ચેક દ્વારા પરીક્ષણ કર્યું છે.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // અમે કેટલીકવાર અસુરક્ષિત બ્લ withinકની અંદર ઉપયોગમાં લેવાય છે

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // આ _cannot_ `unchecked_sub` નો ઉપયોગ કરે છે કારણ કે આપણે લાંબી ઝેડએસટી સ્લાઈસ ઇટિટર્સની લંબાઈને રજૂ કરવા માટે રેપિંગ પર આધારીત છીએ.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // આપણે જાણીએ છીએ કે `start <= end`, તેથી `offset_from` કરતા વધુ સારું કરી શકે છે, જેને સાઇન ઇન કરાવવાની જરૂર છે.
            // અહીં યોગ્ય ફ્લેગો ગોઠવીને આપણે એલએલવીએમને આ કહી શકીએ છીએ, જે તેને સીમાની તપાસમાં દૂર કરવામાં મદદ કરે છે.
            // સલામતી: આક્રમક પ્રકાર દ્વારા, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // એલએલવીએમને એમ પણ કહીને કે નિર્દેશકો પ્રકારનાં કદના ચોક્કસ ગુણાકારથી જુદા છે, તે `(end - start) < size` ને બદલે `len() == 0` ને `start == end` પર izeપ્ટિમાઇઝ કરી શકે છે.
            //
            // સલામતી: આક્રમક પ્રકાર દ્વારા, નિર્દેશકો ગોઠવાયેલ હોય છે તેથી
            //         તેમની વચ્ચેનું અંતર પોઇન્ટી કદનું બહુવિધ હોવું આવશ્યક છે
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` અને `IterMut` પુનરાવર્તકોની શેર કરેલી વ્યાખ્યા
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // પ્રથમ તત્વ પરત કરે છે અને ઇરેટરની શરૂઆતને 1 દ્વારા આગળ વધે છે.
        // ઇનિલિડ ફંક્શનની તુલનામાં પ્રભાવમાં ખૂબ સુધારો.
        // પુનરાવર્તક ખાલી હોવું જોઈએ નહીં.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // છેલ્લું તત્વ પરત કરે છે અને 1 દ્વારા ઇરેટરના અંતને પાછળની બાજુ ખસેડે છે.
        // ઇનિલિડ ફંક્શનની તુલનામાં પ્રભાવમાં ખૂબ સુધારો.
        // પુનરાવર્તક ખાલી હોવું જોઈએ નહીં.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // જ્યારે એક્સ ઝેડએસટી હોય ત્યારે ઇરેટરને સંકોચો, એક્સરેટરેટરના અંતને પાછળથી `n` દ્વારા ખસેડીને.
        // `n` `self.len()` કરતાં વધુ ન હોવું જોઈએ.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // પુનરાવર્તકમાંથી સ્લાઇસ બનાવવા માટે સહાયક કાર્ય.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // સલામતી: પુનરાવર્તક નિર્દેશક સાથેની સ્લાઇસમાંથી બનાવવામાં આવ્યું હતું
                // `self.ptr` અને લંબાઈ `len!(self)`.
                // આ ખાતરી આપે છે કે `from_raw_parts` માટેની બધી પૂર્વજરૂરીયાતો પૂર્ણ થઈ છે.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // `offset` તત્વો દ્વારા પુનરાવર્તકની શરૂઆતને આગળ વધારવા માટે સહાયક કાર્ય, જૂની શરૂઆત પરત.
            //
            // અસુરક્ષિત કારણ કે setફસેટ `self.len()` કરતા વધુ ન હોવું જોઈએ.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // સલામતી: કlerલર ખાતરી આપે છે કે `offset` `self.len()` કરતાં વધુ નથી,
                    // તેથી આ નવું નિર્દેશક `self` ની અંદર છે અને તેથી તે ન nonન-નલ હોવાની બાંયધરી આપે છે.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // `offset` તત્વો દ્વારા પુનરાવર્તકના અંતને પાછળની બાજુ ખસેડવા માટે મદદગાર કાર્ય, નવો અંત પાછો ફરવો.
            //
            // અસુરક્ષિત કારણ કે setફસેટ `self.len()` કરતા વધુ ન હોવું જોઈએ.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // સલામતી: કlerલર ખાતરી આપે છે કે `offset` `self.len()` કરતાં વધુ નથી,
                    // જે `isize` ઓવરફ્લો નહીં કરવાની ખાતરી આપી છે.
                    // ઉપરાંત, પરિણામી નિર્દેશક `slice` ની મર્યાદામાં છે, જે `offset` માટેની અન્ય આવશ્યકતાઓને પૂર્ણ કરે છે.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // કાપી નાંખ્યું સાથે અમલમાં મૂકી શકાય છે, પરંતુ આ સીમાઓની ચકાસણી ટાળે છે

                // સલામતી: સ્લાઈસના પ્રારંભિક નિર્દેશકથી `assume` ક callsલ્સ સલામત છે
                // નોન-નલ હોવું આવશ્યક છે, અને નોન-ઝેડએસટી ઉપરના કાપેલા ભાગોમાં નોન-નલ એન્ડ પોઇન્ટર પણ હોવા આવશ્યક છે.
                // `next_unchecked!` પર ક callલ સલામત છે કારણ કે આપણે તપાસ કરીએ છીએ કે પુનરાવર્તક પહેલા ખાલી છે કે નહીં.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // આ પુનરાવર્તક હવે ખાલી છે.
                    if mem::size_of::<T>() == 0 {
                        // આપણે તેને આ રીતે કરવું પડશે કારણ કે `ptr` ક્યારેય 0 ન હોઈ શકે, પરંતુ `end` (રેપિંગને કારણે) હોઈ શકે છે.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // સલામતી: જો ટી ઝેડએસટી ન હોય તો અંત 0 હોઈ શકતો નથી કારણ કે પીટીઆર 0 નથી અને અંત>=પીટીઆરટી
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // સલામતી: આપણે મર્યાદામાં છીએ.ઝેડએસટીએસ માટે પણ `post_inc_start` યોગ્ય વસ્તુ કરે છે.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            // ઉપરાંત, `assume` બાઉન્ડ્સ ચેકને ટાળે છે.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // સલામતી: આપણે લૂપ અતિક્રમણકાર દ્વારા બાઉન્ડ્રીમાં રહેવાની બાંયધરી આપી છે:
                        // જ્યારે `i >= n`, `self.next()` `None` પરત આપે છે અને લૂપ તૂટી જાય છે.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // અમે ડિફોલ્ટ અમલીકરણને ઓવરરાઇડ કરીએ છીએ, જે `try_fold` નો ઉપયોગ કરે છે, કારણ કે આ સરળ અમલીકરણ ઓછી એલએલવીએમ આઈઆર ઉત્પન્ન કરે છે અને કમ્પાઇલ કરવા માટે વધુ ઝડપી છે.
            // ઉપરાંત, `assume` બાઉન્ડ્સ ચેકને ટાળે છે.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // સલામતી: `i` એ `n` થી પ્રારંભ થતાં `n` કરતા ઓછું હોવું આવશ્યક છે
                        // અને ફક્ત ઘટતું જ છે.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // સલામતી: કlerલરને બાંયધરી આપવી આવશ્યક છે કે `i` ની મર્યાદામાં છે
                // અંતર્ગત સ્લાઇસ, તેથી `i` કોઈ `isize` ઓવરફ્લો કરી શકશે નહીં, અને પરત સંદર્ભોને સ્લાઇસના તત્વનો સંદર્ભિત કરવાની બાંયધરી આપવામાં આવી છે અને આમ માન્ય હોવા માટેની બાંયધરી આપવામાં આવી છે.
                //
                // એ પણ નોંધ લો કે કlerલર એ પણ ખાતરી આપે છે કે અમને ફરીથી એક જ અનુક્રમણિકા સાથે કદી પણ બોલાવવામાં આવતો નથી, અને તે અન્ય કોઈ પદ્ધતિઓ કે જે આ ઉપનામનો ઉપયોગ કરશે તેને બોલાવવામાં આવતી નથી, તેથી પરત સંદર્ભ સંદર્ભમાં પરિવર્તનશીલ હોવું તે માન્ય છે.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // કાપી નાંખ્યું સાથે અમલમાં મૂકી શકાય છે, પરંતુ આ સીમાઓની ચકાસણી ટાળે છે

                // સલામતી: સ્લાઈસનો પ્રારંભિક નિર્દેશક બિન-શૂન્ય હોવા જ જોઈએ, `assume` ક callsલ્સ સલામત છે,
                // અને નોન-ઝેડએસટી ઉપરની કાપણીઓમાં નોન-નલ એન્ડ પોઇન્ટર પણ હોવું આવશ્યક છે.
                // `next_back_unchecked!` પર ક callલ સલામત છે કારણ કે આપણે તપાસ કરીએ છીએ કે પુનરાવર્તક પહેલા ખાલી છે કે નહીં.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // આ પુનરાવર્તક હવે ખાલી છે.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // સલામતી: આપણે મર્યાદામાં છીએ.ઝેડએસટીએસ માટે પણ `pre_dec_end` યોગ્ય વસ્તુ કરે છે.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}