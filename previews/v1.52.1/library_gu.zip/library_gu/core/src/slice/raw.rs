//! `&[T]` અને `&mut [T]` બનાવવા માટે મફત કાર્યો.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// પોઇન્ટર અને લંબાઈથી સ્લાઈસ બનાવે છે.
///
/// `len` દલીલ **તત્વો** ની સંખ્યા છે, બાઇટ્સની સંખ્યા નથી.
///
/// # Safety
///
/// જો નીચેની શરતોમાંથી કોઈનું ઉલ્લંઘન કરવામાં આવે તો વર્તન અનિશ્ચિત છે:
///
/// * `data` `len * mem::size_of::<T>()` ઘણા બાઇટ્સ વાંચવા માટે [valid] હોવું આવશ્યક છે, અને તે યોગ્ય રીતે ગોઠવાયેલ હોવું જોઈએ.આનો અર્થ ખાસ કરીને:
///
///     * આ ટુકડાની આખી મેમરી રેંજ એક જ ફાળવેલ objectબ્જેક્ટમાં હોવી આવશ્યક છે!
///       સ્લાઇસેસ ક્યારેય બહુવિધ ફાળવેલ acrossબ્જેક્ટ્સ પર ફેલાતી નથી.ખોટી રીતે આને ધ્યાનમાં ન લેતા ઉદાહરણ માટે [below](#incorrect-usage) જુઓ.
///     * `data` શૂન્ય-લંબાઈના કાપી નાંખવા માટે પણ બિન-નલ અને સંરેખિત હોવું આવશ્યક છે.
///     આનું એક કારણ એ છે કે ઇનોમ લેઆઉટ optimપ્ટિમાઇઝેશન, સંદર્ભોને (કોઈપણ લંબાઈના ટુકડા સહિત) પર આધાર રાખે છે અને તેને અન્ય ડેટાથી અલગ કરવા માટે બિન-નલ છે.
///     તમે એક નિર્દેશક મેળવી શકો છો જે [`NonNull::dangling()`] નો ઉપયોગ કરીને શૂન્ય-લંબાઈના કાપી નાંખવા માટે `data` તરીકે ઉપયોગી છે.
///
/// * `data` `T` પ્રકારનાં સતત યોગ્ય રીતે પ્રારંભિક મૂલ્યોમાં `len` તરફ નિર્દેશ કરવો આવશ્યક છે.
///
/// * પરત સ્લાઈસ દ્વારા સંદર્ભિત મેમરીને `UnsafeCell` ની સિવાય, આજીવન `'a` સમયગાળા માટે પરિવર્તિત થવી જોઈએ નહીં.
///
/// * સ્લાઇસનો કુલ કદ `len * mem::size_of::<T>()`, `isize::MAX` કરતા મોટો ન હોવો જોઈએ.
///   [`pointer::offset`] નું સલામતી દસ્તાવેજીકરણ જુઓ.
///
/// # Caveat
///
/// પરત સ્લાઇસ માટેનો જીવનકાળ તેના ઉપયોગથી અનુમાનિત છે.
/// આકસ્મિક દુરૂપયોગને રોકવા માટે, આ સંદર્ભમાં સલામતી માટે, જીવનસાથીને જીવનસાથી સાથે જોડવાનું સૂચન કર્યું છે, જેમ કે સ્લાઈસ માટેના યજમાન મૂલ્યના જીવનકાળ દરમિયાન સહાયક કાર્ય પ્રદાન કરીને અથવા સ્પષ્ટ એનોટેશન દ્વારા.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // એક તત્વ માટે સ્લાઇસ પ્રગટ કરો
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### ખોટો વપરાશ
///
/// નીચેનું `join_slices` ફંક્શન **અનબાઉન્ડ** is છે
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // ઉપરોક્ત નિવેશ `fst` અને `snd` સુસંગત છે તેની ખાતરી કરે છે, પરંતુ તે હજી પણ _different allocated objects_ ની અંદર સમાયેલ છે, આ કિસ્સામાં આ કટકા બનાવવી તે અસ્પષ્ટ વર્તન છે.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` અને `b` એ વિવિધ ફાળવેલ objectsબ્જેક્ટ્સ છે ...
///     let a = 42;
///     let b = 27;
///     // ... જે તેમ છતાં યાદશક્તિમાં સાંકળી શકાય છે: |એ |બી |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // સલામતી: કlerલરને `from_raw_parts` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// પરિવર્તનીય સ્લાઇસ પરત આવે છે તે સિવાય [`from_raw_parts`] જેવી જ કાર્યક્ષમતા કરે છે.
///
/// # Safety
///
/// જો નીચેની શરતોમાંથી કોઈનું ઉલ્લંઘન કરવામાં આવે તો વર્તન અનિશ્ચિત છે:
///
/// * `data` ઘણા બાઇટ્સ `len * mem::size_of::<T>()` માટે બંને લખવા અને લખવા માટે [valid] હોવા આવશ્યક છે, અને તે યોગ્ય રીતે ગોઠવાયેલ હોવું જોઈએ.આનો અર્થ ખાસ કરીને:
///
///     * આ ટુકડાની આખી મેમરી રેંજ એક જ ફાળવેલ objectબ્જેક્ટમાં હોવી આવશ્યક છે!
///       સ્લાઇસેસ ક્યારેય બહુવિધ ફાળવેલ acrossબ્જેક્ટ્સ પર ફેલાતી નથી.
///     * `data` શૂન્ય-લંબાઈના કાપી નાંખવા માટે પણ બિન-નલ અને સંરેખિત હોવું આવશ્યક છે.
///     આનું એક કારણ એ છે કે ઇનોમ લેઆઉટ optimપ્ટિમાઇઝેશન, સંદર્ભોને (કોઈપણ લંબાઈના ટુકડા સહિત) પર આધાર રાખે છે અને તેને અન્ય ડેટાથી અલગ કરવા માટે બિન-નલ છે.
///
///     તમે એક નિર્દેશક મેળવી શકો છો જે [`NonNull::dangling()`] નો ઉપયોગ કરીને શૂન્ય-લંબાઈના કાપી નાંખવા માટે `data` તરીકે ઉપયોગી છે.
///
/// * `data` `T` પ્રકારનાં સતત યોગ્ય રીતે પ્રારંભિક મૂલ્યોમાં `len` તરફ નિર્દેશ કરવો આવશ્યક છે.
///
/// * પરત સ્લાઈસ દ્વારા સંદર્ભિત મેમરીને જીવનકાળ `'a` ના સમયગાળા માટે અન્ય કોઈ પોઇન્ટર (વળતર મૂલ્યમાંથી પ્રાપ્ત થતી નથી) દ્વારા notક્સેસ કરવી જોઈએ નહીં.
///   બંને વાંચવા અને લખવાની forbiddenક્સેસ પ્રતિબંધિત છે.
///
/// * સ્લાઇસનો કુલ કદ `len * mem::size_of::<T>()`, `isize::MAX` કરતા મોટો ન હોવો જોઈએ.
///   [`pointer::offset`] નું સલામતી દસ્તાવેજીકરણ જુઓ.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // સલામતી: કlerલરને `from_raw_parts_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// ટીના સંદર્ભને લંબાઈ 1 (કyingપિ કર્યા વિના) ની ટુકડામાં ફેરવે છે.
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// ટીના સંદર્ભને લંબાઈ 1 (કyingપિ કર્યા વિના) ની ટુકડામાં ફેરવે છે.
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}