// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` રેન્જને એવી રીતે ફેરવે છે કે `mid` પરનું તત્વ પ્રથમ ઘટક બને છે.સમાનરૂપે, `left` તત્વોને ડાબી તરફ અથવા `right` તત્વોને જમણી તરફ ફેરવે છે.
///
/// # Safety
///
/// વાંચવા અને લખવા માટે ઉલ્લેખિત શ્રેણી માન્ય હોવી આવશ્યક છે.
///
/// # Algorithm
///
/// એલ્ગોરિધમ 1 નો ઉપયોગ `left + right` ના નાના મૂલ્યો માટે અથવા મોટા `T` માટે થાય છે.
/// તત્વો `mid - left` થી શરૂ થતાં એક સમયે તેમની અંતિમ સ્થિતિમાં ખસેડવામાં આવે છે અને `right` પગલાં મોડ્યુલો `left + right` દ્વારા આગળ વધે છે, જેમ કે ફક્ત એક જ અસ્થાયી આવશ્યક છે.
/// આખરે, અમે પાછા `mid - left` પર આવીશું.
/// જો કે, જો `gcd(left + right, right)` 1 ન હોય, તો ઉપરોક્ત પગલા તત્વો પર છોડી દેવામાં આવશે.
/// દાખ્લા તરીકે:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// સદ્ભાગ્યે, અંતિમ તત્વો વચ્ચે તત્વો પર અવગણવાની સંખ્યા હંમેશા સમાન હોય છે, તેથી અમે ફક્ત અમારી પ્રારંભિક સ્થિતિને સરભર કરી શકીએ છીએ અને વધુ રાઉન્ડ કરી શકીએ છીએ (રાઉન્ડની કુલ સંખ્યા `gcd(left + right, right)` value) છે.
///
/// અંતિમ પરિણામ એ છે કે બધા તત્વો એકવાર અને માત્ર એક વાર અંતિમ સ્વરૂપ પ્રાપ્ત કરે છે.
///
/// એલ્ગોરિધમ 2 નો ઉપયોગ થાય છે જો `left + right` મોટું હોય પરંતુ સ્ટેક બફર પર ફિટ થવા માટે `min(left, right)` એટલું નાનું છે.
/// `min(left, right)` તત્વોને બફર પર કiedપિ કરવામાં આવે છે, `memmove` અન્ય પર લાગુ થાય છે, અને બફર પરના મુદ્દાઓ જ્યાંથી ઉદ્ભવ્યા છે તેનાથી વિરુદ્ધ બાજુના છિદ્રમાં પાછા ફર્યા છે.
///
/// એકવાર `left + right` પૂરતા પ્રમાણમાં મોટા થયા પછી ઉપરોક્ત પ્રદર્શન કરી શકાય તેવા એલ્ગોરિધમ્સ.
/// એલ્ગોરિધમ 1 ને એકસાથે ઘણા રાઉન્ડને ચૂંટીને કરીને પ્રદર્શન કરી શકાય છે, પરંતુ `left + right` પ્રચંડ ન થાય ત્યાં સુધી સરેરાશ ઘણા ઓછા રાઉન્ડ હોય છે, અને એક જ રાઉન્ડનો સૌથી ખરાબ કિસ્સામાં હંમેશા હોય છે.
/// તેના બદલે, નાના રોટેટ સમસ્યા બાકી ન થાય ત્યાં સુધી, અલ્ગોરિધમનો X `min(left, right)` એક્સ તત્વોના વારંવાર અદલાબદલનો ઉપયોગ કરે છે.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// જ્યારે `left < right` તેના બદલે ડાબી બાજુથી અદલાબદલ થાય છે.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. જો આ કેસો તપાસવામાં ન આવે તો નીચે અલ્ગોરિધમ્સ નિષ્ફળ થઈ શકે છે
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // એલ્ગોરિધમ 1 માઇક્રોબેંકમાર્ક્સ સૂચવે છે કે લગભગ `left + right == 32` સુધી રેન્ડમ શિફ્ટ માટેનું સરેરાશ પ્રદર્શન બધી રીતે વધુ સારું છે, પરંતુ સૌથી ખરાબ કેસ પ્રભાવ 16 ની આસપાસ પણ તૂટી જાય છે.
            // 24 ની મધ્યમ ભૂમિ તરીકે પસંદ કરવામાં આવી હતી.
            // જો `T` નું કદ 4 `usize`s કરતા વધારે છે, તો આ અલ્ગોરિધમનો અન્ય અલ્ગોરિધમનો પણ પ્રભાવ આપે છે.
            //
            //
            let x = unsafe { mid.sub(left) };
            // પ્રથમ રાઉન્ડની શરૂઆત
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ની ગણતરી કરીને હાથ પહેલાં શોધી શકાય છે, પરંતુ એક લૂપ કરવાનું વધુ ઝડપી છે જે જીસીડી ને આડઅસર તરીકે ગણતરી કરે છે, પછી બાકીનો ભાગ કરી
            //
            //
            let mut gcd = right;
            // બેંચમાર્ક્સ જણાવે છે કે એકવાર એક વખત અસ્થાયીક વાંચવાને બદલે, પાછળની નકલ કરીને, અને પછી તે કામચલાઉ લખાણ ખૂબ જ અંતમાં લખવાને બદલે ટેમ્પોરરીઝને અદૃશ્ય બનાવવાનું ઝડપી છે.
            // આ સંભવત the એ હકીકતને કારણે છે કે અસ્થાયીકરણોને અદલાબદલ કરવા અથવા બદલીને બે મેનેજ કરવાની જરૂરિયાતને બદલે લૂપમાં ફક્ત એક જ મેમરી સરનામું વપરાય છે.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ને વધારવાના બદલે અને પછી તે તપાસવાની મર્યાદાની બહાર છે કે નહીં તેની તપાસ કરતા, અમે તપાસીએ છીએ કે `i` આગામી ઇન્ક્રીમેન્ટ ઉપરની સીમાની બહાર જશે કે નહીં.
                // આ પોઇંટર્સ અથવા `usize` ના કોઈપણ રેપિંગને અટકાવે છે.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // પ્રથમ રાઉન્ડનો અંત
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // જો `left + right >= 15` હોય તો આ શરતી અહીં હોવી આવશ્યક છે
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // વધુ રાઉન્ડ સાથે ભાગ સમાપ્ત
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` તે શૂન્ય કદના પ્રકારનો નથી, તેથી તેના કદ દ્વારા વિભાજીત કરવાનું ઠીક છે.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // અલ્ગોરિધમનો 2 `[T; 0]` અહીં છે તેની ખાતરી કરવા માટે કે આ ટી માટે યોગ્ય રીતે ગોઠવાયેલ છે
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Gલ્ગોરિધમ 3 અદલાબદલ કરવાની એક વૈકલ્પિક રીત છે જેમાં આ અલ્ગોરિધમનો છેલ્લો અદલાબદલ ક્યાં છે તે શોધવા અને આ અલ્ગોરિધમ જેવા અડીને ભાગોને અદલાબદલ કરવાને બદલે તે છેલ્લા ભાગનો ઉપયોગ કરીને અદલાબદલ કરવામાં આવે છે, પરંતુ આ રીતે હજી ઝડપી છે.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // એલ્ગોરિધમ 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}