// ignore-tidy-filelength

//! સ્લાઇસ મેનેજમેન્ટ અને મેનીપ્યુલેશન.
//!
//! વધુ વિગતો માટે [`std::slice`] જુઓ.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// શુદ્ધ ઝેડ 0 રસ્ટ 0 ઝેડ મેમચર અમલીકરણ, ઝેડ 0 રસ્ટ 0 ઝેડ-મેચચ્ર
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// આ કાર્ય ફક્ત સાર્વજનિક છે કારણ કે ત્યાં એકમ પરીક્ષણના apગલાબંધ રસ્તો નથી.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// સ્લાઈસમાં તત્વોની સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // સલામતી: કોન્સ્ટ અવાજ કારણ કે આપણે લંબાઈના ક્ષેત્રને યુઝના રૂપમાં ટ્રાન્સમિટ કરીએ છીએ (જે તે હોવું જોઈએ)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // સલામત: આ સલામત છે કારણ કે `&[T]` અને `FatPtr<T>` નો લેઆઉટ સમાન છે.
            // ફક્ત `std` જ આ બાંયધરી આપી શકે છે.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: જ્યારે તે સ્થિર-સ્થિર હોય ત્યારે `crate::ptr::metadata(self)` સાથે બદલો.
            // આ લેખન મુજબ, આ એક "Const-stable functions can only call other const-stable functions" ભૂલનું કારણ બને છે.
            //

            // સલામત: * કોન્સ્ટ ટી થી `PtrRepr` સંઘમાંથી મૂલ્ય Accessક્સેસ કરવું સલામત છે
            // અને પી.ટી.આર.કોમ્પોનન્ટ્સ<T>સમાન મેમરી લેઆઉટ છે.
            // ફક્ત std જ આ બાંયધરી આપી શકે છે.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// જો સ્લાઇસની લંબાઈ 0 હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// સ્લાઈસનો પ્રથમ તત્વ અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// સ્લાઇસના પહેલા તત્વમાં પરિવર્તનીય પોઇન્ટર, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// સ્લાઇસના પ્રથમ અને બાકીના બધા તત્વો, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// સ્લાઇસના પ્રથમ અને બાકીના બધા તત્વો, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// સ્લાઇસના છેલ્લા અને બાકીના બધા તત્વો, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// સ્લાઇસના છેલ્લા અને બાકીના બધા તત્વો, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// સ્લાઈસનો છેલ્લો તત્વ અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// સ્લાઈસમાં છેલ્લી વસ્તુમાં પરિવર્તનીય પોઇંટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ઇન્ડેક્સના પ્રકાર પર આધાર રાખીને કોઈ તત્વનો સંદર્ભ અથવા સબલિસિસ આપે છે.
    ///
    /// - જો કોઈ સ્થાન આપવામાં આવે, તો તે સ્થિતિ પરના તત્વનો સંદર્ભ આપે છે અથવા જો મર્યાદાઓ બહાર હોય તો `None`.
    ///
    /// - જો કોઈ શ્રેણી આપવામાં આવે તો, તે શ્રેણીને અનુરૂપ સબસ્લાઇસ, અથવા જો સીમાઓથી બહાર હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// જો અનુક્રમણિકાની મર્યાદા સમાપ્ત ન હોય તો અનુક્રમણિકાના પ્રકાર ([`get`] જુઓ) અથવા `None` ના આધારે તત્વ અથવા સબલિસિસના પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// સીમાઓની ચકાસણી કર્યા વિના, કોઈ તત્વ અથવા સબલિસિસનો સંદર્ભ આપે છે.
    ///
    /// સલામત વિકલ્પ માટે [`get`] જુઓ.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને આઉટ-anફ-સીમાઇસ ઇન્ડેક્સ સાથે કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે જો પરિણામી સંદર્ભનો ઉપયોગ કરવામાં આવતો નથી.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // સલામતી: કlerલરને `get_unchecked` માટેની મોટાભાગની સલામતી આવશ્યકતાઓને સમર્થન આપવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &*index.get_unchecked(self) }
    }

    /// સીમાઓની ચકાસણી કર્યા વિના, તત્વ અથવા લવાજમ માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// સલામત વિકલ્પ માટે [`get_mut`] જુઓ.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને આઉટ-anફ-સીમાઇસ ઇન્ડેક્સ સાથે કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે જો પરિણામી સંદર્ભનો ઉપયોગ કરવામાં આવતો નથી.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // સલામતી: કlerલરને `get_unchecked_mut` માટેની સલામતી આવશ્યકતાઓને સમર્થન આપવું આવશ્યક છે;
        // સ્લાઈસ ડીરેફરન્સીબલ છે કારણ કે `self` એ સલામત સંદર્ભ છે.
        // પરત થયેલ પોઇન્ટર સલામત છે કારણ કે `SliceIndex` ની ઇમ્પ્લ્સને ખાતરી આપી છે કે તે છે.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// સ્લાઈસના બફર પર કાચો પોઇન્ટર આપે છે.
    ///
    /// ક calલરને ખાતરી કરવી આવશ્યક છે કે સ્લાઇસ આ ફંક્શન પરત કરેલા નિર્દેશકને આઉટલેવ કરે છે, નહીં તો તે કચરા તરફ નિર્દેશ કરશે.
    ///
    /// કlerલરે એ પણ સુનિશ્ચિત કરવું આવશ્યક છે કે જે નિર્દેશક (non-transitively) નિર્દેશ કરે છે તે આ નિર્દેશક અથવા તેનાથી પ્રાપ્ત કોઈપણ પોઇન્ટરનો ઉપયોગ કરીને (`UnsafeCell` ની અંદર સિવાય) ક્યારેય લખાયેલ નથી.
    /// જો તમારે સ્લાઈસની સામગ્રીને પરિવર્તિત કરવાની જરૂર હોય, તો [`as_mut_ptr`] નો ઉપયોગ કરો.
    ///
    /// આ સ્લાઈસ દ્વારા સંદર્ભિત કન્ટેનરમાં ફેરફાર કરવાથી તેના બફરને ફરીથી ફેરવવામાં આવે છે, જે તેના માટેના કોઈપણ નિર્દેશકોને પણ અમાન્ય બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// સ્લાઇસેસના બફર પર એક અસુરક્ષિત પરિવર્તનીય પોઇન્ટર આપે છે.
    ///
    /// ક calલરને ખાતરી કરવી આવશ્યક છે કે સ્લાઇસ આ ફંક્શન પરત કરેલા નિર્દેશકને આઉટલેવ કરે છે, નહીં તો તે કચરા તરફ નિર્દેશ કરશે.
    ///
    /// આ સ્લાઈસ દ્વારા સંદર્ભિત કન્ટેનરમાં ફેરફાર કરવાથી તેના બફરને ફરીથી ફેરવવામાં આવે છે, જે તેના માટેના કોઈપણ નિર્દેશકોને પણ અમાન્ય બનાવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// કટકામાં ફેલાયેલા બે કાચા પોઇન્ટર આપે છે.
    ///
    /// પરત કરેલ શ્રેણી અર્ધ-ખુલ્લી છે, જેનો અર્થ છે કે અંત નિર્દેશક *એક ભૂતકાળ* સ્લાઇસનો અંતિમ તત્વ છે.
    /// આ રીતે, ખાલી સ્લાઈસ બે સમાન પોઇંટર દ્વારા રજૂ થાય છે, અને બે પોઇન્ટર વચ્ચેનો તફાવત સ્લાઇસનું કદ રજૂ કરે છે.
    ///
    /// આ પોઇન્ટરનો ઉપયોગ કરવા પર ચેતવણીઓ માટે [`as_ptr`] જુઓ.અંતિમ નિર્દેશકને વધારાની સાવધાનીની જરૂર છે, કારણ કે તે સ્લાઇસમાં માન્ય તત્વ તરફ નિર્દેશ કરતું નથી.
    ///
    /// આ ફંક્શન વિદેશી ઇંટરફેસ સાથે વાતચીત કરવા માટે ઉપયોગી છે જે સી ++ માં સામાન્ય હોવાને કારણે મેમરીમાં તત્વોની શ્રેણી માટે બે પોઇન્ટરનો ઉપયોગ કરે છે.
    ///
    ///
    /// તે તપાસો તે પણ ઉપયોગી થઈ શકે છે કે કોઈ ઘટકનો નિર્દેશક આ કટકાના તત્વને સૂચવે છે કે નહીં:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // સલામતી: અહીંનો `add` સલામત છે, કારણ કે:
        //
        //   - બંને પોઇંટર્સ એ એક જ ofબ્જેક્ટનો ભાગ છે, કારણ કે directlyબ્જેક્ટના સીધા પોઇન્ટિંગને પણ ગણે છે.
        //
        //   - સ્લાઇસનું કદ ક્યારેય isize::MAX બાઇટ્સ કરતા વધારે હોતું નથી, અહીં નોંધ્યું છે તેમ:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - તેમાં સામેલ કોઈ આવરણ હોતું નથી, કારણ કે સરનામાંની જગ્યાના અંતથી કાપી નાંખ્યું નથી.
        //
        // pointer::add ના દસ્તાવેજીકરણ જુઓ.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// કટકામાં ફેલાયેલા બે અસુરક્ષિત પરિવર્તનીય પોઇંટર્સ આપે છે.
    ///
    /// પરત કરેલ શ્રેણી અર્ધ-ખુલ્લી છે, જેનો અર્થ છે કે અંત નિર્દેશક *એક ભૂતકાળ* સ્લાઇસનો અંતિમ તત્વ છે.
    /// આ રીતે, ખાલી સ્લાઈસ બે સમાન પોઇંટર દ્વારા રજૂ થાય છે, અને બે પોઇન્ટર વચ્ચેનો તફાવત સ્લાઇસનું કદ રજૂ કરે છે.
    ///
    /// આ પોઇન્ટરનો ઉપયોગ કરવા પર ચેતવણીઓ માટે [`as_mut_ptr`] જુઓ.
    /// અંતિમ નિર્દેશકને વધારાની સાવધાનીની જરૂર છે, કારણ કે તે સ્લાઇસમાં માન્ય તત્વ તરફ નિર્દેશ કરતું નથી.
    ///
    /// આ ફંક્શન વિદેશી ઇંટરફેસ સાથે વાતચીત કરવા માટે ઉપયોગી છે જે સી ++ માં સામાન્ય હોવાને કારણે મેમરીમાં તત્વોની શ્રેણી માટે બે પોઇન્ટરનો ઉપયોગ કરે છે.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // સલામત: અહીં `add` કેમ સલામત છે તે માટે ઉપરના as_ptr_range() જુઓ.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// સ્લાઈસમાં બે તત્વો ફેરવી લે છે.
    ///
    /// # Arguments
    ///
    /// * એ, પ્રથમ તત્વની અનુક્રમણિકા
    /// * બી, બીજા તત્વની સૂચિ
    ///
    /// # Panics
    ///
    /// જો `a` અથવા `b` મર્યાદાથી બહાર હોય તો ઝેડપેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // એક ઝેડ 0 વેક્ટર 0 ઝેડમાંથી બે પરિવર્તનીય લોન લઈ શકતા નથી, તેથી તેના બદલે કાચા પોઇંટર્સનો ઉપયોગ કરો.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // સલામત: `pa` અને `pb` સલામત પરિવર્તનશીલ સંદર્ભો અને સંદર્ભોમાંથી બનાવવામાં આવ્યા છે
        // સ્લાઇસના તત્વોને અને તેથી માન્ય અને ગોઠવાયેલ હોવાની બાંયધરી આપવામાં આવી છે.
        // નોંધ લો કે `a` અને `b` ની પાછળના તત્વોને .ક્સેસ કરવાની ચકાસણી કરવામાં આવી છે અને જ્યારે સીમાઓ સમાપ્ત થઈ જશે ત્યારે ઝેડપૈનિક 0 ઝેડ હશે.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// સ્લાઈસમાં તત્વોનો ક્રમ, જગ્યાએ બદલાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ખૂબ નાના પ્રકારનાં લોકો માટે, સામાન્ય માર્ગમાં વાંચેલી બધી વ્યક્તિઓ ખરાબ પ્રદર્શન કરે છે.
        // મોટા ભાગને લોડ કરીને અને રજિસ્ટરને બદલીને, કાર્યક્ષમ અનલિએન્ડેડ load/store આપેલ, અમે વધુ સારી રીતે કરી શકીએ છીએ.
        //

        // આદર્શરીતે એલએલવીએમ અમારા માટે આ કરશે, કેમ કે તે સહી વિનાનું વાંચન કાર્યક્ષમ છે કે કેમ તે કરતાં આપણે વધુ સારી રીતે જાણે છે (ઉદાહરણ તરીકે, જુદા જુદા એઆરએમ સંસ્કરણો વચ્ચે બદલાવ થાય છે) અને શ્રેષ્ઠ ભાગનું કદ શું હશે.
        // દુર્ભાગ્યે, LLVM 4.0 (2017-05) મુજબ તે ફક્ત લૂપને અનલ unલ કરે છે, તેથી આપણે આ જાતે જ કરવાની જરૂર છે.
        // (પૂર્વધારણા: વિપરીત મુશ્કેલીભર્યું છે કારણ કે બાજુઓ અલગથી ગોઠવી શકાય છે-હશે, જ્યારે લંબાઈ વિચિત્ર હશે-તેથી મધ્યમાં સંપૂર્ણ રીતે ગોઠવાયેલ સીએમડીનો ઉપયોગ કરવા માટે પૂર્વ-અને અનુસંધાનનો કોઈ રસ્તો નથી.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // યુઝમાં યુ 8 ને વિપરીત કરવા માટે llvm.bswap આંતરિકનો ઉપયોગ કરો
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // સલામતી: અહીં તપાસવા માટે ઘણી વસ્તુઓ છે:
                //
                // - નોંધ લો કે ઉપરનાં સીએફજી તપાસીને લીધે `chunk` 4 અથવા 8 છે.તેથી `chunk - 1` સકારાત્મક છે.
                // - લૂપ ચેક ગેરંટીઝ હોવાથી ઇન્ડેક્સ `i` સાથે અનુક્રમણિકા બરાબર છે
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - અનુક્રમણિકા `ln - i - chunk = ln - (i + chunk)` સાથે અનુક્રમણિકા સારી છે:
                //   - `i + chunk > 0` તુચ્છ સત્ય છે.
                //   - લૂપ ચેક ખાતરી આપે છે:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, આમ બાદબાકી અન્ડરફ્લો થતી નથી.
                // - `read_unaligned` અને `write_unaligned` ક callsલ્સ સારી છે:
                //   - `pa` અનુક્રમણિકા `i` તરફ નિર્દેશ કરે છે જ્યાં `i < ln / 2 - (chunk - 1)` (ઉપર જુઓ) અને `pb` નિર્દેશ કરે છે અનુક્રમણિકા `ln - i - chunk`, તેથી બંને `self` ના અંતથી ઓછામાં ઓછા `chunk` ઘણા બાઇટ્સ દૂર છે.
                //
                //   - કોઈપણ પ્રારંભિક મેમરી માન્ય `usize` છે.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // એક u32 માં u16 ને વિપરીત કરવા માટે રોટ-બાય-16 નો ઉપયોગ કરો
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // સલામત: જો બિન હસ્તાક્ષર કરાયેલા u32 જો `i + 1 < ln` હોય તો `i` માંથી વાંચી શકાય છે
                // (અને દેખીતી રીતે `i < ln`), કારણ કે દરેક તત્વ 2 બાઇટ્સનું છે અને અમે 4 વાંચીએ છીએ.
                //
                // `i + chunk - 1 < ln / 2` # જ્યારે શરત
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // તે 2 દ્વારા વહેંચાયેલ લંબાઈ કરતા ઓછું હોવાથી, તે મર્યાદામાં હોવું આવશ્યક છે.
                //
                // આનો અર્થ એ પણ છે કે `0 < i + chunk <= ln` સ્થિતિ હંમેશાં આદરણીય છે, `pb` પોઇન્ટર સુરક્ષિત રીતે વાપરી શકાય છે તેની ખાતરી કરીને.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // સલામતી: `i` એ સ્લાઇસની અડધી લંબાઈથી ગૌણ છે
            // `i` અને `ln - i - 1` ને accessક્સેસ કરવું સલામત છે (`i` 0 થી શરૂ થાય છે અને `ln / 2 - 1` કરતા વધુ આગળ નહીં જાય).
            // પરિણામી પોઇંટર્સ `pa` અને `pb` તેથી માન્ય અને સંરેખિત છે, અને તેમાંથી વાંચી અને લખી શકાય છે.
            //
            //
            unsafe {
                // સલામત સ્વેપમાં બાઉન્ડ્રી ચેક કરવા ટાળવા અસુરક્ષિત સ્વેપ.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// સ્લાઈસ ઉપર એક ઇરેટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// એક ઇરેટર આપે છે જે દરેક મૂલ્યમાં ફેરફાર કરવાની મંજૂરી આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` લંબાઈના તમામ સુસંગત windows પર એક ઇરેટર આપે છે.
    /// windows ઓવરલેપ
    /// જો સ્લાઇસ `size` કરતા ટૂંકી હોય, તો પુનરાવર્તક કોઈ મૂલ્યો આપતો નથી.
    ///
    /// # Panics
    ///
    /// જો `size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// જો સ્લાઇસ `size` કરતા ટૂંકી હોય:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં કટકા હોય છે અને ઓવરલેપ થતા નથી.જો `chunk_size` સ્લાઇસની લંબાઈને વહેંચતો નથી, તો પછીના ભાગમાં લંબાઈ `chunk_size` હશે નહીં.
    ///
    /// આ પુનરાવર્તકના વિવિધ પ્રકાર માટે [`chunks_exact`] જુઓ કે જે હંમેશાં બરાબર `chunk_size` તત્વોનો હિસ્સો આપે છે, અને તે જ પુનરાવર્તક માટે [`rchunks`] પણ સ્લાઈસના અંતથી શરૂ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં પરિવર્તનશીલ કાપી નાંખ્યું છે, અને તે ઓવરલેપ થતી નથી.જો `chunk_size` સ્લાઇસની લંબાઈને વહેંચતો નથી, તો પછીના ભાગમાં લંબાઈ `chunk_size` હશે નહીં.
    ///
    /// આ પુનરાવર્તકના વિવિધ પ્રકાર માટે [`chunks_exact_mut`] જુઓ કે જે હંમેશાં બરાબર `chunk_size` તત્વોનો હિસ્સો આપે છે, અને તે જ પુનરાવર્તક માટે [`rchunks_mut`] પણ સ્લાઈસના અંતથી શરૂ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં કટકા હોય છે અને ઓવરલેપ થતા નથી.
    /// જો `chunk_size` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `chunk_size-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    ///
    /// દરેક ભાગને બરાબર `chunk_size` તત્વો હોવાને કારણે, કમ્પાઇલર ઘણીવાર [`chunks`] ના કિસ્સામાં પરિણામી કોડને વધુ સારી રીતે optimપ્ટિમાઇઝ કરી શકે છે.
    ///
    /// આ પુનરાવર્તકના ચલ માટે [`chunks`] જુઓ જે બાકીના ભાગને નાના ભાગ તરીકે પણ આપે છે, અને તે જ પુનરાવર્તક માટે [`rchunks_exact`] પણ સ્લાઈસના અંતથી શરૂ કરીને.
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં પરિવર્તનશીલ કાપી નાંખ્યું છે, અને તે ઓવરલેપ થતી નથી.
    /// જો `chunk_size` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `chunk_size-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `into_remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    ///
    /// દરેક ભાગને બરાબર `chunk_size` તત્વો હોવાને કારણે, કમ્પાઇલર ઘણીવાર [`chunks_mut`] ના કિસ્સામાં પરિણામી કોડને વધુ સારી રીતે optimપ્ટિમાઇઝ કરી શકે છે.
    ///
    /// આ પુનરાવર્તકના ચલ માટે [`chunks_mut`] જુઓ જે બાકીના ભાગને નાના ભાગ તરીકે પણ આપે છે, અને તે જ પુનરાવર્તક માટે [`rchunks_exact_mut`] પણ સ્લાઈસના અંતથી શરૂ કરીને.
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// બાકી કોઈ બાકી નથી એમ માનીને sl N`-તત્વો એરેની કટકામાં સ્લાઈસને વિભાજીત કરે છે.
    ///
    ///
    /// # Safety
    ///
    /// આ ત્યારે જ કહી શકાય
    /// - સ્લાઇસ બરાબર `N`-તત્વ ભાગમાં વહેંચાય છે (ઉર્ફ `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // સલામતી: 1-તત્વ ભાગોમાં ક્યારેય બાકી નથી
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // સલામતી: કટકાની લંબાઈ (6) 3 નું ગુણાકાર છે
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // આ અવાસ્તવિક હશે:
    /// // દો ભાગો: &[[_ _;5]]= slice.as_chunks_unchecked()//સ્લાઈસ લંબાઈ 5 લેટ હિસ્સાના બહુવિધ નથી:&[[_ _;0]]= slice.as_chunks_unchecked()//શૂન્ય-લંબાઈના ભાગોને ક્યારેય મંજૂરી નથી
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // સલામતી: અમારી પૂર્વજરૂરીયાત આ કહેવા માટે જરૂરી છે તે જ છે
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // સલામતી: અમે તેમાં `new_len * N` તત્વોની ટુકડા કાસ્ટ કરી
        // `new_len` ઘણા `N` તત્વો ભાગની ભાગ.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// સ્લાઇસને `N`-તત્વો એરેની કટકામાં વિભાજીત કરો, સ્લાઇસની શરૂઆતમાં, અને `N` કરતા ઓછી લંબાઈવાળી બાકીની સ્લાઇસ.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // સલામતી: આપણે પહેલાથી જ શૂન્યથી ગભરાઈ ગયા છીએ, અને બાંધકામ દ્વારા સુનિશ્ચિત થયેલ છે
        // કે સબસ્લાઇસની લંબાઈ એ એન નો બહુવિધ છે.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// સ્લાઇસને `N`-તત્વો એરેની કટકામાં વિભાજીત કરો, સ્લાઇસના અંતથી શરૂ કરીને, અને `N` કરતા ઓછી લંબાઈવાળી બાકીની સ્લાઇસ.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // સલામતી: આપણે પહેલાથી જ શૂન્યથી ગભરાઈ ગયા છીએ, અને બાંધકામ દ્વારા સુનિશ્ચિત થયેલ છે
        // કે સબસ્લાઇસની લંબાઈ એ એન નો બહુવિધ છે.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `N` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં એરે સંદર્ભો છે અને ઓવરલેપ થતા નથી.
    /// જો `N` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `N-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    ///
    /// આ પદ્ધતિ એ [`chunks_exact`] ની ક generનસ્ટ જેનરિક સમકક્ષ છે.
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// બાકી કોઈ બાકી નથી એમ માનીને sl N`-તત્વો એરેની કટકામાં સ્લાઈસને વિભાજીત કરે છે.
    ///
    ///
    /// # Safety
    ///
    /// આ ત્યારે જ કહી શકાય
    /// - સ્લાઇસ બરાબર `N`-તત્વ ભાગમાં વહેંચાય છે (ઉર્ફ `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // સલામતી: 1-તત્વ ભાગોમાં ક્યારેય બાકી નથી
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // સલામતી: કટકાની લંબાઈ (6) 3 નું ગુણાકાર છે
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // આ અવાસ્તવિક હશે:
    /// // દો ભાગો: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//સ્લાઈસ લંબાઈ 5 લેટ હિસ્સાના બહુવિધ નથી:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//શૂન્ય-લંબાઈના ભાગોને ક્યારેય મંજૂરી નથી
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // સલામતી: અમારી પૂર્વજરૂરીયાત આ કહેવા માટે જરૂરી છે તે જ છે
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // સલામતી: અમે તેમાં `new_len * N` તત્વોની ટુકડા કાસ્ટ કરી
        // `new_len` ઘણા `N` તત્વો ભાગની ભાગ.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// સ્લાઇસને `N`-તત્વો એરેની કટકામાં વિભાજીત કરો, સ્લાઇસની શરૂઆતમાં, અને `N` કરતા ઓછી લંબાઈવાળી બાકીની સ્લાઇસ.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // સલામતી: આપણે પહેલાથી જ શૂન્યથી ગભરાઈ ગયા છીએ, અને બાંધકામ દ્વારા સુનિશ્ચિત થયેલ છે
        // કે સબસ્લાઇસની લંબાઈ એ એન નો બહુવિધ છે.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// સ્લાઇસને `N`-તત્વો એરેની કટકામાં વિભાજીત કરો, સ્લાઇસના અંતથી શરૂ કરીને, અને `N` કરતા ઓછી લંબાઈવાળી બાકીની સ્લાઇસ.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // સલામતી: આપણે પહેલાથી જ શૂન્યથી ગભરાઈ ગયા છીએ, અને બાંધકામ દ્વારા સુનિશ્ચિત થયેલ છે
        // કે સબસ્લાઇસની લંબાઈ એ એન નો બહુવિધ છે.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// સ્લાઇસની શરૂઆતમાં, એક સમયે સ્લાઈસના `N` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં પરિવર્તનશીલ એરે સંદર્ભો છે અને તે ઓવરલેપ થતા નથી.
    /// જો `N` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `N-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `into_remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    ///
    /// આ પદ્ધતિ એ [`chunks_exact_mut`] ની ક generનસ્ટ જેનરિક સમકક્ષ છે.
    ///
    /// # Panics
    ///
    /// Panics જો `N` 0 છે. આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઈ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// સ્લાઇસની શરૂઆતથી શરૂ કરીને, સ્લાઇસના `N` તત્વોના ઓવરલેપિંગ windows પર ઇટરેટર પરત કરે છે.
    ///
    ///
    /// આ [`windows`] ની ક constનસ્ટ જેનરિક સમકક્ષ છે.
    ///
    /// જો `N` સ્લાઇસના કદ કરતા વધારે છે, તો તે કોઈ windows આપશે નહીં.
    ///
    /// # Panics
    ///
    /// જો `N` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    /// આ પદ્ધતિ સ્થિર થાય તે પહેલાં આ તપાસ સંભવત time કમ્પાઇલ સમય ભૂલમાં બદલાઇ જશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// સ્લાઇસના અંતથી શરૂ કરીને એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં કટકા હોય છે અને ઓવરલેપ થતા નથી.જો `chunk_size` સ્લાઇસની લંબાઈને વહેંચતો નથી, તો પછીના ભાગમાં લંબાઈ `chunk_size` હશે નહીં.
    ///
    /// આ પુનરાવર્તકના વિવિધ પ્રકાર માટે [`rchunks_exact`] જુઓ કે જે હંમેશાં બરાબર `chunk_size` તત્વોનો હિસ્સો આપે છે, અને સમાન પુનરાવર્તક માટે [`chunks`] પણ સ્લાઈસની શરૂઆતમાં શરૂ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// સ્લાઇસના અંતથી શરૂ કરીને એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં પરિવર્તનશીલ કાપી નાંખ્યું છે, અને તે ઓવરલેપ થતી નથી.જો `chunk_size` સ્લાઇસની લંબાઈને વહેંચતો નથી, તો પછીના ભાગમાં લંબાઈ `chunk_size` હશે નહીં.
    ///
    /// આ પુનરાવર્તકના વિવિધ પ્રકાર માટે [`rchunks_exact_mut`] જુઓ કે જે હંમેશાં બરાબર `chunk_size` તત્વોનો હિસ્સો આપે છે, અને તે જ પુનરાવર્તક માટે [`chunks_mut`] પણ સ્લાઇસની શરૂઆતમાં પ્રારંભ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// સ્લાઇસના અંતથી શરૂ કરીને એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં કટકા હોય છે અને ઓવરલેપ થતા નથી.
    /// જો `chunk_size` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `chunk_size-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    /// દરેક ભાગને બરાબર `chunk_size` તત્વો હોવાને કારણે, કમ્પાઇલર ઘણીવાર [`chunks`] ના કિસ્સામાં પરિણામી કોડને વધુ સારી રીતે optimપ્ટિમાઇઝ કરી શકે છે.
    ///
    /// આ પુનરાવર્તકના ચલ માટે [`rchunks`] જુઓ જે બાકીના ભાગને નાના ભાગ તરીકે પણ આપે છે, અને તે જ પુનરાવર્તક માટે [`chunks_exact`] પણ સ્લાઇસની શરૂઆતમાં શરૂ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// સ્લાઇસના અંતથી શરૂ કરીને એક સમયે સ્લાઈસના `chunk_size` તત્વો પર ઇરેટર આપે છે.
    ///
    /// હિસ્સામાં પરિવર્તનશીલ કાપી નાંખ્યું છે, અને તે ઓવરલેપ થતી નથી.
    /// જો `chunk_size` સ્લાઈસની લંબાઈને વહેંચતું નથી, તો પછી `chunk_size-1` તત્વો સુધીનો છેલ્લો કા .ી નાખવામાં આવશે અને ઇટરેટરના `into_remainder` ફંક્શનમાંથી ફરીથી મેળવી શકાય છે.
    ///
    /// દરેક ભાગને બરાબર `chunk_size` તત્વો હોવાને કારણે, કમ્પાઇલર ઘણીવાર [`chunks_mut`] ના કિસ્સામાં પરિણામી કોડને વધુ સારી રીતે optimપ્ટિમાઇઝ કરી શકે છે.
    ///
    /// આ પુનરાવર્તકના ચલ માટે [`rchunks_mut`] જુઓ જે બાકીના ભાગને નાના ભાગ તરીકે પણ આપે છે, અને તે જ પુનરાવર્તક માટે [`chunks_exact_mut`] પણ સ્લાઇસની શરૂઆતમાં શરૂ થાય છે.
    ///
    ///
    /// # Panics
    ///
    /// જો `chunk_size` 0 હોય તો ઝેડ 0 પેનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ભાગાકારને અલગ કરવા માટે તત્વોની નોન-ઓવરલેપિંગ રન બનાવતી સ્લાઇસ પર ઇટરેટર પરત કરે છે.
    ///
    /// પ્રિડિકેટને પોતાને પગલે બે તત્વો પર બોલાવવામાં આવે છે, તેનો અર્થ એ છે કે પ્રિડિકેટને `slice[0]` અને `slice[1]` પર કહેવામાં આવે છે પછી `slice[1]` અને `slice[2]` અને તેથી વધુ પર.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// આ પદ્ધતિનો ઉપયોગ સortedર્ટ કરેલા સબ્સ્ક્રાઇબલ્સને બહાર કા toવા માટે કરી શકાય છે:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ભાગાકારને અલગ કરવા માટે તત્વોના-ન-ઓવરલેપિંગ પરિવર્તનીય રનનું ઉત્પાદન કરતી સ્લાઇસ પર ઇટરેટર પરત કરે છે.
    ///
    /// પ્રિડિકેટને પોતાને પગલે બે તત્વો પર બોલાવવામાં આવે છે, તેનો અર્થ એ છે કે પ્રિડિકેટને `slice[0]` અને `slice[1]` પર કહેવામાં આવે છે પછી `slice[1]` અને `slice[2]` અને તેથી વધુ પર.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// આ પદ્ધતિનો ઉપયોગ સortedર્ટ કરેલા સબ્સ્ક્રાઇબલ્સને બહાર કા toવા માટે કરી શકાય છે:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// અનુક્રમણિકા પર એક સ્લાઇસને બે ભાગમાં વહેંચે છે.
    ///
    /// પ્રથમમાં `[0, mid)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `mid` સિવાય) અને બીજામાં `[mid, len)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `len` સિવાય).
    ///
    ///
    /// # Panics
    ///
    /// ઝેડ 0 પેનિક્સ 0 ઝેડ જો `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // સલામત: `[ptr; mid]` અને `[mid; len]`, `self` ની અંદર છે, જે
        // `from_raw_parts_mut` ની આવશ્યકતાઓને પૂર્ણ કરે છે.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// એક પરિવર્તનીય સ્લાઇસને અનુક્રમણિકામાં બેમાં વહેંચે છે.
    ///
    /// પ્રથમમાં `[0, mid)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `mid` સિવાય) અને બીજામાં `[mid, len)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `len` સિવાય).
    ///
    ///
    /// # Panics
    ///
    /// ઝેડ 0 પેનિક્સ 0 ઝેડ જો `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // સલામત: `[ptr; mid]` અને `[mid; len]`, `self` ની અંદર છે, જે
        // `from_raw_parts_mut` ની આવશ્યકતાઓને પૂર્ણ કરે છે.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// અનુક્રમણિકામાં સીમાની ચકાસણી કર્યા વિના, એક ટુકડાને બે ભાગમાં વહેંચે છે.
    ///
    /// પ્રથમમાં `[0, mid)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `mid` સિવાય) અને બીજામાં `[mid, len)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `len` સિવાય).
    ///
    ///
    /// સલામત વિકલ્પ માટે [`split_at`] જુઓ.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને આઉટ-anફ-સીમાઇસ ઇન્ડેક્સ સાથે કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે જો પરિણામી સંદર્ભનો ઉપયોગ કરવામાં આવતો નથી.કlerલરને ખાતરી કરવી પડશે કે `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // સલામતી: કlerલરને તે `0 <= mid <= self.len()` તપાસવું પડશે
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// અનુક્રમણિકામાં એક પરિવર્તનીય સ્લાઇસને બે સરખા ચકાસણી કર્યા વિના વહેંચે છે.
    ///
    /// પ્રથમમાં `[0, mid)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `mid` સિવાય) અને બીજામાં `[mid, len)` ના બધા સૂચકાંકો હશે (ફક્ત અનુક્રમણિકા `len` સિવાય).
    ///
    ///
    /// સલામત વિકલ્પ માટે [`split_at_mut`] જુઓ.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને આઉટ-anફ-સીમાઇસ ઇન્ડેક્સ સાથે કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે જો પરિણામી સંદર્ભનો ઉપયોગ કરવામાં આવતો નથી.કlerલરને ખાતરી કરવી પડશે કે `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // સલામતી: કlerલરને તે `0 <= mid <= self.len()` તપાસવું પડશે.
        //
        // `[ptr; mid]` અને `[mid; len]` ઓવરલેપિંગ નથી, તેથી પરિવર્તનશીલ સંદર્ભો આપવો તે સરસ છે.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// જો પ્રથમ તત્વ સાથે મેળ ખાય છે, તો ખાલી સ્લાઈસ એ પુનરાવર્તક દ્વારા પરત કરવામાં આવેલી પ્રથમ આઇટમ હશે.
    /// એ જ રીતે, જો સ્લાઇસમાં છેલ્લો તત્વ મેચ કરવામાં આવે છે, તો ખાલી સ્લાઇસ એ પુનરાવર્તક દ્વારા પરત કરવામાં આવેલી છેલ્લી વસ્તુ હશે:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// જો બે મેળ ખાતા તત્વો સીધા અડીને હોય, તો તેમની વચ્ચે ખાલી સ્લાઈસ આવશે:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત પરિવર્તનીય સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// મેળ ખાતા તત્વ એક ટર્મિનેટર તરીકે પાછલા સબસ્લિસના અંતમાં સમાયેલ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// જો સ્લાઇસનો છેલ્લો તત્વ મેચ કરવામાં આવે છે, તો તે તત્વ પહેલાની સ્લાઇસેસનો ટર્મિનેટર માનવામાં આવશે.
    ///
    /// તે સ્લાઇસ એ ઇટરેટર દ્વારા પરત કરવામાં આવેલી છેલ્લી આઇટમ હશે.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત પરિવર્તનીય સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// મેળ ખાતા તત્વ પહેલાના સબસ્લાઇસમાં સમાપ્ત થનાર તરીકે સમાયેલ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// સ્લાઈસના અંતથી શરૂ કરીને અને પાછળની બાજુએ કામ કરીને, `pred` થી મેળ ખાતા તત્વો દ્વારા અલગ પડેલી સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` ની જેમ, જો પ્રથમ અથવા છેલ્લું તત્વ મેળ ખાય છે, તો ખાલી સ્લાઈસ એ ઇટરેટર દ્વારા પરત કરવામાં આવેલી પ્રથમ (અથવા છેલ્લી) આઇટમ હશે.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// સ્લાઈસના અંતથી શરૂ કરીને અને પાછળની બાજુએ કામ કરીને, `pred` સાથે મેળ ખાતા તત્વો દ્વારા અલગ પડેલા પરિવર્તનીય સબ્સ્ક્રાઇબિસ પર ઇટરેટર પરત કરે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` થી મેળ ખાતા તત્વો દ્વારા વહેંચાયેલ સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે, મોટાભાગની `n` આઇટમ્સ પર પાછા આવવા સુધી મર્યાદિત છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// પરત થયેલ છેલ્લું તત્વ, જો કોઈ હોય તો, સ્લાઇસની બાકીની વસ્તુ સમાવશે.
    ///
    /// # Examples
    ///
    /// સ્લાઇસ સ્પ્લિટ એકવાર 3 (એટલે કે, `[10, 40]`, `[20, 60, 50]`) દ્વારા વિભાજીત સંખ્યાઓ દ્વારા છાપો:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` થી મેળ ખાતા તત્વો દ્વારા વહેંચાયેલ સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે, મોટાભાગની `n` આઇટમ્સ પર પાછા આવવા સુધી મર્યાદિત છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// પરત થયેલ છેલ્લું તત્વ, જો કોઈ હોય તો, સ્લાઇસની બાકીની વસ્તુ સમાવશે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// મોટાભાગની `n` આઇટમ્સ પર પાછા આવવા માટે મર્યાદિત `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// આ સ્લાઈસના અંતથી શરૂ થાય છે અને પાછળની બાજુએ કામ કરે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// પરત થયેલ છેલ્લું તત્વ, જો કોઈ હોય તો, સ્લાઇસની બાકીની વસ્તુ સમાવશે.
    ///
    /// # Examples
    ///
    /// એકવાર સ્લાઈસ સ્પ્લિટ છાપો, અંતથી શરૂ કરીને, 3 (એટલે કે, `[50]`, `[10, 40, 30, 20]`) દ્વારા વિભાજીત સંખ્યાઓ દ્વારા:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// મોટાભાગની `n` આઇટમ્સ પર પાછા આવવા માટે મર્યાદિત `pred` સાથે મેળ ખાતા તત્વો દ્વારા વિભાજિત સબ્સ્ક્રાઇબ્સ ઉપર ઇટરેટર આપે છે.
    /// આ સ્લાઈસના અંતથી શરૂ થાય છે અને પાછળની બાજુએ કામ કરે છે.
    /// મેળ ખાતા તત્વ સબ્સ્ક્રાઇબ્સમાં શામેલ નથી.
    ///
    /// પરત થયેલ છેલ્લું તત્વ, જો કોઈ હોય તો, સ્લાઇસની બાકીની વસ્તુ સમાવશે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// જો સ્લાઈસમાં આપેલ મૂલ્ય સાથેનો કોઈ ઘટક હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// જો તમારી પાસે `&T` નથી, પરંતુ ફક્ત `&U` જેમ કે `T: Borrow<U>` (દા.ત.
    /// Ring શબ્દમાળા: ઉધાર<str>`), તમે `iter().any` નો ઉપયોગ કરી શકો છો:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` ની સ્લાઈસ
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` સાથે શોધો
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// જો X01 એ સ્લાઈસનો ઉપસર્ગ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// જો `needle` ખાલી ટુકડો હોય તો હંમેશાં `true` આપે છે:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// જો `true` એ સ્લાઇસનો પ્રત્યય છે, તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// જો `needle` ખાલી ટુકડો હોય તો હંમેશાં `true` આપે છે:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ઉપસર્ગને દૂર કરીને સબસ્લાઇસ પરત કરે છે.
    ///
    /// જો સ્લાઇસ `prefix` થી શરૂ થાય છે, તો `Some` માં વીંટાળેલા ઉપસર્ગ પછી સબસ્લાઇસ આપે છે.
    /// જો `prefix` ખાલી છે, તો ફક્ત મૂળ કાપી નાંખે.
    ///
    /// જો સ્લાઇસ `prefix` થી પ્રારંભ ન થાય, તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // આ ફંક્શનને ફરીથી લખવાની જરૂર પડશે જો અને જ્યારે સ્લાઈસપatટર્ન વધુ વ્યવહારદક્ષ બને.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// પ્રત્યયને દૂર કર્યા સાથે એક સબસ્લાઇસ આપે છે.
    ///
    /// જો સ્લાઇસ `suffix` સાથે સમાપ્ત થાય છે, તો `Some` માં વીંટાળેલ પ્રત્યય પહેલાં સબસ્લાઇસ આપે છે.
    /// જો `suffix` ખાલી છે, તો ફક્ત મૂળ કાપી નાંખે.
    ///
    /// જો સ્લાઇસ `suffix` સાથે સમાપ્ત થતી નથી, તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // આ ફંક્શનને ફરીથી લખવાની જરૂર પડશે જો અને જ્યારે સ્લાઈસપatટર્ન વધુ વ્યવહારદક્ષ બને.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// દ્વિસંગી આપેલ તત્વ માટે આ સortedર્ટ કરેલી સ્લાઇસ શોધે છે.
    ///
    /// જો કિંમત મળે તો [`Result::Ok`] પરત આવે છે, જેમાં મેચિંગ તત્વની અનુક્રમણિકા શામેલ છે.
    /// જો ત્યાં બહુવિધ મેચ છે, તો પછી કોઈપણ મેચમાંથી પરત મળી શકશે.
    /// જો કિંમત ન મળે તો [`Result::Err`] પરત આવે છે, જેમાં અનુક્રમણિકા શામેલ હોય છે જ્યાં સ matchingર્ટર્ડ orderર્ડર જાળવી રાખતા મેચિંગ તત્વ શામેલ કરી શકાય છે.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`] અને [`partition_point`] પણ જુઓ.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ચાર તત્વોની શ્રેણી જુએ છે.
    /// પ્રથમ જોવા મળે છે, એક અનન્ય નિર્ધારિત સ્થિતિ સાથે;બીજો અને ત્રીજો મળતો નથી;ચોથું `[1, 4]` માં કોઈપણ સ્થિતિ સાથે મેચ કરી શકે છે.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// જો તમે સ sortર્ટ કરેલા vector પર કોઈ આઇટમ દાખલ કરવા માંગતા હો, તો સ sortર્ટ ઓર્ડર જાળવી રાખીને:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// દ્વિસંગી તુલનાત્મક કાર્ય સાથે આ સ aર્ટ કરેલી સ્લાઇસ શોધે છે.
    ///
    /// કમ્પેરેટર ફંક્શનને અંતર્ગત ભાગની ક્રમમાં ગોઠવવાના ક્રમમાં સુસંગત implementર્ડરનો અમલ કરવો જોઈએ, ઓર્ડર કોડ પરત કરવો કે જે સૂચવે છે કે તેની દલીલ `Less`, `Equal` અથવા `Greater` ઇચ્છિત લક્ષ્ય છે કે નહીં.
    ///
    ///
    /// જો કિંમત મળે તો [`Result::Ok`] પરત આવે છે, જેમાં મેચિંગ તત્વની અનુક્રમણિકા શામેલ છે.જો ત્યાં બહુવિધ મેચ છે, તો પછી કોઈપણ મેચમાંથી પરત મળી શકશે.
    /// જો કિંમત ન મળે તો [`Result::Err`] પરત આવે છે, જેમાં અનુક્રમણિકા શામેલ હોય છે જ્યાં સ matchingર્ટર્ડ orderર્ડર જાળવી રાખતા મેચિંગ તત્વ શામેલ કરી શકાય છે.
    ///
    /// [`binary_search`], [`binary_search_by_key`] અને [`partition_point`] પણ જુઓ.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ચાર તત્વોની શ્રેણી જુએ છે.પ્રથમ જોવા મળે છે, એક અનન્ય નિર્ધારિત સ્થિતિ સાથે;બીજો અને ત્રીજો મળતો નથી;ચોથું `[1, 4]` માં કોઈપણ સ્થિતિ સાથે મેચ કરી શકે છે.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // સલામતી: નીચેના આક્રમણકારો દ્વારા ક callલ સલામત બનાવવામાં આવ્યો છે:
            // - `mid >= 0`
            // - `mid < size`: `mid` `[left; right)` બાઉન્ડ દ્વારા મર્યાદિત છે.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // અમે મેચ કરતા if/else નિયંત્રણ પ્રવાહનો ઉપયોગ કેમ કરીએ તે કારણ છે કારણ કે મેચને ફરીથી ગોઠવવાની તુલનાત્મક કામગીરી, જે સંપૂર્ણ સંવેદનશીલ છે.
            //
            // u8 માટે આ x86 asm છે: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// બાઈનરી ચાવી કા extવાના કાર્ય સાથે આ સ thisર્ટ કરેલી સ્લાઇસ શોધે છે.
    ///
    /// ધારે છે કે સ્લાઇસ કી દ્વારા સortedર્ટ કરવામાં આવી છે, ઉદાહરણ તરીકે સમાન કી નિષ્કર્ષણ ફંક્શનનો ઉપયોગ કરીને [`sort_by_key`].
    ///
    /// જો કિંમત મળે તો [`Result::Ok`] પરત આવે છે, જેમાં મેચિંગ તત્વની અનુક્રમણિકા શામેલ છે.
    /// જો ત્યાં બહુવિધ મેચ છે, તો પછી કોઈપણ મેચમાંથી પરત મળી શકશે.
    /// જો કિંમત ન મળે તો [`Result::Err`] પરત આવે છે, જેમાં અનુક્રમણિકા શામેલ હોય છે જ્યાં સ matchingર્ટર્ડ orderર્ડર જાળવી રાખતા મેચિંગ તત્વ શામેલ કરી શકાય છે.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`] અને [`partition_point`] પણ જુઓ.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// બીજા તત્વો દ્વારા સortedર્ટ કરેલા જોડીઓની ટુકડામાં ચાર તત્વોની શ્રેણી જુએ છે.
    /// પ્રથમ જોવા મળે છે, એક અનન્ય નિર્ધારિત સ્થિતિ સાથે;બીજો અને ત્રીજો મળતો નથી;ચોથું `[1, 4]` માં કોઈપણ સ્થિતિ સાથે મેચ કરી શકે છે.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ને `slice::sort_by_key` crate `alloc` માં હોવાને મંજૂરી છે, અને `core` બનાવતી વખતે તે હજી અસ્તિત્વમાં નથી.
    //
    // ડાઉનસ્ટ્રીમ crate: #74481 ની લિંક્સ.કારણ કે આદિમ ફક્ત લિબસ્ટ્ડ એક્સ01 એક્સમાં દસ્તાવેજીકરણ કરવામાં આવે છે, આથી વ્યવહારમાં કદી તુટેલી કડીઓ થતી નથી.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// સ્લાઇસને સortsર્ટ કરે છે, પરંતુ સમાન તત્વોનો ક્રમ જાળવી શકશે નહીં.
    ///
    /// આ સ sortર્ટ અસ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવી શકે છે), ઇન-પ્લેસ (એટલે કે, ફાળવણી કરતું નથી), અને *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ).
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// હાલનું અલ્ગોરિધમનો ઓર્સન પીટર્સ દ્વારા [pattern-defeating quicksort][pdqsort] પર આધારિત છે, જે રેન્ડમાઇઝ્ડ ક્વિક્સોર્ટના ઝડપી સરેરાશ કેસને હીપસોર્ટના સૌથી ખરાબ કેસ સાથે જોડે છે, જ્યારે અમુક દાખલાની સાથે કાપી નાંખ્યું પર રેખીય સમય પ્રાપ્ત કરે છે.
    /// ડિજનરેટ કેસોને ટાળવા માટે તે કેટલાક રેન્ડમાઇઝેશનનો ઉપયોગ કરે છે, પરંતુ હંમેશા નિવારક વર્તન પ્રદાન કરવા માટે નિશ્ચિત ઝેડ સીડ 0 ઝેડ સાથે.
    ///
    /// તે ખાસ કરીને સ્થિર સingર્ટિંગ કરતા વધુ ઝડપી હોય છે, સિવાય કે કેટલાક વિશિષ્ટ કેસો સિવાય, જ્યારે સ્લાઇસમાં કેટલાક કatenન્ટેનેટેડ સortedર્ટ ક્રમ હોય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// કમ્પેરેટર ફંક્શન સાથે સ્લાઈસને સortsર્ટ કરે છે, પરંતુ સમાન તત્વોનો ક્રમ જાળવી શકશે નહીં.
    ///
    /// આ સ sortર્ટ અસ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવી શકે છે), ઇન-પ્લેસ (એટલે કે, ફાળવણી કરતું નથી), અને *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ).
    ///
    /// કમ્પેરેટર ફંક્શનમાં સ્લાઇસમાં તત્વો માટે કુલ ક્રમમાં વ્યાખ્યાયિત કરવી આવશ્યક છે.જો ઓર્ડરિંગ કુલ નથી, તો તત્વોનો ક્રમ અનિશ્ચિત છે.ઓર્ડર એ કુલ ઓર્ડર છે જો તે (બધા `a`, `b` અને `c` માટે):
    ///
    /// * કુલ અને એન્ટિસિમમેટ્રિક: `a < b`, `a == b` અથવા `a > b` માંથી એક બરાબર સાચું છે, અને
    /// * ક્ષણિક, `a < b` અને `b < c` સૂચવે `a < c`.`==` અને `>` બંને માટે સમાન હોવું આવશ્યક છે.
    ///
    /// ઉદાહરણ તરીકે, જ્યારે [`f64`] [`Ord`] લાગુ કરતું નથી કારણ કે `NaN != NaN`, જ્યારે આપણે જાણીએ છીએ કે સ્લાઇસમાં `NaN` નથી હોતો ત્યારે આપણે `partial_cmp` નો ઉપયોગ અમારી સ ourર્ટ ફંક્શન તરીકે કરી શકીએ છીએ.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// હાલનું અલ્ગોરિધમનો ઓર્સન પીટર્સ દ્વારા [pattern-defeating quicksort][pdqsort] પર આધારિત છે, જે રેન્ડમાઇઝ્ડ ક્વિક્સોર્ટના ઝડપી સરેરાશ કેસને હીપસોર્ટના સૌથી ખરાબ કેસ સાથે જોડે છે, જ્યારે અમુક દાખલાની સાથે કાપી નાંખ્યું પર રેખીય સમય પ્રાપ્ત કરે છે.
    /// ડિજનરેટ કેસોને ટાળવા માટે તે કેટલાક રેન્ડમાઇઝેશનનો ઉપયોગ કરે છે, પરંતુ હંમેશા નિવારક વર્તન પ્રદાન કરવા માટે નિશ્ચિત ઝેડ સીડ 0 ઝેડ સાથે.
    ///
    /// તે ખાસ કરીને સ્થિર સingર્ટિંગ કરતા વધુ ઝડપી હોય છે, સિવાય કે કેટલાક વિશિષ્ટ કેસો સિવાય, જ્યારે સ્લાઇસમાં કેટલાક કatenન્ટેનેટેડ સortedર્ટ ક્રમ હોય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // રિવર્સ સોર્ટિંગ
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// કી નિષ્કર્ષણ વિધેય સાથે સ્લાઇસને સortsર્ટ કરે છે, પરંતુ સમાન તત્વોનો ક્રમ જાળવી શકશે નહીં.
    ///
    /// આ સ sortર્ટ અસ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવી શકે છે), ઇન-પ્લેસ (એટલે કે, ફાળવણી કરતું નથી), અને *ઓ*(એમ\* * એન *\* log(*n*)) સૌથી ખરાબ-કેસ છે, જ્યાં કી ફંક્શન *ઓ* છે (*મી*).
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// હાલનું અલ્ગોરિધમનો ઓર્સન પીટર્સ દ્વારા [pattern-defeating quicksort][pdqsort] પર આધારિત છે, જે રેન્ડમાઇઝ્ડ ક્વિક્સોર્ટના ઝડપી સરેરાશ કેસને હીપસોર્ટના સૌથી ખરાબ કેસ સાથે જોડે છે, જ્યારે અમુક દાખલાની સાથે કાપી નાંખ્યું પર રેખીય સમય પ્રાપ્ત કરે છે.
    /// ડિજનરેટ કેસોને ટાળવા માટે તે કેટલાક રેન્ડમાઇઝેશનનો ઉપયોગ કરે છે, પરંતુ હંમેશા નિવારક વર્તન પ્રદાન કરવા માટે નિશ્ચિત ઝેડ સીડ 0 ઝેડ સાથે.
    ///
    /// તેની કી ક callingલિંગ વ્યૂહરચનાને લીધે, કી ફંક્શન ખર્ચાળ હોય તેવા કિસ્સામાં [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) કરતા ધીમું થવાની સંભાવના છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// સ્લાઈસને ફરીથી ગોઠવો કે `index` પરનું તત્વ તેની અંતિમ સortedર્ટ સ્થિતિ પર છે.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// સ્લાઈસને કમ્પેરેટર ફંક્શન સાથે ફરીથી ગોઠવો જેમ કે `index` પર એલિમેન્ટ તેની અંતિમ સ sર્ટ પોઝિશન પર છે.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// કોઈ કી નિષ્કર્ષણ કાર્ય સાથે સ્લાઈસને ફરીથી ગોઠવો જેમ કે `index` પરનું તત્વ તેની અંતિમ સortedર્ટ સ્થિતિ પર છે.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// સ્લાઈસને ફરીથી ગોઠવો કે `index` પરનું તત્વ તેની અંતિમ સortedર્ટ સ્થિતિ પર છે.
    ///
    /// આ ordર્ડરિંગમાં અતિરિક્ત સંપત્તિ છે કે જે સ્થાન `i < index` પરનું કોઈપણ મૂલ્ય, સ્થિતિ `j > index` પરના કોઈપણ મૂલ્ય કરતા ઓછું અથવા તેના સમાન હશે.
    /// વધુમાં, આ પુન reક્રમાંકન અસ્થિર છે (દા.ત.
    /// કોઈપણ સમાન તત્વોની સંખ્યા `index` પોઝિશન પર સમાપ્ત થઈ શકે છે), ઇન-પ્લેસ (એટલે કે
    /// ફાળવણી કરતું નથી) અને *O*(*n*) સૌથી ખરાબ કિસ્સામાં.
    /// આ ફંક્શનને અન્ય લાઇબ્રેરીઓમાં "kth element" તરીકે પણ ઓળખવામાં આવે છે.
    /// તે નીચેના મૂલ્યોનું ત્રિપુટી આપે છે: આપેલ અનુક્રમણિકા પરના બધા કરતા ઓછા તત્વો, આપેલ અનુક્રમણિકાનું મૂલ્ય અને આપેલ અનુક્રમણિકામાંના એક કરતા વધુ બધા તત્વો.
    ///
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ જ ક્વિક્સોર્ટ અલ્ગોરિધમનો ઝડપી પસંદગી ભાગ પર આધારિત છે જે [`sort_unstable`] માટે વપરાય છે.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics જ્યારે `index >= len()`, તેનો અર્થ તે હંમેશાં ખાલી કાપી નાંખ્યું પર panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // સરેરાશ શોધો
    /// v.select_nth_unstable(2);
    ///
    /// // અમને ફક્ત બાંહેધરી આપવામાં આવી છે કે ઉલ્લેખિત અનુક્રમણિકા વિશે જે રીતે સ sortર્ટ કરો છો તેના આધારે, સ્લાઇસેસ નીચેનામાંથી એક હશે.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// સ્લાઈસને કમ્પેરેટર ફંક્શન સાથે ફરીથી ગોઠવો જેમ કે `index` પર એલિમેન્ટ તેની અંતિમ સ sર્ટ પોઝિશન પર છે.
    ///
    /// આ ordર્ડરિંગમાં અતિરિક્ત સંપત્તિ છે કે જે `i < index` ની સ્થિતિ પરના કોઈપણ મૂલ્યની તુલનાત્મક ફંક્શનનો ઉપયોગ કરીને `j > index` પોઝિશન પરના કોઈપણ મૂલ્ય કરતા ઓછા અથવા તેના સમાન હશે.
    /// વધારામાં, આ પુનord ક્રમાંકન અસ્થિર છે (એટલે કે સમાન તત્વોની સંખ્યા સંખ્યા `index` ની સ્થિતિ પર સમાપ્ત થઈ શકે છે), ઇન-પ્લેસ (એટલે કે ફાળવણી કરતું નથી), અને *ઓ*(*એન*) સૌથી ખરાબ કિસ્સામાં.
    /// આ ફંક્શનને અન્ય લાઇબ્રેરીઓમાં "kth element" તરીકે પણ ઓળખવામાં આવે છે.
    /// તે નીચેના મૂલ્યોનું ત્રિપત્ર આપે છે: આપેલ અનુક્રમણિકા પરના બધા કરતા ઓછા તત્વો, આપેલ અનુક્રમણિકાનું મૂલ્ય અને આપેલ અનુક્રમણિકાના એક કરતા વધારે બધા તત્વો, પ્રદાન કરેલા તુલનાત્મક કાર્યનો ઉપયોગ કરીને.
    ///
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ જ ક્વિક્સોર્ટ અલ્ગોરિધમનો ઝડપી પસંદગી ભાગ પર આધારિત છે જે [`sort_unstable`] માટે વપરાય છે.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics જ્યારે `index >= len()`, તેનો અર્થ તે હંમેશાં ખાલી કાપી નાંખ્યું પર panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // મધ્યકને શોધો જેમ કે સ્લાઇસ ઉતરતા ક્રમમાં ગોઠવવામાં આવી હોય.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // અમને ફક્ત બાંહેધરી આપવામાં આવી છે કે ઉલ્લેખિત અનુક્રમણિકા વિશે જે રીતે સ sortર્ટ કરો છો તેના આધારે, સ્લાઇસેસ નીચેનામાંથી એક હશે.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// કોઈ કી નિષ્કર્ષણ કાર્ય સાથે સ્લાઈસને ફરીથી ગોઠવો જેમ કે `index` પરનું તત્વ તેની અંતિમ સortedર્ટ સ્થિતિ પર છે.
    ///
    /// આ ordર્ડરિંગમાં અતિરિક્ત સંપત્તિ છે કે જે `i < index` ની સ્થિતિ પરનું કોઈપણ મૂલ્ય એક્સટ્રેક્શન ફંક્શનનો ઉપયોગ કરીને `j > index` પોઝિશન પરના કોઈપણ મૂલ્ય કરતા ઓછું અથવા તેના સમાન હશે.
    /// વધારામાં, આ પુનord ક્રમાંકન અસ્થિર છે (એટલે કે સમાન તત્વોની સંખ્યા સંખ્યા `index` ની સ્થિતિ પર સમાપ્ત થઈ શકે છે), ઇન-પ્લેસ (એટલે કે ફાળવણી કરતું નથી), અને *ઓ*(*એન*) સૌથી ખરાબ કિસ્સામાં.
    /// આ ફંક્શનને અન્ય લાઇબ્રેરીઓમાં "kth element" તરીકે પણ ઓળખવામાં આવે છે.
    /// તે નીચે આપેલા મૂલ્યોની ત્રિપુટી પરત આપે છે: આપેલ અનુક્રમણિકા પરના બધા કરતા ઓછા તત્વો, આપેલ અનુક્રમણિકાનું મૂલ્ય અને આપેલ અનુક્રમણિકા પરના બધા કરતા વધારે તત્વો, પ્રદાન કરેલા કી નિષ્કર્ષણ વિધેયનો ઉપયોગ કરીને.
    ///
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ જ ક્વિક્સોર્ટ અલ્ગોરિધમનો ઝડપી પસંદગી ભાગ પર આધારિત છે જે [`sort_unstable`] માટે વપરાય છે.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics જ્યારે `index >= len()`, તેનો અર્થ તે હંમેશાં ખાલી કાપી નાંખ્યું પર panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // સરેરાશને પરત કરો જાણે એરે સંપૂર્ણ મૂલ્ય અનુસાર સ accordingર્ટ કરવામાં આવી હોય.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // અમને ફક્ત બાંહેધરી આપવામાં આવી છે કે ઉલ્લેખિત અનુક્રમણિકા વિશે જે રીતે સ sortર્ટ કરો છો તેના આધારે, સ્લાઇસેસ નીચેનામાંથી એક હશે.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait અમલીકરણ અનુસાર બધા સતત પુનરાવર્તિત તત્વોને સ્લાઇસના અંતમાં ખસેડે છે.
    ///
    ///
    /// બે કાપી નાંખે છે.પ્રથમમાં સતત કોઈ પુનરાવર્તિત તત્વો શામેલ નથી.
    /// બીજામાં કોઈ ચોક્કસ ક્રમમાં તમામ ડુપ્લિકેટ્સ શામેલ છે.
    ///
    /// જો સ્લાઇસને સortedર્ટ કરવામાં આવે છે, તો પહેલી રીટર્ન સ્લાઈસમાં કોઈ ડુપ્લિકેટ્સ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// આપેલા સમાનતા સંબંધને સંતોષતા સ્લાઇસના અંતમાં સતત તત્વોના પ્રથમ સિવાય બધાને ખસે છે.
    ///
    /// બે કાપી નાંખે છે.પ્રથમમાં સતત કોઈ પુનરાવર્તિત તત્વો શામેલ નથી.
    /// બીજામાં કોઈ ચોક્કસ ક્રમમાં તમામ ડુપ્લિકેટ્સ શામેલ છે.
    ///
    /// `same_bucket` ફંક્શન સ્લાઈસમાંથી બે તત્વોના સંદર્ભમાં પસાર થાય છે અને તે નક્કી કરવું આવશ્યક છે કે જો તત્વો સમાન સરખામણી કરે.
    /// તત્વો સ્લાઈસમાં તેમના ઓર્ડરથી વિરુદ્ધ ક્રમમાં પસાર થાય છે, તેથી જો `same_bucket(a, b)` `true` પરત આપે, તો `a` સ્લાઈસના અંતમાં ખસેડવામાં આવે છે.
    ///
    ///
    /// જો સ્લાઇસને સortedર્ટ કરવામાં આવે છે, તો પહેલી રીટર્ન સ્લાઈસમાં કોઈ ડુપ્લિકેટ્સ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // તેમ છતાં અમારી પાસે `self` નો પરિવર્તનશીલ સંદર્ભ છે, અમે *મનસ્વી* ફેરફારો કરી શકતા નથી.`same_bucket` ક callsલ્સ panic કરી શકે છે, તેથી આપણે ખાતરી કરવી જોઈએ કે સ્લાઇસ હંમેશાં માન્ય સ્થિતિમાં છે.
        //
        // આપણે જે રીતે આને હેન્ડલ કરીએ છીએ તે સ્વેપ્સનો ઉપયોગ કરીને છે;આપણે બધા તત્વો પર પુનરાવર્તન કરીએ છીએ, જેમ જેમ આપણે આગળ વધીએ છીએ જેથી અંતમાં આપણે જે તત્વો રાખવાની ઇચ્છા રાખીએ છીએ તે આગળ છે, અને જેને આપણે નકારવા માંગીએ છીએ તે પાછળની બાજુએ છે.
        // ત્યારબાદ આપણે સ્લાઈસને વિભાજીત કરી શકીએ છીએ.
        // આ કામગીરી હજી પણ `O(n)` છે.
        //
        // ઉદાહરણ: અમે આ રાજ્યમાં પ્રારંભ કરીએ છીએ, જ્યાં `r` "આગળ" રજૂ કરે છે
        // વાંચો "અને `w` નેક્સ્ટ_રાઇટ` રજૂ કરે છે.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // સ્વ [X-1] ની તુલનામાં self[r] ની તુલના કરવી, આ કોઈ ડુપ્લિકેટ નથી, તેથી અમે self[r] અને self[w] (r==w તરીકે કોઈ અસર નહીં) બદલીએ છીએ અને પછી આર અને ડબ્લ્યુ બંનેને વધારીએ છીએ, અમને છોડીને:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // સ્વ [X-1] ની તુલનામાં self[r] ની તુલના, આ મૂલ્ય એક ડુપ્લિકેટ છે, તેથી આપણે `r` વધારીએ છીએ પરંતુ બાકીની બધી બાબતોને યથાવત છોડી દો:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // સ્વ [X-1] ની સામે self[r] ની તુલના કરો, આ ડુપ્લિકેટ નથી, તેથી self[r] અને self[w] અને અદ્યતન r અને w ને અદલાબદલ કરો:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ડુપ્લિકેટ નહીં, પુનરાવર્તિત કરો:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // ડુપ્લિકેટ, સ્લાઇસનું advance r. End.ડબલ્યુ પર સ્પ્લિટ.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // સલામતી: `while` શરત `next_read` અને `next_write` ની ખાતરી આપે છે
        // `len` કરતા ઓછી હોય છે, આમ `self` ની અંદર હોય છે.
        // `prev_ptr_write` `ptr_write` પહેલાં એક તત્વ તરફ નિર્દેશ કરે છે, પરંતુ `next_write` 1 થી શરૂ થાય છે, તેથી `prev_ptr_write` ક્યારેય 0 કરતા ઓછું હોતું નથી અને તે સ્લાઇસની અંદર નથી.
        // આ `ptr_read`, `prev_ptr_write` અને `ptr_write`, અને `ptr.add(next_read)`, `ptr.add(next_write - 1)` અને `prev_ptr_write.offset(1)` નો ઉપયોગ કરવા માટેની આવશ્યકતાઓને પૂર્ણ કરે છે.
        //
        //
        // `next_write` લૂપ દીઠ એકવારમાં પણ એક વખત વધારો કરવામાં આવે છે, એટલે કે જ્યારે તેને અદલાબદલ કરવાની જરૂર પડે ત્યારે કોઈ તત્વ છોડવામાં આવતું નથી.
        //
        // `ptr_read` અને `prev_ptr_write` ક્યારેય સમાન તત્વ તરફ નિર્દેશ કરતા નથી.`&mut *ptr_read`, `&mut* prev_ptr_write` સલામત રહેવા માટે આ જરૂરી છે.
        // સમજૂતી ફક્ત એટલી છે કે `next_read >= next_write` હંમેશાં સાચું હોય છે, આમ `next_read > next_write - 1` પણ છે.
        //
        //
        //
        //
        //
        unsafe {
            // કાચા પોઇન્ટરનો ઉપયોગ કરીને બાઉન્ડ્સ તપાસને ટાળો.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// તે જ કીમાં ઉકેલાતા સ્લાઇસના અંતમાં સળંગ તત્વોના પ્રથમ સિવાય બધાને ખસે છે.
    ///
    ///
    /// બે કાપી નાંખે છે.પ્રથમમાં સતત કોઈ પુનરાવર્તિત તત્વો શામેલ નથી.
    /// બીજામાં કોઈ ચોક્કસ ક્રમમાં તમામ ડુપ્લિકેટ્સ શામેલ છે.
    ///
    /// જો સ્લાઇસને સortedર્ટ કરવામાં આવે છે, તો પહેલી રીટર્ન સ્લાઈસમાં કોઈ ડુપ્લિકેટ્સ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// સ્લાઈસને સ્થાને સ્થાને ફેરવો જેમ કે સ્લાઇસના પ્રથમ `mid` તત્વો અંત તરફ જાય છે જ્યારે છેલ્લા `self.len() - mid` તત્વો આગળના ભાગમાં જાય છે.
    /// `rotate_left` ને ક callingલ કર્યા પછી, અગાઉ સૂચકાંક `mid` પરનું તત્વ સ્લાઈસમાં પ્રથમ ઘટક બનશે.
    ///
    /// # Panics
    ///
    /// જો `mid` સ્લાઈસની લંબાઈ કરતા વધારે હોય તો આ ફંક્શન panic કરશે.નોંધ લો કે `mid == self.len()` _not_ panic કરે છે અને નો-rotપ રોટેશન છે.
    ///
    /// # Complexity
    ///
    /// રેખીય લે છે (`self.len()`) સમયમાં.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// એક સબસ્લાઇસ ફેરવો:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // સલામતી: `[p.add(mid) - mid, p.add(mid) + k)` ની શ્રેણી ક્ષણિક છે
        // વાંચવા અને લખવા માટે માન્ય, `ptr_rotate` દ્વારા જરૂરી.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// સ્લાઈસને સ્થાને સ્થાને ફેરવો જેમ કે સ્લાઇસના પ્રથમ `self.len() - k` તત્વો અંત તરફ જાય છે જ્યારે છેલ્લા `k` તત્વો આગળના ભાગમાં જાય છે.
    /// `rotate_right` ને ક callingલ કર્યા પછી, અગાઉ સૂચકાંક `self.len() - k` પરનું તત્વ સ્લાઈસમાં પ્રથમ ઘટક બનશે.
    ///
    /// # Panics
    ///
    /// જો `k` સ્લાઈસની લંબાઈ કરતા વધારે હોય તો આ ફંક્શન panic કરશે.નોંધ લો કે `k == self.len()` _not_ panic કરે છે અને નો-rotપ રોટેશન છે.
    ///
    /// # Complexity
    ///
    /// રેખીય લે છે (`self.len()`) સમયમાં.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// એક સબસ્લાઇસ ફેરવો:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // સલામતી: `[p.add(mid) - mid, p.add(mid) + k)` ની શ્રેણી ક્ષણિક છે
        // વાંચવા અને લખવા માટે માન્ય, `ptr_rotate` દ્વારા જરૂરી.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ને ક્લોનીંગ કરીને તત્વોથી `self` ભરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// વારંવાર બંધ થવા પર ક callingલ કરીને પાછા ફરતા તત્વો સાથે `self` ભરો.
    ///
    /// આ પદ્ધતિ નવા મૂલ્યો બનાવવા માટે ક્લોઝરનો ઉપયોગ કરે છે.જો તમે આપેલ મૂલ્ય [`Clone`] કરતા હો, તો [`fill`] નો ઉપયોગ કરો.
    /// જો તમે મૂલ્યો ઉત્પન્ન કરવા માટે [`Default`] trait નો ઉપયોગ કરવા માંગો છો, તો તમે દલીલ તરીકે [`Default::default`] પસાર કરી શકો છો.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` માંથી તત્વોને `self` માં કiesપિ કરે છે.
    ///
    /// `src` ની લંબાઈ `self` જેટલી જ હોવી જોઈએ.
    ///
    /// જો `T`, `Copy` લાગુ કરે છે, તો તે [`copy_from_slice`] નો ઉપયોગ કરવા માટે વધુ પ્રદર્શનકારક હોઈ શકે છે.
    ///
    /// # Panics
    ///
    /// જો આ કાપી નાંખ્યું જુદી જુદી લંબાઈમાં હોય તો આ કાર્ય panic કરશે.
    ///
    /// # Examples
    ///
    /// એક ટુકડામાંથી બીજામાં બે તત્વો ક્લોનિંગ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // કાપી નાંખવાની લંબાઈ સમાન લંબાઈ હોવી જોઈએ, તેથી આપણે સ્રોતની સ્લાઈસ ચાર તત્વોથી બે કરી કા .ીએ છીએ.
    /// // જો આપણે આ નહીં કરીએ તો તે ઝેડપૈનિક 0 ઝેડ હશે.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// ઝેડ 0 રસ્ટ0 ઝેડ લાગુ કરે છે કે કોઈ ચોક્કસ અવકાશમાં ડેટાના કોઈ ચોક્કસ ભાગનો કોઈ પરિવર્તનશીલ સંદર્ભો સાથે માત્ર એક પરિવર્તનશીલ સંદર્ભ હોઈ શકે છે.
    /// આને કારણે, એક ટુકડા પર `clone_from_slice` નો ઉપયોગ કરવાનો પ્રયાસ કરવાથી કમ્પાઇલ નિષ્ફળ થશે:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// આના વિશે કાર્ય કરવા માટે, અમે સ્લાઈસમાંથી બે અલગ પેટા-ટુકડા બનાવવા માટે [`split_at_mut`] નો ઉપયોગ કરી શકીએ છીએ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// મેક્સીનો ઉપયોગ કરીને, `src` માંથી બધા ઘટકોને `self` માં કiesપિ કરે છે.
    ///
    /// `src` ની લંબાઈ `self` જેટલી જ હોવી જોઈએ.
    ///
    /// જો `T`, `Copy` લાગુ કરતું નથી, તો [`clone_from_slice`] નો ઉપયોગ કરો.
    ///
    /// # Panics
    ///
    /// જો આ કાપી નાંખ્યું જુદી જુદી લંબાઈમાં હોય તો આ કાર્ય panic કરશે.
    ///
    /// # Examples
    ///
    /// સ્લાઈસમાંથી બે તત્વોની બીજી ક Copપિ બનાવવી:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // કાપી નાંખવાની લંબાઈ સમાન લંબાઈ હોવી જોઈએ, તેથી આપણે સ્રોતની સ્લાઈસ ચાર તત્વોથી બે કરી કા .ીએ છીએ.
    /// // જો આપણે આ નહીં કરીએ તો તે ઝેડપૈનિક 0 ઝેડ હશે.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// ઝેડ 0 રસ્ટ0 ઝેડ લાગુ કરે છે કે કોઈ ચોક્કસ અવકાશમાં ડેટાના કોઈ ચોક્કસ ભાગનો કોઈ પરિવર્તનશીલ સંદર્ભો સાથે માત્ર એક પરિવર્તનશીલ સંદર્ભ હોઈ શકે છે.
    /// આને કારણે, એક ટુકડા પર `copy_from_slice` નો ઉપયોગ કરવાનો પ્રયાસ કરવાથી કમ્પાઇલ નિષ્ફળ થશે:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// આના વિશે કાર્ય કરવા માટે, અમે સ્લાઈસમાંથી બે અલગ પેટા-ટુકડા બનાવવા માટે [`split_at_mut`] નો ઉપયોગ કરી શકીએ છીએ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // ક0લ સાઇટને ફૂલે નહીં તે માટે ઝેડ 0 પicનિક 80 ઝેડ કોડ પાથ ઠંડા ફંક્શનમાં મૂકવામાં આવ્યો હતો.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // સલામતી: `self` એ વ્યાખ્યા મુજબ `self.len()` તત્વો માટે માન્ય છે, અને `src` હતી
        // સમાન લંબાઈ રાખવા માટે ચકાસાયેલ.
        // કાપી નાંખ્યું ઓવરલેપ કરી શકતું નથી કારણ કે પરિવર્તનીય સંદર્ભો વિશિષ્ટ છે.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// મેમમોવનો ઉપયોગ કરીને સ્લાઈસના એક ભાગમાંથી તત્વોની પોતાની જાતે બીજા ભાગમાં ક Copપિ કરે છે.
    ///
    /// `src` જેની નકલ કરવા માટે `self` ની અંદરની રેન્જ છે.
    /// `dest` તેની નકલ કરવા માટે `self` અંદરની શ્રેણીનો પ્રારંભિક સૂચકાંક છે, જેની લંબાઈ `src` જેટલી હશે.
    /// બે શ્રેણીઓ ઓવરલેપ થઈ શકે છે.
    /// બે શ્રેણીઓનો અંત `self.len()` કરતા ઓછો અથવા તેના સમાન હોવો જોઈએ.
    ///
    /// # Panics
    ///
    /// આ ફંક્શન ઝેડપpanનીક0 ઝેડ કરશે જો કાં તો શ્રેણી સ્લાઈસના અંતથી વધી ગઈ હોય, અથવા જો `src` નો અંત શરૂઆત પહેલાંનો હોય.
    ///
    ///
    /// # Examples
    ///
    /// એક ટુકડાની અંદર ચાર બાઇટ્સની નકલ:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // સલામતી: `ptr::copy` માટેની શરતો બધા ઉપર તપાસવામાં આવી છે,
        // જેમ કે `ptr::add` માટે છે.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` માંના બધા તત્વોને `self` માં અદલાબદલ કરે છે.
    ///
    /// `other` ની લંબાઈ `self` જેટલી જ હોવી જોઈએ.
    ///
    /// # Panics
    ///
    /// જો આ કાપી નાંખ્યું જુદી જુદી લંબાઈમાં હોય તો આ કાર્ય panic કરશે.
    ///
    /// # Example
    ///
    /// કાપી નાંખે બે તત્વો અદલાબદલ કરી રહ્યા છીએ:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// ઝેડ 0 રસ્ટ0 ઝેડ લાગુ કરે છે કે કોઈ ચોક્કસ અવકાશમાં ડેટાના કોઈ ચોક્કસ ભાગ માટે ફક્ત એક પરિવર્તનશીલ સંદર્ભ હોઈ શકે છે.
    ///
    /// આને કારણે, એક ટુકડા પર `swap_with_slice` નો ઉપયોગ કરવાનો પ્રયાસ કરવાથી કમ્પાઇલ નિષ્ફળ થશે:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// આની આસપાસ કામ કરવા માટે, અમે સ્લાઈસમાંથી બે અલગ અલગ પરિવર્તનીય પેટા-ટુકડા બનાવવા માટે [`split_at_mut`] નો ઉપયોગ કરી શકીએ છીએ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // સલામતી: `self` એ વ્યાખ્યા મુજબ `self.len()` તત્વો માટે માન્ય છે, અને `src` હતી
        // સમાન લંબાઈ રાખવા માટે ચકાસાયેલ.
        // કાપી નાંખ્યું ઓવરલેપ કરી શકતું નથી કારણ કે પરિવર્તનીય સંદર્ભો વિશિષ્ટ છે.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` માટે મધ્યમ અને પાછળની સ્લાઇસેસની લંબાઈની ગણતરી કરવા માટેનું કાર્ય.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // અમે `rest` વિશે જે કરવાનું છે તે આકૃતિ છે કે આપણે lowest T`s ની સૌથી ઓછી સંખ્યામાં કેટલા put U`s મૂકી શકીએ છીએ.
        //
        // અને આવા દરેક "multiple" માટે આપણે કેટલા `T`s જોઈએ.
        //
        // ઉદાહરણ તરીકે T=u8 U=u16 ને ધ્યાનમાં લો.પછી આપણે 1 યુ ને 2 સે માં મૂકી શકીએ.સરળ.
        // હવે, ઉદાહરણ તરીકે એક કેસ ધ્યાનમાં લો જ્યાં કદ_કોમ: :<T>=16, કદ_::::<U>24.</u>
        // અમે `rest` સ્લાઈસમાં દરેક 3 સેસની જગ્યાએ 2 યુ મૂકી શકીએ.
        // થોડી વધુ જટિલ.
        //
        // આની ગણતરી કરવા માટેનું સૂત્ર છે:
        //
        // અમારો= lcm(size_of::<T>, size_of::<U>)/કદ_ફાર: : <U>ટીએસ= lcm(size_of::<T>, size_of::<U>)/કદ_::</u><T>
        //
        // વિસ્તૃત અને સરળ:
        //
        // અમારો=કદ_: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=કદ_::::<U>gcd(size_of::<T>, size_of::<U>)</u>
        //
        // સદભાગ્યે, કારણ કે આ બધું સતત મૂલ્યાંકન કરવામાં આવે છે ... અહીં પ્રદર્શન મહત્વનું નથી!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // પુનરાવર્તિત સ્ટેઇનનું એલ્ગોરિધમ આપણે હજી પણ આ `const fn` બનાવવું જોઈએ (અને જો આપણે કરીએ તો રિકર્સીવ અલ્ગોરિધમનમાં પાછા ફરવું જોઈએ) કારણ કે આ બધું કન્સ્ટિવલ કરવા માટે llvm પર આધાર રાખવો એ છે ... સારું, તે મને અસ્વસ્થ બનાવે છે.
            //
            //

            // સલામતી: `a` અને `b` એ બિન-શૂન્ય મૂલ્યો હોવાનું ચકાસાયેલ છે.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // બી માંથી 2 ના બધા પરિબળો ને દૂર કરો
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // સલામતી: `b` એ બિન-શૂન્ય હોવાનું ચકાસાયેલ છે.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // આ જ્ knowledgeાનથી સજ્જ, આપણે શોધી શકીએ કે આપણે કેટલા યુએસ ફિટ થઈ શકીએ!
        let us_len = self.len() / ts * us;
        // અને પાછળના ભાગમાં કેટલા `T`s હશે!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// સ્લાઇસને બીજા પ્રકારની સ્લાઈસમાં ટ્રાન્સમિટ કરો, સુનિશ્ચિત કરો કે પ્રકારોની ગોઠવણી જાળવવામાં આવે છે.
    ///
    /// આ પદ્ધતિ સ્લાઇસેસને ત્રણ અલગ અલગ ટુકડાઓમાં વિભાજીત કરે છે: ઉપસર્ગ, યોગ્ય રીતે એક નવા પ્રકારની મધ્યમ કટકા ગોઠવી, અને પ્રત્યયની કાતરી.
    /// આપેલ પ્રકાર અને ઇનપુટ સ્લાઇસ માટે પદ્ધતિ મધ્યમ સ્લાઈસને સૌથી મોટી લંબાઈને શક્ય બનાવશે, પરંતુ ફક્ત તમારા અલ્ગોરિધમનો પ્રભાવ તેના પર નિર્ભર હોવો જોઈએ, તેની સાચીતા પર નહીં.
    ///
    /// બધા ઇનપુટ ડેટાને ઉપસર્ગ અથવા પ્રત્યયની કાપી નાંખવામાં આવે તે માન્ય છે.
    ///
    /// આ પદ્ધતિનો કોઈ હેતુ નથી જ્યારે ઇનપુટ એલિમેન્ટ `T` અથવા આઉટપુટ એલિમેન્ટ `U` શૂન્ય-કદના હોય અને કંઈપણ ભાગ પાડ્યા વિના મૂળ ટુકડા પાછા આપશે.
    ///
    /// # Safety
    ///
    /// પરત મધ્યમ કટકાના તત્વોના સંદર્ભમાં આ પદ્ધતિ આવશ્યકરૂપે એક `transmute` છે, તેથી `transmute::<T, U>` સંબંધિત તમામ સામાન્ય ચેતવણીઓ પણ અહીં લાગુ પડે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // નોંધ લો કે આમાંના મોટા ભાગના કાર્યનું સતત મૂલ્યાંકન કરવામાં આવશે,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ઝેડએસટીને ખાસ રીતે હેન્ડલ કરો, જે છે-તેમને બરાબર હેન્ડલ ન કરો.
            return (self, &[], &[]);
        }

        // પ્રથમ, આપણે પ્રથમ અને 2 જી સ્લાઈસ વચ્ચે કયા તબક્કે વિભાજીત કરીશું તે શોધો.
        // ptr.align_offset સાથે સરળ.
        let ptr = self.as_ptr();
        // સલામતી: વિગતવાર સલામતી ટિપ્પણી માટે `align_to_mut` પદ્ધતિ જુઓ.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // સલામતી: હવે `rest` ચોક્કસપણે ગોઠવાયેલ છે, તેથી નીચે `from_raw_parts` ઠીક છે,
            // કારણ કે કlerલર ખાતરી આપે છે કે અમે `T` ને `U` માં સુરક્ષિત રૂપે ટ્રાન્સમિટ કરી શકીએ છીએ.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// સ્લાઇસને બીજા પ્રકારની સ્લાઈસમાં ટ્રાન્સમિટ કરો, સુનિશ્ચિત કરો કે પ્રકારોની ગોઠવણી જાળવવામાં આવે છે.
    ///
    /// આ પદ્ધતિ સ્લાઇસેસને ત્રણ અલગ અલગ ટુકડાઓમાં વિભાજીત કરે છે: ઉપસર્ગ, યોગ્ય રીતે એક નવા પ્રકારની મધ્યમ કટકા ગોઠવી, અને પ્રત્યયની કાતરી.
    /// આપેલ પ્રકાર અને ઇનપુટ સ્લાઇસ માટે પદ્ધતિ મધ્યમ સ્લાઈસને સૌથી મોટી લંબાઈને શક્ય બનાવશે, પરંતુ ફક્ત તમારા અલ્ગોરિધમનો પ્રભાવ તેના પર નિર્ભર હોવો જોઈએ, તેની સાચીતા પર નહીં.
    ///
    /// બધા ઇનપુટ ડેટાને ઉપસર્ગ અથવા પ્રત્યયની કાપી નાંખવામાં આવે તે માન્ય છે.
    ///
    /// આ પદ્ધતિનો કોઈ હેતુ નથી જ્યારે ઇનપુટ એલિમેન્ટ `T` અથવા આઉટપુટ એલિમેન્ટ `U` શૂન્ય-કદના હોય અને કંઈપણ ભાગ પાડ્યા વિના મૂળ ટુકડા પાછા આપશે.
    ///
    /// # Safety
    ///
    /// પરત મધ્યમ કટકાના તત્વોના સંદર્ભમાં આ પદ્ધતિ આવશ્યકરૂપે એક `transmute` છે, તેથી `transmute::<T, U>` સંબંધિત તમામ સામાન્ય ચેતવણીઓ પણ અહીં લાગુ પડે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // નોંધ લો કે આમાંના મોટા ભાગના કાર્યનું સતત મૂલ્યાંકન કરવામાં આવશે,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ઝેડએસટીને ખાસ રીતે હેન્ડલ કરો, જે છે-તેમને બરાબર હેન્ડલ ન કરો.
            return (self, &mut [], &mut []);
        }

        // પ્રથમ, આપણે પ્રથમ અને 2 જી સ્લાઈસ વચ્ચે કયા તબક્કે વિભાજીત કરીશું તે શોધો.
        // ptr.align_offset સાથે સરળ.
        let ptr = self.as_ptr();
        // સલામતી: અહીં અમે સુનિશ્ચિત કરીએ છીએ કે અમે યુ માટે સંરેખિત પોઇંટરનો ઉપયોગ કરીશું
        // બાકીની પદ્ધતિ.આ યુ માટે લક્ષિત ગોઠવણી સાથે&[T] પર પોઇન્ટર પસાર કરીને કરવામાં આવે છે.
        // `crate::ptr::align_offset` તેને યોગ્ય રીતે ગોઠવાયેલ અને માન્ય પોઇન્ટર `ptr` (તે `self` ના સંદર્ભમાંથી આવે છે) અને તેની સુરક્ષાની અવરોધોને સંતોષીને, બેની શક્તિ ધરાવતા કદ (જેમ કે તે યુ માટેના જોડાણથી આવે છે) સાથે કહેવામાં આવે છે.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // અમે આ પછી ફરીથી `rest` નો ઉપયોગ કરી શકતા નથી, તે તેના ઉર્ફે `mut_ptr` ને અમાન્ય કરશે!સલામત: `align_to` માટે ટિપ્પણીઓ જુઓ.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// જો આ સ્લાઈસના તત્વો ગોઠવાય છે કે કેમ તે તપાસો.
    ///
    /// તે છે, દરેક તત્વ `a` અને તેના નીચેના તત્વ `b` માટે, `a <= b` હોવું આવશ્યક છે.જો સ્લાઇસ બરાબર શૂન્ય અથવા એક તત્વ આપે છે, તો `true` પરત આવે છે.
    ///
    /// નોંધ લો કે જો `Self::Item` એ ફક્ત `PartialOrd` છે, પરંતુ `Ord` નથી, તો ઉપરોક્ત વ્યાખ્યા સૂચવે છે કે જો કોઈ પણ સતત બે વસ્તુઓ તુલનાત્મક ન હોય તો આ ફંક્શન `false` આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// આપેલ કમ્પેરેટર ફંક્શનનો ઉપયોગ કરીને જો આ સ્લાઈસના તત્વોને સ areર્ટ કરવામાં આવ્યા છે કે કેમ તે તપાસો.
    ///
    /// `PartialOrd::partial_cmp` નો ઉપયોગ કરવાને બદલે, બે તત્વોનો ક્રમ નક્કી કરવા માટે આ કાર્ય આપેલ `compare` ફંક્શનનો ઉપયોગ કરે છે.
    /// તે સિવાય, તે [`is_sorted`] ની બરાબર છે;વધુ માહિતી માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// આપેલ કી નિષ્કર્ષણ ફંક્શનનો ઉપયોગ કરીને આ ટુકડાઓના તત્વોને સortedર્ટ કરવામાં આવ્યા છે કે કેમ તે તપાસો.
    ///
    /// સ્લાઇસના તત્વોની સીધી સરખામણી કરવાને બદલે, આ કાર્ય તત્વોની કીઓની તુલના કરે છે, જે `f` દ્વારા નિર્ધારિત છે.
    /// તે સિવાય, તે [`is_sorted`] ની બરાબર છે;વધુ માહિતી માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// આપેલ પ્રિડીકેટ (બીજા પાર્ટીશનના પ્રથમ તત્વની અનુક્રમણિકા) અનુસાર પાર્ટીશન પોઇન્ટનું અનુક્રમણિકા આપે છે.
    ///
    /// સ્લાઇસ આપેલ પૂર્વધારણા અનુસાર પાર્ટીશન કરે તેવું માનવામાં આવે છે.
    /// આનો અર્થ એ છે કે તે બધા તત્વો કે જેના માટે આગાહીનું વળતર સાચી છે તે સ્લાઇસની શરૂઆતમાં છે અને તે બધા તત્વો કે જેના માટે આગાહી ખોટું આપે છે તે અંત છે.
    ///
    /// ઉદાહરણ તરીકે, [7, 15, 3, 5, 4, 12, 6] એ પ્રિડિકેટ x% 2!=0 હેઠળ પાર્ટીશન થયેલ છે (બધી વિચિત્ર સંખ્યાઓ શરૂઆતમાં છે, બધા પણ અંતે).
    ///
    /// જો આ સ્લાઇસનું પાર્ટીશન થયેલું નથી, તો પાછું આવ્યું પરિણામ અનિશ્ચિત અને અર્થહીન છે, કારણ કે આ પદ્ધતિ એક પ્રકારની દ્વિસંગી શોધ કરે છે.
    ///
    /// [`binary_search`], [`binary_search_by`] અને [`binary_search_by_key`] પણ જુઓ.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // સલામતી: જ્યારે `left < right`, `left <= mid < right`.
            // તેથી `left` હંમેશા વધે છે અને `right` હંમેશા ઘટે છે, અને તેમાંથી કોઈપણ પસંદ થયેલ છે.બંને કિસ્સાઓમાં `left <= right` સંતુષ્ટ છે.તેથી જો એક પગલામાં `left < right`, તો `left <= right` આગલા પગલામાં સંતુષ્ટ છે.
            //
            // તેથી જ્યાં સુધી `left != right`, `0 <= left < right <= len` સંતુષ્ટ છે અને જો આ કેસ `0 <= mid < len` પણ સંતુષ્ટ છે.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: આપણે તેમને સમાન લંબાઈ પર સ્પષ્ટ રીતે કાપી નાખવાની જરૂર છે
        // elપ્ટિમાઇઝરને એલિડ સીમાઓની તપાસ કરવાનું સરળ બનાવવા માટે.
        // પરંતુ તેના પર આધાર રાખી શકાતો નથી તેથી અમારી પાસે ટી: કોપી માટે પણ સ્પષ્ટ સ્પષ્ટીકરણ છે.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// ખાલી કટકા બનાવે છે.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// પરિવર્તનશીલ ખાલી કટકા બનાવે છે.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// કાપી નાંખવાના દાખલાઓ, હાલમાં, ફક્ત `strip_prefix` અને `strip_suffix` દ્વારા વપરાય છે.
/// ઝેડ 0 ફ્યુચર0 ઝેડ પોઇન્ટ પર, અમે `core::str::Pattern` (જે લેખન સમયે `str` સુધી મર્યાદિત છે) ના ટુકડાઓને સામાન્ય બનાવવાની આશા રાખીએ છીએ, અને પછી આ ઝેડ 0 ટ્રાઈટ0 ઝેડ બદલી અથવા નાબૂદ કરવામાં આવશે.
///
pub trait SlicePattern {
    /// કટકાનો તત્વ પ્રકાર મેળ ખાતો હોય છે.
    type Item;

    /// હાલમાં, `SlicePattern` ના ગ્રાહકોને સ્લાઈસની જરૂર છે.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}