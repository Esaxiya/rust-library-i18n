// મૂળ અમલીકરણ ઝેડ ર્રસ્ટ0 ઝેડ-મેચચ્રેથી લેવામાં આવ્યું.
// ક Copyrightપિરાઇટ 2015 એન્ડ્રુ ગેલન્ટ, બ્લસ અને નિકોલસ કોચ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// કાપણીનો ઉપયોગ કરો.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// જો `x` માં કોઈપણ શૂન્ય બાઇટ શામેલ હોય તો `true` આપે છે.
///
/// *મેટર્સ ક Compમ્પ્યુટેશનલ*, જે. અરંડ તરફથી:
///
/// "આ વિચાર એ છે કે દરેક બાઇટ્સમાંથી એકને બાદબાકી કરીને પછી બાઇટ્સ જોઈએ કે જ્યાં orrowણ લેતી વખતે બધી રીતે ખૂબ નોંધપાત્ર રીતે ફેલાય
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` માં બાઇટ `x` સાથે મેળ ખાતું પ્રથમ અનુક્રમણિકા આપે છે.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // નાના ટુકડાઓ માટે ઝડપી માર્ગ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // એક સમયે બે `usize` શબ્દો વાંચીને એક બાઇટ મૂલ્ય માટે સ્કેન કરો.
    //
    // ત્રણ ભાગોમાં `text` સ્પ્લિટ કરો
    // - લખાણમાં પ્રથમ શબ્દ સંરેખિત સરનામું પહેલાં, બિન સહી કરેલ પ્રારંભિક ભાગ
    // - બોડી, એક સમયે 2 શબ્દો દ્વારા સ્કેન કરો
    // - છેલ્લો બાકીનો ભાગ, <2 શબ્દ કદ

    // સંરેખિત સીમા સુધી શોધો
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ટેક્સ્ટનો મુખ્ય ભાગ શોધો
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // સલામતી: જ્યારેનું પૂર્વનિર્ધારણ ઓછામાં ઓછું 2 * usize_bytes અંતરની બાંયધરી આપે છે
        // ઓફસેટ અને સ્લાઇસના અંતની વચ્ચે.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // જો ત્યાં મેચિંગ બાઇટ હોય તો તોડી નાખો
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // બોડી લૂપ બંધ થયા પછી બિંદુ પછી બાઈટ શોધો.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` માં બાઇટ `x` સાથે મેળ ખાતું છેલ્લું અનુક્રમણિકા આપે છે.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // એક સમયે બે `usize` શબ્દો વાંચીને એક બાઇટ મૂલ્ય માટે સ્કેન કરો.
    //
    // `text` ને ત્રણ ભાગોમાં વિભાજિત કરો:
    // - ટેક્સ્ટમાં છેલ્લા શબ્દ સંરેખિત સરનામાં પછી, બિન સહી કરેલ પૂંછડી,
    // - શરીર, એક સમયે 2 શબ્દો દ્વારા સ્કેન,
    // - પ્રથમ બાકીના બાઇટ્સ, <2 શબ્દનું કદ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // આને ફક્ત ઉપસર્ગ અને પ્રત્યયની લંબાઈ મેળવવા માટે કહીએ છીએ.
        // મધ્યમાં આપણે હંમેશાં એક સાથે બે ભાગની પ્રક્રિયા કરીએ છીએ.
        // સલામતી: `[u8]` ને `[usize]` પર સ્થાનાંતરિત કરવું તે સલામત છે કદ સિવાયના તફાવતો સિવાય કે જે `align_to` દ્વારા નિયંત્રિત કરવામાં આવે છે.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ટેક્સ્ટના મુખ્ય ભાગની શોધ કરો, ખાતરી કરો કે અમે મીન_આલિન્ટેડ_ઓફસેટને પાર નથી કરતા.
    // setફસેટ હંમેશા ગોઠવાયેલ હોય છે, તેથી ફક્ત `>` નું પરીક્ષણ કરવું પૂરતું છે અને શક્ય ઓવરફ્લોને ટાળે છે.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // સલામતી: setફસેટ લેન, suffix.len() થી શરૂ થાય છે, ત્યાં સુધી તે તેના કરતા વધારે હોય
        // min_aligned_offset (prefix.len()) બાકીનું અંતર ઓછામાં ઓછું 2 * ભાગ_બેટ્સ છે.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // મેચિંગ બાઇટ હોય તો તોડી નાખો.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // શરીરનો લૂપ બંધ થઈ ગયો તે બિંદુ પહેલાં બાઇટ શોધો.
    text[..offset].iter().rposition(|elt| *elt == x)
}