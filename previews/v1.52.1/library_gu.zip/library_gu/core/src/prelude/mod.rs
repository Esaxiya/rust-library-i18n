//! લિબકોર ઝેડપ્રીઅલ 0 ઝેડ
//!
//! આ મોડ્યુલ લિબકોરના વપરાશકર્તાઓ માટે બનાવાયેલ છે જે લિબસ્ટેડ સાથે લિંક પણ નથી કરતા.
//! આ મોડ્યુલ ડિફોલ્ટ રૂપે આયાત કરવામાં આવે છે જ્યારે `#![no_std]` એ પ્રમાણભૂત લાઇબ્રેરીના ઝેડપ્રેસ્યુલેડ ઝેડની જેમ ઉપયોગમાં લેવાય છે.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// કોર ઝેડપ્રીઅલ0 ઝેડનું 2015 સંસ્કરણ.
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// કોર ઝેડપ્રીપલ 0 ઝેડનું 2018 સંસ્કરણ.
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// કોર ઝેડ 0 પ્રિપ્રોઇલ્ડ0 ઝેડનું 2021 સંસ્કરણ.
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: વધુ વસ્તુઓ ઉમેરો.
}