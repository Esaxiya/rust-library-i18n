//! લિબકોર માટે Panic સપોર્ટ
//!
//! મુખ્ય લાઇબ્રેરી ગભરાટ ભર્યાને વ્યાખ્યાયિત કરી શકતી નથી, પરંતુ તે *ઘોષણા* ઘોષણા કરે છે.
//! આનો અર્થ એ કે લિબકોરની અંદરના કાર્યોને ઝેડપpanનિકિક ઝેડ માટે મંજૂરી છે, પરંતુ અપસ્ટ્રીમ ઝેડ 0 ક્રેટ 0 ઝેડ ઉપયોગ માટે લિબકોર માટે ગભરાટને વ્યાખ્યાયિત કરવી આવશ્યક છે.
//! ગભરાટ માટે વર્તમાન ઇન્ટરફેસ છે:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! આ વ્યાખ્યા કોઈપણ સામાન્ય સંદેશથી ગભરાવાની મંજૂરી આપે છે, પરંતુ તે `Box<Any>` મૂલ્ય સાથે નિષ્ફળ થવાની મંજૂરી આપતું નથી.
//! (`PanicInfo` માં હમણાં જ એક `&(dyn Any + Send)` શામેલ છે, જેના માટે આપણે `PanicInfo: : આંતરિક_constructor` માં ડમી વેલ્યુ ભરીએ છીએ.) આનું કારણ એ છે કે લિબકોરને ફાળવણી કરવાની મંજૂરી નથી.
//!
//!
//! આ મોડ્યુલમાં કેટલાક અન્ય ગભરાટના કાર્યોનો સમાવેશ છે, પરંતુ આ ફક્ત કમ્પાઇલર માટે જરૂરી લ itemsંગ આઇટમ્સ છે.બધા ઝેડ 0 સ્પેનિક્સ 0 ઝેડને આ એક ફંકશન દ્વારા ફનલે કરવામાં આવ્યા છે.
//! વાસ્તવિક પ્રતીક `#[panic_handler]` લક્ષણ દ્વારા જાહેર કરવામાં આવે છે.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// જ્યારે કોઈ ફોર્મેટિંગનો ઉપયોગ કરવામાં આવતો નથી ત્યારે લિબકોરના `panic!` મેક્રોની અંતર્ગત અમલીકરણ.
#[cold]
// શક્ય તેટલી ક callલ સાઇટ્સ પર કોડ ફુલાવને ટાળવા માટે, જ્યાં સુધી ગભરાટ ભર્યા વગર_અનમંત_અબાઉટ ઇનલાઇન ન કરો
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ઓવરફ્લો અને અન્ય `Assert` MIR ટર્મિનેટર પર panic માટે કોડજેન દ્વારા જરૂરી
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // સંભવિત કદના ઓવરહેડને ઘટાડવા માટે ફોર્મેટ_ાર્ગ્સની જગ્યાએ Arguments::new_v1 નો ઉપયોગ કરો ("{}", એક્સપ્રેસ).
    // ફોર્મેટ_ર્ગ્સ!મેક્રો એક્સપ્રેસ લખવા માટે સ્ટ્રર્ટના ડિસ્પ્લે ઝેડટ્રેટ0 ઝેડનો ઉપયોગ કરે છે, જે Formatter::pad ને ક callsલ કરે છે, જેમાં શબ્દમાળા કાપવા અને ગાદી સમાવવા આવશ્યક છે (જો કે અહીં કંઈપણ વપરાયેલ નથી).
    //
    // Arguments::new_v1 નો ઉપયોગ કરવાથી કમ્પ્યુલરને Formatter::pad ને આઉટપુટ દ્વિસંગીમાંથી બાકાત રાખવા દેશે, થોડા કિલોબાઇટ્સ સુધી બચત થશે.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // કોન્સ્ટ-મૂલ્યાંકન થયેલ ઝેડ 0 પpanનિક્સ 0 ઝેડ માટે જરૂરી છે
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice વપરાશ પર panic માટે કોડજેન દ્વારા જરૂરી
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// જ્યારે ફોર્મેટિંગનો ઉપયોગ થાય છે ત્યારે લિબકોરના `panic!` મ maક્રોની અંતર્ગત અમલીકરણ.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // નોંધ આ કાર્ય ક્યારેય એફએફઆઈની સીમાને પાર કરતું નથી;તે એક Rust-to-Rust ક callલ છે જે `#[panic_handler]` ફંક્શનમાં ઉકેલાઈ જાય છે.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // સલામત: `panic_impl` સલામત Rust કોડમાં વ્યાખ્યાયિત કરવામાં આવી છે અને આમ ક callલ કરવા માટે સલામત છે.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` અને `assert_ne!` મેક્રોઝ માટે આંતરિક કાર્ય
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}