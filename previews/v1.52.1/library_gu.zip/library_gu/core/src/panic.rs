//! સ્ટાન્ડર્ડ લાઇબ્રેરીમાં Panic સપોર્ટ.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic વિશે માહિતી પ્રદાન કરતું એક સ્ટ્રક્ટ.
///
/// `PanicInfo` સ્ટ્રક્ચરને [`set_hook`] ફંકશન દ્વારા સેટ કરેલા panic hook પર પસાર કરવામાં આવે છે.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic સાથે સંકળાયેલ પેલોડ પરત કરે છે.
    ///
    /// આ સામાન્ય રીતે, પરંતુ હંમેશાં નહીં, `&'static str` અથવા [`String`] હશે.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// જો `core` crate (`std` માંથી નહીં) ના `panic!` મેક્રોનો ઉપયોગ ફોર્મેટિંગ સ્ટ્રિંગ અને કેટલાક વધારાના દલીલો સાથે કરવામાં આવ્યો હતો, તો તે સંદેશ [`fmt::write`] સાથે ઉદાહરણ તરીકે ઉપયોગમાં લેવા માટે તૈયાર છે.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// જો ઉપલબ્ધ હોય તો તે સ્થાન વિશેની માહિતી પરત કરે છે કે જ્યાંથી ઝેડપicનિક 0 ઝેડ.
    ///
    /// આ પદ્ધતિ હાલમાં હંમેશાં [`Some`] પરત કરશે, પરંતુ આ ઝેડ 0 ફ્યુચર0 ઝેડ સંસ્કરણોમાં બદલાઈ શકે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: જો આને કોઈક વાર પરત નહીં બદલવામાં આવે તો,
        // std::panicking::default_hook અને std::panicking::begin_panic_fmt માં તે કેસ સાથે વ્યવહાર કરો.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: અમે ડાઉનકાસ્ટ_રેફ: : નો ઉપયોગ કરી શકતા નથી<String>() અહીં
        // શબ્દમાળા લિબકોરમાં ઉપલબ્ધ નથી!
        // પેલોડ એ એક શબ્દમાળા છે જ્યારે `std::panic!` ને બહુવિધ દલીલો સાથે બોલાવવામાં આવે છે, પરંતુ તે કિસ્સામાં સંદેશ પણ ઉપલબ્ધ છે.
        //

        self.location.fmt(formatter)
    }
}

/// panic ના સ્થાન વિશેની માહિતી ધરાવતો સ્ટ્રક્ટ.
///
/// આ રચના [`PanicInfo::location()`] દ્વારા બનાવવામાં આવી છે.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// સમાનતા અને ingર્ડરિંગની તુલના ફાઇલ, લાઇન અને પછી ક columnલમ અગ્રતામાં કરવામાં આવે છે.
/// ફાઇલોની તુલના તાર તરીકે કરવામાં આવે છે, `Path` નહીં, જે અણધારી હોઈ શકે છે.
/// વધુ ચર્ચા માટે [`સ્થાન: : ફાઇલ`] નું દસ્તાવેજીકરણ જુઓ.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// આ ફંક્શનના કlerલરનું સ્રોત સ્થાન પરત કરે છે.
    /// જો તે ફંક્શનના કlerલરને otનોટેટ કરવામાં આવે છે, તો તેનું ક callલ સ્થાન પરત કરવામાં આવશે, અને તેથી આગળ ન aન-ટ્રેક ફંક્શન બ bodyડીમાંના પ્રથમ ક callલ પર સ્ટેક છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] પરત કરે છે જ્યાં તેને કહેવામાં આવે છે.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// આ ફંક્શનની વ્યાખ્યામાંથી એક [`Location`] આપે છે.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // એક સરખા અનટ્રેક્ડ ફંક્શનને જુદી જુદી જગ્યાએ ચલાવવાથી એ જ પરિણામ મળે છે
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ટ્રેકેડ ફંક્શનને જુદા જુદા સ્થાને ચલાવવાથી એક અલગ વેલ્યુ મળે છે
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// સ્રોત ફાઇલનું નામ પરત કરે છે જ્યાંથી ઝેડપેનિનિક0 ઝેડ.
    ///
    /// # `&str`, `&Path` નથી
    ///
    /// પરત થયેલ નામ કમ્પાઇલિંગ સિસ્ટમના સ્રોત પાથનો સંદર્ભ આપે છે, પરંતુ સીધા તેને `&Path` તરીકે રજૂ કરવું તે માન્ય નથી.
    /// કમ્પાઈલ કોડ સામગ્રીને પ્રદાન કરતી સિસ્ટમ કરતા જુદા જુદા `Path` અમલીકરણ સાથેની એક અલગ સિસ્ટમ પર ચાલશે અને આ લાઇબ્રેરીમાં હાલમાં "host path" પ્રકારનો પ્રકાર નથી.
    ///
    /// સૌથી આશ્ચર્યજનક વર્તન થાય છે જ્યારે "the same" ફાઇલ મોડ્યુલ સિસ્ટમમાં (સામાન્ય રીતે `#[path = "..."]` એટ્રિબ્યુટ અથવા સમાનનો ઉપયોગ કરીને) બહુવિધ માર્ગો દ્વારા પહોંચી શકાય તેવું છે, જે આ કાર્યથી જુદા જુદા મૂલ્યોને પરત આપવા માટે સમાન કોડ તરીકે દેખાય છે તેનું કારણ બની શકે છે.
    ///
    ///
    /// # Cross-compilation
    ///
    /// જ્યારે યજમાન પ્લેટફોર્મ અને લક્ષ્ય પ્લેટફોર્મ અલગ હોય ત્યારે આ મૂલ્ય `Path::new` અથવા સમાન બાંધકામો પર પસાર થવા માટે યોગ્ય નથી.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic નો ઉદ્ભવ થયો તે રેખા નંબર પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// ક0લમ પરત કરે છે જ્યાંથી panic ઉત્પન્ન થયું.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd થી `panic_unwind` અને અન્ય panic રનટાઇમ્સ પર ડેટા પસાર કરવા માટે libstd દ્વારા ઉપયોગમાં લેવામાં આવતી આંતરિક trait.
/// કોઈપણ સમયે જલ્દી સ્થિર થવાનો હેતુ નથી, ઉપયોગ કરશો નહીં.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// સમાવિષ્ટોની સંપૂર્ણ માલિકી લો.
    /// રીટર્નનો પ્રકાર ખરેખર `Box<dyn Any + Send>` છે, પરંતુ અમે લિબોક inરમાં `Box` નો ઉપયોગ કરી શકતા નથી.
    ///
    /// આ પદ્ધતિ કહેવાયા પછી, `self` માં ફક્ત કેટલાક ડમી ડિફ defaultલ્ટ મૂલ્ય બાકી છે.
    /// આ પદ્ધતિને બે વાર ક twiceલ કરવો, અથવા આ પદ્ધતિને ક afterલ કર્યા પછી `get` પર ક callingલ કરવો એ એક ભૂલ છે.
    ///
    /// દલીલ ઉધાર લેવામાં આવી છે કારણ કે ઝેડપpanપનિકનીકઝેડ રનટાઈમ (`__rust_start_panic`) ફક્ત ઉધાર લેવાયેલ `dyn BoxMeUp` મેળવે છે.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// ફક્ત સમાવિષ્ટો ઉધાર.
    fn get(&mut self) -> &(dyn Any + Send);
}