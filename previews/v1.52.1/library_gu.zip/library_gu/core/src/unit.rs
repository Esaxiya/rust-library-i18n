use crate::iter::FromIterator;

/// પુનરાવર્તકમાંથી બધી એકમની વસ્તુઓ એકમાં ભંગ કરી દે છે.
///
/// જ્યારે તમે ફક્ત ભૂલોની કાળજી લેતા હોવ ત્યારે `Result<(), E>` પર એકત્રિત કરવા જેવા ઉચ્ચ-સ્તરના અમૂર્તતાઓ સાથે જોડાતી વખતે આ વધુ ઉપયોગી છે:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}