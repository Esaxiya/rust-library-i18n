//! સુસ્ત મૂલ્યો અને સ્થિર ડેટાની એક-સમય પ્રારંભિકરણ.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// એક કોષ જે ફક્ત એક જ વાર લખી શકાય છે.
///
/// `RefCell` થી વિપરીત, `OnceCell` ફક્ત તેના મૂલ્ય માટે શેર કરેલા `&T` સંદર્ભ પ્રદાન કરે છે.
/// `Cell` થી વિપરીત, `OnceCell` ને તેની toક્સેસ કરવા માટે મૂલ્યની નકલ કરવાની અથવા તેને બદલવાની જરૂર નથી.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // ઇન્વેરેન્ટ: એક સાથે એક વાર લખાયેલ.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// નવો ખાલી સેલ બનાવે છે.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// અંતર્ગત મૂલ્યનો સંદર્ભ મેળવે છે.
    ///
    /// જો કોષ ખાલી હોય તો `None` પરત કરે છે.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // સલામતી: `આંતરિક'ના આક્રમકને કારણે સલામત
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// અંતર્ગત મૂલ્યના પરિવર્તનીય સંદર્ભ મેળવે છે.
    ///
    /// જો કોષ ખાલી હોય તો `None` પરત કરે છે.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // સલામત: સલામત કારણ કે આપણી પાસે અનોખી accessક્સેસ છે
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// સેલની સામગ્રીને `value` પર સેટ કરો.
    ///
    /// # Errors
    ///
    /// આ પદ્ધતિ `Ok(())` પરત કરે છે જો કોષ ખાલી હતો અને જો તે ભરેલો હોય તો `Err(value)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // સલામતી: સલામત કારણ કે આપણી પાસે ઓવરલેપિંગ પરિવર્તનીય ઉધાર હોઈ શકતા નથી
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // સલામતી: આ એકમાત્ર એવી જગ્યા છે જ્યાં આપણે સ્લોટ સેટ કરીએ છીએ, રેસ નહીં
        // reentrancy/concurrency ને લીધે શક્ય છે, અને અમે તપાસ કરી છે કે સ્લોટ હાલમાં `None` છે, તેથી આ લખાણ `આંતરિક'ના અગ્રણીને જાળવી રાખે છે.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// કોષની સામગ્રી મેળવે છે, જો કોષ ખાલી હતો તો `f` સાથે પ્રારંભ કરીને.
    ///
    /// # Panics
    ///
    /// જો `f` panics, panic એ કlerલરને ફેલાવવામાં આવે છે, અને સેલ બિનસલાહભર્યા રહે છે.
    ///
    ///
    /// `f` થી સેલને ફરી શરૂ કરવા માટે તે ભૂલ છે.આમ કરવાથી ઝેડ 0 પicનિકિક ઝેડમાં પરિણમે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// કોષની સામગ્રી મેળવે છે, જો કોષ ખાલી હતો તો `f` સાથે પ્રારંભ કરીને.
    /// જો સેલ ખાલી હતો અને `f` નિષ્ફળ થયો, તો ભૂલ પાછો આવે છે.
    ///
    /// # Panics
    ///
    /// જો `f` panics, panic એ કlerલરને ફેલાવવામાં આવે છે, અને સેલ બિનસલાહભર્યા રહે છે.
    ///
    ///
    /// `f` થી સેલને ફરી શરૂ કરવા માટે તે ભૂલ છે.આમ કરવાથી ઝેડ 0 પicનિકિક ઝેડમાં પરિણમે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // નોંધ લો કે પુનરાવર્તિત આરંભના કેટલાક કેટલાક પ્રકારો યુબી તરફ દોરી શકે છે (જુઓ `reentrant_init` પરીક્ષણ).
        // હું માનું છું કે આ `assert` ને હટાવવું, જ્યારે `set/get` રાખવું તે અવાજ હશે, પરંતુ ચૂપચાપ જૂના મૂલ્યનો ઉપયોગ કરવાને બદલે ઝેડપેનિક0 ઝેડ માટે તે વધુ સારું લાગે છે.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// આવરિત મૂલ્ય પરત કરીને, કોષનો ઉપયોગ કરે છે.
    ///
    /// જો કોષ ખાલી હતો તો `None` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // કારણ કે `into_inner` `self` ને મૂલ્યથી લે છે, કમ્પાઇલર સ્થિર રૂપે ખાતરી કરે છે કે તે હાલમાં ઉધાર લીધેલ નથી.
        // તેથી `Option<T>` ને બહાર ખસેડવું સલામત છે.
        self.inner.into_inner()
    }

    /// આ `OnceCell` માંથી મૂલ્ય લે છે, તેને પાછા બિનકાર્યક્ષમ સ્થિતિમાં ખસેડીને.
    ///
    /// જો તેની અસર નથી અને જો `OnceCell` પ્રારંભ થયેલ ન હોય તો `None` આપે છે.
    ///
    /// પરિવર્તનશીલ સંદર્ભની જરૂરિયાત દ્વારા સલામતીની ખાતરી આપવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// એક મૂલ્ય જે પ્રથમ onક્સેસ પર પ્રારંભ થાય છે.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   પ્રારંભિક તૈયાર છે
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// આપેલ આરંભિક કાર્ય સાથે નવું આળસુ મૂલ્ય બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// આ આળસુ મૂલ્યનું મૂલ્યાંકન કરવા દબાણ કરે છે અને પરિણામનો સંદર્ભ આપે છે.
    ///
    ///
    /// આ `Deref` પ્રોત્સાહન સમાન છે, પરંતુ સ્પષ્ટ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// પ્રારંભિક કાર્ય તરીકે `Default` નો ઉપયોગ કરીને એક નવું આળસુ મૂલ્ય બનાવે છે.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}