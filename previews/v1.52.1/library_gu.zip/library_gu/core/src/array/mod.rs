//! નિશ્ચિત લંબાઈના એરે માટે `Eq` જેવી વસ્તુઓના અમલીકરણ.
//! આખરે, આપણે બધી લંબાઈમાં સામાન્ય બનાવવું જોઈએ.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` ના સંદર્ભને લંબાઈ 1 (કyingપિ કર્યા વિના) ની એરેના સંદર્ભમાં રૂપાંતરિત કરે છે.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // સલામત: `&T` ને `&[T; 1]` માં રૂપાંતરિત કરવું એ અવાજ છે.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` ના પરિવર્તનીય સંદર્ભને લંબાઈ 1 (કrayપિ કર્યા વિના) ની એરેના પરિવર્તનીય સંદર્ભમાં રૂપાંતરિત કરે છે.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // સલામત: `&mut T` ને `&mut [T; 1]` માં રૂપાંતરિત કરવું એ અવાજ છે.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// ઉપયોગિતા trait ફક્ત નિયત કદના એરે પર જ લાગુ કરવામાં આવી છે
///
/// આ ઝેડ 0 ટ્રાઈટ0 ઝેડનો ઉપયોગ મેટાડેટા બલુનને લીધા વગર સ્થિર-કદના એરે પર અન્ય ઝેડટ્રેટ 0 ઝેડને લાગુ કરવા માટે થઈ શકે છે.
///
/// અમલીકરણોને ફિક્સ-સાઇઝ એરે સુધી મર્યાદિત કરવા માટે ઝેડટ્રેટ 0 ઝેડ અસુરક્ષિત તરીકે ચિહ્નિત થયેલ છે.
/// આ ઝેડ 0 ટ્રાઇટ0 ઝેડનો વપરાશકર્તા માની શકે છે કે અમલીકરણો પાસે ચોક્કસ કદના એરે (ઉદાહરણ તરીકે, અસુરક્ષિત આરંભ માટે) ની મેમરીમાં ચોક્કસ લેઆઉટ હોય છે.
///
///
/// નોંધ લો કે traits [`AsRef`] અને [`AsMut`] એ પ્રકારો માટે સમાન પદ્ધતિઓ પ્રદાન કરે છે જે નિશ્ચિત-કદના એરે હોઈ શકે નહીં.
/// તેના બદલે અમલીકરણકર્તાઓએ તે traits ને પ્રાધાન્ય આપવું જોઈએ.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// એરેને સ્થાનાંતરિત સ્લાઇસમાં ફેરવે છે
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// એરેને પરિવર્તનીય સ્લાઇસમાં રૂપાંતરિત કરે છે
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// જ્યારે સ્લાઇસમાંથી એરેમાં રૂપાંતર નિષ્ફળ જાય ત્યારે ભૂલનો પ્રકાર પાછો ફર્યો.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // સલામતી: ઠીક છે કારણ કે આપણે હમણાં જ તપાસ્યું છે કે લંબાઈ ફિટ છે
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // સલામતી: ઠીક છે કારણ કે આપણે હમણાં જ તપાસ્યું છે કે લંબાઈ ફિટ છે
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: કોડ ફૂલવું ઘટાડવા માટે કેટલીક ઓછી મહત્વપૂર્ણ ઇમ્પ્લ્સ અવગણવામાં આવે છે
// __ સિમ્પલ_સ્લિસ_ઇક 2!{ [A; $N], &'b [B; $N] }___ll_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// એરે [lexicographically](Ord#lexicographical-comparison) ની તુલના લાગુ કરે છે.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// ડિફaultલ્ટ ઇમ્પ્લ્સ કોન્સ્ટ જicsનરિક્સ સાથે કરી શકાતા નથી કારણ કે `[T; 0]` ને ડિફaultલ્ટનો અમલ થવાની જરૂર નથી, અને વિવિધ નંબરો માટે જુદા જુદા પ્રોમ્પ્ટ બ્લોક્સ હોવાને હજી સમર્થન નથી.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// ક્રમમાં દરેક તત્વ પર લાગુ `f` ફંક્શન સાથે, `self` જેવા સમાન કદના એરે આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // સલામતી: આપણે ચોક્કસ જાણીએ છીએ કે આ પુનરાવર્તક બરાબર `N` પ્રાપ્ત કરશે
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// જોડીની એક જ એરેમાં બે એરેને 'ઝિપ્સ અપ' કરો.
    ///
    /// `zip()` એક નવો એરે આપે છે જ્યાં પ્રત્યેક તત્વ એ ટુપલ છે જ્યાં પ્રથમ તત્વ પ્રથમ એરેથી આવે છે, અને બીજો તત્વ બીજા એરેથી આવે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, તે એક સાથે બે એરેને ઝિપ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // સલામતી: આપણે ચોક્કસ જાણીએ છીએ કે આ પુનરાવર્તક બરાબર `N` પ્રાપ્ત કરશે
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// સમગ્ર એરેવાળી સ્લાઈસ પરત કરે છે.`&s[..]` ની સમકક્ષ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// આખા એરેવાળી પરિવર્તનીય સ્લાઇસ પરત કરે છે.
    /// `&mut s[..]` ની સમકક્ષ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// દરેક તત્વ ઉધાર લે છે અને `self` જેટલા કદવાળા સંદર્ભોની એરે આપે છે.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// જો [`map`](#method.map) જેવી અન્ય પદ્ધતિઓ સાથે જોડવામાં આવે તો આ પદ્ધતિ ખાસ કરીને ઉપયોગી છે.
    /// આ રીતે, જો મૂળ એરે `Copy` ન હોય તો તમે એરે ખસેડવાનું ટાળી શકો છો.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // અમે હજી પણ મૂળ એરેને canક્સેસ કરી શકીએ છીએ: તેને ખસેડવામાં આવ્યો નથી.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // સલામતી: આપણે ચોક્કસ જાણીએ છીએ કે આ પુનરાવર્તક બરાબર `N` પ્રાપ્ત કરશે
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// દરેક તત્વ પરસ્પર ઉધાર લે છે અને `self` જેટલા જ કદવાળા પરિવર્તનીય સંદર્ભોની એરે આપે છે.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // સલામતી: આપણે ચોક્કસ જાણીએ છીએ કે આ પુનરાવર્તક બરાબર `N` પ્રાપ્ત કરશે
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `N` એક્સમાંથી `N` આઇટમ્સ ખેંચે છે અને તેમને એરે તરીકે આપે છે.
/// જો પુનરાવર્તક `N` કરતાં ઓછી આઇટમ્સ મેળવે છે, તો આ કાર્ય અસ્પષ્ટ વર્તન દર્શાવે છે.
///
///
/// વધુ માહિતી માટે [`collect_into_array`] જુઓ.
///
/// # Safety
///
/// ક00લરની ખાતરી છે કે `iter` ઓછામાં ઓછી `N` આઇટમ્સ આપે છે.
/// આ સ્થિતિનું ઉલ્લંઘન એ અનિશ્ચિત વર્તનનું કારણ બને છે.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: અહીં `TrustedLen` અંશે પ્રયોગ છે.આ માત્ર એક છે
    // આંતરિક કાર્ય, તેથી જો આ બાઉન્ડ કોઈ ખરાબ ખ્યાલ આવે તો દૂર કરવા માટે મફત લાગે.
    // તે સંજોગોમાં, નીચે નીચલા બાઉન્ડ `debug_assert!` ને પણ દૂર કરવાનું યાદ રાખો!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // સલામત: કાર્ય કરાર દ્વારા આવરી લેવામાં.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` માંથી `N` આઇટમ્સ ખેંચે છે અને તેમને એરે તરીકે આપે છે.જો પુનરાવર્તક `N` આઇટમ્સ કરતાં ઓછી ઉપજ આપે છે, તો `None` પરત આવે છે અને પહેલેથી જ ઉપજવાળી બધી વસ્તુઓ છોડી દેવામાં આવે છે.
///
/// કારણ કે ઇરેટરને પરિવર્તનીય સંદર્ભ તરીકે પસાર કરવામાં આવે છે અને આ ફંક્શન, `next` ને મોટાભાગના `N` સમયે કહે છે, બાકીની આઇટમ્સને પુન toપ્રાપ્ત કરવા માટે પુનરાવર્તક પછી પણ ઉપયોગ કરી શકાય છે.
///
///
/// જો `iter.next()` પ panનિક કરે છે, તો પહેલેથી જ પુનરાવર્તક દ્વારા ઉપજિત બધી આઇટમ્સ છોડી દેવામાં આવે છે.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // સલામતી: ખાલી એરે હંમેશા વસવાટ કરે છે અને તેમાં કોઈ માન્યતા આક્રમણો નથી.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // સલામતી: આ કાચી કટકામાં ફક્ત પ્રારંભિક containબ્જેક્ટ્સ હશે.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // સલામતી: `guard.initialized` 0 થી પ્રારંભ થાય છે, એકમાં વધારો થયો છે
        // લૂપ અને લૂપ એ એન (જે `array.len()`) છે) પર પહોંચ્યા પછી તેને છોડી દેવામાં આવે છે.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // તપાસો કે આખા એરે શરૂ થયા છે.
        if guard.initialized == N {
            mem::forget(guard);

            // સલામતી: ઉપરની સ્થિતિ બધા તત્વોની ખાતરી આપે છે
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // આ ફક્ત ત્યારે જ પહોંચી શકાય છે જો `guard.initialized` `N` પર પહોંચે તે પહેલાં જો ઇરેટર થાકી ગયો હોય.
    //
    // એ પણ નોંધો કે `guard` અહીં છોડવામાં આવ્યું છે, બધા પહેલેથી જ પ્રારંભિક તત્વોને છોડીને.
    None
}