//! એરે માટે `IntoIter` માલિકીની પુનરાવર્તિત વ્યાખ્યાયિત કરે છે.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// એક બાય-વેલ્યુ [array] પુનરાવર્તક.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// આ એરે છે જે આપણે ઉપર ફરીએ છીએ.
    ///
    /// અનુક્રમણિકા `i` સાથેના તત્વો જ્યાં `alive.start <= i < alive.end` હજી પ્રાપ્ત થયા નથી અને માન્ય એરે પ્રવેશો છે.
    /// સૂચકાંકો `i < alive.start` અથવા `i >= alive.end` સાથેના તત્વો પહેલેથી જ પ્રાપ્ત થયા છે અને હવે cesક્સેસ કરવા જોઈએ નહીં!તે મૃત તત્વો પણ સંપૂર્ણપણે બિનસલાહભર્યા સ્થિતિમાં હોઈ શકે છે!
    ///
    ///
    /// તેથી આક્રમણો છે:
    /// - `data[alive]` જીવંત છે (એટલે કે માન્ય તત્વો શામેલ છે)
    /// - `data[..alive.start]` અને `data[alive.end..]` મરી ગયા છે (એટલે કે તત્વો પહેલાથી જ વાંચેલા હતા અને હવે તેને સ્પર્શ કરવો જોઈએ નહીં!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` માં તત્વો કે જે હજી અપાયા નથી.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// આપેલ `array` ઉપર એક નવો ઇટરેટર બનાવે છે.
    ///
    /// *નોંધ*: [`IntoIterator` is implemented for arrays][array-into-iter] પછી, આ પદ્ધતિ ઝેડ ફ્યુચર0 ઝેડમાં નાપસંદ થઈ શકે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` નો પ્રકાર અહીં `&i32` ને બદલે `i32` છે
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // સલામતી: અહીં ટ્રાન્સમ્યુટ ખરેખર સલામત છે.`MaybeUninit` ના દસ્તાવેજો
        // promise:
        //
        // > `MaybeUninit<T>` સમાન કદ અને ગોઠવણીની બાંયધરી છે
        // > `T` તરીકે.
        //
        // ડsક્સ પણ `MaybeUninit<T>` ની એરેથી `T` ની એરેમાં ટ્રાન્સમ્યુટ બતાવે છે.
        //
        //
        // તેની સાથે, આ આરંભ આક્રમણકારોને સંતુષ્ટ કરે છે.

        // FIXME(LukasKalbertodt): ખરેખર અહીં `mem::transmute` નો ઉપયોગ કરો, એકવાર તે કોન્સ જેનરીક્સ સાથે કામ કરે છે:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ત્યાં સુધી, આપણે `mem::transmute_copy` નો ઉપયોગ બીટવાઇઝ કોપીને વિવિધ પ્રકાર તરીકે બનાવવા માટે કરી શકીએ છીએ, પછી `array` ને ભૂલી જાઓ જેથી તેને છોડવામાં ન આવે.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// હજી સુધી ઉપજ ન મળેલા તમામ તત્વોની એક પરિવર્તનશીલ સ્લાઇસ આપે છે.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // સલામતી: આપણે જાણીએ છીએ કે `alive` ની અંદરના બધા તત્વો યોગ્ય રીતે પ્રારંભ થયા છે.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// બધા તત્વોની પરિવર્તનીય સ્લાઇસ આપે છે જે હજી પ્રાપ્ત થઈ નથી.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // સલામતી: આપણે જાણીએ છીએ કે `alive` ની અંદરના બધા તત્વો યોગ્ય રીતે પ્રારંભ થયા છે.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // આગળથી અનુક્રમણિકા મેળવો.
        //
        // `alive.start` ને 1 દ્વારા વધારવું એ `alive` સંબંધિત આક્રમણને જાળવી રાખે છે.
        // જો કે, આ ફેરફારને કારણે, ટૂંકા સમય માટે, જીવંત ઝોન હવે `data[alive]` નથી, પરંતુ `data[idx..alive.end]` છે.
        //
        self.alive.next().map(|idx| {
            // એરેમાંથી એલિમેન્ટ વાંચો.
            // સલામતી: `idx` એ પહેલાના "alive" ક્ષેત્રમાં એક અનુક્રમણિકા છે
            // એરે.આ તત્વને વાંચવાનો અર્થ એ છે કે `data[idx]` ને હવે મૃત માનવામાં આવે છે (એટલે કે સ્પર્શ કરશો નહીં).
            // `idx` એ જીવંત-ઝોનની શરૂઆત હોવાથી, જીવંત ઝોન હવે ફરીથી `data[alive]` છે, બધા આક્રમણોને પુનર્સ્થાપિત કરી રહ્યું છે.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // પાછળથી આગળનું અનુક્રમણિકા મેળવો.
        //
        // `alive.end` ને 1 દ્વારા ઘટાડવું એ `alive` સંબંધિત આક્રમણને જાળવી રાખે છે.
        // જો કે, આ ફેરફારને કારણે, ટૂંકા સમય માટે, જીવંત ઝોન હવે `data[alive]` નથી, પરંતુ `data[alive.start..=idx]` છે.
        //
        self.alive.next_back().map(|idx| {
            // એરેમાંથી એલિમેન્ટ વાંચો.
            // સલામતી: `idx` એ પહેલાના "alive" ક્ષેત્રમાં એક અનુક્રમણિકા છે
            // એરે.આ તત્વને વાંચવાનો અર્થ એ છે કે `data[idx]` ને હવે મૃત માનવામાં આવે છે (એટલે કે સ્પર્શ કરશો નહીં).
            // જેમ કે `idx` એ જીવંત-ઝોનનો અંત હતો, જીવંત ઝોન હવે ફરીથી `data[alive]` છે, બધા આક્રમણોને પુનર્સ્થાપિત કરી રહ્યો છે.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // સલામતી: આ સલામત છે: `as_mut_slice` બરાબર પેટા-સ્લાઇસ આપે છે
        // તત્વો છે કે જે હજી સુધી ખસેડવામાં આવ્યા નથી અને તે છોડી દેવા માટે બાકી છે.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // આક્રમક `live.start <=ને લીધે ક્યારેય ભૂગર્ભમાં ભરાય નહીં
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// પુનરાવર્તક ખરેખર સાચી લંબાઈની જાણ કરે છે.
// "alive" તત્વોની સંખ્યા (જે હજી પણ પ્રાપ્ત થશે) `alive` ની લંબાઈ છે.
// `next` અથવા `next_back` ક્યાં તો આ શ્રેણી લંબાઈમાં ઘટાડો થાય છે.
// તે હંમેશા તે પદ્ધતિઓમાં 1 દ્વારા ઘટાડવામાં આવે છે, પરંતુ માત્ર ત્યારે જ જો `Some(_)` પરત આવે.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // નોંધ, આપણે ખરેખર એક સરખી જીવંત શ્રેણી સાથે મેળ કરવાની જરૂર નથી, તેથી `self` ક્યાં છે તે ધ્યાનમાં લીધા વિના આપણે ફક્ત setફસેટ 0 માં ક્લોન કરી શકીએ છીએ.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // બધા જીવંત તત્વો ક્લોન કરો.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // નવી એરેમાં ક્લોન લખો, પછી તેની જીવંત શ્રેણી અપડેટ કરો.
            // જો panics ને ક્લોન કરી રહ્યા છીએ, તો અમે પાછલી આઇટમ્સને યોગ્ય રીતે મૂકીશું.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ફક્ત તે તત્વો છાપો કે જે હજી પ્રાપ્ત થયા નથી: અમે હવે ઉપજ આપનારા તત્વોને cannotક્સેસ કરી શકતા નથી.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}