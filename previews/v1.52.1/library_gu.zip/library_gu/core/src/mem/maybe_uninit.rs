use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` ના અનઇંટિલાઇઝ્ડ ઉદાહરણો બનાવવા માટેનો રેપર પ્રકાર.
///
/// # પ્રારંભિક આક્રમણક
///
/// કમ્પાઇલર, સામાન્ય રીતે, ધારે છે કે વેરીએબલના પ્રકારની જરૂરિયાતો અનુસાર ચલ યોગ્ય રીતે પ્રારંભ થયેલ છે.ઉદાહરણ તરીકે, સંદર્ભ પ્રકારનું ચલ ગોઠવવું આવશ્યક છે અને બિન-એનયુએલ.
/// આ એક આક્રમક છે જેને અસુરક્ષિત કોડમાં પણ *હંમેશાં* સમર્થન આપવું આવશ્યક છે.
/// પરિણામ રૂપે, સંદર્ભ પ્રકારનાં ચલને શૂન્ય-પ્રારંભિકરણ કરવાથી ઝટપટ [undefined behavior][ub] થાય છે, પછી ભલે તે સંદર્ભ મેમરીની accessક્સેસ માટે ક્યારેય ઉપયોગમાં ન આવે:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // અસ્પષ્ટ વર્તન!⚠️
/// // `MaybeUninit<&i32>` સાથેનો સમકક્ષ કોડ:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // અસ્પષ્ટ વર્તન!⚠️
/// ```
///
/// વિવિધ optimપ્ટિમાઇઝેશન, જેમ કે રન-ટાઇમ ચેક્સને બંધ કરવા અને `enum` લેઆઉટને optimપ્ટિમાઇઝ કરવા માટે કમ્પાઇલર દ્વારા તેનું શોષણ કરવામાં આવે છે.
///
/// એ જ રીતે, સંપૂર્ણ અનઇંટિઆલાઇઝ્ડ મેમરીમાં કોઈપણ સામગ્રી હોઈ શકે છે, જ્યારે `bool` હંમેશા `true` અથવા `false` હોવી જોઈએ.તેથી, અનઇંટિઆલાઇઝ્ડ `bool` બનાવવું એ અસ્પૃષ્ટ વર્તન છે:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // અસ્પષ્ટ વર્તન!⚠️
/// // `MaybeUninit<bool>` સાથેનો સમકક્ષ કોડ:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // અસ્પષ્ટ વર્તન!⚠️
/// ```
///
/// તદુપરાંત, અનઇંટિઆલાઇઝ્ડ મેમરી વિશેષ છે જેમાં તેની પાસે નિશ્ચિત મૂલ્ય નથી ("fixed" જેનો અર્થ "it won't change without being written to" છે).ઘણી વખત સમાન અનઇંટિલાઇઝ્ડ બાઈટ વાંચવાથી વિવિધ પરિણામો મળી શકે છે.
/// આ વેરીએબલમાં ઇંટીજર પ્રકાર હોય તો પણ તે વેરીએબલમાં અનઇંટિલાઇઝ્ડ ડેટા રાખવા માટે વર્તણૂકને અસ્પષ્ટ બનાવે છે, જે અન્યથા કોઈપણ *ફિક્સ* બીટ પેટર્ન ધરાવે છે:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // અસ્પષ્ટ વર્તન!⚠️
/// // `MaybeUninit<i32>` સાથેનો સમકક્ષ કોડ:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // અસ્પષ્ટ વર્તન!⚠️
/// ```
/// (નોંધ લો કે અનઇંટિલાઇઝ્ડ પૂર્ણાંકોની આસપાસના નિયમો હજુ સુધી આખરી થયા નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી તે ટાળવાની સલાહ આપવામાં આવે છે.)
///
/// તે શીર્ષ પર, યાદ રાખો કે મોટાભાગના પ્રકારોમાં ફક્ત વધારાના આક્રમણકારો હોય છે જેને ફક્ત પ્રકારનાં સ્તરે પ્રારંભિક ગણવામાં આવે છે.
/// ઉદાહરણ તરીકે, `1`-પ્રારંભિક [`Vec<T>`] એ પ્રારંભિક માનવામાં આવે છે (હાલના અમલીકરણ હેઠળ; આ સ્થિર ગેરંટીનું નિર્માણ કરતું નથી) કારણ કે કમ્પાઇલરને તેના વિશેની એકમાત્ર આવશ્યકતા એ છે કે ડેટા પોઇન્ટર બિન-શૂન્ય હોવું આવશ્યક છે.
/// આવા `Vec<T>` બનાવવાનું *તાત્કાલિક* અસ્પષ્ટ વર્તનનું કારણ બનતું નથી, પરંતુ મોટાભાગના સલામત ઓપરેશન્સ (તેને છોડવા સહિત) સાથે અસ્પષ્ટ વર્તનનું કારણ બનશે.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` અનહિતીકૃત ડેટા સાથે વ્યવહાર કરવા માટે અસુરક્ષિત કોડને સક્ષમ બનાવવાની સેવા આપે છે.
/// તે કમ્પાઇલર માટે સંકેત છે જે સૂચવે છે કે અહીં ડેટા *પ્રારંભ* થઈ શકશે નહીં:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // સ્પષ્ટ રૂપે અનહિતીકરણ સંદર્ભ બનાવો.
/// // કમ્પાઇલર જાણે છે કે `MaybeUninit<T>` ની અંદરનો ડેટા અમાન્ય હોઈ શકે છે, અને તેથી આ યુબી નથી:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // તેને માન્ય મૂલ્ય પર સેટ કરો.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // પ્રારંભિક ડેટા કાractો-આને ફક્ત *પછી* યોગ્ય રીતે `x` પ્રારંભ કરી શકાય છે!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// કમ્પાઇલર પછી જાણે છે કે આ કોડ પર કોઈ ખોટી ધારણાઓ અથવા optimપ્ટિમાઇઝેશન નહીં કરે.
///
/// તમે `MaybeUninit<T>` વિશે થોડું `Option<T>` જેવું વિચારી શકો છો પરંતુ કોઈ રન-ટાઇમ ટ્રેકિંગ વિના અને સલામતી ચકાસણી વિના.
///
/// ## out-pointers
///
/// તમે "out-pointers" ને અમલમાં મૂકવા માટે `MaybeUninit<T>` નો ઉપયોગ કરી શકો છો: ફંક્શનમાંથી ડેટા પાછો આપવાને બદલે, પરિણામને આગળ વધારવા માટે તેને કેટલાક (uninitialized) મેમરીમાં પોઇન્ટર આપો.
/// આ ઉપયોગી થઈ શકે છે જ્યારે કlerલરને નિયંત્રણમાં રાખવું મહત્વપૂર્ણ છે કે પરિણામ કેવી રીતે સંગ્રહિત થાય છે તે ફાળવવામાં આવે છે, અને તમે બિનજરૂરી ચાલને ટાળવા માંગો છો.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` જૂની વિષયવસ્તુ છોડતી નથી, જે મહત્વપૂર્ણ છે.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // હવે આપણે જાણીએ છીએ કે `v` પ્રારંભ થયેલ છે!આ પણ ખાતરી કરે છે કે ઝેડવેક્ટર 0 ઝેડ યોગ્ય રીતે છોડી દે છે.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## એરે એલિમેન્ટ-બાય-ઇલિમેન્ટ પ્રારંભ કરી રહ્યું છે
///
/// `MaybeUninit<T>` મોટા એરે તત્વ-દ્વારા-તત્વ પ્રારંભ કરવા માટે ઉપયોગ કરી શકાય છે:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` નો અનઇંટિએટલાઇઝ્ડ એરે બનાવો.
///     // `assume_init` સલામત છે કારણ કે આપણે અહીં જે પ્રકારનો આરંભ કર્યો હોવાનો દાવો કરી રહ્યા છીએ તે `કદાચ યુનિનીટસનો સમૂહ છે, જેને આરંભની જરૂર નથી.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ને છોડવાનું કંઈ જ કરતું નથી.
///     // આમ, `ptr::write` ને બદલે કાચા પોઇન્ટર સોંપણીનો ઉપયોગ કરવાથી જૂનું અનઇંટિલાઇઝ્ડ વેલ્યુ ઘટાડવાનું કારણ નથી.
/////
///     // આ લૂપ દરમ્યાન જો ઝેડ 0 પicનિકિક ઝેડ છે, તો આપણી પાસે મેમરી લિક છે, પરંતુ મેમરી સલામતીનો કોઈ મુદ્દો નથી.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // બધું પ્રારંભ થયેલ છે.
///     // પ્રારંભિક પ્રકારમાં એરે ટ્રાન્સમ્યુટ કરો.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// તમે આંશિક પ્રારંભિક એરે સાથે પણ કામ કરી શકો છો, જે નીચા-સ્તરના ડેટાસ્ટ્રક્ચર્સમાં મળી શકે છે.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` નો અનઇંટિએટલાઇઝ્ડ એરે બનાવો.
/// // `assume_init` સલામત છે કારણ કે આપણે અહીં જે પ્રકારનો આરંભ કર્યો હોવાનો દાવો કરી રહ્યા છીએ તે `કદાચ યુનિનીટસનો સમૂહ છે, જેને આરંભની જરૂર નથી.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // અમે સોંપેલ તત્વોની સંખ્યા ગણો.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // એરેમાંની દરેક આઇટમ માટે, જો આપણે તેને ફાળવેલ હોય તો છોડો.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## સ્ટ્રક્ટ-બાય-ફીલ્ડ સ્ટ્રક્ટનો પ્રારંભ
///
/// ક્ષેત્ર દ્વારા ક્ષેત્રે સ્ટ્રક્ટ્સ ક્ષેત્રને પ્રારંભ કરવા માટે તમે `MaybeUninit<T>` અને [`std::ptr::addr_of_mut`] મેક્રોનો ઉપયોગ કરી શકો છો:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ક્ષેત્ર પ્રારંભ કરી રહ્યું છે
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ક્ષેત્ર પ્રારંભ કરી રહ્યા છીએ જો અહીં panic છે, તો પછી `name` ક્ષેત્રમાં `String` લિક થાય છે.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // બધા ફીલ્ડ્સ આરંભીકૃત છે, તેથી અમે પ્રારંભિક ફૂ મેળવવા માટે `assume_init` ને ક callલ કરીએ છીએ.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` જેવું જ કદ, ગોઠવણી અને એબીઆઇ હોવાની બાંયધરી છે:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// જો કે યાદ રાખો કે * એક `MaybeUninit<T>` ધરાવતો પ્રકાર એ જ લેઆઉટ હોવો જરૂરી નથી;ઝેડ રસ્ટ0 ઝેડ સામાન્ય ગેરેંટીમાં નથી કે `Foo<T>` ના ક્ષેત્રોમાં `Foo<U>` જેવું જ ક્રમ છે જો `T` અને `U` સમાન કદ અને સંરેખણ હોય તો પણ.
///
/// વધુમાં, કારણ કે કોઈપણ બીટ મૂલ્ય `MaybeUninit<T>` માટે માન્ય છે કમ્પાઇલર non-zero/niche-filling optimપ્ટિમાઇઝેશંસ લાગુ કરી શકતું નથી, સંભવિત મોટા કદમાં પરિણમે છે:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// જો `T` એફએફઆઇ-સલામત છે, તો તે પણ `MaybeUninit<T>` છે.
///
/// જ્યારે `MaybeUninit` એ `#[repr(transparent)]` છે (તે દર્શાવે છે કે તે સમાન કદ, સંરેખણ અને એબીઆઈને `T` તરીકેની બાંયધરી આપે છે), આ *અગાઉના કોઈપણ ચેતવણીઓ બદલીને* કરતું નથી.
/// `Option<T>` અને `Option<MaybeUninit<T>>` માં હજી જુદા જુદા કદ હોઈ શકે છે, અને `T` પ્રકારનો ક્ષેત્ર ધરાવતા પ્રકારો એ ક્ષેત્ર `MaybeUninit<T>` કરતા અલગ હોઇ શકે (અને કદવાળા) હોઈ શકે છે.
/// `MaybeUninit` યુનિયન પ્રકાર છે, અને યુનિયનો પર `#[repr(transparent)]` અસ્થિર છે (જુઓ [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// સમય જતાં, યુનિયનો પર `#[repr(transparent)]` ની ચોક્કસ બાંયધરીઓ વિકસિત થઈ શકે છે, અને `MaybeUninit` `#[repr(transparent)]` રહી શકે છે અથવા નહીં.
/// તેણે કહ્યું, `MaybeUninit<T>`*હંમેશાં* ગેરંટી આપે છે કે તેની પાસે સમાન કદ, સંરેખણ અને એબીઆઇ એક્સ X એક્સ છે;તે માત્ર એટલું જ છે કે જે રીતે `MaybeUninit` લાગુ કરે છે તેની ખાતરી આપી છે કે જે વિકસી શકે છે.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// લેંગ આઇટમ જેથી અમે તેમાં અન્ય પ્રકારો લપેટી શકીએ.આ જનરેટર માટે ઉપયોગી છે.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` ને ક callingલ કરતા નથી, અમે જાણી શકતા નથી કે શું તેના માટે પૂરતી આરંભ કરવામાં આવે છે.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// આપેલ મૂલ્યથી પ્રારંભિકરૂપે નવો `MaybeUninit<T>` બનાવે છે.
    /// આ કાર્યના વળતર મૂલ્ય પર [`assume_init`] ને ક callલ કરવું સલામત છે.
    ///
    /// નોંધ લો કે `MaybeUninit<T>` છોડવાનું ક્યારેય `T` ના ડ્રોપ કોડ પર ક willલ કરશે નહીં.
    /// `T` શરૂ થઈ જાય તો તેને છોડી દેવામાં આવે તેની ખાતરી કરવાની તમારી જવાબદારી છે.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// અનહિતીકરણની સ્થિતિમાં એક નવું `MaybeUninit<T>` બનાવે છે.
    ///
    /// નોંધ લો કે `MaybeUninit<T>` છોડવાનું ક્યારેય `T` ના ડ્રોપ કોડ પર ક willલ કરશે નહીં.
    /// `T` શરૂ થઈ જાય તો તેને છોડી દેવામાં આવે તેની ખાતરી કરવાની તમારી જવાબદારી છે.
    ///
    /// કેટલાક ઉદાહરણો માટે [type-level documentation][MaybeUninit] જુઓ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// એક અનિયંત્રિત સ્થિતિમાં, `MaybeUninit<T>` આઇટમ્સની નવી એરે બનાવો.
    ///
    /// Note: ઝેડ 0 ફ્યુચર 0 ઝેડ 0 રસ્ટ0 ઝેડ સંસ્કરણમાં જ્યારે એરે લિટરલ સિન્ટેક્સ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ને મંજૂરી આપે છે ત્યારે આ પદ્ધતિ બિનજરૂરી બની શકે છે.
    ///
    /// નીચેનું ઉદાહરણ પછી `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` નો ઉપયોગ કરી શકશે.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ખરેખર વાંચેલી માહિતીનો (કદાચ નાનો) ટુકડો પાછો આપે છે
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // સલામતી: એક અનહિતીકૃત `[MaybeUninit<_>; LEN]` માન્ય છે.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// એક્સિટિલાઇઝ્ડ સ્થિતિમાં એક નવું `MaybeUninit<T>` બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.તે `T` પર આધારીત છે કે શું તે પહેલાથી યોગ્ય આરંભ માટે બનાવે છે.
    ///
    /// ઉદાહરણ તરીકે, `MaybeUninit<usize>::zeroed()` પ્રારંભ થયેલ છે, પરંતુ `MaybeUninit<&'static i32>::zeroed()` નથી કારણ કે સંદર્ભો નલ હોવા જોઈએ નહીં.
    ///
    /// નોંધ લો કે `MaybeUninit<T>` છોડવાનું ક્યારેય `T` ના ડ્રોપ કોડ પર ક willલ કરશે નહીં.
    /// `T` શરૂ થઈ જાય તો તેને છોડી દેવામાં આવે તેની ખાતરી કરવાની તમારી જવાબદારી છે.
    ///
    /// # Example
    ///
    /// આ ફંક્શનનો સાચો વપરાશ: શૂન્યથી સ્ટ્રક્ટની શરૂઆત, જ્યાં સ્ટ્રક્ટના બધા ફીટ બીટ-પેટર્ન 0 ને વેલ્યુ મૂલ્ય તરીકે રાખી શકે છે.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// આ કાર્યનો *ખોટો* ઉપયોગ: જ્યારે `0` એ પ્રકાર માટે માન્ય બીટ-પેટર્ન નથી ત્યારે `x.zeroed().assume_init()` પર ક callingલ કરવો:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // જોડીની અંદર, અમે એક `NotZero` બનાવીએ છીએ જેમાં માન્ય ભેદભાવ ન હોય.
    /// // આ અસ્પષ્ટ વર્તન છે.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // સલામત: ફાળવેલ મેમરી માટે `u.as_mut_ptr()` પોઇન્ટ.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` નું મૂલ્ય સુયોજિત કરે છે.
    /// આ પાછલા કોઈપણ મૂલ્યને તેને છોડ્યા વિના ફરીથી લખી નાખે છે, તેથી જ્યાં સુધી તમે ડિસ્ટ્રક્ટરને ચલાવવાનું ન છોડતા હો ત્યાં સુધી આ બે વાર ન વાપરવાની કાળજી લો.
    ///
    /// તમારી સુવિધા માટે, આ `self` ની (હવે સુરક્ષિત રૂપે પ્રારંભ કરાયેલ) સામગ્રીનો પરિવર્તનશીલ સંદર્ભ પણ આપે છે.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // સલામતી: અમે હમણાં જ આ મૂલ્યની શરૂઆત કરી.
        unsafe { self.assume_init_mut() }
    }

    /// સમાયેલ મૂલ્યનો નિર્દેશક મેળવે છે.
    /// જ્યાં સુધી `MaybeUninit<T>` પ્રારંભ ન થાય ત્યાં સુધી આ નિર્દેશકમાંથી વાંચવું અથવા તેને સંદર્ભમાં ફેરવવું એ અસ્પષ્ટ વર્તન છે.
    /// મેમરી પર લખવું કે જે આ નિર્દેશક (non-transitively) નિર્દેશ કરે છે તે અસ્પૃષ્ટ વર્તન છે (`UnsafeCell<T>` ની અંદર સિવાય).
    ///
    /// # Examples
    ///
    /// આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` માં સંદર્ભ બનાવો.આ ઠીક છે કારણ કે અમે તેને પ્રારંભ કર્યુ છે.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// આ પદ્ધતિનો *ખોટો* ઉપયોગ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // અમે અનઇંટિએટલાઇઝ્ડ vector નો સંદર્ભ બનાવ્યો છે!આ અસ્પષ્ટ વર્તન છે.⚠️
    /// ```
    ///
    /// (નોંધ લો કે અનઇંટિઆલાઇઝ્ડ ડેટાના સંદર્ભોની આસપાસના નિયમો હજી અંતિમ સ્વરૂપ આપ્યા નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી તે ટાળવાની સલાહ આપવામાં આવે છે.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` અને `ManuallyDrop` એ બંને `repr(transparent)` છે તેથી આપણે નિર્દેશક કાસ્ટ કરી શકીએ.
        self as *const _ as *const T
    }

    /// સમાયેલ મૂલ્ય માટે પરિવર્તનીય નિર્દેશક મેળવે છે.
    /// જ્યાં સુધી `MaybeUninit<T>` પ્રારંભ ન થાય ત્યાં સુધી આ નિર્દેશકમાંથી વાંચવું અથવા તેને સંદર્ભમાં ફેરવવું એ અસ્પષ્ટ વર્તન છે.
    ///
    /// # Examples
    ///
    /// આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` માં સંદર્ભ બનાવો.
    /// // આ ઠીક છે કારણ કે અમે તેને પ્રારંભ કર્યુ છે.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// આ પદ્ધતિનો *ખોટો* ઉપયોગ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // અમે અનઇંટિએટલાઇઝ્ડ vector નો સંદર્ભ બનાવ્યો છે!આ અસ્પષ્ટ વર્તન છે.⚠️
    /// ```
    ///
    /// (નોંધ લો કે અનઇંટિઆલાઇઝ્ડ ડેટાના સંદર્ભોની આસપાસના નિયમો હજી અંતિમ સ્વરૂપ આપ્યા નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી તે ટાળવાની સલાહ આપવામાં આવે છે.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` અને `ManuallyDrop` એ બંને `repr(transparent)` છે તેથી આપણે નિર્દેશક કાસ્ટ કરી શકીએ.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` કન્ટેનરથી મૂલ્ય કાractsે છે.આ ખાતરી કરવાની એક સરસ રીત છે કે ડેટા ડ્રોપ થઈ જશે, કારણ કે પરિણામી `T` એ સામાન્ય ડ્રોપ હેન્ડલિંગને આધિન છે.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક theલ કરનારનું છે.જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    /// [type-level documentation][inv] માં આ આરંભિક ઇનઆરીએંટ વિશે વધુ માહિતી શામેલ છે.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// તે શીર્ષ પર, યાદ રાખો કે મોટાભાગના પ્રકારોમાં ફક્ત વધારાના આક્રમણકારો હોય છે જેને ફક્ત પ્રકારનાં સ્તરે પ્રારંભિક ગણવામાં આવે છે.
    /// ઉદાહરણ તરીકે, `1`-પ્રારંભિક [`Vec<T>`] એ પ્રારંભિક માનવામાં આવે છે (હાલના અમલીકરણ હેઠળ; આ સ્થિર ગેરંટીનું નિર્માણ કરતું નથી) કારણ કે કમ્પાઇલરને તેના વિશેની એકમાત્ર આવશ્યકતા એ છે કે ડેટા પોઇન્ટર બિન-શૂન્ય હોવું આવશ્યક છે.
    ///
    /// આવા `Vec<T>` બનાવવાનું *તાત્કાલિક* અસ્પષ્ટ વર્તનનું કારણ બનતું નથી, પરંતુ મોટાભાગના સલામત ઓપરેશન્સ (તેને છોડવા સહિત) સાથે અસ્પષ્ટ વર્તનનું કારણ બનશે.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// આ પદ્ધતિનો *ખોટો* ઉપયોગ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` હજી સુધી આરંભ કરવામાં આવ્યો ન હતો, તેથી આ છેલ્લી લીટી અનિશ્ચિત વર્તનને કારણે થઈ.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `self` પ્રારંભ થયેલ છે.
        // આનો અર્થ એ પણ છે કે `self` એ `value` વેરિઅન્ટ હોવું આવશ્યક છે.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` કન્ટેનરમાંથી મૂલ્ય વાંચે છે.પરિણામી `T` એ સામાન્ય ડ્રોપ હેન્ડલિંગને આધીન છે.
    ///
    /// જ્યારે પણ શક્ય હોય, તો તેના બદલે [`assume_init`] નો ઉપયોગ કરવો વધુ સારું છે, જે `MaybeUninit<T>` ની સામગ્રીની નકલને અટકાવે છે.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલ કરનારનું છે.જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કલ કરવાથી અનિશ્ચિત વર્તન થાય છે.
    /// [type-level documentation][inv] માં આ આરંભિક ઇનઆરીએંટ વિશે વધુ માહિતી શામેલ છે.
    ///
    /// તદુપરાંત, આ તે જ ડેટાની એક નકલને `MaybeUninit<T>` પાછળ છોડી દે છે.
    /// ડેટાની ઘણી નકલોનો ઉપયોગ કરતી વખતે (`assume_init_read` ને ઘણી વખત ક callingલ કરીને, અથવા પહેલા `assume_init_read` અને પછી [`assume_init`] પર ક callingલ કરીને), તે ખાતરી કરવાની ખાતરી કરવાની તમારી જવાબદારી છે કે ડેટા ખરેખર ડુપ્લિકેટ થઈ શકે.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` છે, તેથી આપણે ઘણી વખત વાંચી શકીએ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` મૂલ્યનું ડુપ્લિકેટ કરવું ઠીક છે, તેથી આપણે ઘણી વખત વાંચી શકીએ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// આ પદ્ધતિનો *ખોટો* ઉપયોગ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // અમે હવે સમાન vector ની બે નકલો બનાવી છે, જે ડબલ-ફ્રી તરફ દોરી જાય છે-જ્યારે તે બંને છોડી દેવામાં આવે છે!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `self` પ્રારંભ થયેલ છે.
        // `self.as_ptr()` માંથી વાંચન સુરક્ષિત છે, કારણ કે `self` પ્રારંભ થવું જોઈએ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// જગ્યાએ સમાયેલ મૂલ્યને છોડો.
    ///
    /// જો તમારી પાસે `MaybeUninit` ની માલિકી છે, તો તમે તેના બદલે [`assume_init`] નો ઉપયોગ કરી શકો છો.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલ કરનારનું છે.જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કલ કરવાથી અનિશ્ચિત વર્તન થાય છે.
    ///
    /// તેની ટોચ પર, `T` પ્રકારનાં બધા અતિરિક્ત આક્રમણકારોએ સંતુષ્ટ થવું આવશ્યક છે, કારણ કે `T` (અથવા તેના સભ્યો) ના `Drop` અમલીકરણ આ પર વિશ્વાસ કરી શકે છે.
    /// ઉદાહરણ તરીકે, `1`-પ્રારંભિક [`Vec<T>`] એ પ્રારંભિક માનવામાં આવે છે (હાલના અમલીકરણ હેઠળ; આ સ્થિર ગેરંટીનું નિર્માણ કરતું નથી) કારણ કે કમ્પાઇલરને તેના વિશેની એકમાત્ર આવશ્યકતા એ છે કે ડેટા પોઇન્ટર બિન-શૂન્ય હોવું આવશ્યક છે.
    ///
    /// આવા `Vec<T>` ને છોડી દેવા છતાં અસ્પષ્ટ વર્તનનું કારણ બનશે.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // સલામતી: ક calલરને બાંયધરી આપવી આવશ્યક છે કે `self` પ્રારંભ થયેલ છે અને
        // `T` ના બધા આક્રમણકારોને સંતોષ આપે છે.
        // જો તેવું હોય તો સ્થળ પર મૂલ્ય છોડી દેવાનું સલામત છે.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// સમાયેલ મૂલ્યનો વહેંચાયેલ સંદર્ભ મળે છે.
    ///
    /// આ ઉપયોગી થઈ શકે છે જ્યારે આપણે `MaybeUninit` ને wantક્સેસ કરવા માગીએ છીએ જે પ્રારંભ થયેલ છે પરંતુ તેની પાસે `MaybeUninit` (`.assume_init()`) નો ઉપયોગ અટકાવતા) ની માલિકી નથી.
    ///
    /// # Safety
    ///
    /// જ્યારે કન્ટેન્ટ હજી સંપૂર્ણ રીતે પ્રારંભ થયેલ નથી ત્યારે આને ક .લ કરવાથી અનિશ્ચિત વર્તન થાય છે: `MaybeUninit<T>` ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલરનું છે.
    ///
    ///
    /// # Examples
    ///
    /// ### આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` પ્રારંભ કરો:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // હવે જ્યારે અમારું `MaybeUninit<_>` પ્રારંભિકરૂપે જાણીતું છે, તો તેનો વહેંચાયેલ સંદર્ભ બનાવવાનું ઠીક છે:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // સલામતી: `x` પ્રારંભ કરવામાં આવ્યો છે.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### આ પદ્ધતિના *ખોટા* ઉપયોગો:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // અમે અનઇંટિએટલાઇઝ્ડ vector નો સંદર્ભ બનાવ્યો છે!આ અસ્પષ્ટ વર્તન છે.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` નો ઉપયોગ કરીને `MaybeUninit` પ્રારંભ કરો:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // એક અનહિતીકૃત `Cell<bool>` નો સંદર્ભ: યુબી!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `self` પ્રારંભ થયેલ છે.
        // આનો અર્થ એ પણ છે કે `self` એ `value` વેરિઅન્ટ હોવું આવશ્યક છે.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// સમાયેલ મૂલ્ય માટે પરિવર્તનીય (unique) સંદર્ભ મેળવે છે.
    ///
    /// આ ઉપયોગી થઈ શકે છે જ્યારે આપણે `MaybeUninit` ને wantક્સેસ કરવા માગીએ છીએ જે પ્રારંભ થયેલ છે પરંતુ તેની પાસે `MaybeUninit` (`.assume_init()`) નો ઉપયોગ અટકાવતા) ની માલિકી નથી.
    ///
    /// # Safety
    ///
    /// જ્યારે કન્ટેન્ટ હજી સંપૂર્ણ રીતે પ્રારંભ થયેલ નથી ત્યારે આને ક .લ કરવાથી અનિશ્ચિત વર્તન થાય છે: `MaybeUninit<T>` ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલરનું છે.
    /// હમણાં પૂરતું, `.assume_init_mut()` નો ઉપયોગ `MaybeUninit` પ્રારંભ કરવા માટે કરી શકાતો નથી.
    ///
    /// # Examples
    ///
    /// ### આ પદ્ધતિનો યોગ્ય ઉપયોગ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ઇનપુટ બફરના *બધા* બાઇટ્સ પ્રારંભ કરે છે.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` પ્રારંભ કરો:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // હવે આપણે જાણીએ છીએ કે `buf` પ્રારંભ કરવામાં આવ્યું છે, તેથી અમે તેનો `.assume_init()` કરી શકીએ.
    /// // જો કે, `.assume_init()` નો ઉપયોગ 2048 બાઇટ્સના `memcpy` ને ટ્રિગર કરી શકે છે.
    /// // અમારા બફરને તેની ક copપિ કર્યા વિના પ્રારંભ કરવામાં આવ્યું છે તેવું કહેવા માટે, અમે `&mut MaybeUninit<[u8; 2048]>` ને `&mut [u8; 2048]` માં અપગ્રેડ કરીએ છીએ:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // સલામતી: `buf` પ્રારંભ કરવામાં આવ્યો છે.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // હવે આપણે સામાન્ય ટુકડા તરીકે `buf` નો ઉપયોગ કરી શકીએ છીએ.
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### આ પદ્ધતિના *ખોટા* ઉપયોગો:
    ///
    /// તમે મૂલ્યને પ્રારંભ કરવા માટે `.assume_init_mut()` નો ઉપયોગ કરી શકતા નથી:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // અમે અનહિતીકૃત `bool` નો (mutable) સંદર્ભ બનાવ્યો છે!
    ///     // આ અસ્પષ્ટ વર્તન છે.⚠️
    /// }
    /// ```
    ///
    /// હમણાં પૂરતું, તમે અનિયંત્રિત બફરમાં [`Read`] કરી શકતા નથી:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) અનઇંટિઆલાઇઝ્ડ મેમરીનો સંદર્ભ!
    ///                             // આ અસ્પષ્ટ વર્તન છે.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// અથવા તમે ફીલ્ડ-બાય-ફીલ્ડ ક્રમિક પ્રારંભિક કરવા માટે સીધી ફીલ્ડ accessક્સેસનો ઉપયોગ કરી શકતા નથી:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) અનઇંટિઆલાઇઝ્ડ મેમરીનો સંદર્ભ!
    ///                  // આ અસ્પષ્ટ વર્તન છે.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) અનઇંટિઆલાઇઝ્ડ મેમરીનો સંદર્ભ!
    ///                  // આ અસ્પષ્ટ વર્તન છે.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): આપણે હાલમાં ઉપરોક્ત ખોટા હોવા પર આધાર રાખીએ છીએ, એટલે કે આપણી પાસે અનિટિટાઈઝ્ડ ડેટા (દા.ત., `libcore/fmt/float.rs` માં) નો સંદર્ભો છે.
    // સ્થિરતા પહેલાં આપણે નિયમો વિશે અંતિમ નિર્ણય લેવો જોઈએ.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `self` પ્રારંભ થયેલ છે.
        // આનો અર્થ એ પણ છે કે `self` એ `value` વેરિઅન્ટ હોવું આવશ્યક છે.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` કન્ટેનરની એરેથી મૂલ્યો કાractsે છે.
    ///
    /// # Safety
    ///
    /// ક guaranteeલરની ખાતરી છે કે એરેના બધા ઘટકો પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપી છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // સલામતી: હવે સલામત છે કારણ કે આપણે બધા તત્વો પ્રારંભ કર્યા છે
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * કlerલર ગેરેંટી આપે છે કે એરેના બધા તત્વો પ્રારંભ છે
        // * `MaybeUninit<T>` અને ટી સમાન લેઆઉટ ધરાવવાની ખાતરી આપી છે
        // * કદાચ યુનિન્ટ ડ્રોપ કરતું નથી, તેથી ત્યાં કોઈ ડબલ-ફ્રી નથી અને આમ રૂપાંતર સલામત છે
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ધારી રહ્યા છીએ કે બધા તત્વો પ્રારંભ થઈ ગયા છે, તેમને એક કટકો મેળવો.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` તત્વો ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કલ કરવાથી અનિશ્ચિત વર્તન થાય છે.
    ///
    /// વધુ વિગતો અને ઉદાહરણો માટે [`assume_init_ref`] જુઓ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // સલામતી: ક00લર તેની બાંયધરી આપતું હોવાથી, `*const [T]` પર કાસ્ટ કાપી નાખવું સલામત છે
        // `slice` પ્રારંભ થયેલ છે, અને-મેબે યુનિટીટ `T` જેવું જ લેઆઉટ ધરાવવાની ખાતરી આપી છે.
        // પ્રાપ્ત કરેલ નિર્દેશક માન્ય છે કારણ કે તે `slice` ની માલિકીની મેમરીનો સંદર્ભ આપે છે જે એક સંદર્ભ છે અને આમ તે વાંચવા માટે માન્ય હોવાની બાંયધરી છે.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// ધારી રહ્યા છીએ કે બધા તત્વો પ્રારંભ થયા છે, તેમને પરિવર્તનીય સ્લાઇસ મેળવો.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` તત્વો ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે કlerલ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કલ કરવાથી અનિશ્ચિત વર્તન થાય છે.
    ///
    /// વધુ વિગતો અને ઉદાહરણો માટે [`assume_init_mut`] જુઓ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // સલામતી: `slice_get_ref` માટેની સલામતી નોંધો જેવી જ, પરંતુ અમારી પાસે એ
        // પરિવર્તનશીલ સંદર્ભ કે જે લેખકો માટે માન્ય હોવાની બાંયધરી પણ છે.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// એરેના પ્રથમ તત્વનો નિર્દેશક મેળવે છે.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// એરેના પ્રથમ તત્વ માટે પરિવર્તનીય પોઇન્ટર મેળવે છે.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` થી `this` પર તત્વોની કiesપિ કરે છે, `this` ના હાલના મૂળ વિષયવસ્તુનો પરિવર્તનશીલ સંદર્ભ પાછો આપે છે.
    ///
    /// જો `T`, `Copy` લાગુ કરતું નથી, તો [`write_slice_cloned`] નો ઉપયોગ કરો
    ///
    /// આ [`slice::copy_from_slice`] જેવું જ છે.
    ///
    /// # Panics
    ///
    /// જો આ કાપી નાંખ્યું જુદી જુદી લંબાઈમાં હોય તો આ કાર્ય panic કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // સલામતી: અમે ફક્ત વધારાની ક્ષમતામાં લેનના તમામ ઘટકોની નકલ કરી છે
    /// // Vec ના પહેલા src.len() તત્વો હવે માન્ય છે.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // સલામતી: &[ટી] અને&[કદાચ યુનિનીટ<T>] સમાન લેઆઉટ છે
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // સલામતી: માન્ય તત્વોની હમણાં જ `this` માં કiedપિ કરવામાં આવી છે જેથી તેની શોધ કરવામાં આવે
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` થી `this` સુધીના તત્વોને ક્લોન કરે છે, હવે `this` ના મૂળભૂત સમાવિષ્ટોનો પરિવર્તનશીલ સંદર્ભ પાછો આપે છે.
    /// કોઈપણ પહેલેથી જ શોધાયેલા તત્વો છોડવામાં આવશે નહીં.
    ///
    /// જો `T`, `Copy` લાગુ કરે છે, તો [`write_slice`] નો ઉપયોગ કરો
    ///
    /// આ [`slice::clone_from_slice`] જેવું જ છે પરંતુ હાલના તત્વોને છોડતો નથી.
    ///
    /// # Panics
    ///
    /// જો આ કાપી નાંખ્યું જુદી જુદી લંબાઈમાં હોય અથવા જો `Clone` panics અમલીકરણ કરવામાં આવે તો આ કાર્ય panic કરશે.
    ///
    /// જો ત્યાં panic છે, તો પહેલાથી ક્લોન કરેલ તત્વો છોડી દેવામાં આવશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // સલામતી: અમે હમણાં જ વધારાની ક્ષમતામાં લેનના તમામ ઘટકોને ક્લોન કર્યા છે
    /// // Vec ના પહેલા src.len() તત્વો હવે માન્ય છે.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ક_પિ_ફ્રોમ_સ્લાઇસથી વિપરિત, આ સ્લાઈસ પર ક્લોન_ફ્રોમ_સ્લાઇસ ક .લ કરશે નહીં કારણ કે `MaybeUninit<T: Clone>` ક્લોન લાગુ કરતું નથી.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // સલામતી: આ કાચી કટકામાં ફક્ત પ્રારંભિક containબ્જેક્ટ્સ હશે
                // તેથી જ, તેને છોડવાની મંજૂરી છે.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: આપણે તેમને સમાન લંબાઈ પર સ્પષ્ટ રીતે કાપી નાખવાની જરૂર છે
        // મર્યાદાની ચકાસણી માટે, અને izerપ્ટિમાઇઝર સરળ કેસો (ઉદાહરણ તરીકે ટી= u8) માટે મેમ્પી બનાવશે.
        //
        let len = this.len();
        let src = &src[..len];

        // રક્ષકની આવશ્યકતા છે ક્લોન દરમિયાન b/c panic થઈ શકે છે
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // સલામતી: માન્ય તત્વો હમણાં જ `this` માં લખાઈ ગયા છે જેથી તે શોધવામાં આવે
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}