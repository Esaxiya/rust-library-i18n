use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Automatically T` ના ડિસ્ટ્રક્ટરને આપમેળે ક fromલ કરવાથી કમ્પાઇલરને અટકાવવા માટેનો રેપર.
/// આ રેપર 0-કિંમતનો છે.
///
/// `ManuallyDrop<T>` `T` જેવા સમાન લેઆઉટ optimપ્ટિમાઇઝેશનને આધીન છે.
/// પરિણામે, કમ્પાઇલર તેની સમાવિષ્ટો વિશે કરે છે તેવી ધારણાઓ પર તેની * કોઈ અસર નથી.
/// ઉદાહરણ તરીકે, [`mem::zeroed`] સાથે `ManuallyDrop<&mut T>` પ્રારંભ કરવું એ અસ્પષ્ટ વર્તન છે.
/// જો તમારે અનિટિટેલાઇઝ્ડ ડેટાને હેન્ડલ કરવાની જરૂર હોય, તો તેના બદલે [`MaybeUninit<T>`] નો ઉપયોગ કરો.
///
/// નોંધ લો કે `ManuallyDrop<T>` ની અંદરના મૂલ્યને .ક્સેસ કરવું સલામત છે.
/// આનો અર્થ એ કે `ManuallyDrop<T>` જેની સામગ્રીને છોડી દેવામાં આવી છે તે જાહેર સલામત API દ્વારા ખુલ્લી ન હોવી જોઈએ.
/// અનુરૂપ, `ManuallyDrop::drop` અસુરક્ષિત છે.
///
/// # `ManuallyDrop` અને ડ્રોપ ઓર્ડર.
///
/// ઝેડ 0 રસ્ટ0 ઝેડમાં કિંમતોની સારી રીતે વ્યાખ્યાયિત [drop order] છે.
/// ખાતરી કરવા માટે કે ક્ષેત્રો અથવા સ્થાનિક સ્થાનોને કોઈ વિશિષ્ટ ક્રમમાં છોડવામાં આવ્યા છે, ઘોષણાઓને ફરીથી ગોઠવો કે ગર્ભિત ડ્રોપ ઓર્ડર યોગ્ય છે.
///
/// ડ્રોપ ઓર્ડરને નિયંત્રિત કરવા માટે `ManuallyDrop` નો ઉપયોગ કરવો શક્ય છે, પરંતુ આને અસુરક્ષિત કોડની જરૂર છે અને અનઇન્ડિંડિંગની હાજરીમાં યોગ્ય રીતે કરવું મુશ્કેલ છે.
///
///
/// ઉદાહરણ તરીકે, જો તમે ખાતરી કરવા માંગો છો કે અન્ય પછી કોઈ ચોક્કસ ક્ષેત્ર છોડી દેવામાં આવે છે, તો તેને સ્ટ્રક્ટનું છેલ્લું ક્ષેત્ર બનાવો:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` પછી છોડી દેવામાં આવશે.
///     // ઝેડ 0 રસ્ટ0 ઝેડ ખાતરી આપે છે કે ઘોષણાના ક્રમમાં ક્ષેત્રોને છોડી દેવામાં આવે છે.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// મેન્યુઅલી ડ્રોપ થવાનું મૂલ્ય વીંટો.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // તમે હજી પણ મૂલ્ય પર સલામત રીતે સંચાલિત કરી શકો છો
    /// assert_eq!(*x, "Hello");
    /// // પરંતુ `Drop` અહીં ચલાવવામાં આવશે નહીં
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` કન્ટેનરથી મૂલ્ય કાractsે છે.
    ///
    /// આનાથી મૂલ્ય ફરીથી ઘટાડવાની મંજૂરી મળે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // આ `Box` ઘટાડે છે.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` કન્ટેનરમાંથી મૂલ્ય લે છે.
    ///
    /// આ પદ્ધતિ મુખ્યત્વે ડ્રોપમાં મૂલ્યોને ખસેડવા માટે બનાવાયેલ છે.
    /// મૂલ્યને મેન્યુઅલી મૂકવા માટે [`ManuallyDrop::drop`] નો ઉપયોગ કરવાને બદલે, તમે મૂલ્ય લેવા માટે આ પદ્ધતિનો ઉપયોગ કરી શકો છો અને જો ઇચ્છિત હો તો તેનો ઉપયોગ કરી શકો છો.
    ///
    /// જ્યારે પણ શક્ય હોય, તો તેના બદલે [`into_inner`][`ManuallyDrop::into_inner`] નો ઉપયોગ કરવો વધુ સારું છે, જે `ManuallyDrop<T>` ની સામગ્રીની નકલને અટકાવે છે.
    ///
    ///
    /// # Safety
    ///
    /// આ કાર્ય આગળના વપરાશને અટકાવ્યા વિના સમાયેલ મૂલ્યને અર્થપૂર્ણ રીતે બહાર કા ,ે છે, આ કન્ટેનરની સ્થિતિને યથાવત્ રાખીને.
    /// આ `ManuallyDrop` ફરીથી ઉપયોગમાં લેવાશે નહીં તેની ખાતરી કરવાની જવાબદારી તમારી છે.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // સલામતી: અમે સંદર્ભમાંથી વાંચીએ છીએ, જે ખાતરી આપી છે
        // વાંચવા માટે માન્ય છે.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// જાતે સમાયેલ મૂલ્યને ડ્રોપ કરે છે.આ સમાયેલ મૂલ્યના નિર્દેશક સાથે [`ptr::drop_in_place`] ને ક callingલ કરવા બરાબર છે.
    /// જેમ કે, જ્યાં સુધી સમાયેલ મૂલ્ય પેક્ડ સ્ટ્રક્ટ ન હોય ત્યાં સુધી ડિસ્ટ્રક્ટરને મૂલ્ય ખસેડ્યા વિના તે જગ્યાએ કહેવાશે, અને તેથી [pinned] ડેટાને સુરક્ષિત રીતે છોડવા માટે થઈ શકે છે.
    ///
    /// જો તમારી પાસે મૂલ્યની માલિકી છે, તો તમે તેના બદલે [`ManuallyDrop::into_inner`] નો ઉપયોગ કરી શકો છો.
    ///
    /// # Safety
    ///
    /// આ કાર્ય સમાયેલ મૂલ્યના વિનાશકને ચલાવે છે.
    /// ડિસ્ટ્રિક્ટર પોતે જ કરેલા ફેરફારો સિવાય, મેમરી યથાવત્ છે, અને જ્યાં સુધી કમ્પાઇલરનો સવાલ છે તે હજી પણ બીટ-પેટર્ન ધરાવે છે જે `T` પ્રકાર માટે માન્ય છે.
    ///
    ///
    /// જો કે, આ "zombie" મૂલ્યને સલામત કોડમાં ખુલ્લું મૂકવું જોઈએ નહીં, અને આ ફંકશનને એક કરતા વધુ વખત કહેવા જોઈએ નહીં.
    /// કોઈ મૂલ્યને છોડવામાં આવ્યા પછી તેનો ઉપયોગ કરવા અથવા મૂલ્યને ઘણી વખત છોડવા માટે, અનિશ્ચિત વર્તન (`drop` શું કરે છે તેના આધારે) થઈ શકે છે.
    /// આ સામાન્ય રીતે ટાઇપ સિસ્ટમ દ્વારા અટકાવવામાં આવે છે, પરંતુ `ManuallyDrop` ના વપરાશકર્તાઓએ કમ્પાઇલરની સહાયતા વિના તે બાંયધરીઓને સમર્થન આપવું જોઈએ.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // સલામતી: આપણે પરિવર્તનશીલ સંદર્ભ દ્વારા નિર્દેશિત મૂલ્યને છોડી દઈએ છીએ
        // જે લેખકો માટે માન્ય હોવાની બાંયધરી છે.
        // તે ખાતરી કરવા માટે ક isn'tલર પર છે કે `slot` ફરીથી છોડવામાં આવશે નહીં.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}