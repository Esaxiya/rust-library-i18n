//! મેમરી સાથે કામ કરવા માટેના મૂળભૂત કાર્યો.
//!
//! આ મોડ્યુલમાં પ્રકારોના કદ અને ગોઠવણી માટે, મેમરીને પ્રારંભિક અને ચાલાકી માટેના કાર્યો શામેલ છે.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **તેના વિનાશક** ચલાવ્યા વિના ** મૂલ્ય વિશે માલિકી અને "forgets" લે છે.
///
/// કોઈપણ સંસાધનો જે મૂલ્યનું સંચાલન કરે છે, જેમ કે apગલાની મેમરી અથવા ફાઇલ હેન્ડલ, પહોંચી શકાય તેવી સ્થિતિમાં કાયમ માટે લંબાય છે.જો કે, તે બાંહેધરી આપતું નથી કે આ મેમરી તરફના પોઇંટર માન્ય રહેશે.
///
/// * જો તમે મેમરીને લીક કરવા માંગો છો, તો [`Box::leak`] જુઓ.
/// * જો તમે મેમરીનો કાચો નિર્દેશક મેળવવા માંગતા હો, તો [`Box::into_raw`] જુઓ.
/// * જો તમે કોઈ મૂલ્યનો યોગ્ય રીતે નિકાલ કરવા માંગતા હો, તો તેના ડિસ્ટ્રક્ટરને ચલાવો, [`mem::drop`] જુઓ.
///
/// # Safety
///
/// `forget` `unsafe` તરીકે ચિહ્નિત થયેલ નથી, કારણ કે Rust ની સલામતી બાંયધરીમાં બાંયધરી શામેલ નથી કે વિનાશક હંમેશા ચાલશે.
/// ઉદાહરણ તરીકે, પ્રોગ્રામ, [`Rc`][rc] નો ઉપયોગ કરીને એક સંદર્ભ ચક્ર બનાવી શકે છે અથવા ડિસ્ટ્રક્ટર્સ ચલાવ્યા વગર બહાર નીકળવા માટે [`process::exit`][exit] ને ક callલ કરી શકે છે.
/// આમ, સલામત કોડથી `mem::forget` ને મંજૂરી આપવી એ Rust ની સલામતી બાંયધરીને મૂળભૂત રૂપે બદલતી નથી.
///
/// તે કહ્યું, મેમરી અથવા I/O objectsબ્જેક્ટ્સ જેવા સંસાધનોને લીક કરવું એ સામાન્ય રીતે અનિચ્છનીય છે.
/// જરૂરિયાત એફએફઆઈ અથવા અસુરક્ષિત કોડ માટેના કેટલાક વિશિષ્ટ ઉપયોગના કેસોમાં આવે છે, પરંતુ તે પછી પણ, [`ManuallyDrop`] સામાન્ય રીતે પસંદ કરવામાં આવે છે.
///
/// કારણ કે કોઈ મૂલ્ય ભૂલી જવાની મંજૂરી છે, તેથી તમે લખો છો તે કોઈપણ `unsafe` કોડને આ સંભાવના માટે મંજૂરી આપવી આવશ્યક છે.તમે કોઈ મૂલ્ય પરત કરી શકતા નથી અને અપેક્ષા કરી શકો છો કે કlerલર આવશ્યકપણે મૂલ્યનો ડિસ્ટ્રક્ટર ચલાવશે.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` નો કેનોનિકલ સલામત ઉપયોગ, `Drop` trait દ્વારા અમલમાં મુકાયેલા મૂલ્યના ડિસ્ટ્રક્ટરને અટકાવવાનો છે.ઉદાહરણ તરીકે, આ એક `File` લિક કરશે, એટલે કે
/// ચલ દ્વારા લેવામાં આવેલી જગ્યા પર ફરીથી દાવો કરો પરંતુ અંતર્ગત સિસ્ટમ સ્રોતને ક્યારેય બંધ ન કરો:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// આ ઉપયોગી છે જ્યારે અંતર્ગત સંસાધનની માલિકી અગાઉ ઝેડ રસ્ટ0 ઝેડની બહારના કોડમાં સ્થાનાંતરિત કરવામાં આવી હતી, ઉદાહરણ તરીકે કાચી ફાઇલ વર્ણનકર્તાને સી કોડમાં સ્થાનાંતરિત કરીને.
///
/// # `ManuallyDrop` સાથે સંબંધ
///
/// જ્યારે `mem::forget` નો ઉપયોગ *મેમરી* માલિકીના સ્થાનાંતરણ માટે પણ થઈ શકે છે, આમ કરવાથી ભૂલ થાય છે.
/// [`ManuallyDrop`] તેના બદલે ઉપયોગ કરવો જોઇએ.ઉદાહરણ તરીકે, આ કોડ ધ્યાનમાં લો:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` ની સામગ્રીનો ઉપયોગ કરીને એક `String` બનાવો
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // લીક `v` કારણ કે તેની મેમરી હવે `s` દ્વારા સંચાલિત છે
/// mem::forget(v);  // ભૂલ, વી અમાન્ય છે અને ફંક્શનમાં પસાર થવું જોઈએ નહીં
/// assert_eq!(s, "Az");
/// // `s` ગર્ભિતરૂપે મૂકવામાં આવે છે અને તેની મેમરી અધોગતિ.
/// ```
///
/// ઉપરોક્ત ઉદાહરણ સાથે બે મુદ્દાઓ છે:
///
/// * જો `String` ના નિર્માણ અને `mem::forget()` ના વિનંતી વચ્ચે વધુ કોડ ઉમેરવામાં આવ્યો હોય, તો તે અંદરની panic એ ડબલ ફ્રીનું કારણ બનશે કારણ કે સમાન મેમરી `v` અને `s` બંને દ્વારા નિયંત્રિત છે.
/// * `v.as_mut_ptr()` ને ક callingલ કર્યા પછી અને ડેટાની માલિકીને `s` પરિવહન કર્યા પછી, `v` મૂલ્ય અમાન્ય છે.
/// જ્યારે કિંમત ફક્ત `mem::forget` (જેનું નિરીક્ષણ કરશે નહીં) માં ખસેડવામાં આવે છે, ત્યારે પણ કેટલાક પ્રકારોની તેમના મૂલ્યો પર કડક આવશ્યકતાઓ હોય છે જે ઝૂલતા હોય ત્યારે અથવા તેને માલિકીની ન હોય ત્યારે અમાન્ય બનાવે છે.
/// કોઈપણ રીતે અમાન્ય મૂલ્યોનો ઉપયોગ કરીને, તેમને તેમને પસાર કરવા અથવા કાર્યોથી પરત કરવા સહિત, અસ્પષ્ટ વર્તન રચે છે અને કમ્પાઇલર દ્વારા કરવામાં આવેલી ધારણાઓને તોડી શકે છે.
///
/// `ManuallyDrop` પર સ્વિચ કરવું એ બંને સમસ્યાઓ ટાળે છે:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // અમે `v` ને તેના કાચા ભાગોમાં ડિસએસેમ્બલ કરતા પહેલા, ખાતરી કરો કે તે ઘટી ગયું નથી!
/////
/// let mut v = ManuallyDrop::new(v);
/// // હવે `v` ડિસએસેમ્બલ કરો.આ કામગીરી panic કરી શકતી નથી, તેથી લિક થઈ શકતી નથી.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // અંતે, એક `String` બનાવો.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ગર્ભિતરૂપે મૂકવામાં આવે છે અને તેની મેમરી અધોગતિ.
/// ```
///
/// `ManuallyDrop` સખ્તાઇથી ડબલ-ફ્રી અટકાવે છે કારણ કે અમે બીજું કંઈ પણ કરતા પહેલા ડિસ્ટ્રક્ટરને અક્ષમ કરીએ છીએ.
/// `mem::forget()` આને મંજૂરી આપતું નથી કારણ કે તે તેની દલીલનો વપરાશ કરે છે, અમને `v` માંથી જે કંઈપણ જોઈએ છે તે કા ext્યા પછી જ તેને ક callલ કરવાની ફરજ પાડે છે.
/// જો ઝેડ0 પicનિક0 ઝેડ `ManuallyDrop` ના નિર્માણ અને સ્ટ્રિંગ બનાવવા (જે બતાવ્યા પ્રમાણે કોડમાં થઈ શકતું નથી) વચ્ચે રજૂ કરવામાં આવ્યું હતું, તો તે લીક થઈ શકે છે અને ડબલ ફ્રી નહીં.
/// બીજા શબ્દોમાં કહીએ તો, `ManuallyDrop` (ડબલ) ડ્રોપિંગની બાજુએ ખોટી જગ્યાએ લિકની બાજુએ ભૂલ કરે છે.
///
/// ઉપરાંત, `ManuallyDrop` `s` પર માલિકી સ્થાનાંતરિત કર્યા પછી "touch" `v` રાખવાથી રોકે છે-તેના વિનાશક ચલાવ્યા વિના નિકાલ કરવા માટે `v` સાથે વાતચીત કરવાનું અંતિમ પગલું સંપૂર્ણપણે ટાળી શકાય છે.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] ની જેમ, પણ અસૂચિત મૂલ્યો પણ સ્વીકારે છે.
///
/// જ્યારે `unsized_locals` સુવિધા સ્થિર થાય છે ત્યારે આ ફંક્શન દૂર કરવાના હેતુથી માત્ર એક ચીમ છે.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// બાઇટ્સમાંના પ્રકારનું કદ આપે છે.
///
/// વધુ વિશિષ્ટ રીતે, આ ગોઠવણી પેડિંગ સહિતના આઇટમ પ્રકાર સાથે એરેમાં ક્રમિક તત્વો વચ્ચેનું આ setફસેટ છે.
///
/// આમ, કોઈપણ પ્રકારનાં `T` અને લંબાઈ `n` માટે, `[T; n]` એ `n * size_of::<T>()` નું કદ ધરાવે છે.
///
/// સામાન્ય રીતે, સંકલનમાં કોઈ પ્રકારનું કદ સ્થિર હોતું નથી, પરંતુ વિશિષ્ટ પ્રકારો જેવા કે આદિમ હોય છે.
///
/// નીચેનું કોષ્ટક આદિમ માટે કદ આપે છે.
///
/// પ્રકાર |કદ_કોમ: :\<Type>()
/// ---- | ---------------
/// () |0 ઝેડ 0 બૂલ0 ઝેડ |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 આઇ 128 |16 f32 |4 f64 |8 ચાર |4
///
/// વળી, `usize` અને `isize` સમાન કદ ધરાવે છે.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` અને `Option<Box<T>>` આ પ્રકારો એકસરખા કદના છે.
/// જો `T` કદનું છે, તો તે તમામ પ્રકારના `usize` જેટલા કદના છે.
///
/// પોઇન્ટરનું પરિવર્તન તેના કદમાં ફેરફાર કરતું નથી.જેમ કે, `&T` અને `&mut T` સમાન કદ ધરાવે છે.
/// તેવી જ રીતે `*const T` અને `* mut T` માટે.
///
/// # `#[repr(C)]` આઇટમ્સનું કદ
///
/// આઇટમ્સ માટેના `C` પ્રતિનિધિત્વમાં એક વ્યાખ્યાયિત લેઆઉટ છે.
/// આ લેઆઉટ સાથે, જ્યાં સુધી બધા ક્ષેત્રોમાં સ્થિર કદ હોય ત્યાં સુધી આઇટમ્સનું કદ પણ સ્થિર હોય છે.
///
/// ## સ્ટ્રક્ટ્સનું કદ
///
/// `structs` માટે, કદ નીચેના એલ્ગોરિધમ દ્વારા નક્કી કરવામાં આવે છે.
///
/// ઘોષણાના હુકમ દ્વારા આદેશિત સ્ટ્રક્ટના દરેક ક્ષેત્ર માટે:
///
/// 1. ક્ષેત્રનું કદ ઉમેરો.
/// 2. હાલના કદને આગલા ક્ષેત્રના [alignment] ની નજીકના બહુવિધમાં ફેરવો.
///
/// અંતે, સ્ટ્ર ofક્ટના કદને તેના [alignment] ની નજીકના બહુવિધમાં ગોળાકાર કરો.
/// સ્ટ્રક્ટની ગોઠવણી એ તેના તમામ ક્ષેત્રોમાં સામાન્ય રીતે સૌથી મોટી ગોઠવણી હોય છે;`repr(align(N))` ના ઉપયોગથી આ બદલી શકાય છે.
///
/// `C` થી વિપરીત, શૂન્ય કદના સ્ટ્રક્ટ્સ એક બાઇટના કદ સુધી ગોળાકાર નથી.
///
/// ## એનોમ્સનું કદ
///
/// ભેદ સિવાય અન્ય કોઈ ડેટા ન ધરાવતા એણમ્સના પ્લેટફોર્મ પર સી એન્નમ્સ જેટલું કદ હોય છે જેના માટે તેઓ સંકલન કરે છે.
///
/// ## યુનિયનોનું કદ
///
/// યુનિયનનું કદ તેના સૌથી મોટા ક્ષેત્રનું કદ છે.
///
/// `C` થી વિપરીત, શૂન્ય કદના યુનિયન કદમાં એક બાઇટ સુધી ગોળાકાર નથી.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // કેટલાક આદિમ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // કેટલાક એરે
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // પોઇન્ટર કદ સમાનતા
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` નો ઉપયોગ કરીને.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // પ્રથમ ક્ષેત્રનું કદ 1 છે, તેથી કદમાં 1 ઉમેરો.કદ 1 છે.
/// // બીજા ક્ષેત્રની ગોઠવણી 2 છે, તેથી ગાદી માટે 1 કદમાં ઉમેરો.કદ 2 છે.
/// // બીજા ક્ષેત્રનું કદ 2 છે, તેથી કદમાં 2 ઉમેરો.કદ 4 છે.
/// // ત્રીજા ક્ષેત્રની ગોઠવણી 1 છે, તેથી ગાદી માટેના કદમાં 0 ઉમેરો.કદ 4 છે.
/// // ત્રીજા ક્ષેત્રનું કદ 1 છે, તેથી કદમાં 1 ઉમેરો.કદ 5 છે.
/// // છેલ્લે, સ્ટ્રક્ટની ગોઠવણી 2 છે (કારણ કે તેના ક્ષેત્રો વચ્ચેનો સૌથી મોટો સંરેખણ 2 છે), તેથી ગાદી માટેના કદમાં 1 ઉમેરો.
/// // કદ 6 છે.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // ટુપલ સ્ટ્રક્ટ્સ સમાન નિયમોનું પાલન કરે છે.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // નોંધો કે ક્ષેત્રોને ફરીથી ગોઠવવાથી કદ ઓછું થઈ શકે છે.
/// // અમે `second` પહેલાં `third` મૂકીને બંને પેડિંગ બાઇટ્સને દૂર કરી શકીએ છીએ.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // યુનિયન કદ એ સૌથી મોટા ક્ષેત્રનું કદ છે.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// બાઇટ્સમાં પોઇંટ-ટુ મૂલ્યનું કદ આપે છે.
///
/// આ સામાન્ય રીતે `size_of::<T>()` જેવું જ હોય છે.
/// તેમછતાં, જ્યારે `T`*નો* કોઈ આંકડાકીય રીતે જાણીતો કદ નથી, દા.ત., સ્લાઇસ [`[T]`][slice] અથવા [trait object], પછી ગતિશીલ રીતે જાણીતા કદ મેળવવા માટે `size_of_val` નો ઉપયોગ કરી શકાય છે.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // સલામતી: `val` એ એક સંદર્ભ છે, તેથી તે માન્ય કાચો નિર્દેશક છે
    unsafe { intrinsics::size_of_val(val) }
}

/// બાઇટ્સમાં પોઇંટ-ટુ મૂલ્યનું કદ આપે છે.
///
/// આ સામાન્ય રીતે `size_of::<T>()` જેવું જ હોય છે.જો કે, જ્યારે `T` * નો કોઈ આંકડાકીય રીતે જાણીતો કદ નથી, દા.ત., સ્લાઇસ [`[T]`][slice] અથવા [trait object], પછી ગતિશીલ રીતે જાણીતા કદ મેળવવા માટે `size_of_val_raw` નો ઉપયોગ કરી શકાય છે.
///
/// # Safety
///
/// જો નીચેની શરતો હોલ્ડ કરે છે તો આ ફંક્શન ફક્ત ક callલ કરવા માટે સલામત છે:
///
/// - જો `T` એ `Sized` છે, તો આ કાર્ય ક callલ કરવા માટે હંમેશા સલામત છે.
/// - જો `T` ની અનઇસીઝ્ડ પૂંછડી છે:
///     - એક X01 એક્સ, પછી સ્લાઇસ પૂંછડીની લંબાઈ પ્રારંભિક પૂર્ણાંક હોવી આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
///     - એક X01 એક્સ, પછી પોઇન્ટરનો વtટેબલ ભાગ અનઇઝાઇઝિંગ જબરદસ્તી દ્વારા હસ્તગત માન્ય વtટેબલ તરફ નિર્દેશ કરવો આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
///
///     - એક (unstable) [extern type], તો પછી આ ફંક્શન હંમેશાં ક callલ કરવા માટે સલામત છે, પરંતુ બાહ્ય પ્રકારનું લેઆઉટ જાણીતું ન હોવાથી, panic અથવા અન્યથા ખોટી કિંમત પરત કરી શકે છે.
///     બાહ્ય પ્રકારનાં પૂંછડીઓવાળા પ્રકારનાં સંદર્ભમાં આ [`size_of_val`] જેવું જ વર્તન છે.
///     - નહિંતર, રૂ conિચુસ્ત રીતે આ ફંક્શનને ક .લ કરવાની મંજૂરી નથી.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // સલામતી: કlerલરને માન્ય કાચો પોઇન્ટર પ્રદાન કરવું આવશ્યક છે
    unsafe { intrinsics::size_of_val(val) }
}

/// [એબીઆઇ] એક પ્રકારનાં ઓછામાં ઓછા ગોઠવણીની આવશ્યકતા આપે છે.
///
/// પ્રકાર `T` ના મૂલ્યનો દરેક સંદર્ભ આ સંખ્યાના બહુવિધ હોવા જોઈએ.
///
/// સ્ટ્રક્ટ ફીલ્ડ્સ માટે આ ગોઠવણી છે.તે પસંદ કરેલા ગોઠવણી કરતા નાનું હોઈ શકે છે.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` નિર્દેશ કરે છે તે મૂલ્યના પ્રકારનું [એબીઆઇ] જરૂરી ન્યુનત્તમ ગોઠવણી આપે છે.
///
/// પ્રકાર `T` ના મૂલ્યનો દરેક સંદર્ભ આ સંખ્યાના બહુવિધ હોવા જોઈએ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // સલામતી: વાલ એક સંદર્ભ છે, તેથી તે માન્ય કાચો નિર્દેશક છે
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [એબીઆઇ] એક પ્રકારનાં ઓછામાં ઓછા ગોઠવણીની આવશ્યકતા આપે છે.
///
/// પ્રકાર `T` ના મૂલ્યનો દરેક સંદર્ભ આ સંખ્યાના બહુવિધ હોવા જોઈએ.
///
/// સ્ટ્રક્ટ ફીલ્ડ્સ માટે આ ગોઠવણી છે.તે પસંદ કરેલા ગોઠવણી કરતા નાનું હોઈ શકે છે.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` નિર્દેશ કરે છે તે મૂલ્યના પ્રકારનું [એબીઆઇ] જરૂરી ન્યુનત્તમ ગોઠવણી આપે છે.
///
/// પ્રકાર `T` ના મૂલ્યનો દરેક સંદર્ભ આ સંખ્યાના બહુવિધ હોવા જોઈએ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // સલામતી: વાલ એક સંદર્ભ છે, તેથી તે માન્ય કાચો નિર્દેશક છે
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` નિર્દેશ કરે છે તે મૂલ્યના પ્રકારનું [એબીઆઇ] જરૂરી ન્યુનત્તમ ગોઠવણી આપે છે.
///
/// પ્રકાર `T` ના મૂલ્યનો દરેક સંદર્ભ આ સંખ્યાના બહુવિધ હોવા જોઈએ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// જો નીચેની શરતો હોલ્ડ કરે છે તો આ ફંક્શન ફક્ત ક callલ કરવા માટે સલામત છે:
///
/// - જો `T` એ `Sized` છે, તો આ કાર્ય ક callલ કરવા માટે હંમેશા સલામત છે.
/// - જો `T` ની અનઇસીઝ્ડ પૂંછડી છે:
///     - એક X01 એક્સ, પછી સ્લાઇસ પૂંછડીની લંબાઈ પ્રારંભિક પૂર્ણાંક હોવી આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
///     - એક X01 એક્સ, પછી પોઇન્ટરનો વtટેબલ ભાગ અનઇઝાઇઝિંગ જબરદસ્તી દ્વારા હસ્તગત માન્ય વtટેબલ તરફ નિર્દેશ કરવો આવશ્યક છે, અને *સંપૂર્ણ મૂલ્ય*(ગતિશીલ પૂંછડી લંબાઈ + સ્થિર કદના ઉપસર્ગ) નું કદ `isize` માં ફિટ હોવું આવશ્યક છે.
///
///     - એક (unstable) [extern type], તો પછી આ ફંક્શન હંમેશાં ક callલ કરવા માટે સલામત છે, પરંતુ બાહ્ય પ્રકારનું લેઆઉટ જાણીતું ન હોવાથી, panic અથવા અન્યથા ખોટી કિંમત પરત કરી શકે છે.
///     બાહ્ય પ્રકારનાં પૂંછડીઓવાળા પ્રકારનાં સંદર્ભમાં આ [`align_of_val`] જેવું જ વર્તન છે.
///     - નહિંતર, રૂ conિચુસ્ત રીતે આ ફંક્શનને ક .લ કરવાની મંજૂરી નથી.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // સલામતી: કlerલરને માન્ય કાચો પોઇન્ટર પ્રદાન કરવું આવશ્યક છે
    unsafe { intrinsics::min_align_of_val(val) }
}

/// જો `T` પ્રકારનાં મૂલ્યો છોડી દેવામાં આવે તો `true` પરત કરે છે.
///
/// આ સંપૂર્ણપણે optimપ્ટિમાઇઝેશન સંકેત છે, અને રૂ conિચુસ્તરૂપે લાગુ થઈ શકે છે:
/// તે એવા પ્રકારો માટે `true` પરત આપી શકે છે જેને ખરેખર છોડવાની જરૂર નથી.
/// જેમ કે હંમેશાં `true` પરત ફરવું એ આ કાર્યનો માન્ય અમલ હશે.જો આ કાર્ય ખરેખર `false` આપે છે, તો પછી તમે ચોક્કસ થઈ શકો છો `T` છોડવાની કોઈ આડઅસર નથી.
///
/// સંગ્રહો જેવી વસ્તુઓના નીચલા સ્તરના અમલીકરણો, જેને મેન્યુઅલી તેમનો ડેટા છોડવાની જરૂર છે, આ કાર્યનો ઉપયોગ બિનજરૂરી રીતે તેમના તમામ સમાવિષ્ટોનો નાશ થાય ત્યારે છોડવાનો પ્રયાસ ન કરવા માટે કરવો જોઈએ.
///
/// આ કદાચ રિલીઝ બિલ્ડ્સમાં ફરક પાડશે નહીં (જ્યાં કોઈ લૂપ કે જેની કોઈ આડઅસર નથી તે સરળતાથી શોધી કા eliminatedી શકાય છે), પરંતુ ડિબગ બિલ્ડ્સ માટે ઘણી વાર તે મોટી જીત છે.
///
/// નોંધ લો કે [`drop_in_place`] પહેલેથી જ આ તપાસ કરે છે, તેથી જો તમારું વર્કલોડ [`drop_in_place`] ક ofલ્સની થોડી સંખ્યામાં ઘટાડી શકાય છે, તો તેનો ઉપયોગ કરવો બિનજરૂરી છે.
/// ખાસ નોંધ લો કે તમે એક સ્લાઇસ [`drop_in_place`] કરી શકો છો, અને તે એક જ જરૂરિયાતો કરશે_ બધા મૂલ્યોની તપાસ કરશે.
///
/// Vec જેવા પ્રકારો તેથી સ્પષ્ટ રીતે `needs_drop` નો ઉપયોગ કર્યા વિના ફક્ત `drop_in_place(&mut self[..])`.
/// બીજી બાજુ, [`HashMap`] જેવા પ્રકારોએ એક સમયે મૂલ્ય છોડવું પડશે અને આ API નો ઉપયોગ કરવો જોઈએ.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// સંગ્રહ કેવી રીતે `needs_drop` નો ઉપયોગ કરે છે તેનું ઉદાહરણ અહીં છે:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ડેટા છોડો
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// - લ-શૂન્ય બાઇટ-પેટર્ન દ્વારા દર્શાવવામાં આવેલા `T` પ્રકારનું મૂલ્ય આપે છે.
///
/// આનો અર્થ એ કે, ઉદાહરણ તરીકે, `(u8, u16)` માં પેડિંગ બાઇટ શૂન્ય નથી.
///
/// ત્યાં કોઈ ગેરેંટી નથી કે-લ-શૂન્ય બાઇટ-પેટર્ન કેટલાક પ્રકારનાં `T` નું માન્ય મૂલ્ય રજૂ કરે છે.
/// ઉદાહરણ તરીકે, typesલ-શૂન્ય બાઇટ-પેટર્ન સંદર્ભ પ્રકારો (`&T`, `&mut T`) અને કાર્યોના નિર્દેશકો માટે માન્ય મૂલ્ય નથી.
/// આવા પ્રકારો પર `zeroed` નો ઉપયોગ કરવાથી તાત્કાલિક [undefined behavior][ub] થાય છે કારણ કે [the Rust compiler assumes][inv] કે ત્યાં હંમેશાં એક વેરીએબલમાં માન્ય મૂલ્ય હોય છે જે તેને પ્રારંભિક ગણાય છે.
///
///
/// આ [`MaybeUninit::zeroed().assume_init()`][zeroed] જેવી જ અસર ધરાવે છે.
/// તે કેટલીકવાર એફએફઆઈ માટે ઉપયોગી છે, પરંતુ સામાન્ય રીતે ટાળવું જોઈએ.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// આ ફંકશનનો સાચો વપરાશ: શૂન્ય સાથે પૂર્ણાંક પ્રારંભ કરવો.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// આ કાર્યનો *ખોટો* ઉપયોગ: શૂન્ય સાથે સંદર્ભ પ્રારંભ કરવો.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // અપ્રભાજિત વર્તન!
/// let _y: fn() = unsafe { mem::zeroed() }; // અને ફરીથી!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `T` માટે-લ-શૂન્ય મૂલ્ય માન્ય છે.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// બાયપાસ, ઝેડ રસ્ટ0 ઝેડની સામાન્ય મેમરી-પ્રારંભિક તપાસ `T` પ્રકારનું મૂલ્ય ઉત્પન્ન કરવાનું ingોંગ કરીને, કંઈપણ કરતી વખતે નહીં.
///
/// **આ ફંક્શનને નાપસંદ કરાયું છે.** તેના બદલે [`MaybeUninit<T>`] નો ઉપયોગ કરો.
///
/// અવમૂલ્યનનું કારણ એ છે કે ફંક્શન મૂળભૂત રીતે યોગ્ય રીતે ઉપયોગમાં લઈ શકાતું નથી: તે [`MaybeUninit::uninit().assume_init()`][uninit] જેવી જ અસર ધરાવે છે.
///
/// [`assume_init` documentation][assume_init] સમજાવે છે તેમ, [the Rust compiler assumes][inv] જે મૂલ્યો યોગ્ય રીતે પ્રારંભ થાય છે.
/// પરિણામ રૂપે, ક callingલિંગ દા.ત.
/// `mem::uninitialized::<bool>()` `bool` પરત ફરવા માટે તાત્કાલિક અસ્પષ્ટ વર્તનનું કારણ બને છે જે નિશ્ચિતરૂપે `true` અથવા `false` નથી.
/// સૌથી ખરાબ, ખરેખર અહીંથી પાછા ફરવા જેવી મેમરીને અનિશ્ચિત બનાવવી તે વિશેષ છે જેમાં કમ્પાઇલર જાણે છે કે તેનું મૂલ્ય ચોક્કસ નથી.
/// આ વેરીએબલમાં પૂર્ણાંકોનો પ્રકાર હોય તો પણ તે વેરીએબલમાં અનઇંટિઆલાઇઝ્ડ ડેટા રાખવા માટે અનિશ્ચિત વર્તણૂક બનાવે છે.
/// (નોંધ લો કે અનઇંટિલાઇઝ્ડ પૂર્ણાંકોની આસપાસના નિયમો હજુ સુધી આખરી થયા નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી તે ટાળવાની સલાહ આપવામાં આવે છે.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે યુનિટિડાઇઝ્ડ મૂલ્ય `T` માટે માન્ય છે.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// બંનેમાંથી કોઈ એકને ડિસિનેટાઇઝ કર્યા વિના, બે પરિવર્તનશીલ સ્થળોએ મૂલ્યોને અદલાબદલ કરે છે.
///
/// * જો તમે ડિફોલ્ટ અથવા ડમી મૂલ્ય સાથે સ્વેપ કરવા માંગો છો, તો [`take`] જુઓ.
/// * જો તમે પસાર કરેલ મૂલ્ય સાથે સ્વેપ કરવા માંગતા હો, તો જૂની કિંમત પરત કરીને, [`replace`] જુઓ.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // સલામતી: બધાને સંતોષકારક સલામત પરિવર્તનીય સંદર્ભોમાંથી કાચા નિર્દેશકો બનાવવામાં આવ્યા છે
    // `ptr::swap_nonoverlapping_one` પર અવરોધ
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` ને `T` ના ડિફ valueલ્ટ મૂલ્યથી બદલીને પાછલા `dest` મૂલ્યને પરત કરે છે.
///
/// * જો તમે બે ચલોના મૂલ્યોને બદલવા માંગતા હો, તો [`swap`] જુઓ.
/// * જો તમે ડિફ defaultલ્ટ મૂલ્યને બદલે પસાર કરેલ મૂલ્યથી બદલવા માંગતા હો, તો [`replace`] જુઓ.
///
/// # Examples
///
/// એક સરળ ઉદાહરણ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` સ્ટ્ર fieldક્ટ ક્ષેત્રને "empty" મૂલ્યથી બદલીને તેની માલિકી લેવાની મંજૂરી આપે છે.
/// `take` વિના તમે આ જેવા મુદ્દાઓ ચલાવી શકો છો:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// નોંધ લો કે `T` આવશ્યકપણે [`Clone`] ને લાગુ કરતું નથી, તેથી તે `self.buf` ને ક્લોન અને ફરીથી સેટ પણ કરી શકતું નથી.
/// પરંતુ `take` નો ઉપયોગ `self.buf` ના મૂળ મૂલ્યને `self` થી અલગ કરવા માટે કરી શકાય છે, તેને પાછા ફરવાની મંજૂરી આપીને:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` ને સંદર્ભિત `dest` માં ખસેડે છે, પાછલા `dest` મૂલ્યને પરત કરે છે.
///
/// ન તો મૂલ્ય છોડી દેવાઈ.
///
/// * જો તમે બે ચલોના મૂલ્યોને બદલવા માંગતા હો, તો [`swap`] જુઓ.
/// * જો તમે ડિફ defaultલ્ટ મૂલ્યથી બદલવા માંગો છો, તો [`take`] જુઓ.
///
/// # Examples
///
/// એક સરળ ઉદાહરણ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` સ્ટ્રક્ટ ક્ષેત્રને બીજા મૂલ્યથી બદલીને વપરાશને મંજૂરી આપે છે.
/// `replace` વિના તમે આ જેવા મુદ્દાઓ ચલાવી શકો છો:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// નોંધ લો કે `T` આવશ્યકપણે [`Clone`] અમલમાં મૂકતું નથી, તેથી ચાલને ટાળવા માટે અમે `self.buf[i]` ક્લોન પણ કરી શકતા નથી.
/// પરંતુ `replace` નો ઉપયોગ તે અનુક્રમણિકાના મૂળ મૂલ્યને `self` થી અલગ કરવા માટે કરી શકાય છે, તેને પરત કરવાની મંજૂરી આપીને:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // સલામતી: અમે `dest` માંથી વાંચ્યું પરંતુ પછીથી તેમાં સીધો `src` લખો,
    // જેમ કે જૂની કિંમત ડુપ્લિકેટ નથી.
    // કાંઈ પણ છોડ્યું નથી અને અહીં કંઈપણ ઝેડપૈનિક 0 ઝેડ કરી શકશે નહીં.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// મૂલ્યનો નિકાલ કરે છે.
///
/// આ દલીલના [`Drop`][drop] ના અમલીકરણને બોલાવીને આવું કરે છે.
///
/// આ અસરકારક રીતે તે પ્રકારો માટે કશું કરતું નથી જે `Copy` ને અમલમાં મૂકે છે, દા.ત.
/// integers.
/// આવા મૂલ્યોની કiedપિ કરવામાં આવે છે અને _then_ ફંક્શનમાં ખસેડવામાં આવે છે, તેથી આ ફંક્શન ક callલ પછી મૂલ્ય યથાવત્ રહે છે.
///
///
/// આ કાર્ય જાદુઈ નથી;તે શાબ્દિક રીતે વ્યાખ્યાયિત થયેલ છે
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// કારણ કે `_x` ફંક્શનમાં ખસેડવામાં આવ્યું છે, તે ફંક્શન પાછું આવે તે પહેલાં આપમેળે નીચે આવી જાય છે.
///
/// [drop]: Drop
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // સ્પષ્ટપણે vector છોડો
/// ```
///
/// [`RefCell`] રનટાઈમ પર ઉધારના નિયમોને લાગુ કરે છે, તેથી `drop` [`RefCell`] ઉધારને છૂટા કરી શકે છે:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // આ સ્લોટ પર પરિવર્તનીય ઉધાર છોડી દો
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] લાગુ કરતા પૂર્ણાંકો અને અન્ય પ્રકારો `drop` દ્વારા અસરગ્રસ્ત નથી.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` ની ક movedપિ ખસેડી અને છોડવામાં આવે છે
/// drop(y); // `y` ની ક movedપિ ખસેડી અને છોડવામાં આવે છે
///
/// println!("x: {}, y: {}", x, y.0); // હજુ પણ ઉપલબ્ધ છે
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` નો પ્રકાર `&U` હોવાનો અર્થઘટન કરે છે, અને પછી સમાયેલ મૂલ્યને ખસેડ્યા વિના `src` વાંચે છે.
///
/// આ ફંક્શન અસુરક્ષિત રીતે ધારશે કે `src` એક્સ બાહ્ય માટે `&T` ને `&U` પરિવર્તિત કરીને અને પછી `&U` વાંચીને `src` માન્ય છે X0X (સિવાય કે `&U` `&T` કરતા વધુ સખ્ત ગોઠવણી આવશ્યકતાઓ બનાવે છે ત્યારે પણ આ યોગ્ય રીતે કરવામાં આવે છે).
/// તે અસુરક્ષિત રીતે `src` ની બહાર જવાને બદલે સમાવિષ્ટ મૂલ્યની એક ક createપિ પણ બનાવશે.
///
/// જો `T` અને `U` ના વિવિધ કદ હોય તો તે કમ્પાઇલ-ટાઇમ ભૂલ નથી, પરંતુ `T` અને `U` સમાન કદ ધરાવતા આ ફંક્શનને જ પ્રોત્સાહન આપવા માટે ખૂબ જ પ્રોત્સાહન આપવામાં આવે છે.જો `U` `T` કરતા મોટું હોય તો આ ફંક્શન [undefined behavior][ub] ને ટ્રિગર કરે છે.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' માંથી ડેટાની ક Copyપિ કરો અને તેને 'Foo' તરીકે ગણશો
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // કiedપિ કરેલો ડેટા સુધારો
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' ની સામગ્રી બદલી ન હોવી જોઈએ
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // જો યુની alંચી સંરેખણ આવશ્યકતા હોય, તો src યોગ્ય રીતે ગોઠવાયેલ ન હોઈ શકે.
    if align_of::<U>() > align_of::<T>() {
        // સલામતી: `src` એ એક સંદર્ભ છે જે વાંચવા માટે માન્ય હોવાની બાંયધરી છે.
        // ક calલરે ખાતરી આપી છે કે વાસ્તવિક ટ્રાન્સમ્યુટેશન સલામત છે.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // સલામતી: `src` એ એક સંદર્ભ છે જે વાંચવા માટે માન્ય હોવાની બાંયધરી છે.
        // અમે હમણાં જ તપાસ્યું કે `src as *const U` યોગ્ય રીતે ગોઠવાયેલ છે.
        // ક calલરે ખાતરી આપી છે કે વાસ્તવિક ટ્રાન્સમ્યુટેશન સલામત છે.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// અપારદર્શક પ્રકાર, જે એનમના ભેદભાવને રજૂ કરે છે.
///
/// વધુ માહિતી માટે આ મોડ્યુલમાં [`discriminant`] ફંક્શન જુઓ.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. આ trait અમલીકરણો તારવી શકાતા નથી કારણ કે અમને T પર કોઈ સીમા નથી જોઈતી.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` માં enum વેરિઅન્ટને અનન્ય રૂપે ઓળખવા માટેનું મૂલ્ય આપે છે.
///
/// જો `T` એ એનમ નથી, તો આ ફંક્શનને ક callingલ કરવાથી અસ્પષ્ટ વર્તન થશે નહીં, પરંતુ વળતર મૂલ્ય અનિશ્ચિત છે.
///
///
/// # Stability
///
/// જો એનમ વ્યાખ્યા બદલાય તો એનમ વેરિઅન્ટનો ભેદભાવ બદલાઈ શકે છે.
/// કેટલાક પ્રકારનાં ભેદભાવ સમાન કમ્પાઇલરવાળા સંકલન વચ્ચે બદલાશે નહીં.
///
/// # Examples
///
/// આનો ઉપયોગ ડેટા વહન કરતા એન્મ્સની તુલના કરવા માટે થઈ શકે છે, જ્યારે વાસ્તવિક ડેટાને અવગણીને:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// એનમ પ્રકાર `T` માં વેરિઅન્ટ્સની સંખ્યા પરત કરે છે.
///
/// જો `T` એ એનમ નથી, તો આ ફંક્શનને ક callingલ કરવાથી અસ્પષ્ટ વર્તન થશે નહીં, પરંતુ વળતર મૂલ્ય અનિશ્ચિત છે.
/// એ જ રીતે, જો `T` એ `usize::MAX` કરતા વધુ ચલો સાથેનું એક એનમ છે, તો વળતર મૂલ્ય અનિશ્ચિત છે.
/// નિર્જન વેરિયન્ટ્સ ગણાશે.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}