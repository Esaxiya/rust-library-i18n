#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// એક `RawWaker` ટાસ્ક એક્ઝિક્યુટરના અમલીકરણને [`Waker`] બનાવવા માટે પરવાનગી આપે છે જે કસ્ટમાઇઝ્ડ વેકઅપ વર્તણૂક પ્રદાન કરે છે.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// તેમાં ડેટા પોઇંટર અને [virtual function pointer table (vtable)][vtable] શામેલ છે જે `RawWaker` ની વર્તણૂકને કસ્ટમાઇઝ કરે છે.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// ડેટા પોઇન્ટર, જેનો ઉપયોગ વહીવટકર્તા દ્વારા જરૂરી હોય તે રીતે મનસ્વી ડેટા સંગ્રહિત કરવા માટે થઈ શકે છે.
    /// આ દા.ત. હોઈ શકે છે
    /// `Arc` નો ટાઇપ-ઇરેડ પોઇન્ટર જે કાર્ય સાથે સંકળાયેલ છે.
    /// આ ક્ષેત્રનું મૂલ્ય તે બધા કાર્યોને પસાર થાય છે જે પ્રથમ પરિમાણ તરીકે વtટેબલનો ભાગ છે.
    ///
    data: *const (),
    /// વર્ચ્યુઅલ ફંક્શન પોઇન્ટર ટેબલ જે આ વakerકરની વર્તણૂકને કસ્ટમાઇઝ કરે છે.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// પ્રદાન કરેલા `data` પોઇન્ટર અને `vtable` થી નવું `RawWaker` બનાવે છે.
    ///
    /// એક્ઝેક્યુટર દ્વારા જરૂરી મનસ્વી ડેટા સંગ્રહિત કરવા માટે, `data` પોઇન્ટરનો ઉપયોગ કરી શકાય છે.આ દા.ત. હોઈ શકે છે
    /// `Arc` નો ટાઇપ-ઇરેડ પોઇન્ટર જે કાર્ય સાથે સંકળાયેલ છે.
    /// આ નિર્દેશકનું મૂલ્ય તે બધા કાર્યોમાં પસાર થઈ જશે જે પ્રથમ પરિમાણ તરીકે `vtable` નો ભાગ છે.
    ///
    /// `vtable` એ `Waker` ની વર્તણૂકને કસ્ટમાઇઝ કરે છે જે `RawWaker` માંથી બનાવેલ છે.
    /// `Waker` પરના દરેક Forપરેશન માટે, અંતર્ગત `RawWaker` ના `vtable` માં સંકળાયેલ ફંક્શન કહેવાશે.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// વર્ચુઅલ ફંક્શન પોઇન્ટર ટેબલ (vtable) જે [`RawWaker`] ની વર્તણૂકને નિર્દિષ્ટ કરે છે.
///
/// વtટેબલની અંદરના તમામ કાર્યોમાં પસાર કરાયેલ પોઇન્ટર એ [`RawWaker`] encબ્જેક્ટને બંધ કરતા `data` પોઇન્ટર છે.
///
/// આ સ્ટ્રક્ટની અંદરનાં કાર્યો ફક્ત [`RawWaker`] અમલીકરણની અંદરથી યોગ્ય રીતે નિર્માણ થયેલ [`RawWaker`] ofબ્જેક્ટના `data` પોઇન્ટર પર ક calledલ કરવાના છે.
/// કોઈપણ અન્ય `data` પોઇન્ટરનો ઉપયોગ કરીને સમાયેલ કાર્યોમાંથી એકને કingલ કરવાથી અનિશ્ચિત વર્તન થશે.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// જ્યારે [`RawWaker`] ક્લોન થઈ જાય ત્યારે આ ફંક્શન કહેવાશે, દા.ત. જ્યારે [`Waker`] જેમાં [`RawWaker`] સ્ટોર થયેલ છે ક્લોન થઈ જાય.
    ///
    /// આ કાર્યના અમલીકરણમાં તે બધા સંસાધનોને જાળવી રાખવા આવશ્યક છે કે જે [`RawWaker`] અને સંબંધિત કાર્યના આ વધારાના દાખલા માટે જરૂરી છે.
    /// પરિણામી [`RawWaker`] પર `wake` ને કingલ કરવાથી તે જ કાર્ય શરૂ થવું જોઈએ જે અસલી [`RawWaker`] દ્વારા જાગ્યું હોત.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// જ્યારે `wake` ને [`Waker`] પર બોલાવવામાં આવે ત્યારે આ ફંકશન કહેવામાં આવશે.
    /// તેણે આ [`RawWaker`] સાથે સંકળાયેલ કાર્યને જગાડવું આવશ્યક છે.
    ///
    /// આ કાર્યના અમલીકરણમાં [`RawWaker`] ના આ દાખલા સાથે સંકળાયેલ કોઈપણ સંસાધનોને રિલીઝ કરવાની ખાતરી કરવી આવશ્યક છે અને સંબંધિત કાર્ય.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// જ્યારે `wake_by_ref` ને [`Waker`] પર બોલાવવામાં આવે ત્યારે આ ફંકશન કહેવામાં આવશે.
    /// તેણે આ [`RawWaker`] સાથે સંકળાયેલ કાર્યને જગાડવું આવશ્યક છે.
    ///
    /// આ ફંક્શન `wake` જેવું જ છે, પરંતુ પ્રદાન કરેલા ડેટા પોઇન્ટરનો વપરાશ ન કરવો જોઈએ.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// જ્યારે [`RawWaker`] છોડવામાં આવે ત્યારે આ ફંક્શન કહેવામાં આવે છે.
    ///
    /// આ કાર્યના અમલીકરણમાં [`RawWaker`] ના આ દાખલા સાથે સંકળાયેલ કોઈપણ સંસાધનોને રિલીઝ કરવાની ખાતરી કરવી આવશ્યક છે અને સંબંધિત કાર્ય.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// પ્રદાન કરેલા `clone`, `wake`, `wake_by_ref` અને `drop` કાર્યોથી નવું `RawWakerVTable` બનાવે છે.
    ///
    /// # `clone`
    ///
    /// જ્યારે [`RawWaker`] ક્લોન થઈ જાય ત્યારે આ ફંક્શન કહેવાશે, દા.ત. જ્યારે [`Waker`] જેમાં [`RawWaker`] સ્ટોર થયેલ છે ક્લોન થઈ જાય.
    ///
    /// આ કાર્યના અમલીકરણમાં તે બધા સંસાધનોને જાળવી રાખવા આવશ્યક છે કે જે [`RawWaker`] અને સંબંધિત કાર્યના આ વધારાના દાખલા માટે જરૂરી છે.
    /// પરિણામી [`RawWaker`] પર `wake` ને કingલ કરવાથી તે જ કાર્ય શરૂ થવું જોઈએ જે અસલી [`RawWaker`] દ્વારા જાગ્યું હોત.
    ///
    /// # `wake`
    ///
    /// જ્યારે `wake` ને [`Waker`] પર બોલાવવામાં આવે ત્યારે આ ફંકશન કહેવામાં આવશે.
    /// તેણે આ [`RawWaker`] સાથે સંકળાયેલ કાર્યને જગાડવું આવશ્યક છે.
    ///
    /// આ કાર્યના અમલીકરણમાં [`RawWaker`] ના આ દાખલા સાથે સંકળાયેલ કોઈપણ સંસાધનોને રિલીઝ કરવાની ખાતરી કરવી આવશ્યક છે અને સંબંધિત કાર્ય.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// જ્યારે `wake_by_ref` ને [`Waker`] પર બોલાવવામાં આવે ત્યારે આ ફંકશન કહેવામાં આવશે.
    /// તેણે આ [`RawWaker`] સાથે સંકળાયેલ કાર્યને જગાડવું આવશ્યક છે.
    ///
    /// આ ફંક્શન `wake` જેવું જ છે, પરંતુ પ્રદાન કરેલા ડેટા પોઇન્ટરનો વપરાશ ન કરવો જોઈએ.
    ///
    /// # `drop`
    ///
    /// જ્યારે [`RawWaker`] છોડવામાં આવે ત્યારે આ ફંક્શન કહેવામાં આવે છે.
    ///
    /// આ કાર્યના અમલીકરણમાં [`RawWaker`] ના આ દાખલા સાથે સંકળાયેલ કોઈપણ સંસાધનોને રિલીઝ કરવાની ખાતરી કરવી આવશ્યક છે અને સંબંધિત કાર્ય.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// એક અસુમેળ કાર્યનું `Context`.
///
/// હાલમાં, `Context` ફક્ત `&Waker` ની provideક્સેસ પ્રદાન કરે છે જેનો ઉપયોગ વર્તમાન કાર્યને જાગૃત કરવા માટે થઈ શકે છે.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // જીવનકાળને અવિચારી બનવાની ફરજ પાડીને અમે ઝેડફ્યુચર 0 ઝેડ-પ્રૂફને સુનિશ્ચિત કરો (દલીલ-સ્થિતિ જીવનકાળ અસંગત હોય છે જ્યારે વળતર-સ્થિતિનો જીવનકાળ સહકારી હોય છે).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// એક `&Waker` થી નવું `Context` બનાવો.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// વર્તમાન કાર્ય માટે `Waker` નો સંદર્ભ આપે છે.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// એક્સ એક્સએક્સએક્સ તેના એક્ઝેક્યુટરને સૂચિત કરીને કે તે ચલાવવા માટે તૈયાર છે, દ્વારા જાગૃત થવા માટેનું એક હેન્ડલ છે.
///
/// આ હેન્ડલ એક [`RawWaker`] દાખલાને સમાવે છે, જે એક્ઝેક્યુટર-વિશિષ્ટ વેકઅપ વર્તનને વ્યાખ્યાયિત કરે છે.
///
///
/// [`Clone`], [`Send`] અને [`Sync`] લાગુ કરે છે.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// આ `Waker` સાથે સંકળાયેલ કાર્યને જાગો.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // વાસ્તવિક વેકઅપ ક callલ અમલ માટે વર્ચુઅલ ફંક્શન ક callલ દ્વારા સોંપવામાં આવે છે જે એક્ઝેક્યુટર દ્વારા વ્યાખ્યાયિત કરવામાં આવે છે.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` ને ક callલ ન કરો-વેકરનો વપરાશ `wake` દ્વારા કરવામાં આવશે.
        crate::mem::forget(self);

        // સલામતી: આ સલામત છે કારણ કે `Waker::from_raw` એકમાત્ર રસ્તો છે
        // `wake` અને `data` પ્રારંભ કરવા માટે, વપરાશકર્તાએ `RawWaker` નો કરાર માન્ય રાખ્યો છે તે સ્વીકારવા માટે જરૂરી છે.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` લીધા વિના આ `Waker` સાથે સંકળાયેલ કાર્યને જાગો.
    ///
    /// આ `wake` જેવું જ છે, પરંતુ જ્યાં માલિકીની `Waker` ઉપલબ્ધ છે તે કિસ્સામાં તે થોડી ઓછી કાર્યક્ષમ હશે.
    /// આ પદ્ધતિને `waker.clone().wake()` પર ક callingલ કરવા માટે પ્રાધાન્ય આપવું જોઈએ.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // વાસ્તવિક વેકઅપ ક callલ અમલ માટે વર્ચુઅલ ફંક્શન ક callલ દ્વારા સોંપવામાં આવે છે જે એક્ઝેક્યુટર દ્વારા વ્યાખ્યાયિત કરવામાં આવે છે.
        //

        // સલામત: જુઓ `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// જો આ `Waker` અને બીજા `Waker` એ સમાન કાર્યથી આગળ વધ્યા છે, તો `true` આપે છે.
    ///
    /// આ કાર્ય શ્રેષ્ઠ પ્રયત્નના આધારે કાર્ય કરે છે, અને `વેકર્સ સમાન કાર્યને જાગૃત કરશે ત્યારે પણ ખોટું પાછું આપી શકે છે.
    /// જો કે, જો આ ફંક્શન `true` પરત કરે છે, તો બાંહેધરી આપવામાં આવે છે કે `વેકર્સ સમાન કાર્યને જાગૃત કરશે.
    ///
    /// આ કાર્ય મુખ્યત્વે optimપ્ટિમાઇઝેશન હેતુ માટે વપરાય છે.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] થી નવું `Waker` બનાવે છે.
    ///
    /// જો [`RawWaker`] ના અને [`RawWakerVTable`] ના દસ્તાવેજોમાં વ્યાખ્યાયિત કરારને સમર્થન ન આપવામાં આવ્યું હોય તો પાછા આપેલા `Waker` ની વર્તણૂક અસ્પષ્ટ છે.
    ///
    /// તેથી આ પદ્ધતિ અસુરક્ષિત છે.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // સલામતી: આ સલામત છે કારણ કે `Waker::from_raw` એકમાત્ર રસ્તો છે
            // `clone` અને `data` પ્રારંભ કરવા માટે, વપરાશકર્તાએ [`RawWaker`] નો કરાર માન્ય રાખ્યો છે તે સ્વીકારવા માટે જરૂરી છે.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // સલામતી: આ સલામત છે કારણ કે `Waker::from_raw` એકમાત્ર રસ્તો છે
        // `drop` અને `data` પ્રારંભ કરવા માટે, વપરાશકર્તાએ `RawWaker` નો કરાર માન્ય રાખ્યો છે તે સ્વીકારવા માટે જરૂરી છે.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}