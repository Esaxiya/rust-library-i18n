//! શેર કરવા યોગ્ય પરિવર્તનીય કન્ટેનર.
//!
//! ઝેડ રસ્ટ0 ઝેડ મેમરી સલામતી આ નિયમ પર આધારીત છે: objectબ્જેક્ટ `T` આપેલ, ફક્ત નીચેનામાંથી એક હોવું શક્ય છે:
//!
//! - Immબ્જેક્ટ પર ઘણા બદલી ન શકાય તેવા સંદર્ભો (`&T`) (જેને **એલિયાઝિંગ** તરીકે પણ ઓળખાય છે).
//! - Mutબ્જેક્ટનો એક પરિવર્તનશીલ સંદર્ભ (`&મ્યુટ T`)(જેને **પરિવર્તન** તરીકે પણ ઓળખાય છે).
//!
//! આ Rust કમ્પાઈલર દ્વારા લાગુ કરવામાં આવ્યું છે.જો કે, એવી પરિસ્થિતિઓ છે કે જ્યાં આ નિયમ પર્યાપ્ત લવચીક નથી.કેટલીકવાર કોઈ toબ્જેક્ટ પર બહુવિધ સંદર્ભો હોવું જરૂરી છે અને તેમ છતાં તેને પરિવર્તિત કરવું જરૂરી છે.
//!
//! શેર કરવા યોગ્ય પરિવર્તનીય કન્ટેનર અલીઅસીંગની હાજરીમાં પણ નિયંત્રિત રીતે પરિવર્તનની મંજૂરી માટે અસ્તિત્વમાં છે.બંને [`Cell<T>`] અને [`RefCell<T>`] આને એક થ્રેડેડ રીતે કરવાની મંજૂરી આપે છે.
//! જો કે, `Cell<T>` અથવા `RefCell<T>` ન તો થ્રેડ સુરક્ષિત છે (તેઓ [`Sync`] અમલમાં મૂકતા નથી).
//! જો તમારે બહુવિધ થ્રેડો વચ્ચે અલીઝિંગ અને પરિવર્તન કરવાની જરૂર હોય તો [`Mutex<T>`], [`RwLock<T>`] અથવા [`atomic`] પ્રકારનો ઉપયોગ શક્ય છે.
//!
//! `Cell<T>` અને `RefCell<T>` પ્રકારનાં મૂલ્યો શેર કરેલા સંદર્ભો દ્વારા બદલાઇ શકે છે (દા.ત.
//! સામાન્ય `&T` પ્રકાર), જ્યારે મોટાભાગના ઝેડ રસ્ટ0 ઝેડ પ્રકારોને ફક્ત અનન્ય (`&મ્યુટ T`) સંદર્ભો દ્વારા બદલી શકાય છે.
//! અમે કહીએ છીએ કે `Cell<T>` અને `RefCell<T>` 'વારસાગત પરિવર્તનશીલતા' દર્શાવે છે તેવા લાક્ષણિક ઝેડ રસ્ટ 0 ઝેડ પ્રકારોથી વિપરીત, 'આંતરિક પરિવર્તન' પ્રદાન કરે છે.
//!
//! કોષના પ્રકારો બે સ્વાદમાં આવે છે: `Cell<T>` અને `RefCell<T>`.`Cell<T>`, `Cell<T>` માં અને બહાર કિંમતોને ખસેડીને આંતરિક પરિવર્તન લાવે છે.
//! મૂલ્યોને બદલે સંદર્ભો વાપરવા માટે, કોઈએ `RefCell<T>` પ્રકારનો ઉપયોગ કરવો જ જોઇએ, પરિવર્તન કરતા પહેલા લેખન લ acquક મેળવવો.`Cell<T>` વર્તમાન આંતરિક મૂલ્યને પ્રાપ્ત કરવા અને બદલવા માટેની પદ્ધતિઓ પ્રદાન કરે છે:
//!
//!  - એવા પ્રકારો માટે કે જે [`Copy`] ને લાગુ કરે છે, [`get`](Cell::get) પદ્ધતિ વર્તમાન આંતરિક મૂલ્ય પ્રાપ્ત કરે છે.
//!  - એવા પ્રકારો માટે કે જેઓ [`Default`] ને અમલમાં મૂકે છે, [`take`](Cell::take) પદ્ધતિ વર્તમાન આંતરિક મૂલ્યને [`Default::default()`] સાથે બદલીને બદલાયેલ મૂલ્ય આપે છે.
//!  - બધા પ્રકારો માટે, [`replace`](Cell::replace) પદ્ધતિ વર્તમાન આંતરિક મૂલ્યને બદલે છે અને બદલાયેલ મૂલ્યને પરત કરે છે અને [`into_inner`](Cell::into_inner) પદ્ધતિ `Cell<T>` લે છે અને આંતરિક મૂલ્ય આપે છે.
//!  વધુમાં, [`set`](Cell::set) પદ્ધતિ આંતરિક મૂલ્યને બદલીને, બદલાયેલ મૂલ્યને છોડી દે છે.
//!
//! `RefCell<T>` 'ગતિશીલ ઉધાર' લાગુ કરવા માટે ઝેડ 0 રસ્ટ0 ઝેડના જીવનકાળનો ઉપયોગ કરે છે, એક પ્રક્રિયા કે જેના દ્વારા કોઈ આંતરિક મૂલ્યની અસ્થાયી, વિશિષ્ટ, પરિવર્તનશીલ claimક્સેસનો દાવો કરી શકે છે.
//! `રેફસેલ માટે ઉધાર<T>Z એ ઝેડ રસ્ટ0 ઝેડના મૂળ સંદર્ભ પ્રકારોથી વિપરીત 'રન ટાઇમ પર' ટ્રેક કરવામાં આવે છે, જે કમ્પાઇલ સમયે સંપૂર્ણ સ્થિર રીતે ટ્રેક કરવામાં આવે છે.
//! કારણ કે `RefCell<T>` ઉધાર ગતિશીલ છે, જે મૂલ્ય પહેલાથી પરસ્પર ઉધાર લેવામાં આવ્યું છે તે ઉધાર લેવાનો પ્રયાસ કરવો શક્ય છે;જ્યારે આવું થાય છે ત્યારે તે ઝેડપેંનિક0 ઝેડ થ્રેડમાં પરિણમે છે.
//!
//! # આંતરીક પરિવર્તનશીલતા ક્યારે પસંદ કરવી
//!
//! વધુ સામાન્ય વારસાગત પરિવર્તનશીલતા, જ્યાં કોઈને મૂલ્યના પરિવર્તન માટે અનન્ય mustક્સેસ હોવી આવશ્યક છે, તે એક મુખ્ય ભાષા તત્વો છે જે ઝેડ રસ્ટ0 ઝેડને પોઇન્ટર અલીઅસીંગ વિશે તર્ક આપવા માટે સક્ષમ કરે છે, સ્થિર રીતે ક્રેશ બગને અટકાવે છે.
//! તેના કારણે, વારસાગત પરિવર્તનને પ્રાધાન્ય આપવામાં આવે છે, અને આંતરીક પરિવર્તન એ એક અંતિમ ઉપાય છે.
//! સેલ પ્રકારો પરિવર્તનને સક્ષમ કરે છે જ્યાં તેને અન્યથા મંજૂરી ન આપવામાં આવે ત્યાં સુધી, એવા પ્રસંગો છે કે જ્યારે આંતરિક પરિવર્તન યોગ્ય હોઈ શકે, અથવા તો * ** નો ઉપયોગ કરવો જ જોઇએ, દા.ત.
//!
//! * પરિવર્તનશીલતાનો પરિચય X ફેરફાર કરો કંઈક બદલી શકાય તેવા 'inside'
//! * તાર્કિક-સ્થાવર પદ્ધતિઓની અમલીકરણની વિગતો.
//! * [`Clone`] ના અમલીકરણને મ્યુટ કરી રહ્યાં છે.
//!
//! ## પરિવર્તનશીલતાનો પરિચય X ફેરફાર કરો કંઈક બદલી શકાય તેવા 'inside'
//!
//! [`Rc<T>`] અને [`Arc<T>`] સહિત ઘણા વહેંચાયેલા સ્માર્ટ પોઇન્ટર પ્રકારો, એવા કન્ટેનર પ્રદાન કરે છે જેને ક્લોન કરી શકાય છે અને બહુવિધ પક્ષો વચ્ચે શેર કરી શકાય છે.
//! કારણ કે સમાયેલ મૂલ્યો ગુણાકાર-એલિએઝ્ડ હોઈ શકે છે, તે ફક્ત `&mut` સાથે નહીં, `&` સાથે ઉધાર લઈ શકાય છે.
//! કોષો વિના આ સ્માર્ટ પોઇંટરની અંદરના ડેટાને બિલકુલ ફેરવવું અશક્ય છે.
//!
//! પરિવર્તનશીલતાને ફરીથી રજૂ કરવા માટે શેર કરેલ પોઇન્ટર પ્રકારોની અંદર `RefCell<T>` મૂકવું તે ખૂબ સામાન્ય છે:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // ગતિશીલ ઉધારના અવકાશને મર્યાદિત કરવા માટે એક નવો અવરોધ બનાવો
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // નોંધ લો કે જો આપણે કેશનું પાછલું ઉધાર અવકાશમાંથી બહાર ન પડવા દીધું હોત, તો પછીનું ઉધાર ગતિશીલ થ્રેડ panic નું કારણ બને છે.
//!     //
//!     // આ `RefCell` નો ઉપયોગ કરવાનો મોટો સંકટ છે.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! નોંધ લો કે આ ઉદાહરણ `Rc<T>` નો ઉપયોગ કરે છે, `Arc<T>` નો નહીં.`રેફસેલ<T>એ સિંગલ-થ્રેડેડ દૃશ્યો માટે છે.જો તમને મલ્ટિ-થ્રેડેડ પરિસ્થિતિમાં વહેંચાયેલ પરિવર્તનની જરૂર હોય તો [`RwLock<T>`] અથવા [`Mutex<T>`] નો ઉપયોગ કરો.
//!
//! ## તાર્કિક-સ્થાવર પદ્ધતિઓની અમલીકરણની વિગતો
//!
//! પ્રસંગોપાત, એપીઆઇમાં ખુલાસો ન કરવો એ ઇચ્છનીય છે કે ત્યાં પરિવર્તન થઈ રહ્યું છે "under the hood".
//! આ કારણ હોઈ શકે છે કારણ કે તાર્કિક રૂપે immપરેશન સ્થાવર છે, પરંતુ દા.ત., કેશીંગ અમલીકરણને પરિવર્તન માટે દબાણ કરે છે;અથવા કારણ કે તમારે ઝેડટ્રેટ 0 ઝેડ પદ્ધતિને લાગુ કરવા માટે પરિવર્તનનો ઉપયોગ કરવો આવશ્યક છે જે `&self` લેવા માટે મૂળ રૂપે વ્યાખ્યાયિત કરવામાં આવી હતી.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ખર્ચાળ ગણતરી અહીં જાય છે
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` ના અમલીકરણને મ્યુટ કરી રહ્યાં છે
//!
//! આ ફક્ત એક વિશિષ્ટ, પરંતુ સામાન્ય છે, જે અગાઉના કિસ્સામાં છે: તે ક્રિયાઓ માટે પરિવર્તનશીલતાને છુપાવી રહ્યું છે જે અપરિવર્તનીય લાગે છે.
//! [`clone`](Clone::clone) પદ્ધતિથી સ્રોત મૂલ્યમાં ફેરફાર નહીં થવાની અપેક્ષા છે, અને X001 નહીં, `&self` લેવાની ઘોષણા કરવામાં આવે છે.
//! તેથી, કોઈપણ પરિવર્તન કે જે `clone` પદ્ધતિમાં થાય છે તે માટે કોષના પ્રકારનો ઉપયોગ કરવો આવશ્યક છે.
//! ઉદાહરણ તરીકે, [`Rc<T>`] એ `Cell<T>` ની અંદર તેની સંદર્ભ ગણતરીઓ જાળવી રાખે છે.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// પરિવર્તનશીલ મેમરી સ્થાન.
///
/// # Examples
///
/// આ ઉદાહરણમાં, તમે જોઈ શકો છો કે `Cell<T>` એક પરિવર્તનશીલ સ્ટ્રક્ટની અંદર પરિવર્તનને સક્ષમ કરે છે.
/// અન્ય શબ્દોમાં, તે "interior mutability" ને સક્ષમ કરે છે.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ભૂલ: `my_struct` બદલી ન શકાય તેવું છે
/// // my_struct.regular_field =નવું_મૂલ્ય;
///
/// // કાર્યો: જોકે `my_struct` સ્થાવર છે, `special_field` એ `Cell` છે,
/// // જે હંમેશા પરિવર્તિત થઈ શકે છે
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// ટી માટેના `Default` મૂલ્ય સાથે, એક `Cell<T>` બનાવે છે.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// આપેલ મૂલ્ય ધરાવતું એક નવું `Cell` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// સમાયેલ મૂલ્ય સેટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// બે કોષોનાં મૂલ્યો બદલાઇ જાય છે.
    /// `std::mem::swap` સાથેનો તફાવત એ છે કે આ કાર્ય માટે `&mut` સંદર્ભની જરૂર નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // સલામતી: જો અલગ થ્રેડોમાંથી કહેવામાં આવે તો આ જોખમી હોઈ શકે છે, પરંતુ `Cell`
        // `!Sync` છે તેથી આવું નહીં થાય.
        // આ કોઈપણ પોઇંટર્સને પણ અમાન્ય બનાવશે નહીં કારણ કે `Cell` ખાતરી કરે છે કે બીજું કંઈપણ આમાંથી કોઈ પણ તરફ ધ્યાન દોરશે નહીં `સેલ`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` સાથે સમાયેલ મૂલ્યને બદલે છે, અને જૂના સમાયેલ મૂલ્યને પાછું આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // સલામતી: આ કોઈ અલગ થ્રેડમાંથી ક calledલ કરવામાં આવે તો ડેટા રેસ બનાવવાનું કારણ બની શકે છે,
        // પરંતુ `Cell` એ `!Sync` છે તેથી આવું નહીં થાય.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// મૂલ્યને સમાપ્ત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// સમાયેલ મૂલ્યની એક ક Returnપિ પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // સલામતી: આ કોઈ અલગ થ્રેડમાંથી ક calledલ કરવામાં આવે તો ડેટા રેસ બનાવવાનું કારણ બની શકે છે,
        // પરંતુ `Cell` એ `!Sync` છે તેથી આવું નહીં થાય.
        unsafe { *self.value.get() }
    }

    /// ફંકશનનો ઉપયોગ કરીને સમાયેલ મૂલ્યને અપડેટ કરે છે અને નવું મૂલ્ય આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// આ કોષમાં અંતર્ગત ડેટા પર કાચો પોઇન્ટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// અંતર્ગત ડેટા માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// આ ક callલ `Cell` પરસ્પર ઉધાર લે છે (કમ્પાઇલ સમયે) જે ખાતરી આપે છે કે અમારી પાસે એકમાત્ર સંદર્ભ છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` માંથી `&Cell<T>` પરત કરે છે
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // સલામતી: `&mut` અનન્ય વપરાશની ખાતરી કરે છે.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` ને તેની જગ્યાએ છોડીને, કોષનું મૂલ્ય લે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` માંથી `&[Cell<T>]` પરત કરે છે
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // સલામતી: `Cell<T>` એ `T` જેટલું મેમરી લેઆઉટ છે.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ગતિશીલ રૂપે ચકાસાયેલ બોરો નિયમો સાથે પરિવર્તનશીલ મેમરી સ્થાન
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] દ્વારા ભૂલ પાછો આવી.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] દ્વારા ભૂલ પાછો આવી.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// સકારાત્મક મૂલ્યો `Ref` સક્રિયની સંખ્યાને રજૂ કરે છે.નકારાત્મક મૂલ્યો `RefMut` સક્રિયની સંખ્યાને રજૂ કરે છે.
// મલ્ટીપલ `રેફમ્યુટ્સ તે સમયે જ સક્રિય થઈ શકે છે જો તેઓ `RefCell` (દા.ત., સ્લાઇસની વિવિધ રેન્જ) ના અલગ, નોનઓવરલેપિંગ ઘટકોનો સંદર્ભ આપે.
//
// `Ref` અને `RefMut` એ બંને કદના બે શબ્દો છે, અને તેથી સંભવત: `usize` શ્રેણીના અડધા ભાગને ઓવરફ્લો કરવા માટે અસ્તિત્વમાં ક્યારેય enough રેફ`અથવા M રેફમ`ટ્સ નહીં હોય.
// આમ, એક `BorrowFlag` કદાચ ક્યારેય ઓવરફ્લો અથવા અન્ડરફ્લો થશે નહીં.
// જો કે, આ બાંયધરી નથી, કારણ કે રોગવિજ્ .ાનવિષયક પ્રોગ્રામ વારંવાર બનાવી શકે છે અને પછી mem::forget `રેફ્સ અથવા` રેફમ્યુટ્સ.
// આમ, બિનસલાહભર્યું ટાળવા માટે બધા કોડ સ્પષ્ટપણે ઓવરફ્લો અને અંડરફ્લો માટે તપાસવા આવશ્યક છે, અથવા ઓછામાં ઓછી તે ઘટનામાં યોગ્ય રીતે વર્તે કે જે ઓવરફ્લો અથવા અંડરફ્લો થાય (દા.ત. BorrowRef::new જુઓ).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` ધરાવતું નવું `RefCell` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// આવરિત મૂલ્ય પરત કરીને, `RefCell` લે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // આ કાર્ય મૂલ્ય દ્વારા `self` (`RefCell`) લે છે, કમ્પાઇલર સ્થિર રૂપે ખાતરી કરે છે કે તે હાલમાં ઉધાર લીધું નથી.
        //
        self.value.into_inner()
    }

    /// વીંટાળેલા મૂલ્યને નવી સાથે બદલીને, એક પણ મૂલ્યને કાinી નાખ્યાં વિના, જૂની કિંમત પરત કરી.
    ///
    ///
    /// આ ફંક્શન [`std::mem::replace`](../mem/fn.replace.html) ને અનુરૂપ છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં ઉધાર લેવામાં આવી છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// `f` માંથી ગણતરી કરેલ નવી સાથે બદલાયેલ મૂલ્યને બદલીને, એક પણ મૂલ્યનું નિર્દેશન કર્યા વિના, જૂની કિંમત પરત કરી.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં ઉધાર લેવામાં આવી છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// એક પણ ડિનિટીલાઈઝ કર્યા વિના, `other` ની આવરિત કિંમત સાથે `self` ની આવરિત કિંમત અદલાબદલી.
    ///
    ///
    /// આ ફંક્શન [`std::mem::swap`](../mem/fn.swap.html) ને અનુરૂપ છે.
    ///
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// તરત જ આવરિત મૂલ્ય ઉધાર લે છે.
    ///
    /// પાછા આપેલા `Ref` અવકાશમાંથી બહાર નીકળી જાય ત્યાં સુધી orrowણ ચાલે છે.
    /// તે જ સમયે બહુવિધ બદલી ઉધાર લઈ શકાય છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં પરસ્પર ઉધાર લેવામાં આવી છે.
    /// નicન-પેનિકિંગ વેરિઅન્ટ માટે, [`try_borrow`](#method.try_borrow) નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// ઝેડ 0 પicનિકિક ઝેડનું ઉદાહરણ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// તાત્કાલિક આવરિત મૂલ્ય ઉધાર લે છે, જો મૂલ્ય હાલમાં પરસ્પર ઉધાર લેવામાં આવ્યું હોય તો ભૂલ પાછો.
    ///
    ///
    /// પાછા આપેલા `Ref` અવકાશમાંથી બહાર નીકળી જાય ત્યાં સુધી orrowણ ચાલે છે.
    /// તે જ સમયે બહુવિધ બદલી ઉધાર લઈ શકાય છે.
    ///
    /// આ [`borrow`](#method.borrow) નો નોન-પેનિકિંગ વેરિઅન્ટ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // સલામતી: `BorrowRef` ખાતરી કરે છે કે ત્યાં ફક્ત પરિવર્તનશીલ accessક્સેસ છે
            // ઉધાર લેતી વખતે કિંમત.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// પરિવર્તન આવરિત મૂલ્ય ઉધાર લે છે.
    ///
    /// ઉધાર પાછું `RefMut` અથવા તેમાંથી નીકળેલા બધા `RefMut`s અવકાશમાંથી બહાર નીકળે ત્યાં સુધી ચાલે છે.
    ///
    /// જ્યારે આ orrowણ સક્રિય હોય ત્યારે મૂલ્ય ઉધાર લઈ શકાતું નથી.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં ઉધાર લેવામાં આવી છે.
    /// નicન-પેનિકિંગ વેરિઅન્ટ માટે, [`try_borrow_mut`](#method.try_borrow_mut) નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// ઝેડ 0 પicનિકિક ઝેડનું ઉદાહરણ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// પરિવર્તનીય રીતે વીંટેલું મૂલ્ય ઉધાર લે છે, જો મૂલ્ય હાલમાં ઉધાર લેવામાં આવ્યું હોય તો ભૂલ પાછો.
    ///
    ///
    /// ઉધાર પાછું `RefMut` અથવા તેમાંથી નીકળેલા બધા `RefMut`s અવકાશમાંથી બહાર નીકળે ત્યાં સુધી ચાલે છે.
    /// જ્યારે આ orrowણ સક્રિય હોય ત્યારે મૂલ્ય ઉધાર લઈ શકાતું નથી.
    ///
    /// આ [`borrow_mut`](#method.borrow_mut) નો નોન-પેનિકિંગ વેરિઅન્ટ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // સલામતી: `BorrowRef` અનન્ય વપરાશની બાંયધરી આપે છે.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// આ કોષમાં અંતર્ગત ડેટા પર કાચો પોઇન્ટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// અંતર્ગત ડેટા માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// આ ક callલ પરિવર્તનીય `RefCell` ઉધાર લે છે (કમ્પાઇલ સમયે) જેથી ગતિશીલ તપાસની કોઈ જરૂર નથી.
    ///
    /// જો કે સાવચેત રહો: આ પદ્ધતિ `self` પરિવર્તનશીલ થવાની અપેક્ષા રાખે છે, જે `RefCell` નો ઉપયોગ કરતી વખતે સામાન્ય રીતે કેસ નથી.
    ///
    /// જો `self` પરિવર્તનશીલ ન હોય તો તેના બદલે [`borrow_mut`] પદ્ધતિ પર એક નજર નાખો.
    ///
    /// ઉપરાંત, કૃપા કરીને ધ્યાન રાખો કે આ પદ્ધતિ ફક્ત વિશેષ સંજોગો માટે છે અને સામાન્ય રીતે તમે ઇચ્છો તે હોતી નથી.
    /// શંકાના કિસ્સામાં, તેના બદલે [`borrow_mut`] નો ઉપયોગ કરો.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` ની bણ રાજ્ય પર લીક થયેલા રક્ષકોની અસરને પૂર્વવત્ કરો.
    ///
    /// આ ક callલ [`get_mut`] જેવો જ છે પરંતુ વધુ વિશિષ્ટ.
    /// કોઈ ઉધાર અસ્તિત્વમાં નથી તે સુનિશ્ચિત કરવા માટે તે `RefCell` પરસ્પર ઉધાર લે છે અને તે પછી શેર કરેલા orrowણની રાજ્ય ટ્રેકિંગને ફરીથી સેટ કરે છે.
    /// આ સુસંગત છે જો કેટલાક `Ref` અથવા `RefMut` ઉધાર લીક થયા હોય.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// તાત્કાલિક આવરિત મૂલ્ય ઉધાર લે છે, જો મૂલ્ય હાલમાં પરસ્પર ઉધાર લેવામાં આવ્યું હોય તો ભૂલ પાછો.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` થી વિપરીત, આ પદ્ધતિ અસુરક્ષિત છે કારણ કે તે `Ref` પરત કરતી નથી, આમ ઉધાર ધ્વજને અવ્યવસ્થિત છોડી દે છે.
    /// પરિવર્તનશીલ `RefCell` ઉધાર લેતી વખતે જ્યારે આ પદ્ધતિ દ્વારા પરત કરવામાં આવેલ સંદર્ભ જીવંત છે તે અસ્પષ્ટ વર્તન છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // સલામતી: અમે તપાસીએ છીએ કે હવે કોઈ સક્રિય રીતે લખતું નથી, પરંતુ તે છે
            // કlerલરની ખાતરી કરવાની ખાતરી છે કે પરત સંદર્ભ હવે ઉપયોગમાં ન આવે ત્યાં સુધી કોઈ લખતું નથી.
            // ઉપરાંત, `self.value.get()` એ `self` ની માલિકીની કિંમતનો ઉલ્લેખ કરે છે અને તેથી `self` ના જીવનકાળ માટે માન્ય હોવાની બાંયધરી આપવામાં આવે છે.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// તેની જગ્યાએ `Default::default()` છોડીને, આવરિત મૂલ્ય લે છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં ઉધાર લેવામાં આવી છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics જો કિંમત હાલમાં પરસ્પર ઉધાર લેવામાં આવી છે.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// ટી માટેના `Default` મૂલ્ય સાથે, એક `RefCell<T>` બનાવે છે.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો ક્યાં તો `RefCell` માંનું મૂલ્ય ઉધાર લીધું છે.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ઉધારમાં વધારો આ કેસોમાં બિન-વાંચન મૂલ્ય (<=0) માં પરિણમી શકે છે:
            // 1. તે <0 હતું, એટલે કે ત્યાં લેખન ઉધાર છે, તેથી અમે ઝેડ રસ્ટ0 ઝેડના સંદર્ભ અલીસીંગના નિયમોને લીધે વાંચી ઉધારની મંજૂરી આપી શકતા નથી
            // 2.
            // તે isize::MAX (readingણ લેવાની મહત્તમ રકમ) હતી અને તે isize::MIN (લેખન ઉધારની મહત્તમ રકમ) માં ઓવરફ્લો થઈ ગઈ તેથી અમે વધારાના વાંચનના orrowણની મંજૂરી આપી શકતા નથી કારણ કે ઇસાઇઝ ઘણા વાંચેલા orrowણનું પ્રતિનિધિત્વ કરી શકતું નથી (આ ફક્ત ત્યારે જ થઈ શકે છે જો તમે constant રેફ`સ, જે સારી પ્રથા નથી, ના નાના સતત જથ્થા કરતા વધુ mem::forget કરો છો)
            //
            //
            //
            //
            None
        } else {
            // ઉધારમાં વધારો આ કેસોમાં વાંચન મૂલ્ય (> 0) માં પરિણમી શકે છે:
            // 1. તે=0 હતું, એટલે કે તે ઉધાર લેવામાં આવ્યું ન હતું, અને અમે પ્રથમ વાંચેલ orrowણ લઈ રહ્યા છીએ
            // 2. તે> 0 અને <isize::MAX, એટલે કે હતું
            // ત્યાં readણ વાંચેલા હતા, અને ઇસાઇઝ એટલું મોટું છે કે તે એક વધુ વાંચેલા orrowણનું પ્રતિનિધિત્વ કરે
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // આ સંદર્ભ અસ્તિત્વમાં હોવાથી, આપણે જાણીએ છીએ ઉધાર ધ્વજ એ વાંચનનું orrowણ છે.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // લેખન orrowણમાં ઉભરાતાં ઉધાર કાઉન્ટરને રોકો.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` બ inક્સમાં aણ લેવાયેલા મૂલ્યના સંદર્ભમાં લપેટી.
/// `RefCell<T>` થી અસ્થિર ઉધાર આપેલા મૂલ્ય માટેનો રેપર પ્રકાર.
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// એક `Ref` ની નકલો.
    ///
    /// `RefCell` પહેલાથી જ સ્થિર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `Ref::clone(...)` તરીકે કરવાની જરૂર છે.
    /// `Clone` અમલીકરણ અથવા કોઈ પદ્ધતિ `RefCell` ના સમાવિષ્ટોને ક્લોન કરવા માટે `r.borrow().clone()` ના વ્યાપક ઉપયોગમાં દખલ કરશે.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// ઉધાર લીધેલા ડેટાના ઘટક માટે નવું `Ref` બનાવે છે.
    ///
    /// `RefCell` પહેલાથી જ સ્થિર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `Ref::map(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ઉધાર લીધેલા ડેટાના વૈકલ્પિક ઘટક માટે નવું `Ref` બનાવે છે.
    /// મૂળ રક્ષક `Err(..)` તરીકે પરત આવે છે જો બંધ જો `None` આપે છે.
    ///
    /// `RefCell` પહેલાથી જ સ્થિર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `Ref::filter_map(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ઉધારિત ડેટાના વિવિધ ઘટકો માટે એક `Ref` ને બહુવિધ `રેફ્સમાં વિભાજીત કરે છે.
    ///
    /// `RefCell` પહેલાથી જ સ્થિર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `Ref::map_split(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// અંતર્ગત ડેટાના સંદર્ભમાં રૂપાંતરિત કરો.
    ///
    /// અંતર્ગત `RefCell` ક્યારેય પરસ્પર ફરીથી ઉધાર લઈ શકાતો નથી અને તે હંમેશા પહેલેથી જ ઉધાર લીધેલ દેખાશે.
    ///
    /// સંદર્ભોની સતત સંખ્યા કરતા વધુ લીક કરવું એ સારો વિચાર નથી.
    /// જો માત્ર એક નાની સંખ્યામાં જ લિક આવી હોય તો `RefCell` ફરીથી સ્થિર રીતે ફરીથી ઉધાર લઈ શકાય છે.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `Ref::leak(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // આ રેફને ભૂલીને અમે સુનિશ્ચિત કરીએ છીએ કે રેફસેલમાંનો ઉધાર કાઉન્ટર આજીવન `'b` ની અંદર યુઝેડ પર પાછા જઈ શકશે નહીં.
        // સંદર્ભ ટ્રેકિંગ સ્થિતિને ફરીથી સેટ કરવા માટે, ઉધાર લીધેલા રેફસેલનો અનન્ય સંદર્ભ આવશ્યક છે.
        // મૂળ કોષમાંથી આગળ કોઈ પરિવર્તનશીલ સંદર્ભો બનાવી શકાતા નથી.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// ઉધારિત ડેટાના ઘટક માટે નવું `RefMut` બનાવે છે, દા.ત., એક ઇનોમ વેરિઅન્ટ.
    ///
    /// `RefCell` પહેલાથી પરસ્પર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `RefMut::map(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ઉધાર-ચેકને ઠીક કરો
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ઉધાર લીધેલા ડેટાના વૈકલ્પિક ઘટક માટે નવું `RefMut` બનાવે છે.
    /// મૂળ રક્ષક `Err(..)` તરીકે પરત આવે છે જો બંધ જો `None` આપે છે.
    ///
    /// `RefCell` પહેલાથી પરસ્પર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `RefMut::filter_map(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ઉધાર-ચેકને ઠીક કરો
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // સલામતી: કાર્યકાળ સમયગાળા માટે એક વિશિષ્ટ સંદર્ભ ધરાવે છે
        // તેના ક callલના `orig` દ્વારા, અને નિર્દેશક ફક્ત ફંક્શન ક ofલની અંદરના જ ડે-રેફરન્ડેડ છે જે ક્યારેય વિશિષ્ટ સંદર્ભને છટકી શકશે નહીં.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // સલામતી: ઉપરની જેમ.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ઉધાર લીધેલા ડેટાના વિવિધ ઘટકો માટે એક `RefMut` ને બહુવિધ `RefMut`s માં વિભાજીત કરે છે.
    ///
    /// જ્યાં સુધી બંને પરત નહીં આવે ત્યાં સુધી અંતર્ગત `RefCell` પરસ્પર ઉધાર રહેશે `રિફમ્યુટ્સ અવકાશની બહાર નહીં જાય.
    ///
    /// `RefCell` પહેલાથી પરસ્પર ઉધાર લેવામાં આવ્યું છે, તેથી આ નિષ્ફળ થઈ શકશે નહીં.
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `RefMut::map_split(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// અંતર્ગત ડેટાના પરિવર્તનશીલ સંદર્ભમાં રૂપાંતરિત કરો.
    ///
    /// અંતર્ગત `RefCell` ફરીથી ઉધાર લઈ શકાશે નહીં અને હંમેશાં પરસ્પર ઉધાર લીધેલ દેખાશે, વળતર સંદર્ભને ફક્ત આંતરિક ભાગમાં જ બનાવે છે.
    ///
    ///
    /// આ એક સંકળાયેલ કાર્ય છે જેનો ઉપયોગ `RefMut::leak(...)` તરીકે કરવાની જરૂર છે.
    /// `Deref` દ્વારા ઉપયોગમાં લેવામાં આવતી `RefCell` ની સામગ્રી પર એક જ નામની પદ્ધતિઓમાં કોઈ પદ્ધતિ દખલ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // આ બોરોરેફમેટને ભૂલીને અમે ખાતરી કરીએ છીએ કે રેફસેલમાંનો ઉધાર કાઉન્ટર, આજીવન `'b` ની અંદર UNUSED પર પાછા જઈ શકશે નહીં.
        // સંદર્ભ ટ્રેકિંગ સ્થિતિને ફરીથી સેટ કરવા માટે, ઉધાર લીધેલા રેફસેલનો અનન્ય સંદર્ભ આવશ્યક છે.
        // તે જીવનકાળમાં મૂળ કોષમાંથી આગળ કોઈ સંદર્ભો બનાવી શકાતા નથી, બાકીના જીવનકાળ માટે વર્તમાન ઉધારને એકમાત્ર સંદર્ભ બનાવે છે.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone થી વિપરીત, પ્રારંભિક બનાવવા માટે નવા કહેવામાં આવે છે
        // પરિવર્તનશીલ સંદર્ભ, અને તેથી હાલમાં કોઈ અસ્તિત્વમાં નથી.
        // આમ, ક્લોન વૃદ્ધિ પરિવર્તનીય રિ-કાઉન્ટ, જ્યારે અમે સ્પષ્ટપણે ફક્ત યુએસયુએસડીથી યુઝેડ, 1 પર જવાની મંજૂરી આપીએ છીએ.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ક્લોન્સ એક `BorrowRefMut`.
    //
    // આ ફક્ત ત્યારે જ માન્ય છે જો દરેક `BorrowRefMut` નો ઉપયોગ મૂળ ofબ્જેક્ટની અલગ, નોનઓવરલેપિંગ શ્રેણીના પરિવર્તનીય સંદર્ભને ટ્ર trackક કરવા માટે થાય છે.
    //
    // આ ક્લોન પ્રોત્સાહનમાં નથી તેથી તે કોડ આને સ્પષ્ટ રીતે ક callલ કરશે નહીં.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // ઉધારમાંથી કાઉન્ટર કાઉન્ટરને રોકો.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` થી પરસ્પર ઉધાર આપેલા મૂલ્ય માટેનો રેપર પ્રકાર.
///
/// વધુ માટે [module-level documentation](self) જુઓ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// ઝેડ રસ્ટ0 ઝેડમાં આંતરિક પરિવર્તન માટેનો મુખ્ય આદિમ.
///
/// જો તમારી પાસે સંદર્ભ `&T` છે, તો સામાન્ય રીતે Rust માં કમ્પાઈલર એ જ્ knowledgeાનના આધારે izપ્ટિમાઇઝેશન કરે છે જે `&T` સ્થાવર ડેટાને નિર્દેશ કરે છે.તે ડેટાને મ્યુટિએટ કરવું, ઉદાહરણ તરીકે ઉપનામ દ્વારા અથવા `&T` ને `&mut T` માં ટ્રાન્સમિટ કરીને, અસ્પષ્ટ વર્તન માનવામાં આવે છે.
/// `UnsafeCell<T>` `&T` માટે અપરિવર્તનક્ષમતાની બાંયધરીને પસંદ કરી શકશો નહીં: એક વહેંચાયેલ સંદર્ભ `&UnsafeCell<T>` એ ડેટાને નિર્દેશિત કરી શકે છે જે પરિવર્તિત થઈ રહ્યો છે.આને "interior mutability" કહેવામાં આવે છે.
///
/// અન્ય તમામ પ્રકારો કે જે `Cell<T>` અને `RefCell<T>` જેવા આંતરિક પરિવર્તનની મંજૂરી આપે છે, તેમનો ડેટા લપેટવા માટે આંતરિક રીતે `UnsafeCell` નો ઉપયોગ કરે છે.
///
/// નોંધ લો કે શેર કરેલા સંદર્ભો માટેની માત્ર અમરતાની ગેરંટી `UnsafeCell` દ્વારા અસરગ્રસ્ત છે.પરિવર્તનીય સંદર્ભો માટેની વિશિષ્ટતાની બાંયધરી અસર ન કરે.એલીસીંગ `&mut` મેળવવાનો *કોઈ* કાનૂની માર્ગ નથી, `UnsafeCell<T>` સાથે પણ નથી.
///
/// `UnsafeCell` API એ તકનીકી રૂપે ખૂબ જ સરળ છે: [`.get()`] તમને તેના સમાવિષ્ટોમાં એક કાચો નિર્દેશક `*mut T` આપે છે.તે કાચા પોઇન્ટરને યોગ્ય રીતે વાપરવા માટે એબ્સ્ટ્રેક્શન ડિઝાઇનર તરીકે _you_ સુધી છે.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// ચોક્કસ ઝેડ 0 રસ્ટ0 ઝેડ એલિઅસીંગ નિયમો અંશે પ્રવાહમાં છે, પરંતુ મુખ્ય મુદ્દા વિરોધાભાસી નથી:
///
/// - જો તમે આજીવન `'a` (ક્યાં તો `&T` અથવા `&mut T` સંદર્ભ) સાથે સલામત સંદર્ભ બનાવો છો જે સલામત કોડ દ્વારા એક્સેસ કરી શકાય છે (ઉદાહરણ તરીકે, તમે તેને પાછું કર્યું છે), તો તમારે ડેટાને કોઈપણ રીતે notક્સેસ કરવી જોઈએ નહીં કે જે બાકીના સંદર્ભ માટે વિરોધાભાસી છે. `'a` નું.
/// ઉદાહરણ તરીકે, આનો અર્થ એ છે કે જો તમે `UnsafeCell<T>` થી `*mut T` લો અને તેને `&T` પર કાસ્ટ કરો, તો પછી `T` માંનો ડેટા અવ્યવસ્થિત રહેવો જ જોઇએ (`T` ની અંદરનો કોઈપણ `UnsafeCell` ડેટા મોડ્યુલો જ જોઈએ) જ્યાં સુધી તે સંદર્ભનો સમયગાળો સમાપ્ત ન થાય ત્યાં સુધી.
/// એ જ રીતે, જો તમે કોઈ `&mut T` સંદર્ભ બનાવો કે જે સુરક્ષિત કોડ પર પ્રકાશિત થયો છે, તો તમારે તે સંદર્ભ સમાપ્ત થાય ત્યાં સુધી `UnsafeCell` ની અંદર ડેટા accessક્સેસ કરવો જોઈએ નહીં.
///
/// - બધા સમયે, તમારે ડેટા રેસ ટાળવી આવશ્યક છે.જો બહુવિધ થ્રેડો સમાન `UnsafeCell` ની haveક્સેસ ધરાવે છે, તો પછી કોઈપણ લખાણોને યોગ્ય રીતે થવું આવશ્યક છે-અન્ય તમામ એક્સેસ (અથવા એટોમિક્સનો ઉપયોગ) ના સંબંધ પહેલાં.
///
/// યોગ્ય રચનામાં સહાય કરવા માટે, નીચેના સંજોગોને સિંગલ-થ્રેડેડ કોડ માટે સ્પષ્ટપણે કાનૂની જાહેર કરવામાં આવ્યા છે:
///
/// 1. એક `&T` સંદર્ભ સુરક્ષિત કોડ પર પ્રકાશિત કરી શકાય છે અને ત્યાં તે અન્ય `&T` સંદર્ભો સાથે સહ અસ્તિત્વ ધરાવે છે, પરંતુ `&mut T` સાથે નહીં
///
/// 2. સલામત કોડ પર એક `&mut T` સંદર્ભ પ્રકાશિત થઈ શકે છે જો કે તેની સાથે અન્ય `&mut T` અથવા `&T` સહ-અસ્તિત્વમાં ન હોય.એક `&mut T` હંમેશા અનન્ય હોવા જોઈએ.
///
/// નોંધ લો કે જ્યારે `&UnsafeCell<T>` ના સમાવિષ્ટોમાં પરિવર્તન કરવું (અન્ય `&UnsafeCell<T>` સંદર્ભ ઉર્ફે સેલ હોવા છતાં) બરાબર છે (જો તમે ઉપરોક્ત આક્રમણકારોને કોઈ અન્ય રીતે અમલમાં મૂકો), તો બહુવિધ `&mut UnsafeCell<T>` ઉપનામો રાખવા તે હજી પણ અસ્પષ્ટ વર્તન છે.
/// તે છે, `UnsafeCell` એ એક રેપર છે જે _shared_ accesses (_i.e._ સાથે વિશિષ્ટ ક્રિયાપ્રતિક્રિયા માટે બનાવવામાં આવ્યું છે, `&UnsafeCell<_>` સંદર્ભ દ્વારા);_exclusive_ accesses (_e.g._ સાથે કામ કરતી વખતે, કોઈ `&mut UnsafeCell<_>` દ્વારા) ત્યાં કોઈ જાદુ નથી: સેલ કે આવરિત મૂલ્ય, તે `&mut` ઉધારની અવધિ માટે બદલી શકાય નહીં.
///
/// આ [`.get_mut()`] એક્સેસર દ્વારા પ્રદર્શિત કરવામાં આવ્યું છે, જે _safe_ getter છે જે `&mut T` આપે છે.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// અહીં એક ઉદાહરણ બતાવવામાં આવ્યું છે કે સેલને અલગ પાડતા અનેક સંદર્ભ હોવા છતાં, `UnsafeCell<_>` ની સામગ્રીને કેવી રીતે અવાજથી બદલી શકાય છે:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // સમાન `x` પર બહુવિધ/સહવર્તી/વહેંચાયેલા સંદર્ભો મેળવો.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // સલામતી: આ અવકાશની અંદર `x` ના સમાવિષ્ટો માટે અન્ય કોઈ સંદર્ભો નથી,
///     // તેથી આપણું અસરકારક રીતે અનન્ય છે.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ઉધાર-+
///     *p1_exclusive += 27; // |
/// } // <---------- આ મુદ્દાથી આગળ વધી શકશે નહીં -------------------+
///
/// unsafe {
///     // સલામતી: આ અવકાશમાં કોઈને પણ `x` ની સામગ્રીની વિશિષ્ટ પ્રવેશની અપેક્ષા નથી,
///     // જેથી આપણે એક સાથે અનેક વહેંચણી એક્સેસ કરી શકીએ.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// નીચેનું ઉદાહરણ એ હકીકતને બતાવે છે કે `UnsafeCell<T>` ની વિશિષ્ટ itsક્સેસ તેના `T` ની વિશિષ્ટ impક્સેસ સૂચવે છે:
///
/// ```rust
/// #![forbid(unsafe_code)] // વિશિષ્ટ એક્સેસ સાથે,
///                         // `UnsafeCell` એક પારદર્શક નો-wraપ રેપર છે, તેથી અહીં `unsafe` ની જરૂર નથી.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` નો કમ્પાઈલ-ટાઇમ-ચેક કરેલ અનન્ય સંદર્ભ મેળવો.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // એક વિશિષ્ટ સંદર્ભ સાથે, અમે આ સામગ્રીને મફતમાં ફેરવી શકીએ છીએ.
/// *p_unique.get_mut() = 0;
/// // અથવા, સમાનરૂપે:
/// x = UnsafeCell::new(0);
///
/// // જ્યારે અમારી પાસે મૂલ્ય હોય, ત્યારે અમે આ સામગ્રી મફતમાં કા canી શકીએ છીએ.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` નું નવું ઉદાહરણ બનાવે છે જે નિર્દિષ્ટ મૂલ્યને વીંટાળશે.
    ///
    ///
    /// પદ્ધતિઓ દ્વારા આંતરિક મૂલ્યની બધી Xક્સેસ `unsafe` છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// મૂલ્યને સમાપ્ત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// આવરિત મૂલ્ય માટે પરિવર્તનીય નિર્દેશક મેળવે છે.
    ///
    /// આ કોઈપણ પ્રકારનાં નિર્દેશક પર કાસ્ટ કરી શકાય છે.
    /// `&mut T` પર કાસ્ટિંગ કરતી વખતે uniqueક્સેસ અનન્ય છે (કોઈ સક્રિય સંદર્ભો, પરિવર્તનીય છે કે નહીં) તેની ખાતરી કરો અને ખાતરી કરો કે `&T` પર કાસ્ટ કરતી વખતે કોઈ પરિવર્તન અથવા પરિવર્તનશીલ ઉપનામ નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] ના કારણે આપણે `UnsafeCell<T>` થી `T` પર નિર્દેશક કાસ્ટ કરી શકીએ છીએ.
        // આ લિબસ્ટ્ડની વિશેષ સ્થિતિનો ઉપયોગ કરે છે, વપરાશકર્તા કોડ માટેની કોઈ ગેરેંટી નથી કે આ કમ્પાઇલરના ઝેડ 0 ફ્યુચર0 ઝેડ સંસ્કરણોમાં કાર્ય કરશે!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// અંતર્ગત ડેટા માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// આ ક callલ `UnsafeCell` પરસ્પર ઉધાર લે છે (કમ્પાઇલ સમયે) જે ખાતરી આપે છે કે અમારી પાસે એકમાત્ર સંદર્ભ છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// આવરિત મૂલ્ય માટે પરિવર્તનીય નિર્દેશક મેળવે છે.
    /// [`get`] માં તફાવત એ છે કે આ કાર્ય કાચા પોઇન્ટરને સ્વીકારે છે, જે કામચલાઉ સંદર્ભોની રચનાને ટાળવા માટે ઉપયોગી છે.
    ///
    /// પરિણામ કોઈપણ પ્રકારનાં નિર્દેશકને આપી શકાય છે.
    /// `&mut T` પર કાસ્ટિંગ કરતી વખતે uniqueક્સેસ અનન્ય છે (કોઈ સક્રિય સંદર્ભો, પરિવર્તનીય છે કે નહીં) તેની ખાતરી કરો અને ખાતરી કરો કે `&T` પર કાસ્ટ કરતી વખતે કોઈ પરિવર્તન અથવા પરિવર્તનશીલ ઉપનામ નથી.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` ના ક્રમિક પ્રારંભિકકરણ માટે `raw_get` ની જરૂર પડે છે, કેમ કે `get` ને ક callingલ કરવાથી અનહિતીકૃત ડેટાનો સંદર્ભ બનાવવો જરૂરી છે:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] ના કારણે આપણે `UnsafeCell<T>` થી `T` પર નિર્દેશક કાસ્ટ કરી શકીએ છીએ.
        // આ લિબસ્ટ્ડની વિશેષ સ્થિતિનો ઉપયોગ કરે છે, વપરાશકર્તા કોડ માટેની કોઈ ગેરેંટી નથી કે આ કમ્પાઇલરના ઝેડ 0 ફ્યુચર0 ઝેડ સંસ્કરણોમાં કાર્ય કરશે!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// ટી માટેના `Default` મૂલ્ય સાથે, એક `UnsafeCell` બનાવે છે.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}