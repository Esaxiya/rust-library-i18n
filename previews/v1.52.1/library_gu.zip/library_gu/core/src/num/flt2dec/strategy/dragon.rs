//! "પ્રિન્ટિંગ ફ્લોટિંગ-પોઇન્ટ નંબર ઝડપથી અને સચોટ રીતે" [^ 1] ના આકૃતિ 3 નો લગભગ સીધો (પરંતુ સહેજ optimપ્ટિમાઇઝ) ઝેડ 0 રસ્ટ0 ઝેડ અનુવાદ.
//!
//!
//! [^1]: Burger, આરજી અને ડાયબવિગ, આરકે 1996. ફ્લોટિંગ-પોઇન્ટ નંબરો છાપવા
//!   ઝડપથી અને સચોટ.સિગપ્લેન નહીં.31, 5 (મે. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) માટે `અંકોની પૂર્વનિર્ધારિત એરે
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// માત્ર ત્યારે જ ઉપયોગી છે જ્યારે `x < 16 * scale`;`scaleN` `scale.mul_small(N)` હોવું જોઈએ
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ડ્રેગન માટે ટૂંકી મોડ અમલીકરણ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ફોર્મેટમાં `v` નંબર હોવાનું જાણીતું છે:
    // - `mant * 2^exp` ની બરાબર;
    // - મૂળ પ્રકારમાં `(mant - 2 *minus)* 2^exp` દ્વારા પહેલા;અને
    // - પછી મૂળ પ્રકારમાં `(mant + 2 *plus)* 2^exp`.
    //
    // દેખીતી રીતે, `minus` અને `plus` શૂન્ય ન હોઈ શકે.(અનિષ્ટો માટે, અમે મર્યાદિત મૂલ્યોનો ઉપયોગ કરીએ છીએ.) પણ આપણે ધારીએ છીએ કે ઓછામાં ઓછો એક અંક ઉત્પન્ન થાય છે, એટલે કે,`minus` પણ શૂન્ય ન હોઈ શકે.
    //
    // આનો અર્થ એ પણ છે કે `low = (mant - minus)*2^exp` અને `high = (mant + plus)* 2^exp` વચ્ચેની કોઈપણ સંખ્યા, આ મૂળ ફ્લોટિંગ પોઇન્ટ નંબર પર નકશો, જ્યારે મૂળ મ mantન્ટિસા પણ હતી (એટલે કે, `!mant_was_odd`) જ્યારે સમાવિષ્ટ સીમાઓ સાથે.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` છે
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` સંતોષતા મૂળ ઇનપુટ્સમાંથી `k_0` નો અંદાજ લગાવો.
    // ચુસ્ત બાઉન્ડ `k` સંતોષકારક `10^(k-1) < high <= 10^k` પછીથી ગણવામાં આવે છે.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` ને અપૂર્ણાંક સ્વરૂપમાં રૂપાંતરિત કરો જેથી:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` દ્વારા `mant` ને વિભાજીત કરો.હવે `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // જ્યારે `mant + plus > scale` (અથવા `>=`) ફિક્સઅપ.
    // અમે ખરેખર `scale` ને સુધારી રહ્યા નથી, કારણ કે આપણે તેના બદલે પ્રારંભિક ગુણાકાર છોડી શકીએ છીએ.
    // હવે `scale < mant + plus <= scale * 10` અને અમે અંકો ઉત્પન્ન કરવા માટે તૈયાર છીએ.
    //
    // નોંધો કે `d[0]` * શૂન્ય હોઈ શકે છે, જ્યારે `scale - plus < mant < scale`.
    // આ કિસ્સામાં રાઉન્ડિંગ-અપ શરત (નીચે `up`) તરત જ ટ્રિગર થઈ જશે.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 દ્વારા `scale` સ્કેલિંગની સમકક્ષ
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // અંક જનરેશન માટે કેશ `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // આક્રમણો, જ્યાં `d[0..n-1]` એ અત્યાર સુધીમાં બનાવેલા અંકો છે:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (આમ `mant / scale < 10`) જ્યાં `d[i..j]` એ `d [i] * 10 ^ (જી) માટે ટૂંકું લખાણ છે ... ...
        // + ડી [j-1] * 10 + d[j]`.

        // એક અંક ઉત્પન્ન કરો: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // આ સંશોધિત ડ્રેગન એલ્ગોરિધમનો સરળ વર્ણન છે.
        // ઘણી મધ્યવર્તી વ્યુત્પત્તિઓ અને સંપૂર્ણતા દલીલો સગવડ માટે અવગણવામાં આવે છે.
        //
        // સુધારેલા આક્રમણકારોથી પ્રારંભ કરો, જેમકે આપણે `n` ને અપડેટ કર્યું છે:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ધારો કે `d[0..n-1]` એ `low` અને `high` વચ્ચેની ટૂંકી રજૂઆત છે, એટલે કે, `d[0..n-1]` નીચેના બંનેને સંતોષે છે પરંતુ `d[0..n-2]` તે નથી કરતું:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (દ્વિપક્ષીતા: `v` સુધીના અંકો);અને
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (છેલ્લો આંકડો સાચો છે).
        //
        // બીજી શરત `2 * mant <= scale` ને સરળ બનાવે છે.
        // `mant`, `low` અને `high` ની દ્રષ્ટિએ આક્રમણોને હલ કરવાથી પ્રથમ શરતનું સરળ સંસ્કરણ મળે છે: `-plus < mant < minus`.
        // `-plus < 0 <= mant` થી, જ્યારે `mant < minus` અને `2 * mant <= scale` હોય ત્યારે આપણી પાસે ટૂંકી ટૂંકી રજૂઆત છે.
        // (મૂળ મેન્ટિસા સમાન હોય ત્યારે અગાઉનું `mant <= minus` બને છે.)
        //
        // જ્યારે બીજું (`2 * મન્ટ> સ્કેલ`) ધરાવે નથી, ત્યારે અમારે છેલ્લો આંકડો વધારવાની જરૂર છે.
        // આ સ્થિતિને પુનર્સ્થાપિત કરવા માટે આ પર્યાપ્ત છે: આપણે પહેલેથી જ જાણીએ છીએ કે અંક પે generationી `0 <= v / 10^(k-n) - d[0..n-1] < 1` ની ખાતરી આપે છે.
        // આ કિસ્સામાં, પ્રથમ શરત `-plus < mant - scale < minus` બને છે.
        // જનરેશન પછી `mant < scale` થી, અમારી પાસે `scale < mant + plus` છે.
        // (ફરીથી, મૂળ મેન્ટિસા સમાન હોય ત્યારે આ `scale <= mant + plus` બને છે.)
        //
        // ટૂંક માં:
        // - જ્યારે `mant < minus` (અથવા `<=`) હોય ત્યારે `down` ને રોકો અને રાઉન્ડ (જેમ કે અંકોની જેમ રાખો).
        // - જ્યારે `scale < mant + plus` (અથવા `<=`) ત્યારે `up` ને રોકો અને અંતિમ અંક વધારો.
        // - નહિંતર પેદા કરવાનું ચાલુ રાખો.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // અમારી ટૂંકી રજૂઆત છે, રાઉન્ડિંગમાં આગળ વધો

        // આક્રમણકારોને પુનર્સ્થાપિત કરો.
        // આ હંમેશા અલ્ગોરિધમનો સમાપ્ત કરે છે: `minus` અને `plus` હંમેશા વધે છે, પરંતુ `mant` મોડ્યુલો `scale` ક્લિપ થયેલ છે અને `scale` નિશ્ચિત છે.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // રાઉન્ડિંગ અપ થાય છે જ્યારે i) ફક્ત રાઉન્ડિંગ-અપ શરત ચાલુ કરવામાં આવી હતી, અથવા ii) બંને શરતો ટ્રિગર થઈ હતી અને ટાઇને તોડીને પસંદ કરે છે.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // જો ગોળાકાર અપ લંબાઈ બદલાય છે, તો ઘાતાંક પણ બદલાવશે.
        // એવું લાગે છે કે આ સ્થિતિ સંતોષવા માટે ખૂબ મુશ્કેલ છે (સંભવત impossible અશક્ય), પરંતુ અમે અહીં ફક્ત સલામત અને સુસંગત રહીએ છીએ.
        //
        // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ડ્રેગન માટે ચોક્કસ અને નિશ્ચિત મોડ અમલીકરણ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` સંતોષતા મૂળ ઇનપુટ્સમાંથી `k_0` નો અંદાજ લગાવો.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` દ્વારા `mant` ને વિભાજીત કરો.હવે `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ફિક્સઅપ જ્યારે `mant + plus >= scale`, જ્યાં `plus / scale = 10^-buf.len() / 2`.
    // નિશ્ચિત-કદના બિગનમ રાખવા માટે, અમે ખરેખર `mant + floor(plus) >= scale` નો ઉપયોગ કરીએ છીએ.
    // અમે ખરેખર `scale` ને સુધારી રહ્યા નથી, કારણ કે આપણે તેના બદલે પ્રારંભિક ગુણાકાર છોડી શકીએ છીએ.
    // ફરીથી ટૂંકા ગાણિતીક નિયમો સાથે, `d[0]` શૂન્ય હોઈ શકે છે પરંતુ આખરે તેને ગોળાકાર કરવામાં આવશે.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 દ્વારા `scale` સ્કેલિંગની સમકક્ષ
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // જો આપણે છેલ્લી અંકની મર્યાદા સાથે કામ કરી રહ્યા છીએ, તો ડબલ રાઉન્ડિંગને ટાળવા માટે આપણે વાસ્તવિક રેન્ડરિંગ પહેલાં બફર ટૂંકાવી લેવાની જરૂર છે.
    //
    // નોંધ લો કે જ્યારે રાઉન્ડિંગ થાય ત્યારે આપણે ફરીથી બફરને મોટું કરવું પડશે!
    let mut len = if k < limit {
        // અરેરે, અમે *એક* અંક પણ પેદા કરી શકતા નથી.
        // આ ત્યારે શક્ય છે જ્યારે એમ કહી શકાય કે આપણને 9.5 જેવું કંઈક મળ્યું છે અને તે 10 થઈ ગયું છે.
        // પછીના રાઉન્ડિંગ-અપ કેસના અપવાદ સાથે, અમે ખાલી બફર પાછા કરીએ છીએ, જ્યારે `k == limit` થાય છે અને બરાબર એક અંક ઉત્પન્ન કરવો પડે છે.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // અંક જનરેશન માટે કેશ `(2, 4, 8) * scale`.
        // (આ ખર્ચાળ હોઈ શકે છે, તેથી જ્યારે બફર ખાલી હોય ત્યારે તેમની ગણતરી કરશો નહીં.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // નીચેના અંકો એ બધા શૂન્ય છે, અમે અહીં રોકીએ છીએ *રાઉન્ડિંગ કરવા માટે* પ્રયાસ કરશો નહીં!તેના બદલે, બાકીના અંકો ભરો.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // જો નીચેના અંકો બરાબર are,૦૦૦ હોય તો આપણે અંકોના મધ્યમાં અટકીએ તો રાઉન્ડ અપ કરો ..., પહેલાનો આંકડો તપાસો અને બરાબર (જો કે, પહેલાનો આંકડો સરખો હોય ત્યારે રાઉન્ડ અપ કરવાનું ટાળો) પ્રયાસ કરો.
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // સલામતી: `buf[len-1]` પ્રારંભ થયેલ છે.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // જો ગોળાકાર અપ લંબાઈ બદલાય છે, તો ઘાતાંક પણ બદલાવશે.
        // પરંતુ અમને અંકની નિશ્ચિત સંખ્યાની વિનંતી કરવામાં આવી છે, તેથી બફરને બદલો નહીં ...
        // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... સિવાય કે અમને તેની જગ્યાએ નિશ્ચિત ચોકસાઇની વિનંતી કરવામાં આવશે નહીં.
            // અમારે એ પણ તપાસવાની જરૂર છે કે, જો મૂળ બફર ખાલી હતો, તો `k == limit` (edge કેસ) ત્યારે જ અતિરિક્ત અંકો ઉમેરી શકાશે.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}