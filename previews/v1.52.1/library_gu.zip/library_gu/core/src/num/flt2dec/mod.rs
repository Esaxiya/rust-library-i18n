/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// જ્યારે આનું મોટા પ્રમાણમાં દસ્તાવેજીકરણ કરવામાં આવે છે, ત્યારે આ સિદ્ધાંતરૂપે ખાનગી છે જે ફક્ત પરીક્ષણ માટે સાર્વજનિક કરવામાં આવે છે.
// અમને છતી નહીં કરો.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// અંક-જનરેશન ગાણિતીક નિયમો.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// ટૂંકા મોડ માટે જરૂરી બફરનું ન્યૂનતમ કદ.
///
/// તે મેળવવા માટે થોડું અમૂલ્ય છે, પરંતુ આ ટૂંકા પરિણામો સાથે ફોર્મેટિંગ એલ્ગોરિધમ્સથી મહત્ત્વના દશાંશ અંકોની મહત્તમ સંખ્યા છે.
///
/// ચોક્કસ સૂત્ર `ceil(# bits in mantissa * log_10 2 + 1)` છે.
pub const MAX_SIG_DIGITS: usize = 17;

/// જ્યારે `d` દશાંશ અંકોનો સમાવેશ કરે છે, ત્યારે છેલ્લા અંકમાં વધારો અને કેરીનો પ્રચાર કરો.
/// જ્યારે તે લંબાઈને બદલવા માટેનું કારણ બને ત્યારે આગલું અંકો પરત કરે છે.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] એ બધી નાઇન્સ છે
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 વધેલા ખાતા સાથે 1000..000 સુધીના ગોળાકાર
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ખાલી બફર રાઉન્ડ અપ (થોડી વિચિત્ર પરંતુ વાજબી)
            Some(b'1')
        }
    }
}

/// ફોર્મેટ ભાગો.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// શૂન્ય અંકોની સંખ્યા
    Zero(usize),
    /// 5 અંક સુધીની શાબ્દિક સંખ્યા.
    Num(u16),
    /// આપેલ બાઇટ્સની વર્बટિમ નકલ.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// આપેલ ભાગની ચોક્કસ બાઇટ લંબાઈ પરત કરે છે.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// પૂરા પાડવામાં આવેલા બફરમાં ભાગ લખે છે.
    /// લેખિત બાઇટ્સની સંખ્યા, અથવા બફર પૂરતું ન હોય તો `None` આપે છે.
    /// (તે હજી પણ બફરમાં આંશિક રીતે લખાયેલ બાઇટ્સ છોડી શકે છે; તેના પર આધાર રાખશો નહીં.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// એક અથવા વધુ ભાગો ધરાવતા ફોર્મેટ પરિણામ.
/// આ બાઇટ બફર પર લખી શકાય છે અથવા ફાળવેલ શબ્દમાળામાં કન્વર્ટ કરી શકાય છે.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` અથવા `"+"`, ક્યાં તો નિશાનીનું પ્રતિનિધિત્વ કરતી બાઇટની સ્લાઇસ.
    pub sign: &'static str,
    /// ફોર્મેટ કરેલા ભાગો ચિન્હ પછી રેન્ડર કરવા અને વૈકલ્પિક શૂન્ય ગાદી માટે.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// સંયુક્ત ફોર્મેટ કરેલા પરિણામની ચોક્કસ બાઇટ લંબાઈ પરત કરે છે.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// સપ્લાય કરેલા બફરમાં બધા ફોર્મેટ કરેલા ભાગો લખે છે.
    /// લેખિત બાઇટ્સની સંખ્યા, અથવા બફર પૂરતું ન હોય તો `None` આપે છે.
    /// (તે હજી પણ બફરમાં આંશિક રીતે લખાયેલ બાઇટ્સ છોડી શકે છે; તેના પર આધાર રાખશો નહીં.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// ફોર્મેટ્સમાં દશાંશ અંકો `0.<...buf...> * 10^exp` આપેલ ઓછામાં ઓછા અપૂર્ણાંક અંકોની સંખ્યા સાથે દશાંશ સ્વરૂપમાં આપવામાં આવે છે.
///
/// પરિણામ પૂરા પાડવામાં આવેલા ભાગો એરેમાં સંગ્રહિત કરવામાં આવે છે અને લેખિત ભાગોની સ્લાઇસ પાછો આવે છે.
///
/// `frac_digits` `buf` માં વાસ્તવિક અપૂર્ણાંક અંકોની સંખ્યા કરતા ઓછી હોઈ શકે;
/// તેને અવગણવામાં આવશે અને સંપૂર્ણ અંકો છાપવામાં આવશે.તે ફક્ત રેન્ડર કરેલા અંકો પછી અતિરિક્ત ઝીરો છાપવા માટે વપરાય છે.
/// આમ 0 ના `frac_digits` નો અર્થ છે કે તે ફક્ત આપેલ અંકો જ છાપશે અને બીજું કંઇ નહીં.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // જો છેલ્લા અંકની સ્થિતિ પર પ્રતિબંધ હોય તો, `buf` એ વર્ચુઅલ શૂન્ય સાથે ડાબે-પdedડે હોવાનું માનવામાં આવે છે.
    // વર્ચુઅલ શૂન્યની સંખ્યા, `nzeroes`, `max(0, exp + frac_digits - buf.len())` ની બરાબર છે, જેથી છેલ્લા અંકની `exp - buf.len() - nzeroes` ની સ્થિતિ `-frac_digits` કરતા વધુ ન હોય:
    //
    //
    //                       |<-virtual->|
    //       | <----બફ----> |શૂન્ય |સમાપ્તિ
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ સમાપ્તિ 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ઓવરફ્લો ટાળવા માટે દરેક કેસ માટે વ્યક્તિગત રીતે ગણતરી કરવામાં આવે છે.
    //

    if exp <= 0 {
        // દશાંશ બિંદુ રેન્ડર કરેલા અંકો પહેલાનો છે: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // સલામતી: અમે હમણાં જ `..4` તત્વો પ્રારંભ કર્યા.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // સલામતી: અમે હમણાં જ `..3` તત્વો પ્રારંભ કર્યા.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // દશાંશ બિંદુ એ રેન્ડર કરેલા અંકોની અંદર છે: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // સલામતી: અમે હમણાં જ `..4` તત્વો પ્રારંભ કર્યા.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // સલામતી: અમે હમણાં જ `..3` તત્વો પ્રારંભ કર્યા.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // દશાંશ બિંદુ રેન્ડર કરેલા અંકો પછીનો છે: [1234][____0000] અથવા [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // સલામતી: અમે હમણાં જ `..4` તત્વો પ્રારંભ કર્યા.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // સલામતી: અમે હમણાં જ `..2` તત્વો પ્રારંભ કર્યા.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// આપેલ દશાંશ અંકો `0.<...buf...> * 10^exp` ને ઓછામાં ઓછી આપેલ નોંધપાત્ર અંકોની સંખ્યા સાથે ઘાતાંકીય સ્વરૂપમાં ફોર્મેટ કરો.
///
/// જ્યારે `upper` એ X01 એક્સ છે, ત્યારે એક્સપોનન્ટને `E` દ્વારા પૂર્વવર્તી કરવામાં આવશે;અન્યથા તે `e` છે.
/// પરિણામ પૂરા પાડવામાં આવેલા ભાગો એરેમાં સંગ્રહિત કરવામાં આવે છે અને લેખિત ભાગોની સ્લાઇસ પાછો આવે છે.
///
/// `min_digits` `buf` માં વાસ્તવિક નોંધપાત્ર અંકોની સંખ્યા કરતા ઓછી હોઈ શકે;
/// તેને અવગણવામાં આવશે અને સંપૂર્ણ અંકો છાપવામાં આવશે.તે ફક્ત રેન્ડર કરેલા અંકો પછી અતિરિક્ત ઝીરો છાપવા માટે વપરાય છે.
/// આમ, `min_digits == 0` નો અર્થ છે કે તે ફક્ત આપેલા અંકો જ છાપશે અને બીજું કંઇ નહીં.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ સમાપ્તિ= 1.234 x 10 ^ (સમાપ્ત-1)
    let exp = exp as i32 - 1; // એક્સપ્રેસ i16::MIN હોય ત્યારે અંડરફ્લોને ટાળો
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // સલામતી: અમે હમણાં જ `..n + 2` તત્વો પ્રારંભ કર્યા.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// ફોર્મેટિંગ વિકલ્પો પર સહી કરો.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// ફક્ત નકારાત્મક બિન-શૂન્ય મૂલ્યો માટે `-` છાપે છે.
    Minus, // -inf -1 0 0 1 inf nan
    /// કોઈપણ નકારાત્મક મૂલ્યો (નકારાત્મક શૂન્ય સહિત) માટે ફક્ત `-` છાપે છે.
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// નકારાત્મક બિન-શૂન્ય મૂલ્યો માટે `-` અથવા અન્યથા `+` છાપે છે.
    MinusPlus, // -inf -1 +0 +0 +1 + ઇન્ફ નેન
    /// કોઈપણ નકારાત્મક મૂલ્યો (નકારાત્મક શૂન્ય સહિત), અથવા અન્યથા `+` માટે `-` છાપે છે.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + ઇન્ફ નેન
}

/// ફોર્મેટ થવા માટેનાં સંકેતને અનુરૂપ સ્થિર બાઇટ સ્ટ્રિંગ આપે છે.
/// તે ક્યાં તો `""`, `"+"` અથવા `"-"` હોઈ શકે છે.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// આપેલ ફ્લોટિંગ પોઇન્ટ નંબરને દશાંશ સ્વરૂપમાં ફોર્મેટ કરે છે જેમાં ઓછામાં ઓછા આપેલ અંકોની સંખ્યા હોય છે.
/// સ્ક્રેચ તરીકે આપવામાં આવેલા બાઇટ બફરનો ઉપયોગ કરતી વખતે પરિણામ પૂરા પાડવામાં આવેલા ભાગોના એરેમાં સંગ્રહિત કરવામાં આવે છે.
/// `upper` હાલમાં બિનઉપયોગી છે પરંતુ બિન-મર્યાદિત મૂલ્યો, એટલે કે, `inf` અને `nan` ના કિસ્સામાં ફેરફાર કરવાના future નિર્ણય માટે બાકી છે.
///
/// રેન્ડર થવાનો પ્રથમ ભાગ હંમેશાં એક `Part::Sign` હોય છે (જો કોઈ નિશાની પ્રસ્તુત ન કરવામાં આવે તો તે ખાલી શબ્દમાળા હોઈ શકે છે).
///
/// `format_shortest` અંતર્ગત ડિજિટ-જનરેશનનું કાર્ય હોવું જોઈએ.
/// તેણે શરૂ કરેલ બફરનો તે ભાગ પાછો આપવો જોઈએ.
/// તમે કદાચ આ માટે `strategy::grisu::format_shortest` જોઈએ.
///
/// `frac_digits` `v` માં વાસ્તવિક અપૂર્ણાંક અંકોની સંખ્યા કરતા ઓછી હોઈ શકે;
/// તેને અવગણવામાં આવશે અને સંપૂર્ણ અંકો છાપવામાં આવશે.તે ફક્ત રેન્ડર કરેલા અંકો પછી અતિરિક્ત ઝીરો છાપવા માટે વપરાય છે.
/// આમ 0 ના `frac_digits` નો અર્થ છે કે તે ફક્ત આપેલ અંકો જ છાપશે અને બીજું કંઇ નહીં.
///
/// બાઇટ બફર ઓછામાં ઓછું `MAX_SIG_DIGITS` બાઇટ્સ લાંબુ હોવું જોઈએ.
/// `frac_digits = 10` સાથેના `[+][0.][0000][2][0000]` જેવા સૌથી ખરાબ કેસને લીધે, ઓછામાં ઓછા 4 ભાગો ઉપલબ્ધ હોવા જોઈએ.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..2` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// આપેલ ફ્લોટિંગ પોઇન્ટ નંબરને દશાંશ ફોર્મ અથવા ઘાતક ફોર્મમાં ફોર્મેટ કરે છે, પરિણામી ઘાતક પર આધાર રાખીને.
/// સ્ક્રેચ તરીકે આપવામાં આવેલા બાઇટ બફરનો ઉપયોગ કરતી વખતે પરિણામ પૂરા પાડવામાં આવેલા ભાગોના એરેમાં સંગ્રહિત કરવામાં આવે છે.
/// `upper` બિન-મર્યાદિત મૂલ્યો (`inf` અને `nan`) અથવા ઘાતાના ઉપસર્ગ (`e` અથવા `E`) ના કેસને નક્કી કરવા માટે વપરાય છે.
/// રેન્ડર થવાનો પ્રથમ ભાગ હંમેશાં એક `Part::Sign` હોય છે (જો કોઈ નિશાની પ્રસ્તુત ન કરવામાં આવે તો તે ખાલી શબ્દમાળા હોઈ શકે છે).
///
/// `format_shortest` અંતર્ગત ડિજિટ-જનરેશનનું કાર્ય હોવું જોઈએ.
/// તેણે શરૂ કરેલ બફરનો તે ભાગ પાછો આપવો જોઈએ.
/// તમે કદાચ આ માટે `strategy::grisu::format_shortest` જોઈએ.
///
/// `dec_bounds` એ ટ્યુપલ `(lo, hi)` છે જેમ કે સંખ્યા દશાંશ તરીકે ફોર્મેટ કરવામાં આવે છે જ્યારે માત્ર `10^lo <= V < 10^hi`.
/// નોંધ લો કે આ વાસ્તવિક `v` ને બદલે *સ્પષ્ટ*`V` છે!આમ ઘાતાંકીય સ્વરૂપમાં કોઈપણ મુદ્રિત ખાતા આ શ્રેણીમાં હોઈ શકતા નથી, કોઈપણ મૂંઝવણને ટાળે છે.
///
///
/// બાઇટ બફર ઓછામાં ઓછું `MAX_SIG_DIGITS` બાઇટ્સ લાંબુ હોવું જોઈએ.
/// ઓછામાં ઓછા 6 ભાગો ઉપલબ્ધ હોવા જોઈએ, `[+][1][.][2345][e][-][6]` જેવા ખરાબ કેસને કારણે.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// આપેલ ડીકોડ કરેલ ઘાતકમાંથી ગણતરીના મહત્તમ બફર કદ માટે ક્રુડ અંદાજ (અપર બાઉન્ડ) પરત આપે છે.
///
/// ચોક્કસ મર્યાદા છે:
///
/// - જ્યારે `exp < 0`, મહત્તમ લંબાઈ `ceil(log_10 (5^-exp * (2^64 - 1)))` છે.
/// - જ્યારે `exp >= 0`, મહત્તમ લંબાઈ `ceil(log_10 (2^exp * (2^64 - 1)))` છે.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` કરતા ઓછું છે, જે બદલામાં `20 + (1 + exp* log_10 x)` કરતા ઓછું છે.
/// અમે `log_10 2 < 5/16` અને `log_10 5 < 12/16`, જે આપણા હેતુઓ માટે પૂરતા છે તે તથ્યોનો ઉપયોગ કરીએ છીએ.
///
/// આપણને આની કેમ જરૂર છે?છેલ્લા અંકના પ્રતિબંધ દ્વારા મર્યાદિત ન હોય ત્યાં સુધી `format_exact` ફંક્શન સંપૂર્ણ બફરને ભરી દેશે, પરંતુ શક્ય છે કે વિનંતી કરેલા અંકોની સંખ્યા હાસ્યાસ્પદ રીતે મોટી છે (કહો, 30,000 અંકો).
///
/// બફરનો મોટા ભાગનો ભાગ શૂન્યથી ભરવામાં આવશે, તેથી અમે બધા બફરને અગાઉથી ફાળવવા માંગતા નથી.
/// પરિણામે, આપેલ કોઈપણ દલીલો માટે,
/// `f64` માટે 826 બાઇટ્સના બફર પૂરતા હોવા જોઈએ.સૌથી ખરાબ કિસ્સામાં તેની વાસ્તવિક સંખ્યા સાથે આની તુલના કરો: 770 બાઇટ્સ (જ્યારે `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// ઘાતક સ્વરૂપમાં ફ્લોટિંગ પોઇન્ટ નંબર આપવામાં આવતા ફોર્મેટ્સ, બરાબર આપેલ સંખ્યાબંધ અંકોની સંખ્યા સાથે.
/// સ્ક્રેચ તરીકે આપવામાં આવેલા બાઇટ બફરનો ઉપયોગ કરતી વખતે પરિણામ પૂરા પાડવામાં આવેલા ભાગોના એરેમાં સંગ્રહિત કરવામાં આવે છે.
/// `upper` ઘાતાય ઉપસર્ગ (`e` અથવા `E`) ના કેસને નિર્ધારિત કરવા માટે વપરાય છે.
/// રેન્ડર થવાનો પ્રથમ ભાગ હંમેશાં એક `Part::Sign` હોય છે (જો કોઈ નિશાની પ્રસ્તુત ન કરવામાં આવે તો તે ખાલી શબ્દમાળા હોઈ શકે છે).
///
/// `format_exact` અંતર્ગત ડિજિટ-જનરેશનનું કાર્ય હોવું જોઈએ.
/// તેણે શરૂ કરેલ બફરનો તે ભાગ પાછો આપવો જોઈએ.
/// તમે કદાચ આ માટે `strategy::grisu::format_exact` જોઈએ.
///
/// બાઇટ બફર ઓછામાં ઓછું `ndigits` બાઇટ્સ લાંબુ હોવું જોઈએ સિવાય કે `ndigits` એટલું મોટું હોય કે ફક્ત નિશ્ચિત સંખ્યાની સંખ્યા જ ક્યારેય લખાઈ ન શકે.
/// (`f64` માટે ટિપિંગ પોઇન્ટ આશરે 800 છે, તેથી 1000 બાઇટ્સ પૂરતા હોવા જોઈએ.) `[+][1][.][2345][e][-][6]` જેવા સૌથી ખરાબ કેસને લીધે, ઓછામાં ઓછા 6 ભાગો ઉપલબ્ધ હોવા જોઈએ.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..3` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// અપૂર્ણાંક અંકોની બરાબર આપવામાં આવેલી સંખ્યા સાથે દશાંશ સ્વરૂપમાં ફ્લોટિંગ પોઇન્ટ નંબર આપેલા ફોર્મેટ્સ.
/// સ્ક્રેચ તરીકે આપવામાં આવેલા બાઇટ બફરનો ઉપયોગ કરતી વખતે પરિણામ પૂરા પાડવામાં આવેલા ભાગોના એરેમાં સંગ્રહિત કરવામાં આવે છે.
/// `upper` હાલમાં બિનઉપયોગી છે પરંતુ બિન-મર્યાદિત મૂલ્યો, એટલે કે, `inf` અને `nan` ના કિસ્સામાં ફેરફાર કરવાના future નિર્ણય માટે બાકી છે.
/// રેન્ડર થવાનો પ્રથમ ભાગ હંમેશાં એક `Part::Sign` હોય છે (જો કોઈ નિશાની પ્રસ્તુત ન કરવામાં આવે તો તે ખાલી શબ્દમાળા હોઈ શકે છે).
///
/// `format_exact` અંતર્ગત ડિજિટ-જનરેશનનું કાર્ય હોવું જોઈએ.
/// તેણે શરૂ કરેલ બફરનો તે ભાગ પાછો આપવો જોઈએ.
/// તમે કદાચ આ માટે `strategy::grisu::format_exact` જોઈએ.
///
/// બાઉન્ડ બફર આઉટપુટ માટે પૂરતું હોવું જોઈએ સિવાય કે `frac_digits` એટલું મોટું ન હોય કે ફક્ત નિશ્ચિત સંખ્યાની સંખ્યા જ ક્યારેય લખાઈ ન શકે.
/// (`f64` માટે ટિપિંગ પોઇન્ટ લગભગ 800 છે, અને 1000 બાઇટ્સ પૂરતા હોવા જોઈએ.) `frac_digits = 10` સાથેના `[+][0.][0000][2][0000]` જેવા સૌથી ખરાબ કેસને લીધે, ઓછામાં ઓછા 4 ભાગો ઉપલબ્ધ હોવા જોઈએ.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..2` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // સંભવ છે કે `frac_digits` હાસ્યાસ્પદ રીતે મોટું છે.
            // `format_exact` આ કિસ્સામાં ખૂબ પહેલા રેન્ડરિંગ અંકોનો અંત આવશે, કારણ કે અમે `maxlen` દ્વારા સખત મર્યાદિત છીએ.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // પ્રતિબંધ પૂર્ણ કરી શકાયું નથી, તેથી આ શૂન્યની જેમ રેન્ડર કરવું જોઈએ, `exp` કોઈ બાબત નથી.
                // આમાં આ કેસ શામેલ નથી કે અંતિમ રાઉન્ડ-અપ થયા પછી જ પ્રતિબંધ પૂર્ણ કરવામાં આવ્યો છે;તે `exp = limit + 1` નો નિયમિત કેસ છે.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // સલામતી: અમે હમણાં જ `..2` તત્વો પ્રારંભ કર્યા.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // સલામતી: અમે હમણાં જ `..1` તત્વો પ્રારંભ કર્યા.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}