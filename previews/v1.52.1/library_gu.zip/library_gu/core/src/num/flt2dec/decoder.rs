//! વ્યક્તિગત ભાગો અને ભૂલ શ્રેણીમાં ફ્લોટિંગ-પોઇન્ટ મૂલ્યને ડીકોડ કરે છે.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ડીકોડ કરેલું સહી વિનાનું મર્યાદિત મૂલ્ય, જેમ કે:
///
/// - મૂળ મૂલ્ય `mant * 2^exp` ની બરાબર છે.
///
/// - `(mant - minus)*2^exp` થી `(mant + plus)* 2^exp` સુધીની કોઈપણ સંખ્યા અસલ મૂલ્ય સુધી પહોંચશે.
/// જ્યારે `inclusive` `true` હોય ત્યારે જ શ્રેણી શામેલ હોય છે.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// સ્કેલ કરેલું મન્ટિસા.
    pub mant: u64,
    /// નીચી ભૂલ શ્રેણી.
    pub minus: u64,
    /// ઉપલા ભૂલની શ્રેણી.
    pub plus: u64,
    /// આધાર 2 માં વહેંચાયેલ ખાતા.
    pub exp: i16,
    /// ભૂલની શ્રેણી શામેલ હોય ત્યારે સાચું.
    ///
    /// આઇઇઇઇ 754 માં, જ્યારે મૂળ મ mantન્ટિસા સમાન હતી ત્યારે આ સાચું છે.
    pub inclusive: bool,
}

/// ડીકોડ કરેલ સહી વિનાનું મૂલ્ય
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// અનંતતા, ક્યાં તો સકારાત્મક અથવા નકારાત્મક.
    Infinite,
    /// શૂન્ય, ક્યાં સકારાત્મક અથવા નકારાત્મક.
    Zero,
    /// વધુ ડીકોડ કરેલ ફીલ્ડ્સ સાથે મર્યાદિત સંખ્યાઓ.
    Finite(Decoded),
}

/// ફ્લોટિંગ પોઇન્ટ પ્રકાર જે `ડીકોડ`ડ કરી શકાય છે.
pub trait DecodableFloat: RawFloat + Copy {
    /// ન્યૂનતમ સકારાત્મક સામાન્યકૃત મૂલ્ય.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// આપેલ ફ્લોટિંગ પોઇન્ટ નંબરમાંથી એક સંકેત (જ્યારે નકારાત્મક હોય ત્યારે સાચું) અને `FullDecoded` મૂલ્ય આપે છે.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // પડોશીઓ: (મન્ટ, 2, એક્સપ)
            // Float::integer_decode હંમેશા ઘાતકને સાચવે છે, તેથી મેન્ટિસા સબનોર્મલ્સ માટે સ્કેલ કરે છે.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // પડોશીઓ: (મહત્તમ, સમાપ્તિ, 1)-(મિનોમ ,ર્મંટ, સમાપ્તિ)-(મિનોમmantર્મંટ +1, સમાપ્તિ)
                // જ્યાં મહત્તમ=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // પડોશીઓ: (મ mantંટ, 1, સમાપ્તિ)-(મ mantંટ, સમાપ્તિ)-(મ mantન્ટ + 1, સમાપ્તિ)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}