//! "પ્રિન્ટિંગ ફ્લોટિંગ-પોઇન્ટ નંબર્સ ઝડપથી અને સચોટપણે પૂર્ણાંકો સાથે વર્ણવેલ" [^ 1] માં વર્ણવેલ Grisu3 અલ્ગોરિધમનું Rust અનુકૂલન.
//! તે લગભગ 1KB પ્રિકમ્પ્યુટેડ ટેબલનો ઉપયોગ કરે છે અને બદલામાં, મોટાભાગના ઇનપુટ્સ માટે તે ખૂબ જ ઝડપી છે.
//!
//! [^1]: Florian લોઇટ્સ2010. ફ્લોટિંગ-પોઇન્ટ નંબરો ઝડપથી છાપવા અને
//!   પૂર્ણાંકો સાથે ચોક્કસ.સિગપ્લેન નહીં.45, 6 (જૂન 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// તર્ક માટે `format_shortest_opt` માંની ટિપ્પણીઓ જુઓ.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-હું;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (એફ, ઇ, કે)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` આપવામાં, `(k, 10^k)` જેમ કે `10^k <= x < 10^(k+1)` આપે છે.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// ગ્રીસુ માટે ટૂંકી સ્થિતિ અમલીકરણ.
///
/// તે `None` પરત કરે છે જ્યારે તે અયોગ્ય રજૂઆત પરત કરશે.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // આપણને વધારાની ચોકસાઈના ઓછામાં ઓછા ત્રણ બિટ્સની જરૂર છે

    // વહેંચાયેલ ખાતા સાથે સામાન્યકૃત મૂલ્યોથી પ્રારંભ કરો
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // કોઈપણ `cached = 10^minusk` જેમ કે `ALPHA <= minusk + plus.e + 64 <= GAMMA` શોધો.
    // `plus` નોર્મલાઇઝ થયેલ હોવાથી, આનો અર્થ `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // `ALPHA` અને `GAMMA` ની અમારી પસંદગીઓને જોતાં, આ `plus * cached` ને `[4, 2^32)` માં મૂકે છે.
    //
    // તે સ્પષ્ટપણે `GAMMA - ALPHA` મહત્તમ કરવા ઇચ્છનીય છે, જેથી અમને 10 ની ઘણી કેશ્ડ શક્તિઓની જરૂર ન હોય, પરંતુ કેટલાક મુદ્દાઓ છે:
    //
    //
    // 1. અમે `floor(plus * cached)` ને `u32` ની અંદર રાખવા માગીએ છીએ, કારણ કે તેને મોંઘા ડિવિઝનની જરૂર છે.
    //    (આ ખરેખર ટાળી શકાય તેવું નથી, ચોકસાઈના અંદાજ માટે બાકીની આવશ્યકતા છે.)
    // 2.
    // `floor(plus * cached)` ની બાકીની વારંવાર 10 દ્વારા ગુણાકાર થાય છે, અને તે ઓવરફ્લો થવું જોઈએ નહીં.
    //
    // પ્રથમ `64 + GAMMA <= 32` આપે છે, જ્યારે બીજો `10 * 2^-ALPHA <= 2^64` આપે છે;
    // -60 અને -32 આ અવરોધ સાથેની મહત્તમ શ્રેણી છે અને V8 પણ તેનો ઉપયોગ કરે છે.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // સ્કેલ એફપીએસ.આ 1 ulp ની મહત્તમ ભૂલ આપે છે (પ્રમેય 5.1 થી સાબિત).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-બાદબાકીની વાસ્તવિક શ્રેણી
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus`, `v` અને `plus` ઉપર *ક્વોન્ટીઝ્ડ* આશરે (ભૂલ <1 ulp) છે.
    // કારણ કે આપણે જાણતા નથી કે ભૂલ હકારાત્મક છે કે નકારાત્મક છે, અમે સમાન અંતરે આવેલા બે અંદાજોનો ઉપયોગ કરીએ છીએ અને 2 ઓલ્પ્સની મહત્તમ ભૂલ છે.
    //
    // "unsafe region" એ ઉદાર અંતરાલ છે જે આપણે શરૂઆતમાં જનરેટ કરીએ છીએ.
    // "safe region" એ એક રૂ conિચુસ્ત અંતરાલ છે જેને આપણે ફક્ત સ્વીકારીએ છીએ.
    // અમે અસુરક્ષિત પ્રદેશની અંદરના યોગ્ય રેપર્સથી પ્રારંભ કરીએ છીએ, અને `v` ની નજીકના repr શોધવાનો પ્રયાસ કરીએ છીએ જે સલામત ક્ષેત્રમાં પણ છે.
    // જો આપણે ન કરી શકીએ તો આપણે છોડી દઈશું.
    //
    let plus1 = plus.f + 1;
    // ચાલો plus0 = plus.f, 1;//ફક્ત સમજૂતી માટે minus0 = minus.f + 1 દો;//ફક્ત સમજૂતી માટે
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // વહેંચાયેલ ખાતા

    // `plus1` ને અભિન્ન અને અપૂર્ણાંક ભાગોમાં વહેંચો.
    // ઇન્ટિગ્રલ ભાગો u32 માં ફિટ થવાની બાંયધરી આપવામાં આવે છે, કેમ કે કેશ્ડ પાવર `plus < 2^32` ની ખાતરી આપે છે અને ચોકસાઇ આવશ્યકતાને લીધે સામાન્ય `plus.f` હંમેશા `2^64 - 2^4` કરતા ઓછું હોય છે.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // `plus1` (આમ `plus1 < 10^(max_kappa+1)`) કરતા વધુ નબળા `10^max_kappa` ની ગણતરી કરો.
    // આ નીચે `kappa` ની ઉપરની બાઉન્ડ છે.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // પ્રમેય 6.2: જો `k` એ સૌથી મોટો પૂર્ણાંક ST છે
    // `0 <= y mod 10^k <= y - x`,              તો પછી `V = floor(y / 10^k) * 10^k` એ `[x, y]` માં છે અને તે રેન્જમાં ટૂંકી રજૂઆતમાંથી (નોંધપાત્ર અંકોની ન્યૂનતમ સંખ્યા સાથે).
    //
    //
    // `(minus1, plus1)` વચ્ચે થિઓરેમ 6.2 મુજબ અંકની લંબાઈ `kappa` શોધો.
    // `x` ને બદલે `y mod 10^k < y - x` ને બાકાત રાખવા માટે પ્રમેય 6.2 અપનાવી શકાય છે.
    // (દા.ત., `x` =32000, `y` =32777; `kappa` =2 ત્યારથી `y મોડ 10 ^ 3=777 <y, x=777`.) અલ્ગોરિધમનો `y` બાકાત રાખવા પાછળના ચકાસણી તબક્કા પર આધાર રાખે છે.
    //
    let delta1 = plus1 - minus1;
    // ચાલો delta1int=(delta1>> e) ને વપરાશ મુજબ;//ફક્ત સમજૂતી માટે
    let delta1frac = delta1 & ((1 << e) - 1);

    // દરેક પગલા પર ચોકસાઈ માટે તપાસ કરતી વખતે, અભિન્ન ભાગો રેન્ડર કરો.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // અંક હજી સુધી રેન્ડર કરવાના બાકી છે
    loop {
        // આપણી પાસે હંમેશા `plus1 >= 10^kappa` આક્રમણકારો તરીકે, રેન્ડર કરવા માટે ઓછામાં ઓછો એક અંક હોય છે:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (તે અનુસરે છે કે `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // `remainder` દ્વારા `remainder` ને વિભાજીત કરો.બંનેને `2^-e` દ્વારા સ્કેલ કરવામાં આવ્યા છે.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ કપ્પા) * 2 ^ ઇ
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; અમને સાચો `kappa` મળ્યો છે.
            let ten_kappa = (ten_kappa as u64) << e; // શેર કરેલ ખાતા પર પાછા 10 ^ કપ્પા
            return round_and_weed(
                // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // જ્યારે આપણે બધા અભિન્ન અંકો રેન્ડર કર્યા છે ત્યારે લૂપને તોડી નાખો.
        // અંકોની ચોક્કસ સંખ્યા,`plus1 < 10^(max_kappa+1)` એક્સ તરીકે `plus1 < 10^(max_kappa+1)` છે.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // આક્રમણકારોને પુનર્સ્થાપિત કરો
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // અપૂર્ણાંક ભાગો રેન્ડર કરો, જ્યારે દરેક પગલા પર ચોકસાઈ માટે તપાસ કરો.
    // આ વખતે આપણે વારંવાર ગુણાકાર પર આધાર રાખીએ છીએ, કારણ કે વિભાગ ચોકસાઇ ગુમાવશે.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // આગલું અંક નોંધપાત્ર હોવું જોઈએ કારણ કે આપણે પરીક્ષણ કર્યું છે કે આક્રમણકારોને તોડતા પહેલા, જ્યાં `m = max_kappa + 1` (અભિન્ન ભાગમાંના અંકોની સંખ્યા):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ઓવરફ્લો નહીં થાય, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` ને `10^kappa` દ્વારા વિભાજીત કરો.
        // બંને `2^e / 10^kappa` દ્વારા સ્કેલ કરેલા છે, તેથી બાદમાં અહીં ગર્ભિત છે.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ગર્ભિત વિભાજક
            return round_and_weed(
                // સલામતી: અમે ઉપરની તે મેમરીને પ્રારંભ કરી.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // આક્રમણકારોને પુનર્સ્થાપિત કરો
        kappa -= 1;
        remainder = r;
    }

    // અમે `plus1` ના બધા નોંધપાત્ર અંકો જનરેટ કર્યા છે, પરંતુ ખાતરી નથી કે તે શ્રેષ્ઠ છે કે નહીં.
    // ઉદાહરણ તરીકે, જો `minus1` એ 3.14153 ... અને `plus1` એ 3.14158 છે ..., ત્યાં 3.14154 થી 3.14158 સુધીની 5 જુદી જુદી ટૂંકી રજૂઆત છે પરંતુ અમારી પાસે ફક્ત સૌથી મોટી છે.
    // આપણે ક્રમશ the છેલ્લા અંકોમાં ઘટાડો કરવો પડશે અને તપાસવું જોઈએ કે શું આ શ્રેષ્ઠ રિપ્રિટ છે.
    // ત્યાં વધુમાં વધુ 9 ઉમેદવારો છે (.. 1 થી ..9), તેથી આ એકદમ ઝડપી છે.("rounding" તબક્કો)
    //
    // ફંક્શન તપાસે છે કે શું આ "optimal" રેપ ખરેખર યુપ રેન્જની અંદર છે, અને તે પણ, શક્ય છે કે ગોળાકાર ભૂલને કારણે "second-to-optimal" રેપ ખરેખર ઉત્તમ થઈ શકે.
    // બંને કિસ્સાઓમાં આ `None` આપે છે.
    // ("weeding" તબક્કો)
    //
    // અહીંની બધી દલીલો સામાન્ય (પરંતુ ગર્ભિત) મૂલ્ય `k` દ્વારા સ્કેલ કરવામાં આવી છે, જેથી:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (અને, `remainder < threshold` પણ)
    // - `plus1v = (plus1 - v) * k` (અને તે પણ, અગાઉના આક્રમણકારો તરફથી `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps ની અંદર `v` (ખરેખર `plus1 - v`) માટે બે અંદાજો ઉત્પન્ન કરો.
        // પરિણામી પ્રતિનિધિત્વ બંને માટે સૌથી નજીકનું પ્રતિનિધિત્વ હોવું જોઈએ.
        //
        // અહીં `plus1 - v` નો ઉપયોગ થાય છે, કારણ કે overflow/underflow (તેથી મોટે ભાગે અદલાબદલ નામો) ટાળવા માટે `plus1` ના સંદર્ભમાં ગણતરીઓ કરવામાં આવે છે.
        //
        let plus1v_down = plus1v + ulp; // plus1 - (વી, 1 ઉપ)
        let plus1v_up = plus1v - ulp; // plus1 - (વી +1 ઉપ)

        // છેલ્લો આંકડો ઘટાડવો અને `v + 1 ulp` ની નજીકની રજૂઆત પર રોકો.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // અમે આશરે અંકો `w(n)` સાથે કામ કરીએ છીએ, જે શરૂઆતમાં `plus1 - plus1 % 10^kappa` ની બરાબર છે.લૂપ બોડી `n` વખત ચલાવ્યા પછી, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // અમે ચેકને સરળ બનાવવા માટે `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (આમ `બાકીનું= plus1w(0)`)) સેટ કર્યું.
            // નોંધ લો કે `plus1w(n)` હંમેશા વધે છે.
            //
            // સમાપ્ત કરવાની અમારી પાસે ત્રણ શરતો છે.તેમાંના કોઈપણ લૂપને આગળ વધવામાં અસમર્થ બનાવશે, પરંતુ અમારી પાસે ઓછામાં ઓછું એક માન્ય રજૂઆત છે તેમ છતાં પણ `v + 1 ulp` ની નજીકમાં હોવાનું જાણીતું છે.
            // અમે તેમને બ્રિવીટી માટે TC3 દ્વારા TC1 તરીકે સૂચવીશું.
            //
            // TC1: `w(n) <= v + 1 ulp`, એટલે કે, આ છેલ્લો રેપ છે જે સૌથી નજીકનું હોઈ શકે છે.
            // આ `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` ની બરાબર છે.
            // TC2 સાથે સંયુક્ત (જે `w(n+1)` is valid) તપાસે છે, આ `plus1w(n)` ની ગણતરી પરના શક્ય ઓવરફ્લોને અટકાવે છે.
            //
            // TC2: `w(n+1) < minus1`, એટલે કે, આગળનું રેટર ચોક્કસપણે `v` ની આસપાસ નથી.
            // આ `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` ની બરાબર છે.
            // ડાબી બાજુ ઓવરફ્લો થઈ શકે છે, પરંતુ આપણે `threshold > plus1v` ને જાણીએ છીએ, તેથી જો TC1 ખોટું છે, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` અને જો આપણે `threshold - plus1w(n) < 10^kappa` ને બદલે સલામત રીતે ચકાસી શકીએ તો.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, એટલે કે, આગળનું repr છે
            // વર્તમાન રેપર્સ કરતા `v + 1 ulp` ની નજીક નથી.
            // `z(n) = plus1v_up - plus1w(n)` આપેલ, આ `abs(z(n)) <= abs(z(n+1))` બને છે.ફરીથી એમ ધારીને કે TC1 ખોટું છે, અમારી પાસે `z(n) > 0` છે.અમારી પાસે ધ્યાનમાં લેવા માટેના બે કેસો છે:
            //
            // - જ્યારે `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` બને છે.
            // જેમ કે `plus1w(n)` વધી રહ્યું છે, `z(n)` ઓછું થવું જોઈએ અને આ સ્પષ્ટ ખોટું છે.
            // - જ્યારે `z(n+1) < 0`:
            //   - TC3a: પૂર્વશરત `plus1v_up < plus1w(n) + 10^kappa` છે.TC2 ખોટું છે એમ માનીને, `threshold >= plus1w(n) + 10^kappa` તેથી તે ઓવરફ્લો થઈ શકશે નહીં.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` બને છે, એટલે કે, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   નકારાત્મક TC1 `plus1v_up > plus1w(n)` આપે છે, તેથી જ્યારે TC3a સાથે જોડાઈ જાય ત્યારે તે ઓવરફ્લો અથવા અંડરફ્લો કરી શકશે નહીં.
            //
            // પરિણામે, જ્યારે `TC1 || TC2 || (TC3a && TC3b)` હોય ત્યારે આપણે બંધ થવું જોઈએ.નીચેના તેના inંધી સમાન છે, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ટૂંકમાં પ્રતિનિધિ `0` સાથે સમાપ્ત થઈ શકતું નથી
                plus1w += ten_kappa;
            }
        }

        // તપાસ કરો કે શું આ રજૂઆત પણ `v - 1 ulp` ની નજીકની રજૂઆત છે.
        //
        // `v + 1 ulp` માટેની સમાપ્ત થતી પરિસ્થિતિઓ જેવી જ, `plus1v_down` ને બદલે બધા `plus1v_up` બદલાયા.
        // ઓવરફ્લો વિશ્લેષણ સમાન ધરાવે છે.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // હવે આપણી પાસે `plus1` અને `minus1` વચ્ચેની `v` ની નજીકની રજૂઆત છે.
        // આ ખૂબ ઉદાર છે, તેમ છતાં, તેથી અમે કોઈપણ `w(n)` ને નકારી કા Xીએ `plus0` અને `minus0`, એટલે કે, `plus1 - plus1w(n) <= minus0` અથવા `plus1 - plus1w(n) >= plus0` વચ્ચે.
        // અમે `threshold = plus1 - minus1` અને `plus1 - plus0 = minus0 - minus1 = 2 ulp` એ તથ્યોનો ઉપયોગ કરીએ છીએ.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ડ્રેગન ફ fallલબેક સાથે ગ્રીસુ માટે ટૂંકી મોડ મોડીકરણ.
///
/// આનો ઉપયોગ મોટાભાગના કેસો માટે થવો જોઈએ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // સલામતી: ઉધાર તપાસનાર એટલું સ્માર્ટ નથી કે અમને `buf` નો ઉપયોગ કરવા દે
    // બીજા ઝેડબ્રાંચ0 ઝેડમાં, તેથી અમે અહીં આજીવન જીવન પ્રદાન કરીએ છીએ.
    // પરંતુ અમે ફક્ત `buf` નો ફરીથી ઉપયોગ કરીએ છીએ જો `format_shortest_opt` `None` પરત આપે છે તેથી આ ઠીક છે.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// ગ્રીસુ માટે ચોક્કસ અને નિશ્ચિત મોડ અમલીકરણ.
///
/// તે `None` પરત કરે છે જ્યારે તે અયોગ્ય રજૂઆત પરત કરશે.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // આપણને વધારાની ચોકસાઈના ઓછામાં ઓછા ત્રણ બિટ્સની જરૂર છે
    assert!(!buf.is_empty());

    // નોર્મલાઇઝ અને સ્કેલ `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` ને અભિન્ન અને અપૂર્ણાંક ભાગોમાં વહેંચો.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // બંને જૂના `v` અને નવા `v` (`10^-k` દ્વારા સ્કેલ કરેલું) બંનેમાં <1 ulp (પ્રમેય 5.1) ની ભૂલ છે.
    // કારણ કે આપણે જાણતા નથી કે ભૂલ હકારાત્મક છે કે નકારાત્મક છે, અમે સમાન અંતરે આવેલા બે અંદાજોનો ઉપયોગ કરીએ છીએ અને 2 ઓલ્પ્સની મહત્તમ ભૂલ (ટૂંકા કિસ્સામાં સમાન).
    //
    //
    // ધ્યેય એ છે કે અંકોની બરાબર ગોળાકાર શ્રેણી શોધી કા thatવી જે `v - 1 ulp` અને `v + 1 ulp` બંને માટે સામાન્ય છે, જેથી આપણે મહત્તમ વિશ્વાસ હોઈએ.
    // જો આ શક્ય ન હોય તો, અમે જાણતા નથી કે `v` નું કયું યોગ્ય આઉટપુટ છે, તેથી અમે છોડી દઈએ અને પાછા પડીએ.
    //
    // `err` અહીં `1 ulp * 2^e` તરીકે વ્યાખ્યાયિત કરવામાં આવી છે (`vfrac` માં અલ્પ સમાન), અને જ્યારે પણ `v` સ્કેલ કરવામાં આવે ત્યારે અમે તેને સ્કેલ કરીશું.
    //
    //
    //
    let mut err = 1;

    // `v` (આમ `v < 10^(max_kappa+1)`) કરતા વધુ નબળા `10^max_kappa` ની ગણતરી કરો.
    // આ નીચે `kappa` ની ઉપરની બાઉન્ડ છે.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // જો આપણે છેલ્લી અંકની મર્યાદા સાથે કામ કરી રહ્યા છીએ, તો ડબલ રાઉન્ડિંગને ટાળવા માટે આપણે વાસ્તવિક રેન્ડરિંગ પહેલાં બફર ટૂંકાવી લેવાની જરૂર છે.
    //
    // નોંધ લો કે જ્યારે રાઉન્ડિંગ થાય ત્યારે આપણે ફરીથી બફરને મોટું કરવું પડશે!
    let len = if exp <= limit {
        // અરેરે, અમે *એક* અંક પણ પેદા કરી શકતા નથી.
        // આ ત્યારે શક્ય છે જ્યારે એમ કહી શકાય કે આપણને 9.5 જેવું કંઈક મળ્યું છે અને તે 10 થઈ ગયું છે.
        //
        // સૈદ્ધાંતિક રૂપે અમે ખાલી બફર સાથે `possibly_round` પર તરત જ ક canલ કરી શકીએ છીએ, પરંતુ `max_ten_kappa << e` ને 10 દ્વારા સ્કેલિંગ ઓવરફ્લોમાં પરિણમી શકે છે.
        //
        // આમ આપણે અસ્થિર રહીએ છીએ અને 10 ના પરિબળ દ્વારા ભૂલ શ્રેણીને વિસ્તૃત કરીએ છીએ.
        // આ ખોટા નકારાત્મક દરમાં વધારો કરશે, પરંતુ ફક્ત ખૂબ જ,*ખૂબ* સહેજ;
        // તે માત્ર ત્યારે જ નોંધપાત્ર વાંધો લાવી શકે છે જ્યારે મેન્ટિસા 60 બીટ્સ કરતા મોટી હોય.
        //
        // સલામતી: `len=0`, તેથી આ મેમરીને પ્રારંભ કરવાની જવાબદારી મામૂલી છે.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // અભિન્ન ભાગો રેન્ડર કરો.
    // ભૂલ સંપૂર્ણ અપૂર્ણાંક છે, તેથી આપણે તેને આ ભાગમાં તપાસવાની જરૂર નથી.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // અંક હજી સુધી રેન્ડર કરવાના બાકી છે
    loop {
        // અમારી પાસે હંમેશા આક્રમણકારોને રેન્ડર કરવા માટે ઓછામાં ઓછો એક અંક હોય છે:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (તે અનુસરે છે કે `remainder = vint % 10^(kappa+1)`)
        //
        //

        // `remainder` દ્વારા `remainder` ને વિભાજીત કરો.બંનેને `2^-e` દ્વારા સ્કેલ કરવામાં આવ્યા છે.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // બફર ભરેલું છે?બાકીની સાથે રાઉન્ડિંગ પાસ ચલાવો.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(વી% 10 ^ કપ્પા) * 2 ^ ઇ
            // સલામતી: આપણે `len` ઘણાં બાઇટ્સ પ્રારંભ કર્યા છે.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // જ્યારે આપણે બધા અભિન્ન અંકો રેન્ડર કર્યા છે ત્યારે લૂપને તોડી નાખો.
        // અંકોની ચોક્કસ સંખ્યા,`plus1 < 10^(max_kappa+1)` એક્સ તરીકે `plus1 < 10^(max_kappa+1)` છે.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // આક્રમણકારોને પુનર્સ્થાપિત કરો
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // અપૂર્ણાંક ભાગો રેન્ડર કરો.
    //
    // સિદ્ધાંતમાં આપણે છેલ્લાં ઉપલબ્ધ અંકો પર ચાલુ રાખી શકીએ અને ચોકસાઈ ચકાસી શકીએ.
    // કમનસીબે અમે મર્યાદિત કદના પૂર્ણાંકો સાથે કામ કરી રહ્યા છીએ, તેથી ઓવરફ્લોને શોધવા માટે અમને કેટલાક માપદંડની જરૂર છે.
    // V8 `remainder > err` નો ઉપયોગ કરે છે, જે ખોટી બને છે જ્યારે `v - 1 ulp` અને `v` ના પ્રથમ `i` નોંધપાત્ર અંકો અલગ હોય છે.
    // જો કે આ ઘણાં અન્યથા માન્ય ઇનપુટને નકારે છે.
    //
    // પછીના તબક્કામાં સાચો ઓવરફ્લો તપાસ હોવાથી, અમે તેના બદલે સખ્ત માપદંડનો ઉપયોગ કરીએ છીએ:
    // અમે ચાલુ રાખીએ છીએ કે `err` `10^kappa / 2` કરતા વધારે છે, જેથી `v - 1 ulp` અને `v + 1 ulp` વચ્ચેની રેન્જમાં ચોક્કસપણે બે અથવા વધુ ગોળાકાર રજૂઆતો શામેલ હોય.
    //
    // સંદર્ભ માટે, `possibly_round` માંથી પ્રથમ બે સરખામણીઓ સમાન છે.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // આક્રમણો, જ્યાં `m = max_kappa + 1` (અભિન્ન ભાગમાંના અંકોની સંખ્યા):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ઓવરફ્લો નહીં થાય, `2^e * 10 < 2^64`
        err *= 10; // ઓવરફ્લો નહીં થાય, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` ને `10^kappa` દ્વારા વિભાજીત કરો.
        // બંને `2^e / 10^kappa` દ્વારા સ્કેલ કરેલા છે, તેથી બાદમાં અહીં ગર્ભિત છે.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // બફર ભરેલું છે?બાકીની સાથે રાઉન્ડિંગ પાસ ચલાવો.
        if i == len {
            // સલામતી: આપણે `len` ઘણાં બાઇટ્સ પ્રારંભ કર્યા છે.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // આક્રમણકારોને પુનર્સ્થાપિત કરો
        remainder = r;
    }

    // આગળની ગણતરી નકામું છે (`possibly_round` ચોક્કસપણે નિષ્ફળ થાય છે), તેથી અમે હાર માગીએ છીએ.
    return None;

    // અમે `v` ના બધા વિનંતી કરેલા અંકો જનરેટ કર્યા છે, જે `v - 1 ulp` ના અનુરૂપ અંકો માટે પણ સમાન હોવા જોઈએ.
    // હવે અમે તપાસો કે શું `v - 1 ulp` અને `v + 1 ulp` બંને દ્વારા વહેંચાયેલ કોઈ અનન્ય રજૂઆત છે;આ ક્યાં તો જનરેટ કરેલા અંકો અથવા તે અંકોના રાઉન્ડ-અપ સંસ્કરણ સમાન હોઈ શકે છે.
    //
    // જો શ્રેણીમાં સમાન લંબાઈના બહુવિધ રજૂઆતો હોય, તો અમે ખાતરી કરી શકતા નથી અને તેના બદલે `None` પાછા આપવું જોઈએ.
    //
    // અહીંની બધી દલીલો સામાન્ય (પરંતુ ગર્ભિત) મૂલ્ય `k` દ્વારા સ્કેલ કરવામાં આવી છે, જેથી:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // સલામતી: `buf` નો પ્રથમ `len` બાઇટ્સ પ્રારંભ કરવો આવશ્યક છે.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (સંદર્ભ માટે, ડોટેડ લાઇન એ અંકની સંખ્યામાં શક્ય રજૂઆતો માટે ચોક્કસ મૂલ્ય સૂચવે છે.)
        //
        //
        // ભૂલ ખૂબ મોટી છે કે `v - 1 ulp` અને `v + 1 ulp` વચ્ચે ઓછામાં ઓછા ત્રણ શક્ય રજૂઆતો છે.
        // જે નક્કી કરવું તે યોગ્ય નથી.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // હકીકતમાં, 1/2 ulp બે શક્ય રજૂઆતો રજૂ કરવા માટે પૂરતું છે.
        // (યાદ રાખો કે અમને `v - 1 ulp` અને `v + 1 uલ્પ બંને માટે અનન્ય પ્રતિનિધિત્વની જરૂર છે.) આ પ્રથમ તપાસમાંથી `ulp < ten_kappa` તરીકે ઓવરફ્લો થશે નહીં.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ કપ્પા---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // જો `v + 1 ulp` ગોળાકાર-ડાઉન રજૂઆત (જે પહેલાથી `buf` માં છે) ની નજીક છે, તો અમે સુરક્ષિત રીતે પાછા આવી શકીએ છીએ.
        // નોંધ લો કે `v - 1 ulp` * વર્તમાન પ્રતિનિધિત્વ કરતા ઓછા હોઈ શકે છે, પરંતુ `1 ulp < 10^kappa / 2` તરીકે, આ સ્થિતિ પૂરતી છે:
        // `v - 1 ulp` અને વર્તમાન પ્રતિનિધિત્વ વચ્ચેનું અંતર `10^kappa / 2` કરતાં વધી શકતું નથી.
        //
        // શરત `remainder + ulp < 10^kappa / 2` ની બરાબર છે.
        // કારણ કે આ સરળતાથી ઓવરફ્લો થઈ શકે છે, પ્રથમ `remainder < 10^kappa / 2` છે કે નહીં તે તપાસો.
        // અમે તે `ulp < 10^kappa / 2` ને પહેલેથી ચકાસી લીધું છે, તેથી જ્યાં સુધી `10^kappa` બધા પછી ઓવરફ્લો ન થાય ત્યાં સુધી, બીજી તપાસ બરાબર છે.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // સલામતી: અમારા કોલરે તે મેમરી પ્રારંભ કરી.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------બાકી------> |:
        //   :                          |   :
        //   : <---------10 ^ કપ્પા--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // બીજી બાજુ, જો `v - 1 ulp` ગોળાકાર અપની રજૂઆતની નજીક છે, તો આપણે રાઉન્ડ અપ કરી પાછા ફરવું જોઈએ.
        // તે જ કારણોસર આપણે `v + 1 ulp` તપાસવાની જરૂર નથી.
        //
        // શરત `remainder - ulp >= 10^kappa / 2` ની બરાબર છે.
        // ફરીથી આપણે પ્રથમ `remainder > ulp` તપાસીએ છીએ (નોંધ લો કે આ `remainder >= ulp` નથી, કારણ કે `10^kappa` ક્યારેય શૂન્ય નથી).
        //
        // તે પણ નોંધો કે `remainder - ulp <= 10^kappa`, તેથી બીજો ચેક ઓવરફ્લો થતો નથી.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // સલામતી: અમારા કlerલરે તે મેમરી પ્રારંભ કરી હોવી જોઈએ.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // જ્યારે અમને નિશ્ચિત ચોકસાઇ માટે વિનંતી કરવામાં આવે ત્યારે જ એક અતિરિક્ત અંક ઉમેરો.
                // અમારે એ પણ તપાસવાની જરૂર છે કે, જો મૂળ બફર ખાલી હતો, તો `exp == limit` (edge કેસ) ત્યારે જ અતિરિક્ત અંકો ઉમેરી શકાશે.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // સલામતી: અમે અને અમારા કlerલરે તે મેમરી પ્રારંભ કરી.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // અન્યથા આપણે ડૂમ્ડ (દા.ત., `v - 1 ulp` અને `v - 1 ulp` X વચ્ચેના કેટલાક મૂલ્યો ગોળાકાર થઈ રહ્યાં છે અને અન્ય રાઉન્ડ અપ થઈ રહ્યા છે) અને છોડી દઈએ છીએ.
        //
        None
    }
}

/// ડ્રેગન ફ fallલબેક સાથે ગ્રીસુ માટે ચોક્કસ અને નિશ્ચિત મોડ અમલીકરણ.
///
/// આનો ઉપયોગ મોટાભાગના કેસો માટે થવો જોઈએ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // સલામતી: ઉધાર તપાસનાર એટલું સ્માર્ટ નથી કે અમને `buf` નો ઉપયોગ કરવા દે
    // બીજા ઝેડબ્રાંચ0 ઝેડમાં, તેથી અમે અહીં આજીવન જીવન પ્રદાન કરીએ છીએ.
    // પરંતુ અમે ફક્ત `buf` નો ફરીથી ઉપયોગ કરીએ છીએ જો `format_exact_opt` `None` પરત આપે છે તેથી આ ઠીક છે.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}