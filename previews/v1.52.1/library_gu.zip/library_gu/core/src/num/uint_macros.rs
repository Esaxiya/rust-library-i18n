macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// સૌથી નાનું મૂલ્ય જે આ પૂર્ણાંક પ્રકાર દ્વારા રજૂ થઈ શકે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// આ પૂર્ણાંક પ્રકાર દ્વારા રજૂ કરી શકાય તેવું સૌથી મોટું મૂલ્ય.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// બીટ્સમાં આ પૂર્ણાંક પ્રકારનું કદ.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// આપેલ બેઝમાં સ્ટ્રિંગ સ્લાઈસને પૂર્ણાંકોમાં રૂપાંતરિત કરે છે.
        ///
        /// શબ્દમાળા અંકો પછી વૈકલ્પિક `+` ચિહ્ન હોવાની અપેક્ષા છે.
        ///
        /// અગ્રણી અને પાછળની વ્હાઇટ સ્પેસ ભૂલને રજૂ કરે છે.
        /// અંકો એ `radix` ના આધારે આ અક્ષરોનો સબસેટ છે:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// જો `radix` 2 થી 36 ની રેન્જમાં ન હોય તો આ કાર્ય panics.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાંની સંખ્યા પરત આપે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાં શૂન્યની સંખ્યા પરત કરે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાં અગ્રણી શૂન્યની સંખ્યા પરત કરે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાં પાછળની ઝીરોની સંખ્યા પરત કરે છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાં અગ્રણી લોકોની સંખ્યા પરત કરે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` ની દ્વિસંગી રજૂઆતમાં પાછળના લોકોની સંખ્યા પરત કરે છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// પરિણામી પૂર્ણાંકના અંતમાં કાપવામાં આવેલા બિટ્સને લપેટી, વિશિષ્ટ રકમ, `n` દ્વારા બીટ્સની ડાબી તરફ ડાબી બાજુ સ્થાનાંતરિત કરો.
        ///
        ///
        /// મહેરબાની કરીને નોંધ કરો કે આ તે જ કામગીરી નથી જે `<<` શિફ્ટિંગ operatorપરેટર છે!
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// પરિણામી પૂર્ણાંકની શરૂઆતમાં કાપવામાં આવેલા બીટ્સને વીંટાળવીને, ચોક્કસ રકમ, `n` દ્વારા બિટ્સને જમણી તરફ સ્થાનાંતરિત કરો.
        ///
        ///
        /// મહેરબાની કરીને નોંધ કરો કે આ તે જ કામગીરી નથી જે `>>` શિફ્ટિંગ operatorપરેટર છે!
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// પૂર્ણાંકોના બાઇટ ક્રમમાં વિરુદ્ધ થાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ચાલો m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// પૂર્ણાંકમાં બિટ્સનો ક્રમમાં ફેરવે છે.
        /// ઓછામાં ઓછું નોંધપાત્ર બીટ સૌથી નોંધપાત્ર બીટ બને છે, બીજું ઓછામાં ઓછું-નોંધપાત્ર બીટ બીજો સૌથી નોંધપાત્ર બીટ બને છે, વગેરે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ચાલો m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// કોઈ પૂર્ણાંકને મોટા એન્ડિયનથી લક્ષ્યના અંતમાં ફેરવે છે.
        ///
        /// મોટા એન્ડિયન પર આ કોઈ aપ છે.
        /// થોડું અંતિયા પર બાઇટ્સ અદલાબદલ થાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// જો સીએફજી! (લક્ષ્ય_સેન્ડિયન= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } બીજું {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// પૂર્ણાંકને નાના અંતર્ગતથી લક્ષ્યના અંતમાં ફેરવે છે.
        ///
        /// થોડું અંતિયા પર આ કોઈ નાપસંદગી છે.
        /// મોટા એન્ડિયન પર બાઇટ્સ અદલાબદલ થાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// જો સીએફજી! (લક્ષ્ય_સેન્ડિયન= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } બીજું {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ને લક્ષ્યના અંતથી મોટા અંતમાં ફેરવે છે.
        ///
        /// મોટા એન્ડિયન પર આ કોઈ aપ છે.
        /// થોડું અંતિયા પર બાઇટ્સ અદલાબદલ થાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// જો સીએફજી! (લક્ષ્ય_સેન્ડિયન= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } બીજું { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // કે નહીં?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ને લક્ષ્યના અંતથી થોડા અંતમાં ફેરવે છે.
        ///
        /// થોડું અંતિયા પર આ કોઈ નાપસંદગી છે.
        /// મોટા એન્ડિયન પર બાઇટ્સ અદલાબદલ થાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// જો સીએફજી! (લક્ષ્ય_સેન્ડિયન= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } બીજું { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// પૂર્ણાંક ઉમેર્યું.
        /// ગણતરીઓ `self + rhs`, જો ઓવરફ્લો થયો હોય તો `None` પાછા ફરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// પૂર્ણાંક અનચેક કરેલ પૂર્ણાંક ઉમેરો.ગણતરીઓ `self + rhs`, એમ ધારીને કે ઓવરફ્લો થઈ શકશે નહીં.
        /// આ જ્યારે અનિશ્ચિત વર્તણૂકમાં પરિણમે છે
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // સલામતી: કlerલરને `unchecked_add` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// પૂર્ણાંક બાદબાકી તપાસી.
        /// ગણતરીઓ `self - rhs`, જો ઓવરફ્લો થયો હોય તો `None` પાછા ફરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// અનચેક કરેલ પૂર્ણાંક બાદબાકી.ગણતરીઓ `self - rhs`, એમ ધારીને કે ઓવરફ્લો થઈ શકશે નહીં.
        /// આ જ્યારે અનિશ્ચિત વર્તણૂકમાં પરિણમે છે
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // સલામતી: કlerલરને `unchecked_sub` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// પૂર્ણાંક પૂર્ણાંક ગુણાકાર.
        /// ગણતરીઓ `self * rhs`, જો ઓવરફ્લો થયો હોય તો `None` પાછા ફરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// અનચેક કરેલ પૂર્ણાંક ગુણાકાર.ગણતરીઓ `self * rhs`, એમ ધારીને કે ઓવરફ્લો થઈ શકશે નહીં.
        /// આ જ્યારે અનિશ્ચિત વર્તણૂકમાં પરિણમે છે
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // સલામતી: કlerલરને `unchecked_mul` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// પૂર્ણાંક વિભાગ તપાસી
        /// `self / rhs` ની ગણતરીઓ, `None` પરત જો `rhs == 0`.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // સલામતી: ઉપર શૂન્ય દ્વારા શૂન્યની ચકાસણી કરવામાં આવી છે અને સહી ન કરેલા પ્રકારોનો બીજો કોઈ નથી
                // વિભાગ માટે નિષ્ફળતા સ્થિતિઓ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// યુક્લિડીયન વિભાગ તપાસી.
        /// `self.div_euclid(rhs)` ની ગણતરીઓ, `None` પરત જો `rhs == 0`.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// પૂર્ણાંકની બાકીની તપાસ કરી.
        /// `self % rhs` ની ગણતરીઓ, `None` પરત જો `rhs == 0`.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // સલામતી: ઉપર શૂન્ય દ્વારા શૂન્યની ચકાસણી કરવામાં આવી છે અને સહી ન કરેલા પ્રકારોનો બીજો કોઈ નથી
                // વિભાગ માટે નિષ્ફળતા સ્થિતિઓ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// યુક્લિડિયન મોડ્યુલો તપાસી.
        /// `self.rem_euclid(rhs)` ની ગણતરીઓ, `None` પરત જો `rhs == 0`.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// અવગણના તપાસી.ગણતરીઓ `-self`, `None` પરત કર્યા સિવાય `સ્વ==
        /// 0`.
        ///
        /// નોંધ લો કે કોઈપણ સકારાત્મક પૂર્ણાંકને અવગણવું એ ઓવરફ્લો થશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// પાળી ચકાસાયેલ.
        /// `self << rhs` ની ગણતરીઓ, `None` પરત જો `rhs` એ `self` માં બીટ્સની સંખ્યા કરતા મોટી અથવા બરાબર છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// પાળીને તપાસો.
        /// `self >> rhs` ની ગણતરીઓ, `None` પરત જો `rhs` એ `self` માં બીટ્સની સંખ્યા કરતા મોટી અથવા બરાબર છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// તપાસો
        /// ગણતરીઓ `self.pow(exp)`, જો ઓવરફ્લો થયો હોય તો `None` પાછા ફરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // સમાપ્ત થયા પછી!=0, છેલ્લે સમાપ્તિ 1 હોવી જ જોઇએ.
            // ઘાતકના અંતિમ બીટ સાથે અલગથી ડીલ કરો, કારણ કે પછીથી આધારને ચોરસ કરવો જરૂરી નથી અને તે બિનજરૂરી ઓવરફ્લોનું કારણ બની શકે છે.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// પૂર્ણાંક ઉમેરો સંતૃપ્ત.
        /// ગણતરીઓ `self + rhs`, ઓવરફ્લો થવાને બદલે સંખ્યાત્મક સીમા પર સંતૃપ્ત કરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// પૂર્ણાંક પૂર્ણાંક બાદબાકી કરો.
        /// ગણતરીઓ `self - rhs`, ઓવરફ્લો થવાને બદલે સંખ્યાત્મક સીમા પર સંતૃપ્ત કરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// પૂર્ણાંક પૂર્ણાંક ગુણાકાર.
        /// ગણતરીઓ `self * rhs`, ઓવરફ્લો થવાને બદલે સંખ્યાત્મક સીમા પર સંતૃપ્ત કરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// પૂર્ણાંક પૂર્તિ સંતોષ.
        /// ગણતરીઓ `self.pow(exp)`, ઓવરફ્લો થવાને બદલે સંખ્યાત્મક સીમા પર સંતૃપ્ત કરો.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// વીંટાળવું (modular) ઉમેરો.
        /// પ્રકારોની સીમા પર આસપાસ વીંટાળીને `self + rhs` ની ગણતરીઓ.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// રેપિંગ (modular) બાદબાકી.
        /// પ્રકારોની સીમા પર આસપાસ વીંટાળીને `self - rhs` ની ગણતરીઓ.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// રેપિંગ (modular) ગુણાકાર.
        /// પ્રકારોની સીમા પર આસપાસ વીંટાળીને `self * rhs` ની ગણતરીઓ.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// કૃપા કરીને નોંધો કે આ ઉદાહરણ પૂર્ણાંકોના પ્રકારો વચ્ચે વહેંચાયેલું છે.
        /// જે સમજાવે છે કે શા માટે અહીં `u8` નો ઉપયોગ થાય છે.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// રેપિંગ (modular) વિભાગ.ગણતરીઓ `self / rhs`.
        /// સહી ન કરેલા પ્રકારો પર આવરિત વિભાગ એ ફક્ત સામાન્ય વિભાગ છે.
        /// રેપિંગનો ક્યારેય કોઈ રસ્તો નથી.
        /// આ કાર્ય અસ્તિત્વમાં છે, જેથી રેપિંગ inપરેશનમાં તમામ કામગીરીનો હિસાબ કરવામાં આવે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// લપેટી યુકેલિડીયન વિભાગ.ગણતરીઓ `self.div_euclid(rhs)`.
        /// સહી ન કરેલા પ્રકારો પર આવરિત વિભાગ એ ફક્ત સામાન્ય વિભાગ છે.
        /// રેપિંગનો ક્યારેય કોઈ રસ્તો નથી.
        /// આ કાર્ય અસ્તિત્વમાં છે, જેથી રેપિંગ inપરેશનમાં તમામ કામગીરીનો હિસાબ કરવામાં આવે.
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, ભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ બરાબર `self.wrapping_div(rhs)` જેટલી છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// રેપિંગ (modular) બાકીની.ગણતરીઓ `self % rhs`.
        /// સહી ન કરેલા પ્રકારો પર વીંટળાયેલી બાકીની ગણતરી એ ફક્ત નિયમિત બાકીની ગણતરી છે.
        ///
        /// રેપિંગનો ક્યારેય કોઈ રસ્તો નથી.
        /// આ કાર્ય અસ્તિત્વમાં છે, જેથી રેપિંગ inપરેશનમાં તમામ કામગીરીનો હિસાબ કરવામાં આવે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// લપેટી યુકલિડેન મોડ્યુલો.ગણતરીઓ `self.rem_euclid(rhs)`.
        /// સહી ન કરેલા પ્રકારો પર લપેટેલા મોડ્યુલો ગણતરી ફક્ત નિયમિત બાકીની ગણતરી છે.
        /// રેપિંગનો ક્યારેય કોઈ રસ્તો નથી.
        /// આ કાર્ય અસ્તિત્વમાં છે, જેથી રેપિંગ inપરેશનમાં તમામ કામગીરીનો હિસાબ કરવામાં આવે.
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, ભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ બરાબર `self.wrapping_rem(rhs)` જેટલી છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// રેપિંગ (modular) નેગેગેશન.
        /// પ્રકારોની સીમા પર આસપાસ વીંટાળીને `-self` ની ગણતરીઓ.
        ///
        /// સહી વિનાનાં પ્રકારોમાં નકારાત્મક સમકક્ષ ન હોવાથી આ કાર્યની બધી એપ્લિકેશનો લપેટી જશે (`-0` સિવાય).
        /// અનુરૂપ સહી કરેલ પ્રકારનાં મહત્તમ કરતાં નાના મૂલ્યો માટે પરિણામ અનુરૂપ સહી કરેલ મૂલ્ય કાસ્ટ કરવા જેવું જ છે.
        ///
        /// કોઈપણ મોટા મૂલ્યો `MAX + 1 - (val - MAX - 1)` ની બરાબર છે જ્યાં `MAX` અનુરૂપ સહી કરેલ પ્રકારનું મહત્તમ છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// કૃપા કરીને નોંધો કે આ ઉદાહરણ પૂર્ણાંકોના પ્રકારો વચ્ચે વહેંચાયેલું છે.
        /// જે સમજાવે છે કે શા માટે અહીં `i8` નો ઉપયોગ થાય છે.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// ઝેડ 0 પેનીક 0 ઝેડ-ફ્રી બીટવાઇઝ શિફ્ટ-ડાબે;
        /// `self << mask(rhs)` ઉપજ આપે છે, જ્યાં `mask`, `rhs` ના કોઈપણ ઉચ્ચ ઓર્ડર બિટ્સને દૂર કરે છે જેના કારણે પાળી પ્રકારનાં બિટવિડ્થ કરતાં વધી જશે.
        ///
        /// નોંધ લો કે આ *રોટેટ-ડાબી જેવું જ નથી*;એલ.પી.એસ.માંથી બહાર નીકળી ગયેલા બીટ્સને બીજા છેડે પરત કરવાને બદલે, રેપિંગ શિફ્ટ-ડાબેથી આરએચએસ એ પ્રકારની શ્રેણી માટે મર્યાદિત છે.
        /// આદિમ પૂર્ણાંકોના પ્રકારો બધા એક [`rotate_left`](Self::rotate_left) ફંક્શનને લાગુ કરે છે, જે તમને તેના બદલે જોઈએ તે હોઈ શકે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // સલામતી: પ્રકારનાં બીટાઇઝ દ્વારા માસ્કિંગ ખાતરી કરે છે કે આપણે શિફ્ટ ન કરીએ
            // હદ બહાર
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ઝેડ 0 પેનીક 0 ઝેડ-ફ્રી બીટવાઇઝ શિફ્ટ-રાઇટ;
        /// `self >> mask(rhs)` ઉપજ આપે છે, જ્યાં `mask`, `rhs` ના કોઈપણ ઉચ્ચ ઓર્ડર બિટ્સને દૂર કરે છે જેના કારણે પાળી પ્રકારનાં બિટવિડ્થ કરતાં વધી જશે.
        ///
        /// નોંધ લો કે આ *રોટેટ-રાઇટ જેવું જ નથી*;રેપિંગ શિફ્ટ-રાઇટના આરએચએસ એ એલએચએસમાંથી સ્થાનાંતરિત બીટ્સને બીજા છેડે પરત કરવાને બદલે પ્રકારની શ્રેણીમાં મર્યાદિત છે.
        /// આદિમ પૂર્ણાંકોના પ્રકારો બધા એક [`rotate_right`](Self::rotate_right) ફંક્શનને લાગુ કરે છે, જે તમને તેના બદલે જોઈએ તે હોઈ શકે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // સલામતી: પ્રકારનાં બીટાઇઝ દ્વારા માસ્કિંગ ખાતરી કરે છે કે આપણે શિફ્ટ ન કરીએ
            // હદ બહાર
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// રેપિંગ (modular) એક્સપોનેશન.
        /// પ્રકારોની સીમા પર આસપાસ વીંટાળીને `self.pow(exp)` ની ગણતરીઓ.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // સમાપ્ત થયા પછી!=0, છેલ્લે સમાપ્તિ 1 હોવી જ જોઇએ.
            // ઘાતકના અંતિમ બીટ સાથે અલગથી ડીલ કરો, કારણ કે પછીથી આધારને ચોરસ કરવો જરૂરી નથી અને તે બિનજરૂરી ઓવરફ્લોનું કારણ બની શકે છે.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ની ગણતરી કરે છે
        ///
        /// અંકગણિત ઓવરફ્લો થાય છે કે કેમ તે દર્શાવતી બુલિયન સાથેના વધારાના ભાગને પાછો આપે છે.
        /// જો કોઈ ઓવરફ્લો થયો હોત, તો આવરિત મૂલ્ય પાછું આવે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ની ગણતરી કરે છે
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે બાદબાકીનો એક ભાગ પાછો આપે છે.
        /// જો કોઈ ઓવરફ્લો થયો હોત, તો આવરિત મૂલ્ય પાછું આવે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` અને `rhs` ના ગુણાકારની ગણતરી કરે છે.
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે ગુણાકારનો એક ભાગ પાછો આપે છે.
        /// જો કોઈ ઓવરફ્લો થયો હોત, તો આવરિત મૂલ્ય પાછું આવે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// કૃપા કરીને નોંધો કે આ ઉદાહરણ પૂર્ણાંકોના પ્રકારો વચ્ચે વહેંચાયેલું છે.
        /// જે સમજાવે છે કે શા માટે અહીં `u32` નો ઉપયોગ થાય છે.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// જ્યારે `self` `rhs` દ્વારા વિભાજિત થાય છે ત્યારે વિભાજકની ગણતરી કરે છે.
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે વિભાજકનું એક ભાગ આપે છે.
        /// નોંધ કરો કે સહી વગરનાં પૂર્ણાંકો માટે ઓવરફ્લો ક્યારેય થતો નથી, તેથી બીજું મૂલ્ય હંમેશાં `false` હોય છે.
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// યુક્લિડીયન ડિવિઝન `self.div_euclid(rhs)` ના ભાગની ગણતરી કરે છે.
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે વિભાજકનું એક ભાગ આપે છે.
        /// નોંધ કરો કે સહી વગરનાં પૂર્ણાંકો માટે ઓવરફ્લો ક્યારેય થતો નથી, તેથી બીજું મૂલ્ય હંમેશાં `false` હોય છે.
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, ભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ બરાબર `self.overflowing_div(rhs)` જેટલી છે.
        ///
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// જ્યારે `self` ને `rhs` દ્વારા વિભાજિત કરવામાં આવે ત્યારે બાકીની ગણતરી કરે છે.
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે વિભાજન કર્યા પછી બાકીનું એક ભાગ પાછું આપે છે.
        /// નોંધ કરો કે સહી વગરનાં પૂર્ણાંકો માટે ઓવરફ્લો ક્યારેય થતો નથી, તેથી બીજું મૂલ્ય હંમેશાં `false` હોય છે.
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Euclidean વિભાગ દ્વારા જાતે જ બાકીના `self.rem_euclid(rhs)` ની ગણતરી કરે છે.
        ///
        /// અંકગણિત ઓવરફ્લો થશે કે નહીં તે દર્શાવતી બુલિયન સાથે વિભાજન કર્યા પછી મોડ્યુલોનો ટુપલ પાછો આપે છે.
        /// નોંધ કરો કે સહી વગરનાં પૂર્ણાંકો માટે ઓવરફ્લો ક્યારેય થતો નથી, તેથી બીજું મૂલ્ય હંમેશાં `false` હોય છે.
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, વિભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ ક્રિયા બરાબર `self.overflowing_rem(rhs)` જેટલી છે.
        ///
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ઓવરફ્લોઇંગ ફેશનમાં સ્વ નેગેટ કરે છે.
        ///
        /// આ સહી ન કરેલા મૂલ્યની ઉપેક્ષા રજૂ કરે છે તે મૂલ્ય પરત કરવા માટે રેપિંગ usingપરેશનનો ઉપયોગ કરીને `!self + 1` પરત આપે છે.
        /// નોંધ લો કે હકારાત્મક સહી વિનાનાં મૂલ્યો માટે હંમેશાં ઓવરફ્લો થાય છે, પરંતુ 0 ને નકારવું એ ઓવરફ્લો થતું નથી.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` બિટ્સ દ્વારા સ્વચાલિત પાળી.
        ///
        /// બુલિયન સાથે સ્વના સ્થાનાંતરિત સંસ્કરણનો એક ભાગ પાછો આપે છે જે સૂચવે છે કે પાળીનું મૂલ્ય બીટ્સની સંખ્યા કરતા વધારે અથવા બરાબર હતું કે નહીં.
        /// જો શિફ્ટનું મૂલ્ય ખૂબ મોટું છે, તો પછી મૂલ્ય માસ્ક કરેલું છે (N-1) જ્યાં એન બીટ્સની સંખ્યા છે, અને આ મૂલ્ય પછી શિફ્ટ કરવા માટે વપરાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` બિટ્સ દ્વારા સ્વચાલિત સ્થળાંતર.
        ///
        /// બુલિયન સાથે સ્વના સ્થાનાંતરિત સંસ્કરણનો એક ભાગ પાછો આપે છે જે સૂચવે છે કે પાળીનું મૂલ્ય બીટ્સની સંખ્યા કરતા વધારે અથવા બરાબર હતું કે નહીં.
        /// જો શિફ્ટનું મૂલ્ય ખૂબ મોટું છે, તો પછી મૂલ્ય માસ્ક કરેલું છે (N-1) જ્યાં એન બીટ્સની સંખ્યા છે, અને આ મૂલ્ય પછી શિફ્ટ કરવા માટે વપરાય છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// સ્ક્વેરિંગ દ્વારા પ્રક્ષેપણનો ઉપયોગ કરીને, `exp` ની શક્તિમાં સ્વ વધારો કરે છે.
        ///
        /// ઓવરફ્લો થયું કે નહીં તે દર્શાવતા bool ની સાથે એક્સપોન્સિએશનનું એક મુખ્ય ભાગ પાછું આપે છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, સાચું));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ઓવરફ્લોઇંગ_મુલના પરિણામો સ્ટોર કરવા માટે સ્ક્રેચ સ્પેસ.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // સમાપ્ત થયા પછી!=0, છેલ્લે સમાપ્તિ 1 હોવી જ જોઇએ.
            // ઘાતકના અંતિમ બીટ સાથે અલગથી ડીલ કરો, કારણ કે પછીથી આધારને ચોરસ કરવો જરૂરી નથી અને તે બિનજરૂરી ઓવરફ્લોનું કારણ બની શકે છે.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// સ્ક્વેરિંગ દ્વારા પ્રક્ષેપણનો ઉપયોગ કરીને, `exp` ની શક્તિમાં સ્વ વધારો કરે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // સમાપ્ત થયા પછી!=0, છેલ્લે સમાપ્તિ 1 હોવી જ જોઇએ.
            // ઘાતકના અંતિમ બીટ સાથે અલગથી ડીલ કરો, કારણ કે પછીથી આધારને ચોરસ કરવો જરૂરી નથી અને તે બિનજરૂરી ઓવરફ્લોનું કારણ બની શકે છે.
            //
            //
            acc * base
        }

        /// યુક્લિડિયન વિભાગ કરે છે.
        ///
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, ભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ બરાબર `self / rhs` જેટલી છે.
        ///
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` ની ઓછામાં ઓછી બાકીની ગણતરી.
        ///
        /// કારણ કે, સકારાત્મક પૂર્ણાંકો માટે, ભાગની બધી સામાન્ય વ્યાખ્યાઓ સમાન છે, આ બરાબર `self % rhs` જેટલી છે.
        ///
        ///
        /// # Panics
        ///
        /// જો `rhs` 0 છે, તો આ ફંક્શન panic કરશે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// જો કેટલાક `k` માટે `self == 2^k` હોય અને માત્ર જો `true` આપે છે.
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // બે ની આગામી પાવર કરતા એક ઓછી આપે છે.
        // (8u8 માટે આગળની બેની શક્તિ 8u8 છે અને 6u8 માટે તે 8u8 છે)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // આ પદ્ધતિ ઓવરફ્લો થઈ શકતી નથી, કારણ કે `next_power_of_two` ઓવરફ્લો કેસોમાં તે તેના બદલે પ્રકારનું મહત્તમ મૂલ્ય પાછું ખેંચીને સમાપ્ત થાય છે, અને 0 માટે 0 પરત કરી શકે છે.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // સલામતી: કારણ કે `p > 0`, તે સંપૂર્ણપણે અગ્રણી ઝીરોથી સમાવી શકતું નથી.
            // તેનો અર્થ એ કે શિફ્ટ હંમેશા ઇન-બાઉન્ડ્સમાં હોય છે, અને જ્યારે કેટલાક પ્રોસેસરો (જેમ કે ઇન્ટેલ પ્રિ-હેસવેલ) વધુ કાર્યક્ષમ સીટીએલઝ ઇન્ટર્નિક્સ હોય છે જ્યારે દલીલ બિન-શૂન્ય હોય.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` કરતા બરાબર અથવા બરાબર બેની સૌથી નાની શક્તિ આપે છે.
        ///
        /// જ્યારે રીટર્ન વેલ્યુ ઓવરફ્લો થાય છે (દા.ત., પ્રકાર `uN` માટે `self > (1 << (N-1))`), તે ડિબગ મોડમાં panics અને રીટર્ન મૂલ્યને રીલિઝ મોડમાં 0 પર આવરિત કરવામાં આવે છે (એકમાત્ર પરિસ્થિતિ જેમાં પદ્ધતિ 0 પાછો આવી શકે છે).
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` કરતા બરાબર અથવા બરાબર બેની સૌથી નાની શક્તિ આપે છે.
        /// જો બેની આગળની શક્તિ પ્રકારનાં મહત્તમ મૂલ્ય કરતા વધારે હોય, તો `None` પરત આવે છે, નહીં તો બેની શક્તિ `Some` માં લપેટી છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` કરતા બરાબર અથવા બરાબર બેની સૌથી નાની શક્તિ આપે છે.
        /// જો બેની આગળની શક્તિ પ્રકારનાં મહત્તમ મૂલ્ય કરતા વધારે હોય, તો વળતરનું મૂલ્ય `0` પર આવરિત છે.
        ///
        ///
        /// # Examples
        ///
        /// મૂળભૂત વપરાશ:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// મોટા પૂર્ણાંક (network) બાઇટ ક્રમમાં આ પૂર્ણાંકની મેમરી રજૂઆતને બાઇટ એરે તરીકે પાછા ફરો.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// લિટલ-એન્ડિયન બાઇટ ક્રમમાં આ પૂર્ણાંકની મેમરી રજૂઆતને બાઇટ એરે તરીકે પાછા ફરો.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// મૂળ પૂર્તિ ક્રમમાં બાઇટ એરે તરીકે આ પૂર્ણાંકની મેમરી રજૂઆત.
        ///
        /// જેમ કે લક્ષ્ય પ્લેટફોર્મની મૂળ અંતિમતાનો ઉપયોગ થાય છે, તેમ પોર્ટેબલ કોડે [`to_be_bytes`] અથવા [`to_le_bytes`] નો ઉપયોગ કરવો જોઈએ, તેના બદલે, યોગ્ય.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     બાઇટ્સ, જો સીએફજી! (લક્ષ્ય_માંડિયન= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } બીજું {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // સલામતી: કોન્સ્ટ અવાજ કારણ કે પૂર્ણાંકો સાદા જૂના ડેટાટાઇપ્સ હોય છે જેથી આપણે હંમેશાં હોઈ શકીએ
        // તેમને બાઇટ્સના એરેમાં ટ્રાન્સમિટ કરો
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // સલામતી: પૂર્ણાંકો એ સાદા જૂનાં ડેટાટાઇપ્સ હોય છે તેથી અમે તેને હંમેશાં ટ્રાન્સમિટ કરી શકીએ
            // બાઇટ્સના એરે
            unsafe { mem::transmute(self) }
        }

        /// મૂળ પૂર્તિ ક્રમમાં બાઇટ એરે તરીકે આ પૂર્ણાંકની મેમરી રજૂઆત.
        ///
        ///
        /// [`to_ne_bytes`] જ્યારે પણ શક્ય હોય ત્યારે આને પસંદ કરવું જોઈએ.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// લેટ્સ બાઇટ્સ= num.as_ne_bytes();
        /// assert_eq!(
        ///     બાઇટ્સ, જો સીએફજી! (લક્ષ્ય_માંડિયન= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } બીજું {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // સલામતી: પૂર્ણાંકો એ સાદા જૂનાં ડેટાટાઇપ્સ હોય છે તેથી અમે તેને હંમેશાં ટ્રાન્સમિટ કરી શકીએ
            // બાઇટ્સના એરે
            unsafe { &*(self as *const Self as *const _) }
        }

        /// મોટા એન્ડિઅન્સમાં બાઇટ એરે તરીકે તેની રજૂઆતમાંથી નેટીવ એડીઅઅનિયન પૂર્ણાંક મૂલ્ય બનાવો.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto નો ઉપયોગ કરો;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ઇનપુટ=બાકી;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// થોડું અંતિયામાં બાઇટ એરે તરીકે તેના પ્રતિનિધિત્વમાંથી નેટીવ ઇન્ડિયન પૂર્ણાંક મૂલ્ય બનાવો.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto નો ઉપયોગ કરો;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ઇનપુટ=બાકી;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// નેટીવ એન્ડિઅનેસમાં બાઇટ એરે તરીકે તેની મેમરી રજૂઆતમાંથી નેશનલ એન્ડિયન પૂર્ણાંક મૂલ્ય બનાવો.
        ///
        /// જેમ કે લક્ષ્ય પ્લેટફોર્મની મૂળ અંતિમતાનો ઉપયોગ થાય છે, પોર્ટેબલ કોડ સંભવત [`from_be_bytes`] અથવા [`from_le_bytes`] નો ઉપયોગ કરવા માંગે છે, તેના બદલે યોગ્ય.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } બીજું {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto નો ઉપયોગ કરો;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ઇનપુટ=બાકી;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // સલામતી: કોન્સ્ટ અવાજ કારણ કે પૂર્ણાંકો સાદા જૂના ડેટાટાઇપ્સ હોય છે જેથી આપણે હંમેશાં હોઈ શકીએ
        // તેમને પરિવહન
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // સલામતી: પૂર્ણાંકો એ સાદા જૂનાં ડેટાટાઇપ્સ હોય છે જેથી અમે હંમેશાં તેમની પાસે ટ્રાન્સમિટ કરી શકીએ
            unsafe { mem::transmute(bytes) }
        }

        /// નવો કોડ ઉપયોગ કરવાનું પસંદ કરે છે
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// સૌથી નાનું મૂલ્ય આપે છે જે આ પૂર્ણાંક પ્રકાર દ્વારા રજૂ થઈ શકે છે.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// નવો કોડ ઉપયોગ કરવાનું પસંદ કરે છે
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// આ પૂર્ણાંક પ્રકાર દ્વારા રજૂ થઈ શકે તે સૌથી મોટું મૂલ્ય આપે છે.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}