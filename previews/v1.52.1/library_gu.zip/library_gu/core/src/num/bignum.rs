//! કસ્ટમ મનસ્વી-ચોકસાઇ નંબર (bignum) અમલીકરણ.
//!
//! આ સ્ટેક મેમરીના ખર્ચે heગલા ફાળવણીને ટાળવા માટે રચાયેલ છે.
//! સૌથી વધુ ઉપયોગમાં લેવાતા બિગ્નમ પ્રકાર, `Big32x40`, 32 × 40=1,280 બિટ્સ દ્વારા મર્યાદિત છે અને સ્ટેક મેમરીના વધુમાં વધુ 160 બાઇટ્સ લેશે.
//! આ બધા સંભવિત મર્યાદિત `f64` મૂલ્યોને રાઉન્ડ-ટ્રિપિંગ કરવા માટે પર્યાપ્ત કરતાં વધુ છે.
//!
//! સૈદ્ધાંતિક રીતે વિવિધ ઇનપુટ્સ માટે બહુવિધ બિગનમ પ્રકારો હોવું શક્ય છે, પરંતુ અમે કોડ ફૂલેલાને ટાળવા માટે આમ કરતા નથી.
//!
//! દરેક બિગનમ હજી પણ વાસ્તવિક વપરાશ માટે શોધી કા forવામાં આવે છે, તેથી તે સામાન્ય રીતે વાંધો નથી.
//!

// આ મોડ્યુલ ફક્ત ડેક 2 ફ્લ્ટ અને ફ્લ્ટ 2 ડીઇક માટે જ છે, અને ફક્ત મૂળભૂત લોકોના કારણે.
// તેનો હેતુ હંમેશા સ્થિર થવાનો નથી.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// બિગનોમ્સ દ્વારા જરૂરી અંકગણિત કામગીરી.
pub trait FullOps: Sized {
    /// `(carry', v')` આપે છે જેમ કે `carry' * 2^W + v' = self + other + carry`, જ્યાં `W` એ `Self` માં બિટ્સની સંખ્યા છે.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` આપે છે જેમ કે `carry'*2^W + v' = self* other + carry`, જ્યાં `W` એ `Self` માં બિટ્સની સંખ્યા છે.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` આપે છે જેમ કે `carry'*2^W + v' = self* other + other2 + carry`, જ્યાં `W` એ `Self` માં બિટ્સની સંખ્યા છે.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` જેમ કે `borrow *2^W + self = quo* other + rem` અને `0 <= rem < other` પરત આપે છે, જ્યાં `W` એ `Self` માં બિટ્સની સંખ્યા છે.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // આ ઓવરફ્લો કરી શકશે નહીં;આઉટપુટ `0` અને `2 * 2^nbits - 1` ની વચ્ચે છે.
                    // FIXME: શું એલએલવીએમ આને એડીસી અથવા સમાનમાં izeપ્ટિમાઇઝ કરશે?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // આ ઓવરફ્લો કરી શકશે નહીં;
                    // આઉટપુટ `0` અને `2^nbits * (2^nbits - 1)` ની વચ્ચે છે.
                    // FIXME: શું એલએલવીએમ આને એડીસી અથવા સમાનમાં izeપ્ટિમાઇઝ કરશે?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // આ ઓવરફ્લો કરી શકશે નહીં;
                    // આઉટપુટ `0` અને `2^nbits * (2^nbits - 1)` ની વચ્ચે છે.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // આ ઓવરફ્લો કરી શકશે નહીં;આઉટપુટ `0` અને `other * (2^nbits - 1)` ની વચ્ચે છે.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // આને સક્ષમ કરવા માટે આરએફસી #521 જુઓ.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// 5 અંકમાં રજૂ કરવાની શક્તિની કોષ્ટક.ખાસ કરીને, સૌથી મોટું {u8, u16, u32} મૂલ્ય જે પાંચની શક્તિ છે, વત્તા અનુરૂપ ખાતા.
/// `mul_pow5` માં વપરાય છે.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// પૂર્ણાંક સ્ટેક-ફાળવેલ મનસ્વી-ચોકસાઇ (ચોક્કસ મર્યાદા સુધી).
        ///
        /// આ આપેલ પ્રકાર ("digit") ની ફિક્સ-સાઇઝ એરે દ્વારા સમર્થિત છે.
        /// જ્યારે એરે ખૂબ મોટો નથી (સામાન્ય રીતે કેટલાક સો બાઇટ્સ), તેને અવિચારી રૂપે નકલ કરવાથી પ્રભાવ હિટ થઈ શકે છે.
        ///
        /// આમ આ ઇરાદાપૂર્વક `Copy` નથી.
        ///
        /// ઓવરફ્લોના કિસ્સામાં બિગનમ્સ panic પર ઉપલબ્ધ તમામ કામગીરી.
        /// કlerલર મોટા પર્યાપ્ત બિગનમ પ્રકારોનો ઉપયોગ કરવા માટે જવાબદાર છે.
        pub struct $name {
            /// ઉપયોગમાં મહત્તમ "digit" પર એક વત્તા setફસેટ.
            /// આ ઘટતું નથી, તેથી ગણતરીના ક્રમમાં ધ્યાન રાખો.
            /// `base[size..]` શૂન્ય હોવું જોઈએ.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` નું પ્રતિનિધિત્વ કરે છે જ્યાં `W` એ અંકના પ્રકારમાં બિટ્સની સંખ્યા છે.
            base: [$ty; $n],
        }

        impl $name {
            /// એક અંકથી બિગ્નમ બનાવે છે.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` મૂલ્યથી બિગ્નમ બનાવે છે.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// સ્લાઈસ `[a, b, c, ...]` તરીકે આંતરિક અંકો પરત કરે છે જેમ કે આંકડાકીય મૂલ્ય `a + b *2^W + c* 2^(2W) + ...` છે જ્યાં `W` એ અંકો પ્રકારનાં બિટ્સની સંખ્યા છે.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// બીટ 0 એ ઓછામાં ઓછું નોંધપાત્ર છે ત્યાં `i`-th બીટ પરત કરે છે.
            /// બીજા શબ્દોમાં કહીએ તો, વજન `2^i` સાથેનો બીટ.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// જો બિગનમ શૂન્ય હોય તો `true` આપે છે.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// આ મૂલ્યને રજૂ કરવા માટે જરૂરી બિટ્સની સંખ્યા પરત કરે છે.
            /// નોંધ લો કે શૂન્યને 0 બિટ્સની જરૂરિયાત માનવામાં આવે છે.
            pub fn bit_length(&self) -> usize {
                // ખૂબ જ મહત્વપૂર્ણ અંકો પર જાઓ જે શૂન્ય છે.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // ત્યાં કોઈ શૂન્ય સિવાયના અંકો નથી, એટલે કે, સંખ્યા શૂન્ય છે.
                    return 0;
                }
                // આને leading_zeros() અને બીટ શિફ્ટથી beપ્ટિમાઇઝ કરી શકાય છે, પરંતુ તે કદાચ મુશ્કેલીમાં યોગ્ય નથી.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// પોતાને `other` ઉમેરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// પોતાની પાસેથી `other` બાદબાકી કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// અંકોના કદના `other` દ્વારા પોતાને ગુણાકાર કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// પોતાને `2^bits` દ્વારા ગુણાકાર કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` બિટ્સ દ્વારા પાળી
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` બિટ્સ દ્વારા પાળી
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // સેલ્ફબેઝ [.. અંકો] શૂન્ય છે, શિફ્ટ કરવાની જરૂર નથી
                }

                self.size = sz;
                self
            }

            /// પોતાને `5^e` દ્વારા ગુણાકાર કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // ત્યાં 2 ^ n પર બરાબર n ટ્રાયલિંગ ઝીરો છે, અને ફક્ત સંબંધિત અંકોના કદમાં સતત બે શક્તિઓ હોય છે, તેથી આ કોષ્ટક માટે અનુકૂળ અનુક્રમણિકા છે.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // શક્ય હોય ત્યાં સુધી સૌથી મોટી સિંગલ-ડિજિટ પાવર સાથે ગુણાકાર ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... પછી બાકીની રકમ સમાપ્ત કરો.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (જ્યાં `W` એ અંકોના પ્રકારમાં બિટ્સની સંખ્યા છે) દ્વારા વર્ણવેલ સંખ્યા દ્વારા પોતાને ગુણાકાર કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ આપે છે.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // આંતરિક નિયમિત.જ્યારે aa.len() <= bb.len() હોય ત્યારે શ્રેષ્ઠ કાર્ય કરે છે.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// પોતાને અંકોના કદના `other` દ્વારા વિભાજિત કરે છે અને તેનો પોતાનો પરિવર્તનશીલ સંદર્ભ *અને* બાકીનો આપે છે.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// બીજા બિગનમ દ્વારા સ્વયં વિભાજિત કરો, ભાવિ સાથે `q` અને બાકીના સાથે `r` પર ફરીથી લખો.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // મૂર્ખ ધીમું base-2 લાંબી ડિવિઝન લીધું છે
                // https://en.wikipedia.org/wiki/Division_algorithm
                // લાંબી ડિવિઝન માટે FIXME વધુ મોટા આધાર ($ty) નો ઉપયોગ કરે છે.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // બીટ `i` ને q થી 1 સેટ કરો.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` માટેનો અંકોનો પ્રકાર.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// આનો ઉપયોગ ફક્ત પરીક્ષણ માટે થાય છે.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}