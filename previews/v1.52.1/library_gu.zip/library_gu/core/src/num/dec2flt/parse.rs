//! ફોર્મના દશાંશ શબ્દમાળાને માન્ય અને વિઘટન:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! બીજા શબ્દોમાં કહીએ તો, બે અપવાદો સાથે પ્રમાણભૂત ફ્લોટિંગ-પોઇન્ટ સિન્ટેક્સ: કોઈ નિશાની નહીં, અને "inf" અને "NaN" નું સંચાલન નહીં.આ ડ્રાઇવર ફંક્શન (super::dec2flt) દ્વારા નિયંત્રિત કરવામાં આવે છે.
//!
//! માન્ય ઇનપુટ્સને ઓળખવું પ્રમાણમાં સરળ હોવા છતાં, આ મોડ્યુલને અસંખ્ય અમાન્ય અમાન્યતાઓને પણ નકારી કા ,વા પડશે, ક્યારેય ઝેડપpanનિક 80 ઝેડ નહીં, અને અસંખ્ય તપાસો કરો કે જે અન્ય મોડ્યુલો બદલામાં ઝેડપpanનિકિક ઝેડ (અથવા ઓવરફ્લો) પર આધારિત નથી.
//!
//! બાબતોને વધુ ખરાબ કરવા માટે, ઇનપુટ પર એક જ પાસમાં તે બધું થાય છે.
//! તેથી, કોઈપણ વસ્તુમાં ફેરફાર કરતી વખતે સાવચેત રહો, અને અન્ય મોડ્યુલો સાથે બે વાર તપાસ કરો.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// દશાંશ શબ્દમાળાના રસપ્રદ ભાગો.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// દશાંશ ઘટક, 18 કરતાં ઓછી દશાંશ અંકોની ખાતરી આપી છે.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ઇનપુટ શબ્દમાળા એ માન્ય ફ્લોટિંગ પોઇન્ટ નંબર છે કે કેમ તે તપાસે છે અને જો એમ હોય તો, અભિન્ન ભાગ, અપૂર્ણાંક ભાગ અને તેમાંના ઘાતાકને શોધો.
/// સંકેતોનું સંચાલન કરતું નથી.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' પહેલાં કોઈ અંક નથી
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // અમને બિંદુ પહેલા અથવા પછી ઓછામાં ઓછા એક અંકની જરૂર છે.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // અપૂર્ણાંક ભાગ પછી પાછળનો જંક
            }
        }
        _ => Invalid, // પ્રથમ અંકના શબ્દમાળા પછી પાછળનો જંક
    }
}

/// પ્રથમ ન-ન-અક્ષરનાં અક્ષર સુધી દશાંશ અંકો કા .ે છે.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ઘાતકર્તા નિષ્કર્ષણ અને ભૂલ ચકાસણી.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ઘાતક પછી પાછળનો જંક
    }
    if number.is_empty() {
        return Invalid; // ખાલી ઘટક
    }
    // આ સમયે, અમારી પાસે ચોક્કસપણે અંકોની માન્ય શબ્દમાળા છે.`i64` માં મૂકવામાં તે ખૂબ લાંબું હોઈ શકે છે, પરંતુ જો તે ખૂબ વિશાળ છે, તો ઇનપુટ ચોક્કસપણે શૂન્ય અથવા અનંત છે.
    // દશાંશ અંકોમાંની દરેક શૂન્ય ફક્ત ઘાતકને +/-1 દ્વારા સમાયોજિત કરે છે, એક્સપ્રેસ=10 ^ 18 પર, મર્યાદિત હોવાને કારણે દૂરથી નજીક જવા માટે ઇનપુટ 17 શૂન્ય (!) X હોવું જોઈએ.
    //
    // આ બરાબર ઉપયોગમાં લેવાતું કેસ નથી જે આપણે પૂરું કરવાની જરૂર છે.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}