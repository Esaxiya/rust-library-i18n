//! બિગ્નમ્સ માટે ઉપયોગિતા કાર્યો કે જે પદ્ધતિઓમાં ફેરવવા માટે ખૂબ અર્થમાં નથી.

// ફિક્સ આ મોડ્યુલનું નામ થોડું કમનસીબ છે, કારણ કે અન્ય મોડ્યુલો પણ `core::num` આયાત કરે છે.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` કરતા ઓછા બધાં બિટ્સ કાપવા તે સંબંધિત ભૂલ ઓછી, બરાબર અથવા 0.5 યુએલપી કરતા વધુની રજૂ કરે છે કે કેમ તે ચકાસો.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 યુએલપી
        return Less;
    }
    // જો બાકીના તમામ બિટ્સ શૂન્ય હોય, તો તે= 0.5 યુએલપી છે, અન્યથા> 0.5 જો ત્યાં વધુ બિટ્સ નથી (અડધા_બિટ==0), તો નીચે પણ યોગ્ય રીતે સમાન આપે છે.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// દશાંશ અંકવાળા એક ASCII શબ્દમાળાને `u64` માં ફેરવે છે.
///
/// ઓવરફ્લો અથવા અમાન્ય અક્ષરો માટે ચકાસણી કરતું નથી, તેથી જો કlerલર સાવચેત ન હોય તો, પરિણામ બોગસ છે અને ઝેડપpanનિકિક ઝેડ (જો કે તે `unsafe` હશે નહીં).
/// વધારામાં, ખાલી શબ્દમાળાઓ શૂન્ય તરીકે ગણવામાં આવે છે.
/// આ કાર્ય અસ્તિત્વમાં છે કારણ કે
///
/// 1. `&[u8]` પર `FromStr` નો ઉપયોગ કરવા માટે `from_utf8_unchecked` જરૂરી છે, જે ખરાબ છે, અને
/// 2. `integral.parse()` અને `fractional.parse()` ના પરિણામો સાથે મળીને આ સમગ્ર કાર્ય કરતા વધુ જટિલ છે.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII અંકોના શબ્દમાળાને બિગ્નમમાં ફેરવે છે.
///
/// `from_str_unchecked` ની જેમ, આ ફંક્શન બિન-અંકોને ઘાસ કા toવા માટે પાર્સર પર આધાર રાખે છે.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// 64 બીટ પૂર્ણાંકમાં બિગ્નમને અનપraર કરે છે.Panics જો સંખ્યા ખૂબ મોટી છે.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// બિટ્સની શ્રેણી કા .ે છે.

/// અનુક્રમણિકા 0 એ ઓછામાં ઓછું નોંધપાત્ર બીટ છે અને શ્રેણી સામાન્યની જેમ અડધી ખુલ્લી છે.
/// Panics જો વળતર પ્રકારમાં ફિટ કરતાં વધુ બિટ્સ કાractવાનું કહેવામાં આવે.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}