//! દશાંશ તારને આઇઇઇઇ 754 બાઈનરી ફ્લોટિંગ પોઇન્ટ નંબર્સમાં રૂપાંતરિત કરવું.
//!
//! # સમસ્યા નિવેદન
//!
//! અમને દશાંશ શબ્દમાળા આપવામાં આવી છે જેમ કે `12.34e56`.
//! આ શબ્દમાળામાં અભિન્ન (`12`), અપૂર્ણાંક (`34`) અને ઘાતાના (`56`) ભાગો છે.ગુમ થવા પર બધા ભાગો વૈકલ્પિક અને અર્થઘટન છે.
//!
//! અમે આઇઇઇઇ 754 ફ્લોટિંગ પોઇન્ટ નંબર શોધીએ છીએ જે દશાંશ શબ્દમાળાના ચોક્કસ મૂલ્યની નજીક છે.
//! તે જાણીતું છે કે ઘણા દશાંશ શબ્દમાળાઓ બેઝ બેમાં સમાપ્ત રજૂઆતો ધરાવતા નથી, તેથી અમે છેલ્લા સ્થાને 0.5 એકમો તરફ વળ્યા છીએ (બીજા શબ્દોમાં કહીએ તો, શક્ય છે).
//! ટાઇ, દશાંશ કિંમતો બરાબર અડધા રસ્તો બે સતત ફ્લોટ વચ્ચે, અડધાથી સમૂહની વ્યૂહરચનાથી ઉકેલાય છે, જેને બેન્કરના ગોળાકાર તરીકે પણ ઓળખવામાં આવે છે.
//!
//! કહેવાની જરૂર નથી, આ અમલીકરણની જટિલતાના સંદર્ભમાં અને સીપીયુ ચક્રની દ્રષ્ટિએ લેવામાં આવેલી બંને બાબતોમાં તદ્દન મુશ્કેલ છે.
//!
//! # Implementation
//!
//! પ્રથમ, આપણે ચિહ્નોને અવગણીએ છીએ.અથવા તેના કરતાં, અમે તેને રૂપાંતર પ્રક્રિયાની શરૂઆતમાં જ દૂર કરીએ છીએ અને તેને ખૂબ જ અંતમાં ફરીથી લાગુ કરીએ છીએ.
//! આ બધા ઝેડિજેડ ઝેડ કેસોમાં યોગ્ય છે કારણ કે આઇઇઇઇ ફ્લોટ્સ શૂન્યની આસપાસ સપ્રમાણતા ધરાવે છે, કોઈની અવગણના કરીને તે પ્રથમ બીટ ફ્લિપ કરે છે.
//!
//! તે પછી અમે ઘાસને સમાયોજિત કરીને દશાંશ બિંદુને દૂર કરીએ છીએ: વિભાવના મુજબ, `12.34e56` `1234e54` માં ફેરવાય છે, જેનું વર્ણન આપણે સકારાત્મક પૂર્ણાંક `f = 1234` અને પૂર્ણાંક `e = 54` સાથે કરીએ છીએ.
//! `(f, e)` પ્રતિનિધિત્વનો ઉપયોગ વિશ્લેષણ મંચના છેલ્લા બધા કોડ દ્વારા કરવામાં આવે છે.
//!
//! ત્યારબાદ અમે મશીન-આકારના પૂર્ણાંકો અને નાના, નિશ્ચિત કદના ફ્લોટિંગ પોઇન્ટ નંબરો (પ્રથમ `f32`/`f64`, પછી 64 બીટ મહત્વ અને `Fp` સાથેનો પ્રકાર) નો ઉપયોગ કરીને ક્રમિક રીતે વધુ સામાન્ય અને ખર્ચાળ વિશેષ કિસ્સાઓની લાંબી સાંકળનો પ્રયાસ કરીએ.
//!
//! જ્યારે આ બધા નિષ્ફળ થાય છે, ત્યારે અમે બુલેટને ડંખ લગાવીએ છીએ અને એક સરળ પણ ખૂબ ધીમું અલ્ગોરિધમનો આશરો કરીએ છીએ જેમાં `f * 10^e` નું સંપૂર્ણ ગણતરી કરવામાં આવે છે અને શ્રેષ્ઠ અંદાજ માટે પુનરાવર્તિત શોધ કરવામાં આવે છે.
//!
//! મુખ્યત્વે, આ મોડ્યુલ અને તેના બાળકો વર્ણવેલ ગાણિતીક નિયમોનો અમલ કરે છે:
//! "How to Read Floating Point Numbers Accurately" વિલિયમ ડી દ્વારા
//! ક્લિન્જર, availableનલાઇન ઉપલબ્ધ: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! આ ઉપરાંત, અસંખ્ય સહાયક કાર્યો છે જેનો ઉપયોગ કાગળમાં થાય છે પરંતુ ઝેડ રસ્ટ0 ઝેડ (અથવા ઓછામાં ઓછા મૂળમાં) માં ઉપલબ્ધ નથી.
//! અમારું સંસ્કરણ ઓવરફ્લો અને અંડરફ્લોને હેન્ડલ કરવાની જરૂરિયાત અને અસામાન્ય નંબરને હેન્ડલ કરવાની ઇચ્છા દ્વારા પણ જટિલ છે.
//! બેલેરોફોન અને એલ્ગોરિધમ આરને ઓવરફ્લો, સબનોર્મલ અને અંડરફ્લો સાથે મુશ્કેલી છે.
//! ઇનપુટ્સ નિર્ણાયક ક્ષેત્રમાં આવે તે પહેલાં અમે રૂ conિચુસ્ત રીતે એલ્ગોરિધમ એમ (પેપરના વિભાગ 8 માં વર્ણવેલ ફેરફારો સાથે) પર સ્વિચ કરીએ છીએ.
//!
//! બીજું પાસું કે જેને ધ્યાન આપવાની જરૂર છે તે છે ``RawFloat`` trait, જેના દ્વારા લગભગ તમામ કાર્યોને પેરામેટ્રાઇઝ કરવામાં આવે છે.એક એવું વિચારી શકે કે તે `f64` નું વિશ્લેષણ કરવા અને પરિણામને `f32` પર કાસ્ટ કરવા માટે પૂરતું છે.
//! દુર્ભાગ્યે આ તે વિશ્વ નથી કે જેમાં આપણે જીવીએ છીએ, અને આનો આધાર બે અથવા અર્ધ-થી-રાઉન્ડિંગનો ઉપયોગ કરવાથી કોઈ લેવાદેવા નથી.
//!
//! ઉદાહરણ તરીકે બે પ્રકારો `d2` અને `d4` દશાંશ પ્રકારનું પ્રતિનિધિત્વ કરતા બે દશાંશ અંકો અને ચાર દશાંશ અંકો સાથે દરેકને ધ્યાનમાં લો અને "0.01499" ને ઇનપુટ તરીકે લો.ચાલો હાફ-અપ રાઉન્ડિંગનો ઉપયોગ કરીએ.
//! સીધા બે દશાંશ અંકો પર જવાથી `0.01` મળે છે, પરંતુ જો આપણે પહેલા ચાર અંકોથી આગળ વધીએ, તો આપણે `0.0150` મેળવીએ છીએ, જે પછી `0.02` સુધી ગોળાકાર છે.
//! આ જ સિદ્ધાંત અન્ય કામગીરીઓને પણ લાગુ પડે છે, જો તમે એક્સ 100 એક્સ યુએલપી ચોકસાઈ ઇચ્છતા હો, તો તમારે એક જ સમયે બધા કાપવામાં આવેલા બિટ્સને ધ્યાનમાં લઈને,*બરાબર એકવાર, અંતમાં*,*બધું* કરવાની જરૂર છે.
//!
//! FIXME: તેમ છતાં કેટલાક કોડ ડુપ્લિકેશન જરૂરી છે, સંભવત: કોડના ભાગો બદલી શકાય છે જેમ કે ઓછા કોડની નકલ કરવામાં આવે છે.
//! એલ્ગોરિધમ્સના મોટા ભાગો ફ્લોટ પ્રકારથી આઉટપુટ માટે સ્વતંત્ર હોય છે, અથવા ફક્ત થોડા સ્થળોની needsક્સેસની જરૂર હોય છે, જેને પરિમાણો તરીકે પસાર કરી શકાય છે.
//!
//! # Other
//!
//! રૂપાંતર *panic* ક્યારેય ન હોવું જોઈએ.
//! કોડમાં દાવાઓ અને સ્પષ્ટ panics છે, પરંતુ તેમને ક્યારેય ટ્રિગર થવું જોઈએ નહીં અને ફક્ત આંતરિક સેનિટી તપાસ તરીકે જ સેવા આપવી જોઈએ.કોઈપણ ઝેડ 0 સ્પેનિક્સ 0 ઝેડને બગ માનવી જોઈએ.
//!
//! ત્યાં એકમ પરીક્ષણો છે પરંતુ તેઓ ચોકસાઈથી અચોક્કસતાની ખાતરી કરવા માટે અપૂરતા છે, તેઓ ફક્ત શક્ય ભૂલોની થોડી ટકાવારીને આવરી લે છે.
//! `src/etc/test-float-parse` ડિરેક્ટરીમાં Python સ્ક્રિપ્ટ તરીકે વધુ વિસ્તૃત પરીક્ષણો સ્થિત છે.
//!
//! પૂર્ણાંક ઓવરફ્લો પરની નોંધ: આ ફાઇલના ઘણા ભાગો દશાંશ ઘટક `e` સાથે અંકગણિત કરે છે.
//! મુખ્યત્વે, આપણે દશાંશ બિંદુ આસપાસ ફેરવીએ છીએ: પહેલા દશાંશ અંક પહેલા, છેલ્લા દશાંશ અંક પછી, અને આ રીતે.જો બેદરકારીથી કરવામાં આવે તો આ ઓવરફ્લો થઈ શકે છે.
//! ફક્ત પર્યાપ્ત નાના અસ્પેક્ષકોને બહાર કા toવા માટે અમે વિશ્લેષણ સબમોડ્યુલ પર આધાર રાખીએ છીએ, જ્યાં "sufficient" એટલે "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! મોટા ઘાતરો સ્વીકારવામાં આવે છે, પરંતુ અમે તેમની સાથે અંકગણિત કરતા નથી, તેઓ તરત જ {positive,negative} {zero,infinity} માં ફેરવાઈ જાય છે.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// આ બંનેની પોતાની પરીક્ષણો છે.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// બેઝ 10 માં સ્ટ્રિંગને ફ્લોટમાં ફેરવે છે.
            /// વૈકલ્પિક દશાંશ ઘટક સ્વીકારે છે.
            ///
            /// આ ફંક્શન જેમ કે શબ્દમાળાઓ સ્વીકારે છે
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', અથવા સમાન રીતે, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', અથવા, સમાનરૂપે, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// અગ્રણી અને પાછળની વ્હાઇટ સ્પેસ ભૂલને રજૂ કરે છે.
            ///
            /// # Grammar
            ///
            /// નીચે આપેલા [EBNF] વ્યાકરણનું પાલન કરતી બધી તારીઓ [`Ok`] પરત પરિણમે છે:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # જાણીતી ભૂલો
            ///
            /// કેટલીક પરિસ્થિતિઓમાં, કેટલીક તાર કે જેને માન્ય ફ્લોટ બનાવવી જોઈએ તેના બદલે ભૂલ આપે છે.
            /// વિગતો માટે [issue #31407] જુઓ.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, એક શબ્દમાળા
            ///
            /// # વળતર મૂલ્ય
            ///
            /// `Err(ParseFloatError)` જો શબ્દમાળાએ માન્ય નંબરનું પ્રતિનિધિત્વ કર્યું નથી.
            /// નહિંતર, `Ok(n)` જ્યાં `n` એ ફ્લોટિંગ પોઇન્ટ નંબર છે જે `src` દ્વારા રજૂ થાય છે.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// એક ભૂલ જે ફ્લોટનું વિશ્લેષણ કરતી વખતે પરત મળી શકે.
///
/// આ ભૂલનો ઉપયોગ [`f32`] અને [`f64`] માટે [`FromStr`] અમલીકરણ માટે ભૂલ પ્રકાર તરીકે થાય છે.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// દશાંશ શબ્દમાળાને ચિહ્ન અને બાકીના ભાગમાં વિભાજીત કરે છે, બાકીની તપાસણી અથવા માન્યતા વિના.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // જો શબ્દમાળા અમાન્ય છે, તો અમે ક્યારેય સાઇનનો ઉપયોગ કરતા નથી, તેથી અમારે અહીં માન્ય કરવાની જરૂર નથી.
        _ => (Sign::Positive, s),
    }
}

/// દશાંશ શબ્દમાળાને ફ્લોટિંગ પોઇન્ટ સંખ્યામાં ફેરવે છે.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// દશાંશ-થી-ફ્લોટ રૂપાંતર માટેનો મુખ્ય વર્કહ workર્સ: બધી પૂર્વસૂચનાને ઓર્કેસ્ટ્રેટ કરો અને કયો અલ્ગોરિધમનો વાસ્તવિક રૂપાંતર કરવું જોઈએ તે આકૃતિ કરો.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift દશાંશ બિંદુ બહાર
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // બિગ 32x40 એ 1280 બિટ્સ સુધી મર્યાદિત છે, જે લગભગ 385 દશાંશ અંકોમાં અનુવાદ કરે છે.
    // જો આપણે આને વટાવીએ, તો આપણે ક્રેશ કરીશું, તેથી ખૂબ નજીક આવતાં પહેલાં આપણે ભૂલ કરીશું (10 ^ 10 ની અંદર).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // હવે ઘાતાંક ચોક્કસપણે 16 બીટમાં બંધબેસે છે, જેનો ઉપયોગ મુખ્ય ગાણિતીક નિયમો દરમ્યાન થાય છે.
    let e = e as i16;
    // FIXME આ સીમાઓ બદલે રૂservિચુસ્ત છે.
    // બેલેરોફોનના નિષ્ફળતા મોડ્સનું વધુ કાળજીપૂર્વક વિશ્લેષણ, તેને વધુ કેસોમાં ઝડપી વેગ માટે ઉપયોગમાં લઈ શકે છે.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// લખેલા મુજબ, આ ખરાબ રીતે optimપ્ટિમાઇઝ થાય છે (જુઓ #27130, જો કે તે કોડના જૂના સંસ્કરણનો સંદર્ભ આપે છે).
// `inline(always)` તે માટે કાર્યરત છે.
// એકલામાં ફક્ત બે ક callલ સાઇટ્સ છે અને તે કોડના કદને વધુ ખરાબ કરતી નથી.

/// શક્ય હોય ત્યાં પટ્ટી ઝીરો, જ્યારે આના ઘટકને બદલવાની જરૂર હોય ત્યારે પણ
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // આ ઝીરોને ટ્રિમ કરવાથી કંઈપણ બદલાતું નથી પરંતુ ઝડપી પાથ (<15 અંક) ને સક્ષમ કરી શકે છે.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 0.0 ની સંખ્યાને સરળ બનાવો ... x અને x ... 0.0, તે પ્રમાણે ખાતાને વ્યવસ્થિત કરો.
    // આ હંમેશાં જીત ન હોઈ શકે (સંભવત some કેટલાક નંબરોને ઝડપી પાથથી આગળ ધપાવે છે), પરંતુ તે અન્ય ભાગોને નોંધપાત્ર રીતે સરળ બનાવે છે (નોંધનીય રીતે, મૂલ્યની તીવ્રતાને નજીકમાં).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// આપેલ દશાંશ પર કામ કરતી વખતે અલ્ગોરિધમ આર અને એલ્ગોરિધમ એમ ગણના કરશે તે સૌથી મોટા મૂલ્યના કદ (log10) પર ઝડપી-ગંદા ઉપલા બાઉન્ડને આપે છે.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // અમને અહીં ઓવરફ્લો વિશે ખૂબ ચિંતા કરવાની જરૂર નથી trivial_cases() X અને પાર્સરનો આભાર, જે આપણા માટેના આત્યંતિક ઇનપુટ્સને ફિલ્ટર કરે છે.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // કિસ્સામાં ઇ>=0, બંને એલ્ગોરિધમ્સનું ગણતરી `f * 10^e` વિશે.
        // એલ્ગોરિધમ આર આની સાથે કેટલીક જટિલ ગણતરીઓ કરવા આગળ વધે છે પરંતુ આપણે તેને ઉપલા બાઉન્ડ માટે અવગણી શકીએ છીએ કારણ કે તે પહેલાથી અપૂર્ણાંકને પણ ઘટાડે છે, તેથી આપણે ત્યાં પુષ્કળ બફર છે.
        //
        f_len + (e as u64)
    } else {
        // જો ઇ <0, અલ્ગોરિધમ આર લગભગ સમાન વસ્તુ કરે છે, પરંતુ એલ્ગોરિધમ એમ અલગ પડે છે:
        // તે સકારાત્મક નંબર કે શોધવાનો પ્રયાસ કરે છે જેમ કે એક્સ 100 એક્સ એ અંતર્ગતનું મહત્વ છે.
        // આના પરિણામે લગભગ `2^53 *f* 10^e` <`10^17 *f* 10^e` થશે.
        // એક ઇનપુટ જે આને ટ્રિગર કરે છે તે છે 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// દશાંશ અંકો પણ જોયા વિના સ્પષ્ટ ઓવરફ્લો અને અંડરફ્લો શોધે છે.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // ત્યાં શૂન્ય હતા પરંતુ તેઓ simplify() દ્વારા છીનવી લેવામાં આવ્યા હતા
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // આ ceil(log10(the real value)) નું ક્રૂડ અંદાજ છે.
    // અમારે અહીં ઓવરફ્લો વિશે ખૂબ ચિંતા કરવાની જરૂર નથી કારણ કે ઇનપુટ લંબાઈ ખૂબ ઓછી છે (ઓછામાં ઓછું 2 ^ 64 ની તુલનામાં) અને પાર્સર પહેલેથી જ એક્સ્પેંટરને સંભાળે છે જેનું સંપૂર્ણ મૂલ્ય 10 ^ 18 કરતા વધારે છે (જે હજી 10 ^ 19 ટૂંકા છે) 2 ^ 64) ની.
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}