//! સકારાત્મક આઇઇઇઇ 754 ફ્લોટ્સ પર બિટ ફીડલિંગ.નકારાત્મક સંખ્યાઓ નથી અને નિયંત્રિત કરવાની જરૂર નથી.
//! સામાન્ય ફ્લોટિંગ પોઇન્ટ નંબર્સમાં (ફ્રાક, એક્સપ) જેમ કે નૈતિક રજૂઆત હોય છે જેમ કે મૂલ્ય 2 <sup>એક્સપ</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) હોય છે જ્યાં એન બીટ્સની સંખ્યા હોય છે.
//!
//! સબનોર્મલ થોડા અલગ અને વિચિત્ર હોય છે, પરંતુ તે જ સિદ્ધાંત લાગુ પડે છે.
//!
//! અહીં, તેમ છતાં, અમે તેમને (સગ, કે) તરીકે એફ પોઝિટિવ સાથે રજૂ કરીએ છીએ, જેમ કે મૂલ્ય એફ *
//! 2 <sup>ઇ</sup> .એક્સ 100 એક્સને સ્પષ્ટ બનાવવા ઉપરાંત, આ કહેવાતા મેન્ટિસા પાળી દ્વારા ખાતામાં ફેરફાર કરે છે.
//!
//! બીજી રીતે કહીએ તો, સામાન્ય રીતે ફ્લોટ્સ (1) તરીકે લખાય છે પરંતુ અહીં તે (2) તરીકે લખાયેલા છે:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! અમે (1) ને **અપૂર્ણાંક રજૂઆત** અને (2) ને **અભિન્ન પ્રતિનિધિત્વ** કહીએ છીએ.
//!
//! આ મોડ્યુલમાં ઘણા કાર્યો ફક્ત સામાન્ય નંબરોને સંચાલિત કરે છે.ડેક 2 ફલ્ટ રૂટીન રૂinesિચુસ્ત રીતે ખૂબ નાના અને ખૂબ મોટી સંખ્યામાં સાર્વત્રિક-સાચા ધીમું માર્ગ (એલ્ગોરિધમ એમ) લે છે.
//! તે અલ્ગોરિધમને ફક્ત next_float() ની જરૂર છે જે ઉપનારી અને શૂન્યને હેન્ડલ કરે છે.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` અને `f64` માટે મૂળ રૂપે બધા રૂપાંતર કોડની નકલને ટાળવા માટે સહાયક ઝેડટ્રેટ 0 ઝેડ.
///
/// આ શા માટે જરૂરી છે તેના માટે પિતૃ મોડ્યુલની ડ commentક ટિપ્પણી જુઓ.
///
/// **ક્યારેય નહીં** અન્ય પ્રકારો માટે અમલમાં મૂકવા જોઈએ અથવા ડેક 2 ફ્લ્ટ મોડ્યુલની બહાર ઉપયોગમાં લેવો જોઈએ.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` અને `from_bits` દ્વારા વપરાયેલ પ્રકાર.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// પૂર્ણાંકમાં કાચો ટ્રાન્સમ્યુટેશન કરે છે.
    fn to_bits(self) -> Self::Bits;

    /// પૂર્ણાંકોમાંથી કાચો ટ્રાન્સમ્યુટેશન કરે છે.
    fn from_bits(v: Self::Bits) -> Self;

    /// કેટેગરી આપે છે કે જેમાં આ સંખ્યા આવે છે.
    fn classify(self) -> FpCategory;

    /// મ mantન્ટિસા, ઘાતક અને પૂર્ણાંકો તરીકે સાઇન આપે છે.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ફ્લોટને ડીકોડ કરે છે.
    fn unpack(self) -> Unpacked;

    /// નાના પૂર્ણાંકની જાતિઓ કે જે બરાબર રજૂ કરી શકાય છે.
    /// Panic જો પૂર્ણાંક રજૂ કરી શકાતો નથી, તો આ મોડ્યુલમાંનો અન્ય કોડ ક્યારેય નહીં થાય તેની ખાતરી કરે છે.
    fn from_int(x: u64) -> Self;

    /// પ્રી-કોમ્પ્યુટેડ કોષ્ટકમાંથી 10 <sup>ઇ</sup> મૂલ્ય મેળવે છે.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` માટે Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// નામ શું કહે છે.
    /// જાદુગરીની આંતરિક સુવિધાઓ કરતાં અને એલએલવીએમ તેને સતત ફોલ્ડ કરે છે તેની આશા કરતાં સખત કોડ કરવું સહેલું છે.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ઓવરફ્લો અથવા શૂન્ય અથવા પેદા કરી શકતા નથી તેવા ઇનપુટ્સના દશાંશ અંકો પર બંધાયેલ એક રૂ conિચુસ્ત
    /// સબનોર્મલ્સ.સંભવત the મહત્તમ સામાન્ય મૂલ્યનો દશાંશ ઘટક, તેથી નામ.
    const MAX_NORMAL_DIGITS: usize;

    /// જ્યારે ખૂબ નોંધપાત્ર દશાંશ અંકનું સ્થાન મૂલ્ય આ કરતા વધારે હોય છે, ત્યારે સંખ્યા ચોક્કસપણે અનંતમાં ગોળાકાર હોય છે.
    ///
    const INF_CUTOFF: i64;

    /// જ્યારે સૌથી વધુ દશાંશ અંકનું સ્થાન મૂલ્ય આના કરતા ઓછું હોય, ત્યારે સંખ્યા ચોક્કસપણે શૂન્યથી ગોળ થાય છે.
    ///
    const ZERO_CUTOFF: i64;

    /// ઘાતાંકમાં બિટ્સની સંખ્યા.
    const EXP_BITS: u8;

    /// મહત્વના બિટ્સની સંખ્યા,*છુપાયેલા બીટ સહિત*.
    const SIG_BITS: u8;

    /// છુપાયેલા બીટને * બાકાત રાખીને, મહત્વના બિટ્સની સંખ્યા.
    const EXPLICIT_SIG_BITS: u8;

    /// અપૂર્ણાંક રજૂઆતમાં મહત્તમ કાનૂની ઘાતાંક.
    const MAX_EXP: i16;

    /// અપૂર્ણાંકને બાદ કરતાં અપૂર્ણાંક રજૂઆતમાં લઘુતમ કાનૂની ઘાતક.
    const MIN_EXP: i16;

    /// `MAX_EXP` અભિન્ન રજૂઆત માટે, એટલે કે, પાળી લાગુ પડે છે.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` એન્કોડ કરેલ (એટલે કે setફસેટ પૂર્વગ્રહ સાથે)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` અભિન્ન રજૂઆત માટે, એટલે કે, પાળી લાગુ પડે છે.
    const MIN_EXP_INT: i16;

    /// અભિન્ન પ્રતિનિધિત્વમાં મહત્તમ સામાન્યકૃત મહત્વ.
    const MAX_SIG: u64;

    /// અભિન્ન પ્રતિનિધિત્વમાં ન્યૂનતમ સામાન્યકૃત મહત્વ.
    const MIN_SIG: u64;
}

// મોટે ભાગે #34344 માટે વર્કઆઉન્ડ.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// મ mantન્ટિસા, ઘાતક અને પૂર્ણાંકો તરીકે સાઇન આપે છે.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ઘાતક પૂર્વગ્રહ + મેન્ટિસા પાળી
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe અનિશ્ચિત છે કે શું `as` બધા પ્લેટફોર્મ પર યોગ્ય રીતે રાઉન્ડ કરે છે.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// મ mantન્ટિસા, ઘાતક અને પૂર્ણાંકો તરીકે સાઇન આપે છે.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ઘાતક પૂર્વગ્રહ + મેન્ટિસા પાળી
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe અનિશ્ચિત છે કે શું `as` બધા પ્લેટફોર્મ પર યોગ્ય રીતે રાઉન્ડ કરે છે.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// એક `Fp` ને નજીકના મશીન ફ્લોટ પ્રકારમાં રૂપાંતરિત કરે છે.
/// અસામાન્ય પરિણામો નિયંત્રિત કરતું નથી.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 બીટ છે, તેથી xe ની મ mantન્ટિસા પાળી છે 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// અડધા-થી-સાથેના T::SIG_BITS બિટ્સ માટે 64-બીટ ઇતિહાસનો ગોળાકાર.
/// ઘાતક ઓવરફ્લોને હેન્ડલ કરતું નથી.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // મેન્ટિસા પાળી સમાયોજિત કરો
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// સામાન્ય કરેલ સંખ્યા માટે `RawFloat::unpack()` નું વિપરિત.
/// ઝેડ 0 પેનિક્સ 0 ઝેડ જો મહત્વના નંબર માટે અગત્યનો અથવા ઘાતાંક માન્ય નથી.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // છુપાયેલ બીટ દૂર કરો
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ઘાતક પૂર્વગ્રહ અને મ mantન્ટિસા પાળી માટે ઘાતકને વ્યવસ્થિત કરો
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") પર સાઇન બીટ છોડો, અમારી સંખ્યાઓ તમામ સકારાત્મક છે
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// એક સબનોર્મલ બનાવો.0 ના મેન્ટિસાની મંજૂરી છે અને શૂન્ય બનાવે છે.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // એન્કોડેડ ઘાતા 0 છે, સાઇન બીટ 0 છે, તેથી આપણે ફક્ત બીટ્સનો ફરીથી અર્થઘટન કરવો પડશે.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// એક Fp સાથે આશરે એક bignum.અડધા-થી-સાથેની સાથે 0.5 ULP ની અંદરના રાઉન્ડ્સ.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // અમે અનુક્રમણિકા `start` પહેલાંના બધા બિટ્સ કાપી નાખ્યા, એટલે કે, અમે `start` ની માત્રા દ્વારા અસરકારક રીતે રાઇટ-શિફ્ટ કરીએ છીએ, તેથી આ પણ આપણી જરૂરિયાતની જરૂરિયાત છે.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // કાપવામાં આવેલા બિટ્સના આધારે રાઉન્ડ (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// દલીલ કરતા સખત રીતે નાનો સૌથી મોટો ફ્લોટિંગ પોઇન્ટ નંબર શોધે છે.
/// સબનોર્મલ્સ, શૂન્ય અથવા ઘાતક પ્રવાહને હેન્ડલ કરતું નથી.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// દલીલ કરતા સખત મોટો નાનો ફ્લોટિંગ પોઇન્ટ નંબર શોધો.
// આ ક્રિયા સંતૃપ્ત છે, એટલે કે, next_float(inf) ==inf.
// આ મોડ્યુલમાં મોટાભાગના કોડથી વિપરીત, આ ફંક્શન શૂન્ય, સબનોર્મલ અને અનંતોને નિયંત્રિત કરે છે.
// જો કે, અહીં અન્ય તમામ કોડની જેમ, તે NaN અને નકારાત્મક સંખ્યાઓ સાથે વ્યવહાર કરતું નથી.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // આ સાચું હોવાનું ખૂબ સારું લાગે છે, પરંતુ તે કાર્ય કરે છે.
        // 0.0 એ બધા શૂન્ય શબ્દ તરીકે એન્કોડ થયેલ છે.સબનોર્મલ્સ 0x000 મી ... એમ છે જ્યાં મેન્ટિસા છે.
        // ખાસ કરીને, સૌથી નાનો અસામાન્ય 0x0 ... 01 છે અને સૌથી મોટો 0x000F ... F છે.
        // સૌથી નાની સામાન્ય સંખ્યા 0x0010 ... 0 છે, તેથી આ કોર્નર કેસ પણ કામ કરે છે.
        // જો વૃદ્ધિ મેન્ટિસાને ઓવરફ્લો કરે છે, તો કેરી બટ આપણને જોઈતા ઘાતકને વધારે છે, અને મ mantન્ટિસા બીટ્સ શૂન્ય થઈ જાય છે.
        // છુપાયેલા બીટ સંમેલનને લીધે, આ પણ આપણે જોઈએ તે બરાબર છે!
        // છેલ્લે, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}