//! `f32` સિંગલ-શુદ્ધતા ફ્લોટિંગ પોઇન્ટ પ્રકારને લગતા ચોક્કસ
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` સબ-મોડ્યુલમાં ગણિતરૂપે નોંધપાત્ર સંખ્યા પ્રદાન કરવામાં આવે છે.
//!
//! આ મોડ્યુલમાં સીધા વ્યાખ્યાયિત સ્થાવર માટે (`consts` સબ-મોડ્યુલમાં નિર્ધારિત લોકોથી અલગ), નવા કોડને બદલે સીધા `f32` પ્રકાર પર નિર્ધારિત સંકળાયેલ કન્સ્ટન્ટ્સનો ઉપયોગ કરવો જોઈએ.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` ની આંતરિક રજૂઆતનો મૂળક અથવા આધાર.
/// તેના બદલે [`f32::RADIX`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // હેતુપૂર્ણ રીતે
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// આધાર 2 માં નોંધપાત્ર અંકોની સંખ્યા.
/// તેના બદલે [`f32::MANTISSA_DIGITS`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // હેતુપૂર્ણ રીતે
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// આધાર 10 માં નોંધપાત્ર અંકોની આશરે સંખ્યા.
/// તેના બદલે [`f32::DIGITS`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // હેતુપૂર્ણ રીતે
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` નું મૂલ્ય.
/// તેના બદલે [`f32::EPSILON`] નો ઉપયોગ કરો.
///
/// આ `1.0` અને પછીની મોટી રજૂ કરવાની સંખ્યા વચ્ચેનો તફાવત છે.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // હેતુપૂર્ણ રીતે
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// નાનામાં મર્યાદિત `f32` મૂલ્ય.
/// તેના બદલે [`f32::MIN`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // હેતુપૂર્ણ રીતે
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// નાનામાં સકારાત્મક સામાન્ય `f32` મૂલ્ય.
/// તેના બદલે [`f32::MIN_POSITIVE`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // હેતુપૂર્ણ રીતે
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// સૌથી વધુ મર્યાદિત `f32` મૂલ્ય.
/// તેના બદલે [`f32::MAX`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // હેતુપૂર્ણ રીતે
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 ઘાતાંકની ન્યૂનતમ શક્ય સામાન્ય શક્તિ કરતા એક મોટી.
/// તેના બદલે [`f32::MIN_EXP`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // હેતુપૂર્ણ રીતે
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// મહત્તમ શક્ય 2 શક્તિવાળા શક્તિ.
/// તેના બદલે [`f32::MAX_EXP`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // હેતુપૂર્ણ રીતે
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 ઘાતાંકની ન્યૂનતમ શક્ય સામાન્ય શક્તિ.
/// તેના બદલે [`f32::MIN_10_EXP`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // હેતુપૂર્ણ રીતે
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 ઘાતાંકની મહત્તમ શક્ય શક્તિ.
/// તેના બદલે [`f32::MAX_10_EXP`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // હેતુપૂર્ણ રીતે
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// નંબર (NaN) નથી.
/// તેના બદલે [`f32::NAN`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // હેતુપૂર્ણ રીતે
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// અનંત (∞).
/// તેના બદલે [`f32::INFINITY`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // હેતુપૂર્ણ રીતે
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// નકારાત્મક અનંત (−∞).
/// તેના બદલે [`f32::NEG_INFINITY`] નો ઉપયોગ કરો.
///
/// # Examples
///
/// ```rust
/// // અવમૂલ્યન માર્ગ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // હેતુપૂર્ણ રીતે
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// મૂળભૂત ગાણિતિક સ્થિરતા.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath માંથી ગાણિતિક સ્થિર સાથે બદલો.

    /// આર્કીમિડીઝનું સતત (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// સંપૂર્ણ વર્તુળ સતત (τ)
    ///
    /// 2π ની બરાબર.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// યુલરનો નંબર (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` ની આંતરિક રજૂઆતનો મૂળક અથવા આધાર.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// આધાર 2 માં નોંધપાત્ર અંકોની સંખ્યા.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// આધાર 10 માં નોંધપાત્ર અંકોની આશરે સંખ્યા.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` નું મૂલ્ય.
    ///
    /// આ `1.0` અને પછીની મોટી રજૂ કરવાની સંખ્યા વચ્ચેનો તફાવત છે.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// નાનામાં મર્યાદિત `f32` મૂલ્ય.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// નાનામાં સકારાત્મક સામાન્ય `f32` મૂલ્ય.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// સૌથી વધુ મર્યાદિત `f32` મૂલ્ય.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 ઘાતાંકની ન્યૂનતમ શક્ય સામાન્ય શક્તિ કરતા એક મોટી.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// મહત્તમ શક્ય 2 શક્તિવાળા શક્તિ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 ઘાતાંકની ન્યૂનતમ શક્ય સામાન્ય શક્તિ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 ઘાતાંકની મહત્તમ શક્ય શક્તિ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// નંબર (NaN) નથી.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// અનંત (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// નકારાત્મક અનંત (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// જો આ મૂલ્ય `NaN` હોય તો `true` આપે છે.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` પોર્ટેબીલીટી વિશેની ચિંતાઓને લીબકોરમાં સાર્વજનિક રૂપે અનુપલબ્ધ છે, તેથી આ અમલીકરણ આંતરિક ઉપયોગ માટે ખાનગી ઉપયોગ માટે છે.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// જો આ મૂલ્ય હકારાત્મક અનંત અથવા નકારાત્મક અનંત છે અને `false` અન્યથા, `true` આપે છે.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` પરત કરે છે જો આ સંખ્યા ન તો અનંત છે અથવા `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN ને અલગથી હેન્ડલ કરવાની કોઈ જરૂર નથી: જો સ્વ NaN છે, તો સરખામણી સાચી નથી, બરાબર ઇચ્છિત છે.
        //
        self.abs_private() < Self::INFINITY
    }

    /// જો સંખ્યા [subnormal] હોય તો `true` આપે છે.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` અને `min` વચ્ચેના મૂલ્યો સબનોર્મલ છે.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// જો સંખ્યા ન તો શૂન્ય, અનંત, [subnormal] અથવા `NaN` ન હોય તો `true` આપે છે.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` અને `min` વચ્ચેના મૂલ્યો સબનોર્મલ છે.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// સંખ્યાની ફ્લોટિંગ પોઇન્ટ કેટેગરી પરત કરે છે.
    /// જો ફક્ત એક જ સંપત્તિની ચકાસણી કરવામાં આવી રહી છે, તો તેના બદલે વિશિષ્ટ પિકિકેટનો ઉપયોગ કરવો સામાન્ય રીતે ઝડપી છે.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// જો `self` પર સકારાત્મક સંકેત હોય તો `true` આપે છે, જેમાં `+0.0`, positive NaN`s સકારાત્મક સાઇન બીટ અને સકારાત્મક અનંત સાથે છે.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// જો `self` પર નકારાત્મક સંકેત હોય તો `true` આપે છે, જેમાં `-0.0`, negative NaN`s નેગેટિવ સાઇન બીટ અને નકારાત્મક અનંત સાથે છે.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // આઇઇઇઇ 754 કહે છે: એક્સ 100 એક્સ સાચું છે જો અને જો એક્સમાં નકારાત્મક ચિન્હ હોય તો જ.
        // isSignMinus zeros અને NaN ને પણ લાગુ પડે છે.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// સંખ્યાના પારસ્પરિક (inverse) લે છે, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// રેડિયનને ડિગ્રીમાં ફેરવે છે.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // વધુ સારી ચોકસાઇ માટે સતતનો ઉપયોગ કરો.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ડિગ્રીને રેડિયનમાં ફેરવે છે.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// બે સંખ્યામાં મહત્તમ આપે છે.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// જો દલીલોમાંથી એક એનએન છે, તો બીજી દલીલ પરત આવે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// બે સંખ્યામાં ન્યૂનતમ આપે છે.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// જો દલીલોમાંથી એક એનએન છે, તો બીજી દલીલ પરત આવે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// શૂન્ય તરફના ગોળાકાર અને મૂલ્ય મર્યાદિત છે અને તે પ્રકારમાં બંધબેસે છે એમ ધારીને, કોઈપણ આદિમ પૂર્ણાંક પ્રકારમાં ફેરવે છે.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// મૂલ્ય આવશ્યક છે:
    ///
    /// * `NaN` નહીં
    /// * અનંત નહીં
    /// * તેના અપૂર્ણાંક ભાગને કાપ્યા પછી, વળતર પ્રકાર `Int` માં રજૂ થવા યોગ્ય બનો
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // સલામતી: કlerલરને `FloatToInt::to_int_unchecked` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` માં કાચો ટ્રાન્સમ્યુટેશન.
    ///
    /// આ હાલમાં બધા પ્લેટફોર્મ્સ પર `transmute::<f32, u32>(self)` જેવું જ છે.
    ///
    /// આ કામગીરીની સુવાહ્યતાની કેટલીક ચર્ચા માટે `from_bits` જુઓ (લગભગ કોઈ મુદ્દાઓ નથી).
    ///
    /// નોંધ લો કે આ કાર્ય `as` કાસ્ટિંગથી અલગ છે, જે *સંખ્યાત્મક* મૂલ્યને સાચવવાનો પ્રયાસ કરે છે, અને બિટવાઇઝ મૂલ્યને નહીં.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() કાસ્ટિંગ નથી!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // સલામતી: `u32` એ સાદો જૂનો ડેટાટાઇપ છે તેથી અમે હંમેશાં તેમાં ટ્રાન્સમિટ કરી શકીએ
        unsafe { mem::transmute(self) }
    }

    /// `u32` માંથી કાચો ટ્રાન્સમ્યુટેશન.
    ///
    /// આ હાલમાં બધા પ્લેટફોર્મ્સ પર `transmute::<u32, f32>(v)` જેવું જ છે.
    /// તે બે કારણોસર આ ઉત્સાહી પોર્ટેબલ છે તે તારણ આપે છે:
    ///
    /// * બધા સપોર્ટેડ પ્લેટફોર્મ્સ પર ફ્લોટ્સ અને ઇંટ્સ સમાન અંત હોય છે.
    /// * આઇઇઇ--754 ખૂબ ચોક્કસપણે ફ્લોટ્સનું બીટ લેઆઉટ સ્પષ્ટ કરે છે.
    ///
    /// જો કે ત્યાં એક ચેતવણી છે: આઇઇઇઇ-7544 ના २०० version નાં સંસ્કરણ પહેલાં, નાએન સિગ્નલિંગ બીટનું અર્થઘટન કેવી રીતે કરવું તે ખરેખર ઉલ્લેખિત નહોતું.
    /// મોટાભાગના પ્લેટફોર્મ્સ (ખાસ કરીને x86 અને એઆરએમ) એ અર્થઘટનને પસંદ કર્યું જે આખરે 2008 માં પ્રમાણિત કરવામાં આવ્યું હતું, પરંતુ કેટલાકએ (ખાસ કરીને એમઆઈપીએસ) ન કર્યું.
    /// પરિણામે, MIPS પરના બધા સંકેત નાઓન x86 પર શાંત નાએન છે, અને .લટું.
    ///
    /// સિગ્નલિંગ-નેસ ક્રોસ-પ્લેટફોર્મ સાચવવાનો પ્રયાસ કરવાને બદલે, આ અમલીકરણ ચોક્કસ બિટ્સને સાચવવાનું સમર્થન કરે છે.
    /// આનો અર્થ એ છે કે એનએનએસમાં એન્કોડ કરેલા કોઈપણ પેલોડ્સને સુરક્ષિત રાખવામાં આવશે, ભલે આ પદ્ધતિના પરિણામને નેટવર્ક પર એક x86 મશીનથી MIPS એક પર મોકલવામાં આવે.
    ///
    ///
    /// જો આ પદ્ધતિના પરિણામો ફક્ત તે જ આર્કિટેક્ચર દ્વારા હેરાફેરી કરવામાં આવે છે જેણે તેમને ઉત્પન્ન કર્યા છે, તો કોઈ પોર્ટેબીલીટીની ચિંતા નથી.
    ///
    /// જો ઇનપુટ NaN નથી, તો પછી કોઈ પોર્ટેબીલીટીની ચિંતા નથી.
    ///
    /// જો તમે સિગ્નલિંગની કાળજી લેતા નથી (ખૂબ સંભવિત), તો પછી કોઈ પોર્ટેબીલીટીની ચિંતા નથી.
    ///
    /// નોંધ લો કે આ કાર્ય `as` કાસ્ટિંગથી અલગ છે, જે *સંખ્યાત્મક* મૂલ્યને સાચવવાનો પ્રયાસ કરે છે, અને બિટવાઇઝ મૂલ્યને નહીં.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // સલામતી: `u32` એ સાદો જૂનો ડેટાટાઇપ છે તેથી અમે હંમેશાં તેમાંથી ટ્રાન્સમિટ કરી શકીએ
        // તે બહાર આવ્યું છે કે સલામતીના મુદ્દાઓ sNaN સાથે ભરાઈ ગયા હતા!હુરે!
        unsafe { mem::transmute(v) }
    }

    /// આ ફ્લોટિંગ પોઇન્ટ નંબરની મેમરી રજૂઆતને મોટા-એન્ડિયન (network) બાઇટ ક્રમમાં બાઇટ એરે તરીકે પાછા ફરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// લિટલ-એન્ડિયન બાઇટ ક્રમમાં આ ફ્લોટિંગ પોઇન્ટ નંબરની બાઇટ એરે તરીકે રજૂ કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// મૂળ બાઇટ ક્રમમાં બાઇટ એરે તરીકે આ ફ્લોટિંગ પોઇન્ટ નંબરની મેમરી રજૂઆતને પરત કરો.
    ///
    /// જેમ કે લક્ષ્ય પ્લેટફોર્મની મૂળ અંતિમતાનો ઉપયોગ થાય છે, તેમ પોર્ટેબલ કોડે [`to_be_bytes`] અથવા [`to_le_bytes`] નો ઉપયોગ કરવો જોઈએ, તેના બદલે, યોગ્ય.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// મૂળ બાઇટ ક્રમમાં બાઇટ એરે તરીકે આ ફ્લોટિંગ પોઇન્ટ નંબરની મેમરી રજૂઆતને પરત કરો.
    ///
    ///
    /// [`to_ne_bytes`] જ્યારે પણ શક્ય હોય ત્યારે આને પસંદ કરવું જોઈએ.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // સલામતી: `f32` એ સાદો જૂનો ડેટાટાઇપ છે તેથી અમે હંમેશાં તેમાં ટ્રાન્સમિટ કરી શકીએ
        unsafe { &*(self as *const Self as *const _) }
    }

    /// મોટા એન્ડિયનમાં બાઇટ એરે તરીકે તેની રજૂઆતથી ફ્લોટિંગ પોઇન્ટ મૂલ્ય બનાવો.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// નાનું અંતિયામાં બાઇટ એરે તરીકે તેની રજૂઆતથી ફ્લોટિંગ પોઇન્ટ મૂલ્ય બનાવો.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// મૂળ ઇન્ડિયનમાં બાઇટ એરે તરીકે તેની રજૂઆતથી ફ્લોટિંગ પોઇન્ટ મૂલ્ય બનાવો.
    ///
    /// જેમ કે લક્ષ્ય પ્લેટફોર્મની મૂળ અંતિમતાનો ઉપયોગ થાય છે, પોર્ટેબલ કોડ સંભવત [`from_be_bytes`] અથવા [`from_le_bytes`] નો ઉપયોગ કરવા માંગે છે, તેના બદલે યોગ્ય.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// સ્વ અને અન્ય મૂલ્યો વચ્ચેનો orderર્ડર આપે છે.
    /// ફ્લોટિંગ પોઇન્ટ નંબરો વચ્ચેની પ્રમાણભૂત આંશિક સરખામણીથી વિપરીત, આ સરખામણી હંમેશાં આઇઇઇઇ 754 (2008 રિવિઝન) ફ્લોટિંગ પોઇન્ટ સ્ટાન્ડર્ડમાં વ્યાખ્યાયિત મુજબ કુલ ઓર્ડર પિકિકેટ અનુસાર ક્રમ ઉત્પન્ન કરે છે.
    /// મૂલ્યો નીચેના ક્રમમાં ક્રમમાં આવે છે:
    /// - નેગેટિવ શાંત એનએન
    /// - નેગેટિવ સિગ્નલિંગ એનએન
    /// - નકારાત્મક અનંત
    /// - નકારાત્મક સંખ્યાઓ
    /// - નકારાત્મક અસામાન્ય નંબર
    /// - નકારાત્મક શૂન્ય
    /// - સકારાત્મક શૂન્ય
    /// - સકારાત્મક અસામાન્ય નંબર
    /// - સકારાત્મક સંખ્યાઓ
    /// - સકારાત્મક અનંત
    /// - સકારાત્મક સંકેત એનએન
    /// - સકારાત્મક શાંત એન.એન.એન.
    ///
    /// નોંધ લો કે આ ફંક્શન હંમેશાં `f32` ના [`PartialOrd`] અને [`PartialEq`] અમલીકરણો સાથે સંમત નથી.ખાસ કરીને, તેઓ નકારાત્મક અને સકારાત્મક શૂન્યને સમાન ગણે છે, જ્યારે `total_cmp` નથી.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // નકારાત્મક કિસ્સામાં, બેના પૂરક પૂર્ણાંકો જેવા સમાન લેઆઉટને પ્રાપ્ત કરવા માટે ચિન્હ સિવાયના તમામ બિટ્સ ફ્લિપ કરો
        //
        // આ કામ કેમ કરે છે?આઇઇઇઇ 754 ફ્લોટ્સમાં ત્રણ ફીલ્ડ્સ શામેલ છે:
        // સાઇન બીટ, ઘાતાંક અને મેન્ટિસા.ઘાતક અને મેન્ટિસા ક્ષેત્રોના સમૂહમાં સંપત્તિ છે કે તેનો બિટવાઇઝ ક્રમ સંખ્યાત્મક પરિમાણની બરાબર છે જ્યાં પરિમાણ નિર્ધારિત છે.
        // તીવ્રતા સામાન્ય રીતે એનએન મૂલ્યો પર નિર્ધારિત નથી, પરંતુ આઇઇઇઇ 754 કુલ ઓર્ડર બીટવાઇઝ ક્રમનું પાલન કરવા માટે એનએન મૂલ્યોને પણ વ્યાખ્યાયિત કરે છે.આ ડ commentક્ટરની ટિપ્પણીમાં સમજાવાયેલ orderર્ડર તરફ દોરી જાય છે.
        // જો કે, તીવ્રતાનું પ્રતિનિધિત્વ નકારાત્મક અને સકારાત્મક સંખ્યાઓ માટે સમાન છે-ફક્ત સાઇન બીટ અલગ છે.
        // ફ્લોટ્સને સહી કરેલા પૂર્ણાંકો તરીકે સરળતાથી સરખાવવા માટે, આપણે નકારાત્મક સંખ્યાઓના કિસ્સામાં ઘાતક અને મેન્ટિસા બીટ્સને ફ્લિપ કરવાની જરૂર છે.
        // અમે અસરકારક રીતે નંબરોને "two's complement" ફોર્મમાં કન્વર્ટ કરી.
        //
        // ફ્લિપિંગ કરવા માટે, અમે તેની સામે માસ્ક અને XOR બનાવીએ છીએ.
        // નકારાત્મક-સહી કરેલ મૂલ્યોમાંથી અમે શાખા વિના એક "all-ones except for the sign bit" માસ્કની ગણતરી કરીએ છીએ: જમણે સ્થળાંતર પૂર્ણાંકને વિસ્તૃત કરે છે, તેથી અમે માસ્કને "fill" સાઇન બીટ્સ સાથે કરીએ છીએ, અને પછી એક વધુ શૂન્ય બીટને દબાણ કરવા માટે સહી થયેલ નહીં.
        //
        // સકારાત્મક મૂલ્યો પર, માસ્ક એ બધા શૂન્ય છે, તેથી તે કોઈ વિકલ્પ નથી.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// મૂલ્ય ચોક્કસ અંતરાલમાં પ્રતિબંધિત કરો સિવાય કે તે એનએન હોય.
    ///
    /// જો `self`, `max` કરતા વધારે હોય તો `max` અને જો `self`, `min` કરતા ઓછું હોય તો `max` આપે છે.
    /// અન્યથા આ `self` આપે છે.
    ///
    /// નોંધ લો કે જો આ પ્રારંભિક કિંમત પણ NaN હોત તો આ ફંક્શન NaN આપે છે.
    ///
    /// # Panics
    ///
    /// જો ઝેડપેનિક્સ0 ઝેડ જો `min > max`, `min` એનએન છે, અથવા એક્સ02 એક્સ એનએન છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}