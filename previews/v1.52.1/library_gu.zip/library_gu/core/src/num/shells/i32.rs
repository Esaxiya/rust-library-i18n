//! 32-બીટ સહી કરેલ પૂર્ણાંકો પ્રકાર માટે સતત.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! નવો કોડ સીધા જ આદિમ પ્રકાર પર સંકળાયેલ કન્સ્ટન્ટ્સનો ઉપયોગ કરવો જોઈએ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }