//! 128-બીટ સહી કરેલ પૂર્ણાંક પ્રકાર માટે સતત.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! નવો કોડ સીધા જ આદિમ પ્રકાર પર સંકળાયેલ કન્સ્ટન્ટ્સનો ઉપયોગ કરવો જોઈએ.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }