//! પૂર્ણાંકની વ્યાખ્યા જે શૂન્ય સમાન ન હોવા માટે જાણીતી છે.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// પૂર્ણાંક જે શૂન્ય સમાન ન હોવા માટે જાણીતું છે.
            ///
            /// આ કેટલાક મેમરી લેઆઉટ optimપ્ટિમાઇઝેશનને સક્ષમ કરે છે.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// std::mem::size_of નો ઉપયોગ કરો;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// મૂલ્ય તપાસ્યા વિના શૂન્ય વિનાનું બનાવે છે.
                ///
                /// # Safety
                ///
                /// મૂલ્ય શૂન્ય ન હોવું જોઈએ.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // સલામતી: કlerલર દ્વારા સલામત રહેવાની આ બાંયધરી છે.
                    unsafe { Self(n) }
                }

                /// જો આપેલ મૂલ્ય શૂન્ય ન હોય તો બિન-શૂન્ય બનાવે છે.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // સલામતી: અમે હમણાં જ તપાસ કરી છે કે ત્યાં કોઈ `0` નથી
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// આદિમ પ્રકાર તરીકે મૂલ્ય પરત કરે છે.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // સલામત: `self` અને `rhs` બંને નોનઝેરો હોવાથી, છે
                    // બીટવાઇઝનું પરિણામ અથવા નોનઝેરો હશે.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // સલામતી: `self` નોનઝેરો હોવાથી, પરિણામ
                    // બીટવાઇઝ-અથવા `rhs` ની કિંમતને ધ્યાનમાં લીધા વગર નોનઝેરો હશે.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // સલામતી: `rhs` નોનઝેરો હોવાથી, પરિણામ
                    // બીટવાઇઝ-અથવા `self` ની કિંમતને ધ્યાનમાં લીધા વગર નોનઝેરો હશે.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// `self` ની દ્વિસંગી રજૂઆતમાં અગ્રણી શૂન્યની સંખ્યા પરત કરે છે.
                ///
                /// ઘણા આર્કિટેક્ચરો પર, આ ફંક્શન અંતર્ગત પૂર્ણાંક પ્રકાર પર `leading_zeros()` કરતા વધુ સારું પ્રદર્શન કરી શકે છે, કારણ કે શૂન્યનું વિશેષ સંચાલન ટાળી શકાય છે.
                ///
                /// # Examples
                ///
                /// મૂળભૂત વપરાશ:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // સલામતી: `self` શૂન્ય ન હોઈ શકે, તેથી ctlz_nonzero ને ક toલ કરવું સલામત છે
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// `self` ની દ્વિસંગી રજૂઆતમાં પાછળની ઝીરોની સંખ્યા પરત કરે છે.
                ///
                /// ઘણા આર્કિટેક્ચરો પર, આ ફંક્શન અંતર્ગત પૂર્ણાંક પ્રકાર પર `trailing_zeros()` કરતા વધુ સારું પ્રદર્શન કરી શકે છે, કારણ કે શૂન્યનું વિશેષ સંચાલન ટાળી શકાય છે.
                ///
                ///
                /// # Examples
                ///
                /// મૂળભૂત વપરાશ:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // સલામતી: `self` શૂન્ય ન હોઈ શકે, તેથી cttz_nonzero ને ક callલ કરવું સલામત છે
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// આ કામગીરી શૂન્ય તરફ આગળ વધે છે, ચોક્કસ પરિણામના કોઈપણ અપૂર્ણાંક ભાગને કાપીને, અને ઝેડપpanનપિસેક્સ 0 કરી શકતું નથી.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // સલામત: શૂન્યથી ડિવ એ ચકાસાયેલ છે કારણ કે `other` એ નોનઝેરો છે,
                    // અને MIN/-1 ચકાસાયેલ છે કારણ કે `self` એ એક સહી વિનાનું પૂર્ણાંક છે.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// આ ક્રિયા `n % d == n - (n / d) * d` ને સંતોષ આપે છે, અને panic કરી શકતું નથી.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // સલામતી: શૂન્ય દ્વારા રીમ તપાસવામાં આવી છે કારણ કે `other` એ નોનઝેરો છે,
                    // અને MIN/-1 ચકાસાયેલ છે કારણ કે `self` એ એક સહી વિનાનું પૂર્ણાંક છે.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// જો કેટલાક `k` માટે `self == (1 << k)` હોય અને માત્ર જો `true` આપે છે.
                ///
                /// ઘણા આર્કિટેક્ચરો પર, આ ફંક્શન અંતર્ગત પૂર્ણાંક પ્રકાર પર `is_power_of_two()` કરતા વધુ સારું પ્રદર્શન કરી શકે છે, કારણ કે શૂન્યનું વિશેષ સંચાલન ટાળી શકાય છે.
                ///
                ///
                /// # Examples
                ///
                /// મૂળભૂત વપરાશ:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // એલએલવીએમ 11, અહીં જોવામાં આવેલા અમલીકરણમાં `unchecked_sub(x, 1) & x == 0` ને સામાન્ય બનાવે છે.
                    // મૂળભૂત x86-64 લક્ષ્ય પર, આ શૂન્ય ચેક માટે 3 સૂચનો બચાવે છે.
                    // BMI1 X સાથે BMI1 પર, નોનઝેરો હોવાને કારણે તે `BLSR` પર કોડજેન થવા દે છે, જે અંતર્ગત પૂર્ણાંક પ્રકાર પરના `POPCNT` અમલીકરણની તુલનામાં સૂચનાને બચાવે છે.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }