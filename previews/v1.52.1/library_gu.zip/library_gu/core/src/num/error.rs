//! અભિન્ન પ્રકારોમાં રૂપાંતર માટે ભૂલ પ્રકારો.

use crate::convert::Infallible;
use crate::fmt;

/// જ્યારે ચકાસાયેલ ઇન્ટિગલ પ્રકારનાં રૂપાંતર નિષ્ફળ જાય ત્યારે ભૂલ પ્રકાર પાછો ફર્યો.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` નો ઉપનામ બને ત્યારે `From<Infallible> for TryFromIntError` જેવા કોડ કાર્યરત રહેશે તે સુનિશ્ચિત કરવા માટે દબાણ કરતાં મેચ કરો.
        //
        //
        match never {}
    }
}

/// પૂર્ણાંકોનું વિશ્લેષણ કરતી વખતે જે ભૂલ આવી શકે છે.
///
/// આ ભૂલનો ઉપયોગ `from_str_radix()` ફંક્શન માટે [`i8::from_str_radix`] જેવા આદિમ પૂર્ણાંકો પ્રકારો પરના પ્રકાર તરીકે કરવામાં આવે છે.
///
/// # સંભવિત કારણો
///
/// અન્ય કારણો પૈકી, `ParseIntError` શબ્દમાળામાં અગ્રણી અથવા પાછળના વ્હાઇટ સ્પેસને કારણે ફેંકી શકાય છે, જ્યારે તે માનક ઇનપુટથી પ્રાપ્ત થાય છે.
///
/// [`str::trim()`] પદ્ધતિનો ઉપયોગ એ સુનિશ્ચિત કરે છે કે વિશ્લેષણ કરતા પહેલા કોઈ સફેદ સ્થાન બાકી નથી.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// વિવિધ પ્રકારની ભૂલો સંગ્રહિત કરવા માટે એનમ, જે પૂર્ણાંકનું વિશ્લેષણ નિષ્ફળ થવાનું કારણ બની શકે છે.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// પદચ્છેદનનું મૂલ્ય ખાલી છે.
    ///
    /// અન્ય કારણો પૈકી, ખાલી શબ્દમાળાને વિશ્લેષણ કરતી વખતે આ પ્રકારનું નિર્માણ કરવામાં આવશે.
    Empty,
    /// તેના સંદર્ભમાં અમાન્ય અંક શામેલ છે.
    ///
    /// અન્ય કારણો પૈકી, આ વેરિઅન્ટનું નિર્માણ જ્યારે કોઈ ASCII નો સમાવેશ ન કરે તેવા શબ્દમાળાને વિશ્લેષણ કરતી વખતે બનાવવામાં આવશે.
    ///
    /// જ્યારે `+` અથવા `-` એક શબ્દમાળાની જાતે જ અથવા સંખ્યાની મધ્યમાં ખોટી પડે ત્યારે આ વેરિઅન્ટનું નિર્માણ પણ કરવામાં આવે છે.
    ///
    ///
    InvalidDigit,
    /// લક્ષ્ય પૂર્ણાંકના પ્રકારમાં પૂર્ણાંક સંગ્રહવા માટે ખૂબ મોટો છે.
    PosOverflow,
    /// લક્ષ્ય પૂર્ણાંકના પ્રકારમાં પૂર્ણાંક સંગ્રહવા માટે ખૂબ નાનો છે.
    NegOverflow,
    /// કિંમત શૂન્ય હતી
    ///
    /// આ વેરિઅન્ટ ઉત્સર્જિત થશે જ્યારે પાર્સિંગ શબ્દમાળાની કિંમત શૂન્ય હોય, જે શૂન્ય સિવાયના પ્રકારો માટે ગેરકાયદેસર હશે.
    ///
    Zero,
}

impl ParseIntError {
    /// પૂર્ણાંક નિષ્ફળ થવાના વિગતવાર કારણને આઉટપુટ કરે છે.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}