//! વૈકલ્પિક મૂલ્યો.
//!
//! પ્રકાર [`Option`] વૈકલ્પિક મૂલ્યનું પ્રતિનિધિત્વ કરે છે: દરેક [`Option`] કાં તો [`Some`] છે અને તેમાં મૂલ્ય અથવા [`None`] હોય છે, અને નથી.
//! [`Option`] પ્રકારો ઝેડ રસ્ટ0 ઝેડ કોડમાં ખૂબ સામાન્ય છે, કારણ કે તેમના સંખ્યાબંધ ઉપયોગો છે:
//!
//! * પ્રારંભિક મૂલ્યો
//! * કાર્યો માટે વળતર મૂલ્યો કે જેની સંપૂર્ણ ઇનપુટ શ્રેણી (આંશિક કાર્યો) પર વ્યાખ્યાયિત નથી
//! * અન્યથા સરળ ભૂલોની જાણ કરવા માટેનું વળતર, જ્યાં ભૂલથી [`None`] પરત આવે છે
//! * વૈકલ્પિક સ્ટ્રક્ટ ક્ષેત્રો
//! * એવા ક્ષેત્રોનું માળખું કરો કે જે લોન લઈ શકે અથવા "taken"
//! * વૈકલ્પિક કાર્ય દલીલો
//! * ન્યુલેબલ પોઇંટર્સ
//! * મુશ્કેલ પરિસ્થિતિમાંથી વસ્તુઓ અદલાબદલ કરવી
//!
//! [`ઓપ્શન`] એ સામાન્ય રીતે મૂલ્યની હાજરીને ક્વેરી કરવા અને પગલાં લેવા માટેના દાખલાની મેચિંગ સાથે જોડી કરવામાં આવે છે, હંમેશાં [`None`] કેસનો હિસાબ કરે છે.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ફંકશનનું વળતર મૂલ્ય એ એક વિકલ્પ છે
//! let result = divide(2.0, 3.0);
//!
//! // મૂલ્ય પ્રાપ્ત કરવા માટે દાખલાની મેળ
//! match result {
//!     // આ વિભાગ માન્ય હતો
//!     Some(x) => println!("Result: {}", x),
//!     // આ વિભાગ અમાન્ય હતો
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: ઘણી બધી પદ્ધતિઓ સાથે, વ્યવહારમાં `Option` નો ઉપયોગ કેવી રીતે થાય છે તે બતાવો
//
//! # વિકલ્પો અને પોઇંટર્સ ("nullable" પોઇન્ટર)
//!
//! ઝેડ રસ્ટ0 ઝેડના નિર્દેશક પ્રકારો હંમેશાં કોઈ માન્ય સ્થાન પર નિર્દેશ કરેલા હોવા જોઈએ;ત્યાં કોઈ "null" સંદર્ભો નથી.તેના બદલે, ઝેડ રસ્ટ0 ઝેડમાં *વૈકલ્પિક* પોઇંટર્સ છે, વૈકલ્પિક માલિકીની બ boxક્સની જેમ, [`વિકલ્પ`]`<`[`બ`ક્સ<T>`]`> `.
//!
//! નીચેનું ઉદાહરણ [`i32`] નો વૈકલ્પિક બ createક્સ બનાવવા માટે [`Option`] નો ઉપયોગ કરે છે.
//! નોંધ લો કે પહેલા આંતરિક [`i32`] મૂલ્યનો ઉપયોગ કરવા માટે, બ0ક્સનું મૂલ્ય છે કે કેમ તે નક્કી કરવા માટે `check_optional` ફંક્શનને પેટર્ન મેચિંગનો ઉપયોગ કરવાની જરૂર છે (દા.ત. તે [`Some(...)`][`Some`]) છે કે ([`None`]) નથી.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! ઝેડ રસ્ટ0 ઝેડ નીચેના પ્રકારો `T` ને izeપ્ટિમાઇઝ કરવાની બાંયધરી આપે છે જેમ કે [`Option<T>`] એ `T` જેટલું કદ ધરાવે છે:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` આ સૂચિમાંના એક પ્રકારની આજુબાજુ સ્ટ્રક્ટ.
//!
//! આગળ ખાતરી આપવામાં આવી છે કે, ઉપરના કેસો માટે, `T` ના બધા માન્ય મૂલ્યોથી `Option<T>` અને `Some::<T>(_)` થી `T` સુધી [`mem::transmute`] કરી શકાય છે (પરંતુ `None::<T>` થી `T` માં ટ્રાન્સમિટ કરવું એ અસ્પષ્ટ વર્તણૂક છે).
//!
//! # Examples
//!
//! [`Option`] પર બેઝિક પેટર્ન મેચિંગ:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // સમાયેલ શબ્દમાળાઓનો સંદર્ભ લો
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // વિકલ્પને નાશ કરીને, સમાયેલી સ્ટ્રિંગને દૂર કરો
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! લૂપ પહેલાં [`None`] પર પરિણામ પ્રારંભ કરો:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // શોધવાની માહિતીની સૂચિ.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // અમે સૌથી મોટા પ્રાણીના નામની શોધ કરવા જઈ રહ્યા છીએ, પરંતુ શરૂ કરવા માટે અમારી પાસે ફક્ત `None` છે.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // હવે અમને કેટલાક મોટા પ્રાણીનું નામ મળી ગયું છે
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` પ્રકાર.વધુ માટે [the module level documentation](self) જુઓ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// કોઈ કિંમત નથી
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// કેટલાક મૂલ્ય `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// પ્રકાર અમલીકરણ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // સમાયેલ મૂલ્યોની પૂછપરછ કરી રહી છે
    /////////////////////////////////////////////////////////////////////////

    /// જો વિકલ્પ [`Some`] મૂલ્ય હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// જો વિકલ્પ [`None`] મૂલ્ય હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// જો વિકલ્પ આપેલ મૂલ્ય ધરાવતો [`Some`] મૂલ્ય હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // સંદર્ભો સાથે કામ કરવા માટે એડેપ્ટર
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` થી `Option<&T>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળને સાચવીને, `વિકલ્પ <` [`શબ્દમાળા]`> `ને an વિકલ્પ <` [`યુઝાઇઝ]`> `માં રૂપાંતરિત કરે છે.
    /// [`map`] પધ્ધતિ `self` દલીલને મૂલ્ય દ્વારા લે છે, મૂળ વપરાશ કરે છે, તેથી આ તકનીક `as_ref` નો ઉપયોગ કરીને પહેલા મૂળની અંદરના મૂલ્યના સંદર્ભમાં `Option` લે છે.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // પ્રથમ, `Option<String>` ને `as_ref` સાથે `Option<&String>` પર કાસ્ટ કરો, પછી સ્ટેક પર `text` છોડીને, તે `map` સાથે * વાપરો.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` થી `Option<&mut T>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`]`<અને વિકલ્પથી રૂપાંતરિત કરે છે<T>>`થી ption વિકલ્પ <`[`પીન`]` <અને ટી>> `.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // સલામતી: `x` ને પિન કરવાની બાંયધરી છે કારણ કે તે `self` માંથી આવે છે
        // જે પિન કરેલું છે.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`] from <અને મ્યુટ વિકલ્પથી રૂપાંતરિત કરે છે<T>> `થી ption વિકલ્પ <` [`પીન`]`<અને મ્યુટ ટી>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // સલામત: `get_unchecked_mut` નો ઉપયોગ `Option` ને `self` ની અંદર ખસેડવા માટે ક્યારેય થતો નથી.
        // `x` પિન કરવાની ખાતરી આપી છે કારણ કે તે `self` માંથી આવે છે જે પિન કરેલું છે.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // સમાયેલ મૂલ્યો મેળવવાનું
    /////////////////////////////////////////////////////////////////////////

    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Some`] મૂલ્ય પરત કરે છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત `msg` દ્વારા પ્રદાન કરેલ કસ્ટમ panic સંદેશ સાથેનો [`None`] છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Some`] મૂલ્ય પરત કરે છે.
    ///
    /// કારણ કે આ કાર્ય panic શકે છે, તેથી તેનો ઉપયોગ સામાન્ય રીતે નિરાશ કરવામાં આવે છે.
    /// તેના બદલે, પેટર્ન મેચિંગનો ઉપયોગ કરવાનું અને [`None`] કેસને સ્પષ્ટ રીતે હેન્ડલ કરવાનું પસંદ કરો અથવા [`unwrap_or`], [`unwrap_or_else`] અથવા [`unwrap_or_default`] પર ક .લ કરો.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics જો સેલ્ફ વેલ્યુ [`None`] ની બરાબર છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// સમાયેલ [`Some`] મૂલ્ય અથવા પ્રદાન કરેલું ડિફ .લ્ટ પાછું આપે છે.
    ///
    /// `unwrap_or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`unwrap_or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// સમાયેલ [`Some`] મૂલ્ય પરત કરે છે અથવા તેને બંધ કરવાથી ગણતરી કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// `self` મૂલ્યનો વપરાશ કરતા, સમાયેલ [`Some`] મૂલ્ય પરત કરે છે, તે મૂલ્ય [`None`] નથી તે તપાસ્યા વિના.
    ///
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને [`None`] પર કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // અપ્રભાજિત વર્તન!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // સલામતી: સલામતી કરાર કlerલર દ્વારા સમર્થન આપવું આવશ્યક છે.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // સમાયેલ મૂલ્યોનું પરિવર્તન
    /////////////////////////////////////////////////////////////////////////

    /// સમાયેલ મૂલ્ય પર ફંક્શન લાગુ કરીને એક `Option<T>` થી `Option<U>` નકશા.
    ///
    /// # Examples
    ///
    /// મૂળ વપરાશમાં લેતા, `વિકલ્પ <` [`શબ્દમાળા]`> `ને an વિકલ્પ <` [`યુઝાઇઝ]`> `માં રૂપાંતરિત કરે છે:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` લેતા, મૂલ્ય દ્વારા * સ્વ લે છે
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// સમાયેલ મૂલ્ય પર ફંકશન લાગુ કરે છે (જો કોઈ હોય તો), અથવા પ્રદાન કરેલું ડિફ defaultલ્ટ પાછું આપે છે (જો નહીં).
    ///
    /// `map_or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`map_or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// સમાયેલ મૂલ્ય પર ફંકશન લાગુ કરે છે (જો કોઈ હોય તો), અથવા ડિફ defaultલ્ટની ગણતરી (જો નહીં).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ને [`Result<T, E>`] માં `Option<T>` અને [`None`] ને [`Err(err)`] માં મેપિંગ કરીને `Option<T>` ને [`Result<T, E>`] માં રૂપાંતરિત કરે છે.
    ///
    /// `ok_or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`ok_or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ને [`Result<T, E>`] માં `Option<T>` અને [`None`] ને [`Err(err())`] માં મેપિંગ કરીને `Option<T>` ને [`Result<T, E>`] માં રૂપાંતરિત કરે છે.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// વિકલ્પમાં `value` દાખલ કરે છે તે પછી તેના માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// જો વિકલ્પમાં પહેલાથી જ મૂલ્ય છે, તો જૂનું મૂલ્ય છોડી દેવામાં આવશે.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // સલામતી: ઉપરનો કોડ ફક્ત વિકલ્પ ભર્યો
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ઇટરેટર કન્સ્ટ્રકટર્સ
    /////////////////////////////////////////////////////////////////////////

    /// સંભવિત સમાવેલ મૂલ્ય પર ઇરેટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// સંભવિત સમાવેલ મૂલ્ય પર પરિવર્તનીય ઇટરેટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // મૂલ્યો પર બુલિયન કામગીરી, આતુર અને આળસુ
    /////////////////////////////////////////////////////////////////////////

    /// જો વિકલ્પ [`None`] છે, તો [`None`] પરત કરે છે, નહીં તો `optb` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// જો વિકલ્પ [`None`] હોય તો [`None`] પરત કરે છે, નહીં તો આવરિત મૂલ્ય સાથે `f` ને ક callsલ કરે છે અને પરિણામ આપે છે.
    ///
    ///
    /// કેટલીક ભાષાઓ આ ક્રિયાને ફ્લેટમેપ કહે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// જો વિકલ્પ [`None`] છે, તો [`None`] પરત કરે છે, નહીં તો આવરિત મૂલ્ય સાથે `predicate` ને ક callsલ કરે છે અને વળતર આપે છે:
    ///
    ///
    /// - [`Some(t)`] જો `predicate` `true` (જ્યાં `t` વીંટેલું મૂલ્ય છે) આપે છે, અને
    /// - [`None`] જો `predicate` `false` આપે છે.
    ///
    /// આ ફંક્શન [`Iterator::filter()`] જેવું જ કામ કરે છે.
    /// તમે કલ્પના કરી શકો છો કે `Option<T>` એક અથવા શૂન્ય તત્વો પર ઇરેટર છે.
    /// `filter()` કયા તત્વો રાખવા તે નક્કી કરવા દે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// જો તેમાં કોઈ મૂલ્ય હોય તો વિકલ્પ પરત કરે છે, નહીં તો `optb` આપે છે.
    ///
    /// `or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// વિકલ્પ પરત કરે છે જો તેમાં કોઈ મૂલ્ય હોય, તો અન્યથા `f` પર ક callsલ કરે છે અને પરિણામ પાછું આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// જો `self`, `optb`, [`Some`], બરાબર એક, [`Some`] આપે તો [`Some`] પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // જો કંઈ નહીં હોય તો દાખલ કરવા માટે અને એન્ટ્રી જેવી કામગીરી
    /////////////////////////////////////////////////////////////////////////

    /// જો તે [`None`] હોય તો વિકલ્પમાં `value` દાખલ કરો, પછી સમાયેલ મૂલ્યનો પરિવર્તનશીલ સંદર્ભ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// ડિફ defaultલ્ટ મૂલ્યને વિકલ્પમાં દાખલ કરે છે જો તે [`None`] છે, તો પછી સમાવેલ મૂલ્યનો પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` માંથી ગણવામાં આવેલ મૂલ્યને વિકલ્પમાં દાખલ કરો જો તે [`None`] છે, તો પછી સમાવેલ મૂલ્યનો પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // સલામત: `self` માટેનો `None` વેરિઅન્ટ, `Some` દ્વારા બદલવામાં આવ્યો હોત
            // ઉપરના કોડમાં વિવિધતા.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] ને તેની જગ્યાએ છોડીને, વિકલ્પમાંથી મૂલ્ય લે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// પેરામીટરમાં આપેલા મૂલ્ય દ્વારા વિકલ્પમાં વાસ્તવિક મૂલ્યને બદલીને, જો હાજર હોય તો જૂના મૂલ્યને પરત કરીને, એક પણ જગ્યાએ ડી.સી.ટી.કરણ કર્યા વિના, તેની જગ્યાએ એક [`Some`] છોડીને.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// બીજા `Option` સાથે ઝિપ્સ `self`.
    ///
    /// જો `self` `Some(s)` છે અને `other` એ `Some(o)` છે, તો આ પદ્ધતિ `Some((s, o))` આપે છે.
    /// નહિંતર, `None` પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ફિક્શન `f` સાથે ઝિપ્સ `self` અને બીજો `Option`.
    ///
    /// જો `self` `Some(s)` છે અને `other` એ `Some(o)` છે, તો આ પદ્ધતિ `Some(f(s, o))` આપે છે.
    /// નહિંતર, `None` પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// વિકલ્પની સામગ્રીની નકલ કરીને એક `Option<&T>` ને X0X નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// વિકલ્પની સામગ્રીની નકલ કરીને એક `Option<&mut T>` ને X0X નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// વિકલ્પની સામગ્રીને ક્લોન કરીને એક `Option<&T>` ને X0X નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// વિકલ્પની સામગ્રીને ક્લોન કરીને એક `Option<&mut T>` ને X0X નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ની અપેક્ષા કરતી વખતે અને કંઇ પરત નહીં કરતી વખતે `self` લે છે.
    ///
    /// # Panics
    ///
    /// ઝેડપેનિક્સ0 ઝેડ જો મૂલ્ય એક [`Some`] હોય, તો તેમાં પસાર થયેલા સંદેશ અને [`Some`] ની સામગ્રી શામેલ panic સંદેશ હોય.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // આ panic નહીં કરે, કારણ કે બધી કીઓ અનન્ય છે.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ની અપેક્ષા કરતી વખતે અને કંઇ પરત નહીં કરતી વખતે `self` લે છે.
    ///
    /// # Panics
    ///
    /// ઝેડપેનિક્સ0 ઝેડ જો [`સોમેસ] ની કિંમત દ્વારા પ્રદાન કરવામાં આવેલ કસ્ટમ ઝેડપpanપનિક0 ઝેડ સંદેશ સાથે, [`Some`] હોય તો.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // આ panic નહીં કરે, કારણ કે બધી કીઓ અનન્ય છે.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// સમાયેલ [`Some`] મૂલ્ય અથવા ડિફોલ્ટ આપે છે
    ///
    /// પછી `self` દલીલ લે છે, જો [`Some`], સમાયેલ મૂલ્ય પરત કરે છે, અન્યથા જો [`None`], તે પ્રકાર માટે [default value] આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// શબ્દમાળાને પૂર્ણાંકોમાં રૂપાંતરિત કરે છે, નબળી રીતે બનાવેલા શબ્દમાળાઓને 0 માં ફેરવે છે (પૂર્ણાંકો માટેનું મૂળભૂત મૂલ્ય).
    /// [`parse`] કોઈપણ અન્ય પ્રકારમાં એક શબ્દમાળા રૂપાંતરિત કરે છે જે [`FromStr`] લાગુ કરે છે, ભૂલ પર [`None`] પરત કરે છે.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (અથવા `&Option<T>`) થી `Option<&T::Target>` માં ફેરવે છે.
    ///
    /// મૂળ વિકલ્પને તે જગ્યાએ છોડી દે છે, મૂળના સંદર્ભ સાથે એક નવું બનાવે છે, ઉપરાંત, [`Deref`] દ્વારા સમાવિષ્ટોનો દબાણ કરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (અથવા `&mut Option<T>`) થી `Option<&mut T::Target>` માં ફેરવે છે.
    ///
    /// મૂળ `Option` ને અંદરથી છોડીને, આંતરિક પ્રકારનાં `Deref::Target` પ્રકારનો પરિવર્તનીય સંદર્ભ ધરાવતું એક નવું બનાવ્યું.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] ના `Option` ને `Option` ના [`Result`] માં સ્થાનાંતરિત કરે છે.
    ///
    /// [`None`] [`Ok`]`(`[`કંઈ નહીં]]`) ma પર મેપ કરવામાં આવશે.
    /// [`કેટલાક`]`(`[`Ok`] `(_))` અને [`સમર]` (`[` એરર] `(_)) ને [` Ok`] to પર મેપ કરવામાં આવશે`[`કેટલાક`] `(_))` અને [`એરર]` (_) `.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// આ પોતે જ .expect() ના કોડ કદને ઘટાડવા માટે એક અલગ કાર્ય છે.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// આ પોતે જ .expect_none() ના કોડ કદને ઘટાડવા માટે એક અલગ કાર્ય છે.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait અમલીકરણો
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] પરત આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// સંભવિત સમાયેલી કિંમત કરતાં વધુ વપરાશકાર ઇટરેટરને આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` ને નવી `Some` માં ક Copપિ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` થી `Option<&T>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળને સાચવીને, `વિકલ્પ <` [`શબ્દમાળા]`> `ને an વિકલ્પ <` [`યુઝાઇઝ]`> `માં રૂપાંતરિત કરે છે.
    /// [`map`] પધ્ધતિ `self` દલીલને મૂલ્ય દ્વારા લે છે, મૂળ વપરાશ કરે છે, તેથી આ તકનીક `as_ref` નો ઉપયોગ કરીને પહેલા મૂળની અંદરના મૂલ્યના સંદર્ભમાં `Option` લે છે.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` થી `Option<&mut T>` માં રૂપાંતરિત કરે છે
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// વિકલ્પ ઇટરેટર્સ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// એક [`Option`] ના [`Some`] વેરિએન્ટના સંદર્ભમાં પુનરાવર્તક.
///
/// જો [`Option`] એ [`Some`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
///
/// આ `struct` એ [`Option::iter`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] ના [`Some`] વેરિઅન્ટના પરિવર્તનીય સંદર્ભ પર એક પુનરાવર્તક.
///
/// જો [`Option`] એ [`Some`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
///
/// આ `struct` એ [`Option::iter_mut`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// એક [`Option`] ના [`Some`] વેરિઅન્ટમાં મૂલ્ય પર પુનરાવર્તક.
///
/// જો [`Option`] એ [`Some`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
///
/// આ `struct` એ [`Option::into_iter`] ફંક્શન દ્વારા બનાવવામાં આવ્યું છે.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] માં દરેક તત્વ લે છે: જો તે [`None`][Option::None] છે, તો આગળ કોઈ તત્વો લેવામાં આવ્યાં નથી, અને [`None`][Option::None] પરત આવે છે.
    /// જો કોઈ [`None`][Option::None] ન થાય, તો દરેક [`Option`] ના મૂલ્યોવાળા કન્ટેનર પરત આવે છે.
    ///
    /// # Examples
    ///
    /// અહીં એક ઉદાહરણ છે જે vector માં દરેક પૂર્ણાંકમાં વધારો કરે છે.
    /// અમે `add` ના ચકાસાયેલ ચલનો ઉપયોગ કરીએ છીએ કે જ્યારે ગણતરી ઓવરફ્લો થાય ત્યારે `None` આપે છે.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// જેમ તમે જોઈ શકો છો, આ અપેક્ષિત, માન્ય વસ્તુઓ પરત કરશે.
    ///
    /// અહીં બીજું એક ઉદાહરણ છે જે પૂર્ણાંકોની બીજી સૂચિમાંથી એકને બાદબાકી કરવાનો પ્રયાસ કરે છે, આ વખતે અંડરફ્લોની તપાસ કરે છે:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// છેલ્લું તત્વ શૂન્ય હોવાથી, તે નીચે વહેશે.આમ, પરિણામી મૂલ્ય `None` છે.
    ///
    /// પહેલાંના ઉદાહરણ પર અહીં વિવિધતા છે, તે બતાવે છે કે પ્રથમ `None` પછી કોઈ વધુ તત્વો `iter` માંથી લેવામાં આવતાં નથી.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ત્રીજા તત્વને લીધે તે પાણીની અંદર વહી ગયો, તેથી આગળ કોઈ તત્વો લેવામાં આવ્યા નહીં, તેથી `shared` નું અંતિમ મૂલ્ય 16 નહીં, 6 (= `3 + 2 + 1`) છે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): જ્યારે આ પ્રદર્શન બગ બંધ હોય ત્યારે તેને Iterator::scan સાથે બદલી શકાય છે.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ભૂલ પ્રકાર કે જે ટ્રાયલ 00પરેટર (`?`) ને `None` મૂલ્ય પર લાગુ કરવાથી પરિણમે છે.
/// જો તમે `x?` (જ્યાં `x` એ `Option<T>` છે) ને તમારા ભૂલ પ્રકારમાં રૂપાંતરિત કરવાની મંજૂરી આપવા માંગતા હો, તો તમે `YourErrorType` માટે `impl From<NoneError>` લાગુ કરી શકો છો.
///
/// તે કિસ્સામાં, ફંક્શનની અંદર `x?` જે `Result<_, YourErrorType>` આપે છે તે `None` મૂલ્યને `Err` પરિણામમાં અનુવાદિત કરશે.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` થી `Option<T>` માં રૂપાંતરિત કરે છે
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// ફ્લેટ્ટનિંગ એક સમયે માળાના એક સ્તરને દૂર કરે છે:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}