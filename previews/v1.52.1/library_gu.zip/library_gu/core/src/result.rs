//! `Result` પ્રકાર સાથે હેન્ડલ કરવામાં ભૂલ.
//!
//! [`Result<T, E>`][`Result`] ભૂલો પાછા ફરવા અને પ્રચાર કરવા માટે વપરાય છે.
//! તે સફળતાનું પ્રતિનિધિત્વ કરતું અને મૂલ્ય ધરાવતા, અને [`Err(E)`], ભૂલોનું પ્રતિનિધિત્વ કરતું અને ભૂલ મૂલ્ય ધરાવતા, [`Ok(T)`], વેરિએન્ટ્સ સાથેનું એક એનુમ છે.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! જ્યારે પણ ભૂલોની અપેક્ષા હોય અને પુનoveપ્રાપ્ત થઈ શકે ત્યારે કાર્યો [`Result`] પાછા આપે છે.`std` crate માં, [`Result`] એ [I/O](../../std/io/index.html) માટે સૌથી વધુ ઉપયોગમાં લેવામાં આવે છે.
//!
//! [`Result`] પરત ફરતા એક સરળ ફંક્શનની વ્યાખ્યા હોઇ શકે છે અને તેના જેવા:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`Result s] s પર પેટર્નની મેચિંગ સરળ કેસો માટે સ્પષ્ટ અને સીધી છે, પરંતુ [`Result`] કેટલીક સુવિધા પદ્ધતિઓ સાથે આવે છે જે તેની સાથે કામ કરવાનું વધુ સંકળાયેલી બનાવે છે.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` અને `is_err` પદ્ધતિઓ જે કહે છે તે કરે છે.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` લે છે અને બીજું ઉત્પાદન કરે છે.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // ગણતરી ચાલુ રાખવા માટે `and_then` નો ઉપયોગ કરો.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // ભૂલને હેન્ડલ કરવા માટે `or_else` નો ઉપયોગ કરો.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // પરિણામનો ઉપયોગ કરો અને `unwrap` સાથેની સામગ્રી પરત કરો.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # પરિણામોનો ઉપયોગ કરવો આવશ્યક છે
//!
//! ભૂલો સૂચવવા માટે વળતરના મૂલ્યોનો ઉપયોગ કરવાની સામાન્ય સમસ્યા એ છે કે વળતરની કિંમતને અવગણવી સરળ છે, આમ ભૂલને હેન્ડલ કરવામાં નિષ્ફળ થવું.
//! [`Result`] `#[must_use]` એટ્રિબ્યુટ સાથે ટિપ્પણી કરવામાં આવે છે, જેના પરિણામે જ્યારે પરિણામ મૂલ્યને અવગણવામાં આવે છે ત્યારે કમ્પાઇલર ચેતવણી આપવાનું કારણ બને છે.
//! આ [`Result`] ને ખાસ કરીને વિધેયોમાં ઉપયોગી બનાવે છે જે ભૂલોનો સામનો કરી શકે છે પરંતુ અન્યથા ઉપયોગી મૂલ્ય પાછું આપતું નથી.
//!
//! [`Write`] trait દ્વારા I/O પ્રકારો માટે નિર્ધારિત [`write_all`] પદ્ધતિનો વિચાર કરો:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] ની વાસ્તવિક વ્યાખ્યા [`io::Result`] નો ઉપયોગ કરે છે, જે [`પરિણામ`] just નો એક પર્યાય છે<T, `[`io: :Error`]`>`.*
//!
//! આ પદ્ધતિ મૂલ્યનું નિર્માણ કરતી નથી, પરંતુ લખાણ નિષ્ફળ થઈ શકે છે.ભૂલ કેસને હેન્ડલ કરવાનું નિર્ણાયક છે, અને * આ રીતે કંઇક લખવું નહીં:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // જો `write_all` ભૂલો છે, તો પછી આપણે ક્યારેય જાણીશું નહીં, કારણ કે વળતરની કિંમત અવગણવામાં આવે છે.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! જો તમે Rust માં *કરો* છો, તો કમ્પાઇલર તમને ચેતવણી આપશે (ડિફ defaultલ્ટ રૂપે, `unused_must_use` lint દ્વારા નિયંત્રિત).
//!
//! તમે તેના બદલે, જો તમે ભૂલને હેન્ડલ ન કરવા માંગતા હો, તો ફક્ત [`expect`] સાથે સફળતા પર ભાર મૂકો.
//! આ panic કરશે જો લખાણ નિષ્ફળ જાય, તો શામેલ શા માટે ઉપયોગી સંદેશ પ્રદાન કરે છે:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! તમે સરળતાથી સફળતા પર ભારપૂર્વક જણાવી શકો છો:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! અથવા [`?`] સાથે ક upલ સ્ટેક ઉપર ભૂલનો પ્રચાર કરો:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # પ્રશ્ન ચિહ્ન operatorપરેટર, `?`
//!
//! જ્યારે કોડ લખતા વખતે ઘણા કાર્યો કહે છે કે જે [`Result`] પ્રકાર પરત કરે છે, ત્યારે ભૂલ સંભાળવી કંટાળાજનક હોઈ શકે છે.
//! ક્વોલ સ્ટેક ઉપર પ્રસરેલી ભૂલોના કેટલાક બોઇલરપ્લેટને ક્વિલ માર્ક operatorપરેટર, [`?`], છુપાવે છે.
//!
//! તે આને બદલે છે:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // ભૂલ પર પ્રારંભિક વળતર
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! આ સાથે:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // ભૂલ પર પ્રારંભિક વળતર
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *તે ખૂબ સરસ છે!*
//!
//! [`?`] સાથેની અભિવ્યક્તિને સમાપ્ત કરવાથી, અનડેપ્ડ સફળતા ([`Ok`]) મૂલ્યમાં પરિણમશે, જ્યાં સુધી પરિણામ [`Err`] ન આવે, ત્યાં સુધી કે [`Err`] એન્ક્લોઝિંગ ફંક્શનથી વહેલી પરત આવે છે.
//!
//!
//! [`?`] ફક્ત તે ફંક્શન્સમાં જ વાપરી શકાય છે જે [`Err`] આપે છે તે [`Err`] ના પ્રારંભિક વળતરને કારણે આપે છે.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` એક પ્રકાર છે જે સફળતા ([`Ok`]) અથવા નિષ્ફળતા ([`Err`]) ને રજૂ કરે છે.
///
/// વિગતો માટે [module documentation](self) જુઓ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// સફળતા મૂલ્ય શામેલ છે
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// ભૂલ મૂલ્ય શામેલ છે
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// પ્રકાર અમલીકરણ
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // સમાયેલ મૂલ્યોની પૂછપરછ કરી રહી છે
    /////////////////////////////////////////////////////////////////////////

    /// જો પરિણામ [`Ok`] હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// જો પરિણામ [`Err`] હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// જો પરિણામ આપેલ મૂલ્ય ધરાવતું [`Ok`] મૂલ્ય હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// જો પરિણામ આપેલ મૂલ્ય ધરાવતું [`Err`] મૂલ્ય હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // દરેક ચલ માટે એડેપ્ટર
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` થી [`Option<T>`] માં રૂપાંતરિત કરે છે.
    ///
    /// `self` ને [`Option<T>`] માં રૂપાંતરિત કરે છે, `self` વપરાશ કરે છે, અને ભૂલ હોય તો તેને છોડી દો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` થી [`Option<E>`] માં રૂપાંતરિત કરે છે.
    ///
    /// `self` ને [`Option<E>`] માં રૂપાંતરિત કરે છે, `self` વપરાશ કરે છે અને સફળતા મૂલ્યને અવગણવામાં આવે છે, જો કોઈ હોય તો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // સંદર્ભો સાથે કામ કરવા માટે એડેપ્ટર
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` થી `Result<&T, &E>` માં રૂપાંતરિત કરે છે.
    ///
    /// મૂળ જગ્યાએ મૂકીને, મૂળમાં સંદર્ભ ધરાવતા, એક નવું `Result` ઉત્પન્ન કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` થી `Result<&mut T, &mut E>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // સમાયેલ મૂલ્યોનું પરિવર્તન
    /////////////////////////////////////////////////////////////////////////

    /// એક [`Err`] મૂલ્યને અસ્પષ્ટ છોડીને, સમાયેલ [`Ok`] મૂલ્ય પર ફંક્શન લાગુ કરીને એક `Result<T, E>` થી `Result<U, E>` નકશા બનાવો.
    ///
    ///
    /// આ ફંક્શનનો ઉપયોગ બે કાર્યોના પરિણામો કંપોઝ કરવા માટે થઈ શકે છે.
    ///
    /// # Examples
    ///
    /// બે વડે ગુણાંકિત શબ્દમાળાની દરેક લાઇન પર સંખ્યાઓ છાપો.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// સમાયેલ મૂલ્ય (જો [`Ok`]) પર કાર્ય લાગુ કરે છે, અથવા પ્રદાન કરેલું ડિફ defaultલ્ટ પાછું આપે છે (જો [`Err`] હોય તો).
    ///
    /// `map_or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`map_or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// સમાયેલ [`Ok`] મૂલ્ય પર ફંક્શન લાગુ કરીને અથવા સમાવિષ્ટ [`Err`] મૂલ્ય પર ફ fallલબેક ફંક્શન દ્વારા `Result<T, E>` થી `U` નકશા બનાવો.
    ///
    ///
    /// ભૂલને હેન્ડલ કરતી વખતે આ ફંક્શનનો ઉપયોગ સફળ પરિણામ અનપackક કરવા માટે થઈ શકે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// એક [`Ok`] મૂલ્યને અસ્પષ્ટ છોડીને, સમાયેલ [`Err`] મૂલ્ય પર ફંક્શન લાગુ કરીને એક `Result<T, E>` થી `Result<T, F>` નકશા બનાવો.
    ///
    ///
    /// ભૂલને હેન્ડલ કરતી વખતે આ ફંક્શનનો ઉપયોગ સફળ પરિણામમાંથી પસાર થવા માટે થઈ શકે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ઇટરેટર કન્સ્ટ્રકટર્સ
    /////////////////////////////////////////////////////////////////////////

    /// સંભવિત સમાવેલ મૂલ્ય પર ઇરેટર આપે છે.
    ///
    /// જો પરિણામ [`Result::Ok`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// સંભવિત સમાવેલ મૂલ્ય પર પરિવર્તનીય ઇટરેટર આપે છે.
    ///
    /// જો પરિણામ [`Result::Ok`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // મૂલ્યો પર બુલિયન કામગીરી, આતુર અને આળસુ
    /////////////////////////////////////////////////////////////////////////

    /// જો પરિણામ [`Ok`] હોય તો `res` પરત કરે છે, નહીં તો `self` નું [`Err`] મૂલ્ય આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// જો પરિણામ [`Ok`] હોય તો `op` પર ક .લ કરો, નહીં તો `self` નું [`Err`] મૂલ્ય આપે છે.
    ///
    ///
    /// આ ફંક્શનનો ઉપયોગ `Result` મૂલ્યોના આધારે નિયંત્રણ પ્રવાહ માટે થઈ શકે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// જો પરિણામ [`Err`] હોય તો `res` પરત કરે છે, નહીં તો `self` નું [`Ok`] મૂલ્ય આપે છે.
    ///
    /// `or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// જો પરિણામ [`Err`] હોય તો `op` પર ક .લ કરો, નહીં તો `self` નું [`Ok`] મૂલ્ય આપે છે.
    ///
    ///
    /// આ કાર્ય પરિણામ મૂલ્યોના આધારે નિયંત્રણ પ્રવાહ માટે વાપરી શકાય છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// સમાયેલ [`Ok`] મૂલ્ય અથવા પ્રદાન કરેલું ડિફ .લ્ટ પાછું આપે છે.
    ///
    /// `unwrap_or` પર પસાર કરેલી દલીલોનું આતુરતાથી મૂલ્યાંકન કરવામાં આવે છે;જો તમે ફંક્શન ક callલનું પરિણામ પસાર કરી રહ્યાં છો, તો [`unwrap_or_else`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે, જેનું આળસુ મૂલ્યાંકન કરવામાં આવે છે.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// સમાયેલ [`Ok`] મૂલ્ય પરત કરે છે અથવા તેને બંધ કરવાથી ગણતરી કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// `self` મૂલ્યનો વપરાશ કરતા, સમાયેલ [`Ok`] મૂલ્ય પરત કરે છે, તે મૂલ્યાંકન [`Err`] નથી તે તપાસ્યા વિના.
    ///
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને [`Err`] પર કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // અપ્રભાજિત વર્તન!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // સલામતી: સલામતી કરાર કlerલર દ્વારા સમર્થન આપવું આવશ્યક છે.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// `self` મૂલ્યનો વપરાશ કરતા, સમાયેલ [`Err`] મૂલ્ય પરત કરે છે, તે મૂલ્યાંકન [`Ok`] નથી તે તપાસ્યા વિના.
    ///
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને [`Ok`] પર કingલ કરવો એ *[અસ્પષ્ટ વર્તન]* છે.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // અપ્રભાજિત વર્તન!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // સલામતી: સલામતી કરાર કlerલર દ્વારા સમર્થન આપવું આવશ્યક છે.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` ભાગની સામગ્રીની નકલ કરીને એક `Result<&T, E>` ને `Result<T, E>` પર નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` ભાગની સામગ્રીની નકલ કરીને એક `Result<&mut T, E>` ને `Result<T, E>` પર નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` ભાગની સામગ્રીને ક્લોન કરીને એક `Result<&T, E>` ને `Result<&T, E>` ને નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` ભાગની સામગ્રીને ક્લોન કરીને એક `Result<&mut T, E>` ને `Result<&mut T, E>` ને નકશા બનાવો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Ok`] મૂલ્ય પરત કરે છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત [`Err`] છે, જેમાં panic સંદેશ સાથે પસાર કરેલ સંદેશ અને [`Err`] ની સામગ્રી છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Ok`] મૂલ્ય પરત કરે છે.
    ///
    /// કારણ કે આ કાર્ય panic શકે છે, તેથી તેનો ઉપયોગ સામાન્ય રીતે નિરાશ કરવામાં આવે છે.
    /// તેના બદલે, પેટર્ન મેચિંગનો ઉપયોગ કરવાનું અને [`Err`] કેસને સ્પષ્ટ રીતે હેન્ડલ કરવાનું પસંદ કરો અથવા [`unwrap_or`], [`unwrap_or_else`] અથવા [`unwrap_or_default`] પર ક .લ કરો.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત [`Err`] છે, [`એરર] ની કિંમત દ્વારા પ્રદાન થયેલ panic સંદેશ સાથે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Err`] મૂલ્ય પરત કરે છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત [`Ok`] છે, જેમાં panic સંદેશ સાથે પસાર કરેલ સંદેશ અને [`Ok`] ની સામગ્રી છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` મૂલ્યનો ઉપયોગ કરીને સમાયેલ [`Err`] મૂલ્ય પરત કરે છે.
    ///
    /// # Panics
    ///
    /// Panics જો કિંમત [`Ok`] છે, [`Ok`] ની કિંમત દ્વારા પ્રદાન થયેલ કસ્ટમ panic સંદેશ સાથે.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// સમાયેલ [`Ok`] મૂલ્ય અથવા ડિફોલ્ટ આપે છે
    ///
    /// પછી `self` દલીલ લે છે, જો [`Ok`], સમાયેલ મૂલ્ય પરત કરે છે, અન્યથા જો [`Err`], તે પ્રકારનું ડિફ defaultલ્ટ મૂલ્ય આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// શબ્દમાળાને પૂર્ણાંકોમાં રૂપાંતરિત કરે છે, નબળી રીતે બનાવેલા શબ્દમાળાઓને 0 માં ફેરવે છે (પૂર્ણાંકો માટેનું મૂળભૂત મૂલ્ય).
    /// [`parse`] કોઈ અન્ય પ્રકારમાં શબ્દમાળા ફેરવે છે જે [`FromStr`] લાગુ કરે છે, ભૂલ પર [`Err`] પરત કરે છે.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// સમાયેલ [`Ok`] મૂલ્ય આપે છે, પરંતુ ઝેડપેનિક્સ 0 ઝેડ ક્યારેય નહીં.
    ///
    /// [`unwrap`] થી વિપરીત, આ પદ્ધતિ તેના માટે લાગુ કરવામાં આવતા પરિણામ પ્રકારો પર ક્યારેય ઝેડપેનિક0 ઝેડ માટે જાણીતી છે.
    /// તેથી, `unwrap` ને બદલે જાળવણી સલામતી તરીકે ઉપયોગ કરી શકાય છે જે સંકલન કરવામાં નિષ્ફળ જશે જો `Result` નો ભૂલ પ્રકાર પછીથી ભૂલમાં બદલાઇ જશે જે ખરેખર આવી શકે છે.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (અથવા `&Result<T, E>`) થી `Result<&<T as Deref>::Target, &E>` માં ફેરવે છે.
    ///
    /// [`Deref`](crate::ops::Deref) દ્વારા મૂળ [`Result`] ના [`Ok`] વેરિઅન્ટને Coersces અને નવા [`Result`] પરત આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (અથવા `&mut Result<T, E>`) થી `Result<&mut <T as DerefMut>::Target, &mut E>` માં ફેરવે છે.
    ///
    /// [`DerefMut`](crate::ops::DerefMut) દ્વારા મૂળ [`Result`] ના [`Ok`] વેરિઅન્ટને Coersces અને નવા [`Result`] પરત આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` ના `Result` ને `Result` ના `Option` માં બદલીને.
    ///
    /// `Ok(None)` `None` પર મેપ કરવામાં આવશે.
    /// `Ok(Some(_))` અને `Err(_)` ને `Some(Ok(_))` અને `Some(Err(_))` પર મેપ કરવામાં આવશે.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` થી `Result<T, E>` માં રૂપાંતરિત કરે છે
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// ફ્લેટ્ટનિંગ એક સમયે માળાના એક સ્તરને દૂર કરે છે:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// [`Ok`] મૂલ્ય જો `self` `Ok` છે, અને જો `self` `Err` છે તો [`Err`] મૂલ્ય આપે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, આ ફંક્શન `Result<T, T>` અથવા `Err` છે કે કેમ તે ધ્યાનમાં લીધા વિના, `Result<T, T>` નું મૂલ્ય (`T`) પાછું આપે છે.
    ///
    /// આ [`Atomic*::compare_exchange`], અથવા [`slice::binary_search`] જેવા API સાથે જોડાણમાં ઉપયોગી થઈ શકે છે, પરંતુ ફક્ત તે જ સંજોગોમાં જ્યાં તમને પરિણામ ન હોય કે પરિણામ `Ok` હતું કે નહીં.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// પદ્ધતિઓના કોડ કદને ઘટાડવા માટે આ એક અલગ કાર્ય છે
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait અમલીકરણો
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// સંભવિત સમાયેલી કિંમત કરતાં વધુ વપરાશકાર ઇટરેટરને આપે છે.
    ///
    /// જો પરિણામ [`Result::Ok`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// પરિણામ ઇટરેટર્સ
/////////////////////////////////////////////////////////////////////////////

/// એક [`Result`] ના [`Ok`] વેરિએન્ટના સંદર્ભમાં પુનરાવર્તક.
///
/// જો પરિણામ [`Ok`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
///
/// [`Result::iter`] દ્વારા બનાવેલ.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] ના [`Ok`] વેરિઅન્ટના પરિવર્તનીય સંદર્ભ પર એક પુનરાવર્તક.
///
/// [`Result::iter_mut`] દ્વારા બનાવેલ.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// એક [`Result`] ના [`Ok`] વેરિઅન્ટમાં મૂલ્ય પર પુનરાવર્તક.
///
/// જો પરિણામ [`Ok`] હોય તો પુનરાવર્તક એક મૂલ્ય પ્રાપ્ત કરે છે, નહીં તો કંઈ નહીં.
///
/// આ સ્ટ્રક્ટ [`into_iter`] X દ્વારા [`Result`] ([`IntoIterator`] trait દ્વારા પ્રદાન કરાયેલ) દ્વારા બનાવવામાં આવી છે.
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` માં દરેક તત્વ લે છે: જો તે `Err` હોય, તો આગળ કોઈ તત્વો લેવામાં આવતાં નથી, અને `Err` પરત આવે છે.
    /// જો કોઈ `Err` ન થાય, તો દરેક `Result` ના મૂલ્યોવાળા કન્ટેનર પરત આવે છે.
    ///
    /// અહીં એક ઉદાહરણ છે જે vector માં દરેક પૂર્ણાંકમાં વધારો કરે છે, ઓવરફ્લો માટે તપાસ કરે છે:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// અહીં બીજું એક ઉદાહરણ છે જે પૂર્ણાંકોની બીજી સૂચિમાંથી એકને બાદબાકી કરવાનો પ્રયાસ કરે છે, આ વખતે અંડરફ્લોની તપાસ કરે છે:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// પહેલાંના ઉદાહરણ પર અહીં વિવિધતા છે, તે બતાવે છે કે પ્રથમ `Err` પછી કોઈ વધુ તત્વો `iter` માંથી લેવામાં આવતાં નથી.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ત્રીજા તત્વને લીધે તે પાણીની અંદર વહી ગયો, તેથી આગળ કોઈ તત્વો લેવામાં આવ્યા નહીં, તેથી `shared` નું અંતિમ મૂલ્ય 16 નહીં, 6 (= `3 + 2 + 1`) છે.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): જ્યારે આ પ્રદર્શન બગ બંધ હોય ત્યારે તેને Iterator::scan સાથે બદલી શકાય છે.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}