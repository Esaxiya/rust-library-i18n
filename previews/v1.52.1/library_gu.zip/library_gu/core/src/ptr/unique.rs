use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// કાચા નોન-નલ `*mut T` ની આસપાસનો રેપર જે સૂચવે છે કે આ રેપરનો માલિક રિફરનો માલિક છે.
/// `Box<T>`, `Vec<T>`, `String` અને `HashMap<K, V>` જેવા એબ્સ્ટ્રેક્શન્સ બનાવવા માટે ઉપયોગી છે.
///
/// `*mut T` વિપરીત, `Unique<T>` "as if" વર્તે છે તે `T` નો દાખલો હતો.
/// જો `T` `Send`/`Sync` હોય તો તે `Send`/`Sync` લાગુ કરે છે.
/// તે `T` ના દાખલાની અપેક્ષા રાખી શકે તે પ્રકારની મજબૂત અલીઅઝિંગ ગેરંટીઝ પણ સૂચવે છે:
/// નિર્દેશકના વિવિધને તેના અનન્ય પાથની અનન્ય પાથ વિના સુધારવું જોઈએ નહીં.
///
/// જો તમે તમારા હેતુઓ માટે `Unique` નો ઉપયોગ કરવો યોગ્ય છે કે નહીં તે વિશે અસ્પષ્ટ છો, તો `NonNull` નો ઉપયોગ કરવાનું ધ્યાનમાં લો, જેમાં નબળા અર્થશાસ્ત્ર છે.
///
///
/// `*mut T` થી વિપરીત, નિર્દેશક હંમેશાં બિન-નલ હોવો આવશ્યક છે, પછી ભલે નિર્દેશક ક્યારેય અવમૂલ્યન ન કરે.
/// આ એટલા માટે છે કે enums આ પ્રતિબંધિત મૂલ્યનો ભેદભાવ તરીકે ઉપયોગ કરી શકે છે-`Option<Unique<T>>` એ `Unique<T>` જેટલું કદ ધરાવે છે.
/// તેમ છતાં, નિર્દેશક હજી પણ ઝૂલશે જો તેનો સંદર્ભ ન લેવામાં આવે તો.
///
/// `*mut T` થી વિપરીત, `Unique<T>` `T` કરતા વધુ સહિયારી છે.
/// આ હંમેશાં કોઈપણ પ્રકારનાં માટે યોગ્ય હોવું જોઈએ કે જે અનન્યની એલિયાઝિંગ આવશ્યકતાઓને સમર્થન આપે.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: આ માર્કરના ભિન્નતા માટે કોઈ પરિણામ નથી, પરંતુ તે જરૂરી છે
    // ડ્રોપ સમજવા માટે કે આપણી પાસે `T` તાર્કિક છે.
    //
    // વિગતો માટે, આ જુઓ:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` જો `T` `Send` હોય તો પોઇંટર્સ `Send` હોય છે કારણ કે તેઓ જે ડેટા સંદર્ભ કરે છે તે એકીકૃત નથી.
/// નોંધ કરો કે આ અલીસીંગ આક્રમણક પ્રકાર સિસ્ટમ દ્વારા અનસેન્સ્યુઅર છે;`Unique` નો ઉપયોગ કરીને અમૂર્તતાએ તેને લાગુ કરવું આવશ્યક છે.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` જો `T` `Sync` હોય તો પોઇંટર્સ `Sync` હોય છે કારણ કે તેઓ જે ડેટા સંદર્ભ કરે છે તે એકીકૃત નથી.
/// નોંધ કરો કે આ અલીસીંગ આક્રમણક પ્રકાર સિસ્ટમ દ્વારા અનસેન્સ્યુઅર છે;`Unique` નો ઉપયોગ કરીને અમૂર્તતાએ તેને લાગુ કરવું આવશ્યક છે.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// નવું `Unique` બનાવે છે જે ઝૂલતું હોય છે, પરંતુ સારી રીતે ગોઠવાયેલ છે.
    ///
    /// આ પ્રકારો પ્રારંભ કરવા માટે ઉપયોગી છે કે જે આળસુધી ફાળવે છે, જેમ કે `Vec::new` કરે છે.
    ///
    /// નોંધ લો કે નિર્દેશક મૂલ્ય સંભવિત `T` માં માન્ય પોઇન્ટરનું પ્રતિનિધિત્વ કરી શકે છે, જેનો અર્થ છે કે આનો ઉપયોગ "not yet initialized" સેન્ટિનેલ મૂલ્ય તરીકે થવો જોઈએ નહીં.
    /// પ્રકારો કે જે આળસુધીથી ફાળવે છે તે કેટલાક અન્ય માધ્યમથી પ્રારંભિકરણને ટ્ર trackક કરવું જોઈએ.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // સલામતી: mem::align_of() માન્ય, નોન-નલ પોઇન્ટર આપે છે.આ
        // new_unchecked() ને ક callલ કરવાની શરતોનો આ રીતે આદર કરવામાં આવે છે.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// એક નવું `Unique` બનાવે છે.
    ///
    /// # Safety
    ///
    /// `ptr` બિન-નલ હોવા જ જોઈએ.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `ptr` નોન-નલ છે.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// જો `ptr` નોન-નલ હોય તો નવું `Unique` બનાવે છે.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // સલામતી: નિર્દેશકની તપાસ થઈ ગઈ છે અને તે નલ નથી.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// અંતર્ગત `*mut` પોઇન્ટર પ્રાપ્ત કરે છે.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// સામગ્રીનો સંદર્ભ આપે છે.
    ///
    /// પરિણામી જીવનકાળ સ્વયં માટે બંધાયેલું છે તેથી આ "as if" વર્તે છે તે ખરેખર T નો દાખલો હતો જે ઉધાર મેળવવામાં આવે છે.
    /// જો લાંબી (unbound) જીવનકાળની આવશ્યકતા હોય, તો `&*my_ptr.as_ptr()` નો ઉપયોગ કરો.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // સંદર્ભ માટે જરૂરીયાતો.
        unsafe { &*self.as_ptr() }
    }

    /// પરિવર્તનશીલ સામગ્રીનો સંદર્ભ આપે છે.
    ///
    /// પરિણામી જીવનકાળ સ્વયં માટે બંધાયેલું છે તેથી આ "as if" વર્તે છે તે ખરેખર T નો દાખલો હતો જે ઉધાર મેળવવામાં આવે છે.
    /// જો લાંબી (unbound) જીવનકાળની આવશ્યકતા હોય, તો `&mut *my_ptr.as_ptr()` નો ઉપયોગ કરો.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // પરિવર્તનશીલ સંદર્ભ માટેની આવશ્યકતાઓ.
        unsafe { &mut *self.as_ptr() }
    }

    /// બીજા પ્રકારનાં નિર્દેશકને કાસ્ટ્સ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // સલામતી: Unique::new_unchecked() એક નવી અનન્ય અને આવશ્યકતાઓ બનાવે છે
        // નલ ન થવા માટે આપેલ પોઇન્ટર.
        // આપણે નિર્દેશક તરીકે સ્વયં પસાર કરી રહ્યાં હોવાથી, તે શૂન્ય ન હોઈ શકે.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // સલામતી: પરિવર્તનશીલ સંદર્ભ સંદર્ભ ન હોઈ શકે
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}