use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` પરંતુ બિન-શૂન્ય અને સહકારી.
///
/// કાચા પોઇન્ટરનો ઉપયોગ કરીને ડેટા સ્ટ્રક્ચર્સ બનાવતી વખતે આ ઉપયોગમાં લેવાતી ઘણી વાર સાચી બાબત છે, પરંતુ વધારાની મિલકતોને કારણે તેનો ઉપયોગ આખરે વધુ જોખમી છે.જો તમને ખાતરી ન હોય કે તમારે `NonNull<T>` નો ઉપયોગ કરવો જોઈએ, તો ફક્ત `*mut T` નો ઉપયોગ કરો!
///
/// `*mut T` વિપરીત, નિર્દેશક હંમેશાં બિન-નલ હોવો આવશ્યક છે, પછી ભલે નિર્દેશક ક્યારેય અવમૂલ્યન ન કરે.આ એટલા માટે છે કે enums આ પ્રતિબંધિત મૂલ્યનો ભેદભાવ તરીકે ઉપયોગ કરી શકે છે-`Option<NonNull<T>>` એ `* mut T` જેટલું કદ ધરાવે છે.
/// તેમ છતાં, નિર્દેશક હજી પણ ઝૂલશે જો તેનો સંદર્ભ ન લેવામાં આવે તો.
///
/// `*mut T` થી વિપરીત, `NonNull<T>` એ `T` કરતા વધુ સુવાચ્ય બનવાનું પસંદ કર્યું.આ કોવારિએન્ટ પ્રકારોનું નિર્માણ કરતી વખતે `NonNull<T>` નો ઉપયોગ કરવાનું શક્ય બનાવે છે, પરંતુ જો અવાસ્તવિકતાના જોખમને પરિણામે જો આવા પ્રકારનો ઉપયોગ કરવામાં આવે કે જે ખરેખર સુમેળમાં ન હોવો જોઈએ.
/// (વિરુદ્ધ પસંદગી `*mut T` માટે બનાવવામાં આવી હતી, તેમ છતાં તકનીકી રૂપે અનસoundન્ડનેસ ફક્ત અસુરક્ષિત કાર્યોને બોલાવવાથી થઈ શકે છે.)
///
/// `Box`, `Rc`, `Arc`, `Vec` અને `LinkedList` જેવા મોટાભાગના સલામત અમૂર્ત માટે કોવરિઆન્સ યોગ્ય છે.આ કેસ છે કારણ કે તેઓ એક સાર્વજનિક API પ્રદાન કરે છે જે ઝેડ રસ્ટ0 ઝેડના સામાન્ય વહેંચાયેલ એક્સઓઆર પરિવર્તનશીલ નિયમોનું પાલન કરે છે.
///
/// જો તમારો પ્રકાર સુરક્ષિત રીતે સહકારી ન હોઈ શકે, તો તમારે ખાતરી કરવી જ જોઇએ કે તેમાં કોઈ પણ પ્રકારનું અતિક્રમણ આપવા માટે કેટલાક વધારાના ક્ષેત્ર શામેલ છે.ઘણીવાર આ ક્ષેત્ર `PhantomData<Cell<T>>` અથવા `PhantomData<&'a mut T>` જેવા [`PhantomData`] પ્રકારનું હશે.
///
/// નોંધ લો કે `NonNull<T>` પાસે `&T` માટે `From` દાખલા છે.જો કે, આ એ હકીકતને બદલતું નથી કે એક (શેર કરેલ સંદર્ભમાંથી) દ્વારા પરિવર્તિત કરવું એ અસ્પષ્ટ વર્તણૂક છે જ્યાં સુધી પરિવર્તન [`UnsafeCell<T>`] ની અંદર ન થાય.સમાન શેર કરેલ સંદર્ભમાંથી પરિવર્તનશીલ સંદર્ભ બનાવવા માટે જાય છે.
///
/// આ `From` દાખલાને `UnsafeCell<T>` વિના ઉપયોગ કરતી વખતે, `as_mut` ને ક્યારેય નહીં બોલાવવાની ખાતરી કરવાની તમારી જવાબદારી છે, અને `as_ptr` ક્યારેય પરિવર્તન માટે ઉપયોગમાં લેવાતા નથી.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` પોઇંટર્સ `Send` નથી કારણ કે તેઓ જે ડેટા સંદર્ભ કરે છે તે ઉપનામ હોઈ શકે છે.
// એનબી, આ પ્રોમ્પ્લ બિનજરૂરી છે, પરંતુ વધુ સારા ભૂલ સંદેશાઓ પ્રદાન કરવા જોઈએ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` પોઇંટર્સ `Sync` નથી કારણ કે તેઓ જે ડેટા સંદર્ભ કરે છે તે ઉપનામ હોઈ શકે છે.
// એનબી, આ પ્રોમ્પ્લ બિનજરૂરી છે, પરંતુ વધુ સારા ભૂલ સંદેશાઓ પ્રદાન કરવા જોઈએ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// નવું `NonNull` બનાવે છે જે ઝૂલતું હોય છે, પરંતુ સારી રીતે ગોઠવાયેલ છે.
    ///
    /// આ પ્રકારો પ્રારંભ કરવા માટે ઉપયોગી છે કે જે આળસુધી ફાળવે છે, જેમ કે `Vec::new` કરે છે.
    ///
    /// નોંધ લો કે નિર્દેશક મૂલ્ય સંભવિત `T` માં માન્ય પોઇન્ટરનું પ્રતિનિધિત્વ કરી શકે છે, જેનો અર્થ છે કે આનો ઉપયોગ "not yet initialized" સેન્ટિનેલ મૂલ્ય તરીકે થવો જોઈએ નહીં.
    /// પ્રકારો કે જે આળસુધીથી ફાળવે છે તે કેટલાક અન્ય માધ્યમથી પ્રારંભિકરણને ટ્ર trackક કરવું જોઈએ.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // સલામતી: mem::align_of() નોન-શૂન્ય ઉપયોગિતા આપે છે જે પછી કાસ્ટ થાય છે
        // એક * મ્યુટ ટી.
        // તેથી, `ptr` નલ નથી અને new_unchecked() પર ક callingલ કરવાની શરતોનો આદર કરવામાં આવે છે.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// મૂલ્યના શેર કરેલા સંદર્ભો આપે છે.[`as_ref`] થી વિપરીત, આની જરૂરિયાત હોતી નથી કે મૂલ્ય શરૂ કરવું જોઈએ.
    ///
    /// પરિવર્તનીય સમકક્ષ માટે [`as_uninit_mut`] જુઓ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * પોઇન્ટર યોગ્ય રીતે ગોઠવાયેલ હોવા જોઈએ.
    ///
    /// * તે [the module documentation] માં વ્યાખ્યાયિત અર્થમાં "dereferencable" હોવું આવશ્યક છે.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક નિર્દેશ કરે છે તે મેમરી પરિવર્તિત થવી જોઈએ નહીં (`UnsafeCell` ની અંદર સિવાય).
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // સંદર્ભ માટે જરૂરીયાતો.
        unsafe { &*self.cast().as_ptr() }
    }

    /// મૂલ્યનો અનોખો સંદર્ભ આપે છે.[`as_mut`] થી વિપરીત, આની જરૂરિયાત હોતી નથી કે મૂલ્ય શરૂ કરવું જોઈએ.
    ///
    /// શેર કરેલા પ્રતિરૂપ માટે, [`as_uninit_ref`] જુઓ.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * પોઇન્ટર યોગ્ય રીતે ગોઠવાયેલ હોવા જોઈએ.
    ///
    /// * તે [the module documentation] માં વ્યાખ્યાયિત અર્થમાં "dereferencable" હોવું આવશ્યક છે.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક જે નિર્દેશ કરે છે તે મેમરી કોઈપણ અન્ય પોઇન્ટર દ્વારા (ક્સેસ (વાંચવા અથવા લખેલી) હોવી જોઈએ નહીં.
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // સંદર્ભ માટે જરૂરીયાતો.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// એક નવું `NonNull` બનાવે છે.
    ///
    /// # Safety
    ///
    /// `ptr` બિન-નલ હોવા જ જોઈએ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `ptr` નોન-નલ છે.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// જો `ptr` નોન-નલ હોય તો નવું `NonNull` બનાવે છે.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // સલામતી: નિર્દેશક પહેલેથી જ ચકાસાયેલ છે અને તે નલ નથી
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] જેટલું જ વિધેય કરે છે, સિવાય કે `NonNull` પોઇન્ટર પાછું આવે છે, કાચા `*const` પોઇન્ટરના વિરુદ્ધ છે.
    ///
    ///
    /// વધુ વિગતો માટે [`std::ptr::from_raw_parts`] ના દસ્તાવેજીકરણ જુઓ.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // સલામતી: `ptr::from::raw_parts_mut` નું પરિણામ બિન-શૂન્ય છે કારણ કે `data_address` છે.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// સરનામાં અને મેટાડેટા ઘટકો છે (જેમાં સંભવત wide વિશાળ) પોઇન્ટરને વિઘટિત કરો.
    ///
    /// નિર્દેશક પછીથી [`NonNull::from_raw_parts`] સાથે ફરીથી બનાવી શકાય છે.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// અંતર્ગત `*mut` પોઇન્ટર પ્રાપ્ત કરે છે.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// મૂલ્યનો એક વહેંચાયેલ સંદર્ભ આપે છે.જો મૂલ્ય અનઇંટિલાઇઝેશન થઈ શકે, તો તેના બદલે [`as_uninit_ref`] નો ઉપયોગ કરવો આવશ્યક છે.
    ///
    /// પરિવર્તનીય સમકક્ષ માટે [`as_mut`] જુઓ.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * પોઇન્ટર યોગ્ય રીતે ગોઠવાયેલ હોવા જોઈએ.
    ///
    /// * તે [the module documentation] માં વ્યાખ્યાયિત અર્થમાં "dereferencable" હોવું આવશ્યક છે.
    ///
    /// * નિર્દેશકએ `T` ના પ્રારંભિક દાખલા તરફ નિર્દેશ કરવો આવશ્યક છે.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક નિર્દેશ કરે છે તે મેમરી પરિવર્તિત થવી જોઈએ નહીં (`UnsafeCell` ની અંદર સિવાય).
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    /// (પ્રારંભ થવા વિશેનો ભાગ હજી સંપૂર્ણરૂપે નક્કી કરાયો નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી એકમાત્ર સલામત અભિગમ એ સુનિશ્ચિત કરવાનો છે કે તેઓ ખરેખર પ્રારંભિક છે.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // સંદર્ભ માટે જરૂરીયાતો.
        unsafe { &*self.as_ptr() }
    }

    /// મૂલ્યનો અનોખો સંદર્ભ આપે છે.જો મૂલ્ય અનઇંટિલાઇઝેશન થઈ શકે, તો તેના બદલે [`as_uninit_mut`] નો ઉપયોગ કરવો આવશ્યક છે.
    ///
    /// શેર કરેલા પ્રતિરૂપ માટે, [`as_ref`] જુઓ.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * પોઇન્ટર યોગ્ય રીતે ગોઠવાયેલ હોવા જોઈએ.
    ///
    /// * તે [the module documentation] માં વ્યાખ્યાયિત અર્થમાં "dereferencable" હોવું આવશ્યક છે.
    ///
    /// * નિર્દેશકએ `T` ના પ્રારંભિક દાખલા તરફ નિર્દેશ કરવો આવશ્યક છે.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક જે નિર્દેશ કરે છે તે મેમરી કોઈપણ અન્ય પોઇન્ટર દ્વારા (ક્સેસ (વાંચવા અથવા લખેલી) હોવી જોઈએ નહીં.
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    /// (પ્રારંભ થવા વિશેનો ભાગ હજી સંપૂર્ણરૂપે નક્કી કરાયો નથી, પરંતુ જ્યાં સુધી તે ન થાય ત્યાં સુધી એકમાત્ર સલામત અભિગમ એ સુનિશ્ચિત કરવાનો છે કે તેઓ ખરેખર પ્રારંભિક છે.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // સલામતી: કlerલરને ગેરેંટી આપવી આવશ્યક છે કે `self` બધાને મળે છે
        // પરિવર્તનશીલ સંદર્ભ માટેની આવશ્યકતાઓ.
        unsafe { &mut *self.as_ptr() }
    }

    /// બીજા પ્રકારનાં નિર્દેશકને કાસ્ટ્સ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // સલામતી: `self` એ `NonNull` પોઇન્ટર છે જે આવશ્યક ન nonન છે
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// પાતળા પોઇન્ટર અને લંબાઈથી ન aન-નલ કાચી સ્લાઇસ બનાવે છે.
    ///
    /// `len` દલીલ **તત્વો** ની સંખ્યા છે, બાઇટ્સની સંખ્યા નથી.
    ///
    /// આ કાર્ય સલામત છે, પરંતુ વળતર મૂલ્યને ડિફરન્સ કરવું અસુરક્ષિત છે.
    /// સ્લાઈસ સલામતી આવશ્યકતાઓ માટે [`slice::from_raw_parts`] ના દસ્તાવેજીકરણ જુઓ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // પ્રથમ તત્વ તરફના નિર્દેશકથી પ્રારંભ કરતી વખતે સ્લાઈસ પોઇન્ટર બનાવો
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (નોંધ લો કે આ ઉદાહરણ કૃત્રિમ રીતે આ પદ્ધતિનો ઉપયોગ દર્શાવે છે, પરંતુ sl સ્લાઈસ= NonNull::from(&x[..]);` would be a better way to write code like this.) દો
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // સલામતી: `data` એ `NonNull` પોઇન્ટર છે જે આવશ્યક ન nonન છે
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// નોન-નલ કાચી કટકાની લંબાઈ પરત કરે છે.
    ///
    /// પરત થયેલ મૂલ્ય **તત્વો** ની સંખ્યા છે, બાઇટ્સની સંખ્યા નથી.
    ///
    /// આ કાર્ય સલામત છે, જ્યારે ન-ન-નલ કાચી સ્લાઇસને સ્લાઇસનો સંદર્ભ આપી શકાતી નથી કારણ કે નિર્દેશક પાસે માન્ય સરનામું નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// સ્લાઈસના બફર પર નોન-નલ પોઇન્ટર પાછું આપે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // સલામતી: આપણે જાણીએ છીએ કે `self` નોન-નલ છે.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// સ્લાઈસના બફર પર કાચો પોઇન્ટર આપે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// સંભવત unin અનઇંટિઆલાઇઝ્ડ વેલ્યુઝની સ્લાઈસનો શેર કરેલો સંદર્ભ પાછો આપે છે.[`as_ref`] થી વિપરીત, આની જરૂરિયાત હોતી નથી કે મૂલ્ય શરૂ કરવું જોઈએ.
    ///
    /// પરિવર્તનીય સમકક્ષ માટે [`as_uninit_slice_mut`] જુઓ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` ઘણા બાઇટ્સ વાંચવા માટે નિર્દેશક [valid] હોવો આવશ્યક છે, અને તે યોગ્ય રીતે ગોઠવાયેલ હોવું જોઈએ.આનો અર્થ ખાસ કરીને:
    ///
    ///     * આ ટુકડાની આખી મેમરી રેંજ એક જ ફાળવેલ objectબ્જેક્ટમાં હોવી આવશ્યક છે!
    ///       સ્લાઇસેસ ક્યારેય બહુવિધ ફાળવેલ acrossબ્જેક્ટ્સ પર ફેલાતી નથી.
    ///
    ///     * શૂન્ય-લંબાઈના કાપી નાંખવા માટે પણ નિર્દેશકને ગોઠવવું આવશ્યક છે.
    ///     આનું એક કારણ એ છે કે ઇનોમ લેઆઉટ optimપ્ટિમાઇઝેશન, સંદર્ભોને (કોઈપણ લંબાઈના ટુકડા સહિત) પર આધાર રાખે છે અને તેને અન્ય ડેટાથી અલગ કરવા માટે બિન-નલ છે.
    ///
    ///     તમે એક નિર્દેશક મેળવી શકો છો જે [`NonNull::dangling()`] નો ઉપયોગ કરીને શૂન્ય-લંબાઈના કાપી નાંખવા માટે `data` તરીકે ઉપયોગી છે.
    ///
    /// * સ્લાઇસનો કુલ કદ `ptr.len() * mem::size_of::<T>()`, `isize::MAX` કરતા મોટો ન હોવો જોઈએ.
    ///   [`pointer::offset`] નું સલામતી દસ્તાવેજીકરણ જુઓ.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક નિર્દેશ કરે છે તે મેમરી પરિવર્તિત થવી જોઈએ નહીં (`UnsafeCell` ની અંદર સિવાય).
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    ///
    /// [`slice::from_raw_parts`] પણ જુઓ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // સલામતી: કlerલરને `as_uninit_slice` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// સંભવત unin અનઇંટિઆલાઇઝ્ડ વેલ્યુઝની સ્લાઈસનો અનોખો સંદર્ભ આપે છે.[`as_mut`] થી વિપરીત, આની જરૂરિયાત હોતી નથી કે મૂલ્ય શરૂ કરવું જોઈએ.
    ///
    /// શેર કરેલા પ્રતિરૂપ માટે, [`as_uninit_slice`] જુઓ.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિને ક callingલ કરતી વખતે, તમારે ખાતરી કરવાની રહેશે કે નીચેની બધી બાબતો સાચી છે:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` ઘણાં બાઇટ્સ વાંચવા અને લખવા માટે નિર્દેશક [valid] હોવો આવશ્યક છે, અને તે યોગ્ય રીતે ગોઠવાયેલ હોવું જોઈએ.આનો અર્થ ખાસ કરીને:
    ///
    ///     * આ ટુકડાની આખી મેમરી રેંજ એક જ ફાળવેલ objectબ્જેક્ટમાં હોવી આવશ્યક છે!
    ///       સ્લાઇસેસ ક્યારેય બહુવિધ ફાળવેલ acrossબ્જેક્ટ્સ પર ફેલાતી નથી.
    ///
    ///     * શૂન્ય-લંબાઈના કાપી નાંખવા માટે પણ નિર્દેશકને ગોઠવવું આવશ્યક છે.
    ///     આનું એક કારણ એ છે કે ઇનોમ લેઆઉટ optimપ્ટિમાઇઝેશન, સંદર્ભોને (કોઈપણ લંબાઈના ટુકડા સહિત) પર આધાર રાખે છે અને તેને અન્ય ડેટાથી અલગ કરવા માટે બિન-નલ છે.
    ///
    ///     તમે એક નિર્દેશક મેળવી શકો છો જે [`NonNull::dangling()`] નો ઉપયોગ કરીને શૂન્ય-લંબાઈના કાપી નાંખવા માટે `data` તરીકે ઉપયોગી છે.
    ///
    /// * સ્લાઇસનો કુલ કદ `ptr.len() * mem::size_of::<T>()`, `isize::MAX` કરતા મોટો ન હોવો જોઈએ.
    ///   [`pointer::offset`] નું સલામતી દસ્તાવેજીકરણ જુઓ.
    ///
    /// * તમારે ઝેડ ર્રસ્ટ0 ઝેડના અલીઝિંગ નિયમો લાગુ કરવા આવશ્યક છે, કારણ કે પરત થયેલ આજીવન `'a` મનસ્વી રીતે પસંદ થયેલ છે અને આવશ્યકપણે ડેટાના વાસ્તવિક જીવનકાળને પ્રતિબિંબિત કરતું નથી.
    ///   ખાસ કરીને, આ જીવનકાળના સમયગાળા માટે, નિર્દેશક જે નિર્દેશ કરે છે તે મેમરી કોઈપણ અન્ય પોઇન્ટર દ્વારા (ક્સેસ (વાંચવા અથવા લખેલી) હોવી જોઈએ નહીં.
    ///
    /// આ પદ્ધતિનો પરિણામ ન વપરાયેલ હોય તો પણ આ લાગુ પડે છે!
    ///
    /// [`slice::from_raw_parts_mut`] પણ જુઓ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // આ સલામત છે કારણ કે `memory` ઘણા બાઇટ્સ `memory.len()` માટે વાંચવા અને લખવા માટે માન્ય છે.
    /// // નોંધ કરો કે અહીં `memory.as_mut()` ને ક callingલ કરવાની મંજૂરી નથી કારણ કે સામગ્રીને અનિવેટિલાઇઝ કરી શકાય છે.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // સલામતી: કlerલરને `as_uninit_slice_mut` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// સીમાઓની ચકાસણી કર્યા વિના, કોઈ તત્વ અથવા સબલાઇસ પર કાચો નિર્દેશક પાછો આપે છે.
    ///
    /// આ પદ્ધતિને આઉટ-sફ-સીમાઇક્સ ઇન્ડેક્સ સાથે કingલ કરવો અથવા જ્યારે `self` ડીરેફરન્સીબલ ન હોય ત્યારે *[અસ્પષ્ટ વર્તન]* છે જો પરિણામી પોઇંટરનો ઉપયોગ ન કરવામાં આવે તો પણ.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // સલામતી: કlerલર ખાતરી કરે છે કે `self` ડેરેફરન્સીએબલ છે અને `index` ઇન-બાઉન્ડ્સ.
        // પરિણામ રૂપે, પરિણામી નિર્દેશક ન્યુલ હોઈ શકતો નથી.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // સલામતી: એક અનોખું નિર્દેશક નકામું હોઈ શકતું નથી, તેથી શરતો
        // new_unchecked() આદરણીય છે.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // સલામતી: પરિવર્તનશીલ સંદર્ભ સંદર્ભ ન હોઈ શકે.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // સલામતી: સંદર્ભ સંદર્ભ ન હોઈ શકે, માટે શરતો
        // new_unchecked() આદરણીય છે.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}