#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// કોઈપણ પોઇંટ-ટુ ટાઇપનો પોઇન્ટર મેટાડેટા પ્રકાર પ્રદાન કરે છે.
///
/// # પોઇન્ટર મેટાડેટા
///
/// ઝેડ રસ્ટ0 ઝેડમાં કાચો પોઇન્ટર પ્રકારો અને સંદર્ભ પ્રકારો બે ભાગોથી બનેલા તરીકે વિચારી શકાય છે:
/// ડેટા પોઇન્ટર જેમાં મૂલ્યનો મેમરી સરનામું અને કેટલાક મેટાડેટા શામેલ હોય છે.
///
/// સ્થિર-કદના પ્રકારો (જે `Sized` traits ને લાગુ કરે છે) તેમજ `extern` પ્રકારો માટે, પોઇંટર્સ "પાતળા" હોવાનું કહેવામાં આવે છે: મેટાડેટા શૂન્ય કદના હોય છે અને તેનો પ્રકાર `()` છે.
///
///
/// [dynamically-sized types][dst] તરફના નિર્દેશકોને "પહોળા" અથવા "ચરબી" હોવાનું કહેવામાં આવે છે, તેમાં બિન-શૂન્ય કદના મેટાડેટા છે:
///
/// * સ્ટ્રક્ટ્સ માટે જેનું છેલ્લું ક્ષેત્ર ડીએસટી છે, મેટાડેટા એ છેલ્લા ક્ષેત્ર માટે મેટાડેટા છે
/// * `str` પ્રકાર માટે, મેટાડેટા એ `usize` તરીકે બાઇટ્સની લંબાઈ છે
/// * `[T]` જેવા સ્લાઈસ પ્રકારો માટે, મેટાડેટા એ `usize` તરીકેની વસ્તુઓની લંબાઈ છે
/// * `dyn SomeTrait` જેવા trait Forબ્જેક્ટ્સ માટે, મેટાડેટા [`DynMetadata<Self>`][DynMetadata] છે (દા.ત. `DynMetadata<dyn SomeTrait>`)
///
/// ઝેડ 0 ફ્યુચર0 ઝેડમાં, ઝેડ રસ્ટ0 ઝેડ ભાષા નવા પ્રકારનાં પ્રકારો મેળવી શકે છે જેમાં વિવિધ પોઇન્ટર મેટાડેટા છે.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// આ trait નો મુદ્દો તેનો `Metadata` સંકળાયેલ પ્રકાર છે, જે ઉપર વર્ણવ્યા મુજબ `()` અથવા `usize` અથવા `DynMetadata<_>` છે.
/// તે દરેક પ્રકાર માટે આપમેળે લાગુ કરવામાં આવે છે.
/// અનુરૂપ બાઉન્ડ વગર પણ, તેને સામાન્ય સંદર્ભમાં લાગુ કરવામાં આવશે તેવું ધારી શકાય છે.
///
/// # Usage
///
/// કાચો પોઇંટરો તેમની [`to_raw_parts`] પદ્ધતિથી ડેટા સરનામાં અને મેટાડેટા ઘટકોમાં વિઘટિત કરી શકાય છે.
///
/// વૈકલ્પિક રીતે, એકલા મેટાડેટાને [`metadata`] ફંક્શનથી કાractedી શકાય છે.
/// એક સંદર્ભ [`metadata`] પર પસાર કરી શકાય છે અને ગર્ભિત રીતે જબરદસ્તીથી.
///
/// (possibly-wide) પોઇન્ટરને તેના સરનામાં અને મેટાડેટાથી [`from_raw_parts`] અથવા [`from_raw_parts_mut`] સાથે પાછા મૂકી શકાય છે.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` ના નિર્દેશકો અને સંદર્ભોમાં મેટાડેટા માટેનો પ્રકાર.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` માં trait bounds રાખો
    //
    // અહીંના લોકો સાથે સુમેળમાં `library/core/src/ptr/metadata.rs` માં:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// આ trait ઉપનામના અમલના પ્રકારોના નિર્દેશક "પાતળા" છે.
///
/// આમાં સ્ટેટિલી-`સાઇડ` પ્રકારો અને `extern` પ્રકારો શામેલ છે.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait ઉપનામો ભાષામાં સ્થિર થાય તે પહેલાં તેને સ્થિર કરશો નહીં?
pub trait Thin = Pointee<Metadata = ()>;

/// નિર્દેશકનો મેટાડેટા ઘટક કાractો.
///
/// `*mut T`, `&T`, અથવા `&mut T` પ્રકારનાં મૂલ્યો સીધા જ આ કાર્યમાં પસાર કરી શકાય છે કારણ કે તેઓ સ્પષ્ટપણે `* const T` પર દબાણ કરે છે.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // સલામત: * કોન્સ્ટ ટી થી `PtrRepr` સંઘમાંથી મૂલ્ય Accessક્સેસ કરવું સલામત છે
    // અને પી.ટી.આર.કોમ્પોનન્ટ્સ<T>સમાન મેમરી લેઆઉટ છે.
    // ફક્ત std જ આ બાંયધરી આપી શકે છે.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ડેટા સરનામાં અને મેટાડેટાથી એક (possibly-wide) કાચો નિર્દેશક બનાવે છે.
///
/// આ કાર્ય સલામત છે પરંતુ પરત થયેલ પોઇંટર આવશ્યકપણે સલામત નથી.
/// કાપી નાંખવા માટે, સલામતી આવશ્યકતાઓ માટે [`slice::from_raw_parts`] નું દસ્તાવેજીકરણ જુઓ.
/// ઝેડટ્રેટ0 ઝેડ objectsબ્જેક્ટ્સ માટે, મેટાડેટા એક નિર્દેશકથી સમાન અંતર્ગત ઉભા કરેલા પ્રકારનો જ હોવો જોઈએ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // સલામત: * કોન્સ્ટ ટી થી `PtrRepr` સંઘમાંથી મૂલ્ય Accessક્સેસ કરવું સલામત છે
    // અને પી.ટી.આર.કોમ્પોનન્ટ્સ<T>સમાન મેમરી લેઆઉટ છે.
    // ફક્ત std જ આ બાંયધરી આપી શકે છે.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] જેવી જ વિધેય કરે છે, સિવાય કે કાચા `*mut` પોઇન્ટર પાછું આવે છે, કાચા `* const` પોઇન્ટરના વિરુદ્ધ છે.
///
///
/// વધુ વિગતો માટે [`from_raw_parts`] ના દસ્તાવેજીકરણ જુઓ.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // સલામત: * કોન્સ્ટ ટી થી `PtrRepr` સંઘમાંથી મૂલ્ય Accessક્સેસ કરવું સલામત છે
    // અને પી.ટી.આર.કોમ્પોનન્ટ્સ<T>સમાન મેમરી લેઆઉટ છે.
    // ફક્ત std જ આ બાંયધરી આપી શકે છે.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` બાઉન્ડને ટાળવા માટે મેન્યુઅલ પ્રોમ્પ્ટ આવશ્યક છે.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` બાઉન્ડને ટાળવા માટે મેન્યુઅલ પ્રોમ્પ્ટ આવશ્યક છે.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait objectબ્જેક્ટ પ્રકારનો મેટાડેટા.
///
/// તે vtable (વર્ચુઅલ ક callલ ટેબલ) નો નિર્દેશક છે જે trait insideબ્જેક્ટની અંદર સંગ્રહિત કોંક્રિટ પ્રકારના હેરફેર માટે બધી આવશ્યક માહિતી રજૂ કરે છે.
/// વીટીબલ તેમાં નોંધપાત્ર છે:
///
/// * પ્રકારનું કદ
/// * પ્રકાર ગોઠવણી
/// * પ્રકારનાં `drop_in_place` પ્રોમ્પલનો નિર્દેશક (સાદા-જૂના-ડેટા માટે કોઈ વિકલ્પ હોઈ શકે છે)
/// * પ્રકારનાં trait ના અમલીકરણ માટેની બધી પદ્ધતિઓ તરફ નિર્દેશ
///
/// નોંધો કે પ્રથમ ત્રણ ખાસ છે કારણ કે તેઓ કોઈપણ ઝેડટ્રેટ 0 ઝેડ objectબ્જેક્ટને ફાળવવા, છોડવા અને અધોગતિ કરવા માટે જરૂરી છે.
///
/// આ સ્ટ્રક્ટનું નામ એવા પેરામીટર સાથે રાખવું શક્ય છે કે જે `dyn` trait objectબ્જેક્ટ નથી (ઉદાહરણ તરીકે `DynMetadata<u64>`) પરંતુ તે સ્ટ્રક્ટનું અર્થપૂર્ણ મૂલ્ય પ્રાપ્ત કરવું નહીં.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// બધા vtables નો સામાન્ય ઉપસર્ગ.તે trait પદ્ધતિઓ માટે ફંક્શન પોઇન્ટર દ્વારા અનુસરવામાં આવે છે.
///
/// `DynMetadata::size_of` વગેરેની ખાનગી અમલીકરણ વિગત.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// આ વtટેબલ સાથે સંકળાયેલા પ્રકારનું કદ પરત કરે છે.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// આ વtટેબલ સાથે સંકળાયેલ પ્રકારનું ગોઠવણી પરત કરે છે.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` તરીકે એક સાથે કદ અને સંરેખણ પરત કરે છે
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // સલામતી: કમ્પાઈલરે આ વtટેબલને કોંક્રિટ ઝેડ રસ્ટ0 ઝેડ પ્રકાર માટે બહાર કા .્યું જે
        // માન્ય લેઆઉટ હોવાનું માનવામાં આવે છે.`Layout::for_value` ની જેમ જ તર્ક.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` સીમાને ટાળવા માટે મેન્યુઅલ ઇમ્પ્લ્સ આવશ્યક છે.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}