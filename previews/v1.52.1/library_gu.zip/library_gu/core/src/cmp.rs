//! ઓર્ડર અને સરખામણી માટે કાર્યક્ષમતા.
//!
//! આ મોડ્યુલમાં મૂલ્યોની ingર્ડર અને તુલના કરવા માટેના વિવિધ સાધનો શામેલ છે.સારમાં:
//!
//! * [`Eq`] અને [`PartialEq`] એ ઝેડટ્રેટ્સ 0 ઝેડ છે જે તમને ક્રમશ values મૂલ્યો વચ્ચેની કુલ અને આંશિક સમાનતાને નિર્ધારિત કરવાની મંજૂરી આપે છે.
//! તેમને અમલમાં મૂકવું, `==` અને `!=` torsપરેટર્સને ઓવરલોડ કરે છે.
//! * [`Ord`] અને [`PartialOrd`] એ traits છે જે તમને ક્રમશ you મૂલ્યો વચ્ચેના કુલ અને આંશિક ક્રમમાં વ્યાખ્યાયિત કરવાની મંજૂરી આપે છે.
//!
//! તેમને અમલમાં મૂકવાથી `<`, `<=`, `>` અને `>=` torsપરેટર્સ ઓવરલોડ થાય છે.
//! * [`Ordering`] [`Ord`] અને [`PartialOrd`] ના મુખ્ય કાર્યો દ્વારા પરત થયેલ એક એનમ છે, અને ઓર્ડરનું વર્ણન કરે છે.
//! * [`Reverse`] એક સ્ટ્રક્ટ છે જે તમને સરળતાથી anર્ડરિંગને વિરુદ્ધ કરવાની મંજૂરી આપે છે.
//! * [`max`] અને [`min`] એ ફંક્શન્સ છે જે [`Ord`] ની રચના કરે છે અને તમને મહત્તમ અથવા ન્યૂનતમ બે મૂલ્યો શોધવાની મંજૂરી આપે છે.
//!
//! વધુ વિગતો માટે, સૂચિમાંની દરેક વસ્તુનું સંબંધિત દસ્તાવેજીકરણ જુઓ.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ની સમાનતા તુલના માટે Trait.
///
/// આ ઝેડ 0 ટ્રાઈટ0 ઝેડ એવા પ્રકારો માટે આંશિક સમાનતા માટે પરવાનગી આપે છે, જેનો સંપૂર્ણ સમકક્ષ સંબંધ નથી.
/// ઉદાહરણ તરીકે, ફ્લોટિંગ પોઇન્ટ નંબર્સ `NaN != NaN` માં, તેથી ફ્લોટિંગ પોઇન્ટ પ્રકારો `PartialEq` લાગુ કરે છે પરંતુ [`trait@Eq`] નહીં.
///
/// Malપચારિક રૂપે, સમાનતા હોવી આવશ્યક છે (બધા `a`, `b`, `A`, `B`, `C` પ્રકારનાં `c`):
///
/// - **સપ્રમાણ**: જો `A: PartialEq<B>` અને `B: PartialEq<A>`, તો પછી **`a==b=સૂચવે` b==a`**;અને
///
/// - **ટ્રાન્ઝિટિવ**: જો `A: PartialEq<B>` અને `B: PartialEq<C>` અને `A:
///   આંશિક<C>`, પછી **` a==b`અને `b == c` સૂચવે છે`a==સી`**.
///
/// નોંધ લો કે `B: PartialEq<A>` (symmetric) અને `A: PartialEq<C>` (transitive) ઇમ્પ્લ્સને અસ્તિત્વમાં કરવાની ફરજ પાડવામાં આવતી નથી, પરંતુ આ આવશ્યકતાઓ જ્યારે પણ અસ્તિત્વમાં હોય ત્યારે લાગુ પડે છે.
///
/// ## Derivable
///
/// આ trait નો ઉપયોગ `#[derive]` સાથે થઈ શકે છે.જ્યારે સ્ટ્રક્ટ્સ પર વ્યુત્પન્ન થાય છે, બધા ક્ષેત્રો સમાન હોય તો બે દાખલા સમાન હોય છે, અને જો કોઈપણ ક્ષેત્રો સમાન ન હોય તો બરાબર નથી.જ્યારે enums પર વ્યુત્પન્ન કરવામાં આવે છે, ત્યારે દરેક ચલ પોતાને સમાન હોય છે અને અન્ય ચલો સમાન નથી.
///
/// ## હું `PartialEq` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// `PartialEq` ફક્ત [`eq`] પદ્ધતિ અમલમાં મૂકવાની જરૂર છે;[`ne`] એ તેના સંદર્ભમાં ડિફ .લ્ટ રૂપે વ્યાખ્યાયિત થયેલ છે.[`ne`]*ની કોઈપણ જાતે અમલવારીએ* નિયમનો આદર કરવો જ જોઇએ કે [`eq`] એ [`ne`] નું સખત વ્યસ્ત છે;એટલે કે, `!(a == b)` જો અને માત્ર જો `a != b`.
///
/// `PartialEq`, [`PartialOrd`] અને [`Ord`]*ના અમલીકરણો* એકબીજા સાથે સંમત હોવા જોઈએ.ઝેડટ્રેટિટ્સ0 ઝેડમાંથી કેટલાકને મેળવીને અને અન્યને મેન્યુઅલી અમલમાં મૂકીને આકસ્મિક રીતે તેમને અસંમત બનાવવું સરળ છે.
///
/// ડોમેન માટે ઉદાહરણ અમલીકરણ જેમાં બે પુસ્તકો એક જ પુસ્તક માનવામાં આવે છે જો તેમના આઇએસબીએન મેળ ખાય તો પણ બંધારણો ભિન્ન હોય તો પણ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## હું બે અલગ અલગ પ્રકારોની તુલના કેવી રીતે કરી શકું?
///
/// તમે જે પ્રકાર સાથે તુલના કરી શકો છો તે `પાર્ટિએલ`ઇસીના પ્રકાર પરિમાણ દ્વારા નિયંત્રિત થાય છે.
/// ઉદાહરણ તરીકે, ચાલો આપણા પાછલા કોડને થોડું ઝટકો:
///
/// ```
/// // ઉદ્દેશી સાધન<BookFormat>==<BookFormat>તુલના
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // અમલ<Book>==<BookFormat>તુલના
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // અમલ<BookFormat>==<Book>તુલના
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ને `impl PartialEq<BookFormat> for Book` માં બદલીને, અમે `Bookformat`s ને`Book`s સાથે સરખાવીએ છીએ.
///
/// ઉપરોક્ત જેવું સરખામણી, જે સ્ટ્રક્ટના કેટલાક ક્ષેત્રોને અવગણે છે, તે જોખમી હોઈ શકે છે.તે સરળતાથી આંશિક સમકક્ષ સંબંધ માટેની આવશ્યકતાઓના અનિચ્છનીય ઉલ્લંઘન તરફ દોરી શકે છે.
/// ઉદાહરણ તરીકે, જો આપણે `BookFormat` માટે `PartialEq<Book>` નું ઉપરનું અમલીકરણ રાખ્યું અને `Book` માટે `PartialEq<Book>` નું અમલીકરણ ઉમેર્યું (ક્યાં તો `#[derive]` દ્વારા અથવા પહેલા ઉદાહરણથી મેન્યુઅલ અમલીકરણ દ્વારા) તો પરિણામ સંક્રમણનું ઉલ્લંઘન કરશે:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// આ પદ્ધતિ `self` અને `other` મૂલ્યો સમાન હોવા માટે પરીક્ષણ કરે છે, અને તેનો ઉપયોગ `==` દ્વારા થાય છે.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// આ પદ્ધતિ `!=` માટે પરીક્ષણ કરે છે.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ની સમાનતા તુલના માટે Trait.
///
/// આનો અર્થ એ કે, `a == b` અને `a != b` સખત versલટું હોવા ઉપરાંત, સમાનતા (બધા `a`, `b` અને `c` માટે) હોવી જોઈએ:
///
/// - reflexive: `a == a`;
/// - સપ્રમાણતા: `a == b` સૂચવે `b == a`;અને
/// - પરિવર્તનશીલ: `a == b` અને `b == c` સૂચવે `a == c`.
///
/// આ ગુણધર્મ કમ્પાઇલર દ્વારા ચકાસી શકાતી નથી, અને તેથી `Eq` સૂચવે છે [`PartialEq`], અને તેમાં કોઈ વધારાની પદ્ધતિઓ નથી.
///
/// ## Derivable
///
/// આ trait નો ઉપયોગ `#[derive]` સાથે થઈ શકે છે.
/// જ્યારે નિષ્કર્ષ લેવામાં આવે છે, કારણ કે `Eq` પાસે કોઈ વધારાની પદ્ધતિઓ નથી, તે ફક્ત કમ્પાઇલરને જાણ કરે છે કે આ કોઈ આંશિક સમકક્ષ સંબંધને બદલે સમકક્ષ સંબંધ છે.
///
/// નોંધ લો કે `derive` વ્યૂહરચનામાં બધા ફીલ્ડ્સ `Eq` હોય છે, જે હંમેશાં ઇચ્છિત હોતું નથી.
///
/// ## હું `Eq` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// જો તમે `derive` વ્યૂહરચનાનો ઉપયોગ કરી શકતા નથી, તો સ્પષ્ટ કરો કે તમારો પ્રકાર `Eq` લાગુ કરે છે, જેમાં કોઈ પદ્ધતિઓ નથી:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // આ પદ્ધતિનો ઉપયોગ ફક્ત#[ડેરિંગ] દ્વારા કરવામાં આવે છે કે દરેક પ્રકારનો ઘટક પોતે જ [[ડેરિવેટ] અમલમાં આવે છે, વર્તમાન ડ્રાઈવિંગ ઇન્ફ્રાસ્ટ્રક્ચર એટલે કે આ ઝેડટ્રેટ 0 ઝેડ પર કોઈ પદ્ધતિનો ઉપયોગ કર્યા વિના આ ઉદ્દેશ્ય કરવું લગભગ અશક્ય છે.
    //
    //
    // આ હાથ દ્વારા ક્યારેય અમલમાં મૂકવા જોઈએ નહીં.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: આ સ્ટ્રક્ટનો ઉપયોગ ફક્ત#[derive] દ્વારા
// ભારપૂર્વક જણાવો કે પ્રકારનો દરેક ઘટક Eq લાગુ કરે છે.
//
// આ સ્ટ્રક્ટ ક્યારેય વપરાશકર્તા કોડમાં દેખાશે નહીં.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// એક `Ordering` એ બે મૂલ્યો વચ્ચેની તુલનાનું પરિણામ છે.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// એક orderર્ડર જ્યાં તુલનાત્મક કિંમત બીજા કરતા ઓછી હોય.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// એક orderર્ડર જ્યાં તુલનાત્મક કિંમત બીજાની સમાન હોય.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// એક orderર્ડર જ્યાં તુલનાત્મક કિંમત બીજા કરતા વધારે હોય.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// જો ઓર્ડરિંગ `Equal` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// જો ઓર્ડરિંગ `Equal` વેરિઅન્ટ ન હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// જો ઓર્ડરિંગ `Less` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// જો ઓર્ડરિંગ `Greater` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// જો orderર્ડરિંગ ક્યાં તો `Less` અથવા `Equal` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// જો orderર્ડરિંગ ક્યાં તો `Greater` અથવા `Equal` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ને વિરુદ્ધ કરે છે.
    ///
    /// * `Less` `Greater` બને છે.
    /// * `Greater` `Less` બને છે.
    /// * `Equal` `Equal` બને છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વર્તન:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// આ પદ્ધતિનો ઉપયોગ સરખામણીને ઉલટાવી શકાય છે:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // એરેને મોટાથી નાનામાં સ sortર્ટ કરો.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// સાંકળો બે ક્રમમાં.
    ///
    /// જ્યારે તે `Equal` ન હોય ત્યારે `self` આપે છે.અન્યથા `other` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// આપેલ ફંક્શન સાથે orderર્ડરિંગને સાંકળો.
    ///
    /// જ્યારે તે `Equal` ન હોય ત્યારે `self` આપે છે.
    /// અન્યથા `f` ને ક callsલ કરે છે અને પરિણામ આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// વિપરીત ઓર્ડર માટે સહાયક સ્ટ્રક્ટ.
///
/// આ સ્ટ્રક્ટ એ [`Vec::sort_by_key`] જેવા વિધેયોમાં ઉપયોગમાં લેવા માટે સહાયક છે અને તેનો ઉપયોગ કીના ભાગને વિરુદ્ધ કરવા માટે થઈ શકે છે.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) બનાવે છે તેવા પ્રકારો માટે Trait.
///
/// ઓર્ડર એ કુલ ઓર્ડર છે જો તે (બધા `a`, `b` અને `c` માટે):
///
/// - કુલ અને અસમપ્રમાણ: `a < b`, `a == b` અથવા `a > b` માંથી એક બરાબર સાચું છે;અને
/// - ક્ષણિક, `a < b` અને `b < c` સૂચવે `a < c`.`==` અને `>` બંને માટે સમાન હોવું આવશ્યક છે.
///
/// ## Derivable
///
/// આ trait નો ઉપયોગ `#[derive]` સાથે થઈ શકે છે.
/// જ્યારે સ્ટ્રક્ટ્સ પર તારવવામાં આવે છે, ત્યારે તે સ્ટ્ર'sક્ટના સભ્યોના ઉપરથી નીચેની ઘોષણાના હુકમના આધારે [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ઓર્ડર બનાવશે.
///
/// જ્યારે enums પર તારવવામાં આવે છે, ત્યારે ચલો તેમના ઉપરથી નીચેના ભેદભાવયુક્ત હુકમ દ્વારા ઓર્ડર કરવામાં આવે છે.
///
/// ## લેક્સિકોગ્રાફિકલ સરખામણી
///
/// લેક્સિકોગ્રાફિકલ સરખામણી એ નીચેના ગુણધર્મો સાથેનું એક ઓપરેશન છે:
///  - તત્વ દ્વારા બે અનુક્રમો તુલના કરવામાં આવે છે.
///  - પ્રથમ મેળ ન ખાતા તત્વ વ્યાખ્યાયિત કરે છે કે કયા ક્રમ બીજાની તુલનામાં લેક્સિકોગ્રાફિકલી ઓછા અથવા મોટા છે.
///  - જો એક સિક્વન્સ બીજાનો ઉપસર્ગ છે, તો ટૂંકું અનુક્રમ બીજાની તુલનામાં શબ્દશાસ્ત્રથી ઓછું છે.
///  - જો બે સિક્વન્સમાં સમાન તત્વો હોય અને તે સમાન લંબાઈના હોય, તો પછી ક્રમ શબ્દકોષ સમાન હોય છે.
///  - ખાલી ક્રમ કોઈ પણ ખાલી ન કરતા ક્રમ કરતાં લેક્સિકોગ્રાફિકલી ઓછી છે.
///  - બે ખાલી સિક્વન્સ લેક્સિકોગ્રાફિકલી સમાન છે.
///
/// ## હું `Ord` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// `Ord` આવશ્યક છે કે પ્રકાર પણ [`PartialOrd`] અને [`Eq`] (જેને [`PartialEq`] ની જરૂર હોય).
///
/// પછી તમારે [`cmp`] માટે અમલીકરણને વ્યાખ્યાયિત કરવું આવશ્યક છે.તમને તમારા પ્રકારનાં ક્ષેત્રો પર [`cmp`] નો ઉપયોગ કરવો ઉપયોગી લાગે છે.
///
/// [`PartialEq`], [`PartialOrd`] અને `Ord`*ના અમલીકરણો* એકબીજા સાથે સંમત હોવા જોઈએ.
/// તે છે, `a.cmp(b) == Ordering::Equal` જો અને માત્ર જો `a == b` અને `Some(a.cmp(b)) == a.partial_cmp(b)` બધા `a` અને `b` માટે.
/// ઝેડટ્રેટિટ્સ0 ઝેડમાંથી કેટલાકને મેળવીને અને અન્યને મેન્યુઅલી અમલમાં મૂકીને આકસ્મિક રીતે તેમને અસંમત બનાવવું સરળ છે.
///
/// અહીં એક ઉદાહરણ છે જ્યાં તમે લોકોને માત્ર heightંચાઇથી સ sortર્ટ કરવા માંગો છો, `id` અને `name` ને અવગણીને:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// આ પદ્ધતિ `self` અને `other` વચ્ચે [`Ordering`] આપે છે.
    ///
    /// સંમેલન દ્વારા, `self.cmp(&other)` જો સાચું હોય તો `self <operator> other` અભિવ્યક્તિ સાથે મેળ ખાતા ઓર્ડર આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// મહત્તમ બે મૂલ્યોની તુલના અને વળતર.
    ///
    /// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો બીજી દલીલ આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ન્યૂનતમ બે મૂલ્યોની તુલના અને વળતર આપે છે.
    ///
    /// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો પ્રથમ દલીલ આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// મૂલ્યને ચોક્કસ અંતરાલમાં પ્રતિબંધિત કરો.
    ///
    /// જો `self`, `max` કરતા વધારે હોય તો `max` અને જો `self`, `min` કરતા ઓછું હોય તો `max` આપે છે.
    /// અન્યથા આ `self` આપે છે.
    ///
    /// # Panics
    ///
    /// ઝેડ 0 પેનિક્સ 0 ઝેડ જો `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// સ valuesર્ટ-forર્ડર માટે તુલના કરી શકાય તેવા મૂલ્યો માટે Trait.
///
/// બધા `a`, `b` અને `c` માટે, સરખામણી સંતોષવી આવશ્યક છે:
///
/// - અસમપ્રમાણતા: જો `a < b` પછી `!(a > b)`, તેમજ `a > b` સૂચિત `!(a < b)`;અને
/// - પરિવર્તનશીલતા: `a < b` અને `b < c` સૂચવે `a < c`.`==` અને `>` બંને માટે સમાન હોવું આવશ્યક છે.
///
/// નોંધો કે આ આવશ્યકતાઓનો અર્થ એ છે કે ઝેડટ્રેટ0 ઝેડ પોતે જ સપ્રમાણ અને ટ્રાંઝિટિવલી રીતે અમલમાં મુકવું આવશ્યક છે: જો `T: PartialOrd<U>` અને `U: PartialOrd<V>` પછી `U: PartialOrd<T>` અને `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// આ trait નો ઉપયોગ `#[derive]` સાથે થઈ શકે છે.જ્યારે સ્ટ્રક્ટ્સ પર નિષ્કર્ષ કા ,વામાં આવે છે, ત્યારે તે સ્ટ્ર'sક્ટના સભ્યોની ઉપરથી નીચેની ઘોષણાના હુકમના આધારે લેક્સિકોગ્રાફિક orderર્ડરિંગ ઉત્પન્ન કરશે.
/// જ્યારે enums પર તારવવામાં આવે છે, ત્યારે ચલો તેમના ઉપરથી નીચેના ભેદભાવયુક્ત હુકમ દ્વારા ઓર્ડર કરવામાં આવે છે.
///
/// ## હું `PartialOrd` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// `PartialOrd` ફક્ત [`partial_cmp`] પદ્ધતિના અમલીકરણની જરૂર છે, ડિફ defaultલ્ટ અમલીકરણોથી પેદા થતી અન્ય સાથે.
///
/// જો કે સંપૂર્ણ ઓર્ડર ન હોય તેવા પ્રકારો માટે અન્યને અલગથી અમલમાં મૂકવું શક્ય છે.
/// ઉદાહરણ તરીકે, ફ્લોટિંગ પોઇન્ટ નંબર્સ માટે, `NaN < 0 == false` અને `NaN >= 0 == false` (સીએફ.
/// આઇઇઇઇ 754-2008 વિભાગ 5.11).
///
/// `PartialOrd` તમારે તમારા પ્રકારનો [`PartialEq`] હોવો જરૂરી છે.
///
/// [`PartialEq`], `PartialOrd` અને [`Ord`]*ના અમલીકરણો* એકબીજા સાથે સંમત હોવા જોઈએ.
/// ઝેડટ્રેટિટ્સ0 ઝેડમાંથી કેટલાકને મેળવીને અને અન્યને મેન્યુઅલી અમલમાં મૂકીને આકસ્મિક રીતે તેમને અસંમત બનાવવું સરળ છે.
///
/// જો તમારો પ્રકાર [`Ord`] છે, તો તમે [`cmp`] નો ઉપયોગ કરીને [`partial_cmp`] લાગુ કરી શકો છો:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// તમને તમારા પ્રકારનાં ક્ષેત્રોમાં [`partial_cmp`] નો ઉપયોગ કરવો ઉપયોગી પણ લાગે છે.
/// અહીં `Person` પ્રકારોનું ઉદાહરણ છે કે જેમની પાસે ફ્લોટિંગ-પોઇન્ટ `height` ક્ષેત્ર છે જે એકમાત્ર ક્ષેત્ર છે જે સingર્ટિંગ માટે ઉપયોગમાં લેવાય છે:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// આ પદ્ધતિ `self` અને `other` કિંમતો વચ્ચેનો orderર્ડર આપે છે જો તે અસ્તિત્વમાં હોય.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// જ્યારે તુલના અશક્ય છે:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// આ પદ્ધતિ (`self` અને `other` માટે) કરતા ઓછી પરીક્ષણ કરે છે અને `<` operatorપરેટર દ્વારા તેનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// આ પદ્ધતિ (`self` અને `other` માટે) કરતા ઓછી અથવા બરાબર પરીક્ષણ કરે છે અને `<=` operatorપરેટર દ્વારા તેનો ઉપયોગ થાય છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// આ પદ્ધતિ (`self` અને `other` માટે) થી વધુની ચકાસણી કરે છે અને `>` operatorપરેટર દ્વારા તેનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// આ પદ્ધતિ (`self` અને `other` માટે) કરતા વધારે અથવા બરાબર પરીક્ષણ કરે છે અને `>=` operatorપરેટર દ્વારા તેનો ઉપયોગ થાય છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ન્યૂનતમ બે મૂલ્યોની તુલના અને વળતર આપે છે.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો પ્રથમ દલીલ આપે છે.
///
/// આંતરિક રીતે [`Ord::min`] માટે ઉપનામનો ઉપયોગ કરે છે.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ઉલ્લેખિત સરખામણી વિધેયના સંદર્ભમાં ઓછામાં ઓછા બે મૂલ્યો પરત કરે છે.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો પ્રથમ દલીલ આપે છે.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// તે ઘટક પરત કરે છે જે નિર્ધારિત કાર્યમાંથી ન્યૂનતમ મૂલ્ય આપે છે.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો પ્રથમ દલીલ આપે છે.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// મહત્તમ બે મૂલ્યોની તુલના અને વળતર.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો બીજી દલીલ આપે છે.
///
/// આંતરિક રીતે [`Ord::max`] માટે ઉપનામનો ઉપયોગ કરે છે.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// ઉલ્લેખિત સરખામણી વિધેયના સંદર્ભમાં મહત્તમ બે મૂલ્યો આપે છે.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો બીજી દલીલ આપે છે.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// તે ઘટક પરત કરે છે જે ઉલ્લેખિત કાર્યથી મહત્તમ મૂલ્ય આપે છે.
///
/// જો સરખામણી તેમને સમાન હોવી નક્કી કરે તો બીજી દલીલ આપે છે.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// પ્રાચીન પ્રકારો માટે પાર્શિયલઇક, એક્યુ, પાર્શિયલ ઓર્ડ અને ઓર્ડરનો અમલ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // વધુ ઉત્તમ એસેમ્બલી ઉત્પન્ન કરવા માટે અહીંનો orderર્ડર મહત્વપૂર્ણ છે.
                    // વધુ માહિતી માટે <https://github.com/rust-lang/rust/issues/63758> જુઓ.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // આઇ 8 ને કાસ્ટ કરવા અને ઓર્ડરિંગમાં તફાવતને રૂપાંતરિત કરવાથી વધુ ઉત્તમ એસેમ્બલી ઉત્પન્ન થાય છે.
            //
            // વધુ માહિતી માટે <https://github.com/rust-lang/rust/issues/66780> જુઓ.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // સલામત: ઝેડબૂલ 0 ઝેડ જેમ કે i8 0 અથવા 1 આપે છે, તેથી તફાવત બીજું કશું હોઈ શકે નહીં
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &પોઇંટર્સ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}