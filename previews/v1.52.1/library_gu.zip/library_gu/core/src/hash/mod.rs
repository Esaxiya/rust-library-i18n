//! જેનરિક હેશીંગ સપોર્ટ.
//!
//! આ મોડ્યુલ મૂલ્યના [hash] ની ગણતરી કરવાની સામાન્ય રીત પ્રદાન કરે છે.
//! હેશેસનો ઉપયોગ સામાન્ય રીતે [`HashMap`] અને [`HashSet`] સાથે થાય છે.
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! પ્રકારને હેશેબલ બનાવવાની સરળ રીત એ `#[derive(Hash)]` નો ઉપયોગ કરવો છે:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! જો તમને મૂલ્ય કેવી રીતે હેશ કરવામાં આવે છે તેના પર વધુ નિયંત્રણની જરૂર હોય, તો તમારે [`Hash`] trait અમલમાં મૂકવાની જરૂર છે:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// એક હેશેબલ પ્રકાર.
///
/// `Hash` અમલમાં મૂકતા પ્રકારો, [`Hasher`] ના દાખલા સાથે [`હેશ] સંપાદિત કરવામાં સક્ષમ છે.
///
/// ## `Hash` અમલીકરણ
///
/// જો બધા ક્ષેત્રો `Hash` લાગુ કરે છે તો તમે `#[derive(Hash)]` સાથે `Hash` મેળવી શકો છો.
/// પરિણામી હેશ દરેક ક્ષેત્ર પર [`hash`] ક callingલ કરવાથી મૂલ્યોનું જોડાણ હશે.
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// જો તમને મૂલ્ય કેવી રીતે હેડ કરવામાં આવે છે તેના પર વધુ નિયંત્રણની જરૂર હોય, તો તમે અલબત્ત જાતે જ `Hash` trait ને અમલમાં મૂકી શકો છો:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` અને `Eq`
///
/// `Hash` અને [`Eq`] બંનેને અમલમાં મૂકતી વખતે, તે મહત્વપૂર્ણ છે કે નીચેની મિલકત ધરાવે છે:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// બીજા શબ્દોમાં કહીએ તો, જો બે કીઓ સમાન હોય, તો તેમની હેશ પણ સમાન હોવી જોઈએ.
/// [`HashMap`] અને [`HashSet`] બંને આ વર્તન પર આધાર રાખે છે.
///
/// આભારી છે કે, `#[derive(PartialEq, Eq, Hash)]` સાથે [`Eq`] અને `Hash` બંને લેતી વખતે તમારે આ મિલકતને જાળવી રાખવાની ચિંતા કરવાની જરૂર રહેશે નહીં.
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// આપેલ [`Hasher`] માં આ મૂલ્ય ફીડ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// આપેલ [`Hasher`] માં આ પ્રકારની સ્લાઈસ ફીડ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` વગર ઝેડપ્રીઅલ 0 ઝેડથી મેક્રો `Hash` ના ફરીથી નિકાસ માટે મોડ્યુલને અલગ કરો.
pub(crate) mod macros {
    /// trait `Hash` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// બાઇટ્સના મનસ્વી પ્રવાહને હેશ કરવા માટેનું એક ઝેડટ્રેટ 0 ઝેડ.
///
/// `Hasher` ના દાખલા સામાન્ય રીતે તે રાજ્યનું પ્રતિનિધિત્વ કરે છે જે ડેટાને હેશીંગ કરતી વખતે બદલવામાં આવે છે.
///
/// `Hasher` પેદા કરેલા હેશને પુન Xપ્રાપ્ત કરવા માટે એકદમ મૂળભૂત ઇન્ટરફેસ પ્રદાન કરે છે ([`finish`] સાથે), અને પૂર્ણાંકો લખવા તેમજ બાઇટ્સના ટુકડાઓ એક ઘટકમાં ([`write`] અને [`write_u8`] વગેરે સાથે).
/// મોટા ભાગે, `Hasher` ઉદાહરણો [`Hash`] trait સાથે જોડાણમાં ઉપયોગમાં લેવાય છે.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// અત્યાર સુધી લખેલા મૂલ્યો માટે હેશ મૂલ્ય પરત કરે છે.
    ///
    /// તેનું નામ હોવા છતાં, પદ્ધતિ હેશરની આંતરિક સ્થિતિને ફરીથી સેટ કરતી નથી.
    /// વધારાના [[Writ`] s વર્તમાન મૂલ્યથી ચાલુ રહેશે.
    /// જો તમારે તાજી હેશ મૂલ્ય શરૂ કરવાની જરૂર હોય, તો તમારે નવી હેશર બનાવવી પડશે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// આ `Hasher` માં કેટલાક ડેટા લખે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// આ હેશર પર એકલ `u8` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// આ હેશર પર એકલ `u16` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// આ હેશર પર એકલ `u32` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// આ હેશર પર એકલ `u64` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// આ હેશર પર એકલ `u128` લખે છે.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// આ હેશર પર એકલ `usize` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// આ હેશર પર એકલ `i8` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// આ હેશર પર એકલ `i16` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// આ હેશર પર એકલ `i32` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// આ હેશર પર એકલ `i64` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// આ હેશર પર એકલ `i128` લખે છે.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// આ હેશર પર એકલ `isize` લખે છે.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// [`Hasher`] ના દાખલા બનાવવા માટે એક trait.
///
/// એક `BuildHasher` નો ઉપયોગ સામાન્ય રીતે (દા.ત. [`HashMap`] દ્વારા) દરેક કી માટે [`હેશેર] ઓ બનાવવા માટે થાય છે જેમ કે તેઓ એકબીજાથી સ્વતંત્ર રીતે હેશ થાય છે, કારણ કે [` હેશેર] ની સ્થિતિ સમાવે છે.
///
///
/// `BuildHasher` ના દરેક દાખલા માટે, [`build_hasher`] દ્વારા બનાવેલ [`હેશેર] સમાન હોવું જોઈએ.
/// તે છે, જો બાઇટ્સનો સમાન પ્રવાહ દરેક હેશરમાં ખવડાવવામાં આવે છે, તો સમાન આઉટપુટ પણ ઉત્પન્ન થશે.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// હેશરનો પ્રકાર જે બનાવવામાં આવશે.
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// નવું હેશર બનાવે છે.
    ///
    /// એક જ દાખલા પર `build_hasher` પરના દરેક ક callલ સમાન [`હાશેરી] ઓ પેદા કરવા જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] અને [`Default`] ને લાગુ કરનારા પ્રકારો માટે ડિફ defaultલ્ટ [`BuildHasher`] ઇન્સ્ટન્સ બનાવવા માટે વપરાય છે.
///
/// `BuildHasherDefault<H>` જ્યારે `H` પ્રકાર [`Hasher`] અને [`Default`] લાગુ કરે છે ત્યારે ઉપયોગ કરી શકાય છે, અને તમારે અનુરૂપ [`BuildHasher`] દાખલાની જરૂર છે, પરંતુ કંઈ નિર્ધારિત નથી.
///
///
/// કોઈપણ `BuildHasherDefault` એ [zero-sized] છે.તે [`default`][method.default] સાથે બનાવી શકાય છે.
/// [`HashMap`] અથવા [`HashSet`] સાથે [`HashSet`] નો ઉપયોગ કરતી વખતે, આ કરવાની જરૂર નથી, કારણ કે તેઓ પોતાને યોગ્ય [`Default`] દાખલાઓ લાગુ કરે છે.
///
/// # Examples
///
/// માટે કસ્ટમ [`BuildHasher`] સ્પષ્ટ કરવા માટે `BuildHasherDefault` નો ઉપયોગ કરવો
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // તમારું હેશીંગ અલ્ગોરિધમનો અહીં જાય છે!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // તમારું હેશીંગ અલ્ગોરિધમનો અહીં જાય છે!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // સલામતી: `ptr` માન્ય અને ગોઠવાયેલ છે, કારણ કે આ મેક્રોનો જ ઉપયોગ થાય છે
                    // સંખ્યાત્મક આદિકાળ માટે કે જેમાં કોઈ પેડિંગ નથી.
                    // નવી સ્લાઈસ ફક્ત `data` પર ફેલાયેલી છે અને ક્યારેય પરિવર્તિત થતી નથી, અને તેનો કુલ કદ મૂળ `data` જેટલો જ છે તેથી તે `isize::MAX` કરતા વધુ ન હોઈ શકે.
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // પાતળા નિર્દેશક
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ચરબી નિર્દેશક સલામતી: અમે `self` દ્વારા કબજે કરેલી મેમરીને areક્સેસ કરી રહ્યાં છીએ જે માન્ય હોવાની બાંયધરી છે.
                    // આ ધારે છે કે ચરબી પોઇન્ટરને `(usize, usize)` દ્વારા રજૂ કરી શકાય છે, જે `std` માં કરવું સલામત છે કારણ કે તે મોકલવામાં આવે છે અને `rustc` માં ચરબીના નિર્દેશોના અમલ સાથે સુમેળમાં રાખવામાં આવે છે.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // પાતળા નિર્દેશક
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ચરબી નિર્દેશક સલામતી: અમે `self` દ્વારા કબજે કરેલી મેમરીને areક્સેસ કરી રહ્યાં છીએ જે માન્ય હોવાની બાંયધરી છે.
                    // આ ધારે છે કે ચરબી પોઇન્ટરને `(usize, usize)` દ્વારા રજૂ કરી શકાય છે, જે `std` માં કરવું સલામત છે કારણ કે તે મોકલવામાં આવે છે અને `rustc` માં ચરબીના નિર્દેશોના અમલ સાથે સુમેળમાં રાખવામાં આવે છે.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}