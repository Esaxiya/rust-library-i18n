//! સિપહેશનો અમલ.

#![allow(deprecated)] // આ મોડ્યુલનાં પ્રકારોને નાપસંદ કર્યા છે

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// સિપહેશ S-. નો અમલ.
///
/// આ હાલમાં માનક લાઇબ્રેરી દ્વારા વપરાયેલ ડિફ defaultલ્ટ હેશીંગ ફંક્શન છે (દા.ત., `collections::HashMap` તેનો ઉપયોગ મૂળભૂત રીતે કરે છે).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// સિપહashશ 2-4 નો અમલ.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// સિપહashશ 2-4 નો અમલ.
///
/// See: <https://131002.net/siphash/>
///
/// સિપહેશ એ સામાન્ય હેતુવાળા હેશીંગ ફંક્શન છે: તે સારી ગતિથી ચાલે છે (સ્પુકી અને સિટી સાથે સ્પર્ધા કરે છે) અને મજબૂત _keyed_ હેશિંગને પરવાનગી આપે છે.
///
/// આ તમને [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) જેવા મજબૂત RNG માંથી તમારા હેશ કોષ્ટકોને કી કરવા દે છે.
///
/// જોકે સીપશેશ અલ્ગોરિધમનો સામાન્ય રીતે મજબૂત માનવામાં આવે છે, તે ક્રિપ્ટોગ્રાફિક હેતુ માટે નથી.
/// જેમ કે, આ અમલીકરણના બધા ક્રિપ્ટોગ્રાફિક ઉપયોગો _strongly discouraged_ છે.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // આપણે કેટલા બાઇટ્સ પર પ્રક્રિયા કરી છે
    state: State,  // હેશ રાજ્ય
    tail: u64,     // અનપ્રોસેસ્ડ બાઇટ્સ લે
    ntail: usize,  // પૂંછડીમાં કેટલા બાઇટ્સ માન્ય છે
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 અને v1, v3 એલ્ગોરિધમમાં જોડીમાં બતાવવામાં આવે છે, અને SipHash ના સિમ્પ્ડ અમલીકરણો v02 અને v13 ના vectors નો ઉપયોગ કરશે.
    //
    // તેમને આ ક્રમમાં સ્ટ્રક્ટમાં મૂકીને, કમ્પાઇલર ફક્ત થોડા સિમિત optimપ્ટિમાઇઝેશનને જાતે જ પસંદ કરી શકે છે.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// લે ક્રમમાં બાઇટ સ્ટ્રીમથી ઇચ્છિત પ્રકારનાં પૂર્ણાંકો લોડ કરે છે.
/// કમ્પાઈલરને સંભવિત બિન-સહી કરેલ સરનામાંથી લોડ કરવાની સૌથી અસરકારક રીત પેદા કરવા માટે `copy_nonoverlapping` નો ઉપયોગ કરે છે.
///
///
/// અસુરક્ષિત કારણ કે: i..i+size_of(int_ty) પર અનચેક અનુક્રમણિકા
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// બાઇટ સ્લાઈસના 7 બાઇટ્સનો ઉપયોગ કરીને એક u64 લોડ કરે છે.
/// તે અણઘડ લાગે છે પરંતુ `copy_nonoverlapping` ક thatલ્સ કે જે થાય છે (`load_int_le!` દ્વારા) બધામાં ચોક્કસ કદ હોય છે અને `memcpy` ને ક avoidલ કરવાનું ટાળે છે, જે ગતિ માટે સારું છે.
///
///
/// અસુરક્ષિત કારણ કે: પ્રારંભ પર અનચેક કરેલ અનુક્રમણિકા. સ્ટાર્ટ + લેન
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // આઉટપુટ u64 માં વર્તમાન બાઇટ ઇન્ડેક્સ (એલએસબીથી)
    let mut out = 0;
    if i + 3 < len {
        // સલામતી: `i` `len` કરતા વધારે ન હોઇ શકે, અને કlerલરને ખાતરી આપી હોવી જ જોઇએ
        // કે અનુક્રમણિકા પ્રારંભ..શરૂ + લેન સીમામાં છે.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // સલામતી: ઉપરની જેમ.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // સલામતી: ઉપરની જેમ.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 પર સેટ કરેલી બે પ્રારંભિક કીઓ સાથે એક નવો `SipHasher` બનાવે છે.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// એક `SipHasher` બનાવે છે જે પ્રદાન કરેલી કીઓથી બંધ છે.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 પર સેટ કરેલી બે પ્રારંભિક કીઓ સાથે એક નવો `SipHasher13` બનાવે છે.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// એક `SipHasher13` બનાવે છે જે પ્રદાન કરેલી કીઓથી બંધ છે.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: કોઈ પૂર્ણાંક હેશીંગ પદ્ધતિઓ (`Writ_u *`, `write_i*`) વ્યાખ્યાયિત નથી
    // આ પ્રકાર માટે.
    // અમે તેમને ઉમેરી શકીએ, librustc_data_structures/sip128.rs માં `short_write` અમલીકરણની ક copyપિ કરી શકીએ અને `SipHasher`, `SipHasher13` અને `DefaultHasher` માં `write_u *`/`write_i*` પદ્ધતિઓ ઉમેરી શકીએ.
    //
    // આ તે હેશર્સ દ્વારા પૂર્ણાંક હેશીંગને મોટા પ્રમાણમાં વેગ આપશે, કેટલાક બેંચમાર્ક પર કમ્પાઇલ ગતિને ધીમું કરવાના ભાવે.
    // વિગતો માટે #69152 જુઓ.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // સલામતી: `cmp::min(length, needed)` એ `length` કરતા વધારે ન હોવાની બાંયધરી આપવામાં આવી છે
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // બફર કરેલ પૂંછડી હવે ફ્લશ થઈ ગઈ છે, નવા ઇનપુટ પર પ્રક્રિયા કરો.
        let len = length - needed;
        let left = len & 0x7; // લેન% 8

        let mut i = needed;
        while i < len - left {
            // સલામતી: કારણ કે `len - left` એ 8 હેઠળના સૌથી મોટા ગુણાકાર છે
            // `len`, અને કારણ કે `i` `needed` થી શરૂ થાય છે જ્યાં `len` એ `length - needed` છે, `i + 8` એ `length` કરતા ઓછી અથવા તેની બરાબર ખાતરી આપી છે.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // સલામતી: `i` હવે `needed + len.div_euclid(8) * 8` છે,
        // તેથી `i + left` = `needed + len` = `length`, જે `msg.len()` ની બરાબર વ્યાખ્યા દ્વારા છે.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 પર સેટ કરેલી બે પ્રારંભિક કીઓ સાથે એક `Hasher<S>` બનાવે છે.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}