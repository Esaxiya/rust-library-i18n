use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// અસુમેળ પુનરાવર્તકો સાથે વ્યવહાર કરવા માટેનું એક ઇન્ટરફેસ.
///
/// આ મુખ્ય પ્રવાહ trait છે.
/// સામાન્ય રીતે સ્ટ્રીમ્સની વિભાવના વિશે વધુ માટે, કૃપા કરીને [module-level documentation] જુઓ.
/// ખાસ કરીને, તમે [implement `Stream`][impl] કેવી રીતે કરવું તે જાણી શકો છો.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// પ્રવાહ દ્વારા ઉપજિત વસ્તુઓનો પ્રકાર.
    type Item;

    /// આ પ્રવાહનું આગલું મૂલ્ય બહાર કા Atવાનો પ્રયાસ કરો, જો મૂલ્ય હજી સુધી ઉપલબ્ધ ન હોય તો વેકઅપ માટે વર્તમાન કાર્યની નોંધણી કરો અને જો પ્રવાહ સમાપ્ત થઈ ગયો હોય તો `None` પરત કરો.
    ///
    /// # વળતર મૂલ્ય
    ///
    /// ત્યાં ઘણાં સંભવિત વળતર મૂલ્યો છે, જે પ્રત્યેક અલગ પ્રવાહ સ્થિતિ દર્શાવે છે:
    ///
    /// - `Poll::Pending` મતલબ કે આ પ્રવાહનું આગલું મૂલ્ય હજી તૈયાર નથી.અમલીકરણો સુનિશ્ચિત કરશે કે જ્યારે આગલું મૂલ્ય તૈયાર થઈ શકે ત્યારે વર્તમાન કાર્યને સૂચિત કરવામાં આવશે.
    ///
    /// - `Poll::Ready(Some(val))` મતલબ કે પ્રવાહમાં સફળતાપૂર્વક એક કિંમત, `val` નું ઉત્પાદન થયું છે અને તે પછીના `poll_next` ક onલ્સ પર વધુ મૂલ્યો ઉત્પન્ન કરી શકે છે.
    ///
    /// - `Poll::Ready(None)` મતલબ કે પ્રવાહ સમાપ્ત થયો છે, અને `poll_next` ફરીથી ચાલુ થવું જોઈએ નહીં.
    ///
    /// # Panics
    ///
    /// એકવાર પ્રવાહ સમાપ્ત થઈ ગયા પછી (`Ready(None)` from `poll_next`) પાછો ફર્યો, તેની `poll_next` પદ્ધતિને ફરીથી ક callingલ કરીને panic, કાયમ અવરોધિત થઈ શકે છે, અથવા અન્ય પ્રકારની સમસ્યાઓ પેદા કરી શકે છે; `Stream` trait આવા ક callલની અસરો પર કોઈ આવશ્યકતા નથી.
    ///
    /// જો કે, `poll_next` પદ્ધતિ `unsafe` તરીકે ચિહ્નિત થયેલ નથી, ઝેડ રસ્ટ0 ઝેડના સામાન્ય નિયમો લાગુ થાય છે: ક callsલ ક્યારેય સ્ટ્રીટની સ્થિતિને ધ્યાનમાં લીધા વિના અનિશ્ચિત વર્તન (મેમરી ભ્રષ્ટાચાર, `unsafe` કાર્યોનો ખોટો ઉપયોગ, અથવા જેવા) નું કારણ બનતું નથી.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// પ્રવાહની બાકીની લંબાઈ પરની સીમાઓ પરત કરે છે.
    ///
    /// ખાસ કરીને, `size_hint()` એક ટુપલ આપે છે જ્યાં પ્રથમ તત્વ નીચલું બાઉન્ડ હોય છે, અને બીજો તત્વ ઉપલા બાઉન્ડ હોય છે.
    ///
    /// પાછું આપેલ ટ્યુપલનો બીજો ભાગ એ એક [`વિકલ્પ`]`<`[`યુઝાઇઝ]]`>` છે.
    /// અહીં એક [`None`] નો અર્થ છે કે કાં તો ત્યાં કોઈ ઉપલા બાઉન્ડ નથી, અથવા ઉપલા બાઉન્ડ [`usize`] કરતા મોટા છે.
    ///
    /// # અમલીકરણની નોંધ
    ///
    /// તે અમલમાં મૂકવામાં આવતું નથી કે પ્રવાહના અમલીકરણથી તત્વોની ઘોષિત સંખ્યા મળે છે.બગડેલ પ્રવાહ એ નીચલા બાઉન્ડ કરતા ઓછા અથવા તત્વોના ઉપરના બાઉન્ડ કરતા વધુ પ્રાપ્ત કરી શકે છે.
    ///
    /// `size_hint()` મુખ્યત્વે પ્રવાહના તત્વો માટે જગ્યા બચાવવા જેવા optimપ્ટિમાઇઝેશન માટે વાપરવા માટે બનાવાયેલ છે, પરંતુ દા.ત. પર વિશ્વાસ કરવો જોઇએ નહીં, અસુરક્ષિત કોડમાં બાઉન્ડ્સ ચેક છોડી દેવું જોઈએ.
    /// `size_hint()` ના ખોટા અમલીકરણથી મેમરી સલામતી ઉલ્લંઘન તરફ દોરી જવી જોઈએ નહીં.
    ///
    /// તેણે કહ્યું કે, અમલીકરણએ સાચો અંદાજ પૂરો પાડવો જોઈએ, કારણ કે અન્યથા તે ઝેડટ્રેટ 0 ઝેડના પ્રોટોકોલનું ઉલ્લંઘન હશે.
    ///
    /// ડિફ defaultલ્ટ અમલીકરણ returns (0, `[` કંઈ નહીં]] `) returns આપે છે જે કોઈપણ પ્રવાહ માટે યોગ્ય છે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}