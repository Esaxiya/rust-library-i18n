//! ઓવરલોડેબલ torsપરેટર્સ.
//!
//! આ ઝેડ 0 ટ્રાઇટ્સ 0 ઝેડને અમલમાં મૂકવું તમને અમુક torsપરેટર્સને વધુ ભાર આપી શકે છે.
//!
//! આમાંથી કેટલાક ઝેડટ્રેટ 0 ઝેડ ઝેડપ્રીઅલ 0 ઝેડ દ્વારા આયાત કરવામાં આવ્યાં છે, તેથી તે દરેક ઝેડ ર્રસ્ટ0 ઝેડ પ્રોગ્રામમાં ઉપલબ્ધ છે.ફક્ત traits દ્વારા સમર્થિત operaપરેટર્સ જ વધારે લોડ થઈ શકે છે.
//! ઉદાહરણ તરીકે, એડિશનલ operatorપરેટર (`+`) ને [`Add`] trait દ્વારા ઓવરલોડ કરી શકાય છે, પરંતુ સોંપણી operatorપરેટર (`=`) પાસે trait નું બેકિંગ નથી, તેથી તેના સિમેન્ટિક્સને ઓવરલોડ કરવાની કોઈ રીત નથી.
//! વધારામાં, આ મોડ્યુલ નવા torsપરેટર્સ બનાવવા માટે કોઈ પદ્ધતિ પ્રદાન કરતું નથી.
//! જો ટ્રિટલેસ ઓવરલોડિંગ અથવા કસ્ટમ .પરેટર્સ આવશ્યક છે, તો તમારે ઝેડ રસ્ટ0 ઝેડના સિન્ટેક્સને વિસ્તૃત કરવા માટે મેક્રોઝ અથવા કમ્પાઇલર પ્લગઇન્સ તરફ જોવું જોઈએ.
//!
//! Operatorપરેટર traits ની અમલીકરણ તેમના સામાન્ય સંદર્ભો અને [operator precedence] ને ધ્યાનમાં રાખીને, તેમના સંબંધિત સંદર્ભોમાં આશ્ચર્યજનક હોવી જોઈએ.
//! ઉદાહરણ તરીકે, [`Mul`] લાગુ કરતી વખતે, પરેશનમાં ગુણાકાર સાથે થોડું સામ્ય હોવું જોઈએ (અને અપેક્ષિત ગુણધર્મો જેમ કે સાહસિકતા શેર કરો).
//!
//! નોંધ લો કે `&&` અને `||` torsપરેટર્સ શોર્ટ-સર્કિટ, એટલે કે, તે ફક્ત તેમના બીજા ndપરેન્ડનું મૂલ્યાંકન કરે છે જો તે પરિણામમાં ફાળો આપે.traits દ્વારા આ વર્તણૂક અમલમાં મૂકી શકાય તેવું ન હોવાથી, `&&` અને `||` ઓવરલોડેબલ torsપરેટર્સ તરીકે સપોર્ટેડ નથી.
//!
//! ઘણા torsપરેટર્સ મૂલ્ય દ્વારા તેમના operaપરેન્ડ્સ લે છે.બિલ્ટ-ઇન પ્રકારો સાથે સંકળાયેલ બિન-સામાન્ય સંદર્ભમાં, આ સામાન્ય રીતે સમસ્યા હોતી નથી.
//! જો કે, આ torsપરેટર્સને સામાન્ય કોડમાં ઉપયોગમાં લેવા માટે, કેટલાક ધ્યાન આપવાની જરૂર છે જો મૂલ્યોનો ફરીથી ઉપયોગ કરવો હોય તો theપરેટર્સ તેનો વપરાશ કરવા દેવા સામે.એક વિકલ્પ એ છે કે ક્યારેક [`clone`] નો ઉપયોગ કરવો.
//! બીજો વિકલ્પ એ સંદર્ભો માટે વધારાના ઓપરેટર અમલીકરણો પૂરા પાડતા સમાવિષ્ટ પ્રકારો પર આધાર રાખવાનો છે.
//! ઉદાહરણ તરીકે, વપરાશકર્તા-નિર્ધારિત પ્રકાર `T` માટે, જે વધુમાંને ટેકો આપવા માટે માનવામાં આવે છે, તે `T` અને `&T`, traits [`Add<T>`][`Add`] અને [`Add<&T>`][`Add`] બંનેને અમલમાં મૂકવા માટે એક સારો વિચાર છે, જેથી બિનજરૂરી ક્લોનીંગ વિના સામાન્ય કોડ લખી શકાય.
//!
//!
//! # Examples
//!
//! આ ઉદાહરણ એક `Point` સ્ટ્રક્ટ બનાવે છે જે [`Add`] અને [`Sub`] ને લાગુ કરે છે, અને પછી બે `પોઇન્ટ addingઝ ઉમેરવા અને બાદબાકી દર્શાવે છે.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ઉદાહરણ અમલીકરણ માટે દરેક ઝેડટ્રેટ 0 ઝેડ માટેના દસ્તાવેજો જુઓ.
//!
//! [`Fn`], [`FnMut`], અને [`FnOnce`] traits એ એવા પ્રકારો દ્વારા અમલમાં મૂકવામાં આવે છે કે જેમ કે વિધેયોની જેમ બોલાવી શકાય.નોંધ લો કે [`Fn`] `&self` લે છે, [`FnMut`] લે છે `&mut self` અને [`FnOnce`] એ `self` લે છે.
//! આ ત્રણ પ્રકારની પદ્ધતિઓને અનુરૂપ છે કે જેનો દાખલો બોલાવી શકાય છે: ક callલ-બાય-રેફરન્સ, ક callલ-બાય-મ્યુટેબલ-રેફરન્સ અને ક callલ-બાય-વેલ્યુ.
//! આ traits નો સૌથી સામાન્ય વપરાશ એ ઉચ્ચ-સ્તરના કાર્યોની મર્યાદા તરીકે કાર્ય કરવું છે જે વિધેયો અથવા બંધોને દલીલો તરીકે લે છે.
//!
//! પરિમાણ તરીકે [`Fn`] લેવું:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! પરિમાણ તરીકે [`FnMut`] લેવું:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! પરિમાણ તરીકે [`FnOnce`] લેવું:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` તેના કબજે કરેલા ચલોનો વપરાશ કરે છે, તેથી તે એક કરતા વધુ વખત ચલાવી શકાતું નથી
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ફરીથી `func()` ને ચાલુ કરવાનો પ્રયાસ કરવો એ `func` માટે `use of moved value` ભૂલ ફેંકી દેશે
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` હવે આ બિંદુએ વિનંતી કરી શકાતી નથી
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;