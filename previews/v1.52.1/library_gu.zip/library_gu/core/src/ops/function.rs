/// ક callલ operatorપરેટરનું સંસ્કરણ જે એક સ્થાવર રીસીવર લે છે.
///
/// `Fn` ના દાખલાઓને પરિવર્તિત સ્થિતિ વિના વારંવાર કહી શકાય.
///
/// *આ trait (`Fn`) [function pointers] (`fn`) સાથે મૂંઝવણમાં ન આવે.*
///
/// `Fn` ક્લોઝર દ્વારા આપમેળે અમલમાં મૂકવામાં આવે છે જે ફક્ત કબજે કરેલા ચલોનો પરિવર્તનશીલ સંદર્ભ લે છે અથવા કંઈપણ જપ્ત કરતું નથી, તેમજ (safe) [function pointers] (કેટલીક ચેતવણીઓ સાથે, વધુ વિગતો માટે તેમના દસ્તાવેજીકરણ જુઓ).
///
/// વધારામાં, કોઈપણ પ્રકારનાં `F` માટે કે જે `Fn` લાગુ કરે છે, `&F`, `Fn` ને પણ લાગુ કરે છે.
///
/// [`FnMut`] અને [`FnOnce`] બંને એ `Fn` ની સુપરટ્રેટ્સ હોવાથી, `Fn` ના કોઈપણ કિસ્સાનો પરિમાણ તરીકે ઉપયોગ કરી શકાય છે જ્યાં [`FnMut`] અથવા [`FnOnce`] ની અપેક્ષા છે.
///
/// જ્યારે તમે ફંક્શન જેવા પ્રકારનાં પરિમાણોને સ્વીકારવા માંગતા હો ત્યારે `Fn` નો ઉપયોગ કરો અને તેને વારંવાર અને પરિવર્તિત સ્થિતિ વિના ક callલ કરવાની જરૂર હોય (દા.ત. જ્યારે તેને એક સાથે ક concલ કરો ત્યારે).
/// જો તમને આવી કડક આવશ્યકતાઓની જરૂર નથી, તો [`FnMut`] અથવા [`FnOnce`] ને સીમા તરીકે વાપરો.
///
/// આ વિષય પર કેટલીક વધુ માહિતી માટે [chapter on closures in *The Rust Programming Language*][book] જુઓ.
///
/// નોંધ એ પણ કે `Fn` traits (દા.ત.) માટેનું વિશિષ્ટ વાક્યરચના છે
/// `Fn(usize, bool) -> usize`).જેની તકનીકી વિગતોમાં રુચિ છે તે [the relevant section in the *Rustonomicon*][nomicon] નો સંદર્ભ લઈ શકે છે.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## કલોઝર બોલાવી રહ્યા છે
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` પરિમાણનો ઉપયોગ કરી રહ્યા છીએ
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // જેથી regex તે `&str: !FnMut` પર વિશ્વાસ કરી શકે
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ક callલ ઓપરેશન કરે છે.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ક theલ operatorપરેટરનું સંસ્કરણ જે પરિવર્તનીય રીસીવર લે છે.
///
/// `FnMut` ના દાખલાઓ વારંવાર કહી શકાય છે અને સ્થિતિ બદલી શકે છે.
///
/// `FnMut` ક્લોઝર દ્વારા આપમેળે અમલમાં મૂકવામાં આવે છે જે કબજે કરેલા ચલોના પરિવર્તનીય સંદર્ભો લે છે, તેમજ તે બધા પ્રકારો કે જે [`Fn`] ને લાગુ કરે છે, દા.ત., (safe) [function pointers] (કારણ કે `FnMut` એ [`Fn`] નો સુપરટ્રેટ છે).
/// વધારામાં, કોઈપણ પ્રકારનાં `F` માટે કે જે `FnMut` લાગુ કરે છે, `&mut F`, `FnMut` ને પણ લાગુ કરે છે.
///
/// [`FnOnce`] એ `FnMut` નું સુપરટ્રેટ હોવાથી, [`FnOnce`] ની અપેક્ષા છે ત્યાં `FnMut` નો કોઈપણ દાખલો ઉપયોગ કરી શકાય છે, અને [`Fn`] એ `FnMut` નો સબટ્રેટ હોવાથી [`Fn`] નો કોઈપણ દાખલો વાપરી શકાય છે જ્યાં `FnMut` ની અપેક્ષા છે.
///
/// જ્યારે તમે ફંક્શન જેવા પ્રકારનાં પરિમાણોને સ્વીકારવા માંગતા હો અને તેને ફેરબદલ કરવાની મંજૂરી આપતી વખતે તેને વારંવાર ક callલ કરવાની જરૂર હોય ત્યારે `FnMut` ને બાઉન્ડ તરીકે વાપરો.
/// જો તમે પરિમાણને સ્થાનાંતરિત કરવા માંગતા નથી, તો [`Fn`] ને બાઉન્ડ તરીકે વાપરો;જો તમારે તેને વારંવાર બોલાવવાની જરૂર નથી, તો [`FnOnce`] નો ઉપયોગ કરો.
///
/// આ વિષય પર કેટલીક વધુ માહિતી માટે [chapter on closures in *The Rust Programming Language*][book] જુઓ.
///
/// નોંધ એ પણ કે `Fn` traits (દા.ત.) માટેનું વિશિષ્ટ વાક્યરચના છે
/// `Fn(usize, bool) -> usize`).જેની તકનીકી વિગતોમાં રુચિ છે તે [the relevant section in the *Rustonomicon*][nomicon] નો સંદર્ભ લઈ શકે છે.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## પરસ્પર કેપ્ચરિંગ કલોઝર કહેવું
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` પરિમાણનો ઉપયોગ કરી રહ્યા છીએ
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // જેથી regex તે `&str: !FnMut` પર વિશ્વાસ કરી શકે
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ક callલ ઓપરેશન કરે છે.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ક callલ operatorપરેટરનું સંસ્કરણ જે બાય-વેલ્યુ રીસીવર લે છે.
///
/// `FnOnce` ના દાખલાઓ કહી શકાય છે, પરંતુ ઘણી વખત કbleલ કરી શકાતા નથી.આને કારણે, જો કોઈ પ્રકાર વિશેની એકમાત્ર વસ્તુ તે `FnOnce` લાગુ કરે છે, તો તે ફક્ત એક જ વાર કહી શકાય.
///
/// `FnOnce` ક્લોઝર દ્વારા આપમેળે લાગુ કરવામાં આવે છે જે કદાચ કબજે કરેલા ચલોનો વપરાશ કરી શકે છે, તેમજ તે બધા પ્રકારો કે જે [`FnMut`] ને લાગુ કરે છે, દા.ત., (safe) [function pointers] (કારણ કે `FnOnce` એ [`FnMut`] નો સુપરટ્રેટ છે).
///
///
/// [`Fn`] અને [`FnMut`] બંને `FnOnce` ના સબટ્રાઈટ હોવાથી, [`Fn`] અથવા [`FnMut`] ના કોઈપણ ઉદાહરણનો ઉપયોગ કરી શકાય છે જ્યાં `FnOnce` ની અપેક્ષા છે.
///
/// જ્યારે તમે ફંક્શન જેવા પ્રકારનાં પરિમાણોને સ્વીકારવા માંગતા હો ત્યારે `FnOnce` નો બાઉન્ડ તરીકે ઉપયોગ કરો અને ફક્ત તેને એકવાર ક callલ કરવાની જરૂર છે.
/// જો તમારે પરિમાણને વારંવાર ક callલ કરવાની જરૂર હોય, તો [`FnMut`] ને બાઉન્ડ તરીકે વાપરો;જો તમારે પણ રાજ્યને પરિવર્તન ન કરવાની જરૂર હોય, તો [`Fn`] નો ઉપયોગ કરો.
///
/// આ વિષય પર કેટલીક વધુ માહિતી માટે [chapter on closures in *The Rust Programming Language*][book] જુઓ.
///
/// નોંધ એ પણ કે `Fn` traits (દા.ત.) માટેનું વિશિષ્ટ વાક્યરચના છે
/// `Fn(usize, bool) -> usize`).જેની તકનીકી વિગતોમાં રુચિ છે તે [the relevant section in the *Rustonomicon*][nomicon] નો સંદર્ભ લઈ શકે છે.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` પરિમાણનો ઉપયોગ કરી રહ્યા છીએ
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` તેના કબજે કરેલા ચલોનો વપરાશ કરે છે, તેથી તે એક કરતા વધુ વખત ચલાવી શકાતું નથી.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ફરીથી `func()` ને ચાલુ કરવાનો પ્રયાસ કરવો એ `func` માટે `use of moved value` ભૂલ ફેંકી દેશે.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` હવે આ બિંદુએ વિનંતી કરી શકાતી નથી
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // જેથી regex તે `&str: !FnMut` પર વિશ્વાસ કરી શકે
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ક callલ operatorપરેટરનો ઉપયોગ કર્યા પછી પરત પ્રકાર.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ક callલ ઓપરેશન કરે છે.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}