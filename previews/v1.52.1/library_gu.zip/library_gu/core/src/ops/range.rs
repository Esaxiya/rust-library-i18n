use crate::fmt;
use crate::hash::Hash;

/// અનબાઉન્ડ રેંજ (`..`).
///
/// `RangeFull` મુખ્યત્વે [slicing index] તરીકે ઉપયોગમાં લેવાય છે, તેનો શોર્ટહેન્ડ `..` છે.
/// તે [`Iterator`] તરીકે સેવા આપી શકશે નહીં કારણ કે તેમાં પ્રારંભિક બિંદુ નથી.
///
/// # Examples
///
/// `..` સિન્ટેક્સ એ `RangeFull` છે:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// તેમાં [`IntoIterator`] અમલીકરણ નથી, તેથી તમે તેનો સીધો `for` લૂપમાં ઉપયોગ કરી શકતા નથી.
/// આ સંકલન કરશે નહીં:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] તરીકે ઉપયોગમાં લેવાય છે, `RangeFull` એક સ્લાઇસ તરીકે સંપૂર્ણ એરે ઉત્પન્ન કરે છે.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // આ `RangeFull` છે
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// એક (half-open) રેન્જ સમાવિષ્ટ નીચે અને ફક્ત (`start..end`) ઉપર.
///
///
/// `start..end` શ્રેણીમાં `start <= x < end` સાથેના તમામ મૂલ્યો શામેલ છે.
/// તે ખાલી છે જો `start >= end`.
///
/// # Examples
///
/// `start..end` સિન્ટેક્સ એ `Range` છે:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // આ એક `Range` છે
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ક Copyપિ નથી-#27186 જુઓ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// રેન્જ (inclusive) ની નીચી સીમા.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// શ્રેણી (exclusive) ની ઉપરની સીમા.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// જો શ્રેણીમાં કોઈ આઇટમ્સ ન હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// જો બંને બાજુ અનુપમ હોય તો શ્રેણી ખાલી છે:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// (`start..`) ની નીચે સમાવિષ્ટ શ્રેણી.
///
/// `RangeFrom` `start..` માં `x >= start` સાથેના બધા મૂલ્યો શામેલ છે.
///
/// *નોંધ*: [`Iterator`] અમલીકરણમાં ઓવરફ્લો (જ્યારે સમાયેલ ડેટા પ્રકાર તેની આંકડાકીય મર્યાદા સુધી પહોંચે છે) ને panic, લપેટી અથવા સંતૃપ્ત કરવાની મંજૂરી છે.
/// આ વર્તન [`Step`] trait ના અમલીકરણ દ્વારા વ્યાખ્યાયિત કરવામાં આવે છે.
/// આદિમ પૂર્ણાંકો માટે, આ સામાન્ય નિયમોનું પાલન કરે છે, અને ઓવરફ્લો ચેક પ્રોફાઇલ (ડિબગમાં ઝેડ 0 પicનિક 0 ઝેડ, પ્રકાશનમાં લપેટી) નો આદર કરે છે.
/// એ પણ નોંધ લો કે ઓવરફ્લો તમારા ધારે તે પહેલાં થાય છે: ઓવરફ્લો એ `next` પરના ક callલમાં થાય છે જે મહત્તમ મૂલ્ય મેળવે છે, કારણ કે આગલું મૂલ્ય પ્રાપ્ત કરવા માટે શ્રેણીને રાજ્યમાં સેટ કરવી આવશ્યક છે.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` સિન્ટેક્સ એ `RangeFrom` છે:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // આ એક `RangeFrom` છે
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ક Copyપિ નથી-#27186 જુઓ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// રેન્જ (inclusive) ની નીચી સીમા.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// એક્સ એક્સ એક્સએક્સએક્સએક્સથી ઉપરની શ્રેણી માત્ર.
///
/// `RangeTo` `..end` માં `x < end` સાથેના બધા મૂલ્યો શામેલ છે.
/// તે [`Iterator`] તરીકે સેવા આપી શકશે નહીં કારણ કે તેમાં પ્રારંભિક બિંદુ નથી.
///
/// # Examples
///
/// `..end` સિન્ટેક્સ એ `RangeTo` છે:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// તેમાં [`IntoIterator`] અમલીકરણ નથી, તેથી તમે તેનો સીધો `for` લૂપમાં ઉપયોગ કરી શકતા નથી.
/// આ સંકલન કરશે નહીં:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// જ્યારે [slicing index] તરીકે ઉપયોગમાં લેવાય છે, ત્યારે `RangeTo` એ `end` દ્વારા સૂચવાયેલ અનુક્રમણિકા પહેલા બધા એરે તત્વોની સ્લાઇસ ઉત્પન્ન કરે છે.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // આ એક `RangeTo` છે
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// શ્રેણી (exclusive) ની ઉપરની સીમા.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) ની નીચે અને તેનાથી સમાવિષ્ટ શ્રેણી.
///
/// `RangeInclusive` `start..=end` માં `x >= start` અને `x <= end` સાથેના બધા મૂલ્યો શામેલ છે.તે `start <= end` સિવાય ખાલી છે.
///
/// આ પુનરાવર્તક એ [fused] છે, પરંતુ ઇટરેશન સમાપ્ત થયા પછી `start` અને `end` ના વિશિષ્ટ મૂલ્યો **અનિશ્ચિત** છે કે [`.is_empty()`] સિવાય અન્ય કોઈ કિંમતો ઉત્પન્ન થાય તે પછી `true` પરત કરશે.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` સિન્ટેક્સ એ `RangeInclusive` છે:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // આ એક `RangeInclusive` છે
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ક Copyપિ નથી-#27186 જુઓ
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // નોંધ લો કે અહીંના ક્ષેત્રો ઝેડ 0 ફ્યુચર0 ઝેડમાં રજૂઆત બદલવા માટે જાહેર નથી;ખાસ કરીને, જ્યારે આપણે start/end ને બુદ્ધિગમ્ય રીતે પ્રદર્શિત કરી શકીએ, (future/current) ખાનગી ક્ષેત્રોમાં ફેરફાર કર્યા વિના તેમાં ફેરફાર કરવાથી ખોટી વર્તણૂક થઈ શકે છે, તેથી અમે તે મોડને ટેકો આપવા માંગતા નથી.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // આ ક્ષેત્ર છે:
    //  - `false` બાંધકામ પર
    //  - `false` જ્યારે ઇટરેશનમાં તત્વ મળ્યું છે અને પુનરાવર્તક ખલાસ થતું નથી
    //  - `true` જ્યારે ઇટરેટરનો ઉપયોગ ઇરેટરને ખાલી કરવા માટે કરવામાં આવ્યો છે
    //
    // આને આંશિક ઓર્ડર અથવા વિશેષતા વગર પાર્શિલિએક અને હેશને ટેકો આપવા માટે જરૂરી છે.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// નવી સમાવિષ્ટ શ્રેણી બનાવે છે.`start..=end` લખવા માટે સમાન.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) રેન્જની નીચેની સીમા પરત કરે છે.
    ///
    /// પુનરાવૃત્તિ માટે સમાવિષ્ટ શ્રેણીનો ઉપયોગ કરતી વખતે, `start()` અને [`end()`] ના મૂલ્યો પુનરાવર્તન સમાપ્ત થયા પછી અનિશ્ચિત છે.
    /// સમાવિષ્ટ શ્રેણી ખાલી છે કે કેમ તે નિર્ધારિત કરવા માટે, `start() > end()` ની તુલના કરવાને બદલે [`is_empty()`] પદ્ધતિનો ઉપયોગ કરો.
    ///
    /// Note: આ પદ્ધતિ દ્વારા પરત થયેલ મૂલ્ય શ્રેણીને થાક સુધી પુનરાવર્તિત કર્યા પછી અનિશ્ચિત કરવામાં આવ્યું છે.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) રેન્જની ઉપરની સીમા પરત કરે છે.
    ///
    /// પુનરાવૃત્તિ માટે સમાવિષ્ટ શ્રેણીનો ઉપયોગ કરતી વખતે, [`start()`] અને `end()` ના મૂલ્યો પુનરાવર્તન સમાપ્ત થયા પછી અનિશ્ચિત છે.
    /// સમાવિષ્ટ શ્રેણી ખાલી છે કે કેમ તે નિર્ધારિત કરવા માટે, `start() > end()` ની તુલના કરવાને બદલે [`is_empty()`] પદ્ધતિનો ઉપયોગ કરો.
    ///
    /// Note: આ પદ્ધતિ દ્વારા પરત થયેલ મૂલ્ય શ્રેણીને થાક સુધી પુનરાવર્તિત કર્યા પછી અનિશ્ચિત કરવામાં આવ્યું છે.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` (નીચલા બાઉન્ડ, ઉપલા (inclusive) બાઉન્ડ) માં બનાવે છે.
    ///
    /// Note: આ પદ્ધતિ દ્વારા પરત થયેલ મૂલ્ય શ્રેણીને થાક સુધી પુનરાવર્તિત કર્યા પછી અનિશ્ચિત કરવામાં આવ્યું છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` અમલીકરણ માટે વિશિષ્ટ `Range` માં રૂપાંતરિત કરે છે.
    /// કlerલર, `end == usize::MAX` સાથે વ્યવહાર કરવા માટે જવાબદાર છે.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // જો આપણે કંટાળી ગયા નથી, તો અમે ફક્ત `start..end + 1` કાપવા માગીએ છીએ.
        // જો આપણે કંટાળી ગયા છીએ, તો પછી `end + 1..end + 1` સાથે કાપવાથી અમને ખાલી શ્રેણી મળે છે જે હજી પણ તે અંતિમ બિંદુ માટે બાઉન્ડ્સ-ચેક્સને આધિન છે.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// પુનરાવર્તન સમાપ્ત થયા પછી આ પદ્ધતિ હંમેશાં `false` આપે છે:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // ચોક્કસ ક્ષેત્ર મૂલ્યો અહીં અસ્પષ્ટ છે
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// જો શ્રેણીમાં કોઈ આઇટમ્સ ન હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// જો બંને બાજુ અનુપમ હોય તો શ્રેણી ખાલી છે:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// આ પદ્ધતિ પુનરાવર્તન સમાપ્ત થયા પછી `true` આપે છે:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // ચોક્કસ ક્ષેત્ર મૂલ્યો અહીં અસ્પષ્ટ છે
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// (`..=end`) ની ઉપર સમાવિષ્ટ શ્રેણી.
///
/// `RangeToInclusive` `..=end` માં `x <= end` સાથેના બધા મૂલ્યો શામેલ છે.
/// તે [`Iterator`] તરીકે સેવા આપી શકશે નહીં કારણ કે તેમાં પ્રારંભિક બિંદુ નથી.
///
/// # Examples
///
/// `..=end` સિન્ટેક્સ એ `RangeToInclusive` છે:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// તેમાં [`IntoIterator`] અમલીકરણ નથી, તેથી તમે તેનો સીધો `for` લૂપમાં ઉપયોગ કરી શકતા નથી.આ સંકલન કરશે નહીં:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// જ્યારે [slicing index] તરીકે ઉપયોગમાં લેવાય છે, ત્યારે `RangeToInclusive` બધા એરે તત્વોની સ્લાઇસ ઉત્પન્ન કરે છે અને તેમાં `end` દ્વારા સૂચવેલ અનુક્રમણિકા શામેલ છે.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // આ એક `RangeToInclusive` છે
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// શ્રેણી (inclusive) ની ઉપરની સીમા
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// રેંજટોઇન્ક્લુસિવ<Idx>દ્વારા પ્રોમ્પ્ટ કરી શકતા નથી <RangeTo<Idx>> કારણ કે (..0).into() સાથે અંડરફ્લો શક્ય હશે
//

/// કીઓની શ્રેણીનો અંતિમ બિંદુ.
///
/// # Examples
///
/// `બાઉન્ડ્સ એ અંતિમ બિંદુઓ છે:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] ની દલીલ તરીકે `બાઉન્ડ્સના ટ્યૂપલનો ઉપયોગ કરવો.
/// નોંધ લો કે મોટાભાગના કિસ્સાઓમાં, તેના બદલે રેંજ સિંટેક્સ (`1..5`) નો ઉપયોગ કરવો વધુ સારું છે.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// એક શામેલ બાઉન્ડ.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// એક વિશિષ્ટ બાઉન્ડ.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// અનંત અંતિમ બિંદુ.સૂચવે છે કે આ દિશામાં કોઈ બાઉન્ડ નથી.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` થી `Bound<&T>` માં રૂપાંતરિત કરે છે.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` થી `Bound<&T>` માં રૂપાંતરિત કરે છે.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// બાઉન્ડની સામગ્રીઓનું ક્લોનિંગ કરીને એક `Bound<&T>` ને `Bound<T>` પર નકશો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` ઝેડ રસ્ટ0 ઝેડના બિલ્ટ-ઇન રેંજ પ્રકારો દ્વારા અમલમાં મૂકવામાં આવે છે, જે `..`, `a..`, `..b`, `..=c`, `d..e` અથવા `f..=g` જેવા રેન્જ સિંટેક્સ દ્વારા બનાવવામાં આવે છે.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// પ્રારંભ અનુક્રમણિકા.
    ///
    /// `Bound` તરીકે પ્રારંભ મૂલ્ય પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// અંતિમ અનુક્રમણિકા બાઉન્ડ.
    ///
    /// `Bound` તરીકે અંતિમ મૂલ્ય આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// જો X01 રેન્જમાં સમાવેલ હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// ભારપૂર્વક! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ભારપૂર્વક! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // જ્યારે પુનરાવર્તક ખલાસ થઈ જાય છે, ત્યારે આપણી પાસે સામાન્ય રીતે પ્રારંભ==અંત હોય છે, પરંતુ અમે ઇચ્છીએ છીએ કે શ્રેણી ખાલી દેખાશે, તેમાં કંઈ નથી.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}