/// `?` operatorપરેટરની વર્તણૂકને કસ્ટમાઇઝ કરવા માટે એક trait.
///
/// એક પ્રકારનો અમલ `Try` એ એક છે જેની પાસે success/failure ડિકોટોમીની દ્રષ્ટિએ તેને જોવાની એક પ્રાકૃતિક રીત છે.
/// આ ઝેડ 0 ટ્રાઇટ0 ઝેડ હાલની હમણાંથી તે સફળતા અથવા નિષ્ફળતાના મૂલ્યોને કાractવા અને સફળતા અથવા નિષ્ફળતાના મૂલ્યથી નવું દાખલો બનાવવા બંનેને મંજૂરી આપે છે.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// સફળ તરીકે જોવામાં આવે ત્યારે આ મૂલ્યનો પ્રકાર.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// નિષ્ફળ તરીકે જોવામાં આવે ત્યારે આ મૂલ્યનો પ્રકાર.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" operatorપરેટર લાગુ કરે છે.`Ok(t)` નું વળતર એટલે કે એક્ઝેક્યુશન સામાન્ય રીતે ચાલુ થવું જોઈએ, અને `?` નું પરિણામ એ `t` ની કિંમત છે.
    /// `Err(e)` ના વળતરનો અર્થ એ છે કે એક્ઝેક્યુશન branch ને અંદરની બાજુએથી બંધ કરાયેલ `catch` પર ખસેડવું જોઈએ, અથવા ફંક્શનમાંથી પાછા આવવું જોઈએ.
    ///
    /// જો કોઈ `Err(e)` પરિણામ પાછું આવે છે, તો બંધ કરેલા અવકાશના રીટર્ન પ્રકારમાં `e` નું મૂલ્ય "wrapped" હશે (જે પોતે `Try` લાગુ પાડશે).
    ///
    /// ખાસ કરીને, `X::from_error(From::from(e))` નું મૂલ્ય પાછું આવે છે, જ્યાં `X` એ એન્ક્લોઝિંગ ફંક્શનનો રીટર્ન પ્રકાર છે.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// સંયુક્ત પરિણામ બનાવવા માટે ભૂલ મૂલ્યને વીંટો.
    /// ઉદાહરણ તરીકે, `Result::Err(x)` અને `Result::from_error(x)` સમાન છે.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// સંયુક્ત પરિણામ બનાવવા માટે એક OKકે મૂલ્ય લપેટી.
    /// ઉદાહરણ તરીકે, `Result::Ok(x)` અને `Result::from_ok(x)` સમાન છે.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}