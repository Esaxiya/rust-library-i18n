use crate::ops::Try;

/// Earlyપરેશનને કહેવા માટે વપરાય છે કે શું તે વહેલી તકે નીકળવું જોઈએ અથવા હંમેશની જેમ આગળ વધવું જોઈએ.
///
/// આનો ઉપયોગ વસ્તુઓ (જ્યારે ગ્રાફ ટ્ર graphવર્સલ અથવા મુલાકાતીઓ) ને ઉજાગર કરતી વખતે કરવામાં આવે છે જ્યાં તમે ઇચ્છો છો કે વપરાશકર્તા વહેલી તકે બહાર નીકળવું કે નહીં તે પસંદ કરી શકશે.
/// એનમ રાખવાથી તે સ્પષ્ટ થાય છે-કોઈ આશ્ચર્યજનક "wait, what did `false` mean again?" નહીં-અને મૂલ્ય સહિતની મંજૂરી આપે છે.
///
/// # Examples
///
/// [`Iterator::try_for_each`] થી પ્રારંભિક બહાર નીકળવું:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// મૂળ ઝાડની આડઅસર
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// Asપરેશનના આગલા તબક્કામાં સામાન્ય તરીકે આગળ વધો.
    Continue(C),
    /// અનુગામી તબક્કાઓ ચલાવ્યા વિના Exપરેશનમાંથી બહાર નીકળો.
    Break(B),
    // હા, ચલોનો ક્રમ પ્રકારનાં પરિમાણો સાથે મેળ ખાતો નથી.
    // તેઓ આ ક્રમમાં છે જેથી `ControlFlow<A, B>` <-> `Result<B, A>` એ `Try` અમલીકરણમાં નો-conversપ રૂપાંતર છે.
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// જો આ `Break` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// જો આ `Continue` વેરિઅન્ટ હોય તો `true` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// `ControlFlow` ને `Option` માં રૂપાંતરિત કરે છે જે `Some` છે જો `ControlFlow` અન્યથા `Break` અને `None` હોત.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// નકશા `ControlFlow<B, C>` થી `ControlFlow<T, C>` ફંક્શનને લાગુ કરવાના કિસ્સામાં બ્રેક વેલ્યુ પર લાગુ કરીને.
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// કોઈપણ પ્રકારનાં `Try` અમલીકરણથી `ControlFlow` બનાવો.
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// એક `ControlFlow` ને કોઈપણ પ્રકારનાં `Try` ને અમલમાં મૂકવા;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// તે વારંવાર એવું બને છે કે `Continue` સાથે કોઈ મૂલ્યની આવશ્યકતા હોતી નથી, તેથી જો તમે તેને પસંદ કરો તો, `(())` ટાઇપ કરવાનું ટાળવાનો માર્ગ પ્રદાન કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` જેવા એપીઆઇને `Break` સાથેના મૂલ્યોની જરૂર હોતી નથી, તેથી જો તમે તેને પસંદ કરો તો `(())` ટાઇપ કરવાનું ટાળવાનો માર્ગ પ્રદાન કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}