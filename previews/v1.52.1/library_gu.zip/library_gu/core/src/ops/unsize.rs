use crate::marker::Unsize;

/// ઝેડટ્રેટ 0 ઝેડ કે જે સૂચવે છે કે આ એક માટે નિર્દેશક અથવા રેપર છે, જ્યાં પોઇંટ પર અનઇઝિંગ કરી શકાય છે.
///
/// વધુ વિગતો માટે [DST coercion RFC][dst-coerce] અને [the nomicon entry on coercion][nomicon-coerce] જુઓ.
///
/// બિલ્ટિન પોઇન્ટર પ્રકારો માટે, `T` તરફના નિર્દેશકો `U` તરફના નિર્દેશકોને દબાણ કરશે જો `T: Unsize<U>` પાતળા નિર્દેશકથી ચરબી નિર્દેશકમાં રૂપાંતર કરીને.
///
/// વૈવિધ્યપૂર્ણ પ્રકારો માટે, અહીં બળવો `Foo<T>` થી `Foo<U>` ના દબાણ દ્વારા કાર્ય કરે છે જો `CoerceUnsized<Foo<U>> for Foo<T>` નું ઇમ્પ્લ હાજર હોય.
/// આવી પ્રોમ્પ્લલીટ ફક્ત ત્યારે જ લખી શકાય છે જ્યારે `Foo<T>` માં ફક્ત એક જ નોન-ફેન્ટમડેટા ફીલ્ડ હોય જેમાં `T` શામેલ હોય.
/// જો તે ક્ષેત્રનો પ્રકાર `Bar<T>` છે, તો `CoerceUnsized<Bar<U>> for Bar<T>` નો અમલ અસ્તિત્વમાં હોવો આવશ્યક છે.
/// `Bar<T>` ફીલ્ડને `Bar<U>` માં કબજે કરીને અને `Foo<U>` બનાવવા માટે `Foo<T>` માંથી બાકીના ક્ષેત્રો ભરીને જબરદસ્તી કામ કરશે.
/// આ અસરકારક રીતે નિર્દેશક ક્ષેત્રમાં નીચે કવાયત કરશે અને દબાણ કરશે.
///
/// સામાન્ય રીતે, સ્માર્ટ પોઇંટર્સ માટે, તમે `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ને અમલમાં મૂકશો, `T` પર જ બંધાયેલા વૈકલ્પિક `?Sized` સાથે.
/// રેપર પ્રકારો માટે જે `T` ને સીધા `Cell<T>` અને `RefCell<T>` એમ્બેડ કરે છે, તમે સીધા `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` અમલમાં મૂકી શકો છો.
///
/// આ `Cell<Box<T>>` જેવા પ્રકારનાં દબદબોને કાર્ય કરવા દેશે.
///
/// [`Unsize`][unsize] પ્રકારોને ચિહ્નિત કરવા માટે વપરાય છે જે નિર્દેશકોની પાછળ હોય તો ડીએસટીએસ પર દબાણ કરી શકાય છે.તે કમ્પાઇલર દ્વારા આપમેળે અમલમાં મૂકવામાં આવે છે.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ટી-> &mut યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ટી-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ટી-> * મ્યુટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ટી-> * કોન્સ્ટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * કોન્સ્ટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *મ્યુટ ટી->* મ્યુટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *મ્યુટ ટી->* કોન્સ્ટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *કોન્સ્ટ ટી->* કોન્સ્ટ યુ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// આનો ઉપયોગ objectબ્જેક્ટની સલામતી માટે થાય છે, તે ચકાસવા માટે કે પદ્ધતિનો રીસીવર પ્રકાર ફરીથી મોકલી શકાય છે.
///
/// trait નું ઉદાહરણ અમલીકરણ:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ટી-> &mut યુ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *કોન્સ્ટ ટી->* કોન્સ્ટ યુ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *મ્યુટ ટી->* મ્યુટ યુ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}