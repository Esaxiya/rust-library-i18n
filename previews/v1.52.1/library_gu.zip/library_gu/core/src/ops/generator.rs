use crate::marker::Unpin;
use crate::pin::Pin;

/// જનરેટર ફરીથી પ્રારંભનું પરિણામ.
///
/// આ એનોમ `Generator::resume` પદ્ધતિથી પાછો ફર્યો છે અને જનરેટરના સંભવિત વળતર મૂલ્યો સૂચવે છે.
/// હાલમાં આ કાં તો સસ્પેન્શન પોઇન્ટ (`Yielded`) અથવા સમાપ્તિ બિંદુ (`Complete`) ને અનુરૂપ છે.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// મૂલ્ય સાથે જનરેટર સસ્પેન્ડ.
    ///
    /// આ રાજ્ય સૂચવે છે કે જનરેટરને સસ્પેન્ડ કરવામાં આવ્યું છે અને સામાન્ય રીતે તે `yield` સ્ટેટમેન્ટને અનુરૂપ છે.
    /// આ વેરિઅન્ટમાં પ્રદાન થયેલ મૂલ્ય, `yield` પરની અભિવ્યક્તિને અનુરૂપ છે અને જનરેટર્સ જ્યારે પણ ઉત્પન્ન કરે ત્યારે મૂલ્ય પ્રદાન કરવાની મંજૂરી આપે છે.
    ///
    ///
    Yielded(Y),

    /// વળતર મૂલ્ય સાથે જનરેટર પૂર્ણ થયું.
    ///
    /// આ રાજ્ય સૂચવે છે કે જનરેટર પ્રદાન કરેલ મૂલ્ય સાથે એક્ઝેક્યુશન સમાપ્ત કર્યું છે.
    /// એકવાર જનરેટરે `Complete` પરત કર્યા પછી તે ફરીથી `resume` પર ક callલ કરવા માટે પ્રોગ્રામર ભૂલ માનવામાં આવે છે.
    ///
    Complete(R),
}

/// trait બિલ્ટિન જનરેટર પ્રકારો દ્વારા અમલમાં મૂકવામાં આવે છે.
///
/// જનરેટર, જેને સામાન્ય રીતે કોરોટાઇન્સ તરીકે પણ ઓળખવામાં આવે છે, તે હાલમાં ઝેડ રસ્ટ0 ઝેડમાં એક પ્રાયોગિક ભાષા સુવિધા છે.
/// [RFC 2033] જનરેટરમાં ઉમેરવામાં આવેલા હાલમાં મુખ્યત્વે async/await સિન્ટેક્સ માટે બિલ્ડિંગ બ્લ blockક પૂરા પાડવાનો છે પરંતુ સંભવત ite પુનરાવર્તકો અને અન્ય આદિકાળીઓ માટે અર્ગનોમિક્સ વ્યાખ્યા પૂરી પાડવામાં પણ વિસ્તૃત થશે.
///
///
/// જનરેટર માટે સિન્ટેક્સ અને સિમેન્ટિક્સ અસ્થિર છે અને સ્થિરતા માટે વધુ આરએફસીની જરૂર પડશે.આ સમયે, જોકે, વાક્યરચના બંધ જેવા છે:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// જનરેટરના વધુ દસ્તાવેજો અસ્થિર પુસ્તકમાં મળી શકે છે.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// આ જનરેટર ઉપજ આપતું મૂલ્યનો પ્રકાર.
    ///
    /// આ સંકળાયેલ પ્રકાર `yield` અભિવ્યક્તિને અનુલક્ષે છે અને કિંમતો જેમને દરેક વખતે જનરેટર આપતાં સમયે પરત કરવાની મંજૂરી છે.
    ///
    /// ઉદાહરણ તરીકે, એક જનરેટર-તરીકે-જનરેટરમાં આ પ્રકારનો સંભવત `T` હોવો જોઈએ, જે પ્રકાર પુનરાવર્તિત થઈ રહ્યો છે.
    ///
    type Yield;

    /// આ જનરેટર પરત કરે છે મૂલ્યનો પ્રકાર.
    ///
    /// આ એક જનરેટરમાંથી પાછા ફરતા પ્રકારને અનુરૂપ છે એક `return` નિવેદન સાથે અથવા સ્પષ્ટપણે જનરેટર શાબ્દિકની અંતિમ અભિવ્યક્તિ તરીકે.
    /// ઉદાહરણ તરીકે futures એ તેનો ઉપયોગ `Result<T, E>` તરીકે કરશે કારણ કે તે સંપૂર્ણ fચર રજૂ કરે છે.
    ///
    ///
    type Return;

    /// આ જનરેટરનો અમલ ફરી શરૂ કરે છે.
    ///
    /// આ ફંક્શન જનરેટરનું એક્ઝેક્યુશન ફરી શરૂ કરશે અથવા જો તે પહેલાથી જ ન હોય તો અમલ શરૂ કરશે.
    /// આ ક callલ જનરેટરના છેલ્લા સસ્પેન્શન પોઇન્ટ પર પાછા આવશે, નવીનતમ `yield` થી એક્ઝેક્યુશન ફરી શરૂ કરશે.
    /// જનરેટર ઉપજ આપશે કે વળતર આપે ત્યાં સુધી એક્ઝેક્યુટ કરવાનું ચાલુ રાખશે, આ બિંદુએ આ કાર્ય પાછું આવશે.
    ///
    /// # વળતર મૂલ્ય
    ///
    /// આ ફંક્શનથી પરત થયેલ `GeneratorState` એનમ સૂચવે છે કે પરત ફરતા જનરેટર કયા રાજ્યમાં છે.
    /// જો `Yielded` વેરિઅન્ટ પાછો ફર્યો છે, તો જનરેટર સસ્પેન્શન પોઇન્ટ પર પહોંચી ગયું છે અને મૂલ્ય પ્રાપ્ત થયું છે.
    /// આ રાજ્યમાં જનરેટર્સ પછીના તબક્કે ફરીથી પ્રારંભ માટે ઉપલબ્ધ છે.
    ///
    /// જો `Complete` પરત આવે છે, તો જનરેટર પ્રદાન કરેલા મૂલ્ય સાથે સંપૂર્ણપણે સમાપ્ત થઈ ગયું છે.જનરેટર ફરીથી શરૂ કરવું અમાન્ય છે.
    ///
    /// # Panics
    ///
    /// જો `Complete` વેરિઅન્ટ પહેલાં પાછો ફર્યા બાદ બોલાવવામાં આવે તો આ ફંક્શન panic શકે છે.
    /// જ્યારે ભાષામાં જનરેટર લિટરલ્સની `Complete` પછી ફરી શરૂ કરવામાં ઝેડપpanનિક 80 ઝેડની બાંયધરી આપવામાં આવી છે, `Generator` trait ના તમામ અમલીકરણો માટેની આ બાંયધરી નથી.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}