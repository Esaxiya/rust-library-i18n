/// `*v` જેવા સ્થાવર ડિરેફરન્સિંગ કામગીરી માટે વપરાય છે.
///
/// પરિવર્તનીય સંદર્ભમાં (unary) `*` operatorપરેટર સાથે સ્પષ્ટ ડિરેફરન્સિંગ કામગીરી માટે ઉપયોગ કરવા ઉપરાંત, `Deref` નો ઉપયોગ ઘણા સંજોગોમાં કમ્પાઇલર દ્વારા પણ સ્પષ્ટ રીતે કરવામાં આવે છે.
/// આ પદ્ધતિને ['`Deref` coercion'][more] કહેવામાં આવે છે.
/// પરિવર્તનશીલ સંદર્ભોમાં, [`DerefMut`] નો ઉપયોગ થાય છે.
///
/// સ્માર્ટ પોઇંટર્સ માટે `Deref` અમલીકરણ તેમની પાછળના ડેટાને convenientક્સેસ કરવાનું અનુકૂળ બનાવે છે, તેથી જ તેઓ `Deref` અમલમાં મૂકે છે.
/// બીજી બાજુ, `Deref` અને [`DerefMut`] સંબંધિત નિયમો સ્માર્ટ પોઇંટરોને સમાવવા માટે ખાસ બનાવવામાં આવ્યા હતા.
/// આને કારણે, મૂંઝવણ ટાળવા માટે **re ડેરેફને ફક્ત સ્માર્ટ પોઇંટર્સ** માટે જ અમલમાં મૂકવા જોઈએ.
///
/// સમાન કારણોસર,**આ trait ક્યારેય નિષ્ફળ થવું જોઈએ નહીં**.ડિરેફરન્સ દરમિયાન નિષ્ફળતા એ ખૂબ જ મૂંઝવણભરી થઈ શકે છે જ્યારે એક્સ 100 એક્સ ગર્ભિત રીતે બોલાવવામાં આવે છે.
///
/// # `Deref` જબરદસ્તી પર વધુ
///
/// જો `T` એ `Deref<Target = U>` લાગુ કરે છે, અને `x` એ `T` પ્રકારનું મૂલ્ય છે, તો:
///
/// * પરિવર્તનશીલ સંદર્ભોમાં, `*x` (જ્યાં `T` એ સંદર્ભ અથવા કાચો નિર્દેશક નથી) એ `* Deref::deref(&x)` ની સમકક્ષ છે.
/// * પ્રકાર `&T` ના મૂલ્યો, `&U` પ્રકારનાં મૂલ્યો સાથે દબાણ કરવામાં આવે છે
/// * `T` `U` પ્રકારની બધી (immutable) પદ્ધતિઓને સ્પષ્ટપણે લાગુ કરે છે.
///
/// વધુ વિગતો માટે, [the chapter in *The Rust Programming Language*][book] ની સાથે સાથે [the dereference operator][ref-deref-op], [method resolution] અને [type coercions] પરના સંદર્ભ વિભાગોની મુલાકાત લો.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// એક ક્ષેત્ર સાથેનું સ્ટ્રક્ટ જે સ્ટ્રક્ટને ડિફરન્સ કરીને .ક્સેસિબલ છે.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ડિરેફરન્સ પછી પરિણામી પ્રકાર.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// મૂલ્યનો સંદર્ભ આપે છે.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// પરિવર્તનીય ડિરેફરન્સિંગ કામગીરી માટે વપરાય છે, જેમ કે `*v = 1;`.
///
/// પરિવર્તનીય સંદર્ભમાં (unary) `*` operatorપરેટર સાથે સ્પષ્ટ ડિરેફરન્સિંગ કામગીરી માટે ઉપયોગ કરવા ઉપરાંત, `DerefMut` નો ઉપયોગ ઘણા સંજોગોમાં કમ્પાઇલર દ્વારા પણ સ્પષ્ટ રીતે કરવામાં આવે છે.
/// આ પદ્ધતિને ['`Deref` coercion'][more] કહેવામાં આવે છે.
/// પરિવર્તનશીલ સંદર્ભોમાં, [`Deref`] નો ઉપયોગ થાય છે.
///
/// સ્માર્ટ પોઇંટર્સ માટે `DerefMut` અમલમાં મૂકવું તેમની પાછળનો ડેટા પરિવર્તિત કરવાનું અનુકૂળ બનાવે છે, તેથી જ તેઓ `DerefMut` લાગુ કરે છે.
/// બીજી બાજુ, [`Deref`] અને `DerefMut` સંબંધિત નિયમો સ્માર્ટ પોઇંટરોને સમાવવા માટે ખાસ બનાવવામાં આવ્યા હતા.
/// આને કારણે,**મૂંઝવણ ટાળવા માટે** re ડેરેફમુટે ફક્ત સ્માર્ટ પોઇંટર્સ ** માટે જ અમલમાં મૂકવા જોઈએ.
///
/// સમાન કારણોસર,**આ trait ક્યારેય નિષ્ફળ થવું જોઈએ નહીં**.ડિરેફરન્સ દરમિયાન નિષ્ફળતા એ ખૂબ જ મૂંઝવણભરી થઈ શકે છે જ્યારે એક્સ 100 એક્સ ગર્ભિત રીતે બોલાવવામાં આવે છે.
///
/// # `Deref` જબરદસ્તી પર વધુ
///
/// જો `T` એ `DerefMut<Target = U>` લાગુ કરે છે, અને `x` એ `T` પ્રકારનું મૂલ્ય છે, તો:
///
/// * પરિવર્તનશીલ સંદર્ભોમાં, `*x` (જ્યાં `T` એ સંદર્ભ અથવા કાચો નિર્દેશક નથી) એ `* DerefMut::deref_mut(&mut x)` ની સમકક્ષ છે.
/// * પ્રકાર `&mut T` ના મૂલ્યો, `&mut U` પ્રકારનાં મૂલ્યો સાથે દબાણ કરવામાં આવે છે
/// * `T` `U` પ્રકારની બધી (mutable) પદ્ધતિઓને સ્પષ્ટપણે લાગુ કરે છે.
///
/// વધુ વિગતો માટે, [the chapter in *The Rust Programming Language*][book] ની સાથે સાથે [the dereference operator][ref-deref-op], [method resolution] અને [type coercions] પરના સંદર્ભ વિભાગોની મુલાકાત લો.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// એક જ ક્ષેત્ર સાથેનો સ્ટ્રક્ટ જે સ્ટ્રક્ટને ડિફરન્સ કરીને સુધારી શકાય તેવો છે.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// પરિવર્તન મૂલ્યનો સંદર્ભ લે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// સૂચવે છે કે સ્ટ્ર structક્ટનો ઉપયોગ `arbitrary_self_types` સુવિધા વિના પદ્ધતિ રીસીવર તરીકે થઈ શકે છે.
///
/// Xd1X, `Rc<T>`, `&T` અને `Pin<P>` જેવા stdlib પોઇન્ટર પ્રકારો દ્વારા આનો અમલ કરવામાં આવે છે.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}