/// પરિવર્તનશીલ સંદર્ભોમાં (`container[index]`) ને અનુક્રમણિકા કરવા માટે વપરાય છે.
///
/// `container[index]` તે ખરેખર `*container.index(index)` માટે સિંટેક્ટિક સુગર છે, પરંતુ માત્ર ત્યારે જ જ્યારે અચૂક મૂલ્ય તરીકે ઉપયોગ થાય છે.
/// જો પરિવર્તનશીલ મૂલ્યની વિનંતી કરવામાં આવે છે, તો તેના બદલે [`IndexMut`] નો ઉપયોગ કરવામાં આવશે.
/// જો `value` નો પ્રકાર [`Copy`] ને લાગુ કરે છે તો `let value = v[index]` જેવી સરસ વસ્તુઓની મંજૂરી આપે છે.
///
/// # Examples
///
/// નીચે આપેલ ઉદાહરણ `Index` ને ફક્ત વાંચવા માટેના `NucleotideCount` કન્ટેનર પર લાગુ કરે છે, વ્યક્તિગત ગણતરીઓને અનુક્રમણિકા વાક્યરચના સાથે પુન .પ્રાપ્ત કરવા માટે સક્ષમ કરે છે.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// અનુક્રમણિકા પછી પરત પ્રકાર.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// અનુક્રમણિકા (`container[index]`) ઓપરેશન કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// પરિવર્તનશીલ સંદર્ભોમાં (`container[index]`) ને અનુક્રમણિકા કરવા માટે વપરાય છે.
///
/// `container[index]` ખરેખર એ `*container.index_mut(index)` માટે સિંટેક્ટિક સુગર છે, પરંતુ ફક્ત ત્યારે જ જ્યારે પરિવર્તનશીલ મૂલ્ય તરીકે ઉપયોગ થાય છે.
/// જો કોઈ પરિવર્તનશીલ મૂલ્યની વિનંતી કરવામાં આવે તો, તેના બદલે [`Index`] trait નો ઉપયોગ થાય છે.
/// આ `v[index] = value` જેવી સરસ વસ્તુઓની મંજૂરી આપે છે.
///
/// # Examples
///
/// `Balance` સ્ટ્રક્ટનું એક ખૂબ સરળ અમલીકરણ જેમાં બે બાજુઓ હોય છે, જ્યાં દરેકને પરિવર્તનીય અને સ્થાનાંતરિત કરી શકાય છે.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // આ કિસ્સામાં, `balance[Side::Right]` એ `*balance.index(Side::Right)` માટે ખાંડ છે, કારણ કે આપણે ફક્ત* વાંચી રહ્યા છીએ * `balance[Side::Right]`, તે લખી રહ્યા નથી.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // જો કે, આ કિસ્સામાં `balance[Side::Left]` એ `*balance.index_mut(Side::Left)` માટે ખાંડ છે, કારણ કે આપણે `balance[Side::Left]` લખી રહ્યા છીએ.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// પરિવર્તનીય અનુક્રમણિકા (`container[index]`) ઓપરેશન કરે છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}