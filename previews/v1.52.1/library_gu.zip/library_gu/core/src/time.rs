#![stable(feature = "duration_core", since = "1.25.0")]

//! વૈશ્વિક જથ્થો.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // બંને ઘોષણા સમાન છે
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// સમયગાળાને રજૂ કરવા માટેનો એક `Duration` પ્રકાર, સામાન્ય રીતે સિસ્ટમ ટાઇમઆઉટ માટે વપરાય છે.
///
/// દરેક `Duration` એ સંપૂર્ણ સંખ્યામાં સેકંડ અને નેનોસેકંડમાં રજૂ કરેલા અપૂર્ણાંક ભાગથી બનેલો છે.
/// જો અંતર્ગત સિસ્ટમ નેનોસેકન્ડ-સ્તરની ચોકસાઇને ટેકો આપતી નથી, તો સિસ્ટમ ટાઇમઆઉટને બંધનકર્તા એપીઆઇ સામાન્ય રીતે નેનોસેકન્ડ્સની સંખ્યા વધારશે.
///
/// [`અવધિ] એ [`Add`], [`Sub`], અને અન્ય [`ops`] traits સહિત ઘણા સામાન્ય traits લાગુ કરે છે.તે શૂન્ય-લંબાઈના `Duration` પરત કરીને [`Default`] લાગુ કરે છે.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # ફોર્મેટિંગ `Duration` મૂલ્યો
///
/// `Duration` ઇરાદાપૂર્વક એક `Display` પ્રોમ્પ્ટ હોતી નથી, કારણ કે માનવ વાંચનક્ષમતા માટે સમયના વિવિધ સ્ત્રોતોને ફોર્મેટ કરવાની વિવિધ રીતો છે.
/// `Duration` `Debug` પ્રોત્સાહન પ્રદાન કરે છે જે મૂલ્યની સંપૂર્ણ ચોકસાઇ બતાવે છે.
///
/// `Debug` આઉટપુટ માઇક્રોસેકન્ડ્સ માટે નોન-ASCII "µs" પ્રત્યયનો ઉપયોગ કરે છે.
/// જો તમારું પ્રોગ્રામ આઉટપુટ એવા સંદર્ભમાં દેખાઈ શકે છે કે જે સંપૂર્ણ યુનિકોડ સુસંગતતા પર વિશ્વાસ કરી શકતા નથી, તો તમે `Duration` yourselfબ્જેક્ટ્સને જાતે ફોર્મેટ કરવા અથવા ઝેડ 0 ક્રેટ 0 ઝેડનો ઉપયોગ કરી શકો છો.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // હંમેશા 0 <=નેનોઝ <NANOS_PER_SEC
}

impl Duration {
    /// એક સેકંડનો સમયગાળો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// એક મિલિસેકંડનો સમયગાળો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// એક માઇક્રોસેકન્ડની અવધિ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// એક નેનોસેકંડનો સમયગાળો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// શૂન્ય સમયનો સમયગાળો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// મહત્તમ સમયગાળો.
    ///
    /// તે 584,942,417,355 વર્ષના સમયગાળાની જેટલી સમાન છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// સંપૂર્ણ સેકંડ અને અતિરિક્ત નેનોસેકન્ડ્સની ઉલ્લેખિત સંખ્યામાંથી એક નવો `Duration` બનાવે છે.
    ///
    /// જો નેનોસેકન્ડ્સની સંખ્યા 1 અબજ (એક સેકન્ડમાં નેનોસેકંડની સંખ્યા) કરતા વધારે છે, તો તે પૂરી પાડવામાં આવેલી સેકંડમાં આગળ વધશે.
    ///
    ///
    /// # Panics
    ///
    /// આ કન્સ્ટ્રક્ટર ઝેડપpanનિકિક ઝેડ ઝેડ કરશે જો નેનોસેકન્ડ્સથી લઇને સેકન્ડ્સ કાઉન્ટરને ઓવરફ્લો કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// સંપૂર્ણ સેકંડની ઉલ્લેખિત સંખ્યામાંથી એક નવો `Duration` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// મિલિસેકન્ડની ઉલ્લેખિત સંખ્યામાંથી એક નવો `Duration` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// માઇક્રોસેકન્ડ્સની ઉલ્લેખિત સંખ્યામાંથી એક નવો `Duration` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// નેનોસેકન્ડ્સની ઉલ્લેખિત સંખ્યામાંથી એક નવો `Duration` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// જો આ `Duration` સમય નહીં લગાવે તો સાચું પરત આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// આ `Duration` દ્વારા સમાયેલ _whole_ સેકંડની સંખ્યા પરત કરે છે.
    ///
    /// પરત કરેલ મૂલ્યમાં અવધિના અપૂર્ણાંક (nanosecond) ભાગ શામેલ નથી, જે [`subsec_nanos`] નો ઉપયોગ કરીને મેળવી શકાય છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` દ્વારા રજૂ કરાયેલ કુલ સેકંડની સંખ્યા નક્કી કરવા માટે, [`subsec_nanos`] સાથે સંયોજનમાં `as_secs` નો ઉપયોગ કરો:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// આ `Duration` નો અપૂર્ણાંક ભાગ, આખા મિલિસેકંડમાં પરત કરે છે.
    ///
    /// જ્યારે આ મિલિસેકન્ડ દ્વારા રજૂ કરવામાં આવે છે ત્યારે આ પદ્ધતિ **નથી** અવધિની લંબાઈ પરત કરે છે.
    /// પરત થયેલ સંખ્યા હંમેશાં બીજાના અપૂર્ણાંક ભાગનું પ્રતિનિધિત્વ કરે છે (એટલે કે, તે એક હજારથી ઓછું છે).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// આ માઇક્રોસેકન્ડ્સમાં, આ `Duration` ના અપૂર્ણાંક ભાગ પરત કરે છે.
    ///
    /// માઇક્રોસેકન્ડ્સ દ્વારા રજૂ કરવામાં આવે ત્યારે આ પદ્ધતિ **નહીં** કરે છે.
    /// પરત થયેલ સંખ્યા હંમેશાં સેકંડનો અપૂર્ણાંક ભાગ રજૂ કરે છે (એટલે કે, તે એક મિલિયન કરતા ઓછી છે).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// નેનોસેકન્ડ્સમાં, આ `Duration` ના અપૂર્ણાંક ભાગ પરત કરે છે.
    ///
    /// આ પદ્ધતિ **નહીં** કરે છે જ્યારે નેનોસેકંડ દ્વારા રજૂ કરવામાં આવે ત્યારે તે સમયગાળાની લંબાઈ પરત નહીં કરે.
    /// પરત થયેલ સંખ્યા હંમેશાં સેકંડનો અપૂર્ણાંક ભાગ રજૂ કરે છે (એટલે કે, તે એક અબજથી ઓછી છે).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// આ `Duration` દ્વારા સમાયેલ સંપૂર્ણ મિલિસેકન્ડની કુલ સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// આ `Duration` દ્વારા સમાયેલ સંપૂર્ણ માઇક્રોસેકન્ડ્સની કુલ સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// આ `Duration` દ્વારા સમાયેલી નેનોસેકંડની કુલ સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` ઉમેરો ચકાસાયેલ.
    /// ગણતરીઓ `self + other`, જો ઓવરફ્લો થયો હોય તો [`None`] પાછા ફરો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// સંતૃપ્તિંગ `Duration` ઉમેરો.
    /// ગણતરીઓ `self + other`, જો ઓવરફ્લો થયો હોય તો [`Duration::MAX`] પાછા ફરો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` બાદબાકી તપાસી.
    /// ગણતરીઓ `self - other`, જો પરિણામ નકારાત્મક હશે અથવા જો ઓવરફ્લો થયો હોય તો [`None`] પરત ફરો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// સuraચ્યુરેટિંગ `Duration` બાદબાકી.
    /// ગણતરીઓ `self - other`, જો પરિણામ નકારાત્મક હશે અથવા જો ઓવરફ્લો થયો હોય તો [`Duration::ZERO`] પરત ફરો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` ગુણાકાર ચકાસાયેલ.
    /// ગણતરીઓ `self * other`, જો ઓવરફ્લો થયો હોય તો [`None`] પાછા ફરો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // નેસોસેકન્ડ્સને u64 તરીકે ગુણાકાર કરો, કારણ કે તે તે રીતે ઓવરફ્લો કરી શકતું નથી.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// સuraચ્યુરેટિંગ `Duration` ગુણાકાર.
    /// ગણતરીઓ `self * other`, જો ઓવરફ્લો થયો હોય તો [`Duration::MAX`] પાછા ફરો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` વિભાગ તપાસી.
    /// `self / other` ની ગણતરીઓ, [`None`] પરત જો `other == 0`.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// આ `Duration` દ્વારા સમાયેલી સેકંડની સંખ્યાને `f64` તરીકે પરત કરે છે.
    /// પરત કરેલ મૂલ્યમાં અવધિના અપૂર્ણાંક (nanosecond) ભાગ શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// આ `Duration` દ્વારા સમાયેલી સેકંડની સંખ્યાને `f32` તરીકે પરત કરે છે.
    /// પરત કરેલ મૂલ્યમાં અવધિના અપૂર્ણાંક (nanosecond) ભાગ શામેલ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` તરીકે રજૂ કરેલી સેકંડની ઉલ્લેખિત સંખ્યામાંથી નવો `Duration` બનાવે છે.
    ///
    /// # Panics
    /// જો `secs` મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લો `Duration` ન હોય તો આ કન્સ્ટ્રક્ટર panic કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` તરીકે રજૂ કરેલી સેકંડની ઉલ્લેખિત સંખ્યામાંથી નવો `Duration` બનાવે છે.
    ///
    /// # Panics
    /// જો `secs` મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લો `Duration` ન હોય તો આ કન્સ્ટ્રક્ટર panic કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` દ્વારા ગુણાકાર `Duration`.
    /// # Panics
    /// જો પરિણામ મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લોઝ `Duration` ન આવે તો આ પદ્ધતિ ઝેડપૈનિક 0 ઝેડ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` દ્વારા ગુણાકાર `Duration`.
    /// # Panics
    /// જો પરિણામ મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લોઝ `Duration` ન આવે તો આ પદ્ધતિ ઝેડપૈનિક 0 ઝેડ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // નોંધ લો કે રાઉન્ડિંગ એરરને લીધે પરિણામ 8.478 અને 847800.0 કરતા થોડું અલગ છે
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `f64` ને `f64` દ્વારા વહેંચો.
    /// # Panics
    /// જો પરિણામ મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લોઝ `Duration` ન આવે તો આ પદ્ધતિ ઝેડપૈનિક 0 ઝેડ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // નોંધ લો કે કાપવાનો ઉપયોગ રાઉન્ડિંગ નહીં
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `f32` ને `f32` દ્વારા વહેંચો.
    /// # Panics
    /// જો પરિણામ મર્યાદિત, નકારાત્મક અથવા ઓવરફ્લોઝ `Duration` ન આવે તો આ પદ્ધતિ ઝેડપૈનિક 0 ઝેડ કરશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // નોંધ લો કે રાઉન્ડિંગ એરરને લીધે પરિણામ 0.859_872_611 કરતા થોડું અલગ છે
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // નોંધ લો કે કાપવાનો ઉપયોગ રાઉન્ડિંગ નહીં
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` ને `Duration` દ્વારા વહેંચો અને `f64` પરત કરો.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` ને `Duration` દ્વારા વહેંચો અને `f32` પરત કરો.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// દશાંશ નોટેશનમાં ફ્લોટિંગ પોઇન્ટ નંબર ફોર્મેટ કરે છે.
        ///
        /// નંબર `integer_part` અને અપૂર્ણાંક ભાગ તરીકે આપવામાં આવે છે.
        /// અપૂર્ણાંક ભાગનું મૂલ્ય `fractional_part / divisor` છે.
        /// તેથી `integer_part` =3, `fractional_part` =12 અને `divisor` =100 એ `3.012` નંબર રજૂ કરે છે.
        /// ટ્રેલિંગ ઝીરો છોડી દેવાયા છે.
        ///
        /// `divisor` 100_000_000 થી ઉપર ન હોવું જોઈએ.
        /// તે 10 ની શક્તિ પણ હોવી જોઈએ, બાકીનું બધું અર્થમાં નથી.
        /// `fractional_part` `10 * divisor` કરતા ઓછું હોવું જોઈએ!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // અપૂર્ણાંક ભાગને અસ્થાયી બફરમાં એન્કોડ કરો.
            // બફરને ફક્ત 9 તત્વો રાખવાની જરૂર છે, કારણ કે `fractional_part` 10 ^ 9 કરતા ઓછું હોવું જોઈએ.
            //
            // બફરને નીચેના કોડને સરળ બનાવવા માટે '0' અંકોથી પ્રિફિલ્ડ છે.
            let mut buf = [b'0'; 9];

            // આગળનો અંક આ સ્થિતિ પર લખાયેલ છે
            let mut pos = 0;

            // જ્યારે શૂન્ય ન હોય તેવા અંક બાકી છે ત્યારે અમે બફરમાં અંકો લખતા રહીએ છીએ અને અમે હજી પૂરતા અંકો લખ્યા નથી.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // બફરમાં નવો અંક લખો
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // જો ચોકસાઇ <<સ્પષ્ટ થયેલ હોય, તો ત્યાં કેટલાક બિન-શૂન્ય અંકો બાકી હોઈ શકે છે જે બફરમાં લખાયેલા ન હતા.
            // તે કિસ્સામાં અમારે સામાન્ય ફ્લોટિંગ પોઇન્ટ નંબરો છાપવાના અર્થશાસ્ત્ર સાથે મેળ ખાતી રાઉન્ડિંગ કરવાની જરૂર છે.
            // જો કે, અમારે ફક્ત કામ કરવાની જરૂર છે જ્યારે રાઉન્ડ અપ કરીએ.
            // આવું થાય છે જો બાકીના પ્રથમ અંક>>=5 હોય.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // બફરમાં સમાવિષ્ટ સંખ્યાને ગોળાકાર કરો.
                // અમે બફર દ્વારા પાછળની બાજુએ જઈએ છીએ અને વહનનો ટ્ર .ક રાખીએ છીએ.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // જો બફરમાંનો અંક '9' ન હોય, તો આપણે તેને વધારવાની જરૂર છે અને પછી અટકી શકીએ છીએ (કેમ કે હવે આપણી પાસે ઉપહારો નથી).
                    // નહિંતર, અમે તેને '0' (overflow) પર સેટ કર્યું છે અને ચાલુ રાખીએ છીએ.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // જો અમારી પાસે હજી પણ કેરી બિટ સેટ છે, તો તેનો અર્થ એ કે આપણે આખું બફર '0' પર સેટ કર્યું છે અને પૂર્ણાંકના ભાગને વધારવાની જરૂર છે.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // બફરનો અંત નક્કી કરો: જો ચોકસાઇ સેટ હોય, તો અમે ફક્ત બફરથી ઘણા અંકોનો ઉપયોગ કરીએ છીએ (9 થી કેપ્ડ).
            // જો તે સેટ કરેલું નથી, તો આપણે ફક્ત છેલ્લા અ-શૂન્ય સુધીના બધા અંકોનો ઉપયોગ કરીશું.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // જો આપણે એક જ અપૂર્ણાંક અંકનું ઉત્સર્જન કર્યું નથી અને ચોકસાઇ કોઈ બિન-શૂન્ય મૂલ્ય પર સેટ કરી નથી, તો અમે દશાંશ બિંદુને છાપતા નથી.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // સલામતી: અમે ફક્ત બફરમાં ASCII અંકો લખી રહ્યા છીએ અને તે હતું
                // '0's' સાથે પ્રારંભ કરી, તેથી તેમાં માન્ય UTF8 શામેલ છે.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // જો વપરાશકર્તા ચોકસાઇ> 9 માટે વિનંતી કરે છે, તો આપણે અંતમાં 0 'પેડ કરીએ છીએ.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // વિનંતી કરવામાં આવે તો અગ્રણી '+' સાઇન છાપો
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}