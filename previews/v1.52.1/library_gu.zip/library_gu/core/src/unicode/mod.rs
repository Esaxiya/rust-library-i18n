#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) નું સંસ્કરણ કે જે `char` અને `str` પદ્ધતિઓના યુનિકોડ ભાગો આધારિત છે.
///
/// યુનિકોડના નવા સંસ્કરણો નિયમિતરૂપે પ્રકાશિત થાય છે અને ત્યારબાદ યુનિકોડના આધારે માનક લાઇબ્રેરીની બધી પદ્ધતિઓ અપડેટ થાય છે.
/// તેથી કેટલીક `char` અને `str` પદ્ધતિઓનું વર્તન અને સમય જતાં આ સતત ફેરફારોનું મૂલ્ય.
/// આને * તૂટી ગયેલો ફેરફાર માનવામાં આવતો નથી.
///
/// સંસ્કરણ નંબર આપવાની યોજના [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) માં સમજાવાયેલ છે.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// લિબોલocકના ઉપયોગ માટે, લિબસ્ટ્ડમાં ફરીથી નિકાસ નહીં.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;