#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! વિદેશી ફંક્શન ઇંટરફેસ (FFI) જોડાણને લગતી ઉપયોગિતાઓ.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// જ્યારે [pointer] તરીકે ઉપયોગમાં લેવાય ત્યારે સીના `void` પ્રકારની સમકક્ષ.
///
/// સારમાં, `*const c_void` એ સીના `const void*` ની સમકક્ષ છે અને `*mut c_void` સીના `void*` ની સમકક્ષ છે.
/// તેણે કહ્યું, આ સીના `void` રીટર્ન ટાઇપ જેવો જ નથી * જે Rust નો `()` પ્રકાર છે.
///
/// એફએફઆઈમાં અપારદર્શક પ્રકારનાં નિર્દેશકોને મોડેલ બનાવવા માટે, જ્યાં સુધી `extern type` સ્થિર ન થાય ત્યાં સુધી, ખાલી બાઇટ એરેની આસપાસ newtype રેપરનો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે.
///
/// વિગતો માટે [Nomicon] જુઓ.
///
/// જો તેઓ 1.1.0 સુધી જૂના Rust કમ્પાઈલરને ટેકો આપવા માંગતા હોય તો એક, `std::os::raw::c_void` નો ઉપયોગ કરી શકે છે.
/// Rust 1.30.0 પછી, આ વ્યાખ્યા દ્વારા તેને ફરીથી નિકાસ કરવામાં આવ્યું.
/// વધુ માહિતી માટે, કૃપા કરીને [RFC 2521] વાંચો.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// એનબી, એલએલવીએમ માટે રદબાતલ પોઇન્ટર પ્રકારને ઓળખવા માટે અને એક્સ 100 એક્સ જેવા એક્સ્ટેંશન ફંક્શન્સ દ્વારા, આપણે તેને એલએલવીએમ બિટકોડમાં આઇ 8 * તરીકે રજૂ કરવાની જરૂર છે.
// અહીં ઉપયોગમાં લેવાતા એનમ આને સુનિશ્ચિત કરે છે અને ફક્ત ખાનગી વેરિયન્ટ્સ રાખીને "raw" પ્રકારનો દુરુપયોગ અટકાવે છે.
// અમને બે ચલોની જરૂર છે, કારણ કે કમ્પાઇલર અન્યથા રેપ લક્ષણ વિશે ફરિયાદ કરે છે અને અમને ઓછામાં ઓછું એક વેરિયન્ટ જોઈએ છે કારણ કે ઇનમ નિર્જન હશે અને ઓછામાં ઓછા આવા પોઇંટર્સને ડિરેફરન્સિંગ યુબી હશે.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` નું મૂળભૂત અમલીકરણ.
// નામ WIP છે, હમણાં માટે `VaListImpl` નો ઉપયોગ કરીને.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` કરતા વધુ આક્રમક છે, તેથી દરેક `VaListImpl<'f>` objectબ્જેક્ટ તે ફંક્શનના ક્ષેત્રમાં જોડાયેલું છે જેમાં તે નિર્ધારિત છે
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` નું ABI અમલીકરણ.
/// વધુ વિગતો માટે [AArch64 Procedure Call Standard] જુઓ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` નું ABI અમલીકરણ.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` નું ABI અમલીકરણ.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` માટે એક રેપર
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ને `VaList` માં રૂપાંતરિત કરો જે સીના `va_list` સાથે દ્વિસંગી સુસંગત છે.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ને `VaList` માં રૂપાંતરિત કરો જે સીના `va_list` સાથે દ્વિસંગી સુસંગત છે.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait નો સાર્વજનિક ઇન્ટરફેસમાં ઉપયોગ કરવો જરૂરી છે, જો કે, trait જાતે આ મોડ્યુલની બહાર વાપરવાની મંજૂરી આપવી જોઈએ નહીં.
// વપરાશકર્તાઓને નવા પ્રકાર માટે ઝેડટ્રેટાઇટ ઝેડને અમલમાં મૂકવાની મંજૂરી આપવી (ત્યાંથી va_arg આંતરિકને નવા પ્રકાર પર વાપરવાની મંજૂરી આપવામાં આવે છે) અસ્પષ્ટ વર્તન થવાની સંભાવના છે.
//
// FIXME(dlrobertson): જાહેર ઇન્ટરફેસમાં VaArgSafe trait નો ઉપયોગ કરવા માટે પણ તે બીજે ક્યાંય ઉપયોગમાં લઇ શકાશે નહીં તેની ખાતરી કરવા માટે, ઝેડટ્રેટ0 ઝેડને ખાનગી મોડ્યુલની અંદર જાહેર કરવાની જરૂર છે.
// એકવાર આર.એફ.સી. 2145 લાગુ કરવામાં આવ્યા પછી આમાં સુધારો લાવવો.
//
//
//
//
mod sealed_trait {
    /// ઝેડ 0 ટ્રાઇટ0 ઝેડ જે [super::VaListImpl::arg] સાથે માન્ય પ્રકારોને વાપરવાની મંજૂરી આપે છે.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// આગલી દલીલ તરફ આગળ વધો.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // સલામતી: કlerલરને `va_arg` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe { va_arg(self) }
    }

    /// વર્તમાન સ્થાન પર `va_list` ની કiesપિ કરે છે.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // સલામતી: કlerલરને `va_end` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // સલામતી: અમે `MaybeUninit` ને લખીએ છીએ, આમ તે આરંભ થયેલ છે અને `assume_init` કાનૂની છે
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: આને `va_end` પર ક .લ કરવો જોઈએ, પરંતુ આનો કોઈ સાફ રસ્તો નથી
        // બાંયધરી આપે છે કે `drop` હંમેશા તેના કlerલરમાં આવે છે, તેથી `va_end` સીધા જ તે જ ફંક્શનથી સંબંધિત `va_copy` તરીકે ક calledલ કરશે.
        // `man va_end` જણાવે છે કે સી ને આ જરૂરી છે, અને એલએલવીએમ મૂળભૂત રીતે સી સિમેંટિક્સને અનુસરે છે, તેથી આપણે એ સુનિશ્ચિત કરવાની જરૂર છે કે `va_end` હંમેશાં `va_copy` જેવા જ ફંક્શનથી બોલાવાય છે.
        //
        // વધુ વિગતો માટે, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // આ હમણાં માટે કાર્ય કરે છે, કારણ કે `va_end` એ બધા વર્તમાન LLVM લક્ષ્યો પર કોઈ વિકલ્પ નથી.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` અથવા `va_copy` સાથે આરંભ પછી આર્ગલિસ્ટ `ap` નાશ કરો.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// આર્ગલિસ્ટ `src` ના વર્તમાન સ્થાનને આર્ગલિસ્ટ `dst` પર કiesપિ કરે છે.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` માંથી `T` પ્રકારની દલીલ લોડ કરે છે અને દલીલ `ap` નિર્દેશ કરે છે તેમાં વધારો કરે છે.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}