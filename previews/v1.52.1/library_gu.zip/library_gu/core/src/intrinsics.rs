//! કમ્પાઇલર આંતરિક.
//!
//! અનુરૂપ વ્યાખ્યાઓ `compiler/rustc_codegen_llvm/src/intrinsic.rs` માં છે.
//! સંબંધિત કોન્સ્ટન્ટ અમલીકરણો `compiler/rustc_mir/src/interpret/intrinsics.rs` માં છે
//!
//! # કોન્સ્ટ ઇન્ટર્નિક્સ
//!
//! Note: આંતરરાષ્ટ્રિયતાના સ્થિરતામાં કોઈપણ ફેરફારોની ભાષા ટીમ સાથે ચર્ચા થવી જોઈએ.
//! આમાં સ્થિરતાની સ્થિરતામાં ફેરફાર શામેલ છે.
//!
//! કમ્પાઈલ-ટાઇમ પર આંતરિક ઉપયોગી બનાવવા માટે, કોઈએ <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> થી `compiler/rustc_mir/src/interpret/intrinsics.rs` પરના અમલીકરણની નકલ કરવાની જરૂર છે અને એક `#[rustc_const_unstable(feature = "foo", issue = "01234")]` આંતરિકમાં ઉમેરવાની જરૂર છે.
//!
//!
//! જો આંતરિકનો ઉપયોગ `const fn` માંથી `rustc_const_stable` લક્ષણ સાથે થવો જોઈએ, તો આંતરિકનું લક્ષણ પણ `rustc_const_stable` હોવું જોઈએ.
//! આવા ફેરફારને ટી-લેંગ પરામર્શ વિના ન કરવું જોઈએ, કારણ કે તે ભાષામાં એક લક્ષણ બનાવે છે જે કમ્પાઇલર સપોર્ટ વિના વપરાશકર્તા કોડમાં નકલ કરી શકાતું નથી.
//!
//! # Volatiles
//!
//! વોલેટાઇલ ઇન્ટિન્સિક્સ I/O મેમરી પર કાર્ય કરવાના હેતુથી કામગીરી પ્રદાન કરે છે, જે અન્ય અસ્થિર ઇન્ટિન્સિક્સમાં કમ્પાઇલર દ્વારા ફરીથી ગોઠવવાની ખાતરી આપી નથી.[[volatile]] પર LLVM દસ્તાવેજીકરણ જુઓ.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! અણુ અંતર્ગત મલ્ટિપલ સંભવિત મેમરી ઓર્ડર સાથે મશીન શબ્દો પર સામાન્ય અણુ ક્રિયાઓ પ્રદાન કરે છે.તેઓ ઝેડ 0 સી ++ 0 ઝેડ 11 જેવા સમાન અર્થશાસ્ત્રનું પાલન કરે છે.[[atomics]] પર LLVM દસ્તાવેજીકરણ જુઓ.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! મેમરી ઓર્ડર પર ઝડપી રીફ્રેશર:
//!
//! * લquક પ્રાપ્ત કરવા માટે અવરોધ મેળવો.અનુગામી વાંચન અને અવરોધ અવરોધ પછી થાય છે.
//! * પ્રકાશન, લ reક મુક્ત કરવા માટે અવરોધ.પૂર્વ વાંચન અને લેખન અવરોધ પહેલાં થાય છે.
//! * ક્રમશ consistent સુસંગત, ક્રમિક સુસંગત કામગીરી ક્રમમાં થવાની ખાતરી આપવામાં આવે છે.અણુ પ્રકારો સાથે કામ કરવા માટે આ માનક મોડ છે અને ઝેડ 0 જાવા 0 ઝેડના `volatile` ની બરાબર છે.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// આ આયાતોનો ઉપયોગ ઇન્ટ્રા-ડોક લિંક્સને સરળ બનાવવા માટે કરવામાં આવે છે
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // સલામત: જુઓ `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // એનબી, આ અંતર્ગત કાચા પોઇંટર્સ લે છે કારણ કે તેઓ એલિએઝ્ડ મેમરીને પરિવર્તિત કરે છે, જે `&` અથવા `&mut` ક્યાં માટે માન્ય નથી.
    //

    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Acquire`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Acquire`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Acquire`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ,[`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા, `success` અને `failure` બંને પરિમાણો તરીકે ઉપલબ્ધ છે.
    ///
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Acquire`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// જો વર્તમાન મૂલ્ય `old` મૂલ્ય જેટલું જ હોય તો મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] એક્સ પદ્ધતિ દ્વારા `compare_exchange_weak` પદ્ધતિ દ્વારા `success` અને `failure` પરિમાણો તરીકે [`Ordering::Relaxed`] પસાર કરીને [`atomic`] પ્રકારો પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// નિર્દેશકનું વર્તમાન મૂલ્ય લોડ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `load` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// નિર્દેશકનું વર્તમાન મૂલ્ય લોડ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `load` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// નિર્દેશકનું વર્તમાન મૂલ્ય લોડ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `load` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `store` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `store` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `store` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// જુના મૂલ્યને પરત કરીને, ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `swap` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// જુના મૂલ્યને પરત કરીને, ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `swap` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// જુના મૂલ્યને પરત કરીને, ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `swap` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// જુના મૂલ્યને પરત કરીને, ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `swap` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// જુના મૂલ્યને પરત કરીને, ઉલ્લેખિત મેમરી સ્થાન પર મૂલ્ય સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `swap` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_add` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_add` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_add` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_add` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_add` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_sub` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_sub` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_sub` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_sub` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_sub` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// બિટવાઇઝ અને વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_and` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અને વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_and` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અને વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_and` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અને વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_and` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અને વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_and` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// હાલના મૂલ્ય સાથે બિટવાઇઝ નેન્ડ, પાછલા મૂલ્યને પરત આપીને.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`AtomicBool`] પ્રકાર પર `order` એક્સ દ્વારા `order` તરીકે પસાર કરીને [`AtomicBool`] પ્રકાર પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// હાલના મૂલ્ય સાથે બિટવાઇઝ નેન્ડ, પાછલા મૂલ્યને પરત આપીને.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`AtomicBool`] પ્રકાર પર `order` એક્સ દ્વારા `order` તરીકે પસાર કરીને [`AtomicBool`] પ્રકાર પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// હાલના મૂલ્ય સાથે બિટવાઇઝ નેન્ડ, પાછલા મૂલ્યને પરત આપીને.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`AtomicBool`] પ્રકાર પર `order` એક્સ દ્વારા `order` તરીકે પસાર કરીને [`AtomicBool`] પ્રકાર પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// હાલના મૂલ્ય સાથે બિટવાઇઝ નેન્ડ, પાછલા મૂલ્યને પરત આપીને.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`AtomicBool`] પ્રકાર પર `order` એક્સ દ્વારા `order` તરીકે પસાર કરીને [`AtomicBool`] પ્રકાર પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// હાલના મૂલ્ય સાથે બિટવાઇઝ નેન્ડ, પાછલા મૂલ્યને પરત આપીને.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`AtomicBool`] પ્રકાર પર `order` એક્સ દ્વારા `order` તરીકે પસાર કરીને [`AtomicBool`] પ્રકાર પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// બિટવાઇઝ અથવા વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_or` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અથવા વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_or` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અથવા વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_or` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અથવા વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_or` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// બિટવાઇઝ અથવા વર્તમાન મૂલ્ય સાથે, પાછલું મૂલ્ય પાછું.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_or` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ ઝોર, પાછલા મૂલ્યને પરત કરી રહ્યું છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_xor` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ ઝોર, પાછલા મૂલ્યને પરત કરી રહ્યું છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_xor` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ ઝોર, પાછલા મૂલ્યને પરત કરી રહ્યું છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_xor` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ ઝોર, પાછલા મૂલ્યને પરત કરી રહ્યું છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_xor` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ ઝોર, પાછલા મૂલ્યને પરત કરી રહ્યું છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] પ્રકારો પર `fetch_xor` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી કરેલી તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સાઇન ઇન પૂર્ણાંકો પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_min` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// સહી વિનાની તુલનાનો ઉપયોગ કરીને વર્તમાન મૂલ્ય સાથે મહત્તમ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic`] સહી વગરના પૂર્ણાંક પ્રકારો પર `fetch_max` પદ્ધતિ દ્વારા `order` ને `order` તરીકે પસાર કરીને ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// જો આધારભૂત હોય તો, પ્રીફેચ સૂચના દાખલ કરવા માટે કોડ જનરેટર માટે `prefetch` ઇન્ટિન્સિક એક સંકેત છે;નહિંતર, તે કોઈ વિકલ્પ નથી.
    /// પ્રીફેચેસનો પ્રોગ્રામની વર્તણૂક પર કોઈ અસર હોતી નથી પરંતુ તેની કામગીરીની લાક્ષણિકતાઓ બદલી શકે છે.
    ///
    /// `locality` દલીલ એક સ્થિર પૂર્ણાંક હોવી આવશ્યક છે અને તે (0), કોઈ સ્થાન નહીં, (3) સુધી, સ્થાનિકમાં ક cશમાં રહેવું તે અસ્થાયી સ્થાનિકતા સ્પષ્ટીકરણ છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// જો આધારભૂત હોય તો, પ્રીફેચ સૂચના દાખલ કરવા માટે કોડ જનરેટર માટે `prefetch` ઇન્ટિન્સિક એક સંકેત છે;નહિંતર, તે કોઈ વિકલ્પ નથી.
    /// પ્રીફેચેસનો પ્રોગ્રામની વર્તણૂક પર કોઈ અસર હોતી નથી પરંતુ તેની કામગીરીની લાક્ષણિકતાઓ બદલી શકે છે.
    ///
    /// `locality` દલીલ એક સ્થિર પૂર્ણાંક હોવી આવશ્યક છે અને તે (0), કોઈ સ્થાન નહીં, (3) સુધી, સ્થાનિકમાં ક cશમાં રહેવું તે અસ્થાયી સ્થાનિકતા સ્પષ્ટીકરણ છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// જો આધારભૂત હોય તો, પ્રીફેચ સૂચના દાખલ કરવા માટે કોડ જનરેટર માટે `prefetch` ઇન્ટિન્સિક એક સંકેત છે;નહિંતર, તે કોઈ વિકલ્પ નથી.
    /// પ્રીફેચેસનો પ્રોગ્રામની વર્તણૂક પર કોઈ અસર હોતી નથી પરંતુ તેની કામગીરીની લાક્ષણિકતાઓ બદલી શકે છે.
    ///
    /// `locality` દલીલ એક સ્થિર પૂર્ણાંક હોવી આવશ્યક છે અને તે (0), કોઈ સ્થાન નહીં, (3) સુધી, સ્થાનિકમાં ક cશમાં રહેવું તે અસ્થાયી સ્થાનિકતા સ્પષ્ટીકરણ છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// જો આધારભૂત હોય તો, પ્રીફેચ સૂચના દાખલ કરવા માટે કોડ જનરેટર માટે `prefetch` ઇન્ટિન્સિક એક સંકેત છે;નહિંતર, તે કોઈ વિકલ્પ નથી.
    /// પ્રીફેચેસનો પ્રોગ્રામની વર્તણૂક પર કોઈ અસર હોતી નથી પરંતુ તેની કામગીરીની લાક્ષણિકતાઓ બદલી શકે છે.
    ///
    /// `locality` દલીલ એક સ્થિર પૂર્ણાંક હોવી આવશ્યક છે અને તે (0), કોઈ સ્થાન નહીં, (3) સુધી, સ્થાનિકમાં ક cશમાં રહેવું તે અસ્થાયી સ્થાનિકતા સ્પષ્ટીકરણ છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// એક અણુ વાડ.
    ///
    /// [`Ordering::SeqCst`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    pub fn atomic_fence();
    /// એક અણુ વાડ.
    ///
    /// [`Ordering::Acquire`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    pub fn atomic_fence_acq();
    /// એક અણુ વાડ.
    ///
    /// [`Ordering::Release`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    pub fn atomic_fence_rel();
    /// એક અણુ વાડ.
    ///
    /// [`Ordering::AcqRel`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// એક કમ્પાઇલર-ફક્ત મેમરી અવરોધ.
    ///
    /// કમ્પાઇલર દ્વારા આ અવરોધમાં મેમરી cesક્સેસ ક્યારેય ફરીથી ગોઠવવામાં આવશે નહીં, પરંતુ તેના માટે કોઈ સૂચનાઓ બહાર કા .વામાં આવશે નહીં.
    /// તે સમાન થ્રેડ પરના ઓપરેશન્સ માટે યોગ્ય છે જે અસ્તિત્વમાં હોઈ શકે છે, જેમ કે સિગ્નલ હેન્ડલર્સ સાથે વાતચીત કરતી વખતે.
    ///
    /// [`Ordering::SeqCst`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::compiler_fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// એક કમ્પાઇલર-ફક્ત મેમરી અવરોધ.
    ///
    /// કમ્પાઇલર દ્વારા આ અવરોધમાં મેમરી cesક્સેસ ક્યારેય ફરીથી ગોઠવવામાં આવશે નહીં, પરંતુ તેના માટે કોઈ સૂચનાઓ બહાર કા .વામાં આવશે નહીં.
    /// તે સમાન થ્રેડ પરના ઓપરેશન્સ માટે યોગ્ય છે જે અસ્તિત્વમાં હોઈ શકે છે, જેમ કે સિગ્નલ હેન્ડલર્સ સાથે વાતચીત કરતી વખતે.
    ///
    /// [`Ordering::Acquire`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::compiler_fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// એક કમ્પાઇલર-ફક્ત મેમરી અવરોધ.
    ///
    /// કમ્પાઇલર દ્વારા આ અવરોધમાં મેમરી cesક્સેસ ક્યારેય ફરીથી ગોઠવવામાં આવશે નહીં, પરંતુ તેના માટે કોઈ સૂચનાઓ બહાર કા .વામાં આવશે નહીં.
    /// તે સમાન થ્રેડ પરના ઓપરેશન્સ માટે યોગ્ય છે જે અસ્તિત્વમાં હોઈ શકે છે, જેમ કે સિગ્નલ હેન્ડલર્સ સાથે વાતચીત કરતી વખતે.
    ///
    /// [`Ordering::Release`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::compiler_fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// એક કમ્પાઇલર-ફક્ત મેમરી અવરોધ.
    ///
    /// કમ્પાઇલર દ્વારા આ અવરોધમાં મેમરી cesક્સેસ ક્યારેય ફરીથી ગોઠવવામાં આવશે નહીં, પરંતુ તેના માટે કોઈ સૂચનાઓ બહાર કા .વામાં આવશે નહીં.
    /// તે સમાન થ્રેડ પરના ઓપરેશન્સ માટે યોગ્ય છે જે અસ્તિત્વમાં હોઈ શકે છે, જેમ કે સિગ્નલ હેન્ડલર્સ સાથે વાતચીત કરતી વખતે.
    ///
    /// [`Ordering::AcqRel`] ને `order` તરીકે પસાર કરીને, આ આંતરિકનું સ્થિર સંસ્કરણ [`atomic::compiler_fence`] માં ઉપલબ્ધ છે.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// જાદુઈ આંતરિક કે જેનો અર્થ ફંકશન સાથે જોડાયેલા ગુણોથી મળે છે.
    ///
    /// ઉદાહરણ તરીકે, ડેટાફ્લો આનો ઉપયોગ સ્થિર નિવેદનોને ઇન્જેક્ટ કરવા માટે કરે છે જેથી `rustc_peek(potentially_uninitialized)` ખરેખર ડબલ-તપાસ કરશે કે ડેટાફ્લોએ ખરેખર ગણતરી કરી છે કે તે નિયંત્રણના પ્રવાહમાં તે સ્થાને અનઇટિટાઈઝ્ડ છે.
    ///
    ///
    /// આ આંતરિક કમ્પાઇલરની બહારનો ઉપયોગ કરવો જોઈએ નહીં.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// પ્રક્રિયાના અમલીકરણને અટકાવે છે.
    ///
    /// આ operationપરેશનનું વધુ વપરાશકર્તા મૈત્રીપૂર્ણ અને સ્થિર સંસ્કરણ એ [`std::process::abort`](../../std/process/fn.abort.html) છે.
    ///
    pub fn abort() -> !;

    /// ઓપ્ટિમાઇઝરને જણાવે છે કે કોડમાં આ બિંદુ પહોંચી શકાય તેવું નથી, વધુ optimપ્ટિમાઇઝેશનને સક્ષમ કરે છે.
    ///
    /// એનબી, તે `unreachable!()` મcક્રોથી ખૂબ જ અલગ છે: મેક્રોથી વિપરીત, જે ઝેડપpanનિક્સ 0 ઝેડ એક્ઝેક્યુટ થાય ત્યારે, આ ફંક્શન સાથે ચિહ્નિત કોડ સુધી પહોંચવું *અસ્પષ્ટ વર્તન* છે.
    ///
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) છે.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Optimપ્ટિમાઇઝરને માહિતી આપે છે કે શરત હંમેશાં સાચી હોય છે.
    /// જો સ્થિતિ ખોટી છે, તો વર્તન અસ્પષ્ટ છે.
    ///
    /// આ આંતરિક માટે કોઈ કોડ જનરેટ થયો નથી, પરંતુ izerપ્ટિમાઇઝર પાસ (અને તેની સ્થિતિ) ને પાસ વચ્ચે જાળવવાનો પ્રયત્ન કરશે, જે આસપાસના કોડના optimપ્ટિમાઇઝેશનમાં દખલ કરી શકે છે અને પ્રભાવ ઘટાડે છે.
    /// જો theપ્ટિમાઇઝર દ્વારા આક્રમકને તેની જાતે શોધી શકાય છે, અથવા જો તે કોઈ નોંધપાત્ર optimપ્ટિમાઇઝેશનને સક્ષમ કરતું નથી, તો તેનો ઉપયોગ કરવો જોઈએ નહીં.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// સંકેત આપતા સંકેતો કે ઝેડબ્રાંચ 0 ઝેડ સ્થિતિ સાચી હોવાની સંભાવના છે.
    /// તેને પસાર કરેલ કિંમત પરત કરે છે.
    ///
    /// `if` વિધાનો સિવાયના કોઈપણ ઉપયોગની અસર કદાચ નહીં હોય.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// કમ્પાઈલરને સંકેતો છે કે ઝેડબ્રાંચ 0 ઝેડ સ્થિતિ ખોટી હોવાની સંભાવના છે.
    /// તેને પસાર કરેલ કિંમત પરત કરે છે.
    ///
    /// `if` વિધાનો સિવાયના કોઈપણ ઉપયોગની અસર કદાચ નહીં હોય.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ડિબગર દ્વારા નિરીક્ષણ માટે, બ્રેકપોઇન્ટ ટ્રેપ ચલાવે છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn breakpoint();

    /// બાઇટ્સમાં એક પ્રકારનું કદ.
    ///
    /// વધુ ખાસ રીતે, આ એક સમાન પ્રકારની ક્રમિક વસ્તુઓ વચ્ચે બાઇટ્સમાં inફસેટ છે, જેમાં સંરેખણ પેડિંગ શામેલ છે.
    ///
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::mem::size_of`](crate::mem::size_of) છે.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// એક પ્રકારનું ન્યૂનતમ ગોઠવણી.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::mem::align_of`](crate::mem::align_of) છે.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// એક પ્રકારનું પસંદીદા સંરેખણ.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// બાઇટ્સમાં સંદર્ભિત મૂલ્યનું કદ.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`mem::size_of_val`] છે.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// સંદર્ભિત મૂલ્યની આવશ્યક ગોઠવણી.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::mem::align_of_val`](crate::mem::align_of_val) છે.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// પ્રકારનાં નામવાળી સ્થિર શબ્દમાળાની સ્લાઇસ મેળવે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::any::type_name`](crate::any::type_name) છે.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// એક ઓળખાણકર્તા મેળવે છે જે ઉલ્લેખિત પ્રકારથી વૈશ્વિક સ્તરે અનન્ય છે.
    /// આ ફંક્શન કોઈપણ પ્રકારનાં ઝેડ 0 ક્રેટ 0 ઝેડને ધ્યાનમાં લીધા વગર કોઈ પ્રકારનાં સમાન મૂલ્ય પરત કરશે.
    ///
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::any::TypeId::of`](crate::any::TypeId::of) છે.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// અસલામત કાર્યો માટેનો રક્ષક જે `T` નિર્જન છે જો ક્યારેય ચલાવી શકાતો નથી:
    /// આ સ્થિર રીતે કાં તો panic કરશે, અથવા કંઈ કરશે નહીં.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// અસલામત કાર્યો માટેનો રક્ષક કે જે એક્ઝેક્યુટ કરી શકાતો નથી જો `T` શૂન્ય-પ્રારંભિકરણની મંજૂરી આપતું નથી: આ સ્થિર રીતે કાં તો panic કરશે, અથવા કંઇ કરશે નહીં.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn assert_zero_valid<T>();

    /// અસલામત કાર્યો માટેનો રક્ષક કે જે એક્ઝેક્યુટ કરી શકાતો નથી જો `T` માં અમાન્ય બીટ દાખલાઓ છે: આ સ્થિર રીતે કાં તો panic કરશે, અથવા કંઈ કરશે નહીં.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn assert_uninit_valid<T>();

    /// સ્થિર `Location` નો સંદર્ભ મળે છે જ્યાં તે બોલાવવામાં આવ્યો છે.
    ///
    /// તેના બદલે [`core::panic::Location::caller`](crate::panic::Location::caller) નો ઉપયોગ કરવાનું વિચારો.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ડ્ર dropપ ગ્લુ ચલાવ્યા વિના મૂલ્ય અવકાશની બહાર ખસે છે.
    ///
    /// આ ફક્ત [`mem::forget_unsized`] માટે અસ્તિત્વમાં છે;સામાન્ય `forget` તેના બદલે `ManuallyDrop` નો ઉપયોગ કરે છે.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// એક પ્રકારનાં મૂલ્યના બીટ્સને બીજા પ્રકાર તરીકે ફરીથી વ્યાખ્યાયિત કરે છે.
    ///
    /// બંને પ્રકારનાં કદ સમાન હોવા જોઈએ.
    /// મૂળ, અથવા પરિણામ, ન તો [invalid value](../../nomicon/what-unsafe-does.html) હોઈ શકે છે.
    ///
    /// `transmute` અર્થમાં એક પ્રકારનાં બીજામાં થોડુંક આગળ વધવા સમાન છે.તે સ્રોત મૂલ્યમાંથી બીટ્સને લક્ષ્યસ્થાન મૂલ્યમાં નકલ કરે છે, પછી મૂળ ભૂલી જાય છે.
    /// તે `transmute_copy` ની જેમ હૂડ હેઠળ સીના `memcpy` ની બરાબર છે.
    ///
    /// કારણ કે `transmute` એ બાય-વેલ્યુ ઓપરેશન છે, તેથી *ટ્રાન્સમ્યુટેડ કિંમતો પોતાને* ની ગોઠવણી એ કોઈ ચિંતાની વાત નથી.
    /// કોઈપણ અન્ય કાર્યની જેમ, કમ્પાઇલર પહેલાથી જ ખાતરી કરે છે કે બંને `T` અને `U` યોગ્ય રીતે ગોઠવાયેલ છે.
    /// તેમ છતાં, જ્યારે અન્ય સ્થળોએ * એવા બિંદુઓને સ્થાનાંતરિત કરતી વખતે (જેમ કે પોઇંટર્સ, સંદર્ભો, બ .ક્સેસ…), કlerલરે પોઇંટ-ટુ કિંમતોની યોગ્ય ગોઠવણીની ખાતરી કરવી પડશે.
    ///
    /// `transmute` **અવિશ્વસનીય** અસુરક્ષિત છે.આ કાર્ય સાથે [undefined behavior][ub] બનાવવાની ઘણી બધી રીતો છે.`transmute` એ આખરી છેલ્લો ઉપાય હોવો જોઈએ.
    ///
    /// [nomicon](../../nomicon/transmutes.html) પાસે અતિરિક્ત દસ્તાવેજો છે.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// એવી કેટલીક વસ્તુઓ છે કે જે માટે `transmute` ખરેખર ઉપયોગી છે.
    ///
    /// ફંક્શન પોઇન્ટરમાં નિર્દેશક ફેરવવું.આ મશીનો માટે *પોર્ટેબલ નથી* જ્યાં ફંક્શન પોઇંટર અને ડેટા પોઇંટરો જુદા જુદા કદના હોય છે.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// જીવનકાળ વધારવું, અથવા આક્રમક જીવનકાળ ટૂંકવો.આ અદ્યતન, ખૂબ અસુરક્ષિત Rust છે!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// નિરાશ થશો નહીં: `transmute` ના ઘણા ઉપયોગો અન્ય માધ્યમથી પ્રાપ્ત કરી શકાય છે.
    /// નીચે `transmute` ના સામાન્ય એપ્લિકેશનો છે જે સુરક્ષિત બાંધકામોથી બદલી શકાય છે.
    ///
    /// કાચા bytes(`&[u8]`) ને `u32`, `f64`, વગેરે પર ફેરવો.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // તેના બદલે `u32::from_ne_bytes` નો ઉપયોગ કરો
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // અથવા અંતને સ્પષ્ટ કરવા માટે `u32::from_le_bytes` અથવા `u32::from_be_bytes` નો ઉપયોગ કરો
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// નિર્દેશકને `usize` માં ફેરવવું:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // તેના બદલે એક `as` કાસ્ટનો ઉપયોગ કરો
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` ને `&mut T` માં ફેરવવું:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // તેના બદલે ફરીનો ઉપયોગ કરો
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` ને `&mut U` માં ફેરવવું:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // હવે, એકસાથે `as` અને પુનર્બ્રોઇંગ મૂકી, નોંધ લો કે `as` `as` નો ચેઇન ટ્રાન્ઝિટિવ નથી
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` ને `&[u8]` માં ફેરવવું:
    ///
    /// ```
    /// // આ કરવા માટેનો આ સારો રસ્તો નથી.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // તમે `str::as_bytes` નો ઉપયોગ કરી શકશો
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // અથવા, ફક્ત બાઇટ સ્ટ્રિંગનો ઉપયોગ કરો, જો તમારી પાસે શબ્દમાળા પર શબ્દમાળા નિયંત્રણ છે
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` ને `Vec<Option<&T>>` માં ફેરવી રહ્યું છે.
    ///
    /// કન્ટેનરની આંતરિક પ્રકારની સામગ્રીને ટ્રાન્સમિટ કરવા માટે, તમારે કન્ટેનરના કોઈપણ આક્રમણોનું ઉલ્લંઘન ન કરવું જોઈએ તેની ખાતરી કરવી આવશ્યક છે.
    /// `Vec` માટે, આનો અર્થ એ કે આંતરિક પ્રકારોનાં કદ *અને સંરેખણ* બંને મેળ ખાતા હોય છે.
    /// અન્ય કન્ટેનર પ્રકાર, સંરેખણ અથવા તો `TypeId` ના કદ પર આધાર રાખે છે, જેમાં કન્ટેનર આક્રમણકારોનું ઉલ્લંઘન કર્યા વિના ટ્રાન્સમિટ કરવું બિલકુલ શક્ય નથી.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector ક્લોન કરો કારણ કે અમે પછીથી તેનો ફરીથી ઉપયોગ કરીશું
    /// let v_clone = v_orig.clone();
    ///
    /// // ટ્રાંસમ્યુટનો ઉપયોગ કરીને: આ `Vec` ના અનિશ્ચિત ડેટા લેઆઉટ પર નિર્ભર છે, જે એક ખરાબ વિચાર છે અને અનિશ્ચિત વ્યવહારનું કારણ બની શકે છે.
    /////
    /// // જો કે, તે કોઈ નકલ નથી.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // આ સૂચિત, સલામત રીત છે.
    /// // તે સંપૂર્ણ ઝેડવેક્ટર 0 ઝેડને નવી એરેમાં નકલ કરે છે.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // આ ડેટા નો લેઆઉટ પર આધાર રાખ્યા વિના, કોઈ X-X X X X નો અસુરક્ષિત રસ્તો કોઈ નો-ક copyપિ છે.
    /// // `transmute` ને શાબ્દિક રીતે ક callingલ કરવાને બદલે, અમે એક પોઇંટર કાસ્ટ કરીએ છીએ, પરંતુ મૂળ આંતરિક પ્રકાર (`&i32`) ને નવા (`Option<&i32>`) માં રૂપાંતરિત કરવાના સંદર્ભમાં, આમાં સમાન પ્રકારની ચેતવણીઓ છે.
    /////
    /// // ઉપર આપેલી માહિતી ઉપરાંત, [`from_raw_parts`] દસ્તાવેજીકરણની સલાહ પણ લો.
    /////
    /// let v_from_raw = unsafe {
    ///     // જ્યારે vec_into_raw_parts સ્થિર થાય છે ત્યારે તેને ફિક્સ કરો.
    ///     // ખાતરી કરો કે અસલી ઝેડવેક્ટર 0 ઝેડ છોડી દેવાઈ નથી.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` અમલમાં મૂકવું:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // આ કરવા માટે ઘણી રીતો છે, અને નીચેની (transmute) રીત સાથે બહુવિધ સમસ્યાઓ છે.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // પ્રથમ: ટ્રાંસમ્યુટ સલામત પ્રકાર નથી;બધા તપાસ કરે છે કે ટી અને
    ///         // યુ સમાન કદના છે.
    ///         // બીજું, અહીં, તમારી પાસે બે પરિવર્તનશીલ સંદર્ભો છે જે સમાન મેમરી તરફ નિર્દેશ કરે છે.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // આ પ્રકારની સલામતી સમસ્યાઓથી છૂટકારો મેળવે છે;`&mut *`* ફક્ત *તમને `&mut T` અથવા `* mut T` માંથી `&mut T` આપશે.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // જો કે, તમારી પાસે હજી પણ બે જ પરિવર્તનીય સંદર્ભો છે જે સમાન મેમરી તરફ નિર્દેશ કરે છે.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // આ તે રીતે પ્રમાણભૂત પુસ્તકાલય કરે છે.
    /// // જો તમને આવું કંઈક કરવાની જરૂર હોય તો આ શ્રેષ્ઠ પદ્ધતિ છે
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // હવે તે સમાન મેમરી તરફ નિર્દેશ કરતી ત્રણ પરિવર્તનશીલ સંદર્ભો છે.`slice`, મૂલ્ય ret.0 અને મૂલ્ય ret.1.
    ///         // `slice` `let ptr = ...` પછી ક્યારેય ઉપયોગમાં લેવામાં આવતો નથી, અને તેથી કોઈ તેને "dead" તરીકે ગણી શકે છે, અને તેથી, તમારી પાસે ફક્ત બે વાસ્તવિક પરિવર્તનશીલ કાપી નાંખ્યું છે.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: જ્યારે આ આંતરિક કોન્સ્ટને સ્થિર બનાવે છે, ત્યારે અમારી પાસે કોન્સ્ટ એફ.એન. માં કેટલાક કસ્ટમ કોડ છે
    // `const fn` ની અંદર તેનો ઉપયોગ અટકાવે છે તે તપાસો.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// જો `T` તરીકે આપેલ વાસ્તવિક પ્રકારને ડ્રોપ ગુંદરની જરૂર હોય તો `true` આપે છે;જો `T` માટે પૂરા પાડવામાં આવેલ વાસ્તવિક પ્રકાર, `Copy` લાગુ કરે છે, તો `false` આપે છે.
    ///
    ///
    /// જો વાસ્તવિક પ્રકાર માટે ન તો ડ્રોપ ગુંદરની આવશ્યકતા હોય છે અને ન તો `Copy` લાગુ કરે છે, તો પછી આ કાર્યનું વળતર મૂલ્ય અનિશ્ચિત છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`mem::needs_drop`](crate::mem::needs_drop) છે.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// પોઇન્ટરથી setફસેટની ગણતરી કરે છે.
    ///
    /// પૂર્ણાંકમાં અને રૂપાંતરથી બચવા માટે આ એક આંતરિક તરીકે અમલમાં મૂકવામાં આવ્યું છે, કારણ કે રૂપાંતર એ એલિયાઝિંગ માહિતીને ફેંકી દે છે.
    ///
    /// # Safety
    ///
    /// પ્રારંભિક અને પરિણામી નિર્દેશક બંને કાં તો મર્યાદામાં હોવા જોઈએ અથવા ફાળવેલ objectબ્જેક્ટના અંતમાં એક બાઇટ હોવું જોઈએ.
    /// જો કાં તો નિર્દેશક સીમાની બહાર હોય અથવા અંકગણિત ઓવરફ્લો થાય છે, તો પાછલા મૂલ્યનો વધુ કોઈપણ ઉપયોગ અસ્પૃષ્ટ વર્તણૂકમાં પરિણમશે.
    ///
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`pointer::offset`] છે.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// સંભવિત રેપિંગ, પોઇન્ટરથી potફસેટની ગણતરી કરે છે.
    ///
    /// રૂપાંતર ચોક્કસ optimપ્ટિમાઇઝેશનને અવરોધે છે, કારણ કે પૂર્ણાંકમાં અને કન્વર્ટમાં જવાથી બચવા માટે આ એક આંતરિક તરીકે અમલમાં મૂકવામાં આવે છે.
    ///
    /// # Safety
    ///
    /// `offset` આંતરિકથી વિપરીત, આ આંતરિક પરિણામી નિર્દેશકને ફાળવેલા objectબ્જેક્ટના અંત તરફના બિંદુ અથવા એક બાઇટને પ્રતિબંધિત કરતું નથી, અને તે બેના પૂરક અંકગણિત સાથે લપેટી છે.
    /// પરિણામી મૂલ્ય ખરેખર મેમરીને accessક્સેસ કરવા માટે ઉપયોગમાં લેવાય તે જરૂરી નથી.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`pointer::wrapping_offset`] છે.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` ના કદ અને તેના સંરેખણ સાથે, યોગ્ય `llvm.memcpy.p0i8.0i8.*` આંતરિક સાથે સમાન
    ///
    /// `min_align_of::<T>()`
    ///
    /// અસ્થિર પરિમાણ `true` પર સેટ કરેલું છે, તેથી જ્યાં સુધી કદ શૂન્ય ન હોય ત્યાં સુધી તે optimપ્ટિમાઇઝ કરવામાં આવશે નહીં.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ના કદ અને એક સંરેખણ સાથે, યોગ્ય `llvm.memmove.p0i8.0i8.*` આંતરિક સાથે સમાન
    ///
    /// `min_align_of::<T>()`
    ///
    /// અસ્થિર પરિમાણ `true` પર સેટ કરેલું છે, તેથી જ્યાં સુધી કદ શૂન્ય ન હોય ત્યાં સુધી તે optimપ્ટિમાઇઝ કરવામાં આવશે નહીં.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ના કદ અને `min_align_of::<T>()` ની ગોઠવણી સાથે, યોગ્ય `llvm.memset.p0i8.*` આંતરિક સાથે સમાન.
    ///
    ///
    /// અસ્થિર પરિમાણ `true` પર સેટ કરેલું છે, તેથી જ્યાં સુધી કદ શૂન્ય ન હોય ત્યાં સુધી તે optimપ્ટિમાઇઝ કરવામાં આવશે નહીં.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` પોઇન્ટરથી અસ્થિર લોડ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::ptr::read_volatile`](crate::ptr::read_volatile) છે.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` પોઇન્ટર પર અસ્થિર સ્ટોર કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::ptr::write_volatile`](crate::ptr::write_volatile) છે.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` પોઇન્ટરથી અસ્થિર લોડ કરે છે પોઇન્ટરને ગોઠવાયેલ હોવું જરૂરી નથી.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` પોઇન્ટર પર અસ્થિર સ્ટોર કરે છે.
    /// પોઇન્ટરને ગોઠવવાની જરૂર નથી.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` નો વર્ગમૂળ પાછો આપે છે
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` નો વર્ગમૂળ પાછો આપે છે
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// પૂર્ણાંક પાવર પર એક `f32` ઉભા કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// પૂર્ણાંક પાવર પર એક `f64` ઉભા કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` ની સાઇન આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` ની સાઇન આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` નું કોસ્સીન પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` નું કોસ્સીન પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// એક `f32` ને `f32` પાવરમાં ઉભા કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// એક `f64` ને `f64` પાવરમાં ઉભા કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` ના ઘાતાંકીય વળતર આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` ના ઘાતાંકીય વળતર આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// એક `f32` ની શક્તિ પર ઉભા કરેલા 2 પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// એક `f64` ની શક્તિ પર ઉભા કરેલા 2 પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` ના કુદરતી લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` ના કુદરતી લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// એક `f32` ના બેઝ 10 લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// એક `f64` ના બેઝ 10 લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` ના બેઝ 2 લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` ના બેઝ 2 લોગરીધમ પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` મૂલ્યો માટે `a * b + c` આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` મૂલ્યો માટે `a * b + c` આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` નું સંપૂર્ણ મૂલ્ય પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` નું સંપૂર્ણ મૂલ્ય પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// ન્યૂનતમ બે `f32` મૂલ્યો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// ન્યૂનતમ બે `f64` મૂલ્યો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// મહત્તમ બે `f32` મૂલ્યો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// મહત્તમ બે `f64` મૂલ્યો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` મૂલ્યો માટે `y` થી `x` પરનાં ચિહ્નોની કiesપિ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` મૂલ્યો માટે `y` થી `x` પરનાં ચિહ્નોની કiesપિ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` કરતા ઓછા અથવા તેના સમાનના સૌથી મોટા પૂર્ણાંકને આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` કરતા ઓછા અથવા તેના સમાનના સૌથી મોટા પૂર્ણાંકને આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` કરતા વધારે અથવા તેના સમાનના સૌથી નાના પૂર્ણાંકો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` કરતા વધારે અથવા તેના સમાનના સૌથી નાના પૂર્ણાંકો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` નો પૂર્ણાંક ભાગ પાછો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` નો પૂર્ણાંક ભાગ પાછો આપે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// એક નજીકનું પૂર્ણાંક `f32` પર પાછા ફરો.
    /// દલીલ પૂર્ણાંક ન હોય તો સચોટ ફ્લોટિંગ-પોઇન્ટ અપવાદ વધારશે.
    pub fn rintf32(x: f32) -> f32;
    /// એક નજીકનું પૂર્ણાંક `f64` પર પાછા ફરો.
    /// દલીલ પૂર્ણાંક ન હોય તો સચોટ ફ્લોટિંગ-પોઇન્ટ અપવાદ વધારશે.
    pub fn rintf64(x: f64) -> f64;

    /// એક નજીકનું પૂર્ણાંક `f32` પર પાછા ફરો.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn nearbyintf32(x: f32) -> f32;
    /// એક નજીકનું પૂર્ણાંક `f64` પર પાછા ફરો.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn nearbyintf64(x: f64) -> f64;

    /// એક નજીકનું પૂર્ણાંક `f32` પર પાછા ફરો.શૂન્યથી અડધા રસ્તે ચાલતા કેસને ગોળ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// એક નજીકનું પૂર્ણાંક `f64` પર પાછા ફરો.શૂન્યથી અડધા રસ્તે ચાલતા કેસને ગોળ કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ છે
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// ફ્લોટ એડજેશન જે બીજગણિત નિયમોના આધારે optimપ્ટિમાઇઝેશનને મંજૂરી આપે છે.
    /// માની શકે છે ઇનપુટ્સ મર્યાદિત છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// ફ્લોટ બાદબાકી જે બીજગણિત નિયમોના આધારે optimપ્ટિમાઇઝેશનને મંજૂરી આપે છે.
    /// માની શકે છે ઇનપુટ્સ મર્યાદિત છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// ફ્લોટ ગુણાકાર જે બીજગણિત નિયમોના આધારે optimપ્ટિમાઇઝેશનને મંજૂરી આપે છે.
    /// માની શકે છે ઇનપુટ્સ મર્યાદિત છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// ફ્લોટ ડિવિઝન જે બીજગણિત નિયમોના આધારે optimપ્ટિમાઇઝેશનને મંજૂરી આપે છે.
    /// માની શકે છે ઇનપુટ્સ મર્યાદિત છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ફ્લોટની બાકીની રકમ જે બીજગણિત નિયમોના આધારે optimપ્ટિમાઇઝેશનને મંજૂરી આપે છે.
    /// માની શકે છે ઇનપુટ્સ મર્યાદિત છે.
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// એલએલવીએમના fptoui/fptosi સાથે રૂપાંતરિત કરો, જે મૂલ્યની મર્યાદાથી અસ્પષ્ટ થઈ શકે છે
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] અને [`f64::to_int_unchecked`] તરીકે સ્થિર.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// પૂર્ણાંક પ્રકાર `T` માં સેટ કરેલા બિટ્સની સંખ્યા પરત કરે છે
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `count_ones` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// પૂર્ણાંક પ્રકાર `T` માં અગ્રણી અનસેટ બીટ્સ (zeroes) ની સંખ્યા આપે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `leading_zeros` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` મૂલ્યવાળા `x`, `T` ની બીટ પહોળાઈ પરત કરશે.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` ની જેમ, પરંતુ એક્સ્ટ્રા-અસુરક્ષિત કારણ કે જ્યારે `0` મૂલ્ય સાથે `x` આપવામાં આવે ત્યારે તે `undef` આપે છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// પૂર્ણાંકોના પ્રકાર `T` માં એક્સસેટ બિટ્સ (zeroes) પાછળની સંખ્યા પરત કરે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `trailing_zeros` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` મૂલ્યવાળા `x`, `T` ની બીટ પહોળાઈ પરત કરશે:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` ની જેમ, પરંતુ એક્સ્ટ્રા-અસુરક્ષિત કારણ કે જ્યારે `0` મૂલ્ય સાથે `x` આપવામાં આવે ત્યારે તે `undef` આપે છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// બાઇટ્સને પૂર્ણાંક પ્રકાર `T` માં ફેરવે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `swap_bytes` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// બિટ્સને પૂર્ણાંક પ્રકાર `T` માં ફેરવે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `reverse_bits` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// ચકાસાયેલ પૂર્ણાંક ઉમેરો કરે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `overflowing_add` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ચકાસાયેલ પૂર્ણાંક બાદબાકી કરે છે
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `overflowing_sub` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ચકાસાયેલ પૂર્ણાંક ગુણાકાર કરે છે
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `overflowing_mul` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// `x % y != 0` અથવા `y == 0` અથવા `x == T::MIN && y == -1` જ્યાં અપૂર્ણ વ્યાખ્યાયિત વર્તનમાં પરિણમે ચોક્કસ વિભાગ કરે છે
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// `y == 0` અથવા `x == T::MIN && y == -1` જ્યાં અસ્પૃષ્ટ વર્તણૂક પરિણમે છે, એક અનચેક કરેલ ડિવિઝન કરે છે
    ///
    ///
    /// આ આંતરિક માટે સલામત આવરણો `checked_div` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` અથવા `x == T::MIN && y == -1` હોય ત્યારે અનિશ્ચિત વર્તણૂકના પરિણામે, અનચેક્ડ ડિવિઝનનો બાકીનો ભાગ આપે છે
    ///
    ///
    /// આ આંતરિક માટે સલામત રેપર્સ, `checked_rem` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// `y < 0` અથવા `y >= N`, જ્યાં N બીટમાં ટીની પહોળાઇ હોય ત્યારે અસ્પૃષ્ટ વર્તણૂક પરિણમે છે, એક અનચેક્ડ ડાબી પાળી કરે છે.
    ///
    ///
    /// આ આંતરિક માટે સલામત આવરણો `checked_shl` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// `y < 0` અથવા `y >= N`, જ્યાં N બીટમાં ટીની પહોળાઈ છે ત્યાં અનિશ્ચિત વર્તણૂકનાં પરિણામે, અનચેક કરેલ જમણી પાળી કરે છે.
    ///
    ///
    /// આ આંતરિક માટે સલામત આવરણો `checked_shr` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// જ્યારે `x + y > T::MAX` અથવા `x + y < T::MIN` હોય ત્યારે અનિશ્ચિત વર્તણૂકમાં પરિણમે, અનચેક કરેલ ઉમેરાનું પરિણામ આપે છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// જ્યારે `x - y > T::MAX` અથવા `x - y < T::MIN` હોય ત્યારે અનિશ્ચિત વર્તણૂકના પરિણામે, અનચેક કરેલ બાદબાકીનું પરિણામ આપે છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// જ્યારે `x *y > T::MAX` અથવા `x* y < T::MIN` હોય ત્યારે અનિશ્ચિત વર્તણૂકના પરિણામે, અનચેક કરેલ ગુણાકારનું પરિણામ આપે છે.
    ///
    ///
    /// આ આંતરિકમાં સ્થિર પ્રતિરૂપ નથી.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ડાબી ફેરવો કરે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `rotate_left` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// જમણે ફેરવો કરે છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `rotate_right` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// વળતર (એ + બી) મોડ 2 <sup>એન</sup>, જ્યાં બીટ્સમાં ટીની પહોળાઈ છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `wrapping_add` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// રીટર્ન (એ, બી) મોડ 2 <sup>એન</sup>, જ્યાં બી બીમાં ટીની પહોળાઈ છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `wrapping_sub` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// વળતર (એ * બી) મોડ 2 <sup>એન</sup>, જ્યાં બી બીમાં ટીની પહોળાઈ છે.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `wrapping_mul` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// ગણતરીઓ `a + b`, સંખ્યાત્મક સીમા પર સંતૃપ્ત.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `saturating_add` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// ગણતરીઓ `a - b`, સંખ્યાત્મક સીમા પર સંતૃપ્ત.
    ///
    /// આ આંતરિકનાં સ્થિર સંસ્કરણો `saturating_sub` પદ્ધતિ દ્વારા પૂર્ણાંક આદિમ પર ઉપલબ્ધ છે.
    /// દાખ્લા તરીકે,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' માં વેરિઅન્ટ માટેનો ભેદભાવનું મૂલ્ય પાછું આપે છે;
    /// જો `T` નો કોઈ ભેદભાવ નથી, તો `0` પરત કરે છે.
    ///
    /// આ આંતરિકનું સ્થિર સંસ્કરણ [`core::mem::discriminant`](crate::mem::discriminant) છે.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` પ્રકારનાં ચલની સંખ્યાને `usize` પર પરત કરે છે;
    /// જો `T` ના કોઈ પ્રકારો છે, તો `0` આપે છે.નિર્જન વેરિયન્ટ્સ ગણાશે.
    ///
    /// આ આંતરિકનું સ્થિર થવું સંસ્કરણ [`mem::variant_count`] છે.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust નું "try catch" કન્સ્ટ્રકટ જે ડેટા પોઇન્ટર `data` સાથે ફંક્શન પોઇન્ટર `try_fn` ને બોલાવે છે.
    ///
    /// ત્રીજી દલીલ એ એક કાર્ય કહેવાય છે જો જો ઝેડપેંકનિક 0 ઝેડ થાય છે.
    /// આ ફંક્શન ડેટા પોઇંટર અને લક્ષ્ય-વિશિષ્ટ અપવાદ objectબ્જેક્ટ પર નિર્દેશક લે છે જે પકડાયું હતું.
    ///
    /// વધુ માહિતી માટે કમ્પાઇલરનો સ્રોત તેમજ std ની કેચ અમલીકરણ જુઓ.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// એલએલવીએમ (તેમના ડsક્સ જુઓ) અનુસાર `!nontemporal` સ્ટોર બહાર કા .ે છે.
    /// કદાચ ક્યારેય સ્થિર નહીં બને.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// વિગતો માટે `<*const T>::offset_from` ના દસ્તાવેજીકરણ જુઓ.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// વિગતો માટે `<*const T>::guaranteed_eq` ના દસ્તાવેજીકરણ જુઓ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// વિગતો માટે `<*const T>::guaranteed_ne` ના દસ્તાવેજીકરણ જુઓ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// કમ્પાઇલ સમયે ફાળવો.રનટાઇમ પર બોલાવવા જોઈએ નહીં.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// કેટલાક કાર્યો અહીં વ્યાખ્યાયિત કરવામાં આવ્યા છે કારણ કે તેઓ આકસ્મિક સ્થિર પર આ મોડ્યુલમાં ઉપલબ્ધ બન્યા છે.
// <https://github.com/rust-lang/rust/issues/15702> જુઓ.
// (`transmute` પણ આ કેટેગરીમાં આવે છે, પરંતુ `T` અને `U` સમાન કદની તપાસને લીધે આવરિત કરી શકાતા નથી.)
//

/// `ptr` `align_of::<T>()` ના સંદર્ભમાં યોગ્ય રીતે ગોઠવાયેલ છે કે કેમ તે તપાસો.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` થી `dst` માં `count* size_of::<T>()` બાઇટ્સની નકલો.સ્રોત અને લક્ષ્યસ્થાન *ઓવરલેપ નહીં* હોવું જોઈએ.
///
/// મેમરીના પ્રદેશો માટે જે ઓવરલેપ થઈ શકે છે, તેના બદલે [`copy`] નો ઉપયોગ કરો.
///
/// `copy_nonoverlapping` સીમેંટલી સીના [`memcpy`] ની સમકક્ષ છે, પરંતુ દલીલ હુકમ અદલાબદલ સાથે.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// જો નીચેની શરતોમાંથી કોઈનું ઉલ્લંઘન કરવામાં આવે તો વર્તન અનિશ્ચિત છે:
///
/// * `src` `count * size_of::<T>()` બાઇટ્સ વાંચવા માટે [valid] હોવા આવશ્યક છે.
///
/// * `dst` `count * size_of::<T>()` બાઇટ્સ લખવા માટે [valid] હોવા આવશ્યક છે.
///
/// * બંને `src` અને `dst` યોગ્ય રીતે ગોઠવાયેલા હોવા જોઈએ.
///
/// * મેમરીનો ક્ષેત્ર `src` થી `ગણતરીના કદ સાથે પ્રારંભ થાય છે *
///   કદ_ના: :<T>() `બાઇટ્સ * * સમાન કદ સાથે `dst` થી મેમરીના ક્ષેત્ર સાથે ઓવરલેપ ન હોવા જોઈએ.
///
/// [`read`] ની જેમ, `copy_nonoverlapping`, `T` ની થોડી દિશામાં નકલ બનાવે છે, `T` એ [`Copy`] છે કે કેમ તે ધ્યાનમાં લીધા વિના.
/// જો `T` એ X01 એક્સ ન હોય તો, આ ક્ષેત્રમાં *બંને* કિંમતોનો ઉપયોગ કરીને, જે `*src` થી શરૂ થાય છે અને આ ક્ષેત્રમાં `* dst` થી પ્રારંભ થઈ શકે છે તે [violate memory safety][read-ownership] કરી શકે છે.
///
///
/// નોંધ લો કે જો અસરકારક રીતે કiedપિ કરેલું કદ (`ગણતરી * કદ_: :<T>().) એ `0` છે, પોઇંટરો ન-ન-એનયુએલ અને યોગ્ય રીતે ગોઠવાયેલા હોવા જોઈએ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] ને મેન્યુઅલી અમલમાં મૂકો:
///
/// ```
/// use std::ptr;
///
/// /// `src` ના બધા ઘટકોને `dst` માં ખસેડે છે, `src` ને ખાલી છોડી દે છે.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // ખાતરી કરો કે `dst` પાસે બધા `src` રાખવા માટે પૂરતી ક્ષમતા છે.
///     dst.reserve(src_len);
///
///     unsafe {
///         // કsetલ offફસેટ હંમેશા સલામત છે કારણ કે `Vec` ક્યારેય પણ `isize::MAX` બાઇટ્સ કરતાં વધુ ફાળવણી કરશે નહીં.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // તેની સામગ્રીને છોડ્યા વિના `src` કા00ો.
///         // ઝેડપેનિક્સ 0 ઝેડ આગળ કંઇક સમસ્યાઓથી બચવા માટે અમે આ પ્રથમ કરીએ છીએ.
///         src.set_len(0);
///
///         // બે પ્રદેશો ઓવરલેપ કરી શકતા નથી કારણ કે પરિવર્તનશીલ સંદર્ભો ઉપનામ નથી, અને બે જુદા જુદા ઝેકવેક્ટર્સ0 ઝેડ સમાન મેમરીનો માલિકી ધરાવતા નથી.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` ને સૂચિત કરો કે તે હવે `src` ની સામગ્રી ધરાવે છે.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: આ ચકાસણી ફક્ત રન ટાઇમ પર જ કરો
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // કોડજેનની અસર ઓછી રાખવા માટે ગભરાશો નહીં.
        abort();
    }*/

    // સલામત: `copy_nonoverlapping` માટે સલામતી કરાર હોવો આવશ્યક છે
    // ક calલર દ્વારા સમર્થન આપવામાં આવ્યું.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count *size_of::<T>()` થી `dst` માં `count* size_of::<T>()` બાઇટ્સની નકલો.સ્રોત અને લક્ષ્ય ઓવરલેપ થઈ શકે છે.
///
/// જો સ્રોત અને લક્ષ્ય *ક્યારેય* ઓવરલેપ નહીં થાય, તો [`copy_nonoverlapping`] ને બદલે વાપરી શકાય છે.
///
/// `copy` સીમેંટલી સીના [`memmove`] ની સમકક્ષ છે, પરંતુ દલીલ હુકમ અદલાબદલ સાથે.
/// કyingપિ બનાવવી તે રીતે થાય છે જાણે `src` થી અસ્થાયી એરેમાં બાઇટ્સની નકલ કરવામાં આવી હોય અને પછી એરેથી `dst` પર ક toપિ કરવામાં આવી હોય.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// જો નીચેની શરતોમાંથી કોઈનું ઉલ્લંઘન કરવામાં આવે તો વર્તન અનિશ્ચિત છે:
///
/// * `src` `count * size_of::<T>()` બાઇટ્સ વાંચવા માટે [valid] હોવા આવશ્યક છે.
///
/// * `dst` `count * size_of::<T>()` બાઇટ્સ લખવા માટે [valid] હોવા આવશ્યક છે.
///
/// * બંને `src` અને `dst` યોગ્ય રીતે ગોઠવાયેલા હોવા જોઈએ.
///
/// [`read`] ની જેમ, `copy`, `T` ની થોડી દિશામાં નકલ બનાવે છે, `T` એ [`Copy`] છે કે કેમ તે ધ્યાનમાં લીધા વિના.
/// જો `T` એ X01 એક્સ નથી, તો `*src` થી શરૂ થતાં અને `* dst` થી શરૂ થતા ક્ષેત્રના બંને મૂલ્યોનો ઉપયોગ કરીને [violate memory safety][read-ownership] કરી શકાય છે.
///
///
/// નોંધ લો કે જો અસરકારક રીતે કiedપિ કરેલું કદ (`ગણતરી * કદ_: :<T>().) એ `0` છે, પોઇંટરો ન-ન-એનયુએલ અને યોગ્ય રીતે ગોઠવાયેલા હોવા જોઈએ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// અસુરક્ષિત બફરથી કાર્યક્ષમ રીતે Rust vector બનાવો:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` તેના પ્રકાર અને બિન-શૂન્ય માટે યોગ્ય રીતે ગોઠવવું આવશ્યક છે.
/// /// * `ptr` `T` પ્રકારનાં ઘટ્ટ તત્વોના વાંચવા માટે માન્ય હોવું આવશ્યક છે.
/// /// * `T: Copy` સિવાય આ ફંક્શનને ક functionલ કર્યા પછી તે તત્વોનો ઉપયોગ થવો જોઈએ નહીં.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // સલામતી: આપણી પૂર્વસરત ખાતરી કરે છે કે સ્રોત ગોઠવાયેલ છે અને માન્ય છે,
///     // અને `Vec::with_capacity` ખાતરી કરે છે કે અમારી પાસે તેમને લખવા માટે ઉપયોગી જગ્યા છે.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // સલામતી: અમે તેને આ પહેલાં આટલી ક્ષમતા સાથે બનાવ્યું છે,
///     // અને પાછલા `copy` એ આ તત્વો પ્રારંભ કર્યા છે.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: આ ચકાસણી ફક્ત રન ટાઇમ પર જ કરો
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // કોડજેનની અસર ઓછી રાખવા માટે ગભરાશો નહીં.
        abort();
    }*/

    // સલામતી: ક00લર દ્વારા `copy` માટે સલામતી કરાર હોવો જ જોઇએ.
    unsafe { copy(src, dst, count) }
}

/// `dst` થી `val` થી પ્રારંભ કરીને `count * size_of::<T>()` બાઇટ્સ મેમરી સેટ કરે છે.
///
/// `write_bytes` સીના [`memset`] જેવું જ છે, પરંતુ `count * size_of::<T>()` બાઇટ્સને `val` પર સેટ કરે છે.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// જો નીચેની શરતોમાંથી કોઈનું ઉલ્લંઘન કરવામાં આવે તો વર્તન અનિશ્ચિત છે:
///
/// * `dst` `count * size_of::<T>()` બાઇટ્સ લખવા માટે [valid] હોવા આવશ્યક છે.
///
/// * `dst` યોગ્ય રીતે ગોઠવાયેલ હોવા જોઈએ.
///
/// વધારામાં, કlerલરને ખાતરી કરવી આવશ્યક છે કે `count * size_of::<T>()` બાઇટ્સ મેમરીના આપેલા પ્રદેશમાં લખે છે, તે `T` ની માન્ય કિંમતમાં પરિણમે છે.
/// `T` તરીકે ટાઇપ કરેલ મેમરીના ક્ષેત્રનો ઉપયોગ કરવો જેમાં `T` નું અમાન્ય મૂલ્ય છે તે અસ્પષ્ટ વર્તન છે.
///
/// નોંધ લો કે જો અસરકારક રીતે કiedપિ કરેલું કદ (`ગણતરી * કદ_: :<T>().) એ `0` છે, જેનો નિર્દેશક નોન-એનયુએલ અને યોગ્ય રીતે ગોઠવાયેલ હોવો જોઈએ.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// અમાન્ય મૂલ્ય બનાવવું:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // નલ પોઇન્ટર સાથે `Box<T>` પર ફરીથી લખીને અગાઉનું યોજાયેલ મૂલ્ય લિક કરે છે.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // આ બિંદુએ, `v` નો ઉપયોગ અથવા છોડી દેવાથી અસ્પષ્ટ વર્તણૂક થાય છે.
/// // drop(v); // ERROR
///
/// // પણ `v` "uses" તેને લીક કરવું, અને તેથી તે અસ્પષ્ટ વર્તન છે.
/// // mem::forget(v); // ERROR
///
/// // હકીકતમાં, `v` એ મૂળભૂત પ્રકારનાં લેઆઉટ આક્રમણકારો અનુસાર અમાન્ય છે, તેથી *તેને સ્પર્શતી કોઈપણ કામગીરી* અસ્પષ્ટ વર્તન છે.
/////
/// // ચાલો v2 =v;//ભૂલ
///
/// unsafe {
///     // ચાલો તેના બદલે માન્ય મૂલ્ય મૂકીએ
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // હવે બ fineક્સ બરાબર છે
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // સલામતી: ક00લર દ્વારા `write_bytes` માટે સલામતી કરાર હોવો જ જોઇએ.
    unsafe { write_bytes(dst, val, count) }
}