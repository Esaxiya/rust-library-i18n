//! UTF-8 અને UTF-16 ડીકોડિંગ ઇટરેટર્સ

use crate::fmt;

use super::from_u32_unchecked;

/// એક પુનરાવર્તક જે UTF-16 એન્કોડેડ કોડ પોઇન્ટને ડીકોડ કરે છે તે u16` ના પુનરાવર્તકમાંથી છે.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// UTF-16 કોડ પોઇન્ટને ડીકોડ કરતી વખતે પાછા આવી શકે છે તે ભૂલ.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// `iter` માં UTF-16 એન્કોડેડ કોડ પોઇન્ટ્સ પર ઇરેટર બનાવે છે, p એરર્સ તરીકે અનપેઇ કરેલ સરોગેટ્સને પરત કરે છે.
///
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::char::decode_utf16;
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
///         .collect::<Vec<_>>(),
///     vec![
///         Ok('𝄞'),
///         Ok('m'), Ok('u'), Ok('s'),
///         Err(0xDD1E),
///         Ok('i'), Ok('c'),
///         Err(0xD834)
///     ]
/// );
/// ```
///
/// ક્ષતિપૂર્ણ ડીકોડર, `Err` પરિણામોને બદલી પાત્ર સાથે બદલીને મેળવી શકાય છે:
///
/// ```
/// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
///        .collect::<String>(),
///     "𝄞mus�ic�"
/// );
/// ```
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[inline]
pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if u < 0xD800 || 0xDFFF < u {
            // સલામતી: સરોગેટ નહીં
            Some(Ok(unsafe { from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // એક પાછળનો સરોગેટ
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // પાછળનું સરોગેટ નથી તેથી અમે કોઈ માન્ય સરોગેટ જોડી નથી, તેથી આગલી વખતે u2 ને ફરીથી ફેરવો.
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // બધા ઠીક છે, તેથી ચાલો તેને ડીકોડ કરીએ.
            let c = (((u - 0xD800) as u32) << 10 | (u2 - 0xDC00) as u32) + 0x1_0000;
            // સલામતી: અમે તપાસ્યું કે તે કાનૂની યુનિકોડ મૂલ્ય છે
            Some(Ok(unsafe { from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();
        // અમે સંપૂર્ણ માન્ય સરોગેટ્સ (ચર દીઠ 2 તત્વો), અથવા સંપૂર્ણપણે બિન-સરોગેટ્સ (ચર દીઠ 1 તત્વ) હોઈ શકીએ
        //
        (low / 2, high)
    }
}

impl DecodeUtf16Error {
    /// અનપેયર્ડ સરોગેટ આપે છે જેના કારણે આ ભૂલ થઈ છે.
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}