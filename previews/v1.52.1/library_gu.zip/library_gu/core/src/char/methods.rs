//! impl ચાર {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// એક `char` હોઈ શકે તેવો ઉચ્ચતમ માન્ય કોડ બિંદુ.
    ///
    /// એક `char` એ એક [Unicode Scalar Value] છે, જેનો અર્થ છે કે તે એક X01 એક્સ છે, પરંતુ તે ફક્ત અમુક શ્રેણીમાં છે.
    /// `MAX` તે એક ઉચ્ચતમ માન્ય કોડ પોઇન્ટ છે જે માન્ય [Unicode Scalar Value] છે.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () નો ઉપયોગ ડીકોડિંગ ભૂલને રજૂ કરવા માટે યુનિકોડમાં થાય છે.
    ///
    /// તે થઇ શકે છે, ઉદાહરણ તરીકે, જ્યારે [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ને ખરાબ રચિત UTF-8 બાઇટ્સ આપતી વખતે.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) નું સંસ્કરણ કે જે `char` અને `str` પદ્ધતિઓના યુનિકોડ ભાગો આધારિત છે.
    ///
    /// યુનિકોડના નવા સંસ્કરણો નિયમિતરૂપે પ્રકાશિત થાય છે અને ત્યારબાદ યુનિકોડના આધારે માનક લાઇબ્રેરીની બધી પદ્ધતિઓ અપડેટ થાય છે.
    /// તેથી કેટલીક `char` અને `str` પદ્ધતિઓનું વર્તન અને સમય જતાં આ સતત ફેરફારોનું મૂલ્ય.
    /// આને * તૂટી ગયેલો ફેરફાર માનવામાં આવતો નથી.
    ///
    /// સંસ્કરણ નંબર આપવાની યોજના [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) માં સમજાવાયેલ છે.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` માં UTF-16 એન્કોડેડ કોડ પોઇન્ટ્સ પર ઇરેટર બનાવે છે, p એરર્સ તરીકે અનપેઇ કરેલ સરોગેટ્સને પરત કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ક્ષતિપૂર્ણ ડીકોડર, `Err` પરિણામોને બદલી પાત્ર સાથે બદલીને મેળવી શકાય છે:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ને `char` માં રૂપાંતરિત કરે છે.
    ///
    /// નોંધ લો કે તમામ ચાર્ટ્સ માન્ય છે [`u32`], અને તેની સાથે એકમાં કાસ્ટ કરી શકાય છે
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// જો કે, વિપરીત સાચું નથી: બધા માન્ય [`u32`] માન્ય નથી` ચાર્ટ્સ.
    /// `from_u32()` જો ઇનપુટ `char` માટે માન્ય મૂલ્ય ન હોય તો `None` પરત કરશે.
    ///
    /// આ ફંક્શનના અસુરક્ષિત સંસ્કરણ માટે, જે આ તપાસને અવગણે છે, [`from_u32_unchecked`] જુઓ.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ઇનપુટ માન્ય `char` ન હોય ત્યારે `None` પરત આપવું:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// માન્યતાને અવગણીને, `u32` ને `char` માં રૂપાંતરિત કરે છે.
    ///
    /// નોંધ લો કે તમામ ચાર્ટ્સ માન્ય છે [`u32`], અને તેની સાથે એકમાં કાસ્ટ કરી શકાય છે
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// જો કે, વિપરીત સાચું નથી: બધા માન્ય [`u32`] માન્ય નથી` ચાર્ટ્સ.
    /// `from_u32_unchecked()` આને અવગણશે, અને `char` પર આંખેથી કાસ્ટ થશે, સંભવત અમાન્ય બનાવે છે.
    ///
    ///
    /// # Safety
    ///
    /// આ કાર્ય અસુરક્ષિત છે, કારણ કે તે અમાન્ય `char` મૂલ્યોનું નિર્માણ કરી શકે છે.
    ///
    /// આ ફંક્શનના સલામત સંસ્કરણ માટે, [`from_u32`] ફંક્શન જુઓ.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // સલામતી: સલામતી કરાર કlerલર દ્વારા સમર્થન આપવું આવશ્યક છે.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// આપેલા મૂળાના અંકોને `char` માં ફેરવે છે.
    ///
    /// અહીંના 'radix' ને કેટલીકવાર 'base' પણ કહેવામાં આવે છે.
    /// બેના મૂળમાં દ્વિસંગી સંખ્યા, દસનો દશાંશ, દશાંશ, અને સોળનો હેડક્સેસિમલનો મૂળો સૂચવવામાં આવે છે, જેથી કેટલાક સામાન્ય મૂલ્યો આપવામાં આવે.
    ///
    /// મનસ્વી મુળ આધારભૂત છે.
    ///
    /// `from_digit()` જો ઇનપુટ આપેલ ત્રિજ્યામાં અંક ન હોય તો `None` પરત કરશે.
    ///
    /// # Panics
    ///
    /// ઝેડ પPનિક્સ 0 ઝેડ જો 36 થી વધુનો રેડિક્સ આપવામાં આવે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // દશાંશ 11 એ આધાર 16 માં એક અંક છે
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ઇનપુટ અંક ન હોય ત્યારે `None` પરત આપવું:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ઝિડપેનિક0 ઝેડનું કારણ બને છે, મોટા મૂળાક્ષમાં પસાર થવું:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// આપેલ ત્રિજ્યામાં `char` અંક છે કે કેમ તે તપાસે છે.
    ///
    /// અહીંના 'radix' ને કેટલીકવાર 'base' પણ કહેવામાં આવે છે.
    /// બેના મૂળમાં દ્વિસંગી સંખ્યા, દસનો દશાંશ, દશાંશ, અને સોળનો હેડક્સેસિમલનો મૂળો સૂચવવામાં આવે છે, જેથી કેટલાક સામાન્ય મૂલ્યો આપવામાં આવે.
    ///
    /// મનસ્વી મુળ આધારભૂત છે.
    ///
    /// [`is_numeric()`] ની તુલનામાં, આ કાર્ય ફક્ત `0-9`, `a-z` અને `A-Z` અક્ષરોને ઓળખે છે.
    ///
    /// 'Digit' ફક્ત નીચેના અક્ષરો તરીકે વ્યાખ્યાયિત થયેલ છે:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' ની વધુ વ્યાપક સમજણ માટે, [`is_numeric()`] જુઓ.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// ઝેડ પPનિક્સ 0 ઝેડ જો 36 થી વધુનો રેડિક્સ આપવામાં આવે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ઝિડપેનિક0 ઝેડનું કારણ બને છે, મોટા મૂળાક્ષમાં પસાર થવું:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// આપેલ રેડીક્સમાં `char` ને એક અંકોમાં ફેરવે છે.
    ///
    /// અહીંના 'radix' ને કેટલીકવાર 'base' પણ કહેવામાં આવે છે.
    /// બેના મૂળમાં દ્વિસંગી સંખ્યા, દસનો દશાંશ, દશાંશ, અને સોળનો હેડક્સેસિમલનો મૂળો સૂચવવામાં આવે છે, જેથી કેટલાક સામાન્ય મૂલ્યો આપવામાં આવે.
    ///
    /// મનસ્વી મુળ આધારભૂત છે.
    ///
    /// 'Digit' ફક્ત નીચેના અક્ષરો તરીકે વ્યાખ્યાયિત થયેલ છે:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// જો X01 એક્સ આપેલ ત્રિજ્યામાં અંકનો સંદર્ભ લેતો નથી તો `None` આપે છે.
    ///
    /// # Panics
    ///
    /// ઝેડ પPનિક્સ 0 ઝેડ જો 36 થી વધુનો રેડિક્સ આપવામાં આવે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// નિષ્ફળતામાં બિન-અંકનું પરિણામ પસાર કરવું:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ઝિડપેનિક0 ઝેડનું કારણ બને છે, મોટા મૂળાક્ષમાં પસાર થવું:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` સતત અને 10 અથવા ઓછા હોય તેવા કેસો માટે એક્ઝેક્યુશન ગતિને સુધારવા માટે કોડ અહીં વિભાજિત થયેલ છે
        //
        let val = if likely(radix <= 10) {
            // જો અંક નથી, તો મૂળાક્ષર કરતા મોટી સંખ્યા બનાવવામાં આવશે.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// એક ઇરેટર આપે છે જે અક્ષરના `ચાર્ક્સ તરીકે હેક્સાડેસિમલ યુનિકોડ એસ્કેપ મેળવે છે.
    ///
    /// આ `\u{NNNNNN}` ફોર્મના Rust સિન્ટેક્સવાળા અક્ષરોથી છટકી જશે જ્યાં `NNNNNN` એ હેક્સાડેસિમલ રજૂઆત છે.
    ///
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // અથવા-ઇંગ 1 સુનિશ્ચિત કરે છે કે સી માટે==0 કોડ ગણતરી કરે છે કે એક અંક છાપવો જોઈએ અને (જે સમાન છે)(31, 32) ભૂગર્ભને ટાળે છે
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // સૌથી નોંધપાત્ર હેક્સ અંકોનું અનુક્રમણિકા
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` નું વિસ્તૃત સંસ્કરણ જે વિસ્તૃત ગ્રાફાઇમ કોડિપોઇન્ટ્સને બહાર નીકળવાની મંજૂરી આપે છે.
    /// આ અમને શબ્દમાળાની શરૂઆતમાં હોય ત્યારે અક્ષરોને નોનસ્પેસિંગ માર્ક્સ જેવા વધુ સારી રીતે ફોર્મેટ કરવાની મંજૂરી આપે છે.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// એક ઇરેટર આપે છે જે અક્ષરનો શાબ્દિક એસ્કેપ કોડ `ચાર્જ તરીકે આપે છે.
    ///
    /// આ `str` અથવા `char` ના `Debug` અમલીકરણો જેવા પાત્રોથી છટકી જશે.
    ///
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// એક ઇરેટર આપે છે જે અક્ષરનો શાબ્દિક એસ્કેપ કોડ `ચાર્જ તરીકે આપે છે.
    ///
    /// ડિફલ્ટને શાબ્દિક ઉત્પાદન માટેના પૂર્વગ્રહ સાથે પસંદ કરવામાં આવે છે જે ઝેડ 0 સી ++ 0 ઝેડ 11 અને સમાન સી-ફેમિલી ભાષાઓ સહિત વિવિધ ભાષાઓમાં કાયદેસર હોય છે.
    /// ચોક્કસ નિયમો છે:
    ///
    /// * ટ Tabબ `\t` તરીકે છટકી ગયો છે.
    /// * કેરેજ રીટર્ન `\r` તરીકે છટકી ગયો છે.
    /// * લાઇન ફીડ `\n` તરીકે છટકી ગયો છે.
    /// * સિંગલ ક્વોટ `\'` તરીકે છટકી ગયો છે.
    /// * ડબલ ક્વોટ `\"` તરીકે છટકી ગયો છે.
    /// * બેકસ્લેશ `\\` તરીકે છટકી ગયો છે.
    /// * 'છાપવા યોગ્ય ASCII' શ્રેણીના કોઈપણ અક્ષર `0x20` .. `0x7e` સમાવિષ્ટ છટકી નથી.
    /// * અન્ય તમામ પાત્રોને હેક્સાડેસિમલ યુનિકોડ એસ્કેપ આપવામાં આવે છે;[`escape_unicode`] જુઓ.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// જો UTF-8 માં એન્કોડ કરેલ હોય તો આ `char` ની જરૂર પડશે તે બાઇટ્સની સંખ્યા પરત કરે છે.
    ///
    /// તે બાઇટ્સની સંખ્યા હંમેશાં 1 અને 4 ની વચ્ચે હોય છે, શામેલ છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` પ્રકાર તેની બાંયધરી આપે છે કે તેના સમાવિષ્ટો UTF-8 છે, અને તેથી જો દરેક કોડ પોઇન્ટને `&str` વિમાં X X2X તરીકે રજૂ કરવામાં આવે તો તે લેતી લંબાઈની તુલના કરી શકીએ:
    ///
    ///
    /// ```
    /// // અક્ષરો તરીકે
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // બંનેને ત્રણ બાઇટ્સ તરીકે રજૂ કરી શકાય છે
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str તરીકે, આ બંનેને UTF-8 માં એન્કોડ કરવામાં આવ્યા છે
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // અમે જોઈ શકીએ કે તેઓ કુલ છ બાઇટ્સ લે છે ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... માત્ર &str ની જેમ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// જો UTF-16 માં એન્કોડ કરેલા હોય તો આ `char` માટે 16-બીટ કોડ એકમોની સંખ્યા પરત કરે છે.
    ///
    ///
    /// આ ખ્યાલના વધુ ખુલાસા માટે [`len_utf8()`] માટે દસ્તાવેજીકરણ જુઓ.
    /// આ ફંક્શન એક અરીસો છે, પરંતુ UTF-8 ને બદલે UTF-8 માટે.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// આ પાત્રને UTF-8 તરીકે પ્રદાન કરેલા બાઇટ બફરમાં એન્કોડ કરે છે, અને પછી બફરની સબસ્લાઇસ આપે છે જેમાં એન્કોડ કરેલું પાત્ર હોય છે.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો બફર પૂરતો મોટો ન હોય.
    /// કોઈપણ લંબાઈનો બફર કોઈપણ `char` એન્કોડ કરવા માટે પૂરતો મોટો છે.
    ///
    /// # Examples
    ///
    /// આ બંને ઉદાહરણોમાં, 'ß' એન્કોડ કરવા માટે બે બાઇટ્સ લે છે.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// બફર જે ખૂબ નાનો છે:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // સલામતી: `char` એ સરોગેટ નથી, તેથી આ માન્ય UTF-8 છે.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// આ પાત્રને UTF-16 તરીકે પૂરા પાડવામાં આવેલા `u16` બફરમાં એન્કોડ કરે છે, અને પછી એન્કરલ પાત્ર ધરાવતા બફરની સબ્લિસિસ આપે છે.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો બફર પૂરતો મોટો ન હોય.
    /// કોઈપણ `char` ને એન્કોડ કરવા માટે લંબાઈ 2 નો બફર એટલો મોટો છે.
    ///
    /// # Examples
    ///
    /// આ બંને ઉદાહરણોમાં, '𝕊' એન્કોડ કરવામાં બે takes u16` લે છે.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// બફર જે ખૂબ નાનો છે:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// જો આ `char` માં `Alphabetic` ગુણધર્મ હોય તો `true` પરત કરે છે.
    ///
    /// `Alphabetic` [Unicode Standard] ના પ્રકરણ 4 (અક્ષર ગુણધર્મો) માં વર્ણવેલ છે અને [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] માં ઉલ્લેખિત છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // પ્રેમ એ ઘણી વસ્તુઓ છે, પરંતુ તે મૂળાક્ષર નથી
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// જો આ `char` માં `Lowercase` ગુણધર્મ હોય તો `true` પરત કરે છે.
    ///
    /// `Lowercase` [Unicode Standard] ના પ્રકરણ 4 (અક્ષર ગુણધર્મો) માં વર્ણવેલ છે અને [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] માં ઉલ્લેખિત છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // વિવિધ ચાઇનીઝ સ્ક્રિપ્ટો અને વિરામચિહ્નોમાં કેસ નથી, અને તેથી:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// જો આ `char` માં `Uppercase` ગુણધર્મ હોય તો `true` પરત કરે છે.
    ///
    /// `Uppercase` [Unicode Standard] ના પ્રકરણ 4 (અક્ષર ગુણધર્મો) માં વર્ણવેલ છે અને [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] માં ઉલ્લેખિત છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // વિવિધ ચાઇનીઝ સ્ક્રિપ્ટો અને વિરામચિહ્નોમાં કેસ નથી, અને તેથી:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// જો આ `char` માં `White_Space` ગુણધર્મ હોય તો `true` પરત કરે છે.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] માં ઉલ્લેખિત છે.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // એક તૂટી જગ્યા
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// જો આ `char` [`is_alphabetic()`] અથવા [`is_numeric()`] ક્યાં સંતોષે તો `true` આપે છે.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// જો આ `char` પાસે નિયંત્રણ કોડ માટેની સામાન્ય કેટેગરી હોય તો `true` પરત કરે છે.
    ///
    /// કંટ્રોલ કોડ્સ (`Cc` ની સામાન્ય કેટેગરી સાથેના કોડ પોઇન્ટ) [Unicode Standard] ના પ્રકરણ 4 (અક્ષર ગુણધર્મો) માં વર્ણવેલ છે અને [Unicode Character Database][ucd] [`UnicodeData.txt`] માં ઉલ્લેખિત છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // યુ +009 સી, STRING ટર્મિનેટર
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// જો આ `char` માં `Grapheme_Extend` ગુણધર્મ હોય તો `true` પરત કરે છે.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] માં વર્ણવેલ છે અને [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] માં ઉલ્લેખિત છે.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// જો આ `char` પાસે સંખ્યાઓ માટેની એક સામાન્ય કેટેગરી હોય તો `true` આપે છે.
    ///
    /// [Unicode Character Database][ucd] [`UnicodeData.txt`] માં સંખ્યાઓ માટેની સામાન્ય કેટેગરીઝ (દશાંશ અંકો માટે `Nd`, અક્ષર જેવા આંકડાકીય અક્ષરો માટે `Nl` અને અન્ય આંકડાકીય અક્ષરો માટે `No`) ઉલ્લેખિત છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// એક ઇરેટરને પરત કરે છે જે આ `char` ની એક અથવા વધુ તરીકે લોઅરકેસ મેપિંગ આપે છે
    /// `char`s.
    ///
    /// જો આ `char` ની પાસે લોઅરકેસ મેપિંગ નથી, તો પુનરાવર્તક સમાન `char` મેળવે છે.
    ///
    /// જો આ `char` માં [Unicode Character Database][ucd] [`UnicodeData.txt`] દ્વારા આપવામાં આવેલ એકથી એક લોઅરકેસ મેપિંગ હોય, તો પુનરાવર્તક તે `char` આપે છે.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// જો આ `char` ને વિશેષ વિચારણાની જરૂર હોય (દા.ત. મલ્ટીપલ `ચાર્જ) ઇરેટર [`SpecialCasing.txt`] દ્વારા અપાયેલ` ચાર્જ (ઓ) આપે છે.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// આ ક્રિયા ટેલરિંગ વિના બિનશરતી મેપિંગ કરે છે.તે છે, રૂપાંતર સંદર્ભ અને ભાષાથી સ્વતંત્ર છે.
    ///
    /// [Unicode Standard] માં, પ્રકરણ 4 (અક્ષર ગુણધર્મો) સામાન્ય રીતે કેસ મેપિંગની ચર્ચા કરે છે અને પ્રકરણ 3 (Conformance) કેસ રૂપાંતર માટે ડિફોલ્ટ અલ્ગોરિધમની ચર્ચા કરે છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // કેટલીકવાર પરિણામ એક કરતાં વધુ પાત્ર આવે છે:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // અક્ષરો કે જેમાં અપરકેસ અને લોઅરકેસ બંને નથી, તેઓ પોતાને રૂપાંતરિત કરે છે.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// એક ઇરેટરને પરત કરે છે જે આ `char` ના અપરકેસ મેપિંગને એક અથવા વધુ તરીકે આપે છે
    /// `char`s.
    ///
    /// જો આ `char` પાસે અપરકેસ મેપિંગ નથી, તો ઇરેટર સમાન `char` આપે છે.
    ///
    /// જો આ `char` માં [Unicode Character Database][ucd] [`UnicodeData.txt`] દ્વારા આપવામાં આવેલ એક થી એક અપરકેસ મેપિંગ હોય, તો પુનરાવર્તક તે `char` આપે છે.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// જો આ `char` ને વિશેષ વિચારણાની જરૂર હોય (દા.ત. મલ્ટીપલ `ચાર્જ) ઇરેટર [`SpecialCasing.txt`] દ્વારા અપાયેલ` ચાર્જ (ઓ) આપે છે.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// આ ક્રિયા ટેલરિંગ વિના બિનશરતી મેપિંગ કરે છે.તે છે, રૂપાંતર સંદર્ભ અને ભાષાથી સ્વતંત્ર છે.
    ///
    /// [Unicode Standard] માં, પ્રકરણ 4 (અક્ષર ગુણધર્મો) સામાન્ય રીતે કેસ મેપિંગની ચર્ચા કરે છે અને પ્રકરણ 3 (Conformance) કેસ રૂપાંતર માટે ડિફોલ્ટ અલ્ગોરિધમની ચર્ચા કરે છે.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// પુનરાવર્તક તરીકે:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// સીધા `println!` નો ઉપયોગ:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// બંને સમાન છે:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` નો ઉપયોગ કરીને:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // કેટલીકવાર પરિણામ એક કરતાં વધુ પાત્ર આવે છે:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // અક્ષરો કે જેમાં અપરકેસ અને લોઅરકેસ બંને નથી, તેઓ પોતાને રૂપાંતરિત કરે છે.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # લોકેલ પર નોંધ
    ///
    /// ટર્કીશમાં, લેટિનમાં 'i' ની બરાબર બેની જગ્યાએ પાંચ સ્વરૂપો છે:
    ///
    /// * 'Dotless': હું/ı, ક્યારેક લખેલું ï
    /// * 'Dotted': İ/i
    ///
    /// નોંધ લો કે લોઅરકેસ ડોટેડ 'i' લેટિન જેવું જ છે.તેથી:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// અહીં `upper_i` નું મૂલ્ય ટેક્સ્ટની ભાષા પર આધાર રાખે છે: જો આપણે `en-US` માં છીએ, તો તે `"I"` હોવું જોઈએ, પરંતુ જો આપણે `tr_TR` માં છો, તો તે `"İ"` હોવું જોઈએ.
    /// `to_uppercase()` આને ધ્યાનમાં લેતા નથી, અને તેથી:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ભાષાઓમાં ધરાવે છે.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// મૂલ્ય ASCII ની અંદર છે કે કેમ તે તપાસે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// તેના ASCII અપર કેસ સમકક્ષ મૂલ્યની એક નકલ બનાવે છે.
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// સ્થળને મૂલ્યમાં મોટા કરવા માટે, [`make_ascii_uppercase()`] નો ઉપયોગ કરો.
    ///
    /// બિન-ASCII અક્ષરો ઉપરાંત, ASCII અક્ષરો મોટા કરવા માટે, [`to_uppercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// તેના ASCII લોઅર કેસ સમકક્ષ મૂલ્યની એક નકલ બનાવે છે.
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// જગ્યામાં મૂલ્ય ઘટાડવા માટે, [`make_ascii_lowercase()`] નો ઉપયોગ કરો.
    ///
    /// નાના-ASCII અક્ષરો ઉપરાંત, ASCII અક્ષરોને નાના કરવા માટે, [`to_lowercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// તપાસ કરે છે કે બે મૂલ્યો એએસસીઆઈઆઈ કેસ-સંવેદનશીલ મેચ છે.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ની સમકક્ષ.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// આ પ્રકારને તેના ASCII અપર કેસમાં સમાન સ્થાને રૂપાંતરિત કરે છે.
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું અપરકેસ્ડ મૂલ્ય પાછું આપવા માટે, [`to_ascii_uppercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// આ પ્રકારને તેની ASCII લોઅર કેસમાં સમાન જગ્યાએ રૂપાંતરિત કરે છે.
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// અસ્તિત્વમાંના કોઈ ફેરફાર કર્યા વિના નવું નીચલું મૂલ્ય પાછું આપવા માટે, [`to_ascii_lowercase()`] નો ઉપયોગ કરો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// મૂલ્ય એએસસીઆઈઆઈ મૂળાક્ષર અક્ષર છે કે કેમ તે તપાસો:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', અથવા
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// મૂલ્ય એ ASCII અપરકેસ અક્ષર છે કે કેમ તે તપાસો:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ લોઅરકેસ અક્ષર છે કે કેમ તે તપાસો:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ આલ્ફાન્યુમેરિક અક્ષર છે કે કેમ તે તપાસો:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', અથવા
    /// - U + 0061 'a' ..=U + 007A 'z', અથવા
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ દશાંશ અંક છે કે કેમ તે તપાસો:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ હેક્સાડેસિમલ અંક છે કે કેમ તે તપાસો:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', અથવા
    /// - U + 0041 'A' ..=U + 0046 'F', અથવા
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ વિરામચિહ્નો છે કે કેમ તે તપાસો:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, અથવા
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, અથવા
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, અથવા
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ ગ્રાફિક પાત્ર છે કે કેમ તે તપાસો:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ વ્હાઇટ સ્પેસ પાત્ર છે કે કેમ તે તપાસો:
    /// યુ + 0020 સ્પેસ, યુ + 0009 હોરિઝન્ટલ ટેબ, યુ + 000 એ લાઈન ફીડ, યુ + 000 સી ફોર્મ ફીડ અથવા યુ + 000 ડી કેરેજ પાછો.
    ///
    /// ઝેડ રસ્ટ0 ઝેડ ડબલ્યુડબલ્યુજી ઈન્ફ્રા સ્ટાન્ડર્ડની [definition of ASCII whitespace][infra-aw] નો ઉપયોગ કરે છે.વ્યાપક ઉપયોગમાં બીજી ઘણી વ્યાખ્યાઓ છે.
    /// હમણાં પૂરતું, [the POSIX locale][pct] માં U + 000B VERTICAL TAB તેમ જ ઉપરનાં બધા પાત્રો શામેલ છે, પરંતુ same એક સરખા સ્પષ્ટીકરણથી-[બોર્ને ઝેડશેલ 0 ઝેડમાં "field splitting" માટેનો મૂળભૂત નિયમ][બીએફએસ]*ફક્ત* સ્પેસ, હોરિઝન્ટલ ટેબ અને વ્હાઇટ સ્પેસ તરીકે લાઈન ફીડ.
    ///
    ///
    /// જો તમે કોઈ પ્રોગ્રામ લખી રહ્યાં છો જે હાલના ફાઇલ ફોર્મેટ પર પ્રક્રિયા કરશે, તો આ ફંક્શનનો ઉપયોગ કરતા પહેલા તે ફોર્મેટની વ્હાઇટ સ્પેસની વ્યાખ્યા શું છે તે તપાસો.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// મૂલ્ય એએસસીઆઈઆઈ નિયંત્રણ પાત્ર છે કે કેમ તે તપાસો:
    /// યુ +0000 એનયુએલ ..=યુ +001F યુનિટ સેપરેટર, અથવા યુ +007 એફ કાLEી નાખો.
    /// નોંધ લો કે મોટાભાગની ASCII ગોરા જગ્યા અક્ષરો નિયંત્રણ અક્ષરો છે, પરંતુ સ્પેસ તે નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// પૂરા પાડવામાં આવેલ બાઇટ બફરમાં UTF-8 તરીકેના કાચા u32 મૂલ્યને એન્કોડ કરે છે, અને પછી એન્કરલ પાત્ર ધરાવતા બફરની સબ્લિસિસ આપે છે.
///
///
/// `char::encode_utf8` થી વિપરીત, આ પદ્ધતિ સરોગેટ રેન્જમાં કોડપointsઇન્ટ્સને પણ હેન્ડલ કરે છે.
/// (સરોગેટ રેન્જમાં `char` બનાવવાનું યુબી છે.) પરિણામ માન્ય [generalized UTF-8] છે પરંતુ માન્ય UTF-8 નથી.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics જો બફર પૂરતો મોટો ન હોય.
/// કોઈપણ લંબાઈનો બફર કોઈપણ `char` એન્કોડ કરવા માટે પૂરતો મોટો છે.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// પૂરા પાડવામાં આવેલા `u16` બફરમાં UTF-16 તરીકેના કાચા u32 મૂલ્યને એન્કોડ કરે છે, અને પછી એન્કરલ પાત્ર ધરાવતા બફરની સબસ્લાઇસ આપે છે.
///
///
/// `char::encode_utf16` થી વિપરીત, આ પદ્ધતિ સરોગેટ રેન્જમાં કોડપointsઇન્ટ્સને પણ હેન્ડલ કરે છે.
/// (સરોગેટ રેન્જમાં `char` બનાવવાનું યુબી છે.)
///
/// # Panics
///
/// Panics જો બફર પૂરતો મોટો ન હોય.
/// કોઈપણ `char` ને એન્કોડ કરવા માટે લંબાઈ 2 નો બફર એટલો મોટો છે.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // સલામતી: દરેક હાથ તપાસ કરે છે કે તેમાં લખવા માટે પૂરતા બિટ્સ છે કે કેમ
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // બીએમપી પસાર થાય છે
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // પૂરક વિમાનો સરોગેટ્સમાં તૂટી જાય છે.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}