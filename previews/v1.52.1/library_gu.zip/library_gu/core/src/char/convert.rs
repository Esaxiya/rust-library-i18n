//! અક્ષર રૂપાંતર.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ને `char` માં રૂપાંતરિત કરે છે.
///
/// નોંધ લો કે બધા [`ચાર્જ] માન્ય છે [` u32`] ઓ, અને જેની સાથે કાસ્ટ કરી શકાય છે
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// જો કે, વિપરીત સાચું નથી: બધા માન્ય [`u32`] ઓ માન્ય નથી [`ચ`ર] ઓ.
/// `from_u32()` જો ઇનપુટ [`char`] માટે માન્ય મૂલ્ય ન હોય તો `None` પરત કરશે.
///
/// આ ફંક્શનના અસુરક્ષિત સંસ્કરણ માટે, જે આ તપાસને અવગણે છે, [`from_u32_unchecked`] જુઓ.
///
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ઇનપુટ માન્ય [`char`] ન હોય ત્યારે `None` પરત આપવું:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// માન્યતાને અવગણીને, `u32` ને `char` માં રૂપાંતરિત કરે છે.
///
/// નોંધ લો કે બધા [`ચાર્જ] માન્ય છે [` u32`] ઓ, અને જેની સાથે કાસ્ટ કરી શકાય છે
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// જો કે, વિપરીત સાચું નથી: બધા માન્ય [`u32`] ઓ માન્ય નથી [`ચ`ર] ઓ.
/// `from_u32_unchecked()` આને અવગણશે, અને [`char`] પર આંખેથી કાસ્ટ થશે, સંભવત અમાન્ય બનાવે છે.
///
///
/// # Safety
///
/// આ કાર્ય અસુરક્ષિત છે, કારણ કે તે અમાન્ય `char` મૂલ્યોનું નિર્માણ કરી શકે છે.
///
/// આ ફંક્શનના સલામત સંસ્કરણ માટે, [`from_u32`] ફંક્શન જુઓ.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // સલામતી: ક theલરને ગેરેંટી આપવી આવશ્યક છે કે `i` એ માન્ય ચાર મૂલ્ય છે.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ને [`u32`] માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ને [`u64`] માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ચર કોડ પોઇન્ટના મૂલ્ય પર કાસ્ટ કરવામાં આવે છે, પછી શૂન્ય-વિસ્તૃત 64 બીટ પર.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] જુઓ
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ને [`u128`] માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ચર કોડ પોઇન્ટના મૂલ્ય પર કાસ્ટ કરવામાં આવે છે, પછી શૂન્ય-વિસ્તૃત 128 બીટ પર.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] જુઓ
        c as u128
    }
}

/// 0x00 માં બાઇટ નકશા ..=0xFF એક `char` માટે જેના કોડ પોઇન્ટ સમાન મૂલ્ય છે, U +0000 ..=U + 00FF માં.
///
/// યુનિકોડનું નિર્માણ આ રીતે કરવામાં આવ્યું છે કે આ અક્ષર એન્કોડિંગથી બાઇટ્સને અસરકારક રીતે ડીકોડ કરે છે જેને આઇએએનએ આઇએસઓ-8859-1 કહે છે.
/// આ એન્કોડિંગ ASCII સાથે સુસંગત છે.
///
/// નોંધ લો કે આ ISO/IEC 8859-1 ઉર્ફેથી અલગ છે
/// આઇએસઓ 8859-1 (એક ઓછા હાઈફન સાથે), જે કેટલાક "blanks", બાઇટ મૂલ્યોને છોડી દે છે જે કોઈપણ પાત્રને સોંપાયેલ નથી.
/// ISO-8859-1 (IANA એક) તેમને C0 અને C1 નિયંત્રણ કોડમાં સોંપે છે.
///
/// નોંધ લો કે આ * વિન્ડોઝ-1222 ઉર્ફથી પણ અલગ છે
/// કોડ પૃષ્ઠ 1252, જે સુપરસેટ ISO/IEC 8859-1 છે જે વિરામચિહ્નો અને વિવિધ લેટિન અક્ષરોને કેટલાક (બધા નહીં!) બ્લેન્ક સોંપે છે.
///
/// વસ્તુઓને વધુ મૂંઝવણમાં કરવા માટે, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` અને `windows-1252` એ વિન્ડોઝ-122 સુપરસ્ટેટ માટેના બધા ઉપનામો છે જે બાકીના બ્લેન્ક્સને અનુરૂપ C0 અને C1 નિયંત્રણ કોડથી ભરે છે.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ને [`char`] માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// એક ભૂલ જે ચાર્ક્સનું વિશ્લેષણ કરતી વખતે પરત મળી શકે.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // સલામતી: તપાસ્યું કે તે કાનૂની યુનિકોડ મૂલ્ય છે
            Ok(unsafe { transmute(i) })
        }
    }
}

/// જ્યારે u32 થી ચારમાં રૂપાંતર નિષ્ફળ જાય ત્યારે ભૂલનો પ્રકાર પાછો ફર્યો.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// આપેલા મૂળાના અંકોને `char` માં ફેરવે છે.
///
/// અહીંના 'radix' ને કેટલીકવાર 'base' પણ કહેવામાં આવે છે.
/// બેના મૂળમાં દ્વિસંગી સંખ્યા, દસનો દશાંશ, દશાંશ, અને સોળનો હેડક્સેસિમલનો મૂળો સૂચવવામાં આવે છે, જેથી કેટલાક સામાન્ય મૂલ્યો આપવામાં આવે.
///
/// મનસ્વી મુળ આધારભૂત છે.
///
/// `from_digit()` જો ઇનપુટ આપેલ ત્રિજ્યામાં અંક ન હોય તો `None` પરત કરશે.
///
/// # Panics
///
/// ઝેડ પPનિક્સ 0 ઝેડ જો 36 થી વધુનો રેડિક્સ આપવામાં આવે.
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // દશાંશ 11 એ આધાર 16 માં એક અંક છે
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ઇનપુટ અંક ન હોય ત્યારે `None` પરત આપવું:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ઝિડપેનિક0 ઝેડનું કારણ બને છે, મોટા મૂળાક્ષમાં પસાર થવું:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}