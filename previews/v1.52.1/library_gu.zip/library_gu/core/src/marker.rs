//! આદિમ traits અને પ્રકારો મૂળભૂત ગુણધર્મોનું પ્રતિનિધિત્વ કરે છે.
//!
//! ઝેડ રસ્ટ0 ઝેડ પ્રકારોને તેમની આંતરિક ગુણધર્મો અનુસાર વિવિધ ઉપયોગી રીતોમાં વર્ગીકૃત કરી શકાય છે.
//! આ વર્ગીકરણ traits તરીકે રજૂ થાય છે.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// પ્રકારો કે જે થ્રેડ સીમાઓ પર સ્થાનાંતરિત કરી શકાય છે.
///
/// જ્યારે કમ્પાઇલર તે યોગ્ય છે તે નિર્ધારિત કરે છે ત્યારે આ trait આપમેળે અમલમાં મૂકાય છે.
///
/// નોન-સેન્ડ` પ્રકારનું ઉદાહરણ સંદર્ભ-ગણતરી પોઇન્ટર [`rc::Rc`][`Rc`] છે.
/// જો બે થ્રેડો [`Rc`] s ને ક્લોન કરવાનો પ્રયાસ કરે છે જે સમાન સંદર્ભ-ગણતરી મૂલ્ય તરફ નિર્દેશ કરે છે, તો તેઓ એક જ સમયે સંદર્ભ ગણતરીને અપડેટ કરવાનો પ્રયાસ કરી શકે છે, જે [undefined behavior][ub] છે કારણ કે [`Rc`] અણુ ક્રિયાઓનો ઉપયોગ કરતું નથી.
///
/// તેનો પિતરાઇ [`sync::Arc`][arc] અણુ operationsપરેશનનો ઉપયોગ કરે છે (કેટલાક ઓવરહેડ સાથે) અને તેથી તે `Send` છે.
///
/// વધુ વિગતો માટે [the Nomicon](../../nomicon/send-and-sync.html) જુઓ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// સંકલન સમયે જાણીતા સ્થિર કદવાળા પ્રકારો.
///
/// બધા પ્રકારનાં પરિમાણો `Sized` ની અંતર્ગત બાઉન્ડ હોય છે.જો આ બંધન યોગ્ય નથી, તો તેને દૂર કરવા માટે ખાસ સિન્ટેક્સ `?Sized` નો ઉપયોગ કરી શકાય છે.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // સ્ટ્રક્ટ FooUse(Foo<[i32]>);//ભૂલ: કદના [i32] માટે લાગુ કરાયા નથી
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// એક અપવાદ એ ઝેડટ્રેટ 0 ઝેડનો ગર્ભિત `Self` પ્રકાર છે.
/// trait માં બાહ્ય `Sized` બાઉન્ડ નથી કારણ કે આ [trait]બ્જેક્ટ] s સાથે અસંગત છે, જ્યાં વ્યાખ્યા દ્વારા, trait એ બધા સંભવિત અમલકારો સાથે કામ કરવાની જરૂર છે, અને તેથી તે કોઈપણ કદ હોઈ શકે છે.
///
///
/// તેમ છતાં Rust તમને `Sized` ને trait પર બાંધી દેશે, તમે પછીથી trait formબ્જેક્ટ રચવા માટે તેનો ઉપયોગ કરી શકશો નહીં:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ચાલો y: &dyn બાર= &Impl;//ભૂલ: trait `Bar` objectબ્જેક્ટમાં બનાવી શકાતી નથી
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ડિફaultલ્ટ માટે, ઉદાહરણ તરીકે, જેને આવશ્યક છે કે `[T]: !Default` મૂલ્યાંકનક્ષમ હોય
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// પ્રકારો કે જે ગતિશીલ કદના પ્રકારનાં "unsized" હોઈ શકે છે.
///
/// ઉદાહરણ તરીકે, કદના એરે પ્રકાર `[i8; 2]`, `Unsize<[i8]>` અને `Unsize<dyn fmt::Debug>` ને લાગુ કરે છે.
///
/// `Unsize` ના બધા અમલીકરણો કમ્પાઇલર દ્વારા આપમેળે પ્રદાન કરવામાં આવ્યાં છે.
///
/// `Unsize` આના માટે અમલ કરાયો છે:
///
/// - `[T; N]` `Unsize<[T]>` છે
/// - `T` જ્યારે `T: Trait` છે ત્યારે `Unsize<dyn Trait>` છે
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` છે જો:
///   - `T: Unsize<U>`
///   - ફૂ એક સ્ટ્રક્ટ છે
///   - ફક્ત `Foo` ના છેલ્લા ક્ષેત્રમાં એક પ્રકારનો સમાવેશ છે જેમાં `T` શામેલ છે
///   - `T` તે અન્ય કોઈપણ ક્ષેત્રના પ્રકારનો ભાગ નથી
///   - `Bar<T>: Unsize<Bar<U>>`, જો `Foo` ના છેલ્લા ક્ષેત્રમાં પ્રકાર `Bar<T>` હોય
///
/// `Unsize` "user-defined" જેવા કન્ટેનર જેમ કે ગતિશીલ-કદના પ્રકારો સમાવવા માટે "user-defined" કન્ટેનરને મંજૂરી આપવા માટે, [`ops::CoerceUnsized`] ની સાથે ઉપયોગ થાય છે.
/// વધુ વિગતો માટે [DST coercion RFC][RFC982] અને [the nomicon entry on coercion][nomicon-coerce] જુઓ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// પેટર્નની મેચમાં ઉપયોગમાં લેવાતા સ્થિરતા માટે trait આવશ્યક છે.
///
/// કોઈપણ પ્રકારનો જે `PartialEq` મેળવે છે તે આ trait ને આપમેળે લાગુ કરે છે, તેના પ્રકારનાં પરિમાણો `Eq` ને લાગુ કરે છે કે નહીં તેની *અનુલક્ષીને*.
///
/// જો કોઈ `const` આઇટમમાં કેટલાક પ્રકારનો સમાવેશ છે જે આ trait ને અમલમાં મૂકતો નથી, તો તે પ્રકાર ક્યાં (1.) `PartialEq` ને લાગુ કરતું નથી (જેનો અર્થ એ છે કે તે તુલનાત્મક પદ્ધતિ પ્રદાન કરશે નહીં, જે કોડ જનરેશન ધારે છે તે ઉપલબ્ધ છે), અથવા (2.) તે અમલીકરણ કરે છે *તેના પોતાના*`PartialEq` નું સંસ્કરણ (જે આપણે ધારીએ છીએ તે માળખાકીય-સમાનતાની તુલનાને અનુરૂપ નથી).
///
///
/// ઉપરના બે સંજોગોમાં, આપણે પેટર્નની મેચમાં આવા સતતનો ઉપયોગ નકારીએ છીએ.
///
/// [structural match RFC][RFC1445] અને [issue 63438] પણ જુઓ જેણે આ trait પર એટ્રિબ્યુટ-આધારિત ડિઝાઇનથી સ્થળાંતર કરવાની પ્રેરણા આપી છે.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// પેટર્નની મેચમાં ઉપયોગમાં લેવાતા સ્થિરતા માટે trait આવશ્યક છે.
///
/// કોઈપણ પ્રકારનો કે જે `Eq` મેળવે છે તે આ trait ને આપમેળે લાગુ કરે છે, તેના પ્રકારનાં પરિમાણો `Eq` લાગુ કરે છે કે નહીં તેની *અનુલક્ષીને*.
///
/// અમારી પ્રકારની સિસ્ટમની મર્યાદાની આસપાસ કામ કરવા માટે આ એક હેક છે.
///
/// # Background
///
/// અમે તે જરૂરી છે કે પેટર્ન મેચોમાં ઉપયોગમાં લેવાતા પ્રકારનાં કોન્સટ્સમાં `#[derive(PartialEq, Eq)]` એટ્રિબ્યુટ હોય.
///
/// વધુ આદર્શ વિશ્વમાં, અમે તે આવશ્યકતાને ફક્ત તપાસ કરીને ચકાસી શકીએ કે આપેલ પ્રકાર `StructuralPartialEq` trait *અને*`Eq` trait બંનેને લાગુ કરે છે.
/// જો કે, તમારી પાસે ADTs હોઈ શકે છે જે *કરે છે*`derive(PartialEq, Eq)`, અને એવું બન્યું કે આપણે કમ્પાઇલર સ્વીકારવા માગીએ, અને છતાં સતત પ્રકાર `Eq` ને લાગુ કરવામાં નિષ્ફળ જાય છે.
///
/// જેમ કે, આના જેવો કેસ:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ઉપરોક્ત કોડની સમસ્યા એ છે કે `Wrap<fn(&())>`, `PartialEq` અને `Eq` લાગુ કરતું નથી, કારણ કે '<' a> fn(&'a _)` does not implement those traits.) માટે
///
/// તેથી, અમે `StructuralPartialEq` અને માત્ર `Eq` માટે નિષ્કપટ તપાસ પર આધાર રાખી શકીએ નહીં.
///
/// આની આસપાસ કામ કરવા માટે, અમે બે અલગ અલગ ઝેડટ્રેટ 0 ઝેડનો ઉપયોગ કરીએ છીએ જે બંને ડેરિવેઝ (`#[derive(PartialEq)]` અને `#[derive(Eq)]`) દ્વારા કરવામાં આવે છે અને તપાસો કે તે બંને સ્ટ્રક્ચરલ-મેચ ચેકિંગના ભાગ રૂપે હાજર છે.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// પ્રકારો કે જેના મૂલ્યો બીટ્સની નકલ કરીને ફક્ત નકલ કરી શકાય છે.
///
/// ડિફ defaultલ્ટ રૂપે, વેરિયેબલ બાઇન્ડિંગ્સમાં 'મૂવ સેમેન્ટિક્સ' હોય છે.બીજા શબ્દો માં:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` માં ખસેડવામાં આવી છે, અને તેથી તેનો ઉપયોગ કરી શકાતો નથી
///
/// // println! ("{: ?}", x);//ભૂલ: ખસેડવામાં આવેલા મૂલ્યનો ઉપયોગ
/// ```
///
/// જો કે, જો કોઈ પ્રકાર `Copy` લાગુ કરે છે, તો તેના બદલે 'કોપી સીમેન્ટિક્સ' છે:
///
/// ```
/// // અમે `Copy` અમલીકરણ મેળવી શકીએ છીએ.
/// // `Clone` તે પણ આવશ્યક છે, કારણ કે તે `Copy` નું સુપરટ્રેટ છે.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` ની નકલ છે
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// એ નોંધવું મહત્વપૂર્ણ છે કે આ બે ઉદાહરણોમાં, ફક્ત એટલો જ ફરક છે કે તમને સોંપણી પછી `x` accessક્સેસ કરવાની મંજૂરી છે કે નહીં.
/// હૂડ હેઠળ, એક નકલ અને ચાલ બંને, બિટ્સને મેમરીમાં નકલ કરવામાં પરિણમી શકે છે, જો કે આ કેટલીકવાર દૂર કરવામાં આવે છે.
///
/// ## હું `Copy` ને કેવી રીતે અમલમાં મૂકી શકું?
///
/// તમારા પ્રકાર પર `Copy` લાગુ કરવાની બે રીત છે.`derive` નો ઉપયોગ કરવો સૌથી સરળ છે:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// તમે જાતે જ `Copy` અને `Clone` પણ લાગુ કરી શકો છો:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// બંને વચ્ચે એક નાનો તફાવત છે: `derive` વ્યૂહરચના પણ પ્રકારનાં પરિમાણો પર બંધાયેલા `Copy` મૂકશે, જે હંમેશા ઇચ્છિત હોતી નથી.
///
/// ## `Copy` અને `Clone` વચ્ચે શું તફાવત છે?
///
/// નકલો સ્પષ્ટ રીતે થાય છે, ઉદાહરણ તરીકે, સોંપણી `y = x` ના ભાગ રૂપે.`Copy` ની વર્તણૂક ઓવરલોડેબલ નથી;તે હંમેશાં એક સરળ બીટ મુજબની ક isપિ છે.
///
/// ક્લોનીંગ એ એક સ્પષ્ટ ક્રિયા છે, `x.clone()`.[`Clone`] નો અમલ સલામત મૂલ્યોની ડુપ્લિકેટ કરવા માટે જરૂરી કોઈપણ પ્રકારની વિશિષ્ટ વર્તન પ્રદાન કરી શકે છે.
/// ઉદાહરણ તરીકે, [`String`] માટે [`Clone`] ના અમલીકરણને pointedગલામાં પોઇન્ટ-ટુ શબ્દમાળા બફરની નકલ કરવાની જરૂર છે.
/// [`String`] કિંમતોની એક સરળ બીટવાઇઝ નકલ ફક્ત નિર્દેશકની નકલ કરશે, જે લીટીની નીચે ડબલ ફ્રી તરફ દોરી જશે.
/// આ કારણોસર, [`String`] એ [`Clone`] છે પરંતુ `Copy` નથી.
///
/// [`Clone`] `Copy` નું સુપરટ્રેટ છે, તેથી જે બધું `Copy` છે તે પણ [`Clone`] અમલમાં મૂકવું જોઈએ.
/// જો કોઈ પ્રકાર `Copy` હોય તો તેના [`Clone`] અમલીકરણમાં ફક્ત `*self` પાછા ફરવાની જરૂર છે (ઉપરનું ઉદાહરણ જુઓ).
///
/// ## જ્યારે મારો પ્રકાર `Copy` હોઈ શકે?
///
/// જો તેના તમામ ઘટકો `Copy` લાગુ કરે છે, તો એક પ્રકાર `Copy` લાગુ કરી શકે છે.ઉદાહરણ તરીકે, આ સ્ટ્ર Xક્ટ `Copy` હોઈ શકે છે:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// સ્ટ્રક્ટ `Copy` હોઈ શકે છે, અને [`i32`] એ `Copy` છે, તેથી `Point` `Copy` બનવા માટે પાત્ર છે.
/// તેનાથી વિપરિત, ધ્યાનમાં લો
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// સ્ટ્રક્ટ `PointList`, `Copy` અમલમાં મૂકી શકશે નહીં, કારણ કે [`Vec<T>`] એ `Copy` નથી.જો આપણે `Copy` અમલીકરણ મેળવવાનો પ્રયાસ કરીએ, તો અમને ભૂલ મળશે:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// શેર કરેલા સંદર્ભો (`&T`) એ `Copy` પણ છે, તેથી પ્રકાર `Copy` હોઈ શકે છે, ભલે તે `T` પ્રકારોના શેર કરેલા સંદર્ભો રાખે છે જે *નથી*`Copy` છે.
/// નીચે આપેલા સ્ટ્ર Considerકનો વિચાર કરો, જે `Copy` ને અમલમાં મૂકી શકે છે, કારણ કે તે ઉપરથી ફક્ત અમારા નોન-કોપી પ્રકાર `PointList` નો *વહેંચાયેલ સંદર્ભ* રાખે છે:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## જ્યારે * મારો પ્રકાર `Copy` ન હોઈ શકે?
///
/// કેટલાક પ્રકારો સુરક્ષિત રીતે કiedપિ કરી શકાતા નથી.ઉદાહરણ તરીકે, `&mut T` ની કyingપિ કરવાથી એલિએસ્ડ પરિવર્તનીય સંદર્ભ બનાવવામાં આવશે.
/// [`String`] ની નકલ કરવાથી [`String`] ના બફરને સંચાલિત કરવાની જવાબદારી ડુપ્લિકેટ થશે, જે ડબલ ફ્રી તરફ દોરી જશે.
///
/// પછીના કિસ્સામાં સામાન્ય બનાવવું, કોઈપણ પ્રકારનું [`Drop`] અમલમાં મૂકવું તે `Copy` હોઈ શકતું નથી, કારણ કે તે તેના પોતાના [`size_of::<T>`] બાઇટ્સ ઉપરાંત કેટલાક સંસાધનનું સંચાલન કરી રહ્યું છે.
///
/// જો તમે કોઈ or કોપી ડેટા ડેટાવાળા સ્ટ્રક્ટ અથવા એન્મ પર `Copy` લાગુ કરવાનો પ્રયાસ કરો છો, તો તમને ભૂલ [E0204] મળશે.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## *જ્યારે* મારો પ્રકાર `Copy` હોવો જોઈએ?
///
/// સામાન્ય રીતે કહીએ તો, જો તમારો પ્રકાર _can_ `Copy` લાગુ કરે છે, તો તે હોવું જોઈએ.
/// ધ્યાનમાં રાખો, જોકે, `Copy` ને અમલમાં મૂકવું એ તમારા પ્રકારનાં સાર્વજનિક API નો ભાગ છે.
/// જો પ્રકાર ઝેડ ફ્યુચર0 ઝેડમાં નોન-કopપિ બની શકે, તો બ્રેકિંગ એપીઆઈ ફેરફારને ટાળવા માટે, હવે `Copy` અમલીકરણને અવગણવું સમજદાર હોઇ શકે.
///
/// ## વધારાના અમલકર્તાઓ
///
/// [implementors listed below][impls] ઉપરાંત, નીચેના પ્રકારો પણ `Copy` લાગુ કરે છે:
///
/// * ફંકશન આઇટમ પ્રકારો (એટલે કે, દરેક કાર્ય માટે અલગ અલગ પ્રકારો વ્યાખ્યાયિત)
/// * ફંક્શન પોઇન્ટર પ્રકારો (દા.ત., `fn() -> i32`)
/// * એરે પ્રકારો, બધા કદ માટે, જો આઇટમ પ્રકાર પણ `Copy` લાગુ કરે છે (દા.ત., `[i32; 123456]`)
/// * ટ્યુપલ પ્રકારો, જો દરેક ઘટક પણ `Copy` લાગુ કરે છે (દા.ત., `()`, `(i32, bool)`)
/// * બંધ કરવાનાં પ્રકારો, જો તેઓ પર્યાવરણમાંથી કોઈ મૂલ્ય મેળવે નહીં અથવા જો આવા બધા કબજે કરેલા મૂલ્યો પોતાને `Copy` લાગુ કરે છે.
///   નોંધ લો કે વહેંચાયેલ સંદર્ભ દ્વારા કબજે કરવામાં આવતા ચલો હંમેશા `Copy` ને લાગુ કરે છે (ભલે તે અલગ ન હોય), જ્યારે પરિવર્તનીય સંદર્ભ દ્વારા કબજે કરવામાં આવતા ચલો ક્યારેય `Copy` ને લાગુ કરતા નથી.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) આ એવા પ્રકારની કyingપિ કરવાની મંજૂરી આપે છે જે `Copy` ને અસંતોષકારક જીવનકાળની મર્યાદાને લીધે લાગુ કરતું નથી (જ્યારે `A<'static>: Copy` અને `A<'_>: Clone` ફક્ત `A<'_>` ની કyingપિ બનાવવી).
// અમારી પાસે આ વિશેષતા હમણાં માટે અહીં છે કારણ કે `Copy` પર પહેલેથી જ પ્રમાણભૂત લાઇબ્રેરીમાં અસ્તિત્વમાં છે, અને હાલમાં આ વર્તનને સુરક્ષિત રીતે રાખવાનો કોઈ રસ્તો નથી.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` નું પ્રોમ્પ્ટ ઉત્પન્ન કરનાર ડિરેવ મેક્રો.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// તે પ્રકારો કે જેના માટે તે થ્રેડો વચ્ચેના સંદર્ભોને શેર કરવું સલામત છે.
///
/// જ્યારે કમ્પાઇલર તે યોગ્ય છે તે નિર્ધારિત કરે છે ત્યારે આ trait આપમેળે અમલમાં મૂકાય છે.
///
/// સચોટ વ્યાખ્યા છે: `T` પ્રકાર [`Sync`] છે જો અને જો `&T` [`Send`] હોય તો જ.
/// બીજા શબ્દોમાં કહીએ તો, જો થ્રેડો વચ્ચે `&T` સંદર્ભો પસાર કરતી વખતે [undefined behavior][ub] (ડેટા રેસ સહિત) ની સંભાવના નથી.
///
/// એકની અપેક્ષા મુજબ, [`u8`] અને [`f64`] જેવા આદિકાળના પ્રકારો એ બધા [`Sync`] છે, અને તેથી તેમાં એકંદર સરળ પ્રકારો છે જેમ કે ટ્યુપલ્સ, સ્ટ્રક્ટ્સ અને ઇનોમ્સ.
/// મૂળભૂત [`Sync`] પ્રકારનાં વધુ ઉદાહરણોમાં `&T` જેવા "immutable" પ્રકારો, અને સરળ વારસાગત પરિવર્તનશીલતાવાળા, જેમ કે [`Box<T>`][box], [`Vec<T>`][vec] અને મોટાભાગનાં સંગ્રહ પ્રકારો શામેલ છે.
///
/// (સામાન્ય પરિમાણો તેમના કન્ટેનર [`Sync`] થવા માટે [`Sync`] હોવું જરૂરી છે.)
///
/// વ્યાખ્યાનો કંઈક અંશે આશ્ચર્યજનક પરિણામ એ છે કે `&mut T` એ `Sync` છે (જો `T` `Sync` છે) તેમ છતાં એવું લાગે છે કે તે અનકાઉન્ટ થયેલ પરિવર્તન પ્રદાન કરે છે.
/// યુક્તિ એ છે કે વહેંચાયેલ સંદર્ભ (કે જે `& &mut T`) ની પાછળ પરિવર્તનીય સંદર્ભ ફક્ત વાંચવા માટે બને છે, જાણે કે તે `& &T` છે.
/// તેથી ડેટા રેસનું જોખમ નથી.
///
/// પ્રકારો કે જે `Sync` નથી તે એવા છે જે "interior mutability" નોન-થ્રેડ-સલામત સ્વરૂપમાં હોય છે, જેમ કે [`Cell`][cell] અને [`RefCell`][refcell].
/// આ પ્રકારો અવિર્ય, વહેંચાયેલા સંદર્ભ દ્વારા પણ તેમના સમાવિષ્ટોના પરિવર્તનને મંજૂરી આપે છે.
/// ઉદાહરણ તરીકે [`Cell<T>`][cell] પરની `set` પદ્ધતિમાં `&self` લે છે, તેથી તેને ફક્ત વહેંચાયેલ સંદર્ભ [`&Cell<T>`][cell] આવશ્યક છે.
/// પદ્ધતિ કોઈ સિંક્રોનાઇઝેશન કરતી નથી, આમ [`Cell`][cell] `Sync` હોઈ શકતું નથી.
///
/// બિન-સિંક` પ્રકારનું બીજું ઉદાહરણ સંદર્ભ-ગણતરી પોઇન્ટર [`Rc`][rc] છે.
/// કોઈપણ સંદર્ભ [`&Rc<T>`][rc] આપેલ, તમે બિન-અણુ રીતે સંદર્ભ ગણતરીઓમાં ફેરફાર કરીને, નવો [`Rc<T>`][rc] ક્લોન કરી શકો છો.
///
/// જ્યારે કોઈને થ્રેડ-સલામત આંતરિક પરિવર્તનની જરૂર હોય ત્યારે, ઝેડ રસ્ટ0 ઝેડ X01 એક્સ પ્રદાન કરે છે, સાથે સાથે એક્સ02 એક્સ અને એક્સ00 એક્સ દ્વારા સ્પષ્ટ લkingકિંગ.
/// આ પ્રકારો સુનિશ્ચિત કરે છે કે કોઈપણ પરિવર્તન ડેટાની રેસનું કારણ બની શકતું નથી, તેથી તે પ્રકારો `Sync` છે.
/// તેવી જ રીતે, [`sync::Arc`][arc], [`Rc`][rc] નું થ્રેડ-સલામત એનાલોગ પ્રદાન કરે છે.
///
/// આંતરીક પરિવર્તનવાળા કોઈપણ પ્રકારનાં value(s) ની આસપાસના [`cell::UnsafeCell`][unsafecell] રેપરનો ઉપયોગ કરવો આવશ્યક છે જેને શેર કરેલા સંદર્ભ દ્વારા પરિવર્તિત કરી શકાય છે.
/// આ કરવામાં નિષ્ફળ થવું એ [undefined behavior][ub] છે.
/// ઉદાહરણ તરીકે, [`ટ્રાંસમ્યુટ`][ટ્રાંસમિટ]-ઇંગ `&T` થી `&mut T` સુધી અમાન્ય છે.
///
/// `Sync` વિશે વધુ વિગતો માટે [the Nomicon][nomicon-send-and-sync] જુઓ.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): એકવાર બીટામાં `rustc_on_unimplemented` જમીનમાં નોંધો ઉમેરવા માટે ટેકો આપે છે, અને જરૂરિયાત સાંકળમાં બંધ ક્યાંય છે કે કેમ તે તપાસવા માટે તેને વિસ્તૃત કરવામાં આવી છે, જેમ કે (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// શૂન્ય-કદના પ્રકારોનો ઉપયોગ કરવા માટે વપરાય છે જે "act like" ધરાવે છે જેની પાસે `T` છે.
///
/// તમારા પ્રકારમાં એક `PhantomData<T>` ફીલ્ડ ઉમેરવું એ કમ્પાઇલરને કહે છે કે તમારો પ્રકાર એ પ્રકારનું `T` નું મૂલ્ય સ્ટોર કરે છે તેમ છતાં વર્તે છે, ભલે તે ખરેખર નથી.
/// આ માહિતીનો ઉપયોગ અમુક સલામતી ગુણધર્મોની ગણતરી કરતી વખતે થાય છે.
///
/// `PhantomData<T>` નો ઉપયોગ કેવી રીતે કરવો તેની વધુ ગહન સમજણ માટે, કૃપા કરીને [the Nomicon](../../nomicon/phantom-data.html) જુઓ.
///
/// # એક ભયંકર નોંધ 👻👻👻
///
/// તેમ છતાં તે બંનેના ડરામણા નામો હોવા છતાં, `PhantomData` અને 'ફેન્ટમ પ્રકારો' સંબંધિત છે, પરંતુ સમાન નથી.ફેન્ટમ પ્રકારનું પરિમાણ એ એક પ્રકારનું પરિમાણ છે જેનો ઉપયોગ ક્યારેય થતો નથી.
/// ઝેડ રસ્ટ0 ઝેડમાં, આ વારંવાર કમ્પાઇલરને ફરિયાદ કરવા માટેનું કારણ બને છે, અને સોલ્યુશન એ `PhantomData` દ્વારા "dummy" નો ઉપયોગ ઉમેરવાનો છે.
///
/// # Examples
///
/// ## ન વપરાયેલ આજીવન પરિમાણો
///
/// કદાચ `PhantomData` નો સૌથી સામાન્ય વપરાશ કેસ એ એક સ્ટ્રક્ચર છે જેનો ઉપયોગ ન કરાયેલ આજીવન પરિમાણ છે, સામાન્ય રીતે કેટલાક અસુરક્ષિત કોડના ભાગ રૂપે.
/// ઉદાહરણ તરીકે, અહીં સ્ટ્રક્ટ `Slice` છે જેમાં `*const T` પ્રકારનાં બે પોઇન્ટર છે, સંભવત somewhere ક્યાંક એરે તરફ નિર્દેશિત:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// હેતુ એ છે કે અંતર્ગત ડેટા ફક્ત આજીવન `'a` માટે માન્ય છે, તેથી `Slice` એ `'a` ને આઉટલિવ ન કરવું જોઈએ.
/// જો કે, આ ઉદ્દેશ કોડમાં દર્શાવવામાં આવ્યો નથી, કારણ કે આજીવન `'a` નો કોઈ ઉપયોગ નથી અને તેથી તે કયા ડેટા પર લાગુ પડે છે તે સ્પષ્ટ નથી.
/// અમે કમ્પાઇલરને *કામ કરવા માટે કહીને તેને સુધારી શકીએ છીએ જેમ કે*`Slice` સ્ટ્રક્ટમાં સંદર્ભ `&'a T` છે:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// આને બદલામાં પણ otનોટેશન `T: 'a` ની જરૂર પડે છે, જે સૂચવે છે કે `T` માં કોઈપણ સંદર્ભો આજીવન `'a` ઉપર માન્ય છે.
///
/// જ્યારે `Slice` પ્રારંભ કરો ત્યારે તમે `phantom` ક્ષેત્ર માટે ફક્ત `PhantomData` મૂલ્ય પ્રદાન કરો છો:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ન વપરાયેલ પ્રકારનાં પરિમાણો
///
/// તે ક્યારેક એવું બને છે કે તમારી પાસે ન વપરાયેલ પ્રકારનાં પરિમાણો છે જે દર્શાવે છે કે સ્ટ્રક્ટ કયા પ્રકારનો ડેટા "tied" છે, તેમ છતાં તે માહિતી સ્ટ્રક્ટમાં જ મળી નથી.
/// અહીં એક ઉદાહરણ છે જ્યાં આ [FFI] સાથે ઉદભવે છે.
/// વિદેશી ઇન્ટરફેસ વિવિધ પ્રકારનાં Rust મૂલ્યોનો સંદર્ભ લેવા `*mut ()` પ્રકારનાં હેન્ડલ્સનો ઉપયોગ કરે છે.
/// અમે સ્ટ્ર Xટ `ExternalResource` પર ફેન્ટમ પ્રકારનાં પરિમાણોનો ઉપયોગ કરીને Rust પ્રકારને ટ્ર trackક કરીએ છીએ જે હેન્ડલને વીંટાળે છે.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## માલિકી અને ડ્રોપ ચેક
///
/// પ્રકાર `PhantomData<T>` નું ક્ષેત્ર ઉમેરવું એ સૂચવે છે કે તમારા પ્રકારમાં `T` પ્રકારનો ડેટા છે.આના બદલામાં સૂચિત થાય છે કે જ્યારે તમારા પ્રકારને છોડી દેવામાં આવે છે, ત્યારે તે `T` પ્રકારનાં એક અથવા વધુ ઉદાહરણોને છોડી શકે છે.
/// આ ઝેડ 0 રસ્ટ0 ઝેડ કમ્પાઈલરના [drop check] વિશ્લેષણ પર અસર કરે છે.
///
/// જો તમારું સ્ટ્રક્ટ હકીકતમાં `T` પ્રકારનો ડેટા ધરાવતો નથી, તો `PhantomData<&'a T>` (ideally) અથવા `PhantomData<*const T>` (જો કોઈ આજીવન લાગુ પડતું નથી) જેવા સંદર્ભ પ્રકારનો ઉપયોગ કરવો વધુ સારું છે, જેથી માલિકી સૂચવવામાં ન આવે.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// કમ્પ્યુલર-આંતરિક trait એ enum ભેદભાવના પ્રકારને સૂચવવા માટે વપરાય છે.
///
/// આ trait એ દરેક પ્રકાર માટે આપમેળે લાગુ કરવામાં આવે છે અને [`mem::Discriminant`] માં કોઈ બાંયધરી ઉમેરતી નથી.
/// `DiscriminantKind::Discriminant` અને `mem::Discriminant` વચ્ચે ટ્રાન્સમૂટ કરવું એ **અસ્પષ્ટ વર્તન** છે.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// ભેદભાવનો પ્રકાર, જે `mem::Discriminant` દ્વારા જરૂરી trait bounds ને સંતોષવા જ જોઇએ.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// પ્રકારમાં આંતરિકમાં કોઈપણ `UnsafeCell` શામેલ છે કે કેમ તે નિર્ધારિત કરવા માટે કમ્પાઇલર-આંતરિક trait નો ઉપયોગ થાય છે, પરંતુ કોઈ દિશા નિર્દેશન દ્વારા નથી.
///
/// આ અસર કરે છે, ઉદાહરણ તરીકે, તે પ્રકારનું `static` ફક્ત વાંચવા માટે સ્થિર મેમરી અથવા લખી શકાય તેવી સ્થિર મેમરીમાં મૂકવામાં આવ્યું છે કે કેમ.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// પિન કર્યા પછી સુરક્ષિત રીતે ખસેડી શકાય તેવા પ્રકારો.
///
/// ઝેડ રસ્ટ0 ઝેડમાં પોતે સ્થાવર પ્રકારોની કોઈ કલ્પના નથી, અને હંમેશાં સુરક્ષિત રહેવા માટે ચાલ (દા.ત., સોંપણી અથવા [`mem::replace`] દ્વારા) માને છે.
///
/// પ્રકાર સિસ્ટમ દ્વારા ચાલને રોકવા માટે [`Pin`][Pin] પ્રકારનો ઉપયોગ થાય છે.[`Pin<P<T>>`][Pin] રેપરમાં વીંટાળાયેલા પોઇંટર `P<T>` ને બહાર ખસેડી શકાતા નથી.
/// પીન કરવાની વધુ માહિતી માટે [`pin` module] દસ્તાવેજીકરણ જુઓ.
///
/// `T` માટે `Unpin` trait ને અમલમાં મૂકવું એ પ્રકારને કાપવાનાં બંધનોને દૂર કરે છે, જે પછી [`mem::replace`] જેવા કાર્યો સાથે [`Pin<P<T>>`][Pin] ની બહાર `T` ખસેડવાની મંજૂરી આપે છે.
///
///
/// `Unpin` નોન-પિન કરેલા ડેટા માટે કોઈ પરિણામ નથી.
/// ખાસ કરીને, [`mem::replace`] `!Unpin` ડેટાને ખુશીથી ખસેડે છે (તે કોઈપણ `&mut T` માટે કાર્ય કરે છે, જ્યારે ફક્ત `T: Unpin` નથી).
/// જો કે, તમે [`Pin<P<T>>`][Pin] ની અંદર આવરિત ડેટા પર [`mem::replace`] નો ઉપયોગ કરી શકતા નથી કારણ કે તમે તેના માટે જરૂરી `&mut T` મેળવી શકતા નથી, અને *તે* આ સિસ્ટમ કાર્યરત બનાવે છે.
///
/// તેથી, ઉદાહરણ તરીકે, ફક્ત `Unpin` અમલીકરણનાં પ્રકારો પર જ થઈ શકે છે:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` પર ક callલ કરવા માટે આપણને પરિવર્તનશીલ સંદર્ભની જરૂર છે.
/// // અમે (implicitly) દ્વારા `Pin::deref_mut` નો ઉપયોગ કરીને આવા સંદર્ભ મેળવી શકીએ છીએ, પરંતુ તે ફક્ત એટલું જ શક્ય છે કારણ કે `String` `Unpin` ને લાગુ કરે છે.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// આ trait આપમેળે લગભગ દરેક પ્રકાર માટે લાગુ કરવામાં આવે છે.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// એક માર્કર પ્રકાર જે `Unpin` લાગુ કરતું નથી.
///
/// જો કોઈ પ્રકારમાં `PhantomPinned` શામેલ હોય, તો તે ડિફ byલ્ટ રૂપે `Unpin` લાગુ કરશે નહીં.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// આદિમ પ્રકારના માટે `Copy` ની અમલીકરણ.
///
/// ઝેડ રસ્ટ0 ઝેડમાં વર્ણવી ન શકાય તેવા અમલીકરણો, `rustc_trait_selection` માં `traits::SelectionContext::copy_clone_conditions()` માં લાગુ કરવામાં આવ્યા છે.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// શેર કરેલા સંદર્ભોની કiedપિ કરી શકાય છે, પરંતુ પરિવર્તનશીલ સંદર્ભો *કરી શકતા નથી*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}