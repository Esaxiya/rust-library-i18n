use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// એક ઝેડ 0 ફ્યુચર0 ઝેડ બનાવે છે જે તરત જ મૂલ્ય સાથે તૈયાર હોય છે.
///
/// આ `struct` [`ready()`] દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// એક ઝેડ 0 ફ્યુચર0 ઝેડ બનાવે છે જે તરત જ મૂલ્ય સાથે તૈયાર હોય છે.
///
/// આ ફંક્શન દ્વારા બનાવેલ ઝેડ 0 ફ્યુચર્સ0 ઝેડ `async {}` દ્વારા બનાવવામાં આવેલ કાર્યો સમાન છે.
/// મુખ્ય તફાવત એ છે કે આ ફંક્શન દ્વારા બનાવેલ ઝેડ 0 ફ્યુચર્સ0 ઝેડનું નામ આપવામાં આવ્યું છે અને `Unpin` ને અમલમાં મૂક્યું છે.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}