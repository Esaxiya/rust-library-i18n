#![stable(feature = "futures_api", since = "1.36.0")]

//! અસમકાલીન મૂલ્યો.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// આ પ્રકાર જરૂરી છે કારણ કે:
///
/// a) જનરેટર્સ `for<'a, 'b> Generator<&'a mut Context<'b>>` ને અમલમાં મૂકી શકતા નથી, તેથી અમારે કાચો પોઇન્ટર પસાર કરવાની જરૂર છે (જુઓ <https://github.com/rust-lang/rust/issues/68923>).
///
/// બી) કાચો પોઇંટર અને `NonNull` એ `Send` અથવા `Sync` નથી, તેથી તે દરેક ઝેડ 0 ફ્યુચર0 ઝેડ X03 એક્સને પણ બનાવશે, અને આપણે તે જોઈતા નથી.
///
/// તે `.await` ની HIR નીચલાઇને પણ સરળ બનાવે છે.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ઝેડ 0 ફ્યુચર0 ઝેડમાં જનરેટર લપેટી.
///
/// આ ફંક્શન નીચે એક `GenFuture` આપે છે, પરંતુ વધુ સારી ભૂલ સંદેશાઓ આપવા માટે તેને `impl Trait` માં છુપાવે છે (`GenFuture<[closure.....]>` ને બદલે `impl Future`).
///
// અમે `const async fn` થી પુન recoverપ્રાપ્ત થયા પછી વધારાની ભૂલોને ટાળવા માટે આ `const` છે
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // અમે આ હકીકત પર આધાર રાખીએ છીએ કે અંતર્ગત જનરેટરમાં સ્વ-સંદર્ભિત ઉધાર બનાવવા માટે async/await futures સ્થાવર છે.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // સલામત: સલામત છે કારણ કે આપણે !Unpin + !Drop છીએ અને આ ફક્ત એક ક્ષેત્ર પ્રક્ષેપણ છે.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // જનરેટર ફરી શરૂ કરો, `&mut Context` ને `NonNull` કાચા પોઇન્ટરમાં ફેરવો.
            // `.await` ઘટાડીને `&mut Context` પર સલામત રીતે કાસ્ટ કરવામાં આવશે.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // સલામતી: ક calલરને ગેરેંટી આપવી આવશ્યક છે કે `cx.0` માન્ય પોઇન્ટર છે
    // જે પરિવર્તનશીલ સંદર્ભ માટેની બધી આવશ્યકતાઓને પૂર્ણ કરે છે.
    unsafe { &mut *cx.0.as_ptr().cast() }
}