use crate::future::Future;

/// એક `Future` માં રૂપાંતર.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// આઉટપુટ કે જે ઝેડ ફ્યુચર0 ઝેડ પૂર્ણ થવા પર પેદા કરશે.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// કયા પ્રકારનું ઝેડ 0 ફ્યુચર0 ઝેડ આપણે આમાં ફેરવીએ છીએ?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// મૂલ્યથી ઝેડ 0 ફ્યુચર0 ઝેડ બનાવે છે.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}