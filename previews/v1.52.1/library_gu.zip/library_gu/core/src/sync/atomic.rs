//! અણુ પ્રકારો
//!
//! અણુ પ્રકારો થ્રેડો વચ્ચે પ્રાચીન વહેંચાયેલ મેમરી સંદેશાવ્યવહાર પ્રદાન કરે છે, અને તે અન્ય સહવર્તી પ્રકારનાં બિલ્ડિંગ બ્લોક્સ છે.
//!
//! આ મોડ્યુલ, [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], વગેરે સહિતના પ્રાચીન પ્રકારોની પસંદ કરેલી સંખ્યાના અણુ સંસ્કરણોને વ્યાખ્યાયિત કરે છે.
//! અણુ પ્રકારો operationsપરેશન રજૂ કરે છે જે, જ્યારે યોગ્ય રીતે વપરાય છે, ત્યારે થ્રેડો વચ્ચે અપડેટ્સને સિંક્રનાઇઝ કરે છે.
//!
//! દરેક પદ્ધતિમાં એક [`Ordering`] લે છે જે તે કામગીરી માટે મેમરી અવરોધની શક્તિને રજૂ કરે છે.આ orderર્ડર્સ [C++20 atomic orderings][1] જેવા જ છે.વધુ માહિતી માટે [nomicon][2] જુઓ.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! અણુ ચલો થ્રેડો વચ્ચે વહેંચવા માટે સલામત છે (તેઓ [`Sync`] લાગુ કરે છે) પરંતુ તેઓ જાતે Rust ના [threading model](../../../std/thread/index.html#the-threading-model) ને શેર કરવા અને તેનું પાલન કરવાની પદ્ધતિ પ્રદાન કરતા નથી.
//!
//! અણુ ચલને શેર કરવાની સૌથી સામાન્ય રીત એ છે કે તેને [`Arc`][arc] (એક અણુ-સંદર્ભ-ગણતરીમાં વહેંચાયેલ પોઇન્ટર) મૂકવો.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! અણુ પ્રકારો સ્થિર ચલોમાં સ્ટોર કરી શકાય છે, એક્સ00 એક્સ જેવા સતત પ્રારંભિકનો ઉપયોગ કરીને પ્રારંભિક.અણુ સ્ટેટિક્સનો ઉપયોગ હંમેશા આળસુ વૈશ્વિક પ્રારંભ માટે થાય છે.
//!
//! # Portability
//!
//! આ મોડ્યુલમાં તમામ અણુ પ્રકારો ઉપલબ્ધ હોય તો [lock-free] હોવાની બાંયધરી આપવામાં આવી છે.આનો અર્થ એ કે તેઓ આંતરિક રીતે વૈશ્વિક મ્યુટેક્સ પ્રાપ્ત કરતા નથી.અણુ પ્રકારો અને waitપરેશન રાહ જોતા મુક્ત હોવાની બાંયધરી આપતા નથી.
//! આનો અર્થ એ કે `fetch_or` જેવા ઓપરેશન્સને ક compareપેરેશન-અને-સ્વેપ લૂપ સાથે લાગુ કરવામાં આવી શકે છે.
//!
//! મોટા કદના પરમાણુઓ સાથે સૂચના સ્તર પર અણુ ક્રિયાઓ લાગુ કરી શકાય છે.ઉદાહરણ તરીકે કેટલાક પ્લેટફોર્મ્સ `AtomicI8` અમલમાં મૂકવા માટે 4-બાઇટ અણુ સૂચનોનો ઉપયોગ કરે છે.
//! નોંધ કરો કે આ અનુકરણની કોડની શુદ્ધતા પર કોઈ અસર હોવી જોઈએ નહીં, તે કંઈક ધ્યાન રાખવાની છે.
//!
//! આ મોડ્યુલમાં અણુ પ્રકારો બધા પ્લેટફોર્મ્સ પર ઉપલબ્ધ ન હોઈ શકે.અહીં અણુ પ્રકારો બધા વ્યાપકપણે ઉપલબ્ધ છે, તેમ છતાં, અને સામાન્ય રીતે હાલના પર આધાર રાખી શકાય છે.કેટલાક નોંધપાત્ર અપવાદો આ છે:
//!
//! * PowerPC અને 32-બીટ પોઇંટર્સવાળા MIPS પ્લેટફોર્મ્સમાં `AtomicU64` અથવા `AtomicI64` પ્રકારો નથી.
//! * ARM `armv5te` જેવા પ્લેટફોર્મ્સ કે જે Linux માટે નથી, તે ફક્ત `load` અને `store` provideપરેશન પ્રદાન કરે છે, અને `swap`, `fetch_add`, વગેરે જેવા તુલના અને સ્વેપ (CAS) કામગીરીને સમર્થન આપતા નથી.
//! વધારાના Linux પર, આ સીએએસ કામગીરી [operating system support] દ્વારા લાગુ કરવામાં આવે છે, જે પ્રભાવ દંડ સાથે આવી શકે છે.
//! * ARM `thumbv6m` સાથેના લક્ષ્યો ફક્ત `load` અને `store` provideપરેશન પ્રદાન કરે છે, અને `swap`, `fetch_add`, વગેરે જેવા (CAS) કામગીરીની તુલના અને ટેકો આપતા નથી.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! નોંધ લો કે ઝેડ 0 ફ્યુચર 0 ઝેડ પ્લેટફોર્મ્સ ઉમેરી શકાય છે જેમાં કેટલાક અણુ operationsપરેશન માટે સપોર્ટ પણ નથી.મહત્તમ પોર્ટેબલ કોડ કયા પરમાણુ પ્રકારનો ઉપયોગ કરવામાં આવે છે તેના વિશે ખૂબ કાળજી લેવાનું ઇચ્છશે.
//! `AtomicUsize` અને `AtomicIsize` સામાન્ય રીતે સૌથી વધુ પોર્ટેબલ હોય છે, પરંતુ તે પછી પણ તે દરેક જગ્યાએ ઉપલબ્ધ નથી.
//! સંદર્ભ માટે, `std` લાઇબ્રેરીને પોઇન્ટર-કદના પરમાણુઓની આવશ્યકતા છે, જોકે `core` નથી.
//!
//! હાલમાં તમારે પરમાણુવાળા કોડમાં શરતી રીતે કમ્પાઇલ કરવા માટે, મુખ્યત્વે `#[cfg(target_arch)]` નો ઉપયોગ કરવાની જરૂર પડશે.ત્યાં અસ્થિર `#[cfg(target_has_atomic)]` પણ છે જે ઝેડ ફ્યુચર0 ઝેડમાં સ્થિર થઈ શકે છે.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! એક સરળ સ્પિનલોક:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // લ threadક છૂટા થવા માટે બીજા થ્રેડની રાહ જુઓ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! જીવંત થ્રેડોની વૈશ્વિક ગણતરી રાખો:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// બુલિયન પ્રકાર જે થ્રેડો વચ્ચે સુરક્ષિત રીતે શેર કરી શકાય છે.
///
/// આ પ્રકારનું X-X X જેવી જ મેમરીમાં રજૂઆત છે.
///
/// **નોંધ**: આ પ્રકાર ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે કે જે `u8` ના અણુ લોડ અને સ્ટોર્સને સપોર્ટ કરે છે.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` થી પ્રારંભિક `AtomicBool` બનાવે છે.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// મોકલો એટોમિકબૂલ માટે ગર્ભિતપણે લાગુ કરવામાં આવ્યો છે.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// કાચો પોઇન્ટર પ્રકાર જે થ્રેડો વચ્ચે સુરક્ષિત રીતે શેર કરી શકાય છે.
///
/// આ પ્રકારનું X-X X જેવી જ મેમરીમાં રજૂઆત છે.
///
/// **નોંધ**: આ પ્રકાર ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે કે જે અણુ લોડ અને પોઇન્ટરના સ્ટોર્સને સપોર્ટ કરે છે.
/// તેનું કદ લક્ષ્ય નિર્દેશકના કદ પર આધારિત છે.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// નલ `AtomicPtr<T>` બનાવે છે.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// અણુ મેમરી ઓર્ડર
///
/// મેમરી ઓર્ડરિંગ્સ અણુ ક્રિયાઓ મેમરીને સિંક્રનાઇઝ કરવાની રીતનો ઉલ્લેખ કરે છે.
/// તેના સૌથી નબળા [`Ordering::Relaxed`] માં, byપરેશન દ્વારા સીધી સ્પર્શેલી મેમરી જ સિંક્રનાઇઝ થાય છે.
/// બીજી બાજુ, [`Ordering::SeqCst`] ofપરેશંસની સ્ટોર-લોડ જોડી અન્ય મેમરીને સિંક્રનાઇઝ કરે છે જ્યારે વધુમાં બધા થ્રેડોમાં આવા ofપરેશન્સના કુલ ઓર્ડરને સાચવે છે.
///
///
/// ઝેડ રસ્ટ0 ઝેડની મેમરી ઓર્ડરિંગ્સ [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) છે.
///
/// વધુ માહિતી માટે [nomicon] જુઓ.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// કોઈ ઓર્ડરિંગ અવરોધ નથી, ફક્ત અણુ ક્રિયાઓ છે.
    ///
    /// C ++ 20 માં [`memory_order_relaxed`] ને અનુરૂપ છે.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// જ્યારે સ્ટોર સાથે જોડવામાં આવે છે, ત્યારે [`Acquire`] (અથવા વધુ મજબૂત) ઓર્ડર સાથે આ મૂલ્યના કોઈપણ ભાર પહેલાં, અગાઉના તમામ કામગીરી ઓર્ડર થઈ જાય છે.
    ///
    /// ખાસ કરીને, અગાઉના બધા લેખકો તે બધા થ્રેડો માટે દૃશ્યમાન બને છે જે આ મૂલ્યનો [`Acquire`] (અથવા મજબૂત) લોડ કરે છે.
    ///
    /// નોંધ લો કે લોડ અને સ્ટોર્સને જોડતી કામગીરી માટે આ !ર્ડરનો ઉપયોગ કરવાથી [`Relaxed`] લોડ ઓપરેશન થાય છે!
    ///
    /// આ ઓર્ડર ફક્ત તે કામગીરી માટે લાગુ છે કે જે સ્ટોર કરી શકે.
    ///
    /// C ++ 20 માં [`memory_order_release`] ને અનુરૂપ છે.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// જ્યારે લોડ સાથે જોડવામાં આવે છે, જો લોડ થયેલ મૂલ્ય સ્ટોર ઓપરેશન દ્વારા [`Release`] (અથવા વધુ મજબૂત) ઓર્ડર સાથે લખવામાં આવ્યું હતું, તો પછીની તમામ કામગીરી તે સ્ટોર પછી ઓર્ડર થઈ જાય છે.
    /// ખાસ કરીને, પછીનાં બધા લોડ્સ સ્ટોર પહેલાં લખેલા ડેટા જોશે.
    ///
    /// નોંધ લો કે લોડ અને સ્ટોર્સને જોડતી કામગીરી માટે આ orderર્ડરનો ઉપયોગ કરવાથી [`Relaxed`] સ્ટોર ઓપરેશન થાય છે!
    ///
    /// આ ઓર્ડર ફક્ત તે કામગીરી માટે લાગુ છે કે જે લોડ કરી શકે.
    ///
    /// C ++ 20 માં [`memory_order_acquire`] ને અનુરૂપ છે.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// એક સાથે બંને [`Acquire`] અને [`Release`] ની અસરો ધરાવે છે:
    /// લોડ્સ માટે તે [`Acquire`] ઓર્ડરિંગનો ઉપયોગ કરે છે.સ્ટોર્સ માટે તે [`Release`] ઓર્ડરનો ઉપયોગ કરે છે.
    ///
    /// નોંધ લો કે `compare_and_swap` ના કિસ્સામાં, શક્ય છે કે કોઈ પણ સ્ટોર ન ચલાવતાં ઓપરેશન સમાપ્ત થાય અને તેથી તે ફક્ત [`Acquire`] ઓર્ડર કરે છે.
    ///
    /// જો કે, `AcqRel` ક્યારેય [`Relaxed`] performક્સેસ કરશે નહીં.
    ///
    /// આ ingર્ડરિંગ ફક્ત તે કામગીરી માટે લાગુ છે કે જે બંને લોડ અને સ્ટોર્સને જોડે છે.
    ///
    /// C ++ 20 માં [`memory_order_acq_rel`] ને અનુરૂપ છે.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`એક્વાયર`]/[`રીલીઝ`]/[`એક્ક્રેલ](અનુક્રમે લોડ, સ્ટોર અને લોડ-સાથે-સ્ટોર કામગીરી માટે) વધારાની બાંયધરી સાથે કે બધા થ્રેડો સમાન ક્રમમાં તમામ ક્રમિક સુસંગત કામગીરી જુએ છે. .
    ///
    ///
    /// C ++ 20 માં [`memory_order_seq_cst`] ને અનુરૂપ છે.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// એક [`AtomicBool`] એ `false` થી પ્રારંભ કર્યુ.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// એક નવું `AtomicBool` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// અંતર્ગત [`bool`] નો પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// આ સલામત છે કારણ કે પરિવર્તનીય સંદર્ભ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને .ક્સેસ કરી રહ્યા નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // સલામતી: પરિવર્તનીય સંદર્ભ અનન્ય માલિકીની બાંયધરી આપે છે.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` પર અણુ પ્રવેશ મેળવો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // સલામતી: પરિવર્તનીય સંદર્ભ અનન્ય માલિકીની બાંયધરી આપે છે, અને
        // `bool` અને `Self` બંનેનું સંરેખણ 1 છે.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// અણુ લે છે અને સમાયેલ મૂલ્ય આપે છે.
    ///
    /// આ સલામત છે કારણ કે મૂલ્ય દ્વારા `self` પસાર થવું એ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને accessક્સેસ કરી રહ્યા નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool માંથી મૂલ્ય લોડ કરે છે.
    ///
    /// `load` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// સંભવિત મૂલ્યો [`SeqCst`], [`Acquire`] અને [`Relaxed`] છે.
    ///
    /// # Panics
    ///
    /// જો Panics જો `order` [`Release`] અથવા [`AcqRel`] છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // સલામતી: કોઈપણ ડેટા રેસને અણુ અંતર અને કાચા દ્વારા અટકાવવામાં આવે છે
        // પાસ કરેલ પોઇન્ટર માન્ય છે કારણ કે અમને તે સંદર્ભમાંથી મળ્યું છે.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool માં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// `store` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// સંભવિત મૂલ્યો [`SeqCst`], [`Release`] અને [`Relaxed`] છે.
    ///
    /// # Panics
    ///
    /// જો Panics જો `order` [`Acquire`] અથવા [`AcqRel`] છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // સલામતી: કોઈપણ ડેટા રેસને અણુ અંતર અને કાચા દ્વારા અટકાવવામાં આવે છે
        // પાસ કરેલ પોઇન્ટર માન્ય છે કારણ કે અમને તે સંદર્ભમાંથી મળ્યું છે.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// પાછલું મૂલ્ય પાછું આપતા, bool માં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// `swap` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે, તો તે [`bool`] માં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// વળતર મૂલ્ય હંમેશાં પહેલાનું મૂલ્ય હોય છે.જો તે `current` ની બરાબર છે, તો મૂલ્ય અપડેટ કરવામાં આવ્યું હતું.
    ///
    /// `compare_and_swap` એક [`Ordering`] દલીલ પણ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// નોંધ લો કે [`AcqRel`] નો ઉપયોગ કરતી વખતે પણ, કામગીરી નિષ્ફળ થઈ શકે છે અને તેથી તે ફક્ત `Acquire` લોડ કરે છે, પરંતુ `Release` અર્થશાસ્ત્ર નથી.
    /// [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે જો તે થાય, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # `compare_exchange` અને `compare_exchange_weak` પર સ્થળાંતર કરી રહ્યું છે
    ///
    /// `compare_and_swap` મેમરી ઓર્ડરિંગ્સ માટે નીચેના મેપિંગ સાથે `compare_exchange` ની બરાબર છે:
    ///
    /// અસલ |સફળતા |નિષ્ફળતા
    /// -------- | ------- | -------
    /// આરામ |આરામ |રિલેક્સ્ડ એક્ક્વાયર |હસ્તગત |રીલીઝ મેળવો |પ્રકાશન |રિલેક્સ્ડ એક્ક્રેલ |એક્ક્રેલ |સેક્સીસ્ટ મેળવો |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` જ્યારે સરખામણી સફળ થાય ત્યારે પણ ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જે જ્યારે લૂપમાં જ્યારે તુલના અને સ્વેપનો ઉપયોગ થાય છે ત્યારે કમ્પાઇલરને વધુ સારું એસેમ્બલી કોડ જનરેટ કરવાની મંજૂરી આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે, તો તે [`bool`] માં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
    /// સફળતા પર આ મૂલ્ય `current` ની બરાબરની ખાતરી આપવામાં આવે છે.
    ///
    /// `compare_exchange` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
    /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
    ///
    /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે, તો તે [`bool`] માં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// [`AtomicBool::compare_exchange`] થી વિપરીત, જ્યારે આ તુલના સફળ થાય ત્યારે પણ આ કાર્યને ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જેના પરિણામે કેટલાક પ્લેટફોર્મ પર વધુ કાર્યક્ષમ કોડ આવી શકે છે.
    ///
    /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
    ///
    /// `compare_exchange_weak` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
    /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
    /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// બુલીયન મૂલ્ય સાથે લોજિકલ "and".
    ///
    /// વર્તમાન મૂલ્ય અને દલીલ `val` પર લોજિકલ "and" Perપરેશન કરે છે, અને પરિણામ માટે નવું મૂલ્ય સેટ કરે છે.
    ///
    /// પાછલું મૂલ્ય આપે છે.
    ///
    /// `fetch_and` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// બુલીયન મૂલ્ય સાથે લોજિકલ "nand".
    ///
    /// વર્તમાન મૂલ્ય અને દલીલ `val` પર લોજિકલ "nand" Perપરેશન કરે છે, અને પરિણામ માટે નવું મૂલ્ય સેટ કરે છે.
    ///
    /// પાછલું મૂલ્ય આપે છે.
    ///
    /// `fetch_nand` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // અમે અહીં અણુ_નાંડનો ઉપયોગ કરી શકતા નથી કારણ કે તે અમાન્ય મૂલ્યવાળા ઝેડબૂલ 0 ઝેડમાં પરિણમી શકે છે.
        // આવું થાય છે કારણ કે અણુ operationપરેશન આંતરિકમાં 8-બીટ પૂર્ણાંક સાથે કરવામાં આવે છે, જે ઉપલા 7 બિટ્સ સેટ કરશે.
        //
        // તેથી આપણે તેના બદલે ફક્ત fetch_xor અથવા સ્વેપનો ઉપયોગ કરીએ છીએ.
        if val {
            // ! (x અને ટ્રુ)== !x આપણે bool ને vertંધું કરવું જ જોઇએ.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&ખોટા)==સાચું આપણે bool ને true પર સેટ કરવું જોઈએ.
            //
            self.swap(true, order)
        }
    }

    /// બુલીયન મૂલ્ય સાથે લોજિકલ "or".
    ///
    /// વર્તમાન મૂલ્ય અને દલીલ `val` પર લોજિકલ "or" Perપરેશન કરે છે, અને પરિણામ માટે નવું મૂલ્ય સેટ કરે છે.
    ///
    /// પાછલું મૂલ્ય આપે છે.
    ///
    /// `fetch_or` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// બુલીયન મૂલ્ય સાથે લોજિકલ "xor".
    ///
    /// વર્તમાન મૂલ્ય અને દલીલ `val` પર લોજિકલ "xor" Perપરેશન કરે છે, અને પરિણામ માટે નવું મૂલ્ય સેટ કરે છે.
    ///
    /// પાછલું મૂલ્ય આપે છે.
    ///
    /// `fetch_xor` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// અંતર્ગત [`bool`] પર પરિવર્તનશીલ નિર્દેશક પરત કરે છે.
    ///
    /// પરિણામી પૂર્ણાંકો પર બિન-અણુ વાંચવા અને લખવાનું કરવું એ કોઈ ડેટા રેસ હોઈ શકે છે.
    /// આ પદ્ધતિ મોટે ભાગે એફએફઆઈ માટે ઉપયોગી છે, જ્યાં ફંક્શન સહી `&AtomicBool` ને બદલે `*mut bool` નો ઉપયોગ કરી શકે છે.
    ///
    /// આ અણુના વહેંચાયેલા સંદર્ભમાંથી `*mut` પોઇન્ટર પાછું ફરવું સલામત છે કારણ કે પરમાણુ પ્રકારો આંતરિક પરિવર્તન સાથે કાર્ય કરે છે.
    /// અણુના તમામ ફેરફારો, શેર કરેલા સંદર્ભ દ્વારા મૂલ્યમાં ફેરફાર કરે છે અને તે પરમાણુ કામગીરીનો ઉપયોગ કરે ત્યાં સુધી સલામત રીતે કરી શકે છે.
    /// પાછા ફરેલા કાચા પોઇન્ટરના કોઈપણ ઉપયોગ માટે `unsafe` બ્લોકની જરૂર હોય છે અને હજી પણ તે જ પ્રતિબંધને જાળવવો પડે છે: તેના પરના ઓપરેશન્સ અણુ હોવા આવશ્યક છે.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// મૂલ્ય મેળવે છે, અને તેમાં કોઈ કાર્ય લાગુ કરે છે જે વૈકલ્પિક નવું મૂલ્ય આપે છે.જો કાર્ય `Some(_)` પરત કરે છે, નહીં તો `Err(previous_value)`, `Ok(previous_value)` નો `Result` આપે છે.
    ///
    /// Note: આ ફંક્શનને ઘણી વખત ક callલ કરી શકે છે જો આ દરમ્યાન મૂલ્ય અન્ય થ્રેડોથી બદલાઈ ગયું હોય, જ્યાં સુધી ફંક્શન `Some(_)` આપે છે, પરંતુ ફંક્શન ફક્ત એક જ વાર સ્ટોર કરેલી વેલ્યુ પર લાગુ કરવામાં આવશે.
    ///
    ///
    /// `fetch_update` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// પ્રથમ જ્યારે ઓપરેશન આખરે સફળ થાય છે ત્યારે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે જ્યારે બીજું લોડ્સ માટે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે.
    /// આ અનુક્રમે [`AtomicBool::compare_exchange`] ની સફળતા અને નિષ્ફળતાના ક્રમમાં અનુરૂપ છે.
    ///
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ અંતિમ સફળ લોડ [`Relaxed`] બનાવે છે.
    /// (failed) લોડ ઓર્ડરિંગ ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા સમાન અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે `u8` પર અણુ ક્રિયાઓને ટેકો આપે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// એક નવું `AtomicPtr` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// અંતર્ગત નિર્દેશકનો પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// આ સલામત છે કારણ કે પરિવર્તનીય સંદર્ભ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને .ક્સેસ કરી રહ્યા નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// નિર્દેશકની પરમાણુ accessક્સેસ મેળવો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - પરિવર્તનીય સંદર્ભ અનન્ય માલિકીની બાંયધરી આપે છે.
        //  - `*mut T` અને `Self` નું સંરેખણ rust દ્વારા સપોર્ટેડ બધા પ્લેટફોર્મ્સ પર સમાન છે, ઉપરની ચકાસણી પ્રમાણે.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// અણુ લે છે અને સમાયેલ મૂલ્ય આપે છે.
    ///
    /// આ સલામત છે કારણ કે મૂલ્ય દ્વારા `self` પસાર થવું એ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને accessક્સેસ કરી રહ્યા નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// પોઇન્ટરથી મૂલ્ય લોડ કરે છે.
    ///
    /// `load` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// સંભવિત મૂલ્યો [`SeqCst`], [`Acquire`] અને [`Relaxed`] છે.
    ///
    /// # Panics
    ///
    /// જો Panics જો `order` [`Release`] અથવા [`AcqRel`] છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// પોઇન્ટરમાં વેલ્યુ સ્ટોર કરે છે.
    ///
    /// `store` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// સંભવિત મૂલ્યો [`SeqCst`], [`Release`] અને [`Relaxed`] છે.
    ///
    /// # Panics
    ///
    /// જો Panics જો `order` [`Acquire`] અથવા [`AcqRel`] છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// પોઇન્ટરમાં મૂલ્ય સ્ટોર કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
    ///
    /// `swap` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
    /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે પોઇંટરો પર અણુ ક્રિયાઓને સપોર્ટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે તો નિર્દેશકમાં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// વળતર મૂલ્ય હંમેશાં પહેલાનું મૂલ્ય હોય છે.જો તે `current` ની બરાબર છે, તો મૂલ્ય અપડેટ કરવામાં આવ્યું હતું.
    ///
    /// `compare_and_swap` એક [`Ordering`] દલીલ પણ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
    /// નોંધ લો કે [`AcqRel`] નો ઉપયોગ કરતી વખતે પણ, કામગીરી નિષ્ફળ થઈ શકે છે અને તેથી તે ફક્ત `Acquire` લોડ કરે છે, પરંતુ `Release` અર્થશાસ્ત્ર નથી.
    /// [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે જો તે થાય, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે પોઇંટરો પર અણુ ક્રિયાઓને સપોર્ટ કરે છે.
    ///
    /// # `compare_exchange` અને `compare_exchange_weak` પર સ્થળાંતર કરી રહ્યું છે
    ///
    /// `compare_and_swap` મેમરી ઓર્ડરિંગ્સ માટે નીચેના મેપિંગ સાથે `compare_exchange` ની બરાબર છે:
    ///
    /// અસલ |સફળતા |નિષ્ફળતા
    /// -------- | ------- | -------
    /// આરામ |આરામ |રિલેક્સ્ડ એક્ક્વાયર |હસ્તગત |રીલીઝ મેળવો |પ્રકાશન |રિલેક્સ્ડ એક્ક્રેલ |એક્ક્રેલ |સેક્સીસ્ટ મેળવો |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` જ્યારે સરખામણી સફળ થાય ત્યારે પણ ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જે જ્યારે લૂપમાં જ્યારે તુલના અને સ્વેપનો ઉપયોગ થાય છે ત્યારે કમ્પાઇલરને વધુ સારું એસેમ્બલી કોડ જનરેટ કરવાની મંજૂરી આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે તો નિર્દેશકમાં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
    /// સફળતા પર આ મૂલ્ય `current` ની બરાબરની ખાતરી આપવામાં આવે છે.
    ///
    /// `compare_exchange` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
    /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
    ///
    /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે પોઇંટરો પર અણુ ક્રિયાઓને સપોર્ટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ છે તો નિર્દેશકમાં મૂલ્ય સ્ટોર કરે છે.
    ///
    /// [`AtomicPtr::compare_exchange`] થી વિપરીત, જ્યારે આ તુલના સફળ થાય ત્યારે પણ આ કાર્યને ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જેના પરિણામે કેટલાક પ્લેટફોર્મ્સ પર વધુ કાર્યક્ષમ કોડ આવી શકે છે.
    ///
    /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
    ///
    /// `compare_exchange_weak` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
    /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
    /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે પોઇંટરો પર અણુ ક્રિયાઓને સપોર્ટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // સલામતી: આ આંતરિક અસુરક્ષિત છે કારણ કે તે કાચા નિર્દેશક પર કાર્ય કરે છે
        // પરંતુ અમે ખાતરીપૂર્વક જાણીએ છીએ કે નિર્દેશક માન્ય છે (આપણે હમણાં જ તે સંદર્ભમાં આપેલ `UnsafeCell` પાસેથી મેળવ્યું છે) અને અણુ operationપરેશન આપણને `UnsafeCell` સમાવિષ્ટોને સુરક્ષિત રૂપે પરિવર્તન કરવાની મંજૂરી આપે છે.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// મૂલ્ય મેળવે છે, અને તેમાં કોઈ કાર્ય લાગુ કરે છે જે વૈકલ્પિક નવું મૂલ્ય આપે છે.જો કાર્ય `Some(_)` પરત કરે છે, નહીં તો `Err(previous_value)`, `Ok(previous_value)` નો `Result` આપે છે.
    ///
    /// Note: આ ફંક્શનને ઘણી વખત ક callલ કરી શકે છે જો આ દરમ્યાન મૂલ્ય અન્ય થ્રેડોથી બદલાઈ ગયું હોય, જ્યાં સુધી ફંક્શન `Some(_)` આપે છે, પરંતુ ફંક્શન ફક્ત એક જ વાર સ્ટોર કરેલી વેલ્યુ પર લાગુ કરવામાં આવશે.
    ///
    ///
    /// `fetch_update` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
    /// પ્રથમ જ્યારે ઓપરેશન આખરે સફળ થાય છે ત્યારે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે જ્યારે બીજું લોડ્સ માટે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે.
    /// આ અનુક્રમે [`AtomicPtr::compare_exchange`] ની સફળતા અને નિષ્ફળતાના ક્રમમાં અનુરૂપ છે.
    ///
    /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ અંતિમ સફળ લોડ [`Relaxed`] બનાવે છે.
    /// (failed) લોડ ઓર્ડરિંગ ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા સમાન અથવા નબળા હોવા જોઈએ.
    ///
    /// **Note:** આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે જે પોઇંટરો પર અણુ ક્રિયાઓને સપોર્ટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` ને `AtomicBool` માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // આ મેક્રો સમાપ્ત થાય છે કેટલાક આર્કિટેક્ચરો પર ન વપરાયેલ.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// પૂર્ણાંકોનો પ્રકાર જે થ્રેડો વચ્ચે સુરક્ષિત રીતે શેર કરી શકાય છે.
        ///
        /// આ પ્રકારનું અંતર્ગત પૂર્ણાંક પ્રકાર, [`] જેવી જ મેમરીની રજૂઆત છે
        ///
        #[doc = $s_int_type]
        /// `].
        /// અણુ પ્રકારો અને બિન-અણુ પ્રકારો વચ્ચેના તફાવત તેમજ આ પ્રકારની સુવાહ્ય વિશેની માહિતી માટે, કૃપા કરીને [module-level documentation] જુઓ.
        ///
        ///
        /// **Note:** આ પ્રકાર ફક્ત પ્લેટફોર્મ પર ઉપલબ્ધ છે કે જે અણુ લોડ અને [of ના સ્ટોર્સને સપોર્ટ કરે છે
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// અણુ પૂર્ણાંક `0` માં પ્રારંભ થયો.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // મોકલો સ્પષ્ટ રીતે અમલમાં મૂક્યો છે.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// નવો અણુ પૂર્ણાંક બનાવે છે.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// અંતર્ગત પૂર્ણાંક માટે પરિવર્તનીય સંદર્ભ આપે છે.
            ///
            /// આ સલામત છે કારણ કે પરિવર્તનીય સંદર્ભ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને .ક્સેસ કરી રહ્યા નથી.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// ચાલો મ્યુટ some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - પરિવર્તનીય સંદર્ભ અનન્ય માલિકીની બાંયધરી આપે છે.
                //  - `$int_type` અને `Self` નું સંરેખણ એ જ છે, જેમ કે $cfg_align દ્વારા વચન આપવામાં આવ્યું છે અને ઉપર ચકાસાયેલ છે.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// અણુ લે છે અને સમાયેલ મૂલ્ય આપે છે.
            ///
            /// આ સલામત છે કારણ કે મૂલ્ય દ્વારા `self` પસાર થવું એ બાંયધરી આપે છે કે અન્ય કોઈ થ્રેડો એક સાથે અણુ ડેટાને accessક્સેસ કરી રહ્યા નથી.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// અણુ પૂર્ણાંકથી મૂલ્ય લોડ કરે છે.
            ///
            /// `load` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
            /// સંભવિત મૂલ્યો [`SeqCst`], [`Acquire`] અને [`Relaxed`] છે.
            ///
            /// # Panics
            ///
            /// જો Panics જો `order` [`Release`] અથવા [`AcqRel`] છે.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// અણુ પૂર્ણાંકમાં મૂલ્ય સ્ટોર કરે છે.
            ///
            /// `store` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
            ///  સંભવિત મૂલ્યો [`SeqCst`], [`Release`] અને [`Relaxed`] છે.
            ///
            /// # Panics
            ///
            /// જો Panics જો `order` [`Acquire`] અથવા [`AcqRel`] છે.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// પાછલા મૂલ્યને પરત કરીને, અણુ પૂર્ણાંકમાં મૂલ્ય સ્ટોર કરે છે.
            ///
            /// `swap` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ હોય તો અણુ પૂર્ણાંકમાં મૂલ્ય સ્ટોર કરે છે.
            ///
            /// વળતર મૂલ્ય હંમેશાં પહેલાનું મૂલ્ય હોય છે.જો તે `current` ની બરાબર છે, તો મૂલ્ય અપડેટ કરવામાં આવ્યું હતું.
            ///
            /// `compare_and_swap` એક [`Ordering`] દલીલ પણ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.
            /// નોંધ લો કે [`AcqRel`] નો ઉપયોગ કરતી વખતે પણ, કામગીરી નિષ્ફળ થઈ શકે છે અને તેથી તે ફક્ત `Acquire` લોડ કરે છે, પરંતુ `Release` અર્થશાસ્ત્ર નથી.
            ///
            /// [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે જો તે થાય, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` અને `compare_exchange_weak` પર સ્થળાંતર કરી રહ્યું છે
            ///
            /// `compare_and_swap` મેમરી ઓર્ડરિંગ્સ માટે નીચેના મેપિંગ સાથે `compare_exchange` ની બરાબર છે:
            ///
            /// અસલ |સફળતા |નિષ્ફળતા
            /// -------- | ------- | -------
            /// આરામ |આરામ |રિલેક્સ્ડ એક્ક્વાયર |હસ્તગત |રીલીઝ મેળવો |પ્રકાશન |રિલેક્સ્ડ એક્ક્રેલ |એક્ક્રેલ |સેક્સીસ્ટ મેળવો |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` જ્યારે સરખામણી સફળ થાય ત્યારે પણ ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જે જ્યારે લૂપમાં જ્યારે તુલના અને સ્વેપનો ઉપયોગ થાય છે ત્યારે કમ્પાઇલરને વધુ સારું એસેમ્બલી કોડ જનરેટ કરવાની મંજૂરી આપે છે.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ હોય તો અણુ પૂર્ણાંકમાં મૂલ્ય સ્ટોર કરે છે.
            ///
            /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
            /// સફળતા પર આ મૂલ્ય `current` ની બરાબરની ખાતરી આપવામાં આવે છે.
            ///
            /// `compare_exchange` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
            /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
            /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
            /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
            ///
            /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// જો વર્તમાન મૂલ્ય `current` મૂલ્ય જેટલું જ હોય તો અણુ પૂર્ણાંકમાં મૂલ્ય સ્ટોર કરે છે.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// જ્યારે સરખામણી સફળ થાય છે ત્યારે પણ આ કાર્યને ઉત્સાહપૂર્ણ રીતે નિષ્ફળ થવાની મંજૂરી છે, જેના પરિણામે કેટલાક પ્લેટફોર્મ્સ પર વધુ કાર્યક્ષમ કોડ આવી શકે છે.
            /// વળતર મૂલ્ય એ એક પરિણામ છે જે સૂચવે છે કે શું નવું મૂલ્ય લખાયેલું હતું અને તેમાં પાછલું મૂલ્ય હતું.
            ///
            /// `compare_exchange_weak` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
            /// `success` જો `current` સાથેની સરખામણી સફળ થાય તો થાય છે તે વાંચવા-સંશોધિત-લેખન કામગીરી માટે જરૂરી ક્રમમાં વર્ણવે છે.
            /// `failure` જ્યારે સરખામણી નિષ્ફળ થાય ત્યારે થાય છે તે લોડ ઓપરેશન માટે જરૂરી ઓર્ડરિંગ વર્ણવે છે.
            /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ સફળ લોડ [`Relaxed`] બનાવે છે.
            ///
            /// નિષ્ફળતાનો ઓર્ડર ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા બરાબર અથવા નબળા હોવા જોઈએ.
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ચાલો મ્યુટ ઓલ્ડ= val.load(Ordering::Relaxed);
            /// લૂપ {દો new=old * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } મેચ કરો}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// વર્તમાન મૂલ્યમાં ઉમેરો કરે છે, પાછલું મૂલ્ય પાછું આપે છે.
            ///
            /// આ કામગીરી ઓવરફ્લો પર આસપાસ લપેટી.
            ///
            /// `fetch_add` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્યમાંથી બાદબાકી, પાછલા મૂલ્યને પરત.
            ///
            /// આ કામગીરી ઓવરફ્લો પર આસપાસ લપેટી.
            ///
            /// `fetch_sub` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ "and".
            ///
            /// વર્તમાન મૂલ્ય અને દલીલ `val` પર થોડુંક "and" ઓપરેશન કરે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_and` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ "nand".
            ///
            /// વર્તમાન મૂલ્ય અને દલીલ `val` પર થોડુંક "nand" ઓપરેશન કરે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_nand` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 અને 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ "or".
            ///
            /// વર્તમાન મૂલ્ય અને દલીલ `val` પર થોડુંક "or" ઓપરેશન કરે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_or` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્ય સાથે બિટવાઇઝ "xor".
            ///
            /// વર્તમાન મૂલ્ય અને દલીલ `val` પર થોડુંક "xor" ઓપરેશન કરે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_xor` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// મૂલ્ય મેળવે છે, અને તેમાં કોઈ કાર્ય લાગુ કરે છે જે વૈકલ્પિક નવું મૂલ્ય આપે છે.જો કાર્ય `Some(_)` પરત કરે છે, નહીં તો `Err(previous_value)`, `Ok(previous_value)` નો `Result` આપે છે.
            ///
            /// Note: આ ફંક્શનને ઘણી વખત ક callલ કરી શકે છે જો આ દરમ્યાન મૂલ્ય અન્ય થ્રેડોથી બદલાઈ ગયું હોય, જ્યાં સુધી ફંક્શન `Some(_)` આપે છે, પરંતુ ફંક્શન ફક્ત એક જ વાર સ્ટોર કરેલી વેલ્યુ પર લાગુ કરવામાં આવશે.
            ///
            ///
            /// `fetch_update` આ ofપરેશનના મેમરી ingર્ડરિંગને વર્ણવવા બે [`Ordering`] દલીલો લે છે.
            /// પ્રથમ જ્યારે ઓપરેશન આખરે સફળ થાય છે ત્યારે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે જ્યારે બીજું લોડ્સ માટે જરૂરી ઓર્ડરિંગનું વર્ણન કરે છે.આ સફળતા અને નિષ્ફળતાના ઓર્ડરને અનુરૂપ છે
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// સફળતાના ઓર્ડર તરીકે [`Acquire`] નો ઉપયોગ સ્ટોરને આ ક્રિયા [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ અંતિમ સફળ લોડ [`Relaxed`] બનાવે છે.
            /// (failed) લોડ ઓર્ડરિંગ ફક્ત [`SeqCst`], [`Acquire`] અથવા [`Relaxed`] હોઈ શકે છે અને સફળતાના ઓર્ડર કરતા સમાન અથવા નબળા હોવા જોઈએ.
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ઓર્ડરિંગ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ઓર્ડરિંગ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// વર્તમાન મૂલ્ય સાથે મહત્તમ.
            ///
            /// મહત્તમ વર્તમાન મૂલ્ય અને દલીલ `val` શોધે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_max` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// દો બાર=42;
            /// ચાલો મહત્તમ_ફૂ=foo.fetch_max (બાર, Ordering::SeqCst).max(bar);
            /// ભારપૂર્વક! (મહત્તમ_ફૂ==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// વર્તમાન મૂલ્ય સાથે ન્યૂનતમ.
            ///
            /// વર્તમાન મૂલ્યનું ન્યૂનતમ અને દલીલ `val` શોધે છે, અને પરિણામ પર નવું મૂલ્ય સેટ કરે છે.
            ///
            /// પાછલું મૂલ્ય આપે છે.
            ///
            /// `fetch_min` [`Ordering`] દલીલ લે છે જે આ ofપરેશનના મેમરી ઓર્ડરનું વર્ણન કરે છે.બધા ઓર્ડર મોડ્સ શક્ય છે.
            /// નોંધ લો કે [`Acquire`] નો ઉપયોગ આ સ્ટોરને [`Relaxed`] નો ભાગ બનાવે છે, અને [`Release`] નો ઉપયોગ કરીને લોડ ભાગ [`Relaxed`] બનાવે છે.
            ///
            ///
            /// **નોંધ**: આ પદ્ધતિ ફક્ત પ્લેટફોર્મ પર જ ઉપલબ્ધ છે કે જે પરમાણુ ક્રિયાઓને ટેકો આપે છે
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// દો બાર=12;
            /// ચાલો min_foo=foo.fetch_min (બાર, Ordering::SeqCst).min(bar);
            /// assert_eq! (મિનિટ_ફૂ, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // સલામતી: ડેટા રેસને અણુ આંતરિક દ્વારા અટકાવવામાં આવે છે.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// અંતર્ગત પૂર્ણાંકમાં પરિવર્તનીય પોઇન્ટર પાછું આપે છે.
            ///
            /// પરિણામી પૂર્ણાંકો પર બિન-અણુ વાંચવા અને લખવાનું કરવું એ કોઈ ડેટા રેસ હોઈ શકે છે.
            /// આ પદ્ધતિ મોટે ભાગે એફએફઆઈ માટે ઉપયોગી છે, જ્યાં કાર્ય સહીનો ઉપયોગ કરી શકે છે
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// આ અણુના વહેંચાયેલા સંદર્ભમાંથી `*mut` પોઇન્ટર પાછું ફરવું સલામત છે કારણ કે પરમાણુ પ્રકારો આંતરિક પરિવર્તન સાથે કાર્ય કરે છે.
            /// અણુના તમામ ફેરફારો, શેર કરેલા સંદર્ભ દ્વારા મૂલ્યમાં ફેરફાર કરે છે અને તે પરમાણુ કામગીરીનો ઉપયોગ કરે ત્યાં સુધી સલામત રીતે કરી શકે છે.
            /// પાછા ફરેલા કાચા પોઇન્ટરના કોઈપણ ઉપયોગ માટે `unsafe` બ્લોકની જરૂર હોય છે અને હજી પણ તે જ પ્રતિબંધને જાળવવો પડે છે: તેના પરના ઓપરેશન્સ અણુ હોવા આવશ્યક છે.
            ///
            ///
            /// # Examples
            ///
            /// X `X (extern-declaration) ને અવગણો
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// બાહ્ય "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // સલામતી: `my_atomic_op` અણુ હોય ત્યાં સુધી સલામત.
            /// અસુરક્ષિત {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // સલામતી: કlerલરને `atomic_store` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_load` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_swap` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// પાછલું મૂલ્ય આપે છે (જેમ કે __ sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_add` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// પાછલું મૂલ્ય આપે છે (જેમ કે __ sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_sub` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // સલામતી: કlerલરને `atomic_compare_exchange` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // સલામતી: કlerલરને `atomic_compare_exchange_weak` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_and` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_nand` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_or` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_xor` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// મહત્તમ મૂલ્ય આપે છે (સહી કરેલી સરખામણી)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_max` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// મિનિમ મૂલ્ય આપે છે (સહી કરેલી સરખામણી)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_min` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// મહત્તમ મૂલ્ય આપે છે (સહી ન કરેલી સરખામણી)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_umax` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// મિનિમ મૂલ્ય આપે છે (સહી ન કરેલી સરખામણી)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // સલામતી: કlerલરને `atomic_umin` માટે સલામતી કરારનું સમર્થન કરવું આવશ્યક છે
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// એક અણુ વાડ.
///
/// ઉલ્લેખિત orderર્ડરના આધારે, વાડ કમ્પાઇલર અને સીપીયુને તેની આસપાસના અમુક પ્રકારના મેમરી ઓપરેશન્સને ફરીથી ગોઠવવાથી અટકાવે છે.
/// તે તેના વચ્ચે અણુ operationsપરેશન અથવા અન્ય થ્રેડોમાં વાડ વચ્ચે સુમેળ સાથેના સંબંધો બનાવે છે.
///
/// એક વાડ 'A' જેમાં (ઓછામાં ઓછું) [`Release`] seર્ડર સીમેન્ટિક્સ છે, (ઓછામાં ઓછા) [`Acquire`] સિમેંટિક્સ સાથે વાડ 'B' સાથે સિંક્રનાઇઝ કરે છે, જો અને ત્યાં માત્ર ક્રિયાઓ X અને Y હોય, તો બંને કેટલાક અણુ objectબ્જેક્ટ 'M' પર કાર્ય કરે છે જેમ કે A પહેલા ક્રમ છે એક્સ, વાય એ બી પહેલાં સમન્વયિત થાય છે અને વાય એમમાં ફેરફારનું અવલોકન કરે છે.
/// આ એ અને બી વચ્ચે બને તે પહેલાં પરાધીનતા પ્રદાન કરે છે.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] અથવા [`Acquire`] અર્થશાસ્ત્ર સાથેના અણુ ક્રિયાઓ પણ વાડ સાથે સુમેળ કરી શકે છે.
///
/// એક વાડ કે જેમાં [`SeqCst`] ઓર્ડરિંગ હોય છે, બંને [`Acquire`] અને [`Release`] સિમેન્ટીકસ ઉપરાંત, અન્ય [`SeqCst`] કામગીરી અને/અથવા વાડના વૈશ્વિક પ્રોગ્રામ ઓર્ડરમાં ભાગ લે છે.
///
/// [`Acquire`], [`Release`], [`AcqRel`] અને [`SeqCst`] orderર્ડરિંગ્સ સ્વીકારે છે.
///
/// # Panics
///
/// જો `order` એ [`Relaxed`] હોય તો ઝેડપેનિક્સ 0 ઝેડ.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // સ્પિનલોક પર આધારિત મ્યુચ્યુઅલ બાકાત પ્રાચીન.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // જૂની કિંમત `false` ન થાય ત્યાં સુધી પ્રતીક્ષા કરો.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // આ વાડ `unlock` માં સ્ટોર સાથે સિંક્રનાઇઝ કરે છે.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // સલામત: અણુ વાડનો ઉપયોગ સલામત છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// એક કમ્પાઇલર મેમરી વાડ.
///
/// `compiler_fence` કોઈપણ મશીન કોડનું ઉત્સર્જન કરતું નથી, પરંતુ કમ્પાઇલરને કરવાની રીતની રીમ-ઓર્ડરના પ્રકારોને પ્રતિબંધિત કરે છે.વિશેષરૂપે, આપેલ [`Ordering`] અર્થશાસ્ત્રના આધારે, કમ્પાઇલરને `compiler_fence` પર ક callલની બીજી બાજુ પર ક beforeલ કરતા પહેલાં અથવા પછીથી વાંચન વાંચન અથવા લખવાની મંજૂરી ન હોઇ શકે.નોંધ લો કે તે **નથી***હાર્ડવેર* ને આવી રી-ઓર્ડરિંગ કરવાથી અટકાવે છે.
///
/// આ એક સિંગલ-થ્રેડેડ, એક્ઝેક્યુશન સંદર્ભમાં સમસ્યા નથી, પરંતુ જ્યારે અન્ય થ્રેડો તે જ સમયે મેમરીમાં ફેરફાર કરી શકે છે, ત્યારે [`fence`] જેવા મજબૂત સિંક્રોનાઇઝેશન આદિમ આવશ્યક છે.
///
/// રી-ઓર્ડરિંગ વિવિધ ઓર્ડર અર્થશાસ્ત્ર દ્વારા અટકાવેલ છે:
///
///  - [`SeqCst`] સાથે, આ બિંદુએ વાંચવા અને લખવાની રી-ingર્ડરિંગને મંજૂરી નથી.
///  - [`Release`] સાથે, પહેલાનાં વાંચન અને લેખકોને પાછલા અનુગામી લેખકોને ખસેડી શકાતા નથી.
///  - [`Acquire`] સાથે, અનુગામી વાંચન અને લેખકોને આગળના વાંચન કરતા આગળ ખસેડી શકાતા નથી.
///  - [`AcqRel`] સાથે, ઉપરોક્ત બંને નિયમો લાગુ કરવામાં આવ્યા છે.
///
/// `compiler_fence` સામાન્ય રીતે ફક્ત થ્રેડને પોતાની સાથે * ચલાવવાથી રોકવા માટે જ ઉપયોગી છે.તે છે, જો આપેલ થ્રેડ કોડના એક ભાગને ચલાવે છે, અને તે પછી વિક્ષેપિત થાય છે, અને બીજે ક્યાંય કોડ ચલાવવાનું શરૂ કરે છે (જ્યારે તે જ થ્રેડમાં છે, અને વિભાવનાત્મક રીતે હજી પણ સમાન કોર પર).પરંપરાગત પ્રોગ્રામ્સમાં, આ ફક્ત ત્યારે જ થઈ શકે છે જ્યારે સિગ્નલ હેન્ડલર નોંધાયેલ હોય.
/// વધુ નીચા-સ્તરના કોડમાં, આવી પરિસ્થિતિઓ જ્યારે અંતરાયોને નિયંત્રિત કરતી વખતે પણ થઈ શકે છે, જ્યારે પૂર્વ-ઉત્તેજના સાથે લીલા થ્રેડો લાગુ પાડતી હોય છે, વગેરે.
/// વિચિત્ર વાચકોને [memory barriers] X કર્નલની [memory barriers] ની ચર્ચા વાંચવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
///
/// # Panics
///
/// જો `order` એ [`Relaxed`] હોય તો ઝેડપેનિક્સ 0 ઝેડ.
///
/// # Examples
///
/// `compiler_fence` વિના, નીચેના કોડમાં `assert_eq!` એ બધું એક જ થ્રેડમાં હોવા છતાં, સફળ થવાની બાંયધરી નથી.
/// કેમ તે જોવા માટે, યાદ રાખો કે કમ્પાઇલર સ્ટોર્સને `IMPORTANT_VARIABLE` અને `IS_READ` પર ફેરવી શકશે કારણ કે તે બંને `Ordering::Relaxed` છે.જો તે થાય છે, અને `IS_READY` અપડેટ થયા પછી તરત જ સિગ્નલ હેન્ડલરનો ઉપયોગ કરવામાં આવે છે, તો સિગ્નલ હેન્ડલર `IS_READY=1` જોશે, પરંતુ `IMPORTANT_VARIABLE=0`.
/// આ પરિસ્થિતિમાં `compiler_fence` ઉપાયનો ઉપયોગ કરવો.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // અગાઉના લેખકોને આ મુદ્દાથી આગળ વધતા અટકાવો
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // સલામત: અણુ વાડનો ઉપયોગ સલામત છે.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// પ્રોસેસરનો સંકેત આપે છે કે તે વ્યસ્ત-પ્રતીક્ષા સ્પિન-લૂપ ("સ્પિન લ"ક") ની અંદર છે.
///
/// આ ફંક્શન [`hint::spin_loop`] ની તરફેણમાં નાપસંદ થયેલ છે.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}