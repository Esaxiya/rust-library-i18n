# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate માટે દસ્તાવેજીકરણ જુઓ.