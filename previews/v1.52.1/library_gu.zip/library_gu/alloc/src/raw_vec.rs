#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// નવી મેમરીના સમાવિષ્ટને અનઇટિટાઈઝ્ડ કર્યા છે.
    Uninitialized,
    /// નવી મેમરીને શૂન્ય કરવાની ખાતરી આપવામાં આવી છે.
    Zeroed,
}

/// વધુ એર્ગોનોમિકલી રીતે ફાળવણી, ફરીથી રજૂઆત કરવા, અને મેમરીના બફરને allગલા પર સમાવિષ્ટ, બધા ખૂણાવાળા કેસોની ચિંતા કર્યા વગર, ઘટાડવાની નીચી-સ્તરની યુટિલિટી.
///
/// આ પ્રકાર વેક અને વેકડેક જેવા તમારા પોતાના ડેટા સ્ટ્રક્ચર્સ બનાવવા માટે ઉત્તમ છે.
/// વિશેષ રીતે:
///
/// * શૂન્ય-કદના પ્રકારો પર `Unique::dangling()` ઉત્પન્ન કરે છે.
/// * શૂન્ય-લંબાઈના ફાળવણી પર `Unique::dangling()` ઉત્પન્ન કરે છે.
/// * `Unique::dangling()` મુક્ત કરવાનું ટાળે છે.
/// * ક્ષમતા ગણતરીમાં બધા ઓવરફ્લો પકડે છે (તેમને "capacity overflow" panics પર પ્રોત્સાહન આપે છે).
/// * isize::MAX બાઇટ્સ કરતા વધુ ફાળવણી કરતી 32-બીટ સિસ્ટમ્સ સામે ગાર્ડ્સ.
/// * તમારી લંબાઈને ઓવરફ્લો કરવા સામે રક્ષકો.
/// * ક્ષતિપૂર્ણ ફાળવણી માટે `handle_alloc_error` ક00લ કરો.
/// * એક `ptr::Unique` સમાવે છે અને આ રીતે વપરાશકર્તાને બધા સંબંધિત ફાયદાઓથી સમર્થન આપે છે.
/// * સૌથી મોટી ઉપલબ્ધ ક્ષમતાનો ઉપયોગ કરવા માટે ફાળવણીકાર પાસેથી પરત આપવામાં આવેલી અતિશયતાનો ઉપયોગ કરે છે.
///
/// આ પ્રકાર કોઈપણ રીતે તે સંચાલિત કરે છે તે મેમરીનું નિરીક્ષણ કરતું નથી.જ્યારે તેને છોડવામાં આવે ત્યારે *તેની મેમરી* મુક્ત થશે, પરંતુ તે તેની સામગ્રી છોડવાનો પ્રયાસ કરશે નહીં *.
/// એક `RawVec` ની અંદરની વસ્તુઓ *સ્ટોર કરેલી* હેન્ડલ કરવાનું `RawVec` ના વપરાશકર્તા પર છે.
///
/// નોંધ લો કે શૂન્ય-કદના પ્રકારોનો અતિરેક હંમેશા અનંત હોય છે, તેથી `capacity()` હંમેશાં `usize::MAX` આપે છે.
/// આનો અર્થ એ કે `Box<[T]>` ની સાથે આ પ્રકારના ગોળાકાર ટ્રિપિંગ કરતી વખતે તમારે સાવચેત રહેવાની જરૂર છે, કારણ કે `capacity()` લંબાઈ પ્રાપ્ત કરશે નહીં.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): આ અસ્તિત્વમાં છે કારણ કે `#[unstable]` `const fn`s ને `min_const_fn` ને અનુરૂપ બનાવવાની જરૂર નથી અને તેથી તે ક્યાં તો`min_const_fn`s માં ક cannotલ કરી શકતા નથી.
    ///
    /// જો તમે `RawVec<T>::new` અથવા અવલંબન બદલતા હો, તો કૃપા કરીને `min_const_fn` નું ઉલ્લંઘન કરે તેવી કોઈ પણ વસ્તુનો પરિચય ન કરવાની કાળજી લો.
    ///
    /// NOTE: અમે આ હેકને ટાળી શકીએ અને કેટલાક `#[rustc_force_min_const_fn]` એટ્રિબ્યુટ સાથેની સંભાવનાને તપાસી શકીએ કે જેને `min_const_fn` સાથે જોડાણની જરૂર હોય પરંતુ જ્યારે `#[rustc_const_unstable(feature = "foo", issue = "01234")]` હાજર હોય ત્યારે `stable(...) const fn`/વપરાશકર્તા કોડમાં `foo` ને સક્ષમ ન કરતા, તેને ક callingલ કરવાની મંજૂરી આપતા નથી.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ફાળવણી કર્યા વિના સૌથી મોટી સંભવિત `RawVec` (સિસ્ટમ apગલા પર) બનાવે છે.
    /// જો `T` પાસે સકારાત્મક કદ છે, તો પછી આ `0` ક્ષમતાવાળા `RawVec` બનાવે છે.
    /// જો `T` શૂન્ય-કદનું છે, તો પછી તે ક્ષમતા `usize::MAX` સાથે `RawVec` બનાવે છે.
    /// વિલંબિત ફાળવણીના અમલીકરણ માટે ઉપયોગી.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` માટે બરાબર ક્ષમતા અને ગોઠવણી આવશ્યકતાઓ સાથે એક `RawVec` (સિસ્ટમ apગલા પર) બનાવે છે.
    /// જ્યારે `capacity` `0` અથવા `T` શૂન્ય-કદના હોય ત્યારે `RawVec::new` ને ક callingલ કરવા માટે આ બરાબર છે.
    /// નોંધ લો કે જો `T` શૂન્ય કદનું હોય તો આનો અર્થ છે કે તમે વિનંતી કરેલી ક્ષમતા સાથે `RawVec` મેળવશો નહીં.
    ///
    /// # Panics
    ///
    /// Panics જો વિનંતી કરેલી ક્ષમતા `isize::MAX` બાઇટ્સથી વધુ છે.
    ///
    /// # Aborts
    ///
    /// OOM પર છોડી દે છે.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` ની જેમ, પરંતુ બાફરની ખાતરી છે કે તે શૂન્ય છે.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// નિર્દેશક અને ક્ષમતાથી એક `RawVec` ફરીથી ગોઠવે છે.
    ///
    /// # Safety
    ///
    /// `ptr` ફાળવેલ હોવું આવશ્યક છે (સિસ્ટમના theગલા પર), અને આપેલ `capacity` સાથે.
    /// `capacity` કદના પ્રકારો માટે `isize::MAX` કરતાં વધી શકશે નહીં.(ફક્ત 32-બીટ સિસ્ટમ્સ પરની ચિંતા).
    /// ZST vectors માં `usize::MAX` સુધીની ક્ષમતા હોઈ શકે છે.
    /// જો `ptr` અને `capacity` એ `RawVec` માંથી આવે છે, તો આ ખાતરી આપવામાં આવે છે.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // નાના વેક મૂંગા છે.આના પર જાઓ:
    // - 8 જો તત્વનું કદ 1 હોય, કારણ કે કોઈ પણ allocગલા ફાળવણીકાર ઓછામાં ઓછા 8 બાઇટ્સથી 8 બાઇટ્સની વિનંતીને વધારી શકે છે.
    //
    // - 4 જો તત્વો મધ્યમ કદના હોય (<=1 કીબી).
    // - 1 અન્યથા, ખૂબ ટૂંકા Vecs માટે વધુ પડતી જગ્યાનો વ્યય ન કરવા માટે.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` જેવું છે, પરંતુ પરત `RawVec` માટે ફાળવણીકારની પસંદગી પર પરિમાણો છે.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` એટલે "unallocated".શૂન્ય-કદના પ્રકારો અવગણવામાં આવે છે.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` જેવું છે, પરંતુ પરત `RawVec` માટે ફાળવણીકારની પસંદગી પર પરિમાણો છે.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` જેવું છે, પરંતુ પરત `RawVec` માટે ફાળવણીકારની પસંદગી પર પરિમાણો છે.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ને `RawVec<T>` માં ફેરવે છે.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// સંપૂર્ણ બફરને નિર્દિષ્ટ `len` સાથે `Box<[MaybeUninit<T>]>` માં રૂપાંતરિત કરે છે.
    ///
    /// નોંધ લો કે આ કોઈપણ `cap` ફેરફારને યોગ્ય રીતે ગોઠવશે જે કરવામાં આવી શકે.(વિગતો માટે પ્રકારનું વર્ણન જુઓ.)
    ///
    /// # Safety
    ///
    /// * `len` સૌથી તાજેતરની વિનંતી કરેલી ક્ષમતા કરતા મોટી અથવા સમાન હોવી જોઈએ, અને
    /// * `len` `self.capacity()` કરતા ઓછું અથવા બરાબર હોવું જોઈએ.
    ///
    /// નોંધ, કે વિનંતી કરેલી ક્ષમતા અને `self.capacity()` ભિન્ન હોઈ શકે છે, કારણ કે ફાળવણીકાર વિનંતી કરતા વધારે મેમરી બ્લ blockકને એકંદર કરી શકે છે અને પાછો આપી શકે છે.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // સલામતીની જરૂરિયાતનો અડધો ભાગ (અમે બીજા ભાગની તપાસી શકીએ નહીં).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // અમે અહીં `unwrap_or_else` ટાળીએ છીએ કારણ કે તે ઉત્પન્ન થયેલ એલએલવીએમ આઈઆરનો જથ્થો ફૂલે છે.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// નિર્દેશક, ક્ષમતા અને ફાળવણીકારથી `RawVec` ફરીથી ગોઠવે છે.
    ///
    /// # Safety
    ///
    /// `ptr` ફાળવેલ હોવું આવશ્યક છે (આપેલ ફાળવણીકાર `alloc` દ્વારા), અને આપેલ `capacity` સાથે.
    /// `capacity` કદના પ્રકારો માટે `isize::MAX` કરતાં વધી શકશે નહીં.
    /// (ફક્ત 32-બીટ સિસ્ટમ્સ પરની ચિંતા).
    /// ZST vectors માં `usize::MAX` સુધીની ક્ષમતા હોઈ શકે છે.
    /// જો `ptr` અને `capacity`, `alloc` દ્વારા બનાવેલ `RawVec` માંથી આવે છે, તો આ ખાતરી આપવામાં આવે છે.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ફાળવણીની શરૂઆત માટે કાચો નિર્દેશક મેળવે છે.
    /// નોંધ લો કે જો `capacity == 0` અથવા `T` શૂન્ય-કદના હોય તો આ `Unique::dangling()` છે.
    /// અગાઉના કિસ્સામાં, તમારે સાવચેત રહેવું જોઈએ.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ફાળવણીની ક્ષમતા મેળવે છે.
    ///
    /// જો `T` શૂન્ય-કદનું હોય તો આ હંમેશાં `usize::MAX` રહેશે.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// આ `RawVec` ને ટેકો આપનારા ફાળવણીકારનો એક વહેંચાયેલ સંદર્ભ આપે છે.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // અમારી પાસે મેમરીનો ફાળવેલ ભાગ છે, તેથી અમે અમારું વર્તમાન લેઆઉટ મેળવવા માટે રનટાઇમ તપાસને બાયપાસ કરી શકીએ.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// સુનિશ્ચિત કરે છે કે બફરમાં `len + additional` તત્વોને રાખવા માટે ઓછામાં ઓછી પૂરતી જગ્યા શામેલ છે.
    /// જો તેની પાસે પહેલેથી જ પૂરતી ક્ષમતા નથી, તો orણમુક્તિ *ઓ*(1) વર્તણૂક મેળવવા માટે પૂરતી જગ્યા વત્તા આરામદાયક સ્લ spaceક જગ્યાને ફરીથી વિકસિત કરશે.
    ///
    /// આ વર્તણૂકને મર્યાદિત કરશે જો તે બિનજરૂરી રીતે પોતાને panic તરફ દોરી જાય.
    ///
    /// જો `len` `self.capacity()` કરતા વધારે છે, તો આ ખરેખર વિનંતી કરેલી જગ્યા ફાળવવામાં નિષ્ફળ થઈ શકે છે.
    /// આ ખરેખર અસુરક્ષિત નથી, પરંતુ અસુરક્ષિત કોડ *તમે* લખો છો કે જે આ કાર્યની વર્તણૂક પર આધાર રાખે છે તે તૂટી શકે છે.
    ///
    /// `extend` જેવા બલ્ક-પુશ implementingપરેશનને લાગુ કરવા માટે આ આદર્શ છે.
    ///
    /// # Panics
    ///
    /// Panics જો નવી ક્ષમતા `isize::MAX` બાઇટ્સથી વધુ છે.
    ///
    /// # Aborts
    ///
    /// OOM પર છોડી દે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // જો લેન `isize::MAX` કરતા વધી ગયો હોય તો અનામતને અવગણવું અથવા ગભરાવું પડશે તેથી આ હવે અનચેક કરવું સલામત છે.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` જેવું જ છે, પરંતુ ગભરાટ અથવા ગર્ભપાતને બદલે ભૂલો પરત આપે છે.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// સુનિશ્ચિત કરે છે કે બફરમાં `len + additional` તત્વોને રાખવા માટે ઓછામાં ઓછી પૂરતી જગ્યા શામેલ છે.
    /// જો તે પહેલાથી જ નથી, તો જરૂરી મેમરીની ન્યૂનતમ શક્ય રકમ ફરીથી લગાડશે.
    /// સામાન્ય રીતે આ બરાબર મેમરીની જરુરી માત્રા હશે, પરંતુ સિદ્ધાંતમાં ફાળવણીકાર, અમે માંગ્યા કરતા વધારે આપશે.
    ///
    ///
    /// જો `len` `self.capacity()` કરતા વધારે છે, તો આ ખરેખર વિનંતી કરેલી જગ્યા ફાળવવામાં નિષ્ફળ થઈ શકે છે.
    /// આ ખરેખર અસુરક્ષિત નથી, પરંતુ અસુરક્ષિત કોડ *તમે* લખો છો કે જે આ કાર્યની વર્તણૂક પર આધાર રાખે છે તે તૂટી શકે છે.
    ///
    /// # Panics
    ///
    /// Panics જો નવી ક્ષમતા `isize::MAX` બાઇટ્સથી વધુ છે.
    ///
    /// # Aborts
    ///
    /// OOM પર છોડી દે છે.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` જેવું જ છે, પરંતુ ગભરાટ અથવા ગર્ભપાતને બદલે ભૂલો પરત આપે છે.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ફાળવણીને નિર્ધારિત રકમથી નીચે ઘટાડે છે.
    /// જો આપેલ રકમ 0 છે, તો ખરેખર સંપૂર્ણપણે અવમૂલ્યન થાય છે.
    ///
    /// # Panics
    ///
    /// Panics જો આપેલ રકમ વર્તમાન ક્ષમતા કરતા *મોટી* છે.
    ///
    /// # Aborts
    ///
    /// OOM પર છોડી દે છે.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// જો જરૂરી વધારાની ક્ષમતા પૂર્ણ કરવા માટે બફરને વધવાની જરૂર હોય તો પરત આવે છે.
    /// મુખ્યત્વે `grow` ઇનલાઇન કર્યા વિના ઇનલાઇનિંગ રિઝર્વ-ક callsલ્સ કરવા માટે ઉપયોગમાં લેવાય છે.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // આ પદ્ધતિ સામાન્ય રીતે ઘણી વખત ઇન્સ્ટન્ટ કરવામાં આવે છે.તેથી કમ્પાઇલ સમય સુધારવા માટે, તે શક્ય તેટલું નાનું હોવું જોઈએ.
    // પરંતુ જનરેટ કોડને વધુ ઝડપથી ચલાવવા માટે, અમે તેના ઘણા બધા સમાવિષ્ટને શક્ય તેટલા સ્થિર ગણનાયોગ્ય તરીકે પણ ઇચ્છીએ છીએ.
    // તેથી, આ પદ્ધતિ કાળજીપૂર્વક લખી છે જેથી `T` પર આધાર રાખે છે તે તમામ કોડ તેની અંદર છે, જ્યારે `T` પર શક્ય ન હોય તેટલો કોડ `T` કરતા વધારે સામાન્ય એવા કાર્યોમાં છે.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // આ ક callingલિંગ સંદર્ભો દ્વારા ખાતરી કરવામાં આવી છે.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` હોય ત્યારે અમે `usize::MAX` ની ક્ષમતા પરત કરીએ છીએ
            // 0, અહીં પહોંચવું એ જરૂરી છે કે `RawVec` ઓવરફુલ છે.
            return Err(CapacityOverflow);
        }

        // દુ cheખની વાત છે કે આપણે આ તપાસણીઓ વિશે ખરેખર કંઈ કરી શકીએ નહીં.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // આ ઘાતાંકીય વૃદ્ધિની બાંયધરી આપે છે.
        // ડબલિંગ ઓવરફ્લો થઈ શકતું નથી કારણ કે `cap <= isize::MAX` અને `cap` નો પ્રકાર `usize` છે.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` કરતા વધુ સામાન્ય છે.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // આ પદ્ધતિની અવરોધો `grow_amortized` પરની સમાન છે, પરંતુ આ પદ્ધતિ સામાન્ય રીતે ઓછી વાર ઇન્સ્ટન્ટ કરવામાં આવે છે તેથી તે ઓછી જટિલ છે.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // કારણ કે જ્યારે પ્રકારનું કદ હોય ત્યારે અમે `usize::MAX` ની ક્ષમતા પરત કરીએ છીએ
            // 0, અહીં પહોંચવું એ જરૂરી છે કે `RawVec` ઓવરફુલ છે.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` કરતા વધુ સામાન્ય છે.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// કમ્પાઇલ ટાઇમ્સ ઘટાડવા માટે આ ફંક્શન `RawVec` ની બહાર છે.વિગતો માટે `RawVec::grow_amortized` ઉપરની ટિપ્પણી જુઓ.
// (`A` પરિમાણ મહત્વપૂર્ણ નથી, કારણ કે વ્યવહારમાં જુદા જુદા `A` પ્રકારોની સંખ્યા `T` પ્રકારોની સંખ્યા કરતા ઘણી ઓછી છે.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` નું કદ ઘટાડવા માટે અહીં ભૂલ માટે તપાસો.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ફાળવણીકાર ગોઠવણી સમાનતા માટે તપાસે છે
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*ની માલિકીની મેમરીને* તેના સમાવિષ્ટોને છોડવાનો પ્રયાસ કર્યા વિના મુક્ત કરે છે.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// અનામત ભૂલ સંચાલન માટેનું કેન્દ્રિય કાર્ય.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// આપણે નીચેની બાંયધરી આપવાની જરૂર છે:
// * અમે ક્યારેય `> isize::MAX` બાઇટ-સાઇઝ .બ્જેક્ટ્સ ફાળવતા નથી.
// * અમે `usize::MAX` ઓવરફ્લો કરતા નથી અને ખરેખર ખૂબ ઓછી ફાળવણી કરીએ છીએ.
//
// -64-બીટ પર આપણે ફક્ત ઓવરફ્લો તપાસવાની જરૂર છે કારણ કે `> isize::MAX` બાઇટ્સ ફાળવવાનો પ્રયાસ કરવામાં નિષ્ફળ જશે.
// 32-બીટ અને 16-બીટ પર આપણે આ માટે એક વધારાનો રક્ષક ઉમેરવાની જરૂર છે જો આપણે કોઈ પ્લેટફોર્મ પર ચલાવીએ છીએ જે યુઝર-સ્પેસમાં બધા 4 જીબીનો ઉપયોગ કરી શકે, દા.ત., પીએઇ અથવા એક્સ 100 એક્સ.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ક્ષમતાના ઓવરફ્લોની જાણ કરવા માટે જવાબદાર એક કેન્દ્રીય કાર્ય.
// આ સુનિશ્ચિત કરશે કે આ ઝેડપેનિક્સ0 ઝેડથી સંબંધિત કોડ જનરેશન ન્યૂનતમ છે કારણ કે ત્યાં ફક્ત એક જ સ્થાન છે જે મોડ્યુલ દરમ્યાન ટોળું કરતાં ઝેડપpanનિક્સ 0 ઝેડ.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}