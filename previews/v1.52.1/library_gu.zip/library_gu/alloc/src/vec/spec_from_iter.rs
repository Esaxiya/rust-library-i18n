use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter માટે વપરાયેલી વિશેષતા trait
///
/// ## પ્રતિનિધિમંડળનો આલેખ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // એક સામાન્ય કેસ એક ઝેડ 0 વેક્ટર 0 ઝેડને ફંક્શનમાં પસાર કરી રહ્યું છે જે તરત જ vector માં ફરીથી એકત્રિત કરે છે.
        // જો આ ઇન્ટોઇટર જરાય આગળ વધ્યા ન હોય તો આપણે આને શોર્ટ સર્કિટ કરી શકીએ છીએ.
        // જ્યારે તે અદ્યતન થઈ ગયું છે ત્યારે આપણે મેમરીનો ફરીથી ઉપયોગ કરી શકીએ છીએ અને ડેટાને આગળ લઈ જઈ શકીએ છીએ.
        // પરંતુ અમે ફક્ત ત્યારે જ કરીએ છીએ જ્યારે પરિણામી વીઇસી પાસે સામાન્ય ફ્રોઇટેરેટર અમલીકરણ દ્વારા તેને બનાવવા કરતા વધુ વપરાયેલી ક્ષમતા ન હોય.
        //
        // તે મર્યાદા સખ્તાઇથી જરૂરી નથી કારણ કે વેકની ફાળવણીની વર્તણૂક ઇરાદાપૂર્વક અનિશ્ચિત છે.
        // પરંતુ તે એક રૂ conિચુસ્ત પસંદગી છે.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() ને spec_extend() ને સોંપવું જ જોઇએ કારણ કે ખાલી Vecs માટે extend() પોતે જ spec_from ને ડેલિગેટ કરે છે
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// આ `iterator.as_slice().to_vec()` નો ઉપયોગ કરે છે કારણ કે સ્પેશિયલ એક્સ્ટેંડે અંતિમ ક્ષમતા + લંબાઈ અંગેના કારણોસર વધુ પગલાં ભરવા આવશ્યક છે અને આમ વધુ કાર્ય કરવું જોઈએ.
// `to_vec()` સીધી જ યોગ્ય રકમ ફાળવે છે અને તે બરાબર ભરે છે.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) સાથે અંતર્ગત `[T]::to_vec` પદ્ધતિ, જે આ પદ્ધતિની વ્યાખ્યા માટે જરૂરી છે, ઉપલબ્ધ નથી.
    // તેના બદલે `slice::to_vec` ફંક્શનનો ઉપયોગ કરો જે ફક્ત cfg(test) NB સાથે જ ઉપલબ્ધ છે વધુ માહિતી માટે slice.rs માં slice::hack મોડ્યુલ જુઓ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}