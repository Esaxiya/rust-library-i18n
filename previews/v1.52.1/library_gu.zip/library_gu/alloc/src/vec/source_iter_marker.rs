use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// સ્ત્રોત ફાળવણીનો ફરીથી ઉપયોગ કરતી વખતે, વેકમાં ઇટરેટર પાઇપલાઇન એકઠી કરવા માટે વિશેષતા માટેનું માર્કર
/// જગ્યાએ પાઇપલાઇન ચલાવી રહ્યા છીએ.
///
/// સોર્સઇટર પિતૃ trait એ વિશિષ્ટ કાર્ય માટે ફાળવણીને accessક્સેસ કરવા માટે જરૂરી છે જે ફરીથી ઉપયોગમાં લેવાય છે.
/// પરંતુ તે વિશેષતા માન્ય હોવાનું પૂરતું નથી.
/// પ્રોત્સાહન પર વધારાની મર્યાદા જુઓ.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-આંતરિક SourceIter/InPlaceIterable traits ફક્ત એડેપ્ટરની સાંકળો દ્વારા લાગુ કરવામાં આવે છે <Adapter<Adapter<IntoIter>>> (બધા core/std ની માલિકીની છે).
// એડેપ્ટર અમલીકરણો પર વધારાની મર્યાદાઓ (`impl<I: Trait> Trait for Adapter<I>` ની બહાર) ફક્ત અન્ય traits પર આધારિત છે જે પહેલાથી જ સ્પેશિયલાઇઝેશન traits (ક Copyપિ, ટ્રસ્ટર્ડરંડમ cક્સેસ, ફ્યુઝ્ડિટેટર) તરીકે ચિહ્નિત થયેલ છે.
//
// I.e. માર્કર વપરાશકર્તા દ્વારા પૂરા પાડવામાં આવતા પ્રકારોના જીવનકાળ પર આધારીત નથી.મોડ્યુલો ક theપિ છિદ્ર, જે અન્ય કેટલીક વિશેષતાઓ પહેલેથી જ આધારિત છે.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // વધારાની આવશ્યકતાઓ જે trait bounds દ્વારા વ્યક્ત કરી શકાતી નથી.અમે તેના બદલે કોન્સ્ટન્ટ ઇવલ પર આધાર રાખીએ છીએ:
        // ક) ઝેડએસટી નથી કારણ કે ત્યાં પુનuseઉપયોગ માટે કોઈ ફાળવણી નહીં થાય અને પોઇંટર અંકગણિત panic કરશે b) એલોક કરાર દ્વારા જરૂરી કદની મેચ સી) એલોક કરાર દ્વારા જરૂરી ગોઠવણી મેચ
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // વધુ સામાન્ય અમલીકરણ માટે ફ fallલબેક
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ત્યારથી ટ્રાય-ફોલ્ડનો ઉપયોગ કરો
        // - તે કેટલાક પુનરાવર્તિત એડેપ્ટરો માટે વધુ સારી રીતે વેક્ટર કરે છે
        // - મોટાભાગની આંતરિક પુનરાવૃત્તિ પદ્ધતિઓથી વિપરીત, તે ફક્ત &mut સ્વ લે છે
        // - તે આપણને તેના આંતરિક ભાગોમાં લખાણ પોઇન્ટર દોરવા દે છે અને અંતે તેને પાછું મળે છે
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // પુનરાવૃત્તિ સફળ થઈ, માથું ન છોડો
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // તપાસો કે સોર્સઇટર કોન્ટ્રાક્ટ સાવચેતીભર્યું હતું કે નહીં: જો તેઓ ન હોત તો અમે તેને આ મુદ્દે પણ બનાવી શકીશું નહીં
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ઇનપ્લેસિટેરેબલ કરાર તપાસો.આ ફક્ત ત્યારે જ શક્ય છે જો ઇરેટરરે સ્રોત નિર્દેશકને બધામાં આગળ વધાર્યો હોય.
        // જો તે ટ્રસ્ટેડ રandન્ડમ cessક્સેસ દ્વારા અનચેક કરેલ usesક્સેસનો ઉપયોગ કરે છે તો સ્રોત નિર્દેશક તેની પ્રારંભિક સ્થિતિમાં રહેશે અને અમે તેને સંદર્ભ તરીકે ઉપયોગ કરી શકતા નથી.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // સ્રોતની પૂંછડી પર બાકીના કોઈપણ મૂલ્યો છોડો પરંતુ એકવાર ઇનટુ ઇટર અવકાશમાંથી બહાર જાય તો ફાળવણીના ડ્રોપને અટકાવો, જો ડ્રોપ ઝેડપpanનિક્સ 0 ઝેડ પછી આપણે પણ dst_buf માં એકત્રિત કરેલા કોઈપણ તત્વોને લીક કરીએ છીએ.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ઇનપ્લેસએટેરેબલ કરારની ચોક્કસપણે અહીં ચકાસણી કરી શકાતી નથી, કારણ કે ટ્રાય_ફોલ્ડમાં સ્રોત નિર્દેશકનો એક વિશિષ્ટ સંદર્ભ છે અમે કરી શકીએ છીએ તે તપાસવાનું છે કે તે હજી પણ શ્રેણીમાં છે કે કેમ
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}