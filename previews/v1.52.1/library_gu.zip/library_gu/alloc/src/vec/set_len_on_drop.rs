// જ્યારે `SetLenOnDrop` મૂલ્ય અવકાશની બહાર જાય ત્યારે વેક્ટરની લંબાઈ સેટ કરો.
//
// આ વિચાર છે: સેટલેન ઓનડ્રોપમાં લંબાઈ ક્ષેત્ર એ સ્થાનિક ચલ છે જે ઓપ્ટિમાઇઝર જોશે તે વેકના ડેટા પોઇન્ટર દ્વારા કોઈ સ્ટોર્સ સાથે ઉપનામ આપતું નથી.
// આ ઉપનામના વિશ્લેષણના મુદ્દા #32155 માટે એક કાર્ય સમાન છે
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}