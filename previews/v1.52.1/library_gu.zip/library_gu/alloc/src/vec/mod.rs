//! Apગલાબંધ ફાળવેલ સમાવિષ્ટો સાથેનો એક સુસંગત વૃદ્ધિ પામનાર એરે પ્રકાર, `Vec<T>` લેખિત.
//!
//! ઝેડ 0 વેક્ટર 0 ઝેડમાં `O(1)` ઇન્ડેક્સીંગ, એક્સorરિટાઇઝ્ડ `O(1)` પુશ (અંત સુધી) અને `O(1)` પ popપ (છેડેથી) છે.
//!
//!
//! ઝેડ 0 વેક્ટર 0 ઝેડ ખાતરી કરે છે કે તેઓ ક્યારેય પણ `isize::MAX` બાઇટ્સ કરતા વધારે ફાળવતા નથી.
//!
//! # Examples
//!
//! તમે સ્પષ્ટપણે [`Vec::new`] સાથે [`Vec`] બનાવી શકો છો:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... અથવા [`vec!`] મેક્રોનો ઉપયોગ કરીને:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // દસ શૂન્ય
//! ```
//!
//! તમે ઝેડવેક્ટર 0 ઝેડ (જે vector જરૂરિયાત મુજબ વધશે) ના અંતમાં [`push`] મૂલ્યો કરી શકો છો:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! પોપિંગ કિંમતો એ જ રીતે કાર્ય કરે છે:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! ઝેડ 0 વેક્ટર 0 ઝેડ અનુક્રમણિકાને પણ સપોર્ટ કરે છે ([`Index`] અને [`IndexMut`] traits દ્વારા):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` અને ઉચ્ચારણ 'vector' તરીકે લખાયેલ એક સુસંગત વૃદ્ધિ પામનાર એરે પ્રકાર.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] મેક્રો પ્રારંભિકકરણને વધુ અનુકૂળ બનાવવા માટે પ્રદાન કરવામાં આવ્યું છે:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// તે આપેલ મૂલ્ય સાથે `Vec<T>` ના દરેક તત્વને પ્રારંભ પણ કરી શકે છે.
/// આ અલગ પગલામાં ફાળવણી અને પ્રારંભિક કામગીરી કરતા વધુ કાર્યક્ષમ હોઈ શકે છે, ખાસ કરીને જ્યારે ઝીરોઝના ઝેડ 0 વેક્ટર 0 ઝેડની શરૂઆત કરતી વખતે:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // નીચે આપેલ બરાબર છે, પરંતુ સંભવિત ધીમી છે:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// વધુ માહિતી માટે, જુઓ [Capacity and Reallocation](#capacity-and-reallocation).
///
/// કાર્યક્ષમ સ્ટેક તરીકે `Vec<T>` નો ઉપયોગ કરો:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 છાપે છે
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` પ્રકાર અનુક્રમણિકા દ્વારા મૂલ્યોને .ક્સેસ કરવાની મંજૂરી આપે છે, કારણ કે તે [`Index`] trait લાગુ કરે છે.ઉદાહરણ વધુ સ્પષ્ટ હશે:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // તે '2' પ્રદર્શિત કરશે
/// ```
///
/// તેમ છતાં, સાવચેત રહો: જો તમે કોઈ અનુક્રમણિકાને toક્સેસ કરવાનો પ્રયાસ કરો કે જે `Vec` માં નથી, તો તમારું સ softwareફ્ટવેર panic કરશે!તમે આ કરી શકતા નથી:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// [`get`] અને [`get_mut`] નો ઉપયોગ કરો જો તમે તપાસવા માંગતા હો કે અનુક્રમણિકા `Vec` માં છે કે નહીં.
///
/// # Slicing
///
/// એક `Vec` પરિવર્તનશીલ હોઈ શકે છે.બીજી બાજુ, કાપી નાંખેલ વસ્તુ ફક્ત વાંચવા માટેની .બ્જેક્ટ્સ છે.
/// [slice][prim@slice] મેળવવા માટે, [`&`] નો ઉપયોગ કરો.ઉદાહરણ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... અને તે બધુ જ છે!
/// // તમે તેને આની જેમ પણ કરી શકો છો:
/// let u: &[usize] = &v;
/// // અથવા આ જેમ:
/// let u: &[_] = &v;
/// ```
///
/// ઝેડ રસ્ટ0 ઝેડમાં, જ્યારે તમે ફક્ત વાંચવાની provideક્સેસ પ્રદાન કરવા માંગતા હો ત્યારે ઝેડવેક્ટર્સ0 ઝેડને બદલે દલીલો તરીકે કાપી નાંખવાનું વધુ સામાન્ય છે.તે જ [`String`] અને [`&str`] માટે જાય છે.
///
/// # ક્ષમતા અને પુનallસ્થાપન
///
/// ઝેડ 0 વેક્ટર 0 ઝેડની ક્ષમતા એ કોઈપણ ઝેડ 0 ફ્યુચર0 ઝેડ તત્વો માટે ફાળવવામાં આવેલી જગ્યાની માત્રા છે જે vector પર ઉમેરવામાં આવશે.આને ઝેડવેક્ટર 0 ઝેડની *લંબાઈ* સાથે મૂંઝવણમાં રાખવી નહીં, જે ઝેડવેક્ટર 0 ઝેડ અંદરના વાસ્તવિક તત્વોની સંખ્યાને નિર્દિષ્ટ કરે છે.
/// જો ઝેડવેક્ટર 0 ઝેડની લંબાઈ તેની ક્ષમતા કરતાં વધી જાય, તો તેની ક્ષમતા આપમેળે વધશે, પરંતુ તેના તત્વો ફરીથી લગાડવાની રહેશે.
///
/// ઉદાહરણ તરીકે, ક્ષમતા 10 અને લંબાઈ 0 સાથેનો ઝેડ 0 વેક્ટર 0 ઝેડ 10 વધુ તત્વો માટેની જગ્યા સાથેનો ખાલી vector હશે.vector પર 10 અથવા ઓછા તત્વોને દબાણ કરવાથી તેની ક્ષમતા બદલાશે નહીં અથવા રીલોકેશન થશે નહીં.
/// જો કે, જો ઝેડવેક્ટર 0 ઝેડની લંબાઈ વધારીને 11 કરવામાં આવે છે, તો તેને ફરીથી ફેરવવું પડશે, જે ધીમું થઈ શકે છે.આ કારણોસર, ઝેડવેક્ટર 0 ઝેડ જેટલું મોટું થવાની અપેક્ષા છે તે નિર્દિષ્ટ કરવા માટે જ્યારે પણ શક્ય હોય ત્યારે [`Vec::with_capacity`] નો ઉપયોગ કરવાની ભલામણ કરવામાં આવે છે.
///
/// # Guarantees
///
/// તેના અતિ મૂળભૂત સ્વભાવને લીધે, `Vec` તેની ડિઝાઇન વિશે ઘણી બાંયધરી આપે છે.આ સુનિશ્ચિત કરે છે કે સામાન્ય કિસ્સામાં તે શક્ય તેટલું ઓછું-ઓવરહેડ છે, અને અસુરક્ષિત કોડ દ્વારા આદિમ રીતે યોગ્ય રીતે ચાલાકી કરી શકાય છે.નોંધ લો કે આ ગેરંટીઝ એ અયોગ્ય `Vec<T>` નો સંદર્ભ લો.
/// જો વધારાના પ્રકારનાં પરિમાણો ઉમેરવામાં આવે (દા.ત., કસ્ટમ ફાળવણીકારોને ટેકો આપવા માટે), તો તેમના ડિફોલ્ટને ઓવરરાઇડ કરવાથી વર્તણૂક બદલાઈ શકે છે.
///
/// મૂળભૂત રીતે, `Vec` એ છે અને હંમેશાં (નિર્દેશક, ક્ષમતા, લંબાઈ) ત્રિપુટી હશે.વધુ નહીં, ઓછું નહીં.આ ક્ષેત્રોનો ક્રમ સંપૂર્ણપણે અનિશ્ચિત છે, અને તમારે આને સુધારવા માટે યોગ્ય પદ્ધતિઓનો ઉપયોગ કરવો જોઈએ.
/// નિર્દેશક ક્યારેય રદ થશે નહીં, તેથી આ પ્રકાર નલ-પોઇંટર-optimપ્ટિમાઇઝ છે.
///
/// જો કે, નિર્દેશક ખરેખર ફાળવેલ મેમરી તરફ નિર્દેશ કરી શકશે નહીં.
/// ખાસ કરીને, જો તમે [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], અથવા ખાલી Vec પર [`shrink_to_fit`] પર ક 0લ કરીને 0 ક્ષમતાવાળા `Vec` બનાવો છો, તો તે મેમરીને ફાળવશે નહીં.એ જ રીતે, જો તમે `Vec` ની અંદર શૂન્ય કદના પ્રકારો સંગ્રહિત કરો છો, તો તે તેમના માટે જગ્યા ફાળવશે નહીં.
/// *નોંધ લો કે આ કિસ્સામાં `Vec` 0* ના [`capacity`] ની જાણ કરી શકશે નહીં.
/// `Vec` ફાળવણી કરશે જો અને ફક્ત [`મેમ: : કદ_મા::::<T>`]`() * capacity()> 0`.
/// સામાન્ય રીતે, `વેકની ફાળવણીની વિગતો ખૂબ જ સૂક્ષ્મ છે-જો તમે `Vec` નો ઉપયોગ કરીને મેમરી ફાળવવાનો અને કોઈ બીજા માટે ઉપયોગ કરવાનો ઇરાદો રાખતા હો (તો અસુરક્ષિત કોડને પાસ કરવા માટે, અથવા તમારા પોતાના મેમરી-બેક્ડ સંગ્રહને બનાવવા માટે), ખાતરી કરો `Vec` ને પુનર્પ્રાપ્ત કરવા માટે અને પછી તેને છોડીને `from_raw_parts` નો ઉપયોગ કરીને આ મેમરીને ડિએલોડેક્ટ કરવા માટે.
///
/// જો કોઈ `Vec`*એ* ફાળવેલ મેમરી હોય, તો તે જે ઇશારે નિર્દેશ કરે છે તે theગલા પર છે (ફાળવણીકાર Rust દ્વારા નિર્ધારિત મૂળભૂત રીતે વાપરવા માટે રૂપરેખાંકિત થયેલ છે), અને તેના નિર્દેશક [`len`] પ્રારંભ કરેલા, ઘટ્ટ તત્વોને ક્રમમાં નિર્દેશ કરે છે (તમે શું કરો છો જુઓ કે તમે તેને એક કટકા પર જબરદસ્તી કર્યું છે), [`ક્ષમતા`]`,`[` લેની] પછી તાર્કિક રૂપે અનિશ્ચિત, સંલગ્ન તત્વો.
///
///
/// ક્ષમતા સાથે 4 `'a'` અને `'b'` તત્વો ધરાવતા ઝેડ 0 વેક્ટર 0 ઝેડ નીચે મુજબ વિઝ્યુઅલાઈઝ કરી શકાય છે.ટોચનો ભાગ એ `Vec` સ્ટ્રક્ટ છે, તેમાં ,ગલો, લંબાઈ અને ક્ષમતામાં ફાળવણીના વડાનો નિર્દેશક છે.
/// તળિયાનો ભાગ એ apગલા પર ફાળવણી છે, એક સતત મેમરી બ્લ .ક.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **અનઇનિટ** એ મેમરીનું પ્રતિનિધિત્વ કરે છે જે પ્રારંભ નથી, [`MaybeUninit`] જુઓ.
/// - Note: એબીઆઇ સ્થિર નથી અને `Vec` તેના મેમરી લેઆઉટ (ક્ષેત્રોના ક્રમ સહિત) વિશે કોઈ બાંહેધરી આપતું નથી.
///
/// `Vec` "small optimization" ક્યારેય કરશે નહીં જ્યાં બે કારણોસર તત્વો ખરેખર સ્ટેક પર સ્ટોર કરવામાં આવે છે:
///
/// * અસુરક્ષિત કોડને `Vec` માં યોગ્ય રીતે ચાલાકી કરવી તે વધુ મુશ્કેલ બનાવશે.જો તે ફક્ત ખસેડવામાં આવે તો `Vec` ની સામગ્રીમાં સ્થિર સરનામું હોત નહીં, અને `Vec` ખરેખર મેમરી ફાળવેલ છે કે કેમ તે નક્કી કરવું વધુ મુશ્કેલ હશે.
///
/// * તે દરેક caseક્સેસ પર વધારાના ઝેડબ્રાન્ચ0 ઝેડ સહિતના સામાન્ય કેસમાં દંડ કરશે.
///
/// `Vec` સંપૂર્ણ ખાલી હોવા છતાંય, આપમેળે ક્યારેય સંકોચો નહીં.આ સુનિશ્ચિત કરે છે કે કોઈ બિનજરૂરી ફાળવણી અથવા અધોગતિ થાય નહીં.એક `Vec` ખાલી કરીને અને પછી તે જ [`len`] સુધી પાછા ભરીને ફાળવણીકારને કોઈ ક callsલ ન આવે.જો તમે ન વપરાયેલી મેમરીને મુક્ત કરવા માંગો છો, તો [`shrink_to_fit`] અથવા [`shrink_to`] નો ઉપયોગ કરો.
///
/// [`push`] અને જો અહેવાલની ક્ષમતા પૂરતી છે તો [`insert`] ક્યારેય (ફરીથી) ફાળવશે નહીં.[`push`] અને [`insert`]*ફાળવણી કરશે*(ફરીથી) જો [`લેની]`==`[` ક્ષમતા`].તે છે, અહેવાલ ક્ષમતા સંપૂર્ણપણે સચોટ છે, અને તેના પર આધાર રાખી શકાય છે.તેનો ઇચ્છા હોય તો `Vec` દ્વારા ફાળવેલ મેમરી મેન્યુઅલી મુક્ત કરવા માટે પણ થઈ શકે છે.
/// જથ્થાબંધ શામેલ કરવાની પદ્ધતિઓ * જ્યારે ફરીથી જરૂરી હોય તો પણ તે ફરીથી કાocateી શકે છે.
///
/// `Vec` જ્યારે પૂર્ણ થાય ત્યારે ફરીથી સ્થાનાંતરિત કરતી વખતે, અથવા જ્યારે [`reserve`] ક isલ કરવામાં આવે ત્યારે કોઈ વિશેષ વૃદ્ધિ વ્યૂહરચનાની બાંહેધરી આપતી નથી.વર્તમાન વ્યૂહરચના મૂળભૂત છે અને તે અવિરત વૃદ્ધિ પરિબળનો ઉપયોગ કરવા ઇચ્છનીય સાબિત થઈ શકે છે.જે પણ વ્યૂહરચના ઉપયોગમાં લેવાય છે તે અલબત્ત *O*(1) એમorર્ટેડ [`push`] ની ખાતરી આપે છે.
///
/// `vec![x; n]`, `vec![a, b, c, d]` અને [`Vec::with_capacity(n)`][`Vec::with_capacity`], બધા વિનંતી કરેલી ક્ષમતા સાથે એક `Vec` ઉત્પન્ન કરશે.
/// જો [`લેન`]`==`[`ક્ષમતા`], (જેમ કે [`vec!`] મ maક્રોની જેમ), તો પછી એક `Vec<T>` તત્વોને ફરીથી ગોઠવવા અથવા ખસેડ્યા વિના, [`Box<[T]>`][owned slice] માં રૂપાંતરિત કરી શકાય છે.
///
/// `Vec` તેમાંથી દૂર કરવામાં આવેલા કોઈપણ ડેટાને ખાસ કરીને ફરીથી લખી શકશે નહીં, પરંતુ તે વિશેષ રૂપે સાચવશે નહીં.તેની અનઇંટિઆલાઇઝ્ડ મેમરી એ સ્ક્રેચ સ્પેસ છે જે તે ઇચ્છે તે ઉપયોગ કરી શકે છે.તે સામાન્ય રીતે ફક્ત જે પણ કાર્યક્ષમ અથવા અમલ કરવા માટે અન્યથા સરળ હોય તે કરશે.સુરક્ષા હેતુઓ માટે ભૂંસી નાખવામાં આવતા ડેટા પર ભરોસો ન કરો.
/// જો તમે `Vec` છોડો છો, તો પણ તેના બફરનો ઉપયોગ ફક્ત બીજા `Vec` દ્વારા ફરીથી થઈ શકે છે.
/// જો તમે પ્રથમ `વેકની મેમરીને શૂન્ય કરો છો, તો પણ તે ખરેખર બનશે નહીં કારણ કે izerપ્ટિમાઇઝર આને કોઈ આડઅસર માનતો નથી જે સાચવવું આવશ્યક છે.
/// ત્યાં એક કેસ છે જે આપણે તોડીશું નહીં, જો કે: વધારે ક્ષમતા પર લખવા માટે `unsafe` કોડનો ઉપયોગ કરવો, અને પછી મેચ કરવાની લંબાઈ વધારવી હંમેશા માન્ય છે.
///
/// હાલમાં, `Vec` એ ઓર્ડરની બાંયધરી આપતું નથી જેમાં તત્વોને છોડવામાં આવે છે.
/// હુકમ ભૂતકાળમાં બદલાઈ ગયો છે અને ફરીથી બદલાઈ શકે છે.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// સહજ પદ્ધતિઓ
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// એક નવું, ખાલી `Vec<T>` બનાવે છે.
    ///
    /// vector જ્યાં સુધી તત્વો તેના પર દબાણ ન કરે ત્યાં સુધી ફાળવણી કરશે નહીં.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// ઉલ્લેખિત ક્ષમતા સાથે એક નવું, ખાલી `Vec<T>` બનાવે છે.
    ///
    /// ઝેડવેક્ટર 0 ઝેડ રીલોકેટિંગ કર્યા વિના બરાબર `capacity` તત્વોને પકડવામાં સમર્થ હશે.
    /// જો `capacity` 0 છે, તો vector ફાળવણી કરશે નહીં.
    ///
    /// એ નોંધવું અગત્યનું છે કે પરત vector માં *ક્ષમતા* ઉલ્લેખિત છે, vector ની શૂન્ય *લંબાઈ* હશે.
    ///
    /// લંબાઈ અને ક્ષમતા વચ્ચેના તફાવતની સમજણ માટે,*[ક્ષમતા અને પુનallસ્થાપન]* જુઓ.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // ઝેડવેક્ટર 0 ઝેડમાં કોઈ આઇટમ્સ શામેલ નથી, તેમ છતાં તેમાં વધુ ક્ષમતા છે
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // આ બધું ફરીથી રજૂ કર્યા વિના કરવામાં આવે છે ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... પરંતુ આ ઝેડવેક્ટર 0 ઝેડને ફરીથી ફેરવી શકે છે
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// બીજા vector ના કાચા ઘટકોમાંથી સીધા જ એક `Vec<T>` બનાવે છે.
    ///
    /// # Safety
    ///
    /// આ તપાસ કરવામાં ન આવે તેવા આક્રમણકારોની સંખ્યાને લીધે, તે ખૂબ જ અસુરક્ષિત છે:
    ///
    /// * `ptr` અગાઉ [`શબ્દમાળા]/` વીઈસી દ્વારા ફાળવણી કરવાની જરૂર છે<T>. (ઓછામાં ઓછું, જો તે ન હોત તો તે અયોગ્ય હોવાની સંભાવના છે).
    /// * `T` `ptr` જેટલું ફાળવવામાં આવ્યું હતું તે જ કદ અને ગોઠવણીની જરૂર છે.
    ///   (`T` ઓછા કડક ગોઠવણી પર્યાપ્ત નથી, સંરેખણ એ [`dealloc`] ની આવશ્યકતાને સંતોષવા માટે ખરેખર સમાન હોવું જરૂરી છે કે મેમરીને તે જ લેઆઉટ સાથે ફાળવવી અને ડિલocક્ટેશન કરવું આવશ્યક છે.)
    ///
    /// * `length` `capacity` કરતા ઓછું અથવા સમાન હોવું જરૂરી છે.
    /// * `capacity` તે ક્ષમતા હોવી જરૂરી છે કે જેનો નિર્દેશક સાથે ફાળવવામાં આવ્યો હતો.
    ///
    /// આનું ઉલ્લંઘન એ ફાળવણીકારના આંતરિક ડેટા સ્ટ્રક્ચર્સને ભ્રષ્ટ કરવા જેવી સમસ્યાઓનું કારણ બની શકે છે.ઉદાહરણ તરીકે, તે **નથી** લંબાઈ `size_t` સાથે પોઇન્ટરથી સી `char` એરેમાં `Vec<u8>` બનાવવાનું સલામત છે.
    /// `Vec<u16>` અને તેની લંબાઈમાંથી એક બનાવવું પણ સલામત નથી, કારણ કે ફાળવણીકાર ગોઠવણીની સંભાળ રાખે છે, અને આ બે પ્રકારો જુદા જુદા ગોઠવણી ધરાવે છે.
    /// બફર ગોઠવણી 2 (`u16` માટે) સાથે ફાળવવામાં આવી હતી, પરંતુ તેને `Vec<u8>` માં ફેરવ્યા પછી તે સંરેખણ 1 સાથે અવક્ષયમાં આવશે.
    ///
    /// `ptr` ની માલિકી `Vec<T>` ને અસરકારક રીતે સ્થાનાંતરિત કરવામાં આવી છે જે પછી ઇચ્છા પર પોઇન્ટર દ્વારા નિર્દેશિત મેમરીની સામગ્રીને વિકૃત, ફરીથી વિકસિત કરી શકે છે અથવા બદલી શકે છે.
    /// ખાતરી કરો કે આ કાર્યને બોલાવ્યા પછી બીજું કંઇ પોઇન્ટરનો ઉપયોગ કરશે નહીં.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // જ્યારે vec_into_raw_parts સ્થિર થાય છે ત્યારે તેને ફિક્સ કરો.
    ///     // Running v` ના ડિસ્ટ્રક્ટરને ચલાવવાનું રોકો જેથી અમે ફાળવણીના સંપૂર્ણ નિયંત્રણમાં હોઈએ.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` વિશેની માહિતીના વિવિધ મહત્વપૂર્ણ ટુકડાઓ બહાર કા .ો
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6 સાથે મેમરીને ઓવરરાઇટ કરો
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // બધું પાછા એક વી.ઈ.સી. માં મૂકી દો
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// એક નવું, ખાલી `Vec<T, A>` બનાવે છે.
    ///
    /// vector જ્યાં સુધી તત્વો તેના પર દબાણ ન કરે ત્યાં સુધી ફાળવણી કરશે નહીં.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// પ્રદાન કરેલ ફાળવણીકાર સાથે નિર્દિષ્ટ ક્ષમતા સાથે એક નવું, ખાલી `Vec<T, A>` બનાવે છે.
    ///
    /// ઝેડવેક્ટર 0 ઝેડ રીલોકેટિંગ કર્યા વિના બરાબર `capacity` તત્વોને પકડવામાં સમર્થ હશે.
    /// જો `capacity` 0 છે, તો vector ફાળવણી કરશે નહીં.
    ///
    /// એ નોંધવું અગત્યનું છે કે પરત vector માં *ક્ષમતા* ઉલ્લેખિત છે, vector ની શૂન્ય *લંબાઈ* હશે.
    ///
    /// લંબાઈ અને ક્ષમતા વચ્ચેના તફાવતની સમજણ માટે,*[ક્ષમતા અને પુનallસ્થાપન]* જુઓ.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // ઝેડવેક્ટર 0 ઝેડમાં કોઈ આઇટમ્સ શામેલ નથી, તેમ છતાં તેમાં વધુ ક્ષમતા છે
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // આ બધું ફરીથી રજૂ કર્યા વિના કરવામાં આવે છે ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... પરંતુ આ ઝેડવેક્ટર 0 ઝેડને ફરીથી ફેરવી શકે છે
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// બીજા vector ના કાચા ઘટકોમાંથી સીધા જ એક `Vec<T, A>` બનાવે છે.
    ///
    /// # Safety
    ///
    /// આ તપાસ કરવામાં ન આવે તેવા આક્રમણકારોની સંખ્યાને લીધે, તે ખૂબ જ અસુરક્ષિત છે:
    ///
    /// * `ptr` અગાઉ [`શબ્દમાળા]/` વીઈસી દ્વારા ફાળવણી કરવાની જરૂર છે<T>. (ઓછામાં ઓછું, જો તે ન હોત તો તે અયોગ્ય હોવાની સંભાવના છે).
    /// * `T` `ptr` જેટલું ફાળવવામાં આવ્યું હતું તે જ કદ અને ગોઠવણીની જરૂર છે.
    ///   (`T` ઓછા કડક ગોઠવણી પર્યાપ્ત નથી, સંરેખણ એ [`dealloc`] ની આવશ્યકતાને સંતોષવા માટે ખરેખર સમાન હોવું જરૂરી છે કે મેમરીને તે જ લેઆઉટ સાથે ફાળવવી અને ડિલocક્ટેશન કરવું આવશ્યક છે.)
    ///
    /// * `length` `capacity` કરતા ઓછું અથવા સમાન હોવું જરૂરી છે.
    /// * `capacity` તે ક્ષમતા હોવી જરૂરી છે કે જેનો નિર્દેશક સાથે ફાળવવામાં આવ્યો હતો.
    ///
    /// આનું ઉલ્લંઘન એ ફાળવણીકારના આંતરિક ડેટા સ્ટ્રક્ચર્સને ભ્રષ્ટ કરવા જેવી સમસ્યાઓનું કારણ બની શકે છે.ઉદાહરણ તરીકે, તે **નથી** લંબાઈ `size_t` સાથે પોઇન્ટરથી સી `char` એરેમાં `Vec<u8>` બનાવવાનું સલામત છે.
    /// `Vec<u16>` અને તેની લંબાઈમાંથી એક બનાવવું પણ સલામત નથી, કારણ કે ફાળવણીકાર ગોઠવણીની સંભાળ રાખે છે, અને આ બે પ્રકારો જુદા જુદા ગોઠવણી ધરાવે છે.
    /// બફર ગોઠવણી 2 (`u16` માટે) સાથે ફાળવવામાં આવી હતી, પરંતુ તેને `Vec<u8>` માં ફેરવ્યા પછી તે સંરેખણ 1 સાથે અવક્ષયમાં આવશે.
    ///
    /// `ptr` ની માલિકી `Vec<T>` ને અસરકારક રીતે સ્થાનાંતરિત કરવામાં આવી છે જે પછી ઇચ્છા પર પોઇન્ટર દ્વારા નિર્દેશિત મેમરીની સામગ્રીને વિકૃત, ફરીથી વિકસિત કરી શકે છે અથવા બદલી શકે છે.
    /// ખાતરી કરો કે આ કાર્યને બોલાવ્યા પછી બીજું કંઇ પોઇન્ટરનો ઉપયોગ કરશે નહીં.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // જ્યારે vec_into_raw_parts સ્થિર થાય છે ત્યારે તેને ફિક્સ કરો.
    ///     // Running v` ના ડિસ્ટ્રક્ટરને ચલાવવાનું રોકો જેથી અમે ફાળવણીના સંપૂર્ણ નિયંત્રણમાં હોઈએ.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` વિશેની માહિતીના વિવિધ મહત્વપૂર્ણ ટુકડાઓ બહાર કા .ો
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6 સાથે મેમરીને ઓવરરાઇટ કરો
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // બધું પાછા એક વી.ઈ.સી. માં મૂકી દો
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// એક `Vec<T>` તેના કાચા ઘટકોને વિઘટિત કરે છે.
    ///
    /// અંતર્ગત ડેટા, vector ની લંબાઈ (તત્વોમાં) અને ડેટાની ફાળવેલ ક્ષમતા (તત્વોમાં) માં કાચા નિર્દેશક પાછા ફરે છે.
    /// આ તે જ ક્રમમાં સમાન દલીલો છે જે [`from_raw_parts`] ની દલીલો છે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કlerલર એ `Vec` દ્વારા અગાઉ સંચાલિત મેમરી માટે જવાબદાર છે.
    /// આ કરવાનો એકમાત્ર રસ્તો કાચા પોઇન્ટર, લંબાઈ અને ક્ષમતાને [`from_raw_parts`] ફંક્શન સાથે પાછા `Vec` માં રૂપાંતરિત કરવાનો છે, ડિસ્ટ્રક્ટરને ક્લિનઅપ કરવા દે છે.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // હવે અમે ઘટકોમાં ફેરફાર કરી શકીએ છીએ, જેમ કે કાચા પોઇન્ટરને સુસંગત પ્રકારમાં સ્થાનાંતરિત કરવું.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// એક `Vec<T>` તેના કાચા ઘટકોને વિઘટિત કરે છે.
    ///
    /// અંતર્ગત ડેટા, vector ની લંબાઈ (તત્વોમાં), ડેટાની ફાળવેલ ક્ષમતા (તત્વોમાં) અને ફાળવણીકારને કાચા પોઇન્ટર આપે છે.
    /// આ તે જ ક્રમમાં સમાન દલીલો છે જે [`from_raw_parts_in`] ની દલીલો છે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કlerલર એ `Vec` દ્વારા અગાઉ સંચાલિત મેમરી માટે જવાબદાર છે.
    /// આ કરવાનો એકમાત્ર રસ્તો કાચા પોઇન્ટર, લંબાઈ અને ક્ષમતાને [`from_raw_parts_in`] ફંક્શન સાથે પાછા `Vec` માં રૂપાંતરિત કરવાનો છે, ડિસ્ટ્રક્ટરને ક્લિનઅપ કરવા દે છે.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // હવે અમે ઘટકોમાં ફેરફાર કરી શકીએ છીએ, જેમ કે કાચા પોઇન્ટરને સુસંગત પ્રકારમાં સ્થાનાંતરિત કરવું.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// ઝેડવેક્ટર 0 ઝેડને ફરીથી રજૂ કર્યા વિના પકડી શકે તેવા તત્વોની સંખ્યા પરત કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// આપેલ `Vec<T>` માં ઓછામાં ઓછા `additional` વધુ તત્વો શામેલ કરવાની ક્ષમતા અનામત છે.
    /// સંગ્રહમાં વારંવાર ફેરબદલ ટાળવા માટે સંગ્રહ વધુ જગ્યા અનામત રાખી શકે છે.
    /// `reserve` ને ક callingલ કર્યા પછી, ક્ષમતા `self.len() + additional` કરતા વધારે અથવા તેની બરાબર હશે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// # Panics
    ///
    /// Panics જો નવી ક્ષમતા `isize::MAX` બાઇટ્સથી વધુ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// આપેલ `Vec<T>` માં બરાબર `additional` વધુ તત્વો શામેલ કરવાની ન્યૂનતમ ક્ષમતા અનામત રાખે છે.
    ///
    /// `reserve_exact` ને ક callingલ કર્યા પછી, ક્ષમતા `self.len() + additional` કરતા વધારે અથવા તેની બરાબર હશે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// નોંધ કરો કે ફાળવણીકાર વિનંતી કરતા સંગ્રહને વધુ જગ્યા આપી શકે છે.
    /// તેથી, ક્ષમતા ચોક્કસપણે ન્યૂનતમ હોવા પર વિશ્વાસ કરી શકાતી નથી.
    /// જો ઝેડ ફ્યુચર0 ઝેડ નિવેશની અપેક્ષા હોય તો `reserve` ને પ્રાધાન્ય આપો.
    ///
    /// # Panics
    ///
    /// જો નવી ક્ષમતા `usize` ઓવરફ્લો થાય તો ઝેડ પanનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// આપેલ `Vec<T>` માં ઓછામાં ઓછા `additional` વધુ તત્વો શામેલ કરવાની ક્ષમતા અનામત રાખવાનો પ્રયાસ કરે છે.
    /// સંગ્રહમાં વારંવાર ફેરબદલ ટાળવા માટે સંગ્રહ વધુ જગ્યા અનામત રાખી શકે છે.
    /// `try_reserve` ને ક callingલ કર્યા પછી, ક્ષમતા `self.len() + additional` કરતા વધારે અથવા તેની બરાબર હશે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// # Errors
    ///
    /// જો ક્ષમતા ઓવરફ્લો થાય છે, અથવા ફાળવણીકાર નિષ્ફળતાની જાણ કરે છે, તો પછી ભૂલ પાછો આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // મેમરીનું પૂર્વ-અનામત, જો આપણે ન કરી શકીએ તો બહાર નીકળી રહ્યું છે
    ///     output.try_reserve(data.len())?;
    ///
    ///     // હવે આપણે જાણીએ છીએ કે આ અમારા જટિલ કાર્યની મધ્યમાં OOM ન કરી શકે
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ખૂબ જટિલ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// આપેલ `Vec<T>` માં બરાબર `additional` તત્વો શામેલ કરવા માટે લઘુત્તમ ક્ષમતા અનામત રાખવાનો પ્રયાસ કરે છે.
    /// `try_reserve_exact` ને ક callingલ કર્યા પછી, જો તે `Ok(())` પરત કરે છે, તો ક્ષમતા `self.len() + additional` કરતા વધારે અથવા બરાબર હશે.
    ///
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// નોંધ કરો કે ફાળવણીકાર વિનંતી કરતા સંગ્રહને વધુ જગ્યા આપી શકે છે.
    /// તેથી, ક્ષમતા ચોક્કસપણે ન્યૂનતમ હોવા પર વિશ્વાસ કરી શકાતી નથી.
    /// જો ઝેડ ફ્યુચર0 ઝેડ નિવેશની અપેક્ષા હોય તો `reserve` ને પ્રાધાન્ય આપો.
    ///
    /// # Errors
    ///
    /// જો ક્ષમતા ઓવરફ્લો થાય છે, અથવા ફાળવણીકાર નિષ્ફળતાની જાણ કરે છે, તો પછી ભૂલ પાછો આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // મેમરીનું પૂર્વ-અનામત, જો આપણે ન કરી શકીએ તો બહાર નીકળી રહ્યું છે
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // હવે આપણે જાણીએ છીએ કે આ અમારા જટિલ કાર્યની મધ્યમાં OOM ન કરી શકે
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ખૂબ જટિલ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// શક્ય તેટલું vector ની ક્ષમતાને સંકોચો.
    ///
    /// તે લંબાઈની શક્ય તેટલી નજીક નીચે જશે પરંતુ ફાળવણીકાર હજી પણ vector ને જાણ કરી શકે છે કે થોડા વધુ તત્વો માટે જગ્યા છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ક્ષમતા ક્યારેય લંબાઈ કરતા ઓછી હોતી નથી, અને જ્યારે તે બરાબર હોય ત્યારે કરવાનું કંઈ નથી, તેથી અમે તેને `RawVec::shrink_to_fit` માં panic કેસ ટાળી શકીએ, ફક્ત તેને વધારે ક્ષમતા સાથે બોલાવીને.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// નીચલા બાઉન્ડ સાથે vector ની ક્ષમતાને સંકોચો.
    ///
    /// ક્ષમતા ઓછામાં ઓછી લંબાઈ અને સપ્લાય કરેલ મૂલ્ય બંને જેટલી મોટી રહેશે.
    ///
    ///
    /// જો વર્તમાન ક્ષમતા નીચલી મર્યાદા કરતા ઓછી હોય, તો આ નો-opપ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector ને [`Box<[T]>`][owned slice] માં ફેરવે છે.
    ///
    /// નોંધ લો કે આ કોઈપણ વધારાની ક્ષમતાને છોડી દેશે.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// કોઈપણ વધારાની ક્ષમતા દૂર કરવામાં આવે છે:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// પ્રથમ `len` તત્વો રાખીને અને બાકીના છોડીને, ઝેડવેક્ટર 0 ઝેડને ટૂંકી કરો.
    ///
    /// જો `len` એ vector ની વર્તમાન લંબાઈ કરતા વધારે છે, તો આની કોઈ અસર નથી.
    ///
    /// [`drain`] પદ્ધતિ `truncate` નું અનુકરણ કરી શકે છે, પરંતુ વધારે તત્વોને ઘટાડવાની જગ્યાએ પરત લાવવાનું કારણ બને છે.
    ///
    ///
    /// નોંધો કે આ પદ્ધતિ vector ની ફાળવેલ ક્ષમતા પર કોઈ અસર કરી શકશે નહીં.
    ///
    /// # Examples
    ///
    /// બે તત્વોમાં પાંચ તત્વ vector કાપવા:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// જ્યારે `len` એ vector ની વર્તમાન લંબાઈ કરતા વધારે હોય ત્યારે કોઈ કાપવામાં આવતી નથી:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// જ્યારે `len == 0` એ [`clear`] પદ્ધતિને ક callingલ કરવા માટે સમકક્ષ હોય ત્યારે કાપવું.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // આ સલામત છે કારણ કે:
        //
        // * `drop_in_place` પરની સ્લાઇસ માન્ય છે;`len > self.len` કેસ અમાન્ય સ્લાઇસ બનાવવાનું ટાળે છે, અને
        // * ઝેડવેક્ટર 0 ઝેડનું X01 એક્સ, `drop_in_place` પર ક callingલ કરતા પહેલા સંકોચો છે, જેમ કે `drop_in_place` એકવાર panic પર હતો ત્યારે કોઈ મૂલ્ય બે વાર નહીં મૂકવામાં આવે (જો તે panics બે વાર થાય, તો કાર્યક્રમ બાકી છે).
        //
        //
        //
        unsafe {
            // Note: તે હેતુપૂર્વક છે કે આ `>` છે અને `>=` નથી.
            //       તેને `>=` માં બદલવાનું કેટલાક કેસોમાં નકારાત્મક પ્રભાવની અસરો ધરાવે છે.
            //       વધુ માટે #78884 જુઓ.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// સમગ્ર vector ધરાવતી સ્લાઇસ કાractsે છે.
    ///
    /// `&s[..]` ની સમકક્ષ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// સમગ્ર vector ની પરિવર્તનશીલ સ્લાઇસ કાractsે છે.
    ///
    /// `&mut s[..]` ની સમકક્ષ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector ના બફર પર કાચો પોઇન્ટર આપે છે.
    ///
    /// ક calલરે ખાતરી કરવી આવશ્યક છે કે ઝેડવેક્ટર 0 ઝેડ પોઇન્ટરને આઉટલિવ કરે છે જે આ ફંક્શન પાછું આપે છે, નહીં તો તે કચરા તરફ નિર્દેશ કરે છે.
    /// vector માં ફેરફાર કરવાથી તેના બફરને ફરીથી સ્થાનાંતરિત કરી શકાય છે, જે તેના માટેના કોઈપણ નિર્દેશકોને પણ અમાન્ય બનાવે છે.
    ///
    /// કlerલરે એ પણ સુનિશ્ચિત કરવું આવશ્યક છે કે જે નિર્દેશક (non-transitively) નિર્દેશ કરે છે તે આ નિર્દેશક અથવા તેનાથી પ્રાપ્ત કોઈપણ પોઇન્ટરનો ઉપયોગ કરીને (`UnsafeCell` ની અંદર સિવાય) ક્યારેય લખાયેલ નથી.
    /// જો તમારે સ્લાઈસની સામગ્રીને પરિવર્તિત કરવાની જરૂર હોય, તો [`as_mut_ptr`] નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // અમે `deref` પર જવાથી બચવા માટે સમાન નામની સ્લાઈસ પદ્ધતિને પડછાયા કરીએ છીએ, જે મધ્યવર્તી સંદર્ભ બનાવે છે.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector ના બફર પર અસુરક્ષિત પરિવર્તનીય પોઇન્ટર પાછું આપે છે.
    ///
    /// ક calલરે ખાતરી કરવી આવશ્યક છે કે ઝેડવેક્ટર 0 ઝેડ પોઇન્ટરને આઉટલિવ કરે છે જે આ ફંક્શન પાછું આપે છે, નહીં તો તે કચરા તરફ નિર્દેશ કરે છે.
    ///
    /// vector માં ફેરફાર કરવાથી તેના બફરને ફરીથી સ્થાનાંતરિત કરી શકાય છે, જે તેના માટેના કોઈપણ નિર્દેશકોને પણ અમાન્ય બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 તત્વો માટે પૂરતા મોટા vector ફાળવો.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // કાચા પોઇન્ટર લખો દ્વારા તત્વો પ્રારંભ કરો, પછી લંબાઈ સેટ કરો.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // અમે `deref_mut` પર જવાથી બચવા માટે સમાન નામની સ્લાઈસ પદ્ધતિને પડછાયા કરીએ છીએ, જે મધ્યવર્તી સંદર્ભ બનાવે છે.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// અંતર્ગત ફાળવણીકારનો સંદર્ભ આપે છે.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector ની લંબાઈને `new_len` પર દબાણ કરે છે.
    ///
    /// આ એક નિમ્ન-સ્તરનું operationપરેશન છે જે પ્રકારનાં સામાન્ય આક્રમણોમાંથી કોઈને જાળવતું નથી.
    /// સામાન્ય રીતે vector ની લંબાઈ બદલવી એ [`truncate`], [`resize`], [`extend`] અથવા [`clear`] જેવા સલામત ofપરેશનનો ઉપયોગ કરીને કરવામાં આવે છે.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] કરતા ઓછું અથવા બરાબર હોવું જોઈએ.
    /// - `old_len..new_len` પરના તત્વો પ્રારંભ થવાના હોવા જોઈએ.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// આ પદ્ધતિ પરિસ્થિતિઓમાં ઉપયોગી થઈ શકે છે જેમાં vector અન્ય કોડ માટે બફર તરીકે સેવા આપી રહી છે, ખાસ કરીને FFI પર:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // ડ docક ઉદાહરણ માટે આ માત્ર એક ન્યુનતમ હાડપિંજર છે;
    /// # // વાસ્તવિક લાઇબ્રેરી માટે પ્રારંભિક બિંદુ તરીકે તેનો ઉપયોગ કરશો નહીં.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // એફએફઆઈ પદ્ધતિના દસ્તાવેજો મુજબ, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // સલામતી: જ્યારે `deflateGetDictionary` `Z_OK` આપે છે, ત્યારે તે ધરાવે છે:
    ///     // 1. `dict_length` તત્વો પ્રારંભ કરવામાં આવ્યા હતા.
    ///     // 2.
    ///     // `dict_length` <=ક્ષમતા (32_768) જે `set_len` ને ક toલ કરવા માટે સલામત બનાવે છે.
    ///     unsafe {
    ///         // FFI કIલ કરો ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... અને જે પ્રારંભ કરવામાં આવી હતી તેની લંબાઈને અપડેટ કરો.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// જ્યારે નીચેનું ઉદાહરણ ધ્વનિ છે, ત્યાં મેમરી લિક છે કારણ કે `set_len` કveલ પહેલાં આંતરિક ઝેડવેક્ટર્સ 0 ઝેડને મુક્ત કરાઈ ન હતી:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ખાલી છે તેથી કોઈ ઘટકોને પ્રારંભ કરવાની જરૂર નથી.
    /// // 2. `0 <= capacity` હંમેશા `capacity` જે પણ હોય તે ધરાવે છે.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// સામાન્ય રીતે, અહીં, એક યોગ્ય રીતે સમાવિષ્ટોને છોડવા માટે [`clear`] નો ઉપયોગ કરશે અને આમ મેમરીને લીક નહીં કરે.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector માંથી એક તત્વ દૂર કરે છે અને તેને પાછું આપે છે.
    ///
    /// દૂર કરેલું તત્વ vector ના છેલ્લા તત્વ દ્વારા બદલવામાં આવ્યું છે.
    ///
    /// આ orderર્ડરિંગને સાચવતું નથી, પરંતુ તે O(1) છે.
    ///
    /// # Panics
    ///
    /// જો ઝેડ પanનિક્સ 0 ઝેડ જો `index` સીમાની બહાર હોય તો.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // અમે સ્વ [અનુક્રમણિકા] ને છેલ્લા ઘટક સાથે બદલીએ છીએ.
            // નોંધ લો કે જો ઉપરની સીમાઓ તપાસવામાં સફળ થાય છે તો ત્યાં એક છેલ્લું તત્વ હોવું જોઈએ (જે સ્વયં હોઈ શકે છે [અનુક્રમણિકા] પોતે જ).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector ની અંદર `index` પોઝિશન પર એક તત્વ શામેલ કરે છે, તેના પછી બધા ઘટકોને જમણી તરફ સ્થાનાંતરિત કરે છે.
    ///
    ///
    /// # Panics
    ///
    /// ઝેડ 0 પેનિક્સ 0 ઝેડ જો `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // નવા તત્વ માટે જગ્યા
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // નવી કિંમત મૂકવા માટે હાજર
            //
            {
                let p = self.as_mut_ptr().add(index);
                // જગ્યા બનાવવા માટે બધું શિફ્ટ કરો.
                // (`અનુક્રમણિકાના તત્વનું સતત બે સ્થાને નકલ કરી રહ્યું છે.)
                ptr::copy(p, p.offset(1), len - index);
                // `અનુક્રમણિકા તત્વની પ્રથમ ક overwપિને ફરીથી લખીને તેમાં લખો.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector ની અંદર `index` પોઝિશન પરના તત્વને દૂર કરે છે અને પાછું આપે છે, પછી તે બધા તત્વોને ડાબી તરફ સ્થળાંતર કરે છે.
    ///
    ///
    /// # Panics
    ///
    /// જો ઝેડ પanનિક્સ 0 ઝેડ જો `index` સીમાની બહાર હોય તો.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // અમે જે સ્થાન લઈ રહ્યા છીએ.
                let ptr = self.as_mut_ptr().add(index);
                // તેને ક copyપિ કરો, અસુરક્ષિત રીતે સ્ટેક પર અને તે જ સમયે vector માં મૂલ્યની નકલ.
                //
                ret = ptr::read(ptr);

                // તે સ્થળ ભરવા માટે બધું શિફ્ટ કરો.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// પૂર્વજાત દ્વારા નિર્ધારિત ફક્ત તત્વો જ જાળવી રાખે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, બધા તત્વો `e` ને દૂર કરો જેમ કે `f(&e)` `false` આપે છે.
    /// આ પદ્ધતિ તેના સ્થાને કાર્ય કરે છે, દરેક ક્રમમાં મૂળ ક્રમમાં બરાબર એક વખત મુલાકાત લે છે, અને જાળવેલ તત્વોનો ક્રમ સાચવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// કારણ કે તત્વોની મૂળ ક્રમમાં બરાબર એકવાર મુલાકાત લેવામાં આવે છે, તેથી કયા તત્વો રાખવા તે નક્કી કરવા માટે બાહ્ય સ્થિતિનો ઉપયોગ થઈ શકે છે.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // જો ડ્રોપ ગાર્ડ ચલાવવામાં ન આવે તો ડબલ ડ્રોપ ટાળો, કારણ કે અમે પ્રક્રિયા દરમિયાન કેટલાક છિદ્રો બનાવી શકીએ છીએ.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-પ્રોસેસ્ડ લેન-> |^-તપાસ માટે આગળ
        //                  | <-કા deletedી નાખેલ સીન્ટ-> |
        //      | <-ઓરિજનલ_લેન-> |રાખવામાં આવેલ: તત્વો જે પૂર્વાનુમાન કરે છે તે સાચા છે.
        //
        // છિદ્ર: તત્વો સ્લોટ ખસેડ્યો અથવા છોડ્યો.
        // અનચેક કરેલ: અનચેક કરેલ માન્ય તત્વો.
        //
        // આ ડ્રોપ રક્ષક જ્યારે ત્રાસદાયક અથવા `drop` તત્વ ગભરાઈ જાય ત્યારે વિનંતી કરવામાં આવશે.
        // તે છિદ્રોને coverાંકવા માટે અનચેક કરેલા તત્વો અને `set_len` ને યોગ્ય લંબાઈમાં સ્થાનાંતરિત કરે છે.
        // જ્યારે પ્રિડિકેટ અને `drop` ક્યારેય ગભરાતા નથી, ત્યારે તે optimપ્ટિમાઇઝ થશે.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // સલામતી: અનચેક કરેલી આઇટમ્સ પાછળની માન્ય હોવી આવશ્યક છે કારણ કે આપણે તેમને ક્યારેય સ્પર્શતા નથી.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // સલામતી: છિદ્રો ભર્યા પછી, બધી વસ્તુઓ સંલગ્ન મેમરીમાં હોય છે.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // સલામતી: અનચેક કરેલ તત્વ માન્ય હોવું આવશ્યક છે.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // જો `drop_in_place` ગભરાઈ જાય તો ડબલ ડ્રોપ ટાળવા માટે વહેલું આગળ વધો
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // સલામતી: નીચે પડ્યા પછી અમે આ તત્વને ફરીથી ક્યારેય સ્પર્શતા નથી.
                unsafe { ptr::drop_in_place(cur) };
                // અમે પહેલાથી જ કાઉન્ટરને આગળ વધાર્યું છે.
                continue;
            }
            if g.deleted_cnt > 0 {
                // સલામતી: `deleted_cnt`> 0, તેથી છિદ્ર સ્લોટ વર્તમાન તત્વ સાથે ઓવરલેપ ન થવો જોઈએ.
                // અમે ખસેડવા માટે ક copyપિનો ઉપયોગ કરીએ છીએ, અને આ તત્વને ફરીથી ક્યારેય સ્પર્શ નહીં કરીએ.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // બધી વસ્તુઓ પર પ્રક્રિયા કરવામાં આવે છે.એલએલવીએમ દ્વારા આને `set_len` માં optimપ્ટિમાઇઝ કરી શકાય છે.
        drop(g);
    }

    /// vector માં સતત એલિમેન્ટ્સના પહેલા સિવાયના બધાને દૂર કરે છે જે સમાન કીનો ઉકેલ લાવે છે.
    ///
    ///
    /// જો vector સortedર્ટ થયેલ છે, તો આ બધા ડુપ્લિકેટ્સને દૂર કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// આપેલ સમાનતા સંબંધને સંતોષતા vector માં સતત તત્વોના પ્રથમ સિવાય બધાને દૂર કરે છે.
    ///
    /// `same_bucket` ફંક્શન એ vector માંથી બે તત્વોના સંદર્ભો પસાર કર્યા છે અને તે નક્કી કરવું આવશ્યક છે કે જો તત્વો સમાન સરખામણી કરે.
    /// ટુકડાઓમાં તત્વો તેમના orderર્ડરથી વિરુદ્ધ ક્રમમાં પસાર થાય છે, તેથી જો `same_bucket(a, b)` `true` આપે છે, તો `a` દૂર કરવામાં આવે છે.
    ///
    ///
    /// જો vector સortedર્ટ થયેલ છે, તો આ બધા ડુપ્લિકેટ્સને દૂર કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// સંગ્રહની પાછળના ભાગમાં એક તત્વ જોડે છે.
    ///
    /// # Panics
    ///
    /// Panics જો નવી ક્ષમતા `isize::MAX` બાઇટ્સથી વધુ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // આ ઝેડપેનિનીક ઝેડ અથવા ગર્ભપાત કરશે જો આપણે> isize::MAX બાઇટ્સ ફાળવીશું અથવા લંબાઈ વૃદ્ધિ શૂન્ય-કદના પ્રકારો માટે ઓવરફ્લો થશે.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector માંથી છેલ્લું તત્વ દૂર કરે છે અને તે ખાલી છે, અથવા [`None`] આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` ના બધા ઘટકોને `Self` માં ખસેડે છે, `other` ને ખાલી છોડી દે છે.
    ///
    /// # Panics
    ///
    /// Panics જો vector માં તત્વોની સંખ્યા એક `usize` ઓવરફ્લો કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// અન્ય બફરમાંથી તત્વોને `Self` માં જોડે છે.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// એક ડ્રેઇનિંગ ઇટરેટર બનાવે છે જે vector માં નિર્દિષ્ટ શ્રેણીને દૂર કરે છે અને દૂર કરેલી આઇટમ્સ મેળવે છે.
    ///
    /// જ્યારે ઇરેટર ** ** છોડવામાં આવે છે, ત્યારે ઇરેટરેટર સંપૂર્ણપણે વપરાશમાં ન હોય તો પણ, રેન્જમાંના બધા ઘટકો ઝેડ 0 વેક્ટર 0 ઝેડમાંથી દૂર કરવામાં આવે છે.
    /// જો ઇરેટર ** ** છોડવામાં ન આવે તો (ઉદાહરણ તરીકે [`mem::forget`] સાથે), કેટલા ઘટકોને દૂર કરવામાં આવે છે તે અનિશ્ચિત છે.
    ///
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો પ્રારંભિક બિંદુ અંત બિંદુ કરતા વધારે હોય અથવા જો અંત બિંદુ vector ની લંબાઈ કરતા વધારે હોય.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // એક સંપૂર્ણ શ્રેણી vector ને સાફ કરે છે
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // મેમરી સલામતી
        //
        // જ્યારે ઝેડડ્રેન 0 ઝેડ પ્રથમ બનાવવામાં આવે છે, ત્યારે ઝેડડ્રેન 0 ઝેડ ડિસ્ટ્રક્ટર ક્યારેય ચલાવવાનું નહીં આવે તેની ખાતરી કરવા માટે સ્રોત ઝેડ 0 વેક્ટર 0 ઝેડની લંબાઈ ટૂંકી કરે છે.
        //
        //
        // Drain, ptr::read ને દૂર કરવા માટેના મૂલ્યોને બહાર કા outશે.
        // જ્યારે સમાપ્ત થાય, ત્યારે વેકની બાકીની પૂંછડી છિદ્રને coverાંકવા માટે પાછળની નકલ કરવામાં આવે છે, અને ઝેડવેક્ટર 0 ઝેડ લંબાઈ નવી લંબાઈમાં ફરીથી સ્થાપિત થાય છે.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // ઝેડ 0 ડ્રેન 0 ઝેડ લીક થઈ હોય તો સુરક્ષિત રહેવા માટે, self.vec લંબાઈ સેટ કરો
            self.set_len(start);
            // આખા ઝેડડ્રેન 0 ઝેડ ઇટરેટર (જેમ કે &mut ટી) ના ઉધાર વર્તન સૂચવવા માટે IterMut માં orrowણનો ઉપયોગ કરો.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector ને સાફ કરે છે, બધા મૂલ્યોને દૂર કરે છે.
    ///
    /// નોંધો કે આ પદ્ધતિ vector ની ફાળવેલ ક્ષમતા પર કોઈ અસર કરી શકશે નહીં.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector માં તત્વોની સંખ્યા પરત કરે છે, જેને તેના 'length' તરીકે પણ ઓળખવામાં આવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// જો vector માં કોઈ તત્વો ન હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// આપેલ અનુક્રમણિકા પર સંગ્રહને બે ભાગમાં વહેંચે છે.
    ///
    /// `[at, len)` રેન્જમાં તત્વો ધરાવતા નવા ફાળવેલ vector પરત કરે છે.
    /// ક theલ પછી, મૂળ vector એ તેની પહેલાંની ક્ષમતામાં કોઈ ફેરફાર વિના, `[0, at)` એલિમેન્ટ્સ ધરાવશે.
    ///
    ///
    /// # Panics
    ///
    /// ઝેડ 0 પેનિક્સ 0 ઝેડ જો `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // નવું ઝેડ 0 વેક્ટર 0 ઝેડ મૂળ બફરનો કબજો લઈ શકે છે અને ક theપિને ટાળી શકે છે
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // અસુરક્ષિત `set_len` અને `other` પર આઇટમ્સની ક copyપિ કરો.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` ને જગ્યામાં બદલો જેથી `len` `new_len` ની બરાબર હોય.
    ///
    /// જો `new_len` `len` કરતા વધારે છે, તો ક્લોઝર `f` ને ક callingલ કરવાના પરિણામથી ભરેલા દરેક વધારાના સ્લોટ સાથે, `Vec` તફાવત દ્વારા વિસ્તૃત કરવામાં આવે છે.
    ///
    /// `f` ના વળતર મૂલ્યો, તે જનરેટ થયાના ક્રમમાં `Vec` માં સમાપ્ત થશે.
    ///
    /// જો `new_len` `len` કરતા ઓછું હોય, તો `Vec` ફક્ત કાપવામાં આવે છે.
    ///
    /// આ પદ્ધતિ દરેક દબાણ પર નવા મૂલ્યો બનાવવા માટે ક્લોઝરનો ઉપયોગ કરે છે.જો તમે આપેલ મૂલ્ય [`Clone`] કરતા હો, તો [`Vec::resize`] નો ઉપયોગ કરો.
    /// જો તમે મૂલ્યો ઉત્પન્ન કરવા માટે [`Default`] trait નો ઉપયોગ કરવા માંગતા હો, તો તમે બીજા દલીલ તરીકે [`Default::default`] પસાર કરી શકો છો.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` ખાય છે અને લિક કરે છે, સમાવિષ્ટોનો પરિવર્તનશીલ સંદર્ભ પાછો આપે છે, `&'a mut [T]`.
    /// નોંધ લો કે પ્રકાર `T` એ પસંદ કરેલા જીવનકાળ `'a` ને આઉટલિવ કરવું આવશ્યક છે.
    /// જો પ્રકારમાં ફક્ત સ્થિર સંદર્ભો છે, અથવા કોઈ પણ નથી, તો પછી તે `'static` તરીકે પસંદ કરી શકાય છે.
    ///
    /// આ ફંક્શન [`Box`] પરના [`leak`][Box::leak] ફંક્શન જેવું જ છે સિવાય કે લીક થયેલી મેમરીને ફરીથી પ્રાપ્ત કરવાનો કોઈ રસ્તો નથી.
    ///
    ///
    /// આ કાર્ય મુખ્યત્વે ડેટા માટે ઉપયોગી છે જે પ્રોગ્રામના જીવનના બાકીના સમય માટે જીવે છે.
    /// પરત થયેલ સંદર્ભ છોડી દેવાથી મેમરી લિક થશે.
    ///
    /// # Examples
    ///
    /// સરળ ઉપયોગ:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector ની બાકીની વધારાની ક્ષમતા `MaybeUninit<T>` ના ટુકડા તરીકે પરત કરે છે.
    ///
    /// પરત સ્લાઈસનો ઉપયોગ vector ને ડેટા (દા.ત.) થી ભરવા માટે કરી શકાય છે
    /// [`set_len`] પદ્ધતિનો ઉપયોગ કરીને પ્રારંભિક તરીકે ડેટાને ચિહ્નિત કરતા પહેલા ફાઇલમાંથી વાંચીને).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 તત્વો માટે પૂરતા મોટા vector ફાળવો.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // પ્રથમ 3 તત્વો ભરો.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // પ્રારંભિક તરીકે vector ના પ્રથમ 3 તત્વોને ચિહ્નિત કરો.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // બફર તરફના પોઇંટર્સના અમાન્યતાને રોકવા માટે, આ પદ્ધતિ `split_at_spare_mut` ની શરતમાં લાગુ કરવામાં આવી નથી.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// ઝેડ 0 વેક્ટર 0 ઝેડ કન્ટેન્ટને `T` ની સ્લાઈસ તરીકે, vector ની બાકીની ફાજલ ક્ષમતા સાથે, `MaybeUninit<T>` ના ટુકડા તરીકે પરત કરે છે.
    ///
    /// પરત થયેલ સ્પેર કેપેસિટી સ્લાઈસનો ઉપયોગ X0vector0Z ને ડેટા સાથે ભરવા માટે કરી શકાય છે (દા.ત. ફાઇલમાંથી વાંચીને) ડેટાને [`set_len`] પદ્ધતિનો ઉપયોગ કરીને પ્રારંભિક તરીકે માર્ક કરતા પહેલા.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// નોંધ લો કે આ એક નિમ્ન-સ્તરનું API છે, જેનો ઉપયોગ optimપ્ટિમાઇઝેશન હેતુ માટે કાળજી સાથે થવો જોઈએ.
    /// જો તમારે કોઈ `Vec` પર ડેટા જોડવાની જરૂર છે, તો તમે તમારી ચોક્કસ જરૂરિયાતોને આધારે, [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] અથવા [`resize_with`] નો ઉપયોગ કરી શકો છો.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 તત્વો માટે પૂરતી મોટી જગ્યા અનામત.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // આગામી 4 તત્વો ભરો.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // પ્રારંભિક તરીકે vector ના 4 તત્વોને ચિહ્નિત કરો.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - લેન અવગણવામાં આવે છે અને તેથી ક્યારેય બદલાયું નથી
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// સલામતી: પરત ફર્યા .2 (&mut usize) ને `.set_len(_)` પર ક asલ કરવા જેવું જ માનવામાં આવે છે.
    ///
    /// આ પદ્ધતિનો ઉપયોગ `extend_from_within` માં એકવાર બધા વેક્ટર ભાગોની અનન્ય haveક્સેસ માટે થાય છે.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` તત્વો માટે માન્ય હોવાની બાંયધરી આપવામાં આવી છે
        // - `spare_ptr` બફરની પાછળનો એક તત્વ દર્શાવે છે, તેથી તે `initialized` સાથે ઓવરલેપ થતો નથી
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` ને જગ્યામાં બદલો જેથી `len` `new_len` ની બરાબર હોય.
    ///
    /// જો `new_len` `len` કરતા વધારે છે, તો `Vec` `value` ભરેલા દરેક વધારાના સ્લોટ સાથે, તફાવત દ્વારા વિસ્તૃત કરવામાં આવે છે.
    ///
    /// જો `new_len` `len` કરતા ઓછું હોય, તો `Vec` ફક્ત કાપવામાં આવે છે.
    ///
    /// પસાર કરેલ મૂલ્યને ક્લોન કરવા માટે સક્ષમ થવા માટે, આ પદ્ધતિમાં [`Clone`] લાગુ કરવા માટે `T` ની જરૂર છે.
    /// જો તમને વધુ સુગમતાની જરૂર હોય (અથવા [`Clone`] ને બદલે [`Default`] પર આધાર રાખવો હોય તો), [`Vec::resize_with`] નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// ક્લોન્સ અને બધા ભાગોને ક્લ andસ કરે છે અને એક ટુકડામાં `Vec` માં જોડે છે.
    ///
    /// સ્લાઇસ `other` પર ફેરવાય છે, દરેક તત્વનું ક્લોન કરે છે અને પછી તેને આ `Vec` માં જોડે છે.
    /// `other` vector એ ક્રમમાં પસાર થાય છે.
    ///
    /// નોંધ લો કે આ ફંક્શન [`extend`] જેવું જ છે સિવાય કે તેના સિવાય કટકાથી કામ કરવા માટે વિશિષ્ટ છે.
    ///
    /// જો અને જ્યારે ઝેડ રસ્ટ0 ઝેડ વિશેષતા મેળવે છે, તો આ કાર્ય સંભવત dep દૂર કરવામાં આવશે (પરંતુ હજી પણ ઉપલબ્ધ છે).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` થી vector ના અંત સુધીના ઘટકોની નકલો.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` બાંહેધરી આપે છે કે આપેલ શ્રેણી સ્વ અનુક્રમણિકા માટે માન્ય છે
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// આ કોડ `extend_with_{element,default}` ને સામાન્ય બનાવે છે.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// આપેલ જનરેટરનો ઉપયોગ કરીને, `n` કિંમતો દ્વારા vector વિસ્તૃત કરો.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // બગની આસપાસ કામ કરવા માટે સેટલેન ઓનડ્રોપનો ઉપયોગ કરો જ્યાં કમ્પાઇલર `ptr` દ્વારા self.set_len() દ્વારા ઉપનામ નહીં દ્વારા સ્ટોરનો ખ્યાલ નહીં આવે.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // છેલ્લા એક સિવાય બધા તત્વો લખો
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics કિસ્સામાં દરેક પગલાની લંબાઈમાં વધારો
                local_len.increment_len(1);
            }

            if n > 0 {
                // આપણે બિનજરૂરી ક્લોનીંગ કર્યા વિના સીધા જ છેલ્લા તત્વ લખી શકીએ છીએ
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // અવકાશ રક્ષક દ્વારા સેટ લેન
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait અમલીકરણ અનુસાર vector માં સતત પુનરાવર્તિત તત્વોને દૂર કરે છે.
    ///
    ///
    /// જો vector સortedર્ટ થયેલ છે, તો આ બધા ડુપ્લિકેટ્સને દૂર કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// આંતરિક પદ્ધતિઓ અને કાર્યો
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` માન્ય અનુક્રમણિકા હોવી જરૂરી છે
    /// - `self.capacity() - self.len()` `>= src.len()` હોવા જોઈએ
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - તત્વો પ્રારંભ કર્યા પછી જ લેનમાં વધારો કરવામાં આવે છે
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - કlerલર ગેરેટીસ કે ઝેડ 0 સીઆરસી 0 ઝેડ એ માન્ય અનુક્રમણિકા છે
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - એલિમેન્ટ હમણાં જ `MaybeUninit::write` સાથે પ્રારંભ કરવામાં આવ્યો હતો, તેથી તે વધારવા માટે બરાબર છે
            // - લિકને રોકવા માટે દરેક તત્વ પછી લેન વધારવામાં આવે છે (જુઓ ઇસ્યુ #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - કlerલર ગેરેટીઝ કે `src` એ માન્ય અનુક્રમણિકા છે
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - બંને પોઇંટર્સ અનન્ય સ્લાઇસ સંદર્ભો (`&મ્યુટ [_] from) માંથી બનાવેલ છે તેથી તેઓ માન્ય છે અને ઓવરલેપ થતા નથી.
            //
            // - તત્વો છે: ક Copyપિ કરો તેથી મૂળ કિંમતો સાથે કંઈ પણ કર્યા વિના, તેમની નકલ કરવી તે ઠીક છે
            // - `count` `source` ની લેન સમાન છે, તેથી `count` વાંચવા માટે સ્રોત માન્ય છે
            // - `.reserve(count)` `spare.len() >= count` તેથી ફાજલ `count` લખવા માટે માન્ય છે તેની ખાતરી આપે છે
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - તત્વો હમણાં જ `copy_nonoverlapping` દ્વારા પ્રારંભ કરવામાં આવ્યા હતા
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec માટે સામાન્ય ઝેડટ્રેટ 0 ઝેડ અમલીકરણો
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) સાથે અંતર્ગત `[T]::to_vec` પદ્ધતિ, જે આ પદ્ધતિની વ્યાખ્યા માટે જરૂરી છે, ઉપલબ્ધ નથી.
    // તેના બદલે `slice::to_vec` ફંક્શનનો ઉપયોગ કરો જે ફક્ત cfg(test) NB સાથે જ ઉપલબ્ધ છે વધુ માહિતી માટે slice.rs માં slice::hack મોડ્યુલ જુઓ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ફરીથી લખાશે નહીં તેવી કોઈપણ વસ્તુ છોડો
        self.truncate(other.len());

        // self.len <= other.len ઉપરના કાપવાના કારણે, તેથી અહીં કાપી નાંખ્યું હંમેશા ઇન-બાઉન્ડ હોય છે.
        //
        let (init, tail) = other.split_at(self.len());

        // સમાયેલ મૂલ્યો allocations/resources નો ફરીથી ઉપયોગ કરો.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// ઉપભોક્તા ઇટરેટર બનાવે છે, એટલે કે, જે દરેક મૂલ્યને ઝેડવેક્ટર 0 ઝેડ (શરૂઆતથી અંત સુધી) ની બહાર ખસેડે છે.
    /// આ કહેવા પછી vector નો ઉપયોગ કરી શકાતો નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s માં પ્રકારનાં શબ્દમાળાઓ છે, &String નહીં
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // પાંદડાની પદ્ધતિ જેમાં વિવિધ એક્સ 100 એક્સ અમલીકરણો સોંપે છે જ્યારે તેમની પાસે લાગુ કરવા માટે કોઈ વધુ izપ્ટિમાઇઝેશન નથી
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // આ સામાન્ય ઇટરેટર માટેનો કેસ છે.
        //
        // આ કાર્ય આની નૈતિક સમકક્ષ હોવું જોઈએ:
        //
        //      પુનરાવર્તક માં આઇટમ માટે {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ઓવરફ્લો થઈ શકતું નથી કારણ કે આપણે સરનામાંની જગ્યા ફાળવી હોત
                self.set_len(len + 1);
            }
        }
    }

    /// એક સ્પિકલિંગ ઇટરેટર બનાવે છે જે vector માં નિર્દિષ્ટ શ્રેણીને આપેલ `replace_with` પુનરાવર્તક સાથે બદલીને દૂર કરેલી આઇટમ્સ મેળવે છે.
    ///
    /// `replace_with` `range` જેટલી લંબાઈ હોવી જરૂરી નથી.
    ///
    /// `range` જો ઇરેટરનો અંત સુધી પીવામાં ન આવે તો પણ દૂર કરવામાં આવે છે.
    ///
    /// જો `Splice` મૂલ્ય લીક થયું હોય તો vector માંથી કેટલા ઘટકોને દૂર કરવામાં આવ્યા છે તે અસ્પષ્ટ છે.
    ///
    /// જ્યારે ઇનપુટ ઇટરેટર `replace_with` ત્યારે જ વપરાય છે જ્યારે `Splice` મૂલ્ય છોડી દેવામાં આવે છે.
    ///
    /// આ શ્રેષ્ઠ છે જો:
    ///
    /// * પૂંછડી (`range` પછી vector માં તત્વો) ખાલી છે,
    /// * અથવા `replace_with` `શ્રેણી` ની લંબાઈ કરતા ઓછા અથવા સમાન તત્વો મેળવે છે
    /// * અથવા તેના `size_hint()` નીચલા સીમા ચોક્કસ છે.
    ///
    /// નહિંતર, કામચલાઉ ઝેડ 0 વેક્ટર 0 ઝેડ ફાળવવામાં આવે છે અને પૂંછડી બે વાર ખસેડવામાં આવે છે.
    ///
    /// # Panics
    ///
    /// ઝેડપેનિક્સ 0 ઝેડ જો પ્રારંભિક બિંદુ અંત બિંદુ કરતા વધારે હોય અથવા જો અંત બિંદુ vector ની લંબાઈ કરતા વધારે હોય.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// ઇટિરેટર બનાવે છે જે તત્વને દૂર કરવું જોઈએ કે કેમ તે નિર્ધારિત કરવા માટે બંધનો ઉપયોગ કરે છે.
    ///
    /// જો બંધ સાચું પાછું આવે છે, તો પછી તત્વ દૂર કરવામાં આવે છે અને ઉપજ મળે છે.
    /// જો ક્લોઝર ખોટું વળતર આપે છે, તો તત્વ vector માં રહેશે અને પુનરાવર્તક દ્વારા પ્રાપ્ત થશે નહીં.
    ///
    /// આ પદ્ધતિનો ઉપયોગ કરવો એ નીચેના કોડની સમાન છે:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // તમારો કોડ અહીં
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// પરંતુ `drain_filter` નો ઉપયોગ કરવો વધુ સરળ છે.
    /// `drain_filter` તે વધુ કાર્યક્ષમ પણ છે, કારણ કે તે એરેના તત્વોને બલ્કમાં પાળી શકે છે.
    ///
    /// નોંધો કે `drain_filter` તમને ફિલ્ટર બંધ થવા પરના દરેક તત્વને પરિવર્તિત કરવા દે છે, પછી ભલે તમે તેને રાખવા અથવા દૂર કરવાનું પસંદ કરો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળ ફાળવણીનો ફરીથી ઉપયોગ કરીને, સંધ્યા અને અવરોધોમાં એરેનું વિભાજન:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // લીક થતાં અમારી સામે ગાર્ડ (લિક એમ્પ્લીફિકેશન)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// અમલીકરણને વિસ્તૃત કરો જે તત્વોને વી.સી. પર દબાણ કરતાં પહેલાં સંદર્ભોની બહાર કાiesે છે.
///
/// આ અમલીકરણ સ્લાઇસ પુનરાવર્તકો માટે વિશિષ્ટ છે, જ્યાં તે એક જ સમયે સમગ્ર સ્લાઇસને જોડવા માટે [`copy_from_slice`] નો ઉપયોગ કરે છે.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors ની તુલના લાગુ કરે છે, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors ના ઓર્ડરિંગને લાગુ કરે છે, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] માટે ડ્ર dropપનો ઉપયોગ ડ્રોઇંગ vector ના તત્વોને નબળા જરૂરી પ્રકારનો સંદર્ભ આપવા માટે કાચી કટકાનો ઉપયોગ કરો;
            //
            // અમુક કિસ્સાઓમાં માન્યતાના પ્રશ્નો ટાળી શકશે
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec અધોગતિને સંભાળે છે
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// ખાલી `Vec<T>` બનાવે છે.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: પરીક્ષણ લિબસ્ટેડમાં ખેંચે છે, જે અહીં ભૂલોનું કારણ બને છે
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: પરીક્ષણ લિબસ્ટેડમાં ખેંચે છે, જે અહીં ભૂલોનું કારણ બને છે
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// જો તેનો કદ વિનંતી કરેલા એરે સાથે બરાબર બંધબેસશે, તો એરે તરીકે `Vec<T>` ની સંપૂર્ણ સામગ્રી મેળવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// જો લંબાઈ મેળ ખાતી નથી, તો ઇનપુટ પાછા `Err` માં આવે છે:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// જો તમે ફક્ત `Vec<T>` નો ઉપસર્ગ મેળવવામાં સારુ છો, તો તમે પહેલા [`.truncate(N)`](Vec::truncate) ને ક callલ કરી શકો છો.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // સલામતી: `.set_len(0)` હંમેશાં ધ્વનિ હોય છે.
        unsafe { vec.set_len(0) };

        // સલામતી: એ `વેકનું નિર્દેશક હંમેશાં યોગ્ય રીતે ગોઠવાયેલ હોય છે, અને
        // એરેની ગોઠવણી એરેટ્સની જેમ જ છે.
        // અમે અગાઉ તપાસ કરી હતી કે અમારી પાસે પૂરતી વસ્તુઓ છે.
        // આઇટમ્સ ડબલ-ડ્રોપ નહીં કરે કારણ કે `set_len` `Vec` ને પણ છોડવાનું કહે છે.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}