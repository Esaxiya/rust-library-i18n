use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// એક ઇટિરેટર જે કોઈ તત્વને દૂર કરવું જોઈએ તે નિર્ધારિત કરવા માટે બંધનો ઉપયોગ કરે છે.
///
/// આ સ્ટ્રક્ટ [`Vec::drain_filter`] દ્વારા બનાવવામાં આવી છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// આઇટમનું અનુક્રમણિકા જે `next` પરના આગલા ક callલ દ્વારા નિરીક્ષણ કરવામાં આવશે.
    pub(super) idx: usize,
    /// અત્યાર સુધીમાં (removed) ને ડ્રેઇન કરેલી આઇટમ્સની સંખ્યા.
    pub(super) del: usize,
    /// ડ્રેઇનિંગ પહેલાં `vec` ની અસલ લંબાઈ.
    pub(super) old_len: usize,
    /// ફિલ્ટર કસોટી
    pub(super) pred: F,
    /// એક ઝેડ કે જે panic સૂચવે છે તે ફિલ્ટર પરીક્ષણના સૂચકામાં આવ્યું છે.
    /// `DrainFilter` ની બાકીની રકમનો વપરાશ અટકાવવા માટે ડ્રોપ અમલીકરણમાં આના સંકેત તરીકે ઉપયોગ થાય છે.
    /// કોઈપણ અપ્રોસેસ કરેલ આઇટમ્સને `vec` માં બેકશિલ્ટ કરવામાં આવશે, પરંતુ ફિલ્ટર પicateરિકેટ દ્વારા આગળ કોઈ ચીજો કા droppedી કે પરીક્ષણ કરવામાં આવશે નહીં.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// અંતર્ગત ફાળવણીકારનો સંદર્ભ આપે છે.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // પ્રિડેકેટ કહેવાયા પછી * અનુક્રમણિકાને અપડેટ કરો.
                // જો અનુક્રમણિકા પહેલા અપડેટ કરવામાં આવે અને ઝેડપેનિક્સ 0 ઝેડ ઝેડ, આ અનુક્રમણિકામાંનું તત્વ લીક થઈ જાય.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // આ એક સુંદર અવ્યવસ્થિત રાજ્ય છે, અને ત્યાં કરવા માટે ખરેખર દેખીતી વસ્તુ નથી.
                        // અમે `pred` એક્ઝેક્યુટ કરવાનો પ્રયાસ ચાલુ રાખવા માંગતા નથી, તેથી અમે ફક્ત બધા અપ્રોસેસ્ડ તત્વોની પીછેહઠ કરીશું અને વેક્ટરને કહીએ કે તેઓ હજી પણ અસ્તિત્વમાં છે.
                        //
                        // પ્રેકિટમાં ઝેડ 0 પicનિકિક ઝેડ પહેલાં છેલ્લી સફળતાપૂર્વક ડ્રેઇન કરેલી વસ્તુના ડબલ-ડ્રોપને રોકવા માટે બેકશિફ્ટની આવશ્યકતા છે.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // જો ફિલ્ટર પicateરિકેટ હજી ગભરાવ્યું નથી, તો બાકીના તત્વોનો વપરાશ કરવાનો પ્રયાસ કરો.
        // આપણે પહેલેથી ગભરાઈ ગયા છે કે પછી વપરાશ અહીં ઝેડપેનિક્સ 0 ઝેડમાં છે કે કેમ તે બાકીના કોઈપણ તત્વોનું પાલન કરીશું.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}