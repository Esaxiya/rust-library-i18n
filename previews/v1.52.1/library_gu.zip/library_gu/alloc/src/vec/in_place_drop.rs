use core::ptr::{self};
use core::slice::{self};

// ઇન-પ્લેસ ઇટરેશન માટે સહાયક સંરચના જે પુનરાવર્તનની ગંતવ્ય ટુકડા, એટલે કે માથાને નીચે કા dropsે છે.
// સ્રોતની કટકા (પૂંછડી) ને ઇન્ટોઇટર દ્વારા છોડી દેવામાં આવે છે.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}