//! સુસંગત ક્રમમાં ગતિશીલ કદના દૃશ્ય, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! કાપી નાંખ્યું એ એક પોઇન્ટર અને લંબાઈ તરીકે રજૂ કરેલા મેમરીના બ્લોકમાં એક દૃશ્ય છે.
//!
//! ```
//! // એક વીઇસી કાપી
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // એક કટકા માટે એરે દબાણ
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! કાપી નાંખેલું કાં તો પરિવર્તનીય અથવા વહેંચાયેલ હોય છે.
//! વહેંચાયેલ સ્લાઇસ પ્રકાર `&[T]` છે, જ્યારે પરિવર્તનીય સ્લાઇસ પ્રકાર `&mut [T]` છે, જ્યાં `T` એ તત્વ પ્રકારનું પ્રતિનિધિત્વ કરે છે.
//! ઉદાહરણ તરીકે, તમે મેમરીના બ્લોકને પરિવર્તિત કરી શકો છો કે જે પરિવર્તનીય સ્લાઇસ નિર્દેશ કરે છે:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! આ મોડ્યુલમાં સમાવિષ્ટ કેટલીક ચીજો અહીં આપી છે:
//!
//! ## Structs
//!
//! ત્યાં ઘણી સ્ટ્રક્ટ્સ છે જે કાપી નાંખવા માટે ઉપયોગી છે, જેમ કે [`Iter`], જે સ્લાઇસ પર પુનરાવૃત્તિનું પ્રતિનિધિત્વ કરે છે.
//!
//! ## Trait અમલીકરણો
//!
//! કાપી નાંખવા માટે સામાન્ય ઝેડટ્રેટિટ્સ0 ઝેડના ઘણા અમલીકરણો છે.કેટલાક ઉદાહરણોમાં શામેલ છે:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ટુકડાઓ માટે જેનો તત્વ પ્રકાર [`Eq`] અથવા [`Ord`] છે.
//! * [`Hash`] - ટુકડાઓ માટે જેનો તત્વ પ્રકાર [`Hash`] છે.
//!
//! ## Iteration
//!
//! કાપી નાંખ્યું `IntoIterator` અમલમાં મૂકે છે.પુનરાવર્તક સ્લાઇસ તત્વોનો સંદર્ભ આપે છે.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! પરિવર્તનીય સ્લાઇસ તત્વોને પરિવર્તનીય સંદર્ભો આપે છે:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! આ પુનરાવર્તક સ્લાઇસના તત્વોને પરિવર્તનીય સંદર્ભો આપે છે, તેથી જ્યારે સ્લાઇસનો તત્વ પ્રકાર `i32` છે, જ્યારે પુનરાવર્તકનો તત્વ પ્રકાર `&mut i32` છે.
//!
//!
//! * [`.iter`] અને [`.iter_mut`] એ ડિફ iteલ્ટ પુનરાવર્તકોને પાછા ફરવા માટેની સ્પષ્ટ પદ્ધતિઓ છે.
//! * આગળની પદ્ધતિઓ કે જે પુનરાવર્તિત કરે છે તે છે [`.split`], [`.splitn`], [`.chunks`], [`.windows`] અને વધુ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// આ મોડ્યુલમાં ઘણા યુઝિંગ્સનો ઉપયોગ ફક્ત પરીક્ષણ ગોઠવણીમાં થાય છે.
// ફક્ત બિનવપરાયેલ_ઇમ્પોર્ટ્સ ચેતવણીને ઠીક કરવાને બદલે તેને બંધ કરવું તે વધુ સારું છે.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// મૂળ સ્લાઈસ વિસ્તરણ પદ્ધતિઓ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) એનબી ચકાસણી દરમિયાન `vec!` મેક્રોના અમલીકરણ માટે જરૂરી છે, વધુ વિગતો માટે આ ફાઇલમાં `hack` મોડ્યુલ જુઓ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) એનબી ચકાસણી દરમિયાન `Vec::clone` ના અમલીકરણ માટે જરૂરી છે, વધુ વિગતો માટે આ ફાઇલમાં `hack` મોડ્યુલ જુઓ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` ઉપલબ્ધ નથી, આ ત્રણ કાર્યો એ ખરેખર પદ્ધતિઓ છે જે `impl [T]` માં છે પરંતુ `core::slice::SliceExt` માં નથી, આપણે `test_permutations` પરીક્ષણ માટે આ કાર્યો પૂરા પાડવાની જરૂર છે.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // આપણે આમાં ઇનલાઇન એટ્રિબ્યુટ ઉમેરવું જોઈએ નહીં કારણ કે આનો ઉપયોગ મોટે ભાગે `vec!` મેક્રોમાં થાય છે અને તે સંપૂર્ણ રીગ્રેસનનું કારણ બને છે.
    // ચર્ચા અને સંપૂર્ણ પરિણામો માટે #71204 જુઓ.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // વસ્તુઓ નીચે લૂપમાં પ્રારંભિક તરીકે ચિહ્નિત કરવામાં આવી હતી
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) એલએલવીએમ માટે સીમાઓની તપાસ દૂર કરવા માટે જરૂરી છે અને ઝીપ કરતાં વધુ સારી કોડેન છે.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ઓછામાં ઓછું આ લંબાઈ માટે વી.સી.ની ફાળવણી કરવામાં આવી હતી અને પ્રારંભ કરવામાં આવી હતી.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` ની ક્ષમતા સાથે ઉપર ફાળવવામાં આવેલ છે, અને નીચે ptr::copy_to_non_overlapping માં `s.len()` થી પ્રારંભ કરો.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// સ્લાઈસ સortsર્ટ કરે છે.
    ///
    /// આ સ sortર્ટ સ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવતો નથી) અને *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ).
    ///
    /// જ્યારે લાગુ પડે ત્યારે, અસ્થિર સ sortર્ટિંગને પ્રાધાન્ય આપવામાં આવે છે કારણ કે તે સામાન્ય રીતે સ્થિર સingર્ટિંગ કરતા ઝડપી હોય છે અને તે સહાયક મેમરીને ફાળવતા નથી.
    /// [`sort_unstable`](slice::sort_unstable) જુઓ.
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ [timsort](https://en.wikipedia.org/wiki/Timsort) દ્વારા પ્રેરિત અનુકૂલનશીલ, પુનરાવર્તિત મર્જ સ sortર્ટ છે.
    /// તે એવી સ્થિતિમાં ખૂબ જ ઝડપથી ડિઝાઇન કરવામાં આવી છે કે જ્યાં સ્લાઇસ લગભગ સortedર્ટ થઈ હોય, અથવા તેમાં એક પછી એક બે અથવા વધુ સortedર્ટ સિક્વેન્સ હોય.
    ///
    ///
    /// ઉપરાંત, તે `self` ના અડધા કદના અસ્થાયી સ્ટોરેજની ફાળવણી કરે છે, પરંતુ ટૂંકી કાપી નાંખવાને બદલે, બિન-ફાળવણી દાખલ કરવાની સ sortર્ટનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// કમ્પેરેટર ફંક્શન સાથે સ્લાઈસને સortsર્ટ કરે છે.
    ///
    /// આ સ sortર્ટ સ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવતો નથી) અને *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ).
    ///
    /// કમ્પેરેટર ફંક્શનમાં સ્લાઇસમાં તત્વો માટે કુલ ક્રમમાં વ્યાખ્યાયિત કરવી આવશ્યક છે.જો ઓર્ડરિંગ કુલ નથી, તો તત્વોનો ક્રમ અનિશ્ચિત છે.
    /// ઓર્ડર એ કુલ ઓર્ડર છે જો તે (બધા `a`, `b` અને `c` માટે):
    ///
    /// * કુલ અને એન્ટિસિમમેટ્રિક: `a < b`, `a == b` અથવા `a > b` માંથી એક બરાબર સાચું છે, અને
    /// * ક્ષણિક, `a < b` અને `b < c` સૂચવે `a < c`.`==` અને `>` બંને માટે સમાન હોવું આવશ્યક છે.
    ///
    /// ઉદાહરણ તરીકે, જ્યારે [`f64`] [`Ord`] લાગુ કરતું નથી કારણ કે `NaN != NaN`, જ્યારે આપણે જાણીએ છીએ કે સ્લાઇસમાં `NaN` નથી હોતો ત્યારે આપણે `partial_cmp` નો ઉપયોગ અમારી સ ourર્ટ ફંક્શન તરીકે કરી શકીએ છીએ.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// જ્યારે લાગુ પડે ત્યારે, અસ્થિર સ sortર્ટિંગને પ્રાધાન્ય આપવામાં આવે છે કારણ કે તે સામાન્ય રીતે સ્થિર સingર્ટિંગ કરતા ઝડપી હોય છે અને તે સહાયક મેમરીને ફાળવતા નથી.
    /// [`sort_unstable_by`](slice::sort_unstable_by) જુઓ.
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ [timsort](https://en.wikipedia.org/wiki/Timsort) દ્વારા પ્રેરિત અનુકૂલનશીલ, પુનરાવર્તિત મર્જ સ sortર્ટ છે.
    /// તે એવી સ્થિતિમાં ખૂબ જ ઝડપથી ડિઝાઇન કરવામાં આવી છે કે જ્યાં સ્લાઇસ લગભગ સortedર્ટ થઈ હોય, અથવા તેમાં એક પછી એક બે અથવા વધુ સortedર્ટ સિક્વેન્સ હોય.
    ///
    /// ઉપરાંત, તે `self` ના અડધા કદના અસ્થાયી સ્ટોરેજની ફાળવણી કરે છે, પરંતુ ટૂંકી કાપી નાંખવાને બદલે, બિન-ફાળવણી દાખલ કરવાની સ sortર્ટનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // રિવર્સ સોર્ટિંગ
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// કી નિષ્કર્ષણ વિધેય સાથે સ્લાઇસને સortsર્ટ કરે છે.
    ///
    /// આ સ sortર્ટ સ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવતો નથી) અને *O*(*m*\* * n *\* log(*n*)) સૌથી ખરાબ કેસ છે, જ્યાં કી ફંક્શન *O*(*m*) છે.
    ///
    /// ખર્ચાળ કી કાર્યો માટે (દા.ત.
    /// વિધેયો કે જે સામાન્ય સંપત્તિ cesક્સેસ અથવા મૂળ કામગીરી નથી), [`sort_by_cached_key`](slice::sort_by_cached_key) એ નોંધપાત્ર રીતે ઝડપી થવાની સંભાવના છે, કારણ કે તે તત્વ કીની પુન recસંગઠન કરતું નથી.
    ///
    ///
    /// જ્યારે લાગુ પડે ત્યારે, અસ્થિર સ sortર્ટિંગને પ્રાધાન્ય આપવામાં આવે છે કારણ કે તે સામાન્ય રીતે સ્થિર સingર્ટિંગ કરતા ઝડપી હોય છે અને તે સહાયક મેમરીને ફાળવતા નથી.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) જુઓ.
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// વર્તમાન અલ્ગોરિધમનો એ [timsort](https://en.wikipedia.org/wiki/Timsort) દ્વારા પ્રેરિત અનુકૂલનશીલ, પુનરાવર્તિત મર્જ સ sortર્ટ છે.
    /// તે એવી સ્થિતિમાં ખૂબ જ ઝડપથી ડિઝાઇન કરવામાં આવી છે કે જ્યાં સ્લાઇસ લગભગ સortedર્ટ થઈ હોય, અથવા તેમાં એક પછી એક બે અથવા વધુ સortedર્ટ સિક્વેન્સ હોય.
    ///
    /// ઉપરાંત, તે `self` ના અડધા કદના અસ્થાયી સ્ટોરેજની ફાળવણી કરે છે, પરંતુ ટૂંકી કાપી નાંખવાને બદલે, બિન-ફાળવણી દાખલ કરવાની સ sortર્ટનો ઉપયોગ થાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// કી નિષ્કર્ષણ વિધેય સાથે સ્લાઇસને સortsર્ટ કરે છે.
    ///
    /// સingર્ટ કરતી વખતે, કી ફંક્શનને તત્વ દીઠ માત્ર એક જ વાર કહેવામાં આવે છે.
    ///
    /// આ સ sortર્ટ સ્થિર છે (એટલે કે, સમાન તત્વોને ફરીથી ગોઠવતો નથી) અને *O*(*m*\* * n *+ n* n *log(* n *)) સૌથી ખરાબ કેસ છે, જ્યાં કી ફંક્શન* O *(* m *) છે .
    ///
    /// સરળ કી કાર્યો માટે (દા.ત., સંપત્તિ cesક્સેસ અથવા મૂળ ક્રિયાઓ એવા કાર્યો) માટે, [`sort_by_key`](slice::sort_by_key) ઝડપી થવાની સંભાવના છે.
    ///
    /// # વર્તમાન અમલીકરણ
    ///
    /// હાલનું અલ્ગોરિધમનો ઓર્સન પીટર્સ દ્વારા [pattern-defeating quicksort][pdqsort] પર આધારિત છે, જે રેન્ડમાઇઝ્ડ ક્વિક્સોર્ટના ઝડપી સરેરાશ કેસને હીપસોર્ટના સૌથી ખરાબ કેસ સાથે જોડે છે, જ્યારે અમુક દાખલાની સાથે કાપી નાંખ્યું પર રેખીય સમય પ્રાપ્ત કરે છે.
    /// ડિજનરેટ કેસોને ટાળવા માટે તે કેટલાક રેન્ડમાઇઝેશનનો ઉપયોગ કરે છે, પરંતુ હંમેશા નિવારક વર્તન પ્રદાન કરવા માટે નિશ્ચિત ઝેડ સીડ 0 ઝેડ સાથે.
    ///
    /// સૌથી ખરાબ કિસ્સામાં, અલ્ગોરિધમનો એક ટુકડાની લંબાઈ `Vec<(K, usize)>` માં અસ્થાયી સ્ટોરેજ ફાળવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ફાળવણી ઘટાડવા માટે, નાના નાના નાના નાના પ્રકારો દ્વારા અમારા ઝેડવેક્ટર 0 ઝેડને અનુક્રમણિકા માટે સહાયક મેક્રો.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` ના તત્વો અનન્ય છે, કારણ કે તે અનુક્રમિત છે, તેથી કોઈપણ પ્રકારની મૂળ સ્લાઇસના સંદર્ભમાં સ્થિર રહેશે.
                // અમે અહીં `sort_unstable` નો ઉપયોગ કરીએ છીએ કારણ કે તેને ઓછી મેમરી ફાળવણીની જરૂર છે.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` ને નવી `Vec` માં ક Copપિ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // અહીં, `s` અને `x` સ્વતંત્ર રીતે સુધારી શકાય છે.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ફાળવણીકાર સાથે નવી `Vec` માં `self` ની ક Copપિ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // અહીં, `s` અને `x` સ્વતંત્ર રીતે સુધારી શકાય છે.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // એનબી, વધુ વિગતો માટે આ ફાઇલમાંના `hack` મોડ્યુલને જુઓ.
        hack::to_vec(self, alloc)
    }

    /// ક્લોન્સ અથવા ફાળવણી વિના `self` ને vector માં રૂપાંતરિત કરે છે.
    ///
    /// પરિણામી vector `Vec દ્વારા પાછા બ boxક્સમાં કન્વર્ટ કરી શકાય છે<T>ની `into_boxed_slice` પદ્ધતિ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` હવે તેનો ઉપયોગ કરી શકાતો નથી કારણ કે તે `x` માં રૂપાંતરિત થયો છે.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // એનબી, વધુ વિગતો માટે આ ફાઇલમાંના `hack` મોડ્યુલને જુઓ.
        hack::into_vec(self)
    }

    /// એક સ્લાઇસ `n` વખત પુનરાવર્તિત કરીને ઝેડ 0 વેક્ટર 0 ઝેડ બનાવે છે.
    ///
    /// # Panics
    ///
    /// આ કાર્ય panic કરશે જો ક્ષમતા ઓવરફ્લો થશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ઓવરફ્લો પર એક ઝેડ 0 સ્પેનિક 0 ઝેડ:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // જો `n` શૂન્યથી મોટો હોય, તો તે `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` તરીકે વિભાજિત થઈ શકે છે.
        // `2^expn` `n` ના ડાબી બાજુના '1' બીટ દ્વારા દર્શાવવામાં આવેલી સંખ્યા છે, અને `rem` એ `n` નો બાકીનો ભાગ છે.
        //
        //

        // `set_len()` ને toક્સેસ કરવા માટે `Vec` નો ઉપયોગ કરવો.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` પુનરાવર્તન `buf`-એક્સપ્લોન-વખત બમણી કરીને કરવામાં આવે છે.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // જો `m > 0` હોય, તો બાકીના બિટ્સ બાકીના '1' સુધી છે.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ની ક્ષમતા ધરાવે છે.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ Expn`) પુનરાવર્તન `buf` માંથી જ `rem` X પુનરાવર્તનોની નકલ કરીને કરવામાં આવે છે.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // `2^expn > rem` થી આ નોન-ઓવરલેપિંગ છે.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) ની બરાબર.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` ની સ્લાઈસને એકલ મૂલ્ય `Self::Output` માં ફ્લેટ કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// દરેકની વચ્ચે આપેલ વિભાજક મૂકીને, એકલ મૂલ્ય `Self::Output` માં `T` ની ટુકડો ફ્લેટ કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// દરેકની વચ્ચે આપેલ વિભાજક મૂકીને, એકલ મૂલ્ય `Self::Output` માં `T` ની ટુકડો ફ્લેટ કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// આ સ્લાઈસની ક containingપિવાળી એક ઝેડ 0 વેક્ટર 0 ઝેડ પરત કરે છે જ્યાં દરેક બાઇટ તેના ASCII અપર કેસ સમકક્ષ સાથે મેપ કરેલી હોય છે.
    ///
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// સ્થળને મૂલ્યમાં મોટા કરવા માટે, [`make_ascii_uppercase`] નો ઉપયોગ કરો.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// આ સ્લાઈસની ક containingપિવાળી ઝેડ 0 વેક્ટર 0 ઝેડ પરત કરે છે જ્યાં દરેક બાઇટ તેના ASCII લોઅર કેસ સમકક્ષ સાથે મેપ કરવામાં આવે છે.
    ///
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// જગ્યામાં મૂલ્ય ઘટાડવા માટે, [`make_ascii_lowercase`] નો ઉપયોગ કરો.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// વિશિષ્ટ પ્રકારના ડેટા પરના ટુકડા માટે ઝેડટ્રેટિટ્સ ઝેડ એક્સ્ટેંશન
////////////////////////////////////////////////////////////////////////////////

/// [`[ટી]: : ક`નકાટ](સ્લાઇસ::કોનકટ) માટે સહાયક ઝેડટ્રેટ 0 ઝેડ.
///
/// Note: `Item` પ્રકારનો પરિમાણ આ trait માં વપરાયેલ નથી, પરંતુ તે ઇમ્પલ્સને વધુ સામાન્ય બનાવવાની મંજૂરી આપે છે.
/// તેના વિના, આપણે આ ભૂલ મેળવીએ છીએ:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// આ એટલા માટે છે કારણ કે ઘણા `Borrow<[_]>` ઇમ્પલ્સ સાથે `V` પ્રકારો અસ્તિત્વમાં હોઈ શકે છે, જેમ કે બહુવિધ `T` પ્રકારો લાગુ થશે:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// કન્ડેન્ટેશન પછી પરિણામી પ્રકાર
    type Output;

    /// [`[ટી]: : કોન્કટ`](સ્લાઇસ::કોનકટ) નું અમલીકરણ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[ટી]: : જોડા`](સ્લાઇસ::જોડાઓ) માટે સહાયક ઝેડટ્રેટ0 ઝેડ
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// કન્ડેન્ટેશન પછી પરિણામી પ્રકાર
    type Output;

    /// [`[ટી]: : જોડા`] નું અમલીકરણ (સ્લાઇસ::જોડાઓ)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// સ્લાઇસેસ માટે માનક trait અમલીકરણો
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // લક્ષ્યમાં કંઈપણ છોડો જે ફરીથી લખાશે નહીં
        target.truncate(self.len());

        // target.len <= self.len ઉપરના કાપવાના કારણે, તેથી અહીં કાપી નાંખ્યું હંમેશા ઇન-બાઉન્ડ હોય છે.
        //
        let (init, tail) = self.split_at(target.len());

        // સમાયેલ મૂલ્યો allocations/resources નો ફરીથી ઉપયોગ કરો.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` ને પૂર્વ-સortedર્ટ કરેલા ક્રમ `v[1..]` માં દાખલ કરે છે જેથી સમગ્ર `v[..]` સ .ર્ટ થાય.
///
/// આ નિવેશ સ sortર્ટનું અભિન્ન સબરૂટિન છે.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // અહીં નિવેશ લાગુ કરવાના ત્રણ રસ્તાઓ છે:
            //
            // 1. જ્યાં સુધી પ્રથમ તેની અંતિમ મુકામ પર ન આવે ત્યાં સુધી અડીને તત્વોને અદલાબદલ કરો.
            //    જો કે, આ રીતે અમે જરૂરી કરતાં વધુની આસપાસ ડેટાની ક copyપિ કરીએ છીએ.
            //    જો તત્વો મોટી રચનાઓ હોય (નકલ કરવા માટે ખર્ચાળ), તો આ પદ્ધતિ ધીમી હશે.
            //
            // 2. જ્યાં સુધી પ્રથમ તત્વ માટે યોગ્ય સ્થાન ન મળે ત્યાં સુધી ઇટેરેટ કરો.
            // પછી તેના માટે જગ્યા બનાવવા માટે તેના પછીના તત્વોને શિફ્ટ કરો અને અંતે તેને બાકીના છિદ્રમાં મૂકો.
            // આ એક સારી પદ્ધતિ છે.
            //
            // 3. પ્રથમ તત્વને અસ્થાયી ચલમાં ક Copyપિ કરો.જ્યાં સુધી તે માટે યોગ્ય સ્થાન ન મળે ત્યાં સુધી ઇટેરેટ કરો.
            // જેમ જેમ આપણે આગળ વધીએ છીએ તેમ, દરેક વટાવેલા તત્વની પહેલાંના સ્લોટમાં ક copyપિ કરો.
            // છેલ્લે, બાકીના છિદ્રમાં અસ્થાયી ચલમાંથી ડેટાની નકલ કરો.
            // આ પદ્ધતિ ખૂબ સારી છે.
            // બેંચમાર્કે 2 જી પદ્ધતિની તુલનામાં થોડું સારું પ્રદર્શન દર્શાવ્યું.
            //
            // બધી પદ્ધતિઓ બેંચમાર્કવાળી હતી, અને 3 જીએ શ્રેષ્ઠ પરિણામો દર્શાવ્યા.તેથી અમે તે પસંદ કર્યું.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // નિવેશ પ્રક્રિયાની મધ્યવર્તી સ્થિતિ હંમેશાં `hole` દ્વારા ટ્ર isક કરવામાં આવે છે, જે બે હેતુઓને પૂર્ણ કરે છે:
            // 1. `is_less` માં panics થી `v` ની અખંડિતતાનું રક્ષણ કરે છે.
            // 2. અંતમાં `v` માં બાકીના છિદ્ર ભરો.
            //
            // Panic સલામતી:
            //
            // જો પ્રક્રિયા દરમ્યાન કોઈપણ બિંદુએ `is_less` panics, `hole` નીચે આવશે અને `tmp` માં છિદ્રોને `tmp` સાથે ભરી દેશે, આમ સુનિશ્ચિત કરે છે કે `v` હજી પણ તે દરેક objectબ્જેક્ટ ધરાવે છે જે શરૂઆતમાં તે બરાબર એક વખત યોજાયો હતો.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` છોડી દેવામાં આવે છે અને તેથી `v` ને બાકીના છિદ્રમાં `v` ની નકલ કરે છે.
        }
    }

    // જ્યારે છોડી દેવામાં આવે ત્યારે, `src` માંથી `dest` માંની નકલો.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// અસ્થાયી સ્ટોરેજ તરીકે `buf` નો ઉપયોગ કરીને બિન-ઘટતા રન `v[..mid]` અને `v[mid..]` ને મર્જ કરે છે, અને પરિણામને `v[..]` માં સ્ટોર કરે છે.
///
/// # Safety
///
/// બે કાપી નાંખેલી જગ્યા ખાલી હોવી આવશ્યક છે અને `mid` મર્યાદામાં હોવી આવશ્યક છે.
/// ટૂંકી સ્લાઇસની નકલ રાખવા માટે બફર `buf` લાંબો સમય હોવો જોઈએ.
/// ઉપરાંત, `T` એ શૂન્ય કદના પ્રકારનો ન હોવો જોઈએ.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // મર્જ પ્રક્રિયા પહેલા `buf` માં ટૂંકા ગાળાની નકલ કરે છે.
    // પછી તે નવા કiedપિ કરેલા રન અને લાંબા ગાળાના આગળ (અથવા પાછળની બાજુ) ને શોધી કા .ે છે, તેમના આગલા અસામાન્ય તત્વોની તુલના કરીને અને `v` માં ઓછા (અથવા વધુ) ની નકલ કરે છે.
    //
    // ટૂંક સમયમાં ટૂંકા રનનો સંપૂર્ણ વપરાશ થાય છે, પ્રક્રિયા કરવામાં આવે છે.જો લાંબા ગાળે પહેલા વપરાશ થાય છે, તો પછી આપણે ટૂંકા ગાળાની બાકીની જે પણ બાકી છે તે `v` માં બાકીના છિદ્રમાં નકલ કરવી જોઈએ.
    //
    // પ્રક્રિયાની મધ્યવર્તી સ્થિતિ હંમેશાં `hole` દ્વારા ટ્રedક કરવામાં આવે છે, જે બે હેતુઓને પૂર્ણ કરે છે:
    // 1. `is_less` માં panics થી `v` ની અખંડિતતાનું રક્ષણ કરે છે.
    // 2. જો લાંબા ગાળે પહેલા વપરાશ થાય તો `v` માં બાકીનો છિદ્ર ભરો.
    //
    // Panic સલામતી:
    //
    // જો પ્રક્રિયા દરમ્યાન કોઈપણ બિંદુએ `is_less` panics, `hole` નીચે આવશે અને `buf` માં છુપા ભરીને `buf` માં અસામાન્ય શ્રેણી સાથે ભરો, આમ સુનિશ્ચિત કરે છે કે `v` હજી પણ દરેક પદાર્થ ધરાવે છે જે શરૂઆતમાં તે બરાબર એક વખત યોજાયો હતો.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ડાબી રન ટૂંકા હોય છે.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // શરૂઆતમાં, આ નિર્દેશકો તેમની એરેની શરૂઆત તરફ નિર્દેશ કરે છે.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // ઓછી બાજુનો વપરાશ કરો.
            // જો સમાન હોય, તો સ્થિરતા જાળવવા ડાબી બાજુ પસંદ કરો.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // જમણી રન ટૂંકી છે.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // શરૂઆતમાં, આ નિર્દેશકો તેમની એરેના અંત તરફ નિર્દેશ કરે છે.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // મોટી બાજુનો વપરાશ કરો.
            // જો સમાન હોય, તો સ્થિરતા જાળવવા માટે યોગ્ય રનને પસંદ કરો.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // છેવટે, `hole` નીચે આવી જાય છે.
    // જો ટૂંકા રનનો સંપૂર્ણ વપરાશ કરવામાં ન આવ્યો હોય, તો તેમાં જે કંઈ બાકી છે તે હવે `v` માં છિદ્રમાં ક copપિ થઈ જશે.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // જ્યારે છોડી દેવામાં આવે ત્યારે, `start..end` રેન્જની `dest..` માં કiesપિ કરો.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` તે શૂન્ય કદના પ્રકારનો નથી, તેથી તેના કદ દ્વારા વિભાજીત કરવાનું ઠીક છે.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// આ મર્જ સ sortર્ટ ટિમસોર્ટના કેટલાક (પરંતુ બધા નહીં) વિચારો ઉધાર લે છે, જેનું વિગતવાર [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) માં વર્ણવેલ છે.
///
///
/// અલ્ગોરિધમનો સખત રીતે ઉતરતા અને નીચે ઉતરતા અનુગામીને ઓળખે છે, જેને કુદરતી રન કહેવામાં આવે છે.મર્જ કરવા માટે બાકી બાકી છેક રનનો સ્ટેક બાકી છે.
/// દરેક નવા મળેલા રનને સ્ટેક પર ધકેલી દેવામાં આવે છે, અને પછી આ બે આક્રમણકારો સંતોષ ન થાય ત્યાં સુધી અડીને રનની કેટલીક જોડી મર્જ કરવામાં આવે છે:
///
/// 1. `1..runs.len()` માં દરેક `i` માટે: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` માં દરેક `i` માટે: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// આક્રમણકારો સુનિશ્ચિત કરે છે કે કુલ ચાલી રહેલ સમય *ઓ*(*n*\*log(* n*)) સૌથી ખરાબ કેસ) છે.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // આ લંબાઈ સુધીની કાપી નાંખવાના સ sortર્ટની મદદથી સ getર્ટ થાય છે.
    const MAX_INSERTION: usize = 20;
    // ઓછામાં ઓછા આ ઘણા તત્વોને વિસ્તૃત કરવા માટે નિવેશ સ sortર્ટનો ઉપયોગ કરીને ખૂબ ટૂંકા રન વિસ્તૃત કરવામાં આવે છે.
    const MIN_RUN: usize = 10;

    // સ zeroર્ટિંગમાં શૂન્ય-કદના પ્રકારો પર કોઈ અર્થપૂર્ણ વર્તણૂક નથી.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // ફાળવણી ટાળવા માટે ટૂંકા એરેને દાખલ સ sortર્ટ દ્વારા સ્થાનેથી સortedર્ટ કરવામાં આવે છે.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // સ્ક્રેચ મેમરી તરીકે વાપરવા માટે બફર ફાળવો.અમે લંબાઈ 0 રાખીએ છીએ જેથી `is_less` panics જો નકલો પર ચાલતા ડtorsટરોને જોખમમાં લીધા વિના અમે તેમાં `v` ની સામગ્રીની છીછરી નકલો રાખી શકીએ.
    //
    // જ્યારે બે સortedર્ટ કરેલા રન મર્જ થાય છે, ત્યારે આ બફર ટૂંકા રનની એક ક holdsપિ ધરાવે છે, જેની લંબાઈ હંમેશાં `len / 2` X હશે.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` માં કુદરતી રનને ઓળખવા માટે, અમે તેને પાછળની બાજુએ જઇએ છીએ.
    // તે એક વિચિત્ર નિર્ણય જેવું લાગે છે, પરંતુ આ હકીકતને ધ્યાનમાં લો કે મર્જ થાય છે તે ઘણીવાર વિરુદ્ધ દિશામાં (forwards) માં જાય છે.
    // બેંચમાર્ક અનુસાર, આગળ મર્જ કરવું પાછળની બાજુ મર્જ કરતા સહેજ ઝડપી છે.
    // નિષ્કર્ષ કા backવા માટે, પાછળની બાજુએ વટાવીને રનની ઓળખ કરવાથી કામગીરીમાં સુધારો થાય છે.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // આગળનો કુદરતી રન શોધો અને જો તે સખત રીતે ઉતરતો હોય તો તેને ઉલટાવી દો.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // જો તે ખૂબ ટૂંકા હોય તો રનમાં કેટલાક વધુ તત્વો શામેલ કરો.
        // ટૂંકું અનુક્રમો પર મર્જ સ thanર્ટ કરતા ઇન્સેશન સ sortર્ટ ઝડપી છે, તેથી આ પ્રભાવમાં નોંધપાત્ર સુધારે છે.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // આ રનને સ્ટેક પર દબાણ કરો.
        runs.push(Run { start, len: end - start });
        end = start;

        // આક્રમણકારોને સંતોષવા માટે અડીને આવેલા કેટલાક જોડોને જોડો.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // અંતે, બરાબર એક રન સ્ટેકમાં રહેવું જ જોઇએ.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // રનના સ્ટેકની તપાસ કરે છે અને મર્જ કરવા માટે આગળની જોડની ઓળખ કરે છે.
    // વધુ વિશિષ્ટ રીતે, જો `Some(r)` પરત કરવામાં આવે છે, તો તેનો અર્થ એ કે આગળ `runs[r]` અને `runs[r + 1]` મર્જ કરવું આવશ્યક છે.
    // જો એલ્ગોરિધમનો બદલે નવી રન બનાવવાનું ચાલુ રાખવું જોઈએ, તો `None` પરત આવે છે.
    //
    // ટિમસોર્ટ તેના બગડેલ અમલીકરણ માટે કુખ્યાત છે, અહીં વર્ણવ્યા પ્રમાણે:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // વાર્તાનો ભાવાર્થ છે: આપણે સ્ટેક પર આક્રમણોને ટોચનાં ચાર રન પર અમલમાં મૂકવા જોઈએ.
    // તેમને ફક્ત ટોચના ત્રણ પર અમલ કરવો તે સુનિશ્ચિત કરવા માટે પૂરતું નથી કે આક્રમણકારો હજી પણ સ્ટેકમાં તમામ *રન* રાખે છે.
    //
    // આ ફંક્શન ટોચના ચાર રન માટે આક્રમકોને યોગ્ય રીતે તપાસે છે.
    // આ ઉપરાંત, જો ટોચનો ભાગ અનુક્રમણિકા 0 પર શરૂ થાય છે, તો તે સ alwaysર્ટને પૂર્ણ કરવા માટે, સ્ટેક સંપૂર્ણપણે ભંગાણ ન થાય ત્યાં સુધી તે હંમેશા મર્જ ઓપરેશનની માંગ કરશે.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}