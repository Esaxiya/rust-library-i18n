//! # Rust કોર ફાળવણી અને સંગ્રહ સંગ્રહાલય
//!
//! આ લાઇબ્રેરી apગલાબંધ ફાળવેલ મૂલ્યોના સંચાલન માટે સ્માર્ટ પોઇંટ્સ અને સંગ્રહ પ્રદાન કરે છે.
//!
//! આ લાઇબ્રેરી, લિબકોરની જેમ, સામાન્ય રીતે સીધા ઉપયોગ કરવાની જરૂર હોતી નથી કારણ કે તેની સામગ્રી [`std` crate](../std/index.html) માં ફરીથી નિકાસ કરવામાં આવે છે.
//! Crates કે જે `#![no_std]` એટ્રિબ્યુટનો ઉપયોગ કરે છે તે સામાન્ય રીતે `std` પર આધારિત નથી, તેથી તેઓ તેના બદલે આ crate નો ઉપયોગ કરશો.
//!
//! ## બોક્સવાળી કિંમતો
//!
//! [`Box`] પ્રકાર એ સ્માર્ટ પોઇન્ટર પ્રકાર છે.એક [`Box`] નો ફક્ત એક જ માલિક હોઈ શકે છે, અને માલિક સમાવિષ્ટોને ફેરવવાનું નક્કી કરી શકે છે, જે theગલા પર રહે છે.
//!
//! આ પ્રકારને થ્રેડ્સ વચ્ચે અસરકારક રીતે મોકલી શકાય છે કારણ કે `Box` મૂલ્યનું કદ પોઇન્ટરની જેમ જ છે.
//! વૃક્ષ જેવા ડેટા સ્ટ્રક્ચર્સ ઘણીવાર બ withક્સીસથી બનેલા હોય છે કારણ કે દરેક નોડમાં હંમેશાં એક જ માલિક હોય છે, પિતૃ.
//!
//! ## સંદર્ભ ગણાય પોઇંટર્સ
//!
//! [`Rc`] પ્રકાર એ થ્રેડમાં મેમરીને શેર કરવા માટે બનાવાયેલ નોન-થ્રેડસાફે સંદર્ભ-ગણતરી કરેલ પોઇન્ટર પ્રકાર છે.
//! એક [`Rc`] નિર્દેશક એક પ્રકાર, `T` લપેટી, અને ફક્ત `&T`, શેર કરેલા સંદર્ભની allowsક્સેસને મંજૂરી આપે છે.
//!
//! આ પ્રકારનો ઉપયોગી છે જ્યારે વારસાગત પરિવર્તન (જેમ કે [`Box`] નો ઉપયોગ કરવો) એપ્લિકેશન માટે ખૂબ જ મર્યાદિત હોય છે, અને પરિવર્તનને મંજૂરી આપવા માટે ઘણીવાર [`Cell`] અથવા [`RefCell`] પ્રકારો સાથે જોડાય છે.
//!
//!
//! ## અણુ સંદર્ભ સંદર્ભિત ગણાય છે
//!
//! [`Arc`] પ્રકાર એ [`Rc`] પ્રકારનો થ્રેડસેફ સમકક્ષ છે.તે [`Rc`] ની બધી સમાન વિધેય પ્રદાન કરે છે, સિવાય કે તેમાં સમાવિષ્ટ પ્રકાર `T` શેર કરવા યોગ્ય છે.
//! વધારામાં, [`Arc<T>`][`Arc`] પોતે મોકલવા યોગ્ય છે જ્યારે [`Rc<T>`][`Rc`] નથી.
//!
//! આ પ્રકાર સમાયેલ ડેટાની વહેંચણી forક્સેસની મંજૂરી આપે છે અને શેર કરેલા સંસાધનોના પરિવર્તનને મંજૂરી આપવા માટે મ્યુટેક્સ જેવા સિંક્રનાઇઝેશન પ્રાચીન સાથે ઘણીવાર જોડી બનાવવામાં આવે છે.
//!
//! ## Collections
//!
//! સૌથી સામાન્ય સામાન્ય હેતુ ડેટા સ્ટ્રક્ચર્સના અમલીકરણો આ લાઇબ્રેરીમાં વ્યાખ્યાયિત કરવામાં આવ્યા છે.તેઓ [standard collections library](../std/collections/index.html) દ્વારા ફરીથી નિકાસ કરવામાં આવે છે.
//!
//! ## .ગલા ઇન્ટરફેસો
//!
//! [`alloc`](alloc/index.html) મોડ્યુલ નીચલા-સ્તરના ઇન્ટરફેસને ડિફોલ્ટ વૈશ્વિક ફાળવણીકારને વ્યાખ્યાયિત કરે છે.તે libc ફાળવણીકાર API સાથે સુસંગત નથી.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// તકનીકી રૂપે, આ રસ્ટડોકમાં ભૂલ છે: રસ્ટડોક `#[lang = slice_alloc]` બ્લોક્સ પરના દસ્તાવેજોને `&[T]` માટે જુએ છે, જેમાં `core` માં આ સુવિધાનો ઉપયોગ કરીને દસ્તાવેજો પણ છે અને તે પાગલ થઈ જાય છે કે લક્ષણ-ગેટ સક્ષમ નથી.
// આદર્શરીતે, તે અન્ય ઝેડ 0 ક્રેટ્સ 0 ઝેડના ડsક્સ માટેના વિશેષતાના દરવાજાની તપાસ કરશે નહીં, પરંતુ આ ફક્ત લ langંગ આઇટમ્સ માટે જ દેખાઈ શકે છે, તેથી તે ફિક્સિંગ યોગ્ય લાગતું નથી.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// આ પુસ્તકાલયના પરીક્ષણને મંજૂરી આપો

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// અન્ય મોડ્યુલો દ્વારા ઉપયોગમાં લેવાતા આંતરિક મેક્રોઝ સાથેનું મોડ્યુલ (અન્ય મોડ્યુલો પહેલાં શામેલ હોવું જરૂરી છે).
#[macro_use]
mod macros;

// નિમ્ન-સ્તરની ફાળવણી વ્યૂહરચના માટે providedગલો પૂરા પાડવામાં આવે છે

pub mod alloc;

// ઉપરના usingગલાનો ઉપયોગ કરીને આદિમ પ્રકાર

// કસોટી સીએફજીમાં બિલ્ડ કરતી વખતે લેંગ-આઇટમની ડુપ્લિકેટ ટાળવા માટે `boxed.rs` માંથી મોડને શરતી રીતે વ્યાખ્યાયિત કરવાની જરૂર છે;પણ `use boxed::Box;` ઘોષણાઓને કોડને મંજૂરી આપવાની જરૂર છે.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}