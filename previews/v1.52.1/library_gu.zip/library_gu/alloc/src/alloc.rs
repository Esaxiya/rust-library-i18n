//! મેમરી ફાળવણી API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // વૈશ્વિક ફાળવણીકારને ક callલ કરવા માટે આ જાદુઈ પ્રતીકો છે.ઝેડ 0 રસ્ટક0 ઝેડ તેમને `__rg_alloc` વગેરેને ક toલ કરવા માટે બનાવે છે.
    // જો ત્યાં કોઈ `#[global_allocator]` એટ્રિબ્યુટ (કોડ વિસ્તૃત કરે છે કે જે લક્ષણ મેક્રો તે કાર્યોને ઉત્પન્ન કરે છે), અથવા લિબ્સ્ટડી (`__rdl_alloc` વગેરે) માં ડિફોલ્ટ અમલીકરણોને ક callલ કરવા માટે.
    //
    // `library/std/src/alloc.rs` માં) અન્યથા.
    // એલએલવીએમના ઝેડ 0 ર્રસ્ટ્ક 0 ઝેડ 0 ફોરક 0 ઝેડ પણ વિધેયોના નામોને અનુક્રમે `malloc`, `realloc` અને `free` જેવા તેમને optimપ્ટિમાઇઝ કરવા માટે સક્ષમ કરવા માટેના ખાસ કિસ્સાઓમાં છે.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// વૈશ્વિક મેમરી ફાળવણીકાર.
///
/// આ પ્રકાર, `#[global_allocator]` લક્ષણ સાથે નોંધાયેલા ફાળવણીકારને ક callsલ ફોરવર્ડ કરીને [`Allocator`] trait ને લાગુ કરે છે જો ત્યાં એક છે, અથવા `std` crate નો ડિફોલ્ટ છે.
///
///
/// Note: જ્યારે આ પ્રકાર અસ્થિર છે, તે જે કાર્યક્ષમતા પ્રદાન કરે છે તે [free functions in `alloc`](self#functions) દ્વારા cesક્સેસ કરી શકાય છે.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// વૈશ્વિક ફાળવણીકાર સાથે મેમરી ફાળવો.
///
/// આ ફંક્શન `#[global_allocator]` લક્ષણ સાથે નોંધાયેલ ફાળવણીકારની [`GlobalAlloc::alloc`] પદ્ધતિને ક defaultલ કરે છે, જો ત્યાં એક છે, અથવા `std` crate નો ડિફોલ્ટ છે.
///
///
/// જ્યારે [`Global`] પ્રકાર અને [`Allocator`] trait સ્થિર થાય ત્યારે [`Global`] પ્રકારની `alloc` પદ્ધતિની તરફેણમાં આ કાર્યને અવમૂલ્યન થવાની અપેક્ષા છે.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] જુઓ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// વૈશ્વિક ફાળવણીકાર સાથે મેમરી અધોગતિ.
///
/// આ ફંક્શન `#[global_allocator]` લક્ષણ સાથે નોંધાયેલ ફાળવણીકારની [`GlobalAlloc::dealloc`] પદ્ધતિને ક defaultલ કરે છે, જો ત્યાં એક છે, અથવા `std` crate નો ડિફોલ્ટ છે.
///
///
/// જ્યારે [`Global`] પ્રકાર અને [`Allocator`] trait સ્થિર થાય ત્યારે [`Global`] પ્રકારની `dealloc` પદ્ધતિની તરફેણમાં આ કાર્યને અવમૂલ્યન થવાની અપેક્ષા છે.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] જુઓ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// વૈશ્વિક ફાળવણીકાર સાથે મેમરી ફરીથી કહો.
///
/// આ ફંક્શન `#[global_allocator]` લક્ષણ સાથે નોંધાયેલ ફાળવણીકારની [`GlobalAlloc::realloc`] પદ્ધતિને ક defaultલ કરે છે, જો ત્યાં એક છે, અથવા `std` crate નો ડિફોલ્ટ છે.
///
///
/// જ્યારે [`Global`] પ્રકાર અને [`Allocator`] trait સ્થિર થાય છે ત્યારે [`Global`] પ્રકારની `realloc` પદ્ધતિની તરફેણમાં આ કાર્યને અવમૂલ્યન થવાની અપેક્ષા છે.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] જુઓ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// વૈશ્વિક ફાળવણીકાર સાથે શૂન્ય-પ્રારંભિક મેમરી ફાળવો.
///
/// આ ફંક્શન `#[global_allocator]` લક્ષણ સાથે નોંધાયેલ ફાળવણીકારની [`GlobalAlloc::alloc_zeroed`] પદ્ધતિને ક defaultલ કરે છે, જો ત્યાં એક છે, અથવા `std` crate નો ડિફોલ્ટ છે.
///
///
/// જ્યારે [`Global`] પ્રકાર અને [`Allocator`] trait સ્થિર થાય ત્યારે [`Global`] પ્રકારની `alloc_zeroed` પદ્ધતિની તરફેણમાં આ કાર્યને અવમૂલ્યન થવાની અપેક્ષા છે.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] જુઓ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // સલામતી: `layout` કદમાં શૂન્ય નથી,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // સલામતી: `Allocator::grow` ની જેમ
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // સલામતી: `new_size` એ X-X X કરતા વધારે અથવા તેની સમાન હોવાથી `new_size` એ શૂન્ય નથી
            // સલામતી શરતો દ્વારા જરૂરી છે.ક conditionsલર દ્વારા અન્ય શરતોને સમર્થન આપવું આવશ્યક છે
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` સંભવત `new_size >= old_layout.size()` અથવા કંઈક બીજું માટે તપાસ કરે છે.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // સલામતી: કારણ કે `new_layout.size()` `old_size` કરતા વધારે અથવા તેના કરતા વધુ હોવો જોઈએ,
            // બંને જૂની અને નવી મેમરી ફાળવણી `old_size` બાઇટ્સ માટે વાંચવા અને લખવા માટે માન્ય છે.
            // ઉપરાંત, કારણ કે જૂની ફાળવણી હજી ડિલોડેક્ટેડ નહોતી, તે `new_ptr` ને ઓવરલેપ કરી શકશે નહીં.
            // આમ, `copy_nonoverlapping` પર ક callલ સલામત છે.
            // ક00લર દ્વારા `dealloc` માટે સલામતી કરાર હોવો જ જોઇએ.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // સલામતી: `layout` કદમાં શૂન્ય નથી,
            // ક conditionsલર દ્વારા અન્ય શરતોને સમર્થન આપવું આવશ્યક છે
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // સલામત: ક allલર દ્વારા બધી શરતોને સમર્થન આપવું આવશ્યક છે
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // સલામત: ક allલર દ્વારા બધી શરતોને સમર્થન આપવું આવશ્યક છે
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // સલામતી: ક conditionsલર દ્વારા શરતોને સમર્થન આપવું આવશ્યક છે
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // સલામતી: `new_size` એ શૂન્ય નથી.ક conditionsલર દ્વારા અન્ય શરતોને સમર્થન આપવું આવશ્યક છે
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` સંભવત `new_size <= old_layout.size()` અથવા કંઈક બીજું માટે તપાસ કરે છે.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // સલામતી: કારણ કે `new_size` એ `old_layout.size()` કરતા નાના અથવા સમાન હોવું જોઈએ,
            // બંને જૂની અને નવી મેમરી ફાળવણી `new_size` બાઇટ્સ માટે વાંચવા અને લખવા માટે માન્ય છે.
            // ઉપરાંત, કારણ કે જૂની ફાળવણી હજી ડિલોડેક્ટેડ નહોતી, તે `new_ptr` ને ઓવરલેપ કરી શકશે નહીં.
            // આમ, `copy_nonoverlapping` પર ક callલ સલામત છે.
            // ક00લર દ્વારા `dealloc` માટે સલામતી કરાર હોવો જ જોઇએ.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// અનન્ય પોઇંટર્સ માટે ફાળવણીકાર.
// આ ફંક્શન અનઇન્ડ કરવું જોઈએ નહીં.જો તે થાય છે, એમઆઇઆર કોડજેન નિષ્ફળ જશે.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// આ હસ્તાક્ષર `Box` જેવું જ હોવું જોઈએ, નહીં તો આઈસીઇ થશે.
// જ્યારે `Box` માં એક વધારાનો પરિમાણ ઉમેરવામાં આવે છે (જેમ કે `A: Allocator`), આ પણ અહીં ઉમેરવું પડશે.
// ઉદાહરણ તરીકે જો `Box` ને `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` માં બદલવામાં આવે છે, તો આ કાર્યને `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` માં પણ બદલવું પડશે.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ફાળવણી ભૂલ નિયંત્રક

extern "Rust" {
    // આ વૈશ્વિક ફાળવણી ભૂલ નિયંત્રકને ક callલ કરવા માટેનું જાદુઈ પ્રતીક છે.
    // rustc જો ત્યાં કોઈ `#[alloc_error_handler]` હોય તો તેને `__rg_oom` પર ક callલ કરવા માટે અથવા (`__rdl_oom`) ની નીચેના ડિફોલ્ટ અમલીકરણોને ક callલ કરવા માટે બનાવે છે.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// મેમરી ફાળવણી ભૂલ અથવા નિષ્ફળતા પર છોડી દો.
///
/// ફાળવણીની ભૂલના જવાબમાં ગણતરીને છોડી દેવા ઇચ્છતા મેમરી ફાળવણી એપીઆઇના કlersલર્સને સીધા `panic!` અથવા તેના જેવા જ સીધા પૂછવાને બદલે આ ફંક્શનને ક toલ કરવા માટે પ્રોત્સાહિત કરવામાં આવે છે.
///
///
/// આ કાર્યની ડિફ Theલ્ટ વર્તણૂક માનક ભૂલ પર સંદેશ છાપવા અને પ્રક્રિયાને છોડી દેવાની છે.
/// તે [`set_alloc_error_hook`] અને [`take_alloc_error_hook`] સાથે બદલી શકાય છે.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// ફાળવણી પરીક્ષણ માટે `std::alloc::handle_alloc_error` નો સીધો ઉપયોગ કરી શકાય છે.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // `__rust_alloc_error_handler` જનરેટ દ્વારા કહેવામાં આવે છે

    // જો ત્યાં કોઈ `#[alloc_error_handler]` નથી
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // જો ત્યાં `#[alloc_error_handler]` હોય
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// પૂર્વ-ફાળવેલ, અનઇંટિઆલાઇઝ્ડ મેમરીમાં ક્લોન્સને વિશેષતા આપો.
/// `Box::clone` અને `Rc`/`Arc::make_mut` દ્વારા વપરાયેલ.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *પ્રથમ* ફાળવવાથી optimપ્ટિમાઇઝરને સ્થળ પર ક્લોન કરેલ મૂલ્ય બનાવવા માટે, સ્થાનિક છોડીને ખસેડવાની મંજૂરી આપી શકે છે.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // કોઈ સ્થાનિક મૂલ્ય શામેલ કર્યા વિના, અમે હંમેશાં સ્થાને ક copyપિ કરી શકીએ છીએ.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}