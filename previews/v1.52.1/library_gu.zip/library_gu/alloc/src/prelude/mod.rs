//! ફાળવણી Preide
//!
//! આ મોડ્યુલનો ઉદ્દેશ એ `alloc` crate ની સામાન્ય રીતે ઉપયોગમાં આવતી વસ્તુઓની આયાતને ઘટાડવાનો છે મોડ્યુલોની ટોચ પર ગ્લોબ આયાત ઉમેરીને:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;