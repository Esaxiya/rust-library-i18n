//! સિંગલ-થ્રેડેડ સંદર્ભ-ગણતરી પોઇંટર્સ.'Rc' એટલે 'સંદર્ભ
//! Counted'.
//!
//! પ્રકાર [`Rc<T>`][`Rc`], Xગલામાં ફાળવવામાં આવેલા પ્રકાર `T` ની કિંમતની વહેંચાયેલ માલિકી પ્રદાન કરે છે.
//! [`Rc`] પર [`clone`][clone] ને ઇન્વkingક કરવું એ allocગલામાં સમાન ફાળવણીનું નવું નિર્દેશક ઉત્પન્ન કરે છે.
//! જ્યારે આપેલ ફાળવણીનો છેલ્લો [`Rc`] પોઇન્ટર નાશ પામે છે, ત્યારે તે ફાળવણીમાં સંગ્રહિત મૂલ્ય (ઘણીવાર "inner value" તરીકે ઓળખાય છે) પણ છોડી દેવામાં આવે છે.
//!
//! ઝેડ રસ્ટ0 ઝેડમાં શેર કરેલા સંદર્ભો ડિફ defaultલ્ટ રૂપે પરિવર્તનને મંજૂરી આપતા નથી, અને [`Rc`] પણ તેનો અપવાદ નથી: તમે સામાન્ય રીતે [`Rc`] ની અંદરની બાબતમાં પરિવર્તનશીલ સંદર્ભ મેળવી શકતા નથી.
//! જો તમને પરિવર્તનશીલતાની જરૂર હોય, તો [`Rc`] ની અંદર એક [`Cell`] અથવા [`RefCell`] મૂકો;[an example of mutability inside an `Rc`][mutability] જુઓ.
//!
//! [`Rc`] નોન-અણુ સંદર્ભ ગણતરીનો ઉપયોગ કરે છે.
//! આનો અર્થ એ કે ઓવરહેડ ખૂબ નીચું છે, પરંતુ થ્રેડો વચ્ચે એક [`Rc`] મોકલી શકાતો નથી, અને પરિણામે [`Rc`] [`Send`][send] અમલમાં મૂકતું નથી.
//! પરિણામે, ઝેડ 0 રસ્ટ0 ઝેડ કમ્પાઈલર *કમ્પાઇલ સમયે* તપાસો કે તમે [`Rc`] s ને થ્રેડો વચ્ચે મોકલી રહ્યાં નથી.
//! જો તમને મલ્ટિ-થ્રેડેડ, અણુ સંદર્ભ કાઉન્ટિંગની જરૂર હોય, તો [`sync::Arc`][arc] નો ઉપયોગ કરો.
//!
//! [`downgrade`][downgrade] પદ્ધતિ નોન-માલિકીનો [`Weak`] પોઇન્ટર બનાવવા માટે વાપરી શકાય છે.
//! એક [`Weak`] નિર્દેશક એક [`Rc`] પર [`અપગ્રેડ.][અપગ્રેડ] ડી હોઈ શકે છે, પરંતુ જો ફાળવણીમાં સંગ્રહિત મૂલ્ય પહેલાથી જ છોડી દેવામાં આવી હોય તો આ [`None`] પરત કરશે.
//! બીજા શબ્દોમાં કહીએ તો, `Weak` પોઇન્ટર ફાળવણીની અંદરના મૂલ્યને જીવંત રાખતા નથી;જો કે, તેઓ ફાળવણી (આંતરિક મૂલ્ય માટેની બેકિંગ સ્ટોર) જીવંત રાખે છે.
//!
//! [`Rc`] પોઇંટર્સ વચ્ચેનું એક ચક્ર ક્યારેય વિલંબિત થશે નહીં.
//! આ કારણોસર, [`Weak`] નો ઉપયોગ ચક્રને તોડવા માટે થાય છે.
//! ઉદાહરણ તરીકે, એક ઝાડમાં માતાપિતા ગાંઠોથી બાળકોમાં મજબૂત [`Rc`] પોઇંટર્સ, અને બાળકોથી તેમના માતાપિતા સુધીના [`Weak`] પોઇન્ટર હોઈ શકે છે.
//!
//! `Rc<T>` આપમેળે `T` ([`Deref`] trait દ્વારા) નો સંદર્ભ લો, જેથી તમે [`Rc<T>`][`Rc`] પ્રકારનાં મૂલ્ય પર `T` ની પદ્ધતિઓને ક callલ કરી શકો.
//! `T` ની પદ્ધતિઓ સાથે નામના ક્લેશને ટાળવા માટે, [`Rc<T>`][`Rc`] ની પદ્ધતિઓ પોતે જ સંબંધિત કાર્યો છે, જેને [fully qualified syntax] નો ઉપયોગ કરીને કહેવામાં આવે છે:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `આરસી<T>`Clone` જેવા traits ના અમલીકરણોને સંપૂર્ણ ગુણવત્તાવાળું સિન્ટેક્સનો ઉપયોગ કરીને પણ કહી શકાય.
//! કેટલાક લોકો સંપૂર્ણ રીતે લાયક સિન્ટેક્સનો ઉપયોગ કરવાનું પસંદ કરે છે, જ્યારે અન્ય મેથડ-ક callલ સિન્ટેક્સનો ઉપયોગ કરવાનું પસંદ કરે છે.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // પદ્ધતિ-ક callલ વાક્યરચના
//! let rc2 = rc.clone();
//! // સંપૂર્ણ રીતે લાયક વાક્યરચના
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` નો સ્વચાલિત સંદર્ભ લેતો નથી, કારણ કે આંતરિક મૂલ્ય પહેલાથી જ છોડી દેવામાં આવ્યું છે.
//!
//! # ક્લોનીંગ સંદર્ભો
//!
//! હાલના સંદર્ભ ગણાતા પોઇન્ટરની સમાન ફાળવણીમાં એક નવો સંદર્ભ બનાવવો એ [`Rc<T>`][`Rc`] અને [`Weak<T>`][`Weak`] માટે લાગુ `Clone` trait નો ઉપયોગ કરીને કરવામાં આવે છે.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // નીચે બે વાક્યરચના સમાન છે.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a અને b બંને foo જેવા સમાન મેમરી સ્થાન પર નિર્દેશ કરે છે.
//! ```
//!
//! `Rc::clone(&from)` સિન્ટેક્સ સૌથી વધુ મુર્ખામીયુક્ત છે કારણ કે તે કોડના અર્થને વધુ સ્પષ્ટ રીતે દર્શાવે છે.
//! ઉપરના ઉદાહરણમાં, આ વાક્યરચના એ બતાવવાનું વધુ સરળ બનાવે છે કે આ કોડ foo ની સંપૂર્ણ સામગ્રીની નકલ કરવાને બદલે એક નવો સંદર્ભ બનાવે છે.
//!
//! # Examples
//!
//! એક દૃશ્ય ધ્યાનમાં લો જ્યાં `ગેજેટ્સનો સમૂહ આપેલ `Owner` ની માલિકીનો છે.
//! અમે અમારા `ગેજેટ્સનો તેમના `Owner` પર નિર્દેશ કરવા માગીએ છીએ.અમે આ અનન્ય માલિકી સાથે કરી શકતા નથી, કારણ કે એક કરતા વધુ ગેજેટ્સ સમાન `Owner` સાથે સંબંધિત હોઈ શકે છે.
//! [`Rc`] અમને બહુવિધ `ગેજેટ્સ વચ્ચે એક `Owner` શેર કરવાની મંજૂરી આપે છે, અને `Owner` ત્યાં સુધી કોઈપણ `Gadget` પોઇન્ટ્સ સુધી ફાળવવામાં આવે છે.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... અન્ય ક્ષેત્રો
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... અન્ય ક્ષેત્રો
//! }
//!
//! fn main() {
//!     // સંદર્ભ-ગણતરી કરેલ `Owner` બનાવો.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` થી સંબંધિત `ગેજેટ્સ બનાવો.
//!     // `Rc<Owner>` ને ક્લોનીંગ કરવાનું એ જ `Owner` ફાળવણીનું નવું નિર્દેશક આપે છે, જે પ્રક્રિયામાં સંદર્ભની ગણતરીમાં વધારો કરે છે.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // અમારા સ્થાનિક ચલ `gadget_owner` નો નિકાલ કરો.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` છોડવા છતાં, અમે હજી પણ `ગેજેટ્સના `Owner` નું નામ છાપવામાં સક્ષમ છીએ.
//!     // આ એટલા માટે છે કારણ કે અમે ફક્ત એક જ `Rc<Owner>` ને છોડ્યો છે, `Owner` નહીં કે જે તે નિર્દેશ કરે છે.
//!     // જ્યાં સુધી ત્યાં સમાન `Owner` ફાળવણી પર અન્ય `Rc<Owner>` પોઇંટિંગ છે ત્યાં સુધી તે જીવંત રહેશે.
//!     // ફીલ્ડ પ્રોજેક્શન `gadget1.owner.name` કામ કરે છે કારણ કે `Rc<Owner>` આપમેળે `Owner` નો સંદર્ભ લે છે.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ફંક્શનના અંતે, `gadget1` અને `gadget2` નાશ પામે છે, અને તેમની સાથે અમારા `Owner` નો છેલ્લો ગણતરી સંદર્ભો.
//!     // ગેજેટ મેન હવે નાશ પામે છે.
//!     //
//! }
//! ```
//!
//! જો આપણી આવશ્યકતાઓ બદલાઇ જાય, અને આપણે `Owner` થી `Gadget` પર પણ પસાર થવું જોઈએ, તો આપણે સમસ્યાઓમાં દોડી જઈશું.
//! `Owner` થી `Gadget` સુધીનો [`Rc`] નિર્દેશક એક ચક્રનો પરિચય આપે છે.
//! આનો અર્થ એ કે તેમની સંદર્ભ ગણતરીઓ ક્યારેય 0 સુધી પહોંચી શકતી નથી, અને ફાળવણીનો ક્યારેય નાશ થશે નહીં:
//! મેમરી લિકઆને મેળવવા માટે, આપણે [`Weak`] પોઇંટર્સનો ઉપયોગ કરી શકીએ છીએ.
//!
//! ઝેડ રસ્ટ0 ઝેડ ખરેખર પ્રથમ સ્થાને આ લૂપનું નિર્માણ કરવાનું કંઈક અંશે મુશ્કેલ બનાવે છે.એકબીજા પર નિર્દેશ કરેલા બે મૂલ્યો સાથે સમાપ્ત થવા માટે, તેમાંના એકને પરિવર્તનશીલ બનાવવાની જરૂર છે.
//! આ મુશ્કેલ છે કારણ કે [`Rc`] ફક્ત તેને લપેટેલા મૂલ્યના જ વહેંચાયેલા સંદર્ભો આપીને મેમરી સલામતીને લાગુ કરે છે, અને આ સીધા પરિવર્તનની મંજૂરી આપતું નથી.
//! આપણે [`RefCell`] માં પરિવર્તન કરવા માંગીએ છીએ તે મૂલ્યનો ભાગ લપેટવાની જરૂર છે, જે *આંતરિક મ્યુટિબિલિટી* પ્રદાન કરે છે: વહેંચાયેલ સંદર્ભ દ્વારા પરિવર્તન પ્રાપ્ત કરવાની પદ્ધતિ.
//! [`RefCell`] રનટાઇમ પર ઝેડ 0 રસ્ટ0 ઝેડના ઉધારના નિયમો લાગુ કરે છે.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... અન્ય ક્ષેત્રો
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... અન્ય ક્ષેત્રો
//! }
//!
//! fn main() {
//!     // સંદર્ભ-ગણતરી કરેલ `Owner` બનાવો.
//!     // નોંધ લો કે અમે `RefCell` ની અંદર `માલિકના vector નું` ગેજેટ મૂકી દીધું છે જેથી અમે તેને શેર કરેલા સંદર્ભ દ્વારા બદલી શકીએ.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // પહેલાની જેમ, `gadget_owner` થી સંબંધિત `ગેજેટ્સ બનાવો.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // X ગેજેટ્સને તેમના `Owner` પર ઉમેરો.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ગતિશીલ ઉધાર અહીં સમાપ્ત થાય છે.
//!     }
//!
//!     // અમારા `ગેજેટ્સ પર તેની સમીક્ષા કરો, તેમની વિગતો છાપશો.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` એક `Weak<Gadget>` છે.
//!         // `Weak` પોઇંટર ફાળવણીની હજી પણ અસ્તિત્વમાં છે તેની ખાતરી આપી શકતા નથી, તેથી આપણે `upgrade` પર ક .લ કરવાની જરૂર છે, જે `Option<Rc<Gadget>>` આપે છે.
//!         //
//!         //
//!         // આ સ્થિતિમાં આપણે જાણીએ છીએ કે ફાળવણી હજી પણ અસ્તિત્વમાં છે, તેથી અમે ફક્ત `Option` ને `Option`.
//!         // વધુ જટિલ પ્રોગ્રામમાં, તમારે `None` પરિણામ માટે આકર્ષક ભૂલને સંભાળવાની જરૂર પડી શકે છે.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ફંક્શનના અંતે, `gadget_owner`, `gadget1` અને `gadget2` નાશ પામ્યા છે.
//!     // હવે ગેજેટ્સમાં કોઈ મજબૂત (`Rc`) પોઇન્ટર નથી, તેથી તે નાશ પામ્યા છે.
//!     // આ ગેજેટ મેન પર સંદર્ભની ગણતરીને શૂન્ય કરે છે, તેથી તે પણ નાશ પામે છે.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// સંભવિત ફીલ્ડ-ordર્ડરિંગ સામે આ repr(C) થી ઝેડ ફ્યુચર0 ઝેડ-પ્રૂફ છે, જે ટ્રાન્સમ્યુટેબલ આંતરિક પ્રકારનાં સલામત [into|from]_raw() સાથે દખલ કરશે.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// સિંગલ-થ્રેડેડ સંદર્ભ-ગણતરી નિર્દેશક.'Rc' એટલે 'સંદર્ભ
/// Counted'.
///
/// વધુ વિગતો માટે [module-level documentation](./index.html) જુઓ.
///
/// `Rc` ની અંતર્ગત પદ્ધતિઓ એ બધા સંકળાયેલ કાર્યો છે, જેનો અર્થ એ કે તમારે તેમને `value.get_mut()` ને બદલે, દા.ત. [`Rc::get_mut(&mut value)`][get_mut] તરીકે ક .લ કરવો પડશે.
/// આ આંતરિક પ્રકાર `T` ની પદ્ધતિઓ સાથેના વિરોધોને ટાળે છે.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // આ અસંતોષ બરાબર છે કારણ કે જ્યારે આ આરસી જીવંત છે ત્યારે અમને ખાતરી આપવામાં આવે છે કે આંતરિક નિર્દેશક માન્ય છે.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// નવું `Rc<T>` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // બધા મજબૂત નિર્દેશકોની માલિકીનું એક ગર્ભિત નબળુ નિર્દેશક છે, જે સુનિશ્ચિત કરે છે કે નબળુ વિનાશક ચાલક જ્યારે ફાળવણીને કદી મુક્ત કરતું નથી, ભલે નબળા નિર્દેશક મજબૂતમાં સંગ્રહિત હોય.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// પોતાનામાં નબળા સંદર્ભનો ઉપયોગ કરીને નવું `Rc<T>` બનાવે છે.
    /// આ ફંક્શન વળતર પહેલાં નબળા સંદર્ભને અપગ્રેડ કરવાનો પ્રયાસ કરવાથી `None` મૂલ્ય મળશે.
    ///
    /// જો કે, નબળા સંદર્ભને મુક્તપણે ક્લોન કરી શકાય છે અને પછીના સમયમાં ઉપયોગ માટે સંગ્રહિત કરી શકાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... વધુ ક્ષેત્રો
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // એકલા નબળા સંદર્ભ સાથે "uninitialized" સ્થિતિમાં આંતરિક બનાવો.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // તે મહત્વનું છે કે આપણે નબળા નિર્દેશકની માલિકી છોડીશું નહીં, નહીં તો `data_fn` રીટર્ન થાય ત્યાં સુધી મેમરી મુક્ત થઈ શકે.
        // જો આપણે ખરેખર માલિકી પસાર કરવા માંગતા હો, તો આપણે આપણા માટે વધારાના નબળા નિર્દેશક બનાવી શકીએ છીએ, પરંતુ આના પરિણામે નબળા સંદર્ભની ગણતરીના વધારાના અપડેટ્સ થશે જે કદાચ જરૂરી ન હોય.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // મજબૂત સંદર્ભો સામૂહિક રૂપે વહેંચાયેલા નબળા સંદર્ભના હોવા જોઈએ, તેથી આપણા જૂના નબળા સંદર્ભ માટે ડિસ્ટ્રક્ટર ચલાવશો નહીં.
        //
        mem::forget(weak);
        strong
    }

    /// અનહિતીકૃત સમાવિષ્ટો સાથે એક નવું `Rc` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// એક્સિટિલાઇઝ્ડ સમાવિષ્ટો સાથે નવી `Rc` બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// નવું `Rc<T>` બનાવે છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // બધા મજબૂત નિર્દેશકોની માલિકીનું એક ગર્ભિત નબળુ નિર્દેશક છે, જે સુનિશ્ચિત કરે છે કે નબળુ વિનાશક ચાલક જ્યારે ફાળવણીને કદી મુક્ત કરતું નથી, ભલે નબળા નિર્દેશક મજબૂતમાં સંગ્રહિત હોય.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// જો બિન ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો આપીને બિન-ઉપયોગી સામગ્રી સાથે એક નવું `Rc` બનાવે છે
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// એક્સિટિલાઇઝ્ડ સામગ્રીઓ સાથે નવું `Rc` બનાવે છે, `0` બાઇટ્સથી મેમરી ભરેલી છે, ફાળવણી નિષ્ફળ થાય તો ભૂલ પાછો આવે છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// નવું `Pin<Rc<T>>` બનાવે છે.
    /// જો `T` એ `Unpin` અમલમાં ન મૂક્યું, તો પછી `value` મેમરીમાં પિન થઈ જશે અને ખસેડવામાં અસમર્થ હશે.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// આંતરિક મૂલ્ય પરત કરે છે, જો `Rc` માં બરાબર એક સચોટ સંદર્ભ હોય.
    ///
    /// નહિંતર, એક [`Err`] એ જ `Rc` સાથે પાછો ફર્યો હતો જે અંદર ગયો હતો.
    ///
    ///
    /// બાકી નબળા સંદર્ભો હોય તો પણ આ સફળ થશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // સમાયેલ copyબ્જેક્ટની નકલ કરો

                // નબળાઈઓને સૂચવો કે તેઓ મજબૂત ગણતરી ઘટાડીને પ્રોત્સાહન આપી શકતા નથી, અને પછી માત્ર નકલી નબળાને ઘસાવીને ડ્રોપ તર્કશાસ્ત્રને હેન્ડલ કરતી વખતે ગર્ભિત "strong weak" પોઇન્ટરને દૂર કરો.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// અનટાઇટિલાઇઝ્ડ સમાવિષ્ટો સાથે નવી સંદર્ભ-ગણતરીની સ્લાઇસ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// એક્સિટિલાઇઝ્ડ સામગ્રીઓ સાથે નવી સંદર્ભ-ગણતરીની સ્લાઈસ બનાવે છે, જેમાં `0` બાઇટ્સથી મેમરી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, અંદરની કિંમત ખરેખર આરંભિત સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક .લ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, અંદરની કિંમત ખરેખર આરંભિત સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક .લ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// વીંટાળેલા પોઇન્ટરને પરત કરીને, `Rc` લે છે.
    ///
    /// મેમરી લિકને ટાળવા માટે, નિર્દેશકને પાછા [`Rc::from_raw`][from_raw] નો ઉપયોગ કરીને `Rc` પર પાછા ફેરવવું આવશ્યક છે.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ડેટાને કાચો પોઇન્ટર પ્રદાન કરે છે.
    ///
    /// ગણતરીઓ કોઈપણ રીતે અસર કરતી નથી અને `Rc` પીવામાં આવતી નથી.
    /// `Rc` માં મજબૂત ગણતરીઓ છે ત્યાં સુધી નિર્દેશક માન્ય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // સલામતી: આ Deref::deref અથવા Rc::inner થઈ શકતું નથી કારણ કે
        // આ જેમ કે દા.ત. raw/mut પ્રોવેન્સન્સ જાળવી રાખવા માટે જરૂરી છે
        // `get_mut` `from_raw` દ્વારા આરસી પુન theપ્રાપ્ત થયા પછી નિર્દેશક દ્વારા લખી શકે છે.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// કાચા પોઇન્ટરથી `Rc<T>` બનાવે છે.
    ///
    /// કાચા પોઇન્ટર પહેલા [`Rc<U>::into_raw`][into_raw] પર ક callલ દ્વારા પરત ફર્યા હોવું આવશ્યક છે જ્યાં `U` નું કદ અને `T` જેવું સંરેખણ હોવું આવશ્યક છે.
    /// જો `U` `T` હોય તો આ તુચ્છ રૂપે સાચું છે.
    /// નોંધ લો કે જો `U` એ X01 એક્સ નથી પરંતુ તેનું કદ અને ગોઠવણી સમાન છે, તો આ મૂળભૂત રીતે વિવિધ પ્રકારનાં સંદર્ભ ટ્રાન્સમિટ કરવા જેવું છે.
    /// આ કિસ્સામાં કયા નિયંત્રણો લાગુ પડે છે તેના પર વધુ માહિતી માટે [`mem::transmute`][transmute] જુઓ.
    ///
    /// `from_raw` ના વપરાશકર્તાએ ખાતરી કરવી પડશે કે `T` નું કોઈ ચોક્કસ મૂલ્ય ફક્ત એક જ વાર ઘટી ગયું છે.
    ///
    /// આ ફંક્શન અસુરક્ષિત છે કારણ કે અયોગ્ય ઉપયોગથી મેમરી અસુરક્ષિત થઈ શકે છે, પછી ભલે `Rc<T>` ક્યારેય isક્સેસ ન કરે.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // લિકને અટકાવવા માટે એક `Rc` પર પાછા ફેરવો.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` પર વધુ ક callsલ્સ મેમરી-અસુરક્ષિત હશે.
    /// }
    ///
    /// // જ્યારે `x` ઉપરની અવકાશની બહાર ગઈ ત્યારે મેમરીને મુક્ત કરવામાં આવી, તેથી `x_ptr` હવે ઝૂલતું રહે છે!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // અસલ આરસીબોક્સ શોધવા માટે setફસેટને ઉલટાવી દો.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// આ ફાળવણી માટે એક નવું [`Weak`] પોઇન્ટર બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ખાતરી કરો કે અમે ઝૂલતા નબળાઈ બનાવતા નથી
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// આ ફાળવણીમાં [`Weak`] પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// આ ફાળવણીમાં મજબૂત (`Rc`) પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// જો આ ફાળવણીમાં કોઈ અન્ય `Rc` અથવા [`Weak`] પોઇન્ટર ન હોય તો `true` પરત કરે છે.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// આપેલ `Rc` માં પરિવર્તનીય સંદર્ભ આપે છે, જો સમાન ફાળવણીમાં અન્ય કોઈ `Rc` અથવા [`Weak`] પોઇન્ટર ન હોય તો.
    ///
    ///
    /// [`None`] પરત કરે છે અન્યથા, કારણ કે વહેંચાયેલ મૂલ્યનું પરિવર્તન કરવું સલામત નથી.
    ///
    /// [`make_mut`][make_mut] પણ જુઓ, જે અન્ય નિર્દેશકો હોય ત્યારે આંતરિક મૂલ્ય [`clone`][clone] કરશે.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// આપેલ `Rc` માં કોઈ પણ તપાસ કર્યા વગર પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// [`get_mut`] પણ જુઓ, જે સલામત છે અને યોગ્ય તપાસ કરે છે.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// તે જ ફાળવણીમાં અન્ય કોઈપણ `Rc` અથવા [`Weak`] પોઇંટરો પરત ઉધારની અવધિ માટે યોગ્ય ન હોવો જોઈએ.
    ///
    /// આ તુચ્છ રૂપે કેસ છે જો આવા કોઈ નિર્દેશકો અસ્તિત્વમાં નથી, ઉદાહરણ તરીકે `Rc::new` પછી તરત જ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // અમે "count" ક્ષેત્રોને આવરી લેતા *સંદર્ભ* બનાવતા નથી તેની કાળજી રાખીએ છીએ, કારણ કે આ સંદર્ભ ગણતરીઓની cesક્સેસથી વિરોધાભાસી છે (દા.ત.
        // `Weak` દ્વારા).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// જો બે `Rc`s એ જ ફાળવણી તરફ નિર્દેશ કરે તો `true` પરત કરે છે ([`ptr::eq`] સમાન શિરામાં).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// આપેલ `Rc` માં પરિવર્તનશીલ સંદર્ભ બનાવે છે.
    ///
    /// જો સમાન ફાળવણીમાં અન્ય `Rc` પોઇંટર્સ છે, તો પછી `make_mut` અનન્ય માલિકીની ખાતરી કરવા માટે નવા ફાળવણી માટે આંતરિક મૂલ્ય [`clone`] કરશે.
    /// આને ક્લોન onન-રાઇટ તરીકે પણ ઓળખવામાં આવે છે.
    ///
    /// જો આ ફાળવણી માટે અન્ય કોઈ `Rc` પોઇંટર્સ નથી, તો પછી આ ફાળવણીના [`Weak`] પોઇંટર્સને અલગ કરવામાં આવશે.
    ///
    /// [`get_mut`] પણ જુઓ, જે ક્લોનીંગ કરતાં નિષ્ફળ જશે.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // કંઈપણ ક્લોન નહીં કરો
    /// let mut other_data = Rc::clone(&data);    // આંતરિક ડેટાને ક્લોન નહીં કરે
    /// *Rc::make_mut(&mut data) += 1;        // ક્લોન્સ આંતરિક ડેટા
    /// *Rc::make_mut(&mut data) += 1;        // કંઈપણ ક્લોન નહીં કરો
    /// *Rc::make_mut(&mut other_data) *= 2;  // કંઈપણ ક્લોન નહીં કરો
    ///
    /// // હવે `data` અને `other_data` વિવિધ ફાળવણી તરફ નિર્દેશ કરે છે.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] નિર્દેશકોને અલગ પાડવામાં આવશે:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ડેટાને ક્લોન કરવા માટે, ત્યાં અન્ય આર.સી.એસ.
            // ક્લોન કરેલ મૂલ્યને સીધા લખવાની મંજૂરી આપવા માટે પૂર્વ-ફાળવણી મેમરી.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // ફક્ત ડેટા ચોરી શકે છે, બાકી છે ફક્ત વેક્સ
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // ગર્ભિત મજબૂત-નબળા સંદર્ભો દૂર કરો (અહીં નકલી નબળા કળા કરવાની જરૂર નથી-અમે જાણીએ છીએ કે અન્ય નબળાઈઓ આપણા માટે સફાઇ કરી શકે છે)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // આ અસંતોષ બરાબર છે કારણ કે અમને ખાતરી આપવામાં આવી છે કે જે નિર્દેશક પાછો ફર્યો છે તે એકમાત્ર * પોઇન્ટર છે જે ક્યારેય ટી પર પાછા આવશે.
        // અમારી સંદર્ભની ગણતરી આ સમયે 1 હોવાની બાંયધરી આપવામાં આવી છે, અને અમારે `Rc<T>` પોતે `mut` હોવું જરૂરી છે, તેથી અમે ફાળવણીનો એકમાત્ર સંભવિત સંદર્ભ આપી રહ્યા છીએ.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// કોંક્રિટ પ્રકારના `Rc<dyn Any>` ડાઉનકાસ્ટ કરવાનો પ્રયાસ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// સંભવિત-અસૂચિત આંતરીક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `RcBox<T>` ફાળવે છે જ્યાં મૂલ્ય પૂરા પાડવામાં આવ્યું છે.
    ///
    /// ફંક્શન `mem_to_rcbox` ને ડેટા પોઇન્ટર સાથે કહેવામાં આવે છે અને `RcBox<T>` માટે એક (સંભવિત ચરબી)-પોઇન્ટર પાછું ફરવું જોઈએ.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // આપેલ મૂલ્ય લેઆઉટનો ઉપયોગ કરીને લેઆઉટની ગણતરી કરો.
        // પહેલાં, લેઆઉટની ગણતરી `&*(ptr as* const RcBox<T>)` અભિવ્યક્તિ પર કરવામાં આવતી હતી, પરંતુ આણે ખોટી રીતે સહી કરેલ સંદર્ભ બનાવ્યો (#54908 જુઓ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// સંભવિત-અસૂચિત આંતરીક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `RcBox<T>` ફાળવે છે જ્યાં મૂલ્યનું લેઆઉટ આપવામાં આવ્યું છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો.
    ///
    ///
    /// ફંક્શન `mem_to_rcbox` ને ડેટા પોઇન્ટર સાથે કહેવામાં આવે છે અને `RcBox<T>` માટે એક (સંભવિત ચરબી)-પોઇન્ટર પાછું ફરવું જોઈએ.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // આપેલ મૂલ્ય લેઆઉટનો ઉપયોગ કરીને લેઆઉટની ગણતરી કરો.
        // પહેલાં, લેઆઉટની ગણતરી `&*(ptr as* const RcBox<T>)` અભિવ્યક્તિ પર કરવામાં આવતી હતી, પરંતુ આણે ખોટી રીતે સહી કરેલ સંદર્ભ બનાવ્યો (#54908 જુઓ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // લેઆઉટ માટે ફાળવો.
        let ptr = allocate(layout)?;

        // આરસીબોક્સ પ્રારંભ કરો
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// બિન-કદિત આંતરિક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `RcBox<T>` ફાળવે છે
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // આપેલ મૂલ્યનો ઉપયોગ કરીને `RcBox<T>` માટે ફાળવો.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // બાઇટ્સ તરીકે ક Copyપિ કરો મૂલ્ય
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ફાળવણીની સામગ્રીને છોડ્યા વિના મુક્ત કરો
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// આપેલ લંબાઈ સાથે એક `RcBox<[T]>` ફાળવે છે.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// ટુકડાઓમાંથી તત્વોને નવી ફાળવેલ આરસી <\[ટી\]> માં ક Copyપિ કરો
    ///
    /// અસુરક્ષિત કારણ કે કlerલરને કાં તો માલિકી લેવી જોઈએ અથવા `T: Copy` ને બાંધવું જોઈએ
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ચોક્કસ કદના જાણીતા ઇટરેટરથી `Rc<[T]>` બનાવે છે.
    ///
    /// વર્તન અનિશ્ચિત છે જો કદ ખોટું હોવું જોઈએ.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // ટી તત્વોની ક્લોનીંગ કરતી વખતે ઝેડપાનિક 0 ઝેડ રક્ષક.
        // ઝેડ 0 પicનિકિક ઝેડની ઘટનામાં, નવા આરસીબોક્સમાં લખેલા તત્વોને છોડી દેવામાં આવશે, પછી મેમરી મુક્ત થઈ જશે.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // પ્રથમ તત્વ તરફ નિર્દેશક
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // બધું ચોખ્ખું.રક્ષકને ભૂલી જાઓ જેથી તે નવા આરસીબોક્સને મુક્ત ન કરે.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` માટે વપરાયેલી વિશેષતા trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ના ઘટાડે છે.
    ///
    /// આ મજબૂત સંદર્ભ ગણતરીમાં ઘટાડો કરશે.
    /// જો મજબૂત સંદર્ભ ગણતરી શૂન્ય પર પહોંચે છે, તો પછી માત્ર અન્ય સંદર્ભો (જો કોઈ હોય તો) [`Weak`] છે, તેથી અમે આંતરિક મૂલ્ય `drop` કરીએ છીએ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // કંઈપણ છાપતો નથી
    /// drop(foo2);   // પ્રિન્ટ્સ "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // સમાયેલ destroyબ્જેક્ટનો નાશ કરો
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // હવે સમાવિષ્ટ "strong weak" પોઇન્ટરને દૂર કરો કે અમે સમાવિષ્ટોનો નાશ કર્યો છે.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` પોઇન્ટરનો ક્લોન બનાવે છે.
    ///
    /// આ તે જ ફાળવણીમાં બીજો નિર્દેશક બનાવે છે, મજબૂત સંદર્ભ ગણતરીમાં વધારો કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` માટેના `Default` મૂલ્ય સાથે, એક નવો `Rc<T>` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` પાસે એક પદ્ધતિ હોવા છતાં પણ `Eq` પર વિશેષતા પ્રાપ્ત કરવા માટે હેક.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// અમે આ વિશેષતા અહીં કરી રહ્યા છીએ, અને `&T` પર વધુ સામાન્ય optimપ્ટિમાઇઝેશન તરીકે નહીં, કારણ કે તે અન્યથા રેફ્સ પરની બધી સમાનતા તપાસમાં ખર્ચ ઉમેરશે.
/// અમે ધારીએ છીએ કે `આરસીનો ઉપયોગ મોટા મૂલ્યો સ્ટોર કરવા માટે થાય છે, જે ક્લોન કરવામાં ધીમું હોય છે, પરંતુ સમાનતાની તપાસ માટે પણ ભારે હોય છે, જેના કારણે આ ખર્ચ વધુ સરળતાથી ચૂકવવામાં આવે છે.
///
/// તેમાં બે 00&T`s કરતાં, બે `Rc` ક્લોન હોવાનો વધુ સંભાવના છે, જે સમાન મૂલ્ય તરફ નિર્દેશ કરે છે.
///
/// અમે ફક્ત ત્યારે જ કરી શકીએ છીએ જ્યારે `T: Eq` `PartialEq` તરીકે ઇરાદાપૂર્વક અસ્પષ્ટ હોઈ શકે.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// બે `આરસી માટે સમાનતા.
    ///
    /// બે `Rc`s સમાન છે જો તેમના આંતરિક મૂલ્યો સમાન હોય, ભલે તે વિવિધ ફાળવણીમાં સંગ્રહિત હોય.
    ///
    /// જો `T` પણ `Eq` (સમાનતાના પ્રતિબિંબિતતા) ને લાગુ કરે છે, તો સમાન ફાળવણીનો નિર્દેશ કરે છે તે બે `આરસી હંમેશા સમાન હોય છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// બે `આરસી માટે અસમાનતા.
    ///
    /// બે `Rc`s અસમાન છે જો તેમના આંતરિક મૂલ્યો અસમાન હોય.
    ///
    /// જો `T` પણ `Eq` (સમાનતાના પ્રતિબિંબિતતા) નો અમલ કરે છે, તો તે જ ફાળવણીને નિર્દેશ કરતી બે `આરસી ક્યારેય અસમાન હોતી નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// બે `આરસી માટે આંશિક સરખામણી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `partial_cmp()` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// બે `આરસી માટે સરખામણી કરતા ઓછી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `<` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// બે `Rc`s ની તુલના 'કરતાં ઓછી અથવા બરાબર'.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `<=` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// બે `આરસી માટે સરખામણી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `>` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// બે `Rc`s ની તુલના 'કરતા વધારે અથવા બરાબર'.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `>=` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// બે `આરસી માટે સરખામણી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `cmp()` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// સંદર્ભ-ગણાતી સ્લાઈસ ફાળવો અને cl v` ની આઇટમ્સની ક્લોનિંગ કરીને તેને ભરો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// સંદર્ભ-ગણાતી સ્ટ્રિંગ સ્લાઈસ ફાળવો અને તેમાં `v` ક copyપિ કરો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// સંદર્ભ-ગણાતી સ્ટ્રિંગ સ્લાઈસ ફાળવો અને તેમાં `v` ક copyપિ કરો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// બedક્સ્ડ objectબ્જેક્ટને નવા, સંદર્ભ ગણતરી, ફાળવણી પર ખસેડો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// સંદર્ભ-ગણાતી સ્લાઈસ ફાળવો અને તેમાં વસ્તુઓ ખસેડો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec ને તેની મેમરી મુક્ત કરવાની મંજૂરી આપો, પરંતુ તેની સામગ્રીને નષ્ટ ન કરો
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` માં દરેક તત્વ લે છે અને તેને `Rc<[T]>` માં એકત્રિત કરે છે.
    ///
    /// # પ્રભાવ લાક્ષણિકતાઓ
    ///
    /// ## સામાન્ય કેસ
    ///
    /// સામાન્ય કિસ્સામાં, `Rc<[T]>` માં એકત્રિત કરવાનું પ્રથમ `Vec<T>` માં એકત્રિત કરીને કરવામાં આવે છે.તે છે, જ્યારે નીચે લખતા હો ત્યારે:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// આ જેમ વર્તે છે જેમ કે આપણે લખ્યું છે:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ફાળવણીનો પ્રથમ સેટ અહીં થાય છે.
    ///     .into(); // `Rc<[T]>` માટે બીજું ફાળવણી અહીં થાય છે.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// આ `Vec<T>` બાંધવા માટે જરૂરી તેટલી વખત ફાળવણી કરશે અને પછી તે `Vec<T>` ને `Rc<[T]>` માં ફેરવવા માટે એકવાર ફાળવવામાં આવશે.
    ///
    ///
    /// ## જાણીતી લંબાઈના ઇટરેટર્સ
    ///
    /// જ્યારે તમારું `Iterator` `TrustedLen` લાગુ કરે છે અને ચોક્કસ કદનું હોય ત્યારે, `Rc<[T]>` માટે એક ફાળવણી કરવામાં આવશે.દાખ્લા તરીકે:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // અહીં ફક્ત એક જ ફાળવણી થાય છે.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` માં એકત્રિત કરવા માટે વપરાયેલી વિશેષતા trait.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // આ એક `TrustedLen` પુનરાવર્તક માટેનો કેસ છે.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // સલામતી: આપણને ખાતરી કરવાની જરૂર છે કે પુનરાવર્તકની ચોક્કસ લંબાઈ છે અને અમારી પાસે છે.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // સામાન્ય અમલીકરણ પર પાછા ફરો.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] નું એક સંસ્કરણ છે જે વ્યવસ્થાપિત ફાળવણીનો બિન-માલિકીનો સંદર્ભ ધરાવે છે.`Weak` પોઇન્ટર પર [`upgrade`] પર ક callingલ કરીને ફાળવણી isક્સેસ કરી શકાય છે, જે [`વિકલ્પ`] returns <`[`Rc`] returns આપે છે<T>>`.
///
/// `Weak` સંદર્ભ માલિકી તરફની ગણતરી કરતું નથી, તેથી તે ફાળવણીમાં સંગ્રહિત મૂલ્યને ઘટાડતા અટકાવશે નહીં, અને X01 એક્સ પોતે પણ હજી પણ હાજર હોવાના મૂલ્ય વિશે કોઈ બાંયધરી આપતું નથી.
/// જ્યારે તે [`અપગ્રેડ`] ડી.
/// જોકે નોંધ લો કે એક `Weak` સંદર્ભ *કરે છે* ફાળવણીની જાતે જ (બેકિંગ સ્ટોર) અવમૂલ્યન થવાથી અટકાવે છે.
///
/// એક `Weak` નિર્દેશક [`Rc`] દ્વારા સંચાલિત ફાળવણીના અસ્થાયી સંદર્ભને રાખવા માટે તેના આંતરિક મૂલ્યને ઘટાડતા અટકાવ્યા વિના ઉપયોગી છે.
/// [`Rc`] પોઇન્ટર વચ્ચેના પરિપત્ર સંદર્ભોને રોકવા માટે પણ તેનો ઉપયોગ થાય છે, કારણ કે પરસ્પર માલિકીનાં સંદર્ભો ક્યારેય [`Rc`] ને ક્યાંય છોડવા દેતા નથી.
/// ઉદાહરણ તરીકે, એક ઝાડમાં માતાપિતા ગાંઠોથી બાળકોમાં મજબૂત [`Rc`] પોઇંટર્સ, અને બાળકોથી તેમના માતાપિતા સુધીના `Weak` પોઇન્ટર હોઈ શકે છે.
///
/// `Weak` પોઇન્ટર મેળવવા માટેની લાક્ષણિક રીત, [`Rc::downgrade`] ને ક callલ કરવો.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // આ પ્રકારનું કદ enપ્ટિમાઇઝ કરવા માટે, ઇંગ્સમાં આ એક `NonNull` છે, પરંતુ તે આવશ્યક પોઇન્ટર નથી.
    //
    // `Weak::new` આને `usize::MAX` પર સેટ કરે છે જેથી તેને apગલા પર સ્થાન ફાળવવાની જરૂર ન પડે.
    // તે મૂલ્ય ક્યારેય નથી જે વાસ્તવિક નિર્દેશક પાસે હશે કારણ કે આરસીબોક્સમાં ઓછામાં ઓછું 2 ગોઠવણી છે.
    // આ ફક્ત ત્યારે જ શક્ય છે જ્યારે `T: Sized`;અસૂચિત `T` ક્યારેય ઝૂલતું નથી.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// કોઈપણ મેમરીને ફાળવ્યા વિના, નવું `Weak<T>` બનાવે છે.
    /// રીટર્ન વેલ્યુ પર [`upgrade`] પર કingલ કરવો હંમેશા [`None`] આપે છે.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// માહિતી ક્ષેત્ર વિશે કોઈ નિવેદનો કર્યા વગર સંદર્ભ ગણતરીઓને allowક્સેસ કરવા માટે સહાયકનો પ્રકાર.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// આ `Weak<T>` દ્વારા નિર્દેશિત Xબ્જેક્ટ `T` પર કાચો નિર્દેશક પાછો આપે છે.
    ///
    /// જો ત્યાં કેટલાક મજબૂત સંદર્ભો હોય તો જ નિર્દેશક માન્ય છે.
    /// નિર્દેશક ઝૂંટવું, અનલિએન્ડ કરેલું અથવા [`null`] અન્યથા હોઈ શકે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // બંને એક જ toબ્જેક્ટ તરફ નિર્દેશ કરે છે
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // અહીં મજબૂત તે જીવંત રાખે છે, તેથી અમે હજી પણ accessબ્જેક્ટને .ક્સેસ કરી શકીએ છીએ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // પરંતુ વધુ નહીં.
    /// // અમે weak.as_ptr() કરી શકીએ છીએ, પરંતુ નિર્દેશકને ક્સેસ કરવાથી અનિશ્ચિત વર્તન થઈ શકે છે.
    /// // assert_eq! ("હેલો", અસુરક્ષિત {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // જો પોઇંટર ઝૂલતો હોય, તો અમે સીધો જ મોકલ્યો હતો.
            // આ માન્ય પેલોડ સરનામું હોઈ શકતું નથી, કારણ કે પેલોડ ઓછામાં ઓછું આરસીબોક્સ (usize) તરીકે ગોઠવાયેલ છે.
            ptr as *const T
        } else {
            // સલામતી: જો is_dangling ખોટા વળતર આપે છે, તો પછી નિર્દેશક યોગ્ય નથી.
            // પેલોડ આ બિંદુએ છોડી શકાય છે, અને અમારે પ્રોવિન્સન્સ જાળવવું પડશે, તેથી કાચા પોઇન્ટર મેનીપ્યુલેશનનો ઉપયોગ કરો.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` લે છે અને તેને કાચા પોઇન્ટરમાં ફેરવે છે.
    ///
    /// આ નબળા નિર્દેશકને કાચા પોઇન્ટરમાં રૂપાંતરિત કરે છે, જ્યારે હજી પણ એક નબળા સંદર્ભની માલિકી સાચવે છે (નબળી ગણતરી આ કામગીરી દ્વારા સંશોધિત થતી નથી).
    /// તે [`from_raw`] સાથે પાછા `Weak<T>` માં ફેરવી શકાય છે.
    ///
    /// [`as_ptr`] ની જેમ પોઇન્ટરના લક્ષ્યને .ક્સેસ કરવા માટે સમાન નિયંત્રણો લાગુ પડે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] દ્વારા અગાઉ બનાવેલા કાચા પોઇન્ટરને પાછા `Weak<T>` માં ફેરવે છે.
    ///
    /// આનો ઉપયોગ સલામત રીતે મજબૂત સંદર્ભ મેળવવા માટે (પછીથી X01 એક્સ પર ક callingલ કરીને) અથવા `Weak<T>` છોડીને નબળા ગણતરીને દૂર કરવા માટે થઈ શકે છે.
    ///
    /// તે એક નબળા સંદર્ભની માલિકી લે છે ([`new`] દ્વારા બનાવેલા પોઇંટર્સના અપવાદ સિવાય, આ કંઈપણ ધરાવતા નથી; પદ્ધતિ હજી પણ તેમના પર કાર્ય કરે છે).
    ///
    /// # Safety
    ///
    /// પોઇન્ટર [`into_raw`] માંથી ઉદ્ભવ્યો હોવો જોઈએ અને હજી પણ તેના સંભવિત નબળા સંદર્ભની માલિકી હોવી જોઈએ.
    ///
    /// આ ક callingલ કરતી વખતે મજબૂત ગણતરી માટે 0 હોવાની મંજૂરી છે.
    /// તેમ છતાં, આ હાલમાં કાચા પોઇન્ટર તરીકે રજૂ કરાયેલા એક નબળા સંદર્ભની માલિકી લે છે (નબળી ગણતરી આ ઓપરેશન દ્વારા સુધારવામાં આવતી નથી) અને તેથી તે [`into_raw`] પર પહેલાંના ક callલ સાથે જોડી હોવી આવશ્યક છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // છેલ્લી નબળી ગણતરીમાં ઘટાડો.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ઇનપુટ પોઇન્ટર કેવી રીતે મેળવાય છે તેના સંદર્ભ માટે Weak::as_ptr જુઓ.

        let ptr = if is_dangling(ptr as *mut T) {
            // આ એક ઝૂલતું નબળું છે.
            ptr as *mut RcBox<T>
        } else {
            // નહિંતર, અમને ખાતરી આપવામાં આવી છે કે નિર્દેશક નબળાઇથી આવે છે.
            // સલામત: ડેટા_ઓફસેટ ક callલ કરવા માટે સલામત છે, કારણ કે પી.ટી.આર. એક વાસ્તવિક (સંભવિત ઘટાડો) ટીનો સંદર્ભ આપે છે.
            let offset = unsafe { data_offset(ptr) };
            // આમ, આખું આરસીબોક્સ મેળવવા માટે અમે setફસેટને ઉલટાવીએ છીએ.
            // સલામતી: નિર્દેશક નબળાઇથી ઉત્પન્ન થયો છે, તેથી આ setફસેટ સલામત છે.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // સલામતી: હવે આપણે અસલ નબળા નિર્દેશકને પ્રાપ્ત કરી લીધું છે, તેથી નબળા બનાવી શકીએ છીએ.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` પોઇન્ટરને [`Rc`] પર અપગ્રેડ કરવાનો પ્રયાસ, જો સફળ થાય તો આંતરિક મૂલ્યના ઘટાડામાં વિલંબ થાય છે.
    ///
    ///
    /// જો આંતરિક મૂલ્ય ત્યારબાદ છોડી દેવામાં આવે તો [`None`] પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // બધા મજબૂત પોઇંટરો નાશ.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// આ ફાળવણી તરફ નિર્દેશ કરતી મજબૂત (`Rc`) પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// જો `self`, [`Weak::new`] નો ઉપયોગ કરીને બનાવવામાં આવ્યો હતો, તો આ 0 પરત આવશે.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// આ ફાળવણી તરફ નિર્દેશ કરતી `Weak` પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// જો કોઈ મજબૂત નિર્દેશક બાકી નથી, તો આ શૂન્ય પરત આવશે.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ગર્ભિત નબળા ptr બાદબાકી
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// જ્યારે નિર્દેશક ઝૂલતું હોય અને ત્યાં કોઈ ફાળવવામાં આવેલ `RcBox` ન હોય ત્યારે `None` આપે છે, (એટલે કે, જ્યારે આ `Weak` `Weak::new` દ્વારા બનાવવામાં આવ્યું હતું).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // અમે "data" ફીલ્ડને આવરી લેતા એક સંદર્ભ બનાવવા * ન કરવા માટે ખૂબ કાળજી રાખીએ છીએ, કારણ કે આ ક્ષેત્ર એક સાથે પરિવર્તિત થઈ શકે છે (ઉદાહરણ તરીકે, જો છેલ્લા `Rc` છોડવામાં આવે છે, તો ડેટા ફીલ્ડને જગ્યાએ મૂકવામાં આવશે).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// જો બે નબળાઈ એક સમાન ફાળવણી તરફ નિર્દેશ કરે તો `true` આપે છે ([`ptr::eq`] જેવું જ), અથવા જો બંને કોઈ ફાળવણી તરફ નિર્દેશ કરતા નથી (કારણ કે તે `Weak::new()`) સાથે બનાવવામાં આવ્યા હતા.
    ///
    ///
    /// # Notes
    ///
    /// કારણ કે આ નિર્દેશકોની તુલના કરે છે તેનો અર્થ એ કે `Weak::new()` એકબીજાને સમાન કરશે, તેમ છતાં તેઓ કોઈપણ ફાળવણી તરફ નિર્દેશ કરતા નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ની તુલના.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` પોઇન્ટરને છોડે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // કંઈપણ છાપતો નથી
    /// drop(foo);        // પ્રિન્ટ્સ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // નબળી ગણતરી 1 થી શરૂ થાય છે, અને તે બધા શૂન્ય નિર્દેશીઓ અદૃશ્ય થઈ જાય તો જ શૂન્ય થઈ જશે.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// તે જ ફાળવણી તરફ નિર્દેશ કરે છે તે `Weak` પોઇન્ટરનો ક્લોન બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// એક નવી `Weak<T>` બનાવે છે, `T` માટે પ્રારંભ કર્યા વિના મેમરી ફાળવણી.
    /// રીટર્ન વેલ્યુ પર [`upgrade`] પર કingલ કરવો હંમેશા [`None`] આપે છે.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: અમે mem::forget સાથે સલામત રૂપે વ્યવહાર કરવા માટે અહીં તપાસ કરી.વિશેષ રીતે
// જો તમે mem::forget આરસીએસ (અથવા નબળા), રેફ-કાઉન્ટ ઓવરફ્લો થઈ શકે છે, અને પછી બાકી આરસીએસ (અથવા નબળા) અસ્તિત્વમાં હોય ત્યારે તમે ફાળવણીને મુક્ત કરી શકો છો.
//
// અમે ગર્ભપાત કરીએ છીએ કારણ કે આ એક અધોગતિપૂર્ણ દૃશ્ય છે કે જે થાય છે તેની અમને પરવા નથી-કોઈ વાસ્તવિક પ્રોગ્રામ આનો અનુભવ ન કરવો જોઈએ.
//
// માલિકી અને ચાલ-અર્થતંત્ર માટે આભાર તમારે ઝેડ રસ્ટ0 ઝેડમાં આ ખૂબ ક્લોન કરવાની જરૂર નથી, કારણ કે આમાં નહિવત ઓવરહેડ હોવું જોઈએ.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // અમે મૂલ્યને છોડવાને બદલે ઓવરફ્લો પર છોડી દેવા માંગીએ છીએ.
        // જ્યારે આ કહેવામાં આવે ત્યારે સંદર્ભ ગણતરી ક્યારેય શૂન્ય રહેશે નહીં;
        // તેમ છતાં, અમે એલએલવીએમને અન્યથા ચૂકી ગયેલા optimપ્ટિમાઇઝેશન પર સંકેત આપવા માટે અહીં એક બંધને શામેલ કરીએ છીએ.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // અમે મૂલ્યને છોડવાને બદલે ઓવરફ્લો પર છોડી દેવા માંગીએ છીએ.
        // જ્યારે આ કહેવામાં આવે ત્યારે સંદર્ભ ગણતરી ક્યારેય શૂન્ય રહેશે નહીં;
        // તેમ છતાં, અમે એલએલવીએમને અન્યથા ચૂકી ગયેલા optimપ્ટિમાઇઝેશન પર સંકેત આપવા માટે અહીં એક બંધને શામેલ કરીએ છીએ.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// પોઇન્ટરના પાછળના પેલોડ માટે `RcBox` ની અંદર setફસેટ મેળવો.
///
/// # Safety
///
/// નિર્દેશકએ T ના પહેલાના માન્ય દાખલા પર (અને તેના માટે માન્ય મેટાડેટા હોવું જોઈએ) નિર્દેશ કરવું આવશ્યક છે, પરંતુ ટીને છોડી દેવાની મંજૂરી છે.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // આરસીબoxક્સના અંતમાં વણસેલાવેલ મૂલ્યને સંરેખિત કરો.
    // કારણ કે આરસીબોક્સ એ repr(C) છે, તે હંમેશા મેમરીમાં છેલ્લું ક્ષેત્ર રહેશે.
    // સલામતી: ફક્ત અનઇસીઇઝ્ડ પ્રકારો જ શક્ય છે કાપી નાંખેલ ઝેડટ્રેટ 0 ઝેડ objectsબ્જેક્ટ્સ
    // અને બાહ્ય પ્રકારો, align_of_val_raw ની આવશ્યકતાઓને સંતોષવા માટે ઇનપુટ સલામતી આવશ્યકતા હાલમાં પૂરતી છે;આ તે ભાષાનું અમલીકરણ વિગત છે કે જે std ની બહાર ન હોઈ શકે.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}