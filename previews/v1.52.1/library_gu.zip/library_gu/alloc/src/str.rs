//! યુનિકોડ શબ્દમાળા કાપી નાંખ્યું.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` પ્રકાર એ બે મુખ્ય શબ્દમાળા પ્રકારોમાંથી એક છે, બીજો `String`.
//! તેના `String` પ્રતિરૂપથી વિપરીત, તેની સામગ્રી ઉધાર લેવામાં આવે છે.
//!
//! # મૂળભૂત વપરાશ
//!
//! `&str` પ્રકારનું મૂળભૂત શબ્દમાળા ઘોષણા:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! અહીં આપણે શબ્દમાળાને શાબ્દિક ઘોષણા કરી છે, જેને શબ્દમાળા સ્લાઇસ તરીકે પણ ઓળખવામાં આવે છે.
//! શબ્દમાળા અક્ષરોમાં સ્થિર જીવનકાળ હોય છે, જેનો અર્થ એ છે કે શબ્દમાળા `hello_world` સમગ્ર પ્રોગ્રામના સમયગાળા માટે માન્ય હોવાની ખાતરી આપવામાં આવે છે.
//!
//! અમે સ્પષ્ટ રીતે `હેલો_વર્લ્ડ`નું જીવનકાળ પણ સ્પષ્ટ કરી શકીએ છીએ.
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// આ મોડ્યુલમાં ઘણા યુઝિંગ્સનો ઉપયોગ ફક્ત પરીક્ષણ ગોઠવણીમાં થાય છે.
// ફક્ત બિનવપરાયેલ_ઇમ્પોર્ટ્સ ચેતવણીને ઠીક કરવાને બદલે તેને બંધ કરવું તે વધુ સારું છે.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` માં `str` અહીં અર્થપૂર્ણ નથી.
/// trait નો આ પ્રકારનો પરિમાણ ફક્ત બીજી ઇમ્પલિને સક્ષમ કરવા માટે અસ્તિત્વમાં છે.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // હાર્ડકોડ્ડ કદવાળા લૂપ્સ નાના વિભાજક લંબાઈવાળા કિસ્સાઓને વધુ ઝડપથી ચલાવે છે
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // મનસ્વી બિન-શૂન્ય કદ ફ fallલબેક
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Joinપ્ટિમાઇઝ જોડાણ અમલીકરણ જે બંને વી.સી. માટે કાર્ય કરે છે<T>(ટી: ક Copyપિ કરો) અને સ્ટ્રિંગની આંતરિક વીસી હાલમાં (2018-05-13) ત્યાં એક પ્રકારનો અનુમાન અને વિશેષતા સાથેનો બગ છે (જુઓ #36262 અંક જુઓ) આ કારણોસર સ્લાઈસકોનકેટ<T>ટી માટે વિશિષ્ટ નથી: ક andપિ અને સ્લાઈસકોનકેટ<str>આ કાર્યનો એકમાત્ર વપરાશકર્તા છે.
// જ્યારે તે નિશ્ચિત થાય ત્યારે તે જગ્યાએ મૂકવામાં આવે છે.
//
// શબ્દમાળા જોડાવા માટેની સીમા એસ: બોરો છે<str>અને વૈક-જોડાણ ઉધાર માટે <[T]> [T] અને str બંને એએસઆરએફ <[ટી]> કેટલાક ટી માટે
// => s.borrow().as_ref() અને અમારી પાસે હંમેશા કાપી નાંખવામાં આવે છે
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // પ્રથમ ટુકડો એકમાત્ર એક ભાગ છે તે પહેલાંના ભાગલા વગરનો
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // જો જોડાયેલ વેકની ચોક્કસ કુલ લંબાઈની ગણતરી કરો જો `len` ગણતરી ઓવરફ્લો થાય છે, તો અમે ઝેડપેનિક0 ઝેડ કરીશું જે આપણે કોઈપણ રીતે મેમરીમાંથી બહાર નીકળી ગયા હોત અને બાકીના ફંક્શનની સલામતી માટે પૂર્વ વી.ક. ફાળવણી જરૂરી છે.
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // એક અનિયંત્રિત બફર તૈયાર કરો
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // બાહ્ય તપાસો વગર કodપિ વિભાજક અને કાપી નાંખ્યું નાના વિભાગો માટેના હાર્ડકોડ્ડ seફસેટ્સ સાથે લૂપ્સ ઉત્પન્ન કરે છે મોટા પ્રમાણમાં સુધારો (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // એક વિચિત્ર ઉધાર અમલીકરણ લંબાઈની ગણતરી અને વાસ્તવિક ક forપિ માટે વિવિધ કાપી નાંખશે.
        //
        // ખાતરી કરો કે અમે કitલરને અનિટિએટલાઇઝ્ડ બાઇટ્સનો પર્દાફાશ કર્યો નથી.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// શબ્દમાળા કાપી નાંખવાની પદ્ધતિઓ.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// કોઈ `Box<str>` ને ક copપિ અથવા ફાળવણી કર્યા વિના `Box<[u8]>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// પેટર્નની બધી મેચોને બીજા શબ્દમાળાથી બદલી દે છે.
    ///
    /// `replace` એક નવું [`String`] બનાવે છે, અને આ સ્ટ્રિંગમાંથી ડેટાની તેમાં કiceપિ કરે છે.
    /// આમ કરતી વખતે, તે કોઈ પેટર્નની મેચ શોધવાનો પ્રયાસ કરે છે.
    /// જો તેને કોઈ મળે, તો તે તેમને રિપ્લેસમેન્ટ સ્ટ્રિંગ સ્લાઈસથી બદલી નાખે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// જ્યારે પેટર્ન મેળ ખાતી નથી:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// પેટર્નની પ્રથમ એન મેચોને બીજા શબ્દમાળાથી બદલી નાખે છે.
    ///
    /// `replacen` એક નવું [`String`] બનાવે છે, અને આ સ્ટ્રિંગમાંથી ડેટાની તેમાં કiceપિ કરે છે.
    /// આમ કરતી વખતે, તે કોઈ પેટર્નની મેચ શોધવાનો પ્રયાસ કરે છે.
    /// જો તે કોઈ પણ મળે છે, તો તે તેમને મોટાભાગના `count` સમયે રિપ્લેસમેન્ટ સ્ટ્રિંગ સ્લાઈસથી બદલી નાખે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// જ્યારે પેટર્ન મેળ ખાતી નથી:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // ફરીથી ફાળવણીના સમય ઘટાડવાની આશા છે
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// એક નવી [`String`] તરીકે, આ શબ્દમાળાની સ્લાઈસના લોઅરકેસ સમકક્ષ પરત કરે છે.
    ///
    /// 'Lowercase' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `Lowercase` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// જ્યારે કેસ બદલાતી વખતે કેટલાક અક્ષરો બહુવિધ અક્ષરોમાં વિસ્તૃત થઈ શકે છે, તેથી આ કાર્ય પરિમાણને જગ્યાએ-બદલીને બદલે [`String`] આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// સિગ્મા સાથેનું એક મુશ્કેલ ઉદાહરણ:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // પરંતુ એક શબ્દના અંતે, તે ς, નહીં σ છે:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// કેસ વિનાની ભાષાઓ બદલાતી નથી:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word નકશા ς, કોઈ શબ્દના અંત સિવાય જ્યાં તે નકશા કરે છે.
                // આ એકમાત્ર શરતી (contextual) છે પરંતુ `SpecialCasing.txt` માં ભાષા-સ્વતંત્ર મેપિંગ છે, તેથી સામાન્ય "condition" મિકેનિઝમની જગ્યાએ તેને સખત-કોડ કરો.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` ની વ્યાખ્યા માટે.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// આ સ્ટ્રિંગ સ્લાઈસના મોટા અપરકેસને નવા [`String`] તરીકે પરત કરે છે.
    ///
    /// 'Uppercase' યુનિકોડ ડેરિવેટ કોર પ્રોપર્ટી `Uppercase` ની શરતો અનુસાર વ્યાખ્યાયિત કરવામાં આવી છે.
    ///
    /// જ્યારે કેસ બદલાતી વખતે કેટલાક અક્ષરો બહુવિધ અક્ષરોમાં વિસ્તૃત થઈ શકે છે, તેથી આ કાર્ય પરિમાણને જગ્યાએ-બદલીને બદલે [`String`] આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// કેસ વિનાની સ્ક્રિપ્ટ્સ બદલાતી નથી:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// એક પાત્ર બહુવિધ બની શકે છે:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// કોઈ [`Box<str>`] ને નકલ અથવા ફાળવણી કર્યા વિના [`String`] માં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` વખત સ્ટ્રિંગનું પુનરાવર્તન કરીને એક નવું [`String`] બનાવે છે.
    ///
    /// # Panics
    ///
    /// આ કાર્ય panic કરશે જો ક્ષમતા ઓવરફ્લો થશે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// ઓવરફ્લો પર એક ઝેડ 0 સ્પેનિક 0 ઝેડ:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// આ શબ્દમાળાની એક ક Returnપિ પરત કરે છે જ્યાં દરેક અક્ષરને તેના ASCII અપર કેસ સમકક્ષ સાથે મેપ કરવામાં આવે છે.
    ///
    ///
    /// 'a' થી 'z' સુધીના ASCII અક્ષરો 'A' થી 'Z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// સ્થળને મૂલ્યમાં મોટા કરવા માટે, [`make_ascii_uppercase`] નો ઉપયોગ કરો.
    ///
    /// બિન-ASCII અક્ષરો ઉપરાંત, ASCII અક્ષરો મોટા કરવા માટે, [`to_uppercase`] નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 આક્રમકને સાચવે છે.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// આ શબ્દમાળાની એક ક Returnપિ પરત કરે છે જ્યાં દરેક અક્ષરને તેના ASCII લોઅર કેસ સમકક્ષ સાથે મેપ કરવામાં આવે છે.
    ///
    ///
    /// 'A' થી 'Z' સુધીના ASCII અક્ષરો 'a' થી 'z' પર મેપ કરેલા છે, પરંતુ બિન-ASCII અક્ષરો યથાવત છે.
    ///
    /// જગ્યામાં મૂલ્ય ઘટાડવા માટે, [`make_ascii_lowercase`] નો ઉપયોગ કરો.
    ///
    /// નાના-ASCII અક્ષરો ઉપરાંત, ASCII અક્ષરોને નાના કરવા માટે, [`to_lowercase`] નો ઉપયોગ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 આક્રમકને સાચવે છે.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// બાઇટ્સની બedક્સ્ડ સ્લાઈસને, બedક્સવાળી સ્ટ્રિંગ સ્લાઈસમાં રૂપાંતરિત કર્યા વિના, તપાસો કે શબ્દમાળામાં માન્ય UTF-8 છે.
///
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}