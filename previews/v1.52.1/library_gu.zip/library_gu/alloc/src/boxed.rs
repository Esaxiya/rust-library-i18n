//! Apગલા ફાળવણી માટેનો નિર્દેશક પ્રકાર.
//!
//! [`Box<T>`], આકસ્મિક રીતે 'box' તરીકે ઓળખાય છે, ઝેડ 0 રસ્ટ0 ઝેડમાં apગલા ફાળવણીનું સૌથી સરળ સ્વરૂપ પ્રદાન કરે છે.બ thisક્સીસ આ ફાળવણી માટે માલિકી પ્રદાન કરે છે, અને જ્યારે અવકાશની બહાર જાય છે ત્યારે તેમની સામગ્રીને છોડી દે છે.બesક્સીઝ પણ સુનિશ્ચિત કરે છે કે તેઓ ક્યારેય પણ `isize::MAX` બાઇટ્સ કરતા વધારે ફાળવતા નથી.
//!
//! # Examples
//!
//! એક [`Box`] બનાવીને સ્ટેકથી valueગલા પર કોઈ મૂલ્ય ખસેડો:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! એક [`Box`] માંથી [dereferencing] દ્વારા સ્ટેક પર પાછા મૂકો:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! પુનરાવર્તિત ડેટા સ્ટ્રક્ચર બનાવવું:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! આ `Cons (1, Cons(2, Nil))`.
//!
//! રિકર્સીવ સ્ટ્રક્ચર્સ બ boxક્સીડ હોવા આવશ્યક છે, કારણ કે જો `Cons` ની વ્યાખ્યા આની જેમ દેખાય છે:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! તે કામ કરશે નહીં.આ કારણ છે કે `List` નું કદ સૂચિમાં કેટલા તત્વો છે તેના પર આધાર રાખે છે, અને તેથી આપણે `Cons` માટે કેટલી મેમરી ફાળવવી તે જાણતા નથી.એક [`Box<T>`] રજૂ કરીને, જેનો વ્યાખ્યાયિત કદ હોય છે, અમે જાણીએ છીએ કે કેટલું મોટું `Cons` હોવું જરૂરી છે.
//!
//! # મેમરી લેઆઉટ
//!
//! શૂન્ય-કદના મૂલ્યો માટે, એક [`Box`] તેના ફાળવણી માટે [`Global`] ફાળવણીકારનો ઉપયોગ કરશે.[`Box`] અને [`Global`] ફાળવણીકાર સાથે ફાળવેલ કાચા પોઇન્ટર વચ્ચેની બંને રીતોને રૂપાંતરિત કરવા માટે માન્ય છે, જો કે ફાળવણીકાર સાથે વપરાયેલ [`Layout`] પ્રકાર માટે યોગ્ય છે.
//!
//! વધુ સ્પષ્ટ રીતે, એક `value:*mut T` જે [`Global`] ફાળવણી કરનાર સાથે `Layout::for_value(&* value)` સાથે ફાળવવામાં આવેલ છે તે [`Box::<T>::from_raw(value)`] નો ઉપયોગ કરીને બ intoક્સમાં રૂપાંતરિત થઈ શકે છે.
//! તેનાથી વિપરિત, [`Box::<T>::into_raw`] માંથી મેળવેલ `value:*mut T` ને ટેકો આપતી મેમરી, [`Layout::for_value(&* value)`] સાથે [`Global`] ફાળવણીકારનો ઉપયોગ કરીને ડિલોકટેડ થઈ શકે છે.
//!
//! શૂન્ય-કદના મૂલ્યો માટે, `Box` પોઇન્ટર હજી પણ વાંચવા અને લખવા માટે [valid] હોવું જોઈએ અને પૂરતા પ્રમાણમાં ગોઠવાયેલ છે.
//! ખાસ કરીને, કોઈપણ અલાઈન ન nonન-શૂન્ય પૂર્ણાંકને કાચા પોઇન્ટર પર કાસ્ટ કરવાથી એક માન્ય પોઇન્ટર ઉત્પન્ન થાય છે, પરંતુ જે નિર્દેશક અગાઉ ફાળવેલ મેમરીમાં નિર્દેશ કરે છે તે મુક્ત નથી.
//! જો `Box::new` નો ઉપયોગ ન કરી શકાય તો ZST પર બ buildક્સ બનાવવાની ભલામણ કરેલ રીત એ [`ptr::NonNull::dangling`] નો ઉપયોગ કરવો છે.
//!
//! `T: Sized` સુધી, `Box<T>` એ એકલ નિર્દેશક તરીકે રજૂ થવાની બાંયધરી આપવામાં આવે છે અને તે સી પોઇંટર્સ (એટલે કે સી પ્રકાર `T*`) સાથે એબીઆઈ સુસંગત પણ છે.
//! આનો અર્થ એ છે કે જો તમારી પાસે બાહ્ય "C" Rust વિધેયો છે જે સી થી કહેવાશે, તો તમે તે X0Rust0Z કાર્યો `Box<T>` પ્રકારોનો ઉપયોગ કરીને વ્યાખ્યાયિત કરી શકો છો, અને સી બાજુ પર સંબંધિત પ્રકાર તરીકે `T*` નો ઉપયોગ કરી શકો છો.
//! ઉદાહરણ તરીકે, આ સી હેડરને ધ્યાનમાં લો જે વિધેયો જાહેર કરે છે જે અમુક પ્રકારના `Foo` મૂલ્ય બનાવે છે અને તેનો નાશ કરે છે:
//!
//! ```c
//! /* સી હેડર */
//!
//! /* કlerલરને માલિકી પરત કરે છે */
//! struct Foo* foo_new(void);
//!
//! /* કlerલરની માલિકી લે છે;જ્યારે NULL સાથે જોડાણ કરવામાં આવે ત્યારે કોઈ વિકલ્પ નહીં */
//! void foo_delete(struct Foo*);
//! ```
//!
//! આ બંને વિધેયો નીચે મુજબ Rust માં અમલમાં આવી શકે છે.અહીં, સીથી `struct Foo*` પ્રકારનું ભાષાંતર `Box<Foo>` માં કરવામાં આવ્યું છે, જે માલિકીના અવરોધોને કબજે કરે છે.
//! એ પણ નોંધ લો કે `foo_delete` નો નulલ્બલ દલીલ Rust માં `Option<Box<Foo>>` તરીકે રજૂ થાય છે, કારણ કે `Box<Foo>` નલ હોઈ શકતું નથી.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! તેમ છતાં `Box<T>` ની સમાન રજૂઆત છે અને સી ABI એ સી પોઇન્ટર તરીકે છે, તેનો અર્થ એ નથી કે તમે મનસ્વી `T*` ને `Box<T>` માં રૂપાંતરિત કરી શકો છો અને વસ્તુઓની અપેક્ષા રાખી શકો છો.
//! `Box<T>` મૂલ્યો હંમેશાં સંપૂર્ણ રીતે ગોઠવાયેલ રહેશે, ન-ન-નલ પોઇન્ટર.તદુપરાંત, `Box<T>` માટેનો વિનાશક વૈશ્વિક ફાળવણીકાર સાથે મૂલ્યને મુક્ત કરવાનો પ્રયાસ કરશે.સામાન્ય રીતે, વૈશ્વિક ફાળવણીકારમાંથી ઉદ્ભવતા પોઇંટરો માટે ફક્ત `Box<T>` નો ઉપયોગ કરવો શ્રેષ્ઠ પ્રથા છે.
//!
//! **મહત્વપૂર્ણ.** ઓછામાં ઓછા હાલમાં, તમારે વિધેયો માટે `Box<T>` પ્રકારોનો ઉપયોગ કરવાનું ટાળવું જોઈએ કે જે સીમાં નિર્ધારિત છે, પરંતુ ઝેડ રસ્ટ0 ઝેડથી વિનંતી કરવામાં આવશે.તે કિસ્સાઓમાં, તમારે સી પ્રકારોને શક્ય તેટલું નજીકથી મિરર કરવું જોઈએ.
//! `Box<T>` જેવા પ્રકારોનો ઉપયોગ કરવો જ્યાં સી વ્યાખ્યા ફક્ત `T*` નો ઉપયોગ કરે છે તે [rust-lang/unsafe-code-guidelines#198][ucg#198] માં વર્ણવ્યા અનુસાર, અસ્પષ્ટ વર્તન તરફ દોરી શકે છે.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Apગલા ફાળવણી માટેનો નિર્દેશક પ્રકાર.
///
/// વધુ માટે [module-level documentation](../../std/boxed/index.html) જુઓ.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Heગલા પર મેમરી ફાળવે છે અને પછી તેમાં `x` મૂકે છે.
    ///
    /// જો ખરેખર `T` શૂન્ય-કદનું હોય તો આ ફાળવણી કરતું નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// અનિટિએટલાઇઝ્ડ સમાવિષ્ટો સાથે એક નવો બ Constક્સ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// એક્સિટિલાઇઝ્ડ સમાવિષ્ટો સાથે એક નવું `Box` બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// નવું `Pin<Box<T>>` બનાવે છે.
    /// જો `T` એ `Unpin` અમલમાં ન મૂક્યું, તો પછી `x` મેમરીમાં પિન થઈ જશે અને ખસેડવામાં અસમર્થ હશે.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Heગલા પર મેમરી ફાળવે છે પછી `x` તેમાં મૂકે છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો
    ///
    ///
    /// જો ખરેખર `T` શૂન્ય-કદનું હોય તો આ ફાળવણી કરતું નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો આપીને, apગલા પર બિન-ઉપયોગી સામગ્રી સાથે એક નવો બ Constક્સ બનાવે છે
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Uninગલા પર `0` બાઇટ્સથી મેમરી ભરાઈ જવા સાથે, અનઇંટિએટલાઇઝ્ડ સામગ્રીઓ સાથે એક નવું `Box` બનાવે છે
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// આપેલ ફાળવણીકારમાં મેમરી ફાળવે છે પછી તેમાં `x` મૂકે છે.
    ///
    /// જો ખરેખર `T` શૂન્ય-કદનું હોય તો આ ફાળવણી કરતું નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// આપેલ ફાળવણીકારમાં મેમરી ફાળવે છે પછી તેમાં `x` મૂકે છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો આવે છે
    ///
    ///
    /// જો ખરેખર `T` શૂન્ય-કદનું હોય તો આ ફાળવણી કરતું નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// પ્રદાન કરેલા ફાળવણીકારમાં અનિટિએટલાઇઝ્ડ સમાવિષ્ટો સાથે એક નવો બ Constક્સ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: બંધને ક્યારેક ઇનલાઇન કરી શકાય નહીં ત્યારથી અનપ્રેપ_અર_અન્ય પર મેચ પસંદ કરો.
        // તે કોડનું કદ મોટું બનાવશે.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પરત આપીને, પૂરા પાડવામાં આવેલ ફાળવણીકારમાં બિન-ઉપયોગી સામગ્રી સાથે એક નવો બ Constક્સ બનાવે છે
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// પ્રદાન કરેલા ફાળવણીકારમાં `0` બાઇટ્સથી મેમરી ભરાઈ જવાને, અનહિતીકરણવાળી સામગ્રી સાથે એક નવું `Box` બનાવે છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: બંધને ક્યારેક ઇનલાઇન કરી શકાય નહીં ત્યારથી અનપ્રેપ_અર_અન્ય પર મેચ પસંદ કરો.
        // તે કોડનું કદ મોટું બનાવશે.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// પૂરી પાડવામાં આવેલ ફાળવણીકારમાં `0` બાઇટ્સથી મેમરી ભરાઈ જાય છે, ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો આવે છે, અનઇંટિએટલાઇઝ્ડ સમાવિષ્ટો સાથે એક નવું `Box` બનાવે છે,
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// નવું `Pin<Box<T, A>>` બનાવે છે.
    /// જો `T` એ `Unpin` અમલમાં ન મૂક્યું, તો પછી `x` મેમરીમાં પિન થઈ જશે અને ખસેડવામાં અસમર્થ હશે.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ને `Box<[T]>` માં ફેરવે છે
    ///
    /// આ રૂપાંતર apગલા પર ફાળવણી કરતું નથી અને તે જગ્યાએ થાય છે.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// આવરિત મૂલ્ય પરત કરીને, `Box` લે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// અનહિતીકૃત સામગ્રીઓ સાથે નવી બ boxક્સ્ડ સ્લાઈસ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// એક્સિટિએટલાઇઝ્ડ સામગ્રીઓ સાથે નવી બedક્સ્ડ સ્લાઈસ બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// પ્રદાન કરેલા ફાળવણીકારમાં અનિટિટાઈઝ્ડ સમાવિષ્ટો સાથે નવી બedક્સ્ડ સ્લાઈસ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// `0` બાઇટ્સ સાથે મેમરી ભરેલી સાથે, પ્રદાન કરેલ ફાળવણીકારમાં અનહિતીકરણની સામગ્રી સાથે નવી બedક્સ્ડ સ્લાઈસ બનાવે છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, તે મૂલ્ય ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક theલ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, તે મૂલ્ય ખરેખર પ્રારંભિક સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક theલ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// કાચા પોઇન્ટરથી બ Constક્સ બનાવે છે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કાચો પોઇન્ટર પરિણામી `Box` ની માલિકીનું છે.
    /// ખાસ કરીને, `Box` ડિસ્ટ્રક્ટર `T` ના ડિસ્ટ્રક્ટરને ક callલ કરશે અને ફાળવેલ મેમરીને મુક્ત કરશે.
    /// આ સુરક્ષિત રહેવા માટે, `Box` દ્વારા વપરાયેલી [memory layout] અનુસાર મેમરીને ફાળવવામાં આવવી આવશ્યક છે.
    ///
    ///
    /// # Safety
    ///
    /// આ કાર્ય અસુરક્ષિત છે કારણ કે અયોગ્ય ઉપયોગથી મેમરી સમસ્યાઓ થઈ શકે છે.
    /// ઉદાહરણ તરીકે, જો ફંક્શનને સમાન કાચા પોઇન્ટર પર બે વાર કહેવામાં આવે તો ડબલ-ફ્રી થઈ શકે છે.
    ///
    /// સલામતીની સ્થિતિનું વર્ણન [memory layout] વિભાગમાં કરવામાં આવ્યું છે.
    ///
    /// # Examples
    ///
    /// એક `Box` ફરીથી બનાવો જે અગાઉ [`Box::into_raw`] નો ઉપયોગ કરીને કાચા નિર્દેશકમાં રૂપાંતરિત થયો હતો:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// વૈશ્વિક ફાળવણીકારનો ઉપયોગ કરીને જાતે શરૂઆતથી એક `Box` બનાવો:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // સામાન્ય રીતે .write એ `ptr` ના (uninitialized) અગાઉના સમાવિષ્ટોનો વિનાશ કરવાનો પ્રયાસ કરવાનું ટાળવું જરૂરી છે, જો કે આ સરળ ઉદાહરણ માટે `*ptr = 5` એ પણ કામ કર્યું હોત.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// આપેલ ફાળવણીકારમાં કાચા પોઇન્ટરથી બ Constક્સ બનાવે છે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કાચો પોઇન્ટર પરિણામી `Box` ની માલિકીનું છે.
    /// ખાસ કરીને, `Box` ડિસ્ટ્રક્ટર `T` ના ડિસ્ટ્રક્ટરને ક callલ કરશે અને ફાળવેલ મેમરીને મુક્ત કરશે.
    /// આ સુરક્ષિત રહેવા માટે, `Box` દ્વારા વપરાયેલી [memory layout] અનુસાર મેમરીને ફાળવવામાં આવવી આવશ્યક છે.
    ///
    ///
    /// # Safety
    ///
    /// આ કાર્ય અસુરક્ષિત છે કારણ કે અયોગ્ય ઉપયોગથી મેમરી સમસ્યાઓ થઈ શકે છે.
    /// ઉદાહરણ તરીકે, જો ફંક્શનને સમાન કાચા પોઇન્ટર પર બે વાર કહેવામાં આવે તો ડબલ-ફ્રી થઈ શકે છે.
    ///
    /// # Examples
    ///
    /// એક `Box` ફરીથી બનાવો જે અગાઉ [`Box::into_raw_with_allocator`] નો ઉપયોગ કરીને કાચા નિર્દેશકમાં રૂપાંતરિત થયો હતો:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// સિસ્ટમ ફાળવણીકારનો ઉપયોગ કરીને જાતે શરૂઆતથી એક `Box` બનાવો:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // સામાન્ય રીતે .write એ `ptr` ના (uninitialized) અગાઉના સમાવિષ્ટોનો વિનાશ કરવાનો પ્રયાસ કરવાનું ટાળવું જરૂરી છે, જો કે આ સરળ ઉદાહરણ માટે `*ptr = 5` એ પણ કામ કર્યું હોત.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// વીંટાળેલા કાચા નિર્દેશકને પરત કરીને, `Box` લે છે.
    ///
    /// નિર્દેશક યોગ્ય રીતે સંરેખિત અને બિન-નલ હશે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કlerલર એ `Box` દ્વારા અગાઉ સંચાલિત મેમરી માટે જવાબદાર છે.
    /// ખાસ કરીને, કlerલરે `T` નો યોગ્ય રીતે નાશ કરવો જોઈએ અને `Box` દ્વારા ઉપયોગમાં લેવાયેલા [memory layout] ને ધ્યાનમાં રાખીને મેમરીને મુક્ત કરવી જોઈએ.
    /// આ કરવાનો સૌથી સહેલો રસ્તો એ [`Box::from_raw`] ફંક્શન સાથે કાચા પોઇન્ટરને પાછા `Box` માં રૂપાંતરિત કરવો, `Box` ડિસ્ટ્રક્ટરને ક્લિનઅપ કરવાની મંજૂરી આપી.
    ///
    ///
    /// Note: આ એક સંબંધિત કાર્ય છે, જેનો અર્થ છે કે તમારે તેને `b.into_raw()` ને બદલે `Box::into_raw(b)` તરીકે ક callલ કરવો પડશે.
    /// આ એટલા માટે છે કે આંતરિક પ્રકાર પરની પદ્ધતિ સાથે કોઈ વિરોધાભાસ નથી.
    ///
    /// # Examples
    /// સ્વચાલિત સફાઇ માટે [`Box::from_raw`] વડે કાચા નિર્દેશકને પાછા `Box` માં ફેરવવું:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ડિસ્ટ્રક્ટરને સ્પષ્ટ રૂપે ચલાવીને અને મેમરીને વિક્ષુત કરીને મેન્યુઅલ સફાઇ:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// આવરિત કાચા પોઇન્ટર અને ફાળવણીકારને પરત કરીને, `Box` લે છે.
    ///
    /// નિર્દેશક યોગ્ય રીતે સંરેખિત અને બિન-નલ હશે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કlerલર એ `Box` દ્વારા અગાઉ સંચાલિત મેમરી માટે જવાબદાર છે.
    /// ખાસ કરીને, કlerલરે `T` નો યોગ્ય રીતે નાશ કરવો જોઈએ અને `Box` દ્વારા ઉપયોગમાં લેવાયેલા [memory layout] ને ધ્યાનમાં રાખીને મેમરીને મુક્ત કરવી જોઈએ.
    /// આ કરવાનો સૌથી સહેલો રસ્તો એ [`Box::from_raw_in`] ફંક્શન સાથે કાચા પોઇન્ટરને પાછા `Box` માં રૂપાંતરિત કરવો, `Box` ડિસ્ટ્રક્ટરને ક્લિનઅપ કરવાની મંજૂરી આપી.
    ///
    ///
    /// Note: આ એક સંબંધિત કાર્ય છે, જેનો અર્થ છે કે તમારે તેને `b.into_raw_with_allocator()` ને બદલે `Box::into_raw_with_allocator(b)` તરીકે ક callલ કરવો પડશે.
    /// આ એટલા માટે છે કે આંતરિક પ્રકાર પરની પદ્ધતિ સાથે કોઈ વિરોધાભાસ નથી.
    ///
    /// # Examples
    /// સ્વચાલિત સફાઇ માટે [`Box::from_raw_in`] વડે કાચા નિર્દેશકને પાછા `Box` માં ફેરવવું:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ડિસ્ટ્રક્ટરને સ્પષ્ટ રૂપે ચલાવીને અને મેમરીને વિક્ષુત કરીને મેન્યુઅલ સફાઇ:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // સ્ટેક્ડ બોરો દ્વારા બ Boxક્સને "unique pointer" તરીકે માન્યતા આપવામાં આવે છે, પરંતુ આંતરિક રીતે તે ટાઇપ સિસ્ટમ માટેનો કાચો નિર્દેશક છે.
        // તેને સીધા કાચા પોઇન્ટરમાં ફેરવવાનું એલિએઝ્ડ કાચા પ્રવેશને મંજૂરી આપવા માટેના અનન્ય પોઇન્ટર "releasing" તરીકે ઓળખાશે નહીં, તેથી બધી કાચા નિર્દેશક પદ્ધતિઓએ `Box::leak` પસાર થવું પડશે.
        //
        // કાચા પોઇન્ટર તરફ વળવું *કે* યોગ્ય રીતે વર્તે છે.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// અંતર્ગત ફાળવણીકારનો સંદર્ભ આપે છે.
    ///
    /// Note: આ એક સંબંધિત કાર્ય છે, જેનો અર્થ છે કે તમારે તેને `b.allocator()` ને બદલે `Box::allocator(&b)` તરીકે ક callલ કરવો પડશે.
    /// આ એટલા માટે છે કે આંતરિક પ્રકાર પરની પદ્ધતિ સાથે કોઈ વિરોધાભાસ નથી.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` ખાય છે અને લીક કરે છે, પરિવર્તનીય સંદર્ભ આપે છે, `&'a mut T`.
    /// નોંધ લો કે પ્રકાર `T` એ પસંદ કરેલા જીવનકાળ `'a` ને આઉટલિવ કરવું આવશ્યક છે.
    /// જો પ્રકારમાં ફક્ત સ્થિર સંદર્ભો છે, અથવા કોઈ પણ નથી, તો પછી તે `'static` તરીકે પસંદ કરી શકાય છે.
    ///
    /// આ કાર્ય મુખ્યત્વે ડેટા માટે ઉપયોગી છે જે પ્રોગ્રામના જીવનના બાકીના સમય માટે જીવે છે.
    /// પરત થયેલ સંદર્ભ છોડી દેવાથી મેમરી લિક થશે.
    /// જો આ સ્વીકાર્ય ન હોય તો, સંદર્ભ પ્રથમ `Box` એક્સ ફંક્શન સાથે આવરી લેવો જોઈએ જે `Box` ઉત્પન્ન કરે છે.
    ///
    /// ત્યારબાદ આ `Box` છોડી શકાય છે જે `T` ને યોગ્ય રીતે નાશ કરશે અને ફાળવેલ મેમરીને મુક્ત કરશે.
    ///
    /// Note: આ એક સંબંધિત કાર્ય છે, જેનો અર્થ છે કે તમારે તેને `b.leak()` ને બદલે `Box::leak(b)` તરીકે ક callલ કરવો પડશે.
    /// આ એટલા માટે છે કે આંતરિક પ્રકાર પરની પદ્ધતિ સાથે કોઈ વિરોધાભાસ નથી.
    ///
    /// # Examples
    ///
    /// સરળ ઉપયોગ:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// અનસાઇઝ્ડ ડેટા:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ને `Pin<Box<T>>` માં ફેરવે છે
    ///
    /// આ રૂપાંતર apગલા પર ફાળવણી કરતું નથી અને તે જગ્યાએ થાય છે.
    ///
    /// આ [`From`] દ્વારા પણ ઉપલબ્ધ છે.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // જ્યારે `T: !Unpin` હોય ત્યારે `Pin<Box<T>>` ની અંદરની જગ્યા ખસેડવી અથવા બદલી શક્ય નથી, તેથી કોઈપણ વધારાની આવશ્યકતાઓ વિના તેને સીધો પિન કરવું સલામત છે.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: કંઇ કરશો નહીં, ડ્રોપ હાલમાં કમ્પાઇલર દ્વારા કરવામાં આવે છે.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// ટી માટેના `Default` મૂલ્ય સાથે, એક `Box<T>` બનાવે છે.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// આ બ'sક્સની સામગ્રીના `clone()` સાથે એક નવો બ Returnક્સ પાછો આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // મૂલ્ય સમાન છે
    /// assert_eq!(x, y);
    ///
    /// // પરંતુ તેઓ અનન્ય પદાર્થો છે
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // ક્લોન કરેલ મૂલ્યને સીધા લખવાની મંજૂરી આપવા માટે પૂર્વ-ફાળવણી મેમરી.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// નવું ફાળવણી બનાવ્યા વિના `સ્રોત'ની સામગ્રીને `self` માં ક Copપિ કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // મૂલ્ય સમાન છે
    /// assert_eq!(x, y);
    ///
    /// // અને કોઈ ફાળવણી થઈ નથી
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // આ ડેટાની એક નકલ બનાવે છે
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// સામાન્ય પ્રકાર `T` ને `Box<T>` માં રૂપાંતરિત કરે છે
    ///
    /// રૂપાંતર apગલા પર ફાળવે છે અને તેમાં `t` ને સ્ટેકમાંથી ખસેડે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ને `Pin<Box<T>>` માં ફેરવે છે
    ///
    /// આ રૂપાંતર apગલા પર ફાળવણી કરતું નથી અને તે જગ્યાએ થાય છે.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ને `Box<[T]>` માં ફેરવે છે
    ///
    /// આ રૂપાંતર apગલા પર ફાળવે છે અને `slice` ની નકલ કરે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // એક&[u8] બનાવો જેનો ઉપયોગ બ <ક્સ <[u8]> બનાવવા માટે કરવામાં આવશે
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ને `Box<str>` માં ફેરવે છે
    ///
    /// આ રૂપાંતર apગલા પર ફાળવે છે અને `s` ની નકલ કરે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ને `Box<[u8]>` માં ફેરવે છે
    /// આ રૂપાંતર apગલા પર ફાળવણી કરતું નથી અને તે જગ્યાએ થાય છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // એક બ createક્સ બનાવો<str>જેનો ઉપયોગ બ <ક્સ <[u8]> બનાવવા માટે કરવામાં આવશે
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // એક&[u8] બનાવો જેનો ઉપયોગ બ <ક્સ <[u8]> બનાવવા માટે કરવામાં આવશે
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ને `Box<[T]>` માં ફેરવે છે
    /// આ રૂપાંતર એરેને નવી apગલાની ફાળવેલ મેમરીમાં ખસેડે છે.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// કોંક્રિટ પ્રકારના બ concreteક્સને ડાઉનકાસ્ટ કરવાનો પ્રયાસ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// કોંક્રિટ પ્રકારના બ concreteક્સને ડાઉનકાસ્ટ કરવાનો પ્રયાસ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// કોંક્રિટ પ્રકારના બ concreteક્સને ડાઉનકાસ્ટ કરવાનો પ્રયાસ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // આંતરિક યુનિકને સીધા બ Boxક્સમાંથી બહાર કા possibleવું શક્ય નથી, તેના બદલે અમે તેને * કોન્સ્ટ પર કાસ્ટ કરીએ છીએ જે અનન્યને ઉપનામ આપે છે
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// કદના for I`s માટે વિશેષતા કે જે ડિફોલ્ટને બદલે `last()` ના implementation I`s ના અમલીકરણનો ઉપયોગ કરે છે.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}