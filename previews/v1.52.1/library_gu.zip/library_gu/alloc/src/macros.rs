/// દલીલોવાળી એક [`Vec`] બનાવે છે.
///
/// `vec!` `Vec`s ને એરે અભિવ્યક્તિઓ જેવા સમાન વાક્યરચના સાથે વ્યાખ્યાયિત કરવાની મંજૂરી આપે છે.
/// આ મેક્રોના બે સ્વરૂપો છે:
///
/// - તત્વોની આપેલ સૂચિવાળા [`Vec`] બનાવો:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - આપેલ તત્વ અને કદમાંથી એક [`Vec`] બનાવો:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// નોંધ લો કે એરે અભિવ્યક્તિઓથી વિપરીત આ વાક્યરચના બધા તત્વોને સમર્થન આપે છે જે [`Clone`] ને લાગુ કરે છે અને તત્વોની સંખ્યા સતત હોવી જોઈએ નહીં.
///
/// આ અભિવ્યક્તિની ડુપ્લિકેટ કરવા માટે `clone` નો ઉપયોગ કરશે, તેથી નોન-સ્ટેન્ડર્ડ `Clone` અમલીકરણવાળા પ્રકારો સાથે આનો ઉપયોગ કરીને ખૂબ કાળજી લેવી જોઈએ.
/// ઉદાહરણ તરીકે, `vec![Rc::new(1);]] Same એ જ બedક્સ્ડ પૂર્ણાંક મૂલ્યના પાંચ સંદર્ભોનું એક vector બનાવશે, સ્વતંત્ર રીતે બedક્સ્ડ પૂર્ણાંકો તરફ નિર્દેશ કરતા પાંચ સંદર્ભો નહીં.
///
///
/// પણ, નોંધ લો કે `vec![expr; 0]` ને મંજૂરી છે, અને ખાલી vector ઉત્પન્ન કરે છે.
/// આ હજી પણ `expr` નું મૂલ્યાંકન કરશે, અને તરત જ પરિણામી મૂલ્યને છોડી દેશે, તેથી આડઅસરોને ધ્યાનમાં રાખવું.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) સાથે અંતર્ગત `[T]::into_vec` પદ્ધતિ, જે આ મેક્રો વ્યાખ્યા માટે જરૂરી છે, ઉપલબ્ધ નથી.
// તેના બદલે `slice::into_vec` ફંક્શનનો ઉપયોગ કરો જે ફક્ત cfg(test) NB સાથે જ ઉપલબ્ધ છે વધુ માહિતી માટે slice.rs માં slice::hack મોડ્યુલ જુઓ
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// રનટાઇમ અભિવ્યક્તિઓના ઇન્ટરપોલેશનનો ઉપયોગ કરીને એક `String` બનાવે છે.
///
/// પ્રથમ દલીલ `format!` એ એક ફોર્મેટ શબ્દમાળા છે.આ શબ્દમાળા હોવું જ જોઈએ.ફોર્મેટિંગ સ્ટ્રિંગની શક્તિ સમાયેલ in {. In s માં છે.
///
/// `format!` પર પસાર થયેલા વધારાના પરિમાણો નામ અથવા સ્થિતિના પરિમાણોનો ઉપયોગ ન થાય ત્યાં સુધી આપવામાં આવેલા ક્રમમાં ફોર્મેટિંગ સ્ટ્રિંગની અંદર replace {}; replace ને બદલો;વધુ માહિતી માટે [`std::fmt`] જુઓ.
///
///
/// `format!` નો સામાન્ય ઉપયોગ એ કatenન્ટેટેશન અને શબ્દમાળાઓનો પ્રકોપ છે.
/// સમાન સંમેલનનો ઉપયોગ શબ્દમાળાના હેતુવાળા ગંતવ્યના આધારે, [`print!`] અને [`write!`] મેક્રોઝ સાથે થાય છે.
///
/// સિંગલ વેલ્યુને સ્ટ્રિંગમાં કન્વર્ટ કરવા માટે, [`to_string`] મેથડનો ઉપયોગ કરો.આ [`Display`] ફોર્મેટિંગ trait નો ઉપયોગ કરશે.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics જો ફોર્મેટિંગ trait અમલીકરણ ભૂલ આપે છે.
/// આ ખોટું અમલીકરણ સૂચવે છે કારણ કે `fmt::Write for String` ક્યારેય ભૂલને પાછો આપતો નથી.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// પેટર્નની સ્થિતિમાં ડાયગ્નોસ્ટિક્સ સુધારવા માટે એએસટી નોડને અભિવ્યક્તિ પર દબાણ કરો.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}