use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// નોડ્સમાં તત્વોની ન્યૂનતમ સંખ્યા કે જે મૂળ નથી.
/// આપણી પાસે પદ્ધતિઓ દરમિયાન અસ્થાયીરૂપે ઓછા તત્વો હોઈ શકે છે.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// `BTreeMap` માં એક વૃક્ષ એ `node` મોડ્યુલમાં વધારાના આક્રમણકારો સાથેનું એક વૃક્ષ છે:
// - કીઓ ચડતા ક્રમમાં દેખાવી આવશ્યક છે (કીના પ્રકાર અનુસાર)
// - જો રુટ નોડ આંતરિક હોય, તો તેમાં ઓછામાં ઓછું 1 તત્વ હોવું આવશ્યક છે.
// - દરેક નોન-રુટ નોડમાં ઓછામાં ઓછા MIN_LEN તત્વો હોય છે.
//
// ખાલી નકશો રુટ નોડની ગેરહાજરી દ્વારા અથવા રુટ નોડ દ્વારા રજૂ કરી શકાય છે જે ખાલી પર્ણ છે.
//

/// [B-Tree] પર આધારિત નકશો.
///
/// બી-વૃક્ષો કેશ-કાર્યક્ષમતા અને ખરેખર શોધમાં કરવામાં આવેલા કાર્યની માત્રાને ઘટાડવા વચ્ચેના મૂળભૂત સમાધાનનું પ્રતિનિધિત્વ કરે છે.સિદ્ધાંતમાં, બાઈનરી સર્ચ ટ્રી X01 એક્સ એ સ sર્ટ કરેલા નકશા માટે શ્રેષ્ઠ પસંદગી છે, કેમ કે એક સંપૂર્ણ સંતુલિત બીએસટી તત્વ (log<sub>2</sub>n) શોધવા માટે જરૂરી તુલનાત્મકની સૈદ્ધાંતિક લઘુત્તમ માત્રા કરે છે.
/// જો કે, વ્યવહારમાં આ રીતે કરવામાં આવે છે આધુનિક કમ્પ્યુટર આર્કિટેક્ચરો માટે *ખૂબ* બિનકાર્યક્ષમ.
/// ખાસ કરીને, દરેક તત્વ તેના પોતાના વ્યક્તિગત રૂપે apગલા-ફાળવેલ નોડમાં સંગ્રહિત થાય છે.
/// આનો અર્થ છે કે પ્રત્યેક નિવેશ એ apગલા-ફાળવણીને ટ્રિગર કરે છે, અને દરેક એક સરખામણી કેશ-મિસ હોવી જોઈએ.
/// વ્યવહારમાં આ બંને નોંધપાત્ર ખર્ચાળ ચીજો હોવાથી, અમને ઓછામાં ઓછા બીએસટી વ્યૂહરચના પર ફરીથી વિચાર કરવાની ફરજ પડી છે.
///
/// બી-ટ્રી તેના બદલે દરેક નોડમાં B-1 થી 2B-1 એલિમેન્ટ્સને એક સુસંગત એરેમાં સમાવે છે.આ કરીને, અમે બીના પરિબળ દ્વારા ફાળવણીની સંખ્યા ઘટાડીએ છીએ, અને શોધમાં કacheશ કાર્યક્ષમતામાં સુધારો કરીએ છીએ.જો કે, આનો અર્થ એ નથી કે શોધમાં સરેરાશ *વધુ* તુલના કરવી પડશે.
/// સરખામણીની ચોક્કસ સંખ્યા વપરાયેલી નોડ શોધ વ્યૂહરચના પર આધારિત છે.શ્રેષ્ઠ કેશ કાર્યક્ષમતા માટે, કોઈ નોડોને રેખીય રીતે શોધી શકશે.શ્રેષ્ઠ તુલના માટે, કોઈ દ્વિસંગી શોધનો ઉપયોગ કરીને નોડ શોધી શકે છે.એક સમાધાન તરીકે, એક પણ રેખીય શોધ છે, જે શરૂઆતમાં માત્ર હું કેટલાક પસંદગી માટે દરેક હું <sup>મા</sup> તત્વ ચેક્સ શકે છે.
///
/// હાલમાં, અમારું અમલીકરણ સરળ નિષ્ક્રીય રેખીય શોધ કરે છે.આ તત્વોના *નાના* ગાંઠો પર સરસ કામગીરી પ્રદાન કરે છે જેની તુલના કરવી સસ્તી છે.જો કે ઝેડ ફ્યુચર0 ઝેડમાં અમે બી ની પસંદગી, અને સંભવત અન્ય પરિબળો પર આધારિત શ્રેષ્ઠ શોધ વ્યૂહરચના પસંદ કરવાનું વધુ સંશોધન કરવા માંગીએ છીએ.રેખીય શોધનો ઉપયોગ કરીને, રેન્ડમ તત્વની શોધમાં O(B * log(n)) સરખામણી લેવાની અપેક્ષા છે, જે સામાન્ય રીતે BST કરતા વધુ ખરાબ હોય છે.
///
/// વ્યવહારમાં, તેમ છતાં, પ્રદર્શન ઉત્તમ છે.
///
/// કીને એવી રીતે સુધારવી તે તર્કની ભૂલ છે કે [`Ord`] trait દ્વારા નિર્ધારિત મુજબ, કીની કોઈપણ અન્ય કીને લગતી orderર્ડરિંગ, જ્યારે તે નકશામાં હોય ત્યારે બદલાય છે.આ સામાન્ય રીતે ફક્ત [`Cell`], [`RefCell`], વૈશ્વિક રાજ્ય, I/O અથવા અસુરક્ષિત કોડ દ્વારા શક્ય છે.
/// આવી તર્ક ભૂલથી પરિણમેલા વર્તનનો ઉલ્લેખ કરવામાં આવ્યો નથી, પરંતુ પરિણામની અસ્પષ્ટ વર્તનમાં પરિણમશે નહીં.આમાં ઝેડ 0 પicsનિક્સ 0 ઝેડ, ખોટા પરિણામો, વિયોગો, મેમરી લિક અને સમાપ્ત ન થવાનો સમાવેશ થઈ શકે છે.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // પ્રકાર અનુમાન અમને સ્પષ્ટ પ્રકારનાં સહીને બાકાત કરવા દે છે (જે આ ઉદાહરણમાં `BTreeMap<&str, &str>` હશે).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // કેટલીક મૂવીઝની સમીક્ષા કરો.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // ચોક્કસ માટે તપાસો.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // અરેરે, આ સમીક્ષામાં જોડણીની ઘણી ભૂલો છે, ચાલો તેને કા deleteી નાખો.
/// movie_reviews.remove("The Blues Brothers");
///
/// // કેટલીક કીઓ સાથે સંકળાયેલ મૂલ્યો જુઓ.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // કી માટેનું મૂલ્ય જુઓ (જો કી ન મળે તો ઝેડપૈનિક 0 ઝેડ હશે).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // બધું ઉપર ફરી વળવું.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` એક [`Entry API`] પણ લાગુ કરે છે, જે કીઓ અને તેમના મૂલ્યો મેળવવા, સેટ કરવાની, અપડેટ કરવાની અને દૂર કરવાની વધુ જટિલ પદ્ધતિઓ માટે પરવાનગી આપે છે:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // પ્રકાર અનુમાન અમને સ્પષ્ટ પ્રકારનાં સહીને બાકાત કરવા દે છે (જે આ ઉદાહરણમાં `BTreeMap<&str, u8>` હશે).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // ખરેખર અહીં કેટલાક રેન્ડમ વેલ્યુ પરત આપી શકે છે, ચાલો હમણાં માટે અમુક નિશ્ચિત મૂલ્ય પરત કરીએ
/////
///     42
/// }
///
/// // કી દાખલ કરો જો તે પહેલાથી અસ્તિત્વમાં નથી
/// player_stats.entry("health").or_insert(100);
///
/// // ફંક્શનનો ઉપયોગ કરીને કી દાખલ કરો કે જે નવું મૂલ્ય પૂરો પાડે છે જો તે પહેલાથી અસ્તિત્વમાં નથી
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // કોઈ કીને અપડેટ કરો, સંભવત set સેટ ન થયેલ કીની સામે રક્ષણ આપો
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // અનપ્રેપ સફળ થાય છે કારણ કે આપણે હમણાં જ વીંટાળ્યું છે
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // અમે સબટ્રીને સીધી ડિસ્ટ્રક્ચર કરી શકતા નથી કારણ કે BTreeMap ડ્ર Dપને લાગુ કરે છે
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // આદર્શરીતે અમે અહીં `BTreeMap::new` ને ક callલ કરીશું, પરંતુ તેમાં `K છે:
            // ઓર્ડર-અવરોધ, જે આ પદ્ધતિનો અભાવ છે.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // અનપ્રેપ સફળ થાય છે કારણ કે ખાલી નથી
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// `BTreeMap` ની પ્રવેશો પર એક પુનરાવર્તક.
///
/// આ `struct`, [`BTreeMap`] પર [`iter`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` ની પ્રવેશો ઉપર પરિવર્તનીય પુનરાવર્તક.
///
/// આ `struct`, [`BTreeMap`] પર [`iter_mut`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// `BTreeMap` ની પ્રવેશો પર માલિકીની ઇટરેટર.
///
/// આ `struct` [`into_iter`] પદ્ધતિ દ્વારા [`BTreeMap`] (`IntoIterator` trait દ્વારા પ્રદાન કરાયેલ) દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// બાકીની વસ્તુઓ ઉપર સંદર્ભોનો ઇરેટર આપે છે.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// `IntoIter` નું એક સરળ સંસ્કરણ જે ડબલ-એન્ડ નથી અને તેનો એક જ હેતુ છે: `IntoIter` નું બાકીનું છોડવું.
/// તેથી તે પહેલાં `back` પાંદડા edge શોધવાની જરૂરિયાત વિના આખા વૃક્ષને છોડવાની સેવા આપે છે.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// `BTreeMap` ની કીઓ ઉપર એક ઇરેટર.
///
/// આ `struct`, [`BTreeMap`] પર [`keys`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` ના મૂલ્યો ઉપર એક પુનરાવર્તક.
///
/// આ `struct`, [`BTreeMap`] પર [`values`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` ના મૂલ્યો ઉપર એક પરિવર્તનીય પુનરાવર્તક.
///
/// આ `struct`, [`BTreeMap`] પર [`values_mut`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// `BTreeMap` ની કીઓ ઉપર માલિકીની ઇટરેટર.
///
/// આ `struct`, [`BTreeMap`] પર [`into_keys`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// `BTreeMap` ના મૂલ્યો પર માલિકીનું ઇટરેટર.
///
/// આ `struct`, [`BTreeMap`] પર [`into_values`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// એક `BTreeMap` માં પ્રવેશોની પેટા-રેન્જ પરનો ઇટરેટર.
///
/// આ `struct`, [`BTreeMap`] પર [`range`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` માં પ્રવેશોની પેટા-રેન્જમાં પરિવર્તનીય ઇટરેટર.
///
/// આ `struct`, [`BTreeMap`] પર [`range_mut`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // `K` અને `V` માં આક્રમક બનો
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// એક નવું, ખાલી `BTreeMap` બનાવે છે.
    ///
    /// તેના પોતાના પર કંઈપણ ફાળવતું નથી.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // એન્ટ્રીઝ હવે ખાલી નકશામાં દાખલ કરી શકાય છે
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// બધા તત્વોને દૂર કરીને, નકશાને સાફ કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// કીને અનુરૂપ મૂલ્યનો સંદર્ભ આપે છે.
    ///
    /// ચાવી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર ફોર્મ પર theર્ડરિંગ * કી પ્રકાર પરના ક્રમ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// પ્રદાન કરેલી કીને અનુરૂપ કી-મૂલ્યની જોડી પરત કરે છે.
    ///
    /// પૂરી પાડવામાં આવેલી કી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર આપેલ ફોર્મ *પર theર્ડરિંગ* કી પ્રકારનાં theર્ડરિંગ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// નકશામાં પ્રથમ કી-મૂલ્યની જોડી પરત કરે છે.
    /// આ જોડીની ચાવી નકશામાં લઘુતમ કી છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// ઇન-પ્લેસ મેનીપ્યુલેશન માટે નકશામાં પ્રથમ પ્રવેશ આપે છે.
    /// આ પ્રવેશની ચાવી નકશામાં લઘુતમ કી છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// નકશામાં પ્રથમ તત્વ દૂર કરે છે અને આપે છે.
    /// આ તત્વની ચાવી એ ન્યુનત્તમ કી છે જે નકશામાં હતી.
    ///
    /// # Examples
    ///
    /// તત્વોને ચડતા ક્રમમાં ડ્રોઇંગ કરો, જ્યારે દરેક પુનરાવૃત્તિને ઉપયોગી નકશો રાખતા હોવ.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// નકશામાં છેલ્લી કી-મૂલ્યની જોડી પરત કરે છે.
    /// આ જોડીની ચાવી નકશામાં મહત્તમ કી છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// ઇન-પ્લેસ મેનીપ્યુલેશન માટે નકશામાં છેલ્લી પ્રવેશ આપે છે.
    /// આ પ્રવેશની કી નકશામાં મહત્તમ કી છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// નકશામાં છેલ્લું તત્વ દૂર કરે છે અને આપે છે.
    /// આ તત્વની ચાવી મહત્તમ કી છે જે નકશામાં હતી.
    ///
    /// # Examples
    ///
    /// તત્વોને ઉતરતા ક્રમમાં ડ્રોઇંગ કરો, જ્યારે દરેક પુનરાવૃત્તિને ઉપયોગી નકશો રાખતા હોવ.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// જો નકશામાં ઉલ્લેખિત કી માટે મૂલ્ય હોય તો `true` પરત કરે છે.
    ///
    /// ચાવી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર ફોર્મ પર theર્ડરિંગ * કી પ્રકાર પરના ક્રમ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// કીને અનુરૂપ મૂલ્ય માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// ચાવી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર ફોર્મ પર theર્ડરિંગ * કી પ્રકાર પરના ક્રમ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // અમલીકરણ નોંધો માટે `get` જુઓ, આ મૂળ રૂપે મુટની ઉમેરવામાં આવેલી એક ક copyપિ પેસ્ટ છે
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// નકશામાં કી-મૂલ્યની જોડી શામેલ કરો.
    ///
    /// જો નકશામાં આ કી હાજર ન હોય તો, `None` પરત આવે છે.
    ///
    /// જો નકશામાં આ કી હાજર છે, તો મૂલ્ય અપડેટ કરવામાં આવે છે, અને જૂની કિંમત પરત આવે છે.
    /// કી અપડેટ થયેલ નથી, તેમ છતાં;આ તે પ્રકારના માટે મહત્વનું છે જે સમાન વિના `==` હોઈ શકે.
    ///
    /// વધુ માટે [module-level documentation] જુઓ.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// નકશામાં કી-મૂલ્યની જોડી દાખલ કરવાનો પ્રયાસ કરે છે, અને પ્રવેશના મૂલ્ય માટે પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// જો નકશામાં પહેલેથી જ આ કી હાજર છે, તો કંઈપણ અપડેટ કરવામાં આવતું નથી, અને કબજે કરેલા પ્રવેશ અને મૂલ્ય ધરાવતી ભૂલ પરત આવે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// નકશામાંથી કીને દૂર કરે છે, જો કી નકશામાં હોય તો કી પર મૂલ્ય પરત કરશે.
    ///
    /// ચાવી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર ફોર્મ પર theર્ડરિંગ * કી પ્રકાર પરના ક્રમ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// નકશામાંથી એક કીને દૂર કરે છે, સંગ્રહિત કી અને મૂલ્ય પરત કરે છે જો કી નકશામાં પહેલાં હોય.
    ///
    /// ચાવી નકશાના કી પ્રકારનું કોઈપણ ઉધાર સ્વરૂપ હોઈ શકે છે, પરંતુ ઉધાર ફોર્મ પર theર્ડરિંગ * કી પ્રકાર પરના ક્રમ સાથે મેળ ખાતો હોવો જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// પૂર્વજાત દ્વારા નિર્ધારિત ફક્ત તત્વો જ જાળવી રાખે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, બધા જોડીઓ `(k, v)` ને દૂર કરો જેમ કે `f(&k, &mut v)` `false` આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // ફક્ત સમાન ક્રમાંકિત કીઓવાળા તત્વો રાખો.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// `other` માંથી બધા ઘટકોને `Self` માં ખસેડે છે, `other` ને ખાલી છોડી દે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // શું આપણે કાંઈ પણ જોડવું પડશે?
        if other.is_empty() {
            return;
        }

        // જો `self` ખાલી છે, તો અમે ફક્ત `self` અને `other` બદલી શકીએ છીએ.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// નકશામાં તત્વોની પેટા-રેન્જમાં ડબલ-એન્ડેડ ઇટરેટર બનાવે છે.
    /// સરળ રીત એ છે કે રેન્જ સિંટેક્સ `min..max` નો ઉપયોગ કરવો, આમ `range(min..max)` એ મિનિમ (inclusive) થી મહત્તમ (exclusive) સુધી તત્વો આપશે.
    /// શ્રેણી `(Bound<T>, Bound<T>)` તરીકે પણ દાખલ થઈ શકે છે, તેથી `range((Excluded(4) ઉદાહરણ તરીકે, Included(10)))` 4 થી 10 સુધી ડાબી-વિશિષ્ટ, જમણી-સમાવિષ્ટ શ્રેણી પ્રાપ્ત કરશે.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો શ્રેણી `start > end` હોય.
    /// Panics, જો શ્રેણી `start == end` અને બંને સીમાઓ `Excluded` હોય.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// નકશામાં તત્વોની પેટા-રેન્જમાં પરિવર્તનીય ડબલ-એન્ડેડ ઇટરેટર બનાવે છે.
    /// સરળ રીત એ છે કે રેન્જ સિંટેક્સ `min..max` નો ઉપયોગ કરવો, આમ `range(min..max)` એ મિનિમ (inclusive) થી મહત્તમ (exclusive) સુધી તત્વો આપશે.
    /// શ્રેણી `(Bound<T>, Bound<T>)` તરીકે પણ દાખલ થઈ શકે છે, તેથી `range((Excluded(4) ઉદાહરણ તરીકે, Included(10)))` 4 થી 10 સુધી ડાબી-વિશિષ્ટ, જમણી-સમાવિષ્ટ શ્રેણી પ્રાપ્ત કરશે.
    ///
    ///
    /// # Panics
    ///
    /// Panics જો શ્રેણી `start > end` હોય.
    /// Panics, જો શ્રેણી `start == end` અને બંને સીમાઓ `Excluded` હોય.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// ઇન-પ્લેસ મેનીપ્યુલેશન માટે નકશામાં આપેલ કીની અનુરૂપ પ્રવેશ મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // વેકમાં અક્ષરોની સંખ્યાની ગણતરી કરો
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) જો અમે દાખલ ન કરીએ તો ફાળવણી કરવાનું ટાળો
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// આપેલ કી પર સંગ્રહને બે ભાગમાં વહેંચે છે.
    /// કી સહિતની આપેલ કી પછી બધું જ આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // અનપ્રેપ સફળ થાય છે કારણ કે ખાલી નથી

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// એક ઇરેટર બનાવે છે જે ચડતા કી ક્રમમાં બધા તત્વો (કી-વેલ્યુ જોડીઓ) ની મુલાકાત લે છે અને કોઈ તત્વને દૂર કરવું જોઈએ કે કેમ તે નિર્ધારિત કરવા માટે બંધનો ઉપયોગ કરે છે.
    /// જો ક્લોઝર `true` પરત કરે છે, તો તત્વ નકશામાંથી દૂર કરવામાં આવે છે અને ઉપજ મળે છે.
    /// જો ક્લોઝર `false`, અથવા panics પરત આપે છે, તો તત્વ નકશામાં રહે છે અને પ્રાપ્ત થશે નહીં.
    ///
    /// પુનરાવર્તક તમને ક્લોઝરમાં દરેક તત્વનું મૂલ્ય ફેરવવા દે છે, પછી ભલે તમે તેને રાખવા અથવા દૂર કરવાનું પસંદ કરો.
    ///
    /// જો ઇટરેટર ફક્ત આંશિક રીતે વપરાશ કરવામાં આવે છે અથવા તેનો વપરાશ જ નથી કરવામાં આવે તો, બાકીના દરેક તત્વો હજી પણ બંધ હોવાને આધિન હોય છે, જે તેનું મૂલ્ય બદલી શકે છે અને, `true` પરત કરીને, તત્વને કા removedી નાખે છે.
    ///
    ///
    /// જો panic બંધ થાય છે, અથવા એક તત્વ છોડતી વખતે panic થાય છે, અથવા જો `DrainFilter` મૂલ્ય લીક થાય છે, તો તે કેટલા વધુ તત્વોને બંધ કરવામાં આવશે તે અસ્પષ્ટ છે.
    ///
    /// # Examples
    ///
    /// અસલ અને વિચિત્ર કીઓમાં નકશાને વિભાજીત કરવો, મૂળ નકશાને ફરીથી વાપરીને:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// સ theર્ટ કરેલા ક્રમમાં, બધી કીઓની મુલાકાત લેતા વપરાશકાર ઇટરેટર બનાવે છે.
    /// આને બોલાવ્યા પછી નકશા વાપરી શકાશે નહીં.
    /// પુનરાવર્તક તત્વનો પ્રકાર `K` છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// કી દ્વારા ક્રમમાં, બધા મૂલ્યોની મુલાકાત લેતા વપરાશકાર ઇટરેટર બનાવે છે.
    /// આને બોલાવ્યા પછી નકશા વાપરી શકાશે નહીં.
    /// પુનરાવર્તક તત્વનો પ્રકાર `V` છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// બાકીની વસ્તુઓ ઉપર સંદર્ભોનો ઇરેટર આપે છે.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // ન-ન-ફ્યુઝિંગ ઇટરેટરને આગળ વધારવા જેવું જ.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // અમે નીચે કરીએ છીએ તે જ લૂપ ચાલુ રાખો.
                // આ ફક્ત અનડિંડિંગ કરતી વખતે ચાલે છે, તેથી આપણે આ વખતે ઝેડપેનિક્સ 0 ઝેડ વિશે કાળજી લેવાની જરૂર નથી (તે છોડી દેશે).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// બીટ્રીમેપ પર `drain_filter` પર ક byલ કરીને એક ઇટરેટર ઉત્પન્ન કર્યું.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// ડ્રેઇનફિલ્ટરનો મોટાભાગનો અમલીકરણ એ પ્રિડેક્ટના પ્રકાર પર સામાન્ય છે, આમ BTreeSet::DrainFilter માટે પણ સેવા આપે છે.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// ઉધાર લીધેલા નકશામાં લંબાઈના ક્ષેત્રનો સંદર્ભ, અપડેટ લાઇવ.
    length: &'a mut usize,
    /// ઉધાર લીધેલા નકશામાં મૂળ ક્ષેત્રમાં દફનાવવામાં આવેલા સંદર્ભ.
    /// તેને `take` પર ડ્રોપ હેન્ડલરને મંજૂરી આપવા માટે `Option` માં લપેટી.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// પાછા આપવાના આગલા તત્વ પહેલાંનાં પર્ણમાં edge અથવા છેલ્લું પર્ણ edge છે.
    /// ખાલી હોય તો જો નકશામાં મૂળ ન હોય, જો પુનરાવર્તન છેલ્લા પાંદડા edge કરતા આગળ વધ્યું હોય, અથવા જો કોઈ panic પૂર્વાનુમાનમાં આવ્યું હોય.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// ડિબગ અમલીકરણોને આગલા તત્વની આગાહી કરવાની મંજૂરી આપો.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// પ્રિડિકેટને આધારે લાક્ષણિક `DrainFilter::next` પદ્ધતિનો અમલ.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // સલામતી: આપણે રુટને એવી રીતે સ્પર્શ કરીશું જે નહીં થાય
                    // પરત થયેલ સ્થિતિને અમાન્ય કરો.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// લાક્ષણિક `DrainFilter::size_hint` પદ્ધતિનો અમલ.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // મોટાભાગના બીટ્રી ઇટરેટર્સમાં, `self.length` એ મુલાકાત લેવાની બાકી તત્વોની સંખ્યા છે.
        // અહીં, તેમાં એવા તત્વો શામેલ છે જેની મુલાકાત લીધી હતી અને તે પૂર્વજાણે drain ન કરવાનું નક્કી કર્યું હતું.
        // આ ઉપલા બાઉન્ડને વધુ સચોટ બનાવવા માટે એક વધારાનું ક્ષેત્ર જાળવવું જરૂરી છે અને તે યોગ્ય નથી.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// બાકીની વસ્તુઓ ઉપર સંદર્ભોનો ઇરેટર આપે છે.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// ખાલી `BTreeMap` બનાવે છે.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// પ્રદાન કરેલી કીને અનુરૂપ મૂલ્યનો સંદર્ભ આપે છે.
    ///
    /// # Panics
    ///
    /// જો કી `BTreeMap` માં હાજર ન હોય તો Panics.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// કી દ્વારા સortedર્ટ કરેલા નકશાની એન્ટ્રીઝ પર ઇરેટર મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// કી દ્વારા સortedર્ટ કરેલા નકશાની એન્ટ્રીઝ પર પરિવર્તનશીલ ઇટરેટર મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // કીમાં "a" ન હોય તો મૂલ્યમાં 10 ઉમેરો
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// સ sર્ટ કરેલા ક્રમમાં, નકશાની કીઝ પર ઇરેટર મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// કી દ્વારા ક્રમમાં, નકશાના મૂલ્યો પર ઇરેટર મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// કી દ્વારા ક્રમમાં, નકશાના મૂલ્યો પર એક પરિવર્તનીય ઇટરેટર મેળવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// નકશામાં તત્વોની સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// જો નકશામાં કોઈ તત્વો ન હોય તો `true` પરત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// જો રુટ નોડ એ ખાલી (non-allocated) રુટ નોડ છે, તો અમારું પોતાનું નોડ ફાળવો.
    /// સંપૂર્ણ BTreeMap ઉધાર ટાળવા માટે એક સંબંધિત કાર્ય છે.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;