use core::intrinsics;
use core::mem;
use core::ptr;

/// આ સંબંધિત ફંક્શનને બોલાવીને `v` અનન્ય સંદર્ભ પાછળના મૂલ્યને બદલે છે.
///
///
/// જો ઝેડ 0 સ્પેનિક્સ 0 ઝેડ `change` બંધ થવામાં આવે છે, તો આખી પ્રક્રિયાને છોડી દેવામાં આવશે.
#[allow(dead_code)] // ઉદાહરણ તરીકે અને ઝેડ ફ્યુચર0 ઝેડ ઉપયોગ માટે રાખો
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// આ સંબંધિત ફંક્શનને ક callingલ કરીને `v` અનન્ય સંદર્ભ પાછળના મૂલ્યને બદલે છે, અને તે સાથે પ્રાપ્ત કરેલું પરિણામ આપે છે.
///
///
/// જો ઝેડ 0 સ્પેનિક્સ 0 ઝેડ `change` બંધ થવામાં આવે છે, તો આખી પ્રક્રિયાને છોડી દેવામાં આવશે.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}