use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// અસ્થાયી રૂપે તે જ શ્રેણીના બીજા, સ્થિર સમકક્ષને બહાર કા .ે છે.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ઝાડમાં નિર્દિષ્ટ શ્રેણીને સીમાંકિત કરતી અલગ પાંદડાની ધાર શોધે છે.
    /// કાં તો એક જ વૃક્ષમાં વિવિધ હેન્ડલ્સની જોડી અથવા ખાલી વિકલ્પોની જોડી આપે છે.
    ///
    /// # Safety
    ///
    /// જ્યાં સુધી `BorrowType` એ `Immut` ન હોય, ત્યાં સુધી તે જ કેવીની બે વાર મુલાકાત લેવા માટે ડુપ્લિકેટ હેન્ડલ્સનો ઉપયોગ કરશો નહીં.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())`, પરંતુ વધુ કાર્યક્ષમની સમકક્ષ.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ઝાડમાં વિશિષ્ટ રેંજને મર્યાદિત કરતી પર્ણ ધારની જોડી શોધે છે.
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને કી દ્વારા ઓર્ડર કરવામાં આવે છે, જેમ કે એક `BTreeMap` માંનું ઝાડ છે.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // સલામતી: અમારું orrowણ લેવાનો પ્રકાર અપ્રચલિત છે.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// આખા વૃક્ષને સીમિત કરતી પર્ણ ધારની જોડી શોધે છે.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ઉલ્લેખિત શ્રેણીને સીમિત કરતી પર્ણ ધારની જોડીમાં એક અનોખો સંદર્ભ વિભાજિત કરે છે.
    /// પરિણામ એ (some) પરિવર્તનને મંજૂરી આપતા બિન-વિશિષ્ટ સંદર્ભો છે, જેનો કાળજીપૂર્વક ઉપયોગ કરવો આવશ્યક છે.
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને કી દ્વારા ઓર્ડર કરવામાં આવે છે, જેમ કે એક `BTreeMap` માંનું ઝાડ છે.
    ///
    ///
    /// # Safety
    /// સમાન કેવીની બે વાર મુલાકાત લેવા માટે ડુપ્લિકેટ હેન્ડલ્સનો ઉપયોગ કરશો નહીં.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ઝાડની સંપૂર્ણ શ્રેણીને સીમિત કરતી પર્ણ ધારની જોડીમાં એક અનોખો સંદર્ભ વિભાજિત કરે છે.
    /// પરિણામો બિન-અનન્ય સંદર્ભો છે જે પરિવર્તનને મંજૂરી આપે છે (ફક્ત મૂલ્યોના), તેથી કાળજી સાથે ઉપયોગ કરવો આવશ્યક છે.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // અમે અહીં રુટ નોડરેફને ડુપ્લિકેટ કરીએ છીએ-અમે ક્યારેય એક જ કેવીની બે વાર મુલાકાત કરીશું નહીં, અને ક્યારેય ઓવરલેપિંગ મૂલ્ય સંદર્ભો સાથે અંત નહીં કરીએ.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ઝાડની સંપૂર્ણ શ્રેણીને સીમિત કરતી પર્ણ ધારની જોડીમાં એક અનોખો સંદર્ભ વિભાજિત કરે છે.
    /// પરિણામો બિન-વિશિષ્ટ સંદર્ભો છે જે મોટા પ્રમાણમાં વિનાશક પરિવર્તનને મંજૂરી આપે છે, તેથી તેનો ઉપયોગ ખૂબ કાળજી સાથે કરવો જોઈએ.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // અમે રુટ નોડરેફને અહીં ડુપ્લિકેટ કરીએ છીએ-અમે તેને ક્યારેય એવી રીતે willક્સેસ કરીશું નહીં કે જે મૂળમાંથી મેળવેલા સંદર્ભોને ઓવરલેપ કરે.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// એક પર્ણ edge હેન્ડલ આપ્યું, [`Result::Ok`] ને હેન્ડલ સાથે પાડોશી KV ને જમણી બાજુ પરત કરે છે, જે એક જ પાંદડા નોડ અથવા પૂર્વજ નોડમાં છે.
    ///
    /// જો ઝેડ્ડ્જિ0 ઝેડ પર્ણ ઝાડમાં છેલ્લું છે, તો રુટ નોડ સાથે [`Result::Err`] આપે છે.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// એક પર્ણ edge હેન્ડલ આપ્યું, [`Result::Ok`] ને હેન્ડલ સાથે પાડોશી કેવીને ડાબી બાજુ પરત કરે છે, જે એક જ પાંદડા નોડ અથવા પૂર્વજ નોડમાં છે.
    ///
    /// જો ઝાડમાં ઝેડ્ડ્ડ્ઝેડઝેડ લીફ પ્રથમ છે, તો રુટ નોડ સાથે [`Result::Err`] આપે છે.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// આંતરિક edge હેન્ડલ આપેલ, [`Result::Ok`] ને હેન્ડલ સાથે પાડોશી KV ને જમણી બાજુએ આપે છે, જે એક જ આંતરિક નોડ અથવા પૂર્વજ નોડમાં છે.
    ///
    /// જો આંતરિક edge એ ઝાડનો અંતિમ છે, તો રુટ નોડ સાથે [`Result::Err`] આપે છે.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// મૃત્યુ પામેલા ઝાડમાં ઝેડ્ડ્ડ્ઝેડઝેડનું એક પાંદડું આપ્યું છે, આગળના પાંદડા edge જમણી બાજુ પર આપે છે, અને વચ્ચેની કી-મૂલ્યની જોડી, જે ક્યાં તો તે જ પાંદડા નોડમાં હોય છે, પૂર્વજ નોડમાં અથવા અસ્તિત્વમાં નથી.
    ///
    ///
    /// આ પદ્ધતિ કોઈપણ node(s) ને પણ અંતિમ સ્થાને પહોંચે છે.
    /// આ સૂચવે છે કે જો કોઈ કી-મૂલ્યની જોડી અસ્તિત્વમાં ન હોય, તો ઝાડની બાકીની બાકીની ડીલોલોકેટ થઈ ગઈ હશે અને પાછા જવા માટે કંઈ બાકી નથી.
    ///
    /// # Safety
    /// આપેલ edge પાછલા કાઉન્ટરપartર્ટ `deallocating_next_back` દ્વારા પાછા ફર્યા ન હોવા જોઈએ.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// મૃત્યુ પામેલા ઝાડમાં ઝેડ્ડ્ડ્ઝેઝ ઝેડ હેન્ડલ આપ્યું છે, આગળના પાંદડા edge ડાબી બાજુ પર આપે છે, અને વચ્ચેની કી-મૂલ્યની જોડી, જે ક્યાં તો તે જ પાંદડા નોડમાં હોય છે, પૂર્વજ નોડમાં અથવા અસ્તિત્વમાં નથી.
    ///
    ///
    /// આ પદ્ધતિ કોઈપણ node(s) ને પણ અંતિમ સ્થાને પહોંચે છે.
    /// આ સૂચવે છે કે જો કોઈ કી-મૂલ્યની જોડી અસ્તિત્વમાં ન હોય, તો ઝાડની બાકીની બાકીની ડીલોલોકેટ થઈ ગઈ હશે અને પાછા જવા માટે કંઈ બાકી નથી.
    ///
    /// # Safety
    /// આપેલ edge પાછલા કાઉન્ટરપartર્ટ `deallocating_next` દ્વારા પાછા ફર્યા ન હોવા જોઈએ.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// પાંદડામાંથી મૂળ સુધીના ગાંઠોના ileગલાને ઘટાડે છે.
    /// ઝાડની બંને બાજુએ `deallocating_next` અને `deallocating_next_back` ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી ઝીણી સપાટી
    /// કેમ કે તે ફક્ત ત્યારે જ બોલાવવાનો છે જ્યારે બધી કીઓ અને મૂલ્યો પાછા ફર્યા છે, કોઈપણ કી અથવા મૂલ્યો પર કોઈ સફાઇ કરવામાં આવતી નથી.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// પર્ણ edge હેન્ડલને આગલા પાંદડા edge પર ખસેડે છે અને વચ્ચેની કી અને મૂલ્યના સંદર્ભો આપે છે.
    ///
    ///
    /// # Safety
    /// મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// પર્ણ edge હેન્ડલને પાછલા પાંદડા edge પર ખસેડે છે અને વચ્ચેની કી અને મૂલ્યના સંદર્ભો આપે છે.
    ///
    ///
    /// # Safety
    /// મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// પર્ણ edge હેન્ડલને આગલા પાંદડા edge પર ખસેડે છે અને વચ્ચેની કી અને મૂલ્યના સંદર્ભો આપે છે.
    ///
    ///
    /// # Safety
    /// મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // બેંચમાર્ક અનુસાર, આ છેલ્લું કરવું ઝડપી છે.
        kv.into_kv_valmut()
    }

    /// પર્ણ edge હેન્ડલને પાછલા પાંદડા પર ખસે છે અને વચ્ચેના કી અને મૂલ્યના સંદર્ભો આપે છે.
    ///
    ///
    /// # Safety
    /// મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // બેંચમાર્ક અનુસાર, આ છેલ્લું કરવું ઝડપી છે.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// પર્ણ edge હેન્ડલને આગલા પાંદડા edge પર ખસેડે છે અને વચ્ચેની કી અને મૂલ્ય પાછું આપે છે, તેના પેરન્ટ નોડ ઝૂલતામાં અનુરૂપ edge છોડતી વખતે કોઈ પણ નોડ પાછળ છોડી દે છે.
    ///
    /// # Safety
    /// - મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    /// - તે કેવી અગાઉ કાઉન્ટરપાર્ટ `next_back_unchecked` દ્વારા ઝાડમાંથી પસાર થવા માટે ઉપયોગમાં લેવામાં આવતી હેન્ડલ્સની કોઈપણ ક onપિ પર પાછો ફર્યો નહોતો.
    ///
    /// અપડેટ કરેલ હેન્ડલ સાથે આગળ વધવાનો એકમાત્ર સલામત રસ્તો છે તેની તુલના કરવી, તેને છોડો, આ પદ્ધતિને ફરીથી તેની સલામતીની સ્થિતિને આધિન ક .લ કરો અથવા કાઉન્ટરપાર્ટ `next_back_unchecked` ને તેની સલામતીની સ્થિતિને આધિન ક .લ કરો.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// પર્ણ edge હેન્ડલને પાછલા પાંદડા edge પર ખસેડે છે અને વચ્ચેની કી અને મૂલ્ય પાછું આપે છે, તેના પેરન્ટ નોડ ઝૂલતામાં અનુરૂપ edge છોડતી વખતે કોઈ પણ નોડ પાછળ છોડી દે છે.
    ///
    /// # Safety
    /// - મુસાફરી કરેલી દિશામાં બીજો કે.વી. હોવો આવશ્યક છે.
    /// - તે પર્ણ edge અગાઉ કાઉન્ટરપાર્ટ `next_unchecked` દ્વારા ઝાડમાંથી પસાર થવા માટે ઉપયોગમાં લેવામાં આવતી હેન્ડલ્સની કોઈપણ નકલ પર પરત આપી ન હતી.
    ///
    /// અપડેટ કરેલ હેન્ડલ સાથે આગળ વધવાનો એકમાત્ર સલામત રસ્તો છે તેની તુલના કરવી, તેને છોડો, આ પદ્ધતિને ફરીથી તેની સલામતીની સ્થિતિને આધિન ક .લ કરો અથવા કાઉન્ટરપાર્ટ `next_unchecked` ને તેની સલામતીની સ્થિતિને આધિન ક .લ કરો.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// નોડમાં અથવા તેની નીચે ડાબી બાજુનું પર્ણ edge પરત કરે છે, બીજા શબ્દોમાં કહીએ તો, આગળ નેવિગેટ કરતી વખતે (અથવા પાછલા નેવિગેટ કરતી વખતે છેલ્લી) તમારે જે edge ની જરૂર છે.
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// નોડમાં અથવા તેની નીચે જમણી બાજુનું પર્ણ edge પરત કરે છે, બીજા શબ્દોમાં કહીએ તો, આગળ નેવિગેટ કરતી વખતે (અથવા પહેલા જ્યારે નેવિગેટ કરતી વખતે પ્રથમ) તમારે જરૂરી edge.
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ચડતા કીઓના ક્રમમાં પર્ણ ગાંઠો અને આંતરિક કે.વી. ની મુલાકાત લે છે, અને સંપૂર્ણ રીતે internalંડાઈવાળા પ્રથમ ક્રમમાં આંતરિક ગાંઠોની મુલાકાત લે છે, એટલે કે આંતરિક ગાંઠો તેમના વ્યક્તિગત કેવી અને તેમના બાળ નોડ પહેલાંના છે.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (પેટા) વૃક્ષમાં તત્વોની સંખ્યાની ગણતરી કરે છે.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// આગળ નેવિગેશન માટે કેવીની નજીકના ઝેડિજેડ ઝેડ ઝેડ લીફ પરત કરે છે.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// પછાત નેવિગેશન માટે કે.વી. ની નજીકમાં ઝેડિડ્ઝ 0 ઝેડનું પર્ણ આપે છે.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}