use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// ઝાડમાંથી કી-મૂલ્યની જોડી દૂર કરે છે, અને તે જોડી આપે છે, સાથે સાથે તે ભૂતપૂર્વ જોડીને અનુરૂપ પર્ણ edge આપે છે.
    /// શક્ય છે કે આ રુટ નોડ કે જે આંતરિક છે તે ખાલી કરે છે, જેને કોલરે વૃક્ષ ધરાવતા નકશામાંથી પ popપ કરવું જોઈએ.
    /// ક calલરને પણ નકશાની લંબાઈ ઘટાડવી જોઈએ.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // આપણે અસ્થાયીરૂપે બાળ પ્રકારને ભૂલી જવું જોઈએ, કારણ કે પાનના તાત્કાલિક માતાપિતા માટે કોઈ નોડ પ્રકાર નથી.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // સલામતી: `new_pos` એ પાંદડા છે કે આપણે એક ભાઈ અથવા બહેનથી શરૂ કર્યું છે.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // ફક્ત જો આપણે મર્જ કર્યું, તો પેરેંટ (જો કોઈ હોય તો) સંકોચો છે, પરંતુ નીચેના પગલાને અવગણીને અન્યથા બેંચમાર્કમાં ચૂકવણી કરવામાં આવશે નહીં.
            //
            // સલામતી: જ્યાં `pos` છે ત્યાં અમે પાંદડાને નષ્ટ અથવા ફરીથી ગોઠવીશું નહીં
            // તેના પેરન્ટ્સને રિકર્સિવ હેન્ડલ કરીને;સૌથી ખરાબ રીતે આપણે દાદા-માતાપિતા દ્વારા માતાપિતાનો નાશ કરીશું અથવા ફરીથી ગોઠવીશું, આમ પત્તાની અંદરની પિતૃની લિંક બદલીશું.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // તેના પાંદડાથી અડીને આવેલા કે.વી.ને દૂર કરો અને પછી તે તત્વની જગ્યાએ તેને પાછું મૂકી દો, જેને દૂર કરવા અમને કહેવામાં આવ્યું હતું.
        //
        // `choose_parent_kv` માં સૂચિબદ્ધ કારણોસર, ડાબી બાજુની અડીને KV ને પ્રાધાન્ય આપો.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // આંતરિક નોડ ચોરી અથવા મર્જ થઈ શકે છે.
        // મૂળ કે.વી. ક્યાં સમાપ્ત થયું છે તે શોધવા માટે જમણે પાછા જાઓ.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}