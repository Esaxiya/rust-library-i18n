use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// રસ્તામાં એક `length` ચલને વધારીને, બે ચડતા ઇટરેટર્સના જોડાણથી તમામ કી-મૂલ્યના જોડીઓ જોડે છે.બાદમાં કરનાર જ્યારે ડ્રોપ હેન્ડલર ઉભો કરે છે ત્યારે લીક થવાનું ટાળવાનું સરળ બનાવે છે.
    ///
    /// જો બંને પુનરાવર્તકો સમાન કી ઉત્પન્ન કરે છે, તો આ પદ્ધતિ જોડીને ડાબી ઇટરેટરથી છોડે છે અને જોડીને જમણા ઇટરેટરથી જોડે છે.
    ///
    /// જો તમે ઇચ્છો છો કે ઝાડ એક કડક ચડતા ક્રમમાં સમાપ્ત થાય, જેમ કે `BTreeMap`, બંને પુનરાવર્તકોએ કડક ચડતા ક્રમમાં ચાવી ઉત્પન્ન કરવી જોઈએ, જે ઝાડની બધી કીઓ કરતા વધારે છે, પ્રવેશ પર ઝાડમાં પહેલેથી કોઈપણ ચાવીઓ સહિત.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // અમે `left` અને `right` ને રેખીય સમયમાં સortedર્ટ કરેલા અનુક્રમમાં મર્જ કરવાની તૈયારી કરીએ છીએ.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // દરમિયાન, અમે રેખીય સમયમાં સortedર્ટ કરેલા ક્રમમાંથી એક વૃક્ષ બનાવીએ છીએ.
        self.bulk_push(iter, length)
    }

    /// રસ્તામાં એક `length` ચલને વધારીને, બધા કી-મૂલ્યની જોડીને ઝાડના અંત સુધી દબાણ કરે છે.
    /// જ્યારે પુનરાવર્તિત કરનાર ગભરાવે છે ત્યારે કlerલર માટે લિક ટાળવાનું સરળ બનાવે છે.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // બધી કી-મૂલ્યની જોડીમાં ફેરવો, તેમને યોગ્ય સ્તરે ગાંઠોમાં દબાણ કરો.
        for (key, value) in iter {
            // વર્તમાન પર્ણ નોડમાં કી-મૂલ્યની જોડી દબાણ કરવાનો પ્રયાસ કરો.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // કોઈ જગ્યા બાકી નથી, ઉપર જાઓ અને ત્યાં દબાણ કરો.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // બાકી જગ્યા સાથે નોડ મળી, અહીં દબાણ કરો.
                                open_node = parent;
                                break;
                            } else {
                                // ફરીથી ઉપર જાઓ.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // અમે ટોચ પર છીએ, એક નવું રુટ નોડ બનાવો અને ત્યાં દબાણ કરો.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // કી-મૂલ્યની જોડી અને નવી જમણી સબટ્રી દબાણ કરો.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ફરીથી જમણી બાજુના પાનમાં નીચે જાઓ.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // પ્રત્યેક પુનરાવર્તનમાં વધારો, તેની ખાતરી કરવા માટે કે નકશો એરેટર તત્વોને ઘટે છે, પછી ભલે તે ઇરેટર પેક્સને આગળ વધે.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// એકમાં બે સortedર્ટ કરેલા અનુક્રમોને મર્જ કરવા માટે એક ઇટરેટર
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// જો બે કીઓ સમાન હોય, તો યોગ્ય સ્રોતમાંથી કી-મૂલ્યની જોડી આપે છે.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}