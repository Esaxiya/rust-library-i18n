// આદર્શને પગલે અમલીકરણનો આ પ્રયાસ છે
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// ઝેડ રસ્ટ0 ઝેડમાં ખરેખર આશ્રિત પ્રકારો અને બહુકોષીય રિકર્ઝન નથી, તેથી અમે ઘણી બધી અસફળતા સાથે કરીએ છીએ.
//

// આ મોડ્યુલનું એક મુખ્ય લક્ષ્ય એ છે કે ઝાડને સામાન્ય (જો વિચિત્ર આકારની હોય તો) કન્ટેનર તરીકે સારવાર આપીને અને બી-ટ્રી આક્રમણકારો સાથેના મોટાભાગના લોકો સાથે વ્યવહાર કરવાનું ટાળવું.
//
// જેમ કે, આ મોડ્યુલને ધ્યાન આપતું નથી કે શું એન્ટ્રીઓ સortedર્ટ કરેલી છે, કયા ગાંઠો અંડરફુલ હોઈ શકે છે, અથવા તો શું અંતર્ગતનો અર્થ થાય છે.જો કે, અમે થોડા આક્રમણકારો પર આધાર રાખીએ છીએ:
//
// - ઝાડમાં એકસમાન depth/height હોવા આવશ્યક છે.આનો અર્થ એ છે કે આપેલ નોડમાંથી પાંદડા તરફ જવાના દરેક પાથની બરાબર સમાન લંબાઈ છે.
// - `n` લંબાઈના નોડમાં `n` કીઓ, `n` મૂલ્યો અને `n + 1` ધાર છે.
//   આ સૂચવે છે કે ખાલી નોડમાં પણ ઓછામાં ઓછું એક edge છે.
//   પર્ણ નોડ માટે, "having an edge" નો અર્થ ફક્ત એ છે કે આપણે નોડમાં કોઈ સ્થાન ઓળખી શકીએ, કારણ કે પર્ણ ધાર ખાલી હોય છે અને ડેટા રજૂઆત કરવાની જરૂર નથી.
// આંતરિક નોડમાં, ઝેડ્ડેજ 0 ઝેડ બંને પોઝિશનને ઓળખે છે અને તેમાં ચાઇલ્ડ નોડનો નિર્દેશક શામેલ છે.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// પર્ણ ગાંઠો અને આંતરિક ગાંઠોના પ્રતિનિધિત્વનો અંતર્ગત રજૂઆત.
struct LeafNode<K, V> {
    /// અમે `K` અને `V` માં સહકારી બનવા માંગીએ છીએ.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// પેરેન્ટ નોડના `edges` એરેમાં આ નોડની અનુક્રમણિકા.
    /// `*node.parent.edges[node.parent_idx]` `node` જેવી જ વસ્તુ હોવી જોઈએ.
    /// જ્યારે માત્ર `parent` નોન-નલ હોય ત્યારે પ્રારંભ કરવાની આ બાંયધરી આપવામાં આવે છે.
    parent_idx: MaybeUninit<u16>,

    /// આ નોડ સ્ટોર્સની કી અને મૂલ્યોની સંખ્યા.
    len: u16,

    /// એરે નોડનો વાસ્તવિક ડેટા સ્ટોર કરે છે.
    /// દરેક એરેના ફક્ત પ્રથમ `len` તત્વો પ્રારંભ અને માન્ય છે.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// જગ્યાએ નવા `LeafNode` પ્રારંભ કરે છે.
    unsafe fn init(this: *mut Self) {
        // સામાન્ય નીતિ તરીકે, અમે જો ક્ષેત્રો હોઈ શકે તો તેઓ બિનકાર્યરત છોડીએ, કારણ કે વાલ્ગ્રિંડમાં ટ્ર trackક કરવું તે થોડું ઝડપી અને સરળ બંને હોવું જોઈએ.
        //
        unsafe {
            // પેરેંટ_આઈડીએક્સ, કીઓ અને વalsલ્સ એ બધા સંભવિત છે
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// નવો બ boxક્સ્ડ `LeafNode` બનાવે છે.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// આંતરિક ગાંઠોની અંતર્ગત રજૂઆત.`લીફનોડ્સની જેમ, અનઇટિઆલાઇઝ્ડ કીઓ અને મૂલ્યો છોડવાનું અટકાવવા આ` BoxedNode`s ની પાછળ છુપાયેલા હોવા જોઈએ.
/// કોઈ `InternalNode` તરફનો કોઈપણ નિર્દેશક સીધા નોડના અંતર્ગત `LeafNode` ભાગ તરફના નિર્દેશક પર કાસ્ટ કરી શકાય છે, કોડને પાંદડા અને આંતરિક ગાંઠો પર સામાન્ય રીતે કાર્ય કરવાની મંજૂરી આપે છે, જે બે નિર્દેશક તરફ ધ્યાન દોરતા હોય તે પણ તપાસ્યા વગર.
///
/// આ મિલકત `repr(C)` ના ઉપયોગથી સક્ષમ છે.
///
#[repr(C)]
// gdb_providers.py આત્મનિરીક્ષણ માટે આ પ્રકારનાં નામનો ઉપયોગ કરે છે.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// આ નોડના બાળકોને નિર્દેશક.
    /// `len + 1` આમાંથી પ્રારંભિક અને માન્ય માનવામાં આવે છે, સિવાય કે અંત નજીક, જ્યારે ઝાડ ઉધારના પ્રકાર `Dying` દ્વારા યોજવામાં આવે છે, તેમાંના કેટલાક પોઇંટર્સ ઝૂલતા હોય છે.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// નવો બ boxક્સ્ડ `InternalNode` બનાવે છે.
    ///
    /// # Safety
    /// આંતરિક ગાંઠોનો આક્રમણ એ છે કે તેમની પાસે ઓછામાં ઓછી એક પ્રારંભિક અને માન્ય edge છે.
    /// આ ફંક્શન આવા edge ને સેટ નથી કરતું.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // આપણે ફક્ત ડેટા પ્રારંભ કરવાની જરૂર છે;ધાર કદાચ યુનિનીટ છે.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// નોડ માટે સંચાલિત, નોન-નલ પોઇન્ટર.આ ક્યાં તો `LeafNode<K, V>` નો માલિકીનો પોઇન્ટર અથવા `InternalNode<K, V>` નો માલિકીનો પોઇન્ટર છે.
///
/// જો કે, `BoxedNode` એ બે પ્રકારનાં ગાંઠોમાંથી ખરેખર કયા શામેલ છે તે વિશે કોઈ માહિતી શામેલ નથી, અને, માહિતીના આ અભાવને કારણે આંશિકરૂપે, તે એક અલગ પ્રકાર નથી અને તેનો કોઈ ડિસ્ટ્રક્ટર નથી.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// માલિકીના વૃક્ષનું મૂળ નોડ.
///
/// નોંધ લો કે આમાં ડિસ્ટ્રક્ટર નથી, અને તેને જાતે જ સાફ કરવું જોઈએ.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// શરૂઆતમાં ખાલી છે તેના પોતાના રૂટ નોડ સાથે, નવું માલિકીનું વૃક્ષ આપે છે.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` શૂન્ય ન હોવું જોઈએ.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// પરસ્પર માલિકીની રુટ નોડ ઉધાર લે છે.
    /// `reborrow_mut` થી વિપરીત, આ સલામત છે કારણ કે મૂળને નષ્ટ કરવા માટે વળતર મૂલ્યનો ઉપયોગ કરી શકાતો નથી, અને ઝાડના અન્ય સંદર્ભો હોઈ શકતા નથી.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// સહેજ પરસ્પર રૂપે માલિકીની રુટ નોડ ઉધાર લે છે.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// બદલી ન શકાય તેવા સંદર્ભમાં સંક્રમણ કે જે આત્યંતિક પરવાનગી આપે છે અને વિનાશક પદ્ધતિઓ પ્રદાન કરે છે અને બીજું કંઇક.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// પાછલા રુટ નોડ તરફ ઇશારો કરીને એક જ ઝેડ્ડ્ઝેડઝેડ સાથે એક નવું આંતરિક નોડ ઉમેરશે, તે નોડને રુટ નોડ બનાવો અને તેને પાછા ફરો.
    /// આ theંચાઈને 1 દ્વારા વધે છે અને `pop_internal_level` ની વિરુદ્ધ છે.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, સિવાય કે આપણે હવે ભૂલી ગયા છીએ કે હવે આપણે આંતરિક છીએ:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// નવા મૂળ નોડ તરીકે તેના પ્રથમ બાળકનો ઉપયોગ કરીને, આંતરિક રુટ નોડને દૂર કરે છે.
    /// જેમ કે તે ફક્ત કહેવા માટે બનાવાયેલ છે જ્યારે રુટ નોડમાં ફક્ત એક જ બાળક હોય છે, કોઈપણ કી, મૂલ્યો અને અન્ય બાળકો પર કોઈ સફાઇ કરવામાં આવતી નથી.
    ///
    /// આ 1ંચાઈને 1 દ્વારા ઘટાડે છે અને `push_internal_level` ની વિરુદ્ધ છે.
    ///
    /// `Root` objectબ્જેક્ટની વિશિષ્ટ Requક્સેસની જરૂર છે પરંતુ રૂટ નોડ પર નહીં;
    /// તે અન્ય હેન્ડલ્સને અથવા રુટ નોડના સંદર્ભોને અમાન્ય કરશે નહીં.
    ///
    /// Panics જો ત્યાં કોઈ આંતરિક સ્તર ન હોય, એટલે કે, જો રુટ નોડ એક પાંદડું હોય.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // સલામતી: અમે આંતરિક હોવાની ખાતરી આપી.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // સલામત: અમે `self` વિશેષ રૂપે ઉધાર લીધું છે અને તેનો ઉધાર પ્રકાર વિશિષ્ટ છે.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // સલામતી: પ્રથમ edge હંમેશા પ્રારંભ થાય છે.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` X `Mut` હોય ત્યારે પણ, X0X હંમેશા `K` અને `V` માં સહકારી હોય છે.
// આ તકનીકી રૂપે ખોટું છે, પરંતુ `NodeRef` ના આંતરિક ઉપયોગને લીધે કોઈ પણ અસુવિધામાં પરિણમી શકતું નથી કારણ કે આપણે `K` અને `V` પર સંપૂર્ણપણે સામાન્ય રહીએ છીએ.
//
// જો કે, જ્યારે પણ સાર્વજનિક પ્રકાર `NodeRef` ને વીંટાળે છે, ત્યારે ખાતરી કરો કે તેમાં સાચો તફાવત છે.
//
/// નોડનો સંદર્ભ.
///
/// આ પ્રકારનાં સંખ્યાબંધ પરિમાણો છે જે નિયંત્રિત કરે છે કે તે કેવી રીતે કાર્ય કરે છે:
/// - `BorrowType`: એક ડમી પ્રકાર જે ઉધારના પ્રકારનું વર્ણન કરે છે અને આજીવન વહન કરે છે.
///    - જ્યારે આ `Immut<'a>` છે, ત્યારે `NodeRef` લગભગ `&'a Node` ની જેમ કાર્ય કરે છે.
///    - જ્યારે આ `ValMut<'a>` હોય, ત્યારે `NodeRef` કીઓ અને ઝાડના બંધારણને ધ્યાનમાં રાખીને આશરે `&'a Node` ની જેમ કાર્ય કરે છે, પરંતુ ઘણા ઝાડના મૂલ્યોના ઘણા પરિવર્તનીય સંદર્ભોને સાથે રહેવાની મંજૂરી આપે છે.
///    - જ્યારે આ `Mut<'a>` હોય, ત્યારે `NodeRef` લગભગ `&'a mut Node` ની જેમ કાર્ય કરે છે, જોકે શામેલ કરવાની પદ્ધતિઓ પરિવર્તનશીલ પોઇન્ટરને એકસાથે રહેવાની મંજૂરી આપે છે.
///    - જ્યારે આ `Owned` હોય, ત્યારે `NodeRef` લગભગ `Box<Node>` ની જેમ કાર્ય કરે છે, પરંતુ તેમાં ડિસ્ટ્રક્ટર નથી, અને તેને જાતે જ સાફ કરવું જોઈએ.
///    - જ્યારે આ `Dying` છે, ત્યારે `NodeRef` હજી પણ `Box<Node>` ની જેમ આશરે કાર્ય કરે છે, પરંતુ ઝાડને થોડોક નાશ કરવાની પદ્ધતિઓ છે, અને સામાન્ય પદ્ધતિઓ, જ્યારે ક callલ કરવા માટે અસુરક્ષિત તરીકે ચિહ્નિત થયેલ નથી, યુબીને ખોટી રીતે બોલાવી શકે છે.
///
///   કોઈપણ `NodeRef` ઝાડ દ્વારા નેવિગેટ કરવાની મંજૂરી આપે છે, તેથી `BorrowType` અસરકારક રીતે ફક્ત નોડ પર જ નહીં, સંપૂર્ણ ઝાડ પર લાગુ પડે છે.
/// - `K` અને `V`: આ નોડ્સમાં સંગ્રહિત કીઓ અને મૂલ્યોનાં પ્રકારો છે.
/// - `Type`: આ `Leaf`, `Internal` અથવા `LeafOrInternal` હોઈ શકે છે.
/// જ્યારે આ `Leaf` હોય, ત્યારે `NodeRef` એ પાંદડા નોડ તરફ નિર્દેશ કરે છે, જ્યારે આ `Internal` હોય ત્યારે `NodeRef` આંતરિક નોડ તરફ નિર્દેશ કરે છે, અને જ્યારે આ `LeafOrInternal` હોય છે ત્યારે `NodeRef` બંને પ્રકારના નોડ તરફ નિર્દેશ કરી શકે છે.
///   `Type` જ્યારે `NodeRef` ની બહાર વપરાય ત્યારે તેને `NodeType` નામ આપવામાં આવ્યું.
///
/// `BorrowType` અને `NodeType` બંને સ્થિર પ્રકારની સલામતીના શોષણ માટે આપણે કઈ પદ્ધતિઓ લાગુ કરીએ છીએ તે પ્રતિબંધિત કરે છે.આપણે આવી નિયંત્રણો લાગુ કરી શકીએ તેવી રીતે મર્યાદાઓ છે:
/// - દરેક પ્રકારનાં પરિમાણો માટે, આપણે ફક્ત એક પદ્ધતિને સામાન્ય રીતે અથવા કોઈ ચોક્કસ પ્રકાર માટે વ્યાખ્યાયિત કરી શકીએ છીએ.
/// ઉદાહરણ તરીકે, અમે `into_kv` જેવી પદ્ધતિને બધા `BorrowType` માટે સામાન્ય રીતે વ્યાખ્યાયિત કરી શકતા નથી, અથવા આજીવન વહન કરતા તમામ પ્રકારો માટે એકવાર, કારણ કે અમે ઇચ્છીએ છીએ કે તે `&'a` સંદર્ભોને પાછો આપે.
///   તેથી, અમે તેને ફક્ત ઓછામાં ઓછા શક્તિશાળી પ્રકાર `Immut<'a>` માટે વ્યાખ્યાયિત કરીએ છીએ.
/// - અમે `Mut<'a>` થી `Immut<'a>` કહેવાથી ગર્ભિત જબરદસ્તી મેળવી શકીએ નહીં.
///   તેથી, `into_kv` જેવી પદ્ધતિ સુધી પહોંચવા માટે, આપણે વધુ શક્તિશાળી `NodeRef` પર સ્પષ્ટ રીતે `reborrow` પર ક .લ કરવો પડશે.
///
/// `NodeRef` પરની બધી પદ્ધતિઓ કે જે અમુક પ્રકારના સંદર્ભ આપે છે, ક્યાં તો:
/// - `self` ને મૂલ્ય દ્વારા લો અને `BorrowType` દ્વારા હાથ ધરવામાં આવતી આજીવન પરત કરો.
///   કેટલીકવાર, આવી પદ્ધતિનો ઉપયોગ કરવા માટે, આપણે `reborrow_mut` પર ક callલ કરવાની જરૂર છે.
/// - સંદર્ભ દ્વારા `self` લો, અને (implicitly) એ સંદર્ભના જીવનકાળને બદલે, `BorrowType` દ્વારા કરવામાં આવેલા જીવનકાળને બદલે.
/// આ રીતે, ઉધાર તપાસનાર ખાતરી આપે છે કે જ્યાં સુધી પરત સંદર્ભનો ઉપયોગ કરવામાં આવશે ત્યાં સુધી `NodeRef` ઉધાર રહેશે.
///   ઇનસેટને ટેકો આપતી પદ્ધતિઓ આ નિયમને કાચા પોઇંટર, એટલે કે, કોઈપણ જીવનકાળ વિના સંદર્ભ આપીને પાછો ફરકી જાય છે.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// નોડ અને પાંદડાઓના સ્તરથી અલગ એવા સ્તરની સંખ્યા, નોડનો સતત જે `Type` દ્વારા સંપૂર્ણ રીતે વર્ણવી શકાતો નથી, અને તે નોડ પોતે જ સંગ્રહિત કરતું નથી.
    /// આપણે ફક્ત રૂટ નોડની .ંચાઇ સંગ્રહિત કરવાની જરૂર છે, અને તેમાંથી દરેક અન્ય નોડની heightંચાઈ મેળવવી જોઈએ.
    /// જો `Type` `Leaf` હોય તો શૂન્ય હોવું જોઈએ અને જો `Type` `Internal` હોય તો શૂન્ય નહીં.
    ///
    ///
    height: usize,
    /// પાંદડા અથવા આંતરિક નોડનો નિર્દેશક.
    /// `InternalNode` ની વ્યાખ્યા ખાતરી કરે છે કે નિર્દેશક કોઈપણ રીતે માન્ય છે.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// એક નોડ સંદર્ભ અનપ .ક કરો જે `NodeRef::parent` તરીકે પેક કરવામાં આવ્યો હતો.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// આંતરિક નોડનો ડેટા પ્રદર્શિત કરે છે.
    ///
    /// આ નોડના અન્ય સંદર્ભોને અમાન્ય કરવાથી બચવા માટે કાચો ptr આપે છે.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // સલામતી: સ્થિર નોડ પ્રકાર `Internal` છે.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// આંતરિક નોડના ડેટાની વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// નોડની લંબાઈ શોધે છે.આ કી અથવા મૂલ્યોની સંખ્યા છે.
    /// ધારની સંખ્યા `len() + 1` છે.
    /// નોંધ લો કે, સલામત હોવા છતાં, આ ફંક્શનને કલ કરવાથી અસુરક્ષિત કોડ દ્વારા બનાવેલા મ્યુટેબલ સંદર્ભોને અમાન્ય કરવાની આડઅસર થઈ શકે છે.
    ///
    pub fn len(&self) -> usize {
        // નિર્ણાયકરૂપે, અમે અહીં ફક્ત `len` ફીલ્ડને accessક્સેસ કરીએ છીએ.
        // જો બોરોન ટાઇપ marker::ValMut છે, તો કિંમતોના બાકી પરિવર્તનીય સંદર્ભો હોઈ શકે છે જેને આપણે અમાન્ય ન કરવું જોઈએ.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// નોડ અને પાંદડા એક બીજાના સ્તરની સંખ્યા પરત કરે છે.
    /// શૂન્ય heightંચાઇ એટલે નોડ એક પાંદડા છે.
    /// જો તમે ઉપરના મૂળવાળા વૃક્ષો બતાવો છો, તો નંબર કહે છે કે કઈ એલિવેશન પર નોડ દેખાય છે.
    /// જો તમે પાંદડાવાળા ઝાડ ઉપરથી ચિત્રિત કરો છો, તો સંખ્યા કહે છે કે નોડની ઉપર ઝાડ કેટલું highંચું લંબાય છે.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// તે જ નોડ માટે અસ્થાયીરૂપે બીજો, અપરિચિત સંદર્ભ લે છે.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// કોઈપણ પાંદડા અથવા આંતરિક નોડનો પર્ણ ભાગ છતી કરે છે.
    ///
    /// આ નોડના અન્ય સંદર્ભોને અમાન્ય કરવાથી બચવા માટે કાચો ptr આપે છે.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // નોડ ઓછામાં ઓછા લીફનોડ ભાગ માટે માન્ય હોવો આવશ્યક છે.
        // આ નોડરેફ પ્રકારનો સંદર્ભ નથી કારણ કે અમને ખબર નથી કે તે અનન્ય અથવા શેર કરવું જોઈએ.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// વર્તમાન નોડનો પેરેંટ શોધે છે.
    /// જો વર્તમાન નોડમાં ખરેખર માતાપિતા હોય તો `Ok(handle)` પરત કરે છે, જ્યાં `handle` વર્તમાન નોડ તરફ નિર્દેશ કરે છે તે પિતૃના edge તરફ નિર્દેશ કરે છે.
    ///
    /// `Err(self)` પરત કરે છે જો વર્તમાન નોડ પાસે કોઈ પેરેંટ નથી, તો મૂળ `NodeRef` પાછા આપશે.
    ///
    /// પદ્ધતિનું નામ માને છે કે તમે ટોચ પર રુટ નોડ સાથેના વૃક્ષોનું ચિત્ર લો.
    ///
    /// `edge.descend().ascend().unwrap()` અને `node.ascend().unwrap().descend()` બંનેએ, સફળતા પર, કંઇ કરવું જોઈએ નહીં.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // આપણે ગાંઠો માટે કાચા પોઇંટરો વાપરવાની જરૂર છે કારણ કે, જો બોરોટાઇપ marker::ValMut છે, તો મૂલ્યોના બાકી પરિવર્તનીય સંદર્ભો હોઈ શકે છે જેને આપણે અમાન્ય ન કરવું જોઈએ.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// નોંધ લો કે `self` નિમ્નપ્ટી હોવું આવશ્યક છે.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// નોંધ લો કે `self` નિમ્નપ્ટી હોવું આવશ્યક છે.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// કોઈ પણ પાંદડાના પાંદડાના ભાગ અથવા કોઈ સ્થાવર વૃક્ષમાં આંતરિક નોડ છતી કરે છે.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // સલામતી: `Immut` તરીકે ઉધાર લીધેલા આ વૃક્ષમાં કોઈ પરિવર્તનશીલ સંદર્ભો હોઈ શકતા નથી.
        unsafe { &*ptr }
    }

    /// નોડમાં સંગ્રહિત કીઓમાં દૃશ્ય ઉધાર લે છે.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` ની જેમ, નોડના પેરેંટ નોડનો સંદર્ભ મળે છે, પરંતુ તે પ્રક્રિયામાં વર્તમાન નોડને પણ ડિલોલોકેટ કરે છે.
    /// આ અસુરક્ષિત છે કારણ કે વર્તમાન નોડ ડિલોડેટેડ હોવા છતાં પણ accessક્સેસ કરી શકાય છે.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// અસુરક્ષિત સ્થિર માહિતીને કમ્પાઇલર પર ભારપૂર્વક જણાવે છે કે આ નોડ એક `Leaf` છે.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// અસુરક્ષિત સ્થિર માહિતીને કમ્પાઇલર પર ભારપૂર્વક જણાવે છે કે આ નોડ એક `Internal` છે.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// તે જ નોડ માટે અસ્થાયી રૂપે બીજું, પરિવર્તનશીલ સંદર્ભ લે છે.સાવચેત રહો, કારણ કે આ પદ્ધતિ ખૂબ જ ખતરનાક છે, બમણા કારણ કે તે તરત જ ખતરનાક ન દેખાઈ શકે.
    ///
    /// પરિવર્તનશીલ નિર્દેશકો ઝાડની આજુ બાજુ ગમે ત્યાં ફરવા જઈ શકે છે, પરત પોઇન્ટર સરળતાથી મૂળ નિર્દેશકને ઝૂલતા, સીમાડાથી બહાર અથવા સ્ટેક્ડ bણના નિયમો હેઠળ અમાન્ય બનાવવા માટે વાપરી શકાય છે.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` માં હજી બીજા પ્રકારનાં પરિમાણો ઉમેરવાનો વિચાર કરો કે જે આ અસંગતતાને અટકાવતા, ફરીથી ઉગાડવામાં આવેલા પોઇન્ટર પર નેવિગેશન પદ્ધતિઓના ઉપયોગને પ્રતિબંધિત કરે છે.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// કોઈપણ પાંદડા અથવા આંતરિક નોડના પાનની ભાગની વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // સલામતી: અમારી પાસે સંપૂર્ણ નોડની વિશિષ્ટ haveક્સેસ છે.
        unsafe { &mut *ptr }
    }

    /// કોઈપણ પાંદડા અથવા આંતરિક નોડના પાનની ભાગની વિશિષ્ટ Offક્સેસ પ્રદાન કરે છે.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // સલામતી: અમારી પાસે સંપૂર્ણ નોડની વિશિષ્ટ haveક્સેસ છે.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// કી સ્ટોરેજ ક્ષેત્રના તત્વની વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    ///
    /// # Safety
    /// `index` 0 ની મર્યાદામાં છે .. ક્ષમતા
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // સલામતી: કlerલર સ્વયં પર વધુ પદ્ધતિઓ ક callલ કરી શકશે નહીં
        // કી સ્લાઇસ સંદર્ભ છોડી ન દે ત્યાં સુધી, કારણ કે આપણી પાસે ઉધારની આજીવન અનન્ય .ક્સેસ છે.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// નોડના મૂલ્ય સંગ્રહ ક્ષેત્રના તત્વ અથવા સ્લાઇસની વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    ///
    /// # Safety
    /// `index` 0 ની મર્યાદામાં છે .. ક્ષમતા
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // સલામતી: કlerલર સ્વયં પર વધુ પદ્ધતિઓ ક callલ કરી શકશે નહીં
        // જ્યાં સુધી વેલ્યુ સ્લાઈસ રેફરન્સ ન પડે ત્યાં સુધી, આપણી પાસે theણના જીવનકાળ માટે અનન્ય .ક્સેસ છે.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge સમાવિષ્ટો માટે નોડના સ્ટોરેજ ક્ષેત્રના તત્વ અથવા સ્લાઇસની વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    ///
    /// # Safety
    /// `index` 0. .Capacity + 1 ની સીમામાં છે
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // સલામતી: કlerલર સ્વયં પર વધુ પદ્ધતિઓ ક callલ કરી શકશે નહીં
        // edge સ્લાઈસ સંદર્ભ છોડી દે ત્યાં સુધી, કારણ કે આપણી પાસે ઉધારની આજીવન અનન્ય accessક્સેસ છે.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - નોડમાં `idx` કરતા વધુ પ્રારંભિક તત્વો છે.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // અન્ય તત્વોના ઉત્કૃષ્ટ સંદર્ભો સાથેના ઉપભોગને ટાળવા માટે, ખાસ કરીને, અગાઉના પુનરાવર્તનોમાં કlerલરમાં પાછા ફર્યા હોય તે માટે, અમે ફક્ત એક જ તત્ત્વનો સંદર્ભ બનાવીએ છીએ જેમાં અમને રસ છે.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ઇસ્યુ #74679 ના કારણે આપણે અનઇઝાઇઝ્ડ એરે પોઇંટર્સ પર દબાણ કરવું પડશે.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// નોડની લંબાઈ માટે વિશિષ્ટ Bક્સેસ ઉધાર લે છે.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// નોડના અન્ય સંદર્ભોને અમાન્ય કર્યા વિના, નોડની લિંક તેના પિતૃ edge પર સેટ કરે છે.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// તેના પિતૃ edge પર રુટની લિંકને સાફ કરે છે.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// નોડના અંતમાં કી-મૂલ્યની જોડી ઉમેરો.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` દ્વારા પરત થયેલ દરેક આઇટમ એ નોડ માટે માન્ય ઝેડિજેજ 0 ઝેડ અનુક્રમણિકા છે.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// નોડના અંત સુધી, તે જોડીની જમણી બાજુએ જવા માટે, કી-મૂલ્યની જોડી અને edge ઉમેરે છે.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// નોડ એ `Internal` નોડ અથવા `Leaf` નોડ છે કે કેમ તે તપાસે છે.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// કોઈ નોડની અંતર્ગત વિશિષ્ટ કી-મૂલ્યની જોડી અથવા ઝેડડિજ0 ઝેડનો સંદર્ભ.
/// `Node` પરિમાણ એક `NodeRef` હોવું આવશ્યક છે, જ્યારે `Type` એ `KV` (કી-મૂલ્યની જોડી પરના હેન્ડલને સૂચિત કરતું) અથવા `Edge` (edge પરના હેન્ડલને સૂચિત કરતું) હોઈ શકે છે.
///
/// નોંધ લો કે `Leaf` ગાંઠોમાં પણ `Edge` હેન્ડલ્સ હોઈ શકે છે.
/// ચાઇલ્ડ નોડ પર પોઇન્ટર રજૂ કરવાને બદલે, તે તે જગ્યાઓનું પ્રતિનિધિત્વ કરે છે જ્યાં બાળ નિર્દેશકો કી-મૂલ્યની જોડી વચ્ચે જાય છે.
/// ઉદાહરણ તરીકે, લંબાઈ 2 સાથેના નોડમાં, ત્યાં 3 સંભવિત ઝેડિજેડ 0 ઝેડ સ્થાનો હશે, નોડની ડાબી બાજુએ, બે જોડીની વચ્ચેની એક અને નોડની જમણી બાજુએ.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// આપણને `#[derive(Clone)]` ની સંપૂર્ણ સામાન્યતાની જરૂર નથી, કારણ કે એકમાત્ર સમય `Node` હશે `ક્લોન`બલ ત્યારે છે જ્યારે તે કોઈ પરિવર્તનશીલ સંદર્ભ હોય અને તેથી `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// આ હેન્ડલ નિર્દેશ કરે છે તે edge અથવા કી-મૂલ્યની જોડી ધરાવતા નોડને પાછું મેળવે છે.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// નોડમાં આ હેન્ડલની સ્થિતિ પરત કરે છે.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` માં કી-મૂલ્યની જોડી માટે એક નવું હેન્ડલ બનાવે છે.
    /// અસુરક્ષિત કારણ કે ક calલરને ખાતરી કરવી આવશ્યક છે કે `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// આંશિક અસરનું જાહેર અમલીકરણ હોઈ શકે છે, પરંતુ આ મોડ્યુલમાં ફક્ત તેનો ઉપયોગ થાય છે.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// તે જ સ્થાન પર અસ્થાયી રૂપે બીજું, સ્થાવર હેન્ડલ બહાર કા .ે છે.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // અમે Handle::new_kv અથવા Handle::new_edge નો ઉપયોગ કરી શકતા નથી કારણ કે આપણે આપણા પ્રકારને જાણતા નથી
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// અસુરક્ષિત સ્થિર માહિતીને કમ્પાઇલર પર ભારપૂર્વક જણાવે છે કે હેન્ડલનો નોડ એક `Leaf` છે.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// તે જ સ્થાન પર અસ્થાયી રૂપે બીજું, પરિવર્તનીય હેન્ડલ બહાર કા .ે છે.
    /// સાવચેત રહો, કારણ કે આ પદ્ધતિ ખૂબ જ ખતરનાક છે, બમણા કારણ કે તે તરત જ ખતરનાક ન દેખાઈ શકે.
    ///
    ///
    /// વિગતો માટે, જુઓ `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // અમે Handle::new_kv અથવા Handle::new_edge નો ઉપયોગ કરી શકતા નથી કારણ કે આપણે આપણા પ્રકારને જાણતા નથી
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` માં edge માટે નવું હેન્ડલ બનાવે છે.
    /// અસુરક્ષિત કારણ કે ક calલરને ખાતરી કરવી આવશ્યક છે કે `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge અનુક્રમણિકા આપેલ છે જ્યાં આપણે ક્ષમતામાં ભરેલા નોડમાં દાખલ કરવા માગીએ છીએ, વિભાજીત બિંદુના સંવેદનશીલ કે.વી. અનુક્રમણિકાની ગણતરી કરીએ છીએ અને નિવેશ ક્યાં કરવું.
///
/// સ્પ્લિટ પોઇન્ટનું લક્ષ્ય તેની કી અને મૂલ્ય પેરેન્ટ નોડમાં સમાપ્ત થવા માટે છે;
/// કીઓ, કિંમતો અને વિભાજીત બિંદુની ડાબી બાજુએ ધાર ડાબી બાઈક બની જાય છે;
/// કીઓ, મૂલ્યો અને વિભાજીત બિંદુની જમણી બાજુએ ધાર યોગ્ય બાળક બને છે.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // ઝેડ રસ્ટ0 ઝેડ ઇશ્યુ #74834 આ સપ્રમાણ નિયમોને સમજાવવાનો પ્રયાસ કરે છે.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// આ edge ની જમણી અને ડાબી બાજુની કી-મૂલ્ય જોડીઓ વચ્ચે નવી કી-મૂલ્યની જોડી શામેલ કરે છે.
    /// આ પદ્ધતિ ધારે છે કે નવી જોડી ફીટ થવા માટે નોડમાં પૂરતી જગ્યા છે.
    ///
    /// પરત થયેલ પોઇન્ટર શામેલ કરેલ મૂલ્ય તરફ નિર્દેશ કરે છે.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// આ edge ની જમણી અને ડાબી બાજુની કી-મૂલ્ય જોડીઓ વચ્ચે નવી કી-મૂલ્યની જોડી શામેલ કરે છે.
    /// જો ત્યાં પૂરતી જગ્યા ન હોય તો આ પદ્ધતિ નોડને વિભાજિત કરે છે.
    ///
    /// પરત થયેલ પોઇન્ટર શામેલ કરેલ મૂલ્ય તરફ નિર્દેશ કરે છે.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ચાઇલ્ડ નોડમાં પેરેંટ પોઇન્ટર અને અનુક્રમણિકાને ઠીક કરે છે કે જે આ ઝેડિજેડ0 ઝેડ લિંક કરે છે.
    /// આ ઉપયોગી છે જ્યારે ધારનો ક્રમ બદલવામાં આવ્યો છે,
    fn correct_parent_link(self) {
        // નોડના અન્ય સંદર્ભોને અમાન્ય કર્યા વિના બેકપોઇંટર બનાવો.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// નવી કી-મૂલ્યની જોડી અને એક ઝેડ્ડ્ઝેડઝેડ દાખલ કરે છે જે આ edge અને તે edge ની જમણી તરફની કી-મૂલ્યની જોડીની વચ્ચેની નવી જોડીની જમણી બાજુ જશે.
    /// આ પદ્ધતિ ધારે છે કે નવી જોડી ફીટ થવા માટે નોડમાં પૂરતી જગ્યા છે.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// નવી કી-મૂલ્યની જોડી અને એક ઝેડ્ડ્ઝેડઝેડ દાખલ કરે છે જે આ edge અને તે edge ની જમણી તરફની કી-મૂલ્યની જોડીની વચ્ચેની નવી જોડીની જમણી બાજુ જશે.
    /// જો ત્યાં પૂરતી જગ્યા ન હોય તો આ પદ્ધતિ નોડને વિભાજિત કરે છે.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// આ edge ની જમણી અને ડાબી બાજુની કી-મૂલ્ય જોડીઓ વચ્ચે નવી કી-મૂલ્યની જોડી શામેલ કરે છે.
    /// જો ત્યાં પૂરતો ઓરડો ન હોય તો આ પદ્ધતિ નોડને વિભાજિત કરે છે, અને મૂળ પહોંચ્યા ત્યાં સુધી પેરન્ટ નોડમાં ભાગલા ભાગને વારંવાર દાખલ કરવાનો પ્રયાસ કરે છે.
    ///
    ///
    /// જો પરત થયેલ પરિણામ એક `Fit` છે, તો તેના હેન્ડલનો નોડ આ edge નો નોડ અથવા પૂર્વજ હોઈ શકે છે.
    /// જો પરત થયેલ પરિણામ એક `Split` છે, તો `left` ફીલ્ડ રુટ નોડ હશે.
    /// પરત થયેલ પોઇન્ટર શામેલ કરેલ મૂલ્ય તરફ નિર્દેશ કરે છે.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// આ edge દ્વારા નિર્દેશિત નોડ શોધે છે.
    ///
    /// પદ્ધતિનું નામ માને છે કે તમે ટોચ પર રુટ નોડ સાથેના વૃક્ષોનું ચિત્ર લો.
    ///
    /// `edge.descend().ascend().unwrap()` અને `node.ascend().unwrap().descend()` બંનેએ, સફળતા પર, કંઇ કરવું જોઈએ નહીં.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // આપણે ગાંઠો માટે કાચા પોઇંટરો વાપરવાની જરૂર છે કારણ કે, જો બોરોટાઇપ marker::ValMut છે, તો મૂલ્યોના બાકી પરિવર્તનીય સંદર્ભો હોઈ શકે છે જેને આપણે અમાન્ય ન કરવું જોઈએ.
        // Heightંચાઈ ક્ષેત્રને ingક્સેસ કરવામાં કોઈ ચિંતા નથી કારણ કે તે મૂલ્યની કiedપિ કરવામાં આવી છે.
        // સાવચેત રહો, એકવાર નોડ પોઇન્ટરનો સંદર્ભ લેવામાં આવે છે, પછી અમે સંદર્ભ (Rust ઇસ્યુ #73987) સાથે ધારની એરેને accessક્સેસ કરીએ છીએ અને એરેમાં અથવા અંદરના કોઈપણ અન્ય સંદર્ભોને અમાન્ય કરીએ છીએ, કોઈપણ આસપાસ હોવું જોઈએ.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // અમે અલગ કી અને મૂલ્ય પદ્ધતિઓ કહી શકતા નથી, કારણ કે બીજાને ક callingલ કરવાથી પહેલા દ્વારા આપેલા સંદર્ભને અમાન્ય કરવામાં આવે છે.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// કે અને હેન્ડલ સંદર્ભિત કી અને મૂલ્ય બદલો.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// પર્ણ ડેટાની કાળજી લઈને, `split` ના ચોક્કસ `NodeType` ના અમલીકરણમાં સહાય કરે છે.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// અંતર્ગત નોડને ત્રણ ભાગોમાં વિભાજિત કરે છે:
    ///
    /// - આ હેન્ડલની ડાબી બાજુ ફક્ત કી-મૂલ્યના જોડીઓ રાખવા માટે નોડ કાપવામાં આવે છે.
    /// - આ હેન્ડલ દ્વારા નિર્દેશિત કી અને મૂલ્ય કાractedવામાં આવે છે.
    /// - આ હેન્ડલની જમણી બાજુની બધી કી-મૂલ્યની જોડીઓ નવા ફાળવેલ નોડમાં મૂકવામાં આવે છે.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// આ હેન્ડલ દ્વારા નિર્દેશિત કી-મૂલ્યની જોડી દૂર કરે છે અને કી-મૂલ્યની જોડી પડી ગયેલી edge ની સાથે, તેને આપે છે.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// અંતર્ગત નોડને ત્રણ ભાગોમાં વિભાજિત કરે છે:
    ///
    /// - આ હેન્ડલની ડાબી બાજુ ફક્ત ધાર અને કી-મૂલ્યવાળા જોડીઓ સમાવવા માટે નોડ કાપવામાં આવે છે.
    /// - આ હેન્ડલ દ્વારા નિર્દેશિત કી અને મૂલ્ય કાractedવામાં આવે છે.
    /// - આ હેન્ડલની જમણી બાજુની બધી ધાર અને કી-મૂલ્યના જોડીઓ નવા ફાળવેલ નોડમાં મૂકવામાં આવે છે.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// આંતરિક કી-મૂલ્યની જોડીની આસપાસ સંતુલન operationપરેશનના મૂલ્યાંકન અને પ્રદર્શન માટે સત્રનું પ્રતિનિધિત્વ કરે છે.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// બાળક તરીકે નોડને સંડોવતા સંતુલન સંદર્ભ પસંદ કરે છે, આમ કેવિની વચ્ચે તરત જ ડાબી તરફ અથવા પિતૃ નોડમાં જમણી બાજુ હોય છે.
    /// જો કોઈ માતાપિતા ન હોય તો `Err` પરત કરે છે.
    /// Panics જો પિતૃ ખાલી છે.
    ///
    /// ડાબી બાજુ પસંદ કરે છે, શ્રેષ્ઠ બનવા માટે જો આપેલ નોડ કોઈક રીતે અંડરફુલ હોય, એટલે કે અહીં ફક્ત તેનો અર્થ એ છે કે તેમાં તેના ડાબા ભાઈ કરતા ઓછા તત્વો છે અને જમણા ભાઈ-બહેન, જો તે અસ્તિત્વમાં છે.
    /// તે કિસ્સામાં, ડાબા ભાઈ-બહેન સાથે મર્જ કરવું વધુ ઝડપી છે, કારણ કે આપણે ફક્ત નોડના એન તત્વોને ખસેડવાની જરૂર છે, તેને જમણી તરફ સ્થાનાંતરિત કરવાને અને આગળ એન તત્વો કરતા વધુ ખસેડવાની જરૂર છે.
    /// ડાબા ભાઈ-બહેનમાંથી ચોરી કરવી એ સામાન્ય રીતે ઝડપી પણ હોય છે, કારણ કે આપણે ભાઈના તત્વોમાંથી ઓછામાં ઓછા એનને ડાબી બાજુએ સ્થાનાંતરિત કરવાને બદલે માત્ર નોડના એન તત્વોને જમણી તરફ ખસેડવાની જરૂર છે.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// મર્જ કરવું શક્ય છે કે કેમ તે પરત કરે છે, એટલે કે, બંને અડીને આવેલા બાળ નોડ્સ સાથે કેન્દ્રિય કેવીને જોડવા માટે નોડમાં પૂરતી જગ્યા છે કે નહીં.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// મર્જ કરે છે અને બંધ પર નિર્ણય લે છે કે શું પાછો આપવો.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // સલામતી: મર્જ કરવામાં આવતા ગાંઠોની heightંચાઇ oneંચાઇથી એક છે
                // આ edge ના નોડના, આમ શૂન્યથી ઉપર છે, તેથી તે આંતરિક છે.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// માતાપિતાની કી-મૂલ્યની જોડી અને બંને અડીને આવેલા ચાઇલ્ડ નોડ્સને ડાબી બાજુ ચાઇલ્ડ નોડમાં મર્જ કરે છે અને સંકોચાયેલ પેરેન્ટ નોડને પરત કરે છે.
    ///
    ///
    /// Panics સિવાય કે અમે `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// માતાપિતાની કી-મૂલ્યની જોડી અને બંને અડીને આવેલા ચાઇલ્ડ નોડ્સને ડાબી ચાઇલ્ડ નોડમાં મર્જ કરે છે અને તે ચાઇલ્ડ નોડ પરત કરે છે.
    ///
    ///
    /// Panics સિવાય કે અમે `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// માતાપિતાની કી-મૂલ્યની જોડી અને બંને અડીને આવેલા ચાઇલ્ડ નોડ્સને ડાબી ચાઇલ્ડ નોડમાં મર્જ કરે છે અને તે ચાઇલ્ડ નોડમાં edge હેન્ડલ આપે છે જ્યાં ટ્રેક કરેલું બાળક edge સમાપ્ત થાય છે,
    ///
    ///
    /// Panics સિવાય કે અમે `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// વૃદ્ધ પિતૃ કી-મૂલ્યની જોડીને જમણા બાળકમાં દબાણ કરતી વખતે, ડાબા બાળકથી કી-મૂલ્યની જોડી દૂર કરે છે અને તેને માતાપિતાના કી-મૂલ્ય સંગ્રહમાં મૂકે છે.
    ///
    /// `track_right_edge_idx` દ્વારા ઉલ્લેખિત મૂળ edge સમાપ્ત થાય ત્યાં અનુરૂપ જમણા બાળકમાં edge નું હેન્ડલ આપે છે.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// જમણા બાળકમાંથી કી-મૂલ્યની જોડી દૂર કરે છે અને વૃદ્ધ પિતૃ કી-મૂલ્યની જોડીને ડાબી બાઈક પર દબાણ કરતી વખતે તેને માતાપિતાના કી-મૂલ્ય સ્ટોરેજમાં મૂકે છે.
    ///
    /// `track_left_edge_idx` દ્વારા ઉલ્લેખિત ડાબા બાળકમાં ઝેડેડજે 0 ઝેડ પરનું હેન્ડલ પાછું આપે છે, જે ખસેડતું નથી.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// આ `steal_left` જેવું જ ચોરી કરે છે પરંતુ એક સાથે અનેક તત્વો ચોરી કરે છે.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ખાતરી કરો કે અમે સુરક્ષિત રીતે ચોરી કરી શકીએ છીએ.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // પર્ણ ડેટા ખસેડો.
            {
                // યોગ્ય બાળકમાં ચોરાયેલા તત્વો માટે જગ્યા બનાવો.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // તત્વોને ડાબી બાજુથી જમણી તરફ ખસેડો.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ડાબી-સૌથી ચોરી કરેલી જોડીને પેરેંટ પર ખસેડો.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // માતાપિતાની કી-મૂલ્યની જોડીને યોગ્ય બાળક પર ખસેડો.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ચોરીની ધાર માટે જગ્યા બનાવો.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // ધાર ચોરી.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` નું સપ્રમાણ ક્લોન.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ખાતરી કરો કે અમે સુરક્ષિત રીતે ચોરી કરી શકીએ છીએ.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // પર્ણ ડેટા ખસેડો.
            {
                // જમણી-ચોરી કરેલી જોડીને પેરેંટ પર ખસેડો.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // માતાપિતાની કી-મૂલ્યની જોડીને ડાબી બાજુ ખસેડો.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // તત્વોને જમણા બાળકથી ડાબી તરફ ખસેડો.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // અંતર ભરો જ્યાં ચોરીના તત્વો હતા.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ધાર ચોરી.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // અંતર ભરો જ્યાં ચોરીની ધાર હતી.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// આ નોડ એ `Leaf` નોડ છે એમ જણાવી કોઈપણ સ્થિર માહિતીને દૂર કરે છે.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// આ નોડ એક `Internal` નોડ છે એમ જણાવી કોઈપણ સ્થિર માહિતીને દૂર કરે છે.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// અંતર્ગત નોડ એ `Internal` નોડ અથવા `Leaf` નોડ છે કે કેમ તે તપાસે છે.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` પછી પ્રત્યયને એક નોડથી બીજામાં ખસેડો.`right` ખાલી હોવું આવશ્યક છે.
    /// `right` નું પ્રથમ ઝેડ્ડેજ 0 ઝેડ યથાવત છે.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// નિવેશનું પરિણામ, જ્યારે નોડને તેની ક્ષમતા કરતાં વધુ વિસ્તૃત કરવાની જરૂર હોય ત્યારે.
pub struct SplitResult<'a, K, V, NodeType> {
    // તત્વો અને કિનારીઓ સાથેના અસ્તિત્વમાં રહેલા ઝાડમાં ફેરફાર કરેલ નોડ જે `kv` ની ડાબી બાજુએ છે.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // કેટલીક કી અને મૂલ્ય વિભાજિત, અન્યત્ર દાખલ કરવા માટે.
    pub kv: (K, V),
    // `kv` ની જમણી બાજુના તત્વો અને કિનારીઓવાળા, ન જોડાયેલા, નવા નોડ.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // શું આ ઉધારના પ્રકારનાં નોડ સંદર્ભો ઝાડનાં અન્ય ગાંઠોમાં જવા માટે પરવાનગી આપે છે.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ટ્ર Traવર્સલની જરૂર નથી, તે `borrow_mut` ના પરિણામનો ઉપયોગ કરીને થાય છે.
        // ટ્ર traવર્સલને અક્ષમ કરીને, અને ફક્ત મૂળના નવા સંદર્ભો બનાવીને, આપણે જાણીએ છીએ કે `Owned` પ્રકારનો દરેક સંદર્ભ રૂટ નોડનો છે.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// પ્રારંભિક તત્વોની ટુકડામાં એક મૂલ્ય શામેલ કરો એક અનુક્રમિત તત્વ દ્વારા.
///
/// # Safety
/// સ્લાઈસમાં `idx` કરતાં વધુ તત્વો છે.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// બધા પ્રારંભિક તત્વોની ટુકડામાંથી એક મૂલ્યને દૂર કરે છે અને પાછું આપે છે, પાછળનું એક અનઇટિટેલાઇઝ્ડ તત્વ પાછળ છોડીને.
///
///
/// # Safety
/// સ્લાઈસમાં `idx` કરતાં વધુ તત્વો છે.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// સ્લાઈસ `distance` સ્થિતિમાં તત્વોને ડાબી તરફ સ્થાનાંતરિત કરો.
///
/// # Safety
/// સ્લાઈસમાં ઓછામાં ઓછા `distance` તત્વો છે.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// સ્લાઈસ `distance` સ્થિતિમાં ઘટકોને જમણી તરફ સ્થાનાંતરિત કરો.
///
/// # Safety
/// સ્લાઈસમાં ઓછામાં ઓછા `distance` તત્વો છે.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// બધા કિંમતોને પ્રારંભિક તત્વોની ટુકડામાંથી અનઇંટિએટલાઇઝ્ડ તત્વોની ટુકડામાં ખસેડે છે, બધા અનઇંટિલાઇઝ્ડ તરીકે `src` ની પાછળ છોડીને.
///
/// `dst.copy_from_slice(src)` જેવું કામ કરે છે પરંતુ `T` ને `Copy` હોવાની જરૂર નથી.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;