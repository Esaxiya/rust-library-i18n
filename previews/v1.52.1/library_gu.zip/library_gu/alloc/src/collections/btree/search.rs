use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` જેમ, જોવા માટે સમાવિષ્ટ બાઉન્ડ.
    Included(T),
    /// `Bound::Excluded(T)` ની જેમ, જોવાનું એક વિશિષ્ટ બાઉન્ડ.
    Excluded(T),
    /// `Bound::Unbounded` ની જેમ, બિનશરતી શામેલ બાઉન્ડ.
    AllIncluded,
    /// બિનશરતી વિશિષ્ટ બાઉન્ડ.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// નોડની આગેવાનીમાં, (સબ) ટ્રીમાં આપેલ ચાવી, રિકર્સિવ રીતે જુએ છે.
    /// મેળ ખાતા KV ના હેન્ડલ સાથે `Found` પરત કરે છે, જો કોઈ હોય તો.
    /// નહિંતર, જ્યાં ચાવી છે ત્યાંના પર્ણ edge ના હેન્ડલ સાથે એક `GoDown` આપે છે.
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને કી દ્વારા ઓર્ડર કરવામાં આવે છે, જેમ કે એક `BTreeMap` માંનું ઝાડ છે.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// નજીકના નોડ પર નીચે જાય છે જ્યાં edge એ શ્રેણીના નીચલા સીમા સાથે મેળ ખાતી હોય તે edge થી ઉપરના બાઉન્ડ સાથે બંધબેસે છે, એટલે કે, નજીકમાં નોડ કે જેમાં ઓછામાં ઓછી એક કી સમાવિષ્ટ હોય.
    ///
    ///
    /// જો મળે, તો તે નોડ સાથે `Ok` આપે છે, તેમાં edge સૂચકાંકોની જોડી શ્રેણીને મર્યાદિત કરે છે, અને નોડ આંતરિક હોય તેવા કિસ્સામાં, બાળ નોડ્સમાં શોધ ચાલુ રાખવા માટે બાઉન્ડ્સની અનુરૂપ જોડી.
    ///
    /// જો મળ્યું ન હોય, તો આખી શ્રેણી સાથે મેળ ખાતા પર્ણ edge સાથે એક `Err` આપે છે.
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને ચાવી દ્વારા મંગાવવામાં આવે.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // આ ચલોને ઇનલાઇન કરવાથી બચવું જોઈએ.
        // અમે ધારીએ છીએ કે `range` દ્વારા નોંધાયેલ સીમાઓ સમાન રહેશે, પરંતુ વિરોધી અમલીકરણ, (#81138) કોલ્સ વચ્ચે બદલાઈ શકે છે.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// શ્રેણીના નીચલા સીમાને સીમિત કરતા નોડમાં એક ઝેડજેડ 0 ઝેડ શોધે છે.
    /// મેચિંગ ચાઇલ્ડ નોડમાં શોધ ચાલુ રાખવા માટે વાપરવા માટે નીચલા બાઉન્ડને પણ પરત કરે છે, જો `self` એ આંતરિક નોડ છે.
    ///
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને ચાવી દ્વારા મંગાવવામાં આવે.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ઉપલા બાઉન્ડ માટે `find_lower_bound_edge` નો ક્લોન.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// પુનરાવર્તન વિના, નોડમાં આપેલ કી જુએ છે.
    /// મેળ ખાતા KV ના હેન્ડલ સાથે `Found` પરત કરે છે, જો કોઈ હોય તો.
    /// નહિંતર, edge ના હેન્ડલ સાથે એક `GoDown` આપે છે જ્યાં કી મળી શકે છે (જો નોડ આંતરિક હોય) અથવા જ્યાં કી દાખલ કરી શકાય છે.
    ///
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને કી દ્વારા ઓર્ડર કરવામાં આવે છે, જેમ કે એક `BTreeMap` માંનું ઝાડ છે.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// કાં તો નોડમાં કેવી અનુક્રમણિકા આપે છે કે જેના પર કી (અથવા સમકક્ષ) અસ્તિત્વમાં છે, અથવા edge અનુક્રમણિકા જ્યાં કીની છે.
    ///
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને કી દ્વારા ઓર્ડર કરવામાં આવે છે, જેમ કે એક `BTreeMap` માંનું ઝાડ છે.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// શ્રેણીના નીચલા સીમાને સીમિત કરતા નોડમાં એક ઝેડેડજે 0 ઝેડ અનુક્રમણિકા શોધે છે.
    /// મેચિંગ ચાઇલ્ડ નોડમાં શોધ ચાલુ રાખવા માટે વાપરવા માટે નીચલા બાઉન્ડને પણ પરત કરે છે, જો `self` એ આંતરિક નોડ છે.
    ///
    ///
    /// પરિણામ ફક્ત ત્યારે જ અર્થપૂર્ણ છે જો ઝાડને ચાવી દ્વારા મંગાવવામાં આવે.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ઉપલા બાઉન્ડ માટે `find_lower_bound_index` નો ક્લોન.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}