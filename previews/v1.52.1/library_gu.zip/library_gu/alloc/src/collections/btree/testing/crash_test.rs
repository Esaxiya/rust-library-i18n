use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// ક્રેશ ટેસ્ટ ડમી દાખલાઓનો બ્લુપ્રિન્ટ જે ચોક્કસ ઘટનાઓને મોનિટર કરે છે.
/// કેટલાક દાખલાઓ અમુક સમયે panic પર ગોઠવેલ હોઈ શકે છે.
/// ઇવેન્ટ્સ `clone`, `drop` અથવા કેટલાક અનામી `query` છે.
///
/// ક્રેશ ટેસ્ટ ડમીઝને ઓળખવામાં આવે છે અને આઈડી દ્વારા ઓર્ડર આપવામાં આવે છે, જેથી તેઓ બીટ્રીમેપમાં કી તરીકે ઉપયોગ કરી શકે.
/// ઇરાદાપૂર્વક ઉપયોગ કરે છે તે અમલીકરણ, `Debug` trait સિવાય crate માં નિર્ધારિત કોઈપણ પર આધાર રાખતો નથી.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// ક્રેશ ટેસ્ટ ડમી ડિઝાઇન બનાવે છે.`id` હુકમ અને દાખલાઓની સમાનતા નક્કી કરે છે.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// ક્રેશ ટેસ્ટ ડમીનું એક ઉદાહરણ બનાવે છે જે તે કઇ ઇવેન્ટ્સનો અનુભવ કરે છે અને વૈકલ્પિક panics રેકોર્ડ કરે છે.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// ડમીના દાખલા ક્લોન કરવામાં આવ્યા છે તે કેટલી વાર આપે છે.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// ડમીના કેટલા વખત દાખલા પડ્યા છે તે પરત કરે છે.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// ડમીના તેના `query` સભ્યને કેટલી વાર ઇન્વેસ્ટ કરવામાં આવ્યા છે તે પાછો આપે છે.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// કેટલીક અનામી ક્વેરી, જેનું પરિણામ પહેલેથી જ આપવામાં આવ્યું છે.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}