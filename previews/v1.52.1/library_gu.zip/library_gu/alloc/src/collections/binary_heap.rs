//! દ્વિસંગી apગલા સાથે અગ્રતા કતાર લાગુ કરવામાં આવી.
//!
//! સૌથી વધુ ઘટક શામેલ કરવા અને પ popપ કરવામાં *O*(log(*n*)) સમયની જટિલતા છે.
//! સૌથી મોટા તત્વની તપાસ કરવી એ *ઓ*(1) છે.ઝેડ 0 વેક્ટર 0 ઝેડને દ્વિસંગી apગલામાં રૂપાંતર કરવું તે જગ્યાએ કરી શકાય છે, અને તેમાં *ઓ*(*એન*) જટિલતા છે.
//! દ્વિસંગી heગલાને સ્થળે સ Zર્ટ vector માં રૂપાંતરિત પણ કરી શકાય છે, તેનો ઉપયોગ *O*(*n*\*log(* n*)) ઇન-પ્લેસ હીપ્સોર્ટ) માટે થઈ શકે છે.
//!
//! # Examples
//!
//! આ એક મોટું ઉદાહરણ છે જે [shortest path problem][sssp] ને [directed graph][dir_graph] પર હલ કરવા માટે [Dijkstra's algorithm][dijkstra] લાગુ કરે છે.
//!
//! તે બતાવે છે કે કેવી રીતે કસ્ટમ પ્રકારો સાથે [`BinaryHeap`] નો ઉપયોગ કરવો.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // અગ્રતા કતાર `Ord` પર આધારિત છે.
//! // સ્પષ્ટપણે trait અમલમાં મૂકવું જેથી કતાર મહત્તમ-apગલાને બદલે મિનિ-apગલો થઈ જાય.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // નોંધ લો કે અમે ખર્ચ પરનો ઓર્ડર ફ્લિપ કરીએ છીએ.
//!         // ટાઇની સ્થિતિમાં આપણે સ્થિતિઓની તુલના કરીએ છીએ, આ પગલું `PartialEq` અને `Ord` ની સુસંગતતાના અમલીકરણ માટે જરૂરી છે.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` તેમજ અમલ કરવાની જરૂર છે.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ટૂંકા અમલીકરણ માટે, દરેક નોડ એક `usize` તરીકે રજૂ થાય છે.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ડિજકસ્ત્રનું ટૂંકું પાથ એલ્ગોરિધમ
//!
//! // `start` થી પ્રારંભ કરો અને દરેક નોડના વર્તમાન ટૂંકા અંતરને ટ્રેક કરવા માટે `dist` નો ઉપયોગ કરો.આ અમલીકરણ મેમરી-કાર્યક્ષમ નથી કારણ કે તે કતારમાં ડુપ્લિકેટ ગાંઠો છોડી શકે છે.
//! //
//! // તે સરળ અમલીકરણ માટે, `usize::MAX` નો સેન્ટિનેલ મૂલ્ય તરીકે પણ ઉપયોગ કરે છે.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // ડિસ્ટ [નોડ]=હાલનું સૌથી ટૂંકું અંતર `start` થી `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // અમે શૂન્ય ખર્ચ સાથે, `start` પર છીએ
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // પ્રથમ (min-heap) નીચા ખર્ચવાળા ગાંઠો સાથે સરહદની તપાસ કરો
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // વૈકલ્પિક રૂપે આપણે બધા ટૂંકા રસ્તાઓ શોધવાનું ચાલુ રાખી શક્યા હોત
//!         if position == goal { return Some(cost); }
//!
//!         // અગત્યનું કારણ કે આપણે પહેલેથી જ વધુ સારી રીત શોધી શકી છે
//!         if cost > dist[position] { continue; }
//!
//!         // દરેક નોડ માટે આપણે પહોંચી શકીએ છીએ, જુઓ કે આપણે આ નોડમાંથી ઓછી કિંમતે જતા કોઈ રસ્તો શોધી શકીએ કે કેમ
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // જો એમ હોય તો, તેને ફ્રન્ટિયરમાં ઉમેરો અને ચાલુ રાખો
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // રાહત, આપણે હવે એક સારો રસ્તો શોધી કા .્યો છે
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // લક્ષ્ય પહોંચી શકાય તેવું નથી
//!     None
//! }
//!
//! fn main() {
//!     // આ નિર્દેશિત ગ્રાફ છે જેનો આપણે ઉપયોગ કરીશું.
//!     // નોડ નંબરો જુદા જુદા રાજ્યોને અનુરૂપ છે, અને ઝેડ્ડેજ 0 ઝેડ વેઇટ એક નોડથી બીજામાં જવાના ખર્ચનું પ્રતીક છે.
//!     //
//!     // નોંધ લો કે ધાર એકતરફી છે.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          વી 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ગ્રાફને અડીને સૂચિ તરીકે રજૂ કરવામાં આવે છે જ્યાં દરેક અનુક્રમણિકા, નોડ મૂલ્યને અનુરૂપ, આઉટગોઇંગ ધારની સૂચિ ધરાવે છે.
//!     // તેની કાર્યક્ષમતા માટે પસંદ કરેલ.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // નોડ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // નોડ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // નોડ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // નોડ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // નોડ 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// દ્વિસંગી apગલા સાથે અગ્રતા કતાર લાગુ કરવામાં આવી.
///
/// આ એક મહત્તમ apગલો હશે.
///
/// આઇટમની એવી રીતે સુધારણા કરવી તે તર્કની ભૂલ છે કે `Ord` trait દ્વારા નિર્ધારિત મુજબ, આઇટમની અન્ય કોઈપણ વસ્તુને લગતી ingર્ડર આપતી વખતે, તે changesગલામાં હોય ત્યારે બદલાય છે.
///
/// આ સામાન્ય રીતે ફક્ત `Cell`, `RefCell`, વૈશ્વિક રાજ્ય, I/O અથવા અસુરક્ષિત કોડ દ્વારા શક્ય છે.
/// આવી તર્ક ભૂલથી પરિણમેલા વર્તનનો ઉલ્લેખ કરવામાં આવ્યો નથી, પરંતુ પરિણામની અસ્પષ્ટ વર્તનમાં પરિણમશે નહીં.
/// આમાં ઝેડ 0 પicsનિક્સ 0 ઝેડ, ખોટા પરિણામો, વિયોગો, મેમરી લિક અને સમાપ્ત ન થવાનો સમાવેશ થઈ શકે છે.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // પ્રકાર અનુમાન અમને સ્પષ્ટ પ્રકારનાં સહીને બાકાત કરવા દે છે (જે આ ઉદાહરણમાં `BinaryHeap<i32>` હશે).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Theગલાની આગામી વસ્તુ જોવા માટે આપણે ડોકીનો ઉપયોગ કરી શકીએ છીએ.
/// // આ કિસ્સામાં, ત્યાં હજી સુધી કોઈ આઇટમ્સ નથી તેથી અમને કંઈ મળતું નથી.
/// assert_eq!(heap.peek(), None);
///
/// // ચાલો કેટલાક સ્કોર્સ ઉમેરીએ ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // હવે પિક એ theગલાની સૌથી મહત્વપૂર્ણ વસ્તુ બતાવે છે.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // આપણે aગલાની લંબાઈ ચકાસી શકીએ છીએ.
/// assert_eq!(heap.len(), 3);
///
/// // અમે theગલાની વસ્તુઓ પર ફરી વળી શકીએ છીએ, જો કે તે ક્રમમાં આવે છે.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // જો આપણે તેના બદલે આ સ્કોર્સ પ popપ કરીએ, તો તેઓ ક્રમમાં પાછા આવવા જોઈએ.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // અમે બાકીની કોઈપણ ચીજોનો clearગલો સાફ કરી શકીએ છીએ.
/// heap.clear();
///
/// // .ગલો હવે ખાલી હોવો જોઈએ.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// ક્યાં તો `std::cmp::Reverse` અથવા કસ્ટમ `Ord` અમલીકરણનો ઉપયોગ `BinaryHeap` ને મિનિ-હીપ બનાવવા માટે કરી શકાય છે.
/// આ `heap.pop()` ને સૌથી મોટી કિંમતને બદલે સૌથી નાના મૂલ્ય પરત કરે છે.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` માં કિંમતો વીંટો
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // જો આપણે આ સ્કોર્સને હવે પ ,પ કરીએ, તો તે પાછલા ક્રમમાં પાછા આવવા જોઈએ.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # સમયની જટિલતા
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` નું મૂલ્ય અપેક્ષિત કિંમત છે;પદ્ધતિ દસ્તાવેજીકરણ વધુ વિગતવાર વિશ્લેષણ આપે છે.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` પરની સૌથી મોટી આઇટમના પરિવર્તનીય સંદર્ભને વીંટાળતી રચના.
///
///
/// આ `struct`, [`BinaryHeap`] પર [`peek_mut`] પદ્ધતિ દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // સલામતી: પીકમૂટ ફક્ત ખાલી ન પડે તેવા forગલા માટે જ ઇન્સ્ટન્ટિએટેડ છે.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // સલામત: પીકમૂટ ફક્ત ખાલી ખાલી forગલા માટે જ ઇન્સ્ટન્ટિએટેડ છે
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // સલામત: પીકમૂટ ફક્ત ખાલી ખાલી forગલા માટે જ ઇન્સ્ટન્ટિએટેડ છે
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Apગલામાંથી પેક કરેલું મૂલ્ય દૂર કરે છે અને પાછું આપે છે.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ખાલી `BinaryHeap<T>` બનાવે છે.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// મેક્સ-હીપ તરીકે ખાલી `BinaryHeap` બનાવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// વિશિષ્ટ ક્ષમતાવાળા ખાલી `BinaryHeap` બનાવે છે.
    /// આ `capacity` તત્વો માટે પૂરતી મેમરીનું પૂર્વનિર્ધારણ કરે છે, જેથી `BinaryHeap` ઓછામાં ઓછા ઘણા મૂલ્યો શામેલ ન થાય ત્યાં સુધી ફરીથી ફરીથી ગોઠવવાની જરૂર નથી.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// દ્વિસંગી apગલાની સૌથી મોટી વસ્તુનો પરિવર્તનીય સંદર્ભ, અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// Note: જો `PeekMut` મૂલ્ય લીક થાય છે, તો apગલો અસંગત સ્થિતિમાં હોઈ શકે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # સમયની જટિલતા
    ///
    /// જો આઇટમમાં ફેરફાર કરવામાં આવે તો સૌથી ખરાબ સમયની જટિલતા એ *O*(log(*n*)) છે, નહીં તો તે *ઓ*(1) છે.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// દ્વિસંગી apગલામાંથી મહાન વસ્તુને દૂર કરે છે અને તેને પરત આપે છે, અથવા જો ખાલી હોય તો `None`.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # સમયની જટિલતા
    ///
    /// *N* તત્વો ધરાવતા apગલા પર `pop` નો સૌથી ખરાબ કેસ ખર્ચ એ *O*(log(*n*)) છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // સલામતી: !self.is_empty() એટલે self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// બાઈનરીના ontoગલા પર કોઈ વસ્તુને દબાણ કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # સમયની જટિલતા
    ///
    /// `push` ની અપેક્ષિત કિંમત, એ તત્વોને દબાણમાં લાવવાના દરેક સંભવિત ક્રમમાં સરેરાશ, અને પૂરતા પ્રમાણમાં મોટી સંખ્યામાં દબાણ,*ઓ*(1) છે.
    ///
    /// પહેલેથી જ કોઈપણ સ .ર્ટ કરેલા દાખલામાં *નથી* તેવા તત્વોને દબાણ કરતી વખતે આ સૌથી અર્થપૂર્ણ કિંમત મેટ્રિક છે.
    ///
    /// જો તત્વો મુખ્યત્વે ચડતા ક્રમમાં દબાણ કરવામાં આવે તો સમય જટિલતામાં ઘટાડો થાય છે.
    /// સૌથી ખરાબ સ્થિતિમાં, તત્વોને ચડતા ક્રમમાં દબાણ કરવામાં આવે છે અને દબાણ દીઠ orણમુક્ત કિંમત *n* તત્વો ધરાવતા againstગલાની સામે *O*(log(*n*)) છે.
    ///
    /// `push` પર *સિંગલ* ક ofલની સૌથી ખરાબ સ્થિતિની કિંમત છે *ઓ*(*એન*).સૌથી ખરાબ સ્થિતિ ત્યારે થાય છે જ્યારે ક્ષમતા ખતમ થઈ જાય અને તેને કદ બદલવાની જરૂર હોય.
    /// પાછલા આંકડાઓમાં આકાર બદલવા માટેનો ખર્ચ કરવામાં આવ્યો છે.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // સલામતી: અમે નવી વસ્તુને ધકેલી દીધી એટલે તેનો અર્થ એ કે
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` લે છે અને સ Zર્ટ કરેલા (ascending) ક્રમમાં vector પરત આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // સલામતી: `end` `self.len() - 1` થી 1 (બંને શામેલ) પર જાય છે,
            //  તેથી હંમેશા alwaysક્સેસ કરવા માટે તે માન્ય અનુક્રમણિકા છે.
            //  અનુક્રમણિકા 0 (એટલે કે `ptr`) ને accessક્સેસ કરવું સલામત છે, કારણ કે
            //  1 <=અંત <self.len(), જેનો અર્થ self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // સલામતી: `end` `self.len() - 1` થી 1 પર જાય છે (બંને શામેલ છે) તેથી:
            //  0 <1 <=અંત <= self.len(), 1 <self.len() જેનો અર્થ 0 <અંત અને અંત <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // ઝિફ્ટવેક્ટર 0 ઝેડ (એક છિદ્ર પાછળ છોડીને) ની તુલના બહાર ખસેડવા, અન્ય સાથે સ્થળાંતર કરવા અને કા removedી નાખેલા તત્વને છિદ્રના અંતિમ સ્થાને પાછા ઝેડવેક્ટર 0 ઝેડમાં ખસેડવા માટે sift_up અને sift_down ના અમલીકરણ અસુરક્ષિત બ્લોક્સનો ઉપયોગ કરે છે.
    //
    // `Hole` પ્રકારનો ઉપયોગ આને રજૂ કરવા માટે કરવામાં આવે છે, અને ખાતરી કરો કે છિદ્ર તેના અવકાશના અંતે, panic પર પણ પાછું ભરાઈ ગયું છે.
    // છિદ્રનો ઉપયોગ અદલાબદલના ઉપયોગની તુલનામાં સતત પરિબળને ઘટાડે છે, જેમાં ઘણી ચાલ કરતાં બમણો સમાવેશ થાય છે.
    //
    //
    //
    //

    /// # Safety
    ///
    /// કlerલરને તેની ખાતરી કરવી આવશ્યક છે કે `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` પર મૂલ્ય કા Takeો અને એક છિદ્ર બનાવો.
        // સલામતી: કlerલર તેની ખાતરી આપે છે કે << self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // સલામતી: hole.pos()> પ્રારંભ>=0, જેનો અર્થ hole.pos()> 0
            //  અને તેથી hole.pos(), 1 અન્ડરફ્લો થઈ શકશે નહીં.
            //  આ ખાતરી આપે છે કે પેરેંટ <hole.pos() તેથી તે માન્ય અનુક્રમણિકા પણ છે!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // સલામતી: ઉપરની જેમ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` પર એક તત્વ લો અને તેને downગલાથી નીચે ખસેડો, જ્યારે તેના બાળકો મોટા હોય.
    ///
    ///
    /// # Safety
    ///
    /// કlerલરને તેની ખાતરી કરવી આવશ્યક છે કે `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // સલામતી: કlerલર ગેરેંટી આપે છે કે પોઝ <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // લૂપ ઇનઆરીએન્ટ: બાળક==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // સલામત બે બાળકોની સાથે સરખામણી કરો: બાળક <અંત, 1 <self.len() અને બાળક + 1 <અંત <= self.len(), તેથી તેઓ માન્ય અનુક્રમણિકા છે.
            //
            //  બાળક==2 *hole.pos() + 1!= hole.pos() અને બાળક + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 અથવા 2* hole.pos() + 2 ઓવરફ્લો થઈ શકે જો ટી ઝેડએસટી હોય
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // જો આપણે પહેલાથી ક્રમમાં હોય, તો રોકો.
            // સલામતી: બાળક હવે વૃદ્ધ બાળક અથવા વૃદ્ધ બાળક +1 છે
            //  અમે પહેલેથી જ સાબિત કર્યું છે કે બંને <self.len() અને!= hole.pos() છે
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // સલામતી: ઉપરની જેમ.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // સલામતી: અને&શોર્ટ સર્કિટ, જેનો અર્થ એ કે
        //  બીજી શરત તે પહેલાથી જ સાચું છે કે બાળક==અંત, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // સલામતી: બાળક પહેલાથી જ માન્ય અનુક્રમણિકા સાબિત થયું છે અને
            //  બાળક==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// કlerલરને તેની ખાતરી કરવી આવશ્યક છે કે `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // સલામત: પોઝ <લેન કલર દ્વારા ખાતરી આપવામાં આવે છે અને
        //  દેખીતી રીતે લેન= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` પર એક તત્વ લો અને તેને બધી રીતે apગલાની નીચે ખસેડો, પછી તેને તેની સ્થિતિ પર સત્યંતરણ કરો.
    ///
    ///
    /// Note: જ્યારે તે તત્વ મોટા તરીકે ઓળખાય છે/તળિયે નજીક હોવું જોઈએ ત્યારે આ ઝડપી છે.
    ///
    /// # Safety
    ///
    /// કlerલરને તેની ખાતરી કરવી આવશ્યક છે કે `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // સલામતી: કlerલર તેની ખાતરી આપે છે કે << self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // લૂપ ઇનઆરીએન્ટ: બાળક==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // સલામતી: બાળક <અંત, 1 <self.len() અને
            //  બાળક +1 <અંત <= self.len(), તેથી તેઓ માન્ય અનુક્રમણિકા છે.
            //  બાળક==2 *hole.pos() + 1!= hole.pos() અને બાળક + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 અથવા 2* hole.pos() + 2 ઓવરફ્લો થઈ શકે જો ટી ઝેડએસટી હોય
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // સલામતી: ઉપરની જેમ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // સલામત: બાળક==અંત, 1 <self.len(), તેથી તે માન્ય અનુક્રમણિકા છે
            //  અને બાળક==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // સલામતી: પોઝ એ છિદ્રમાં સ્થાન છે અને તે પહેલાથી સાબિત થયું હતું
        //  માન્ય અનુક્રમણિકા હોઈ.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // સલામતી: n એ self.len()/2 થી પ્રારંભ થાય છે અને નીચે 0 પર જાય છે.
            //  ફક્ત ત્યારે જ કેસ! (N <self.len()) છે જો self.len() ==0, પરંતુ તે લૂપ સ્થિતિ દ્વારા નકારી કા .વામાં આવે છે.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` ના બધા ઘટકોને `self` માં ખસેડે છે, `other` ને ખાલી છોડી દે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) ઓપરેશન લે છે અને લગભગ 2 *(len1 + len2) ની તુલના ખરાબમાં થાય છે જ્યારે `extend` એ O(len2* log(len1)) ઓપરેશન લે છે અને લગભગ 1 *len2* log_2(len1) તુલનામાં, len1>= len2 ધારીને.
        // મોટા Forગલા માટે, ક્રોસઓવર પોઇન્ટ હવે આ તર્કનું પાલન કરશે નહીં અને તે અનુભવપૂર્ણ રીતે નક્કી કરવામાં આવ્યું હતું.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// એક ઇરેટર પાછો આપે છે જે orderગલાના ક્રમમાં તત્વો મેળવે છે.
    /// પુનvedપ્રાપ્ત તત્વો મૂળ fromગલામાંથી દૂર કરવામાં આવે છે.
    /// બાકીના તત્વો apગલાબંધ ક્રમમાં મૂકવા પર દૂર કરવામાં આવશે.
    ///
    /// Note:
    /// * `.drain_sorted()` એ *ઓ*(*n*\*log(* n*)); `.drain()` કરતા વધુ ધીમી છે).
    ///   તમારે મોટાભાગના કેસો માટે બાદમાં વાપરવું જોઈએ.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // elementsગલા ક્રમમાં બધા તત્વો દૂર કરે છે
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// પૂર્વજાત દ્વારા નિર્ધારિત ફક્ત તત્વો જ જાળવી રાખે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, બધા તત્વો `e` ને દૂર કરો જેમ કે `f(&e)` `false` આપે છે.
    /// તત્વોની ગોઠવણી (અને અનિશ્ચિત) ક્રમમાં કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ફક્ત સમાન સંખ્યા રાખો
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// અંતર્ગત vector માં, મનસ્વી ક્રમમાં બધા મૂલ્યોની મુલાકાત લેનાર એક ઇટરેટર આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // મનસ્વી ક્રમમાં 1, 2, 3, 4 છાપો
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// એક ઇરેટર પાછો આપે છે જે orderગલાના ક્રમમાં તત્વો મેળવે છે.
    /// આ પદ્ધતિ મૂળ apગલા વાપરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// દ્વિસંગી apગલાની સૌથી મોટી વસ્તુ અથવા જો ખાલી હોય તો `None` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # સમયની જટિલતા
    ///
    /// સૌથી ખરાબ કિસ્સામાં કિંમત *ઓ*(1) છે.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// દ્વિસંગી apગલો ફરીથી ગોઠવ્યા વિના પકડી શકે તેવા તત્વોની સંખ્યા પરત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// આપેલ `BinaryHeap` માં બરાબર `additional` વધુ તત્વો શામેલ કરવાની ન્યૂનતમ ક્ષમતા અનામત રાખે છે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// નોંધ કરો કે ફાળવણીકાર વિનંતી કરતા સંગ્રહને વધુ જગ્યા આપી શકે છે.
    /// તેથી ક્ષમતા ચોક્કસપણે ઓછામાં ઓછી હોવા પર આધાર રાખી શકાતી નથી.
    /// જો ઝેડ ફ્યુચર0 ઝેડ નિવેશની અપેક્ષા હોય તો [`reserve`] ને પ્રાધાન્ય આપો.
    ///
    /// # Panics
    ///
    /// જો નવી ક્ષમતા `usize` ઓવરફ્લો થાય તો ઝેડ પanનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` માં શામેલ કરવા માટે ઓછામાં ઓછા `additional` વધુ તત્વો માટેની ક્ષમતા અનામત છે.
    /// સંગ્રહમાં વારંવાર ફેરબદલ ટાળવા માટે સંગ્રહ વધુ જગ્યા અનામત રાખી શકે છે.
    ///
    /// # Panics
    ///
    /// જો નવી ક્ષમતા `usize` ઓવરફ્લો થાય તો ઝેડ પanનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// શક્ય તેટલી વધારાની ક્ષમતાને કાardsી નાખો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// નીચા બાઉન્ડ સાથેની ક્ષમતાને કા .ી નાખો.
    ///
    /// ક્ષમતા ઓછામાં ઓછી લંબાઈ અને સપ્લાય કરેલ મૂલ્ય બંને જેટલી મોટી રહેશે.
    ///
    ///
    /// જો વર્તમાન ક્ષમતા નીચલી મર્યાદા કરતા ઓછી હોય, તો આ નો-opપ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` લે છે અને મનસ્વી ક્રમમાં અંતર્ગત vector પરત આપે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // કોઈ ક્રમમાં છાપશે
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// દ્વિસંગી apગલાની લંબાઈ પરત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// દ્વિસંગી apગલો ખાલી છે કે કેમ તે તપાસે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// દૂર કરેલા તત્વો પર પુનરાવર્તક પાછા ફરતા, બાઈનરીના apગલાને સાફ કરે છે.
    ///
    /// તત્વો મનસ્વી ક્રમમાં દૂર કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// દ્વિસંગી apગલાથી બધી વસ્તુઓ ઉતારી.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// છિદ્ર એક સ્લાઇસમાં છિદ્રનું પ્રતિનિધિત્વ કરે છે.
///
/// ડ્રોપમાં, `Hole` મૂળ કા removedી નાખેલી કિંમત સાથે છિદ્રની સ્થિતિ ભરીને સ્લાઇસને પુનર્સ્થાપિત કરશે.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// અનુક્રમણિકા `pos` પર એક નવો `Hole` બનાવો.
    ///
    /// અસુરક્ષિત, કારણ કે ડેટા ડેટાની સ્લાઇસમાં જ હોવો જોઈએ.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // સલામત: પોસ સ્લાઇસની અંદર હોવી જોઈએ
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// દૂર કરેલા તત્વનો સંદર્ભ આપે છે.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` પર તત્વનો સંદર્ભ આપે છે.
    ///
    /// અસુરક્ષિત કારણ કે અનુક્રમણિકા ડેટા સ્લાઈસમાં હોવી આવશ્યક છે અને પોસ જેટલી હોવી જોઈએ નહીં.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// નવા સ્થાન પર છિદ્ર ખસેડો
    ///
    /// અસુરક્ષિત કારણ કે અનુક્રમણિકા ડેટા સ્લાઈસમાં હોવી આવશ્યક છે અને પોસ જેટલી હોવી જોઈએ નહીં.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ફરીથી છિદ્ર ભરો
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` ના તત્વો ઉપર એક ઇરેટર.
///
/// આ `struct` [`BinaryHeap::iter()`] દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ની તરફેણમાં દૂર કરો
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` ના તત્વો ઉપર માલિકીનું ઇટરેટર.
///
/// આ `struct` [`BinaryHeap::into_iter()`] (`IntoIterator` trait દ્વારા પ્રદાન થયેલ) દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// એક `BinaryHeap` ના તત્વો ઉપર ડ્રેઇનિંગ ઇટરેટર.
///
/// આ `struct` [`BinaryHeap::drain()`] દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// એક `BinaryHeap` ના તત્વો ઉપર ડ્રેઇનિંગ ઇટરેટર.
///
/// આ `struct` [`BinaryHeap::drain_sorted()`] દ્વારા બનાવવામાં આવ્યું છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Apગલા ક્રમમાં હીપ તત્વો દૂર કરે છે.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ને `BinaryHeap<T>` માં ફેરવે છે.
    ///
    /// આ રૂપાંતર સ્થાને થાય છે, અને તેમાં *O*(*n*) સમયની જટિલતા છે.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ને `Vec<T>` માં ફેરવે છે.
    ///
    /// આ રૂપાંતર માટે કોઈ ડેટા હિલચાલ અથવા ફાળવણીની આવશ્યકતા નથી, અને તેમાં સતત સમયની જટિલતા છે.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// વપરાશકર્તા ઇટરેટર બનાવે છે, એટલે કે, તે દરેક મૂલ્યને બાઈનરી apગલાને મનસ્વી ક્રમમાં ખસેડે છે.
    /// આ કહેવા પછી દ્વિસંગી heગલાનો ઉપયોગ કરી શકાતો નથી.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // મનસ્વી ક્રમમાં 1, 2, 3, 4 છાપો
    /// for x in heap.into_iter() {
    ///     // x નો પ્રકાર i32 છે, &i32 નહીં
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}