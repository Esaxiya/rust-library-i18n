#![stable(feature = "wake_trait", since = "1.51.0")]
//! અસુમેળ કાર્યો સાથે કામ કરવા માટે પ્રકારો અને ઝેડ 0 ટ્રાઇટ્સ 0 ઝેડ.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// એક્ઝેક્યુટર પર કાર્ય જાગવાનો અમલ.
///
/// આ trait નો ઉપયોગ [`Waker`] બનાવવા માટે કરી શકાય છે.
/// એક્ઝેક્યુટર આ trait ના અમલીકરણને વ્યાખ્યાયિત કરી શકે છે, અને તેનો ઉપયોગ તે વહીવટકર્તા પર એક્ઝેક્યુટ થયેલ કાર્યોમાં પસાર થવા માટે વેકર બનાવવા માટે કરે છે.
///
/// આ trait એ [`RawWaker`] બનાવવા માટે મેમરી-સલામત અને એર્ગોનોમિક વિકલ્પ છે.
/// તે સામાન્ય વહીવટકર્તા ડિઝાઇનને સમર્થન આપે છે જેમાં કોઈ કાર્યને જાગૃત કરવા માટે વપરાયેલ ડેટા [`Arc`] માં સંગ્રહિત થાય છે.
/// કેટલાક એક્ઝેક્યુટર્સ (ખાસ કરીને એમ્બેડ કરેલા સિસ્ટમો માટેના) આ API નો ઉપયોગ કરી શકતા નથી, તેથી જ તે સિસ્ટમોના વિકલ્પ તરીકે [`RawWaker`] અસ્તિત્વમાં છે.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// મૂળભૂત `block_on` ફંક્શન કે જે fચર લે છે અને વર્તમાન થ્રેડ પર પૂર્ણ થવા માટે તેને ચલાવે છે.
///
/// **Note:** આ ઉદાહરણ સરળતા માટે યોગ્યતાનો વેપાર કરે છે.
/// ડેડલોક્સને રોકવા માટે, પ્રોડક્શન-ગ્રેડના અમલીકરણોને `thread::unpark` પર મધ્યવર્તી ક callsલ્સ તેમજ નેસ્ટેડ વિનંતીઓનું સંચાલન કરવાની જરૂર રહેશે.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// કહેવા પર વર્તમાન થ્રેડ જાગે છે તે વેકર.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// વર્તમાન થ્રેડ પર પૂર્ણ થવા માટે એક ઝેડ 0 ફ્યુચર0 ઝેડ ચલાવો.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // ઝેડ 0 ફ્યુચર0 ઝેડને પિન કરો જેથી તે પોલ કરી શકાય.
///     let mut fut = Box::pin(fut);
///
///     // ઝેડ ફ્યુચર0 ઝેડ પર પસાર થવા માટે એક નવો સંદર્ભ બનાવો.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // પૂર્ણ કરવા માટે ઝેડ ફ્યુચર0 ઝેડ ચલાવો.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// આ કાર્ય જાગો.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// વેકરનો વપરાશ કર્યા વિના આ કાર્યને જાગૃત કરો.
    ///
    /// જો વહીવટકર્તા વેકરને લીધા વિના જાગવાની સસ્તી રીતને ટેકો આપે છે, તો તેને આ પદ્ધતિને ફરીથી લખવી જોઈએ.
    /// ડિફ defaultલ્ટ રૂપે, તે ક્લોન પર [`Arc`] ને ક્લોન કરે છે અને [`wake`] ને ક callsલ કરે છે.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // સલામત: આ સલામત છે કારણ કે કાચા_વાકર સલામત રીતે બાંધકામ કરે છે
        // આર્કમાંથી એક કાચો<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: રાવવakerકર બનાવવા માટેનું આ ખાનગી ફંક્શનનો ઉપયોગ તેના કરતા થાય છે
// `From<Arc<W>> for RawWaker` એક્સની સલામતી, `From<Arc<W>> for Waker` ની સલામતી સાચી ઝેડટ્રેટ 0 ઝેડ ડિસ્પેચ પર આધારિત નથી તેની ખાતરી કરવા માટે, તેના બદલે બંને પ્રોમ્પ્લેસ આ કાર્યને સીધા અને સ્પષ્ટ રીતે કહે છે.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // તેને ક્લોન કરવા માટે આર્કની સંદર્ભ ગણતરીમાં વધારો.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake::wake ફંક્શનમાં આર્કને ખસેડીને, મૂલ્ય દ્વારા વેક
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // સંદર્ભ દ્વારા વેક, વેકરને છોડવાનું ટાળવા માટે મેન્યુઅલી ડ્રropપમાં લપેટી
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ડ્રોપ પર આર્કની સંદર્ભ ગણતરીમાં ઘટાડો
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}