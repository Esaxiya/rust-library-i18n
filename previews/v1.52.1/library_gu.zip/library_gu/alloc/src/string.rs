//! એક યુટીએફ-8 - એન્કોડ કરેલું, વિકસિત શબ્દમાળા.
//!
//! આ મોડ્યુલમાં [`String`] પ્રકાર, શબ્દમાળાઓમાં રૂપાંતરિત કરવા માટે [`ToString`] trait અને કેટલાક ભૂલ પ્રકારો છે જે [s String`] s સાથે કામ કરવાથી પરિણમી શકે છે.
//!
//!
//! # Examples
//!
//! શબ્દમાળાથી નવા [`String`] બનાવવાની ઘણી રીતો છે:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! તમે હાલનામાંથી એક સાથે એક નવી [`String`] બનાવી શકો છો
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! જો તમારી પાસે vector માન્ય UTF-8 બાઇટ્સ છે, તો તમે તેમાંથી [`String`] બનાવી શકો છો.તમે વિપરીત પણ કરી શકો છો.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // અમે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી અમે `unwrap()` નો ઉપયોગ કરીશું.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// એક યુટીએફ-8 - એન્કોડ કરેલું, વિકસિત શબ્દમાળા.
///
/// `String` પ્રકાર એ સૌથી સામાન્ય શબ્દમાળા પ્રકાર છે જેની પાસે સ્ટ્રિંગની સામગ્રી પરની માલિકી છે.તે તેના ઉધાર કાઉન્ટર પાર્ટ, આદિમ [`str`] સાથે ગા a સંબંધ ધરાવે છે.
///
/// # Examples
///
/// તમે X002 સાથે [a literal string][`str`] માંથી `String` બનાવી શકો છો:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// તમે [`push`] પદ્ધતિથી એક [`char`] ને `String` માં જોડી શકો છો, અને [`push_str`] પદ્ધતિ સાથે [`&str`] ઉમેરી શકો છો:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// જો તમારી પાસે UTF-8 બાઇટ્સનો vector છે, તો તમે તેમાંથી [`from_utf8`] પદ્ધતિથી `String` બનાવી શકો છો:
///
/// ```
/// // vector માં કેટલાક બાઇટ્સ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // અમે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી અમે `unwrap()` નો ઉપયોગ કરીશું.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `શબ્દમાળા હંમેશાં UTF-8 માન્ય હોય છે.આના કેટલાક સૂચિતાર્થ છે, જેમાંથી પ્રથમ એ છે કે જો તમને બિન-યુટીએફ-8 શબ્દમાળાની જરૂર હોય, તો [`OsString`] ને ધ્યાનમાં લો.તે સમાન છે, પરંતુ UTF-8 અવરોધ વિના.બીજો અર્થ એ છે કે તમે `String` માં અનુક્રમણિકા કરી શકતા નથી:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// અનુક્રમણિકા એ સતત-સમય કામગીરી માટે બનાવાયેલ છે, પરંતુ UTF-8 એન્કોડિંગ અમને આ કરવાની મંજૂરી આપતું નથી.તદુપરાંત, તે સ્પષ્ટ નથી કે અનુક્રમણિકા કઈ પ્રકારની વસ્તુ પરત કરવી જોઈએ: એક બાઇટ, કોડીપોઈન્ટ અથવા ગ્રાફીમ ક્લસ્ટર.
/// [`bytes`] અને [`chars`] પદ્ધતિઓ પહેલા બેથી અનુક્રમે ઇટરેટર્સને આપે છે.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `શબ્દમાળા અમલીકરણ [` ડેરેફ] `<Target=str>`, અને તેથી [`str`] ની બધી પદ્ધતિઓનો વારસો મેળવો.આ ઉપરાંત, આનો અર્થ એ છે કે તમે એક ફંક્શનમાં `String` પસાર કરી શકો છો જે એમ્પર્સન્ડ (`&`) નો ઉપયોગ કરીને [`&str`] લે છે:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// આ `String` માંથી એક [`&str`] બનાવશે અને તેમાં પ્રવેશ કરશે. આ રૂપાંતર ખૂબ સસ્તું છે, અને તેથી સામાન્ય રીતે, વિધેયો [`&str`] ને દલીલો તરીકે સ્વીકારે છે સિવાય કે તેમને કોઈ વિશિષ્ટ કારણોસર `String` ની જરૂર ન પડે.
///
/// કેટલાક કિસ્સાઓમાં, ઝેડ રસ્ટ0 ઝેડ પાસે આ રૂપાંતર કરવા માટે પૂરતી માહિતી નથી, જેને [`Deref`] જબરદસ્તી તરીકે ઓળખવામાં આવે છે.નીચેના ઉદાહરણમાં, શબ્દમાળાની સ્લાઇસ [`&'a str`][`&str`], trait `TraitExample` ને લાગુ કરે છે, અને કાર્ય `example_func` કંઈપણ લે છે જે trait ને લાગુ કરે છે.
/// આ સ્થિતિમાં, ઝેડ રસ્ટ0 ઝેડને બે ગર્ભિત રૂપાંતરણો કરવાની જરૂર પડશે, જે ઝેડ રસ્ટ0 ઝેડ પાસે કરવાનો અર્થ નથી.
/// તે કારણોસર, નીચેનું ઉદાહરણ કમ્પાઇલ કરશે નહીં.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// ત્યાં બે વિકલ્પો છે જે તેના બદલે કાર્ય કરશે.શબ્દમાળા શબ્દમાળાની સ્લાઈસ સ્પષ્ટ રીતે કાractવા માટે, [`as_str()`] પદ્ધતિનો ઉપયોગ કરીને, પ્રથમ, `example_func(&example_string);` ને `example_func(example_string.as_str());` માં બદલવાનો રહેશે.
/// બીજી રીત `example_func(&example_string);` ને `example_func(&*example_string);` માં બદલાય છે.
/// આ કિસ્સામાં અમે `String` ને [`str`][`&str`] નો સંદર્ભ આપીએ છીએ, પછી [`str`][`&str`] નો સંદર્ભ [`&str`] પર કરીએ છીએ.
/// બીજી રીત વધુ મૂર્ખામીભર્યું છે, તેમ છતાં બંને ગર્ભિત રૂપાંતર પર આધાર રાખીને સ્પષ્ટ રૂપે રૂપાંતર કરવાનું કામ કરે છે.
///
/// # Representation
///
/// એક `String` ત્રણ ઘટકોથી બનેલો છે: કેટલાક બાઇટ્સ, એક લંબાઈ અને ક્ષમતાનો નિર્દેશક.પોઇન્ટર તેના ડેટા સ્ટોર કરવા માટે આંતરિક બફર `String` નો નિર્દેશ કરે છે.લંબાઈ એ હાલમાં બફરમાં સંગ્રહિત બાઇટ્સની સંખ્યા છે, અને ક્ષમતા બાઇટ્સમાં બફરનું કદ છે.
///
/// જેમ કે, લંબાઈ હંમેશાં ક્ષમતા કરતા ઓછી અથવા તેના જેટલી હશે.
///
/// આ બફર હંમેશાં theગલા પર સંગ્રહિત થાય છે.
///
/// તમે આને [`as_ptr`], [`len`] અને [`capacity`] પદ્ધતિઓથી જોઈ શકો છો:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // જ્યારે vec_into_raw_parts સ્થિર થાય છે ત્યારે તેને ફિક્સ કરો.
/// // શબ્દમાળાના ડેટાને આપમેળે છોડતા અટકાવો
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // વાર્તામાં ઓગણીસ બાઇટ્સ છે
/// assert_eq!(19, len);
///
/// // અમે પી.ટી.આર., લેન અને ક્ષમતામાંથી સ્ટ્રીંગ ફરીથી બનાવી શકીએ છીએ.
/// // આ બધું અસુરક્ષિત છે કારણ કે ઘટકો માન્ય છે તેની ખાતરી કરવા માટે આપણે જવાબદાર છીએ:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// જો `String` ની પૂરતી ક્ષમતા હોય, તો તેમાં તત્વો ઉમેરવાથી ફરીથી ફાળવણી કરવામાં આવશે નહીં.ઉદાહરણ તરીકે, આ પ્રોગ્રામનો વિચાર કરો:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// આ નીચેનાને આઉટપુટ કરશે:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// શરૂઆતમાં, અમારી પાસે કોઈ મેમરી ફાળવવામાં આવતી નથી, પરંતુ આપણે શબ્દમાળા સાથે જોડીએ છીએ, તે તેની ક્ષમતાને યોગ્ય રીતે વધારે છે.જો આપણે શરૂઆતમાં યોગ્ય ક્ષમતા ફાળવવા માટે [`with_capacity`] પદ્ધતિનો ઉપયોગ કરીએ તો:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// અમે એક અલગ આઉટપુટ સાથે અંત:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// અહીં, લૂપની અંદર વધુ મેમરી ફાળવવાની જરૂર નથી.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 બાઇટ vector થી `String` ને રૂપાંતરિત કરતી વખતે શક્ય ભૂલ મૂલ્ય.
///
/// આ પ્રકાર એ [`String`] પરની [`from_utf8`] પદ્ધતિ માટેનો ભૂલ પ્રકાર છે.
/// પુનર્નિર્દેશોને કાળજીપૂર્વક ટાળવા માટે તે એવી રીતે બનાવવામાં આવી છે: [`into_bytes`] પદ્ધતિ બાઇટ vector પાછા આપશે જે રૂપાંતરના પ્રયાસમાં ઉપયોગમાં લેવાઈ હતી.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] દ્વારા પ્રદાન થયેલ [`Utf8Error`] પ્રકાર એ ભૂલ રજૂ કરે છે કે જે [`u8`] s ની સ્લાઈસને [`&str`] માં રૂપાંતરિત કરતી વખતે આવી શકે છે.
/// આ અર્થમાં, તે `FromUtf8Error` નું એનાલોગ છે, અને તમે [`utf8_error`] પદ્ધતિ દ્વારા `FromUtf8Error` માંથી એક મેળવી શકો છો.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// // vector માં કેટલાક અમાન્ય બાઇટ્સ
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 બાઇટ સ્લાઈસથી `String` ને રૂપાંતરિત કરતી વખતે શક્ય ભૂલ મૂલ્ય.
///
/// આ પ્રકાર એ [`String`] પરની [`from_utf16`] પદ્ધતિ માટેનો ભૂલ પ્રકાર છે.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// મૂળભૂત વપરાશ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// નવું ખાલી `String` બનાવે છે.
    ///
    /// આપેલ છે કે `String` ખાલી છે, આ કોઈ પ્રારંભિક બફર ફાળવશે નહીં.જ્યારે કે તેનો અર્થ એ કે આ પ્રારંભિક કામગીરી ખૂબ સસ્તું છે, જ્યારે તમે ડેટા ઉમેરશો ત્યારે તે વધુ પડતી ફાળવણીનું કારણ બની શકે છે.
    ///
    /// જો તમારી પાસે `String` કેટલો ડેટા ધરાવે છે તેનો ખ્યાલ છે, તો વધુ પડતી ફરીથી ફાળવણી અટકાવવા માટે [`with_capacity`] પદ્ધતિનો વિચાર કરો.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// કોઈ વિશિષ્ટ ક્ષમતા સાથે નવું ખાલી `String` બનાવે છે.
    ///
    /// `શબ્દમાળાઓ પાસે તેમના ડેટાને રાખવા માટે આંતરિક બફર હોય છે.
    /// ક્ષમતા એ બફરની લંબાઈ છે, અને [`capacity`] પદ્ધતિથી શોધી શકાય છે.
    /// આ પદ્ધતિ ખાલી `String` બનાવે છે, પરંતુ પ્રારંભિક બફર સાથેની એક જે `capacity` બાઇટ્સને પકડી શકે છે.
    /// આ ઉપયોગી છે જ્યારે તમે `String` પર ડેટાના સમૂહને ઉમેરી રહ્યા હોવ, તેને કરવાની જરૂરિયાતને ફરીથી ઘટાડવાની સંખ્યામાં ઘટાડો કરો.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// જો આપેલ ક્ષમતા `0` છે, તો કોઈ ફાળવણી થશે નહીં, અને આ પદ્ધતિ [`new`] પદ્ધતિની સમાન છે.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // તેમાં વધુ માટેની ક્ષમતા હોવા છતાં, શબ્દમાળામાં કોઈ અક્ષરો નથી
    /// assert_eq!(s.len(), 0);
    ///
    /// // આ બધું ફરીથી રજૂ કર્યા વિના કરવામાં આવે છે ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... પરંતુ આ શબ્દમાળાને ફરીથી ફેરવી શકે છે
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) સાથે અંતર્ગત `[T]::to_vec` પદ્ધતિ, જે આ પદ્ધતિની વ્યાખ્યા માટે જરૂરી છે, ઉપલબ્ધ નથી.
    // અમને પરીક્ષણના હેતુ માટે આ પદ્ધતિની જરૂર નથી, તેથી હું તેને વધુ વળતર માટે N0 ને slice.rs માં slice::hack મોડ્યુલ જોઉં છું.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// એક vector બાઇટ્સને `String` માં ફેરવે છે.
    ///
    /// એક શબ્દમાળા ([`String`]) બાઇટ્સ ([`u8`]) થી બનેલો છે, અને vector of bytes ([`Vec<u8>`]) બાઇટ્સથી બનેલો છે, તેથી આ કાર્ય બંને વચ્ચે ફેરવે છે.
    /// બધી બાઇટ કાપી નાંખ્યું માન્ય `શબ્દમાળાઓ નથી, તેમ છતાં: `String` ને આવશ્યક છે કે તે માન્ય UTF-8 છે.
    /// `from_utf8()` બાઇટ્સ માન્ય UTF-8 છે તેની ખાતરી કરવા માટે ચકાસે છે, અને પછી રૂપાંતર કરે છે.
    ///
    /// જો તમને ખાતરી છે કે બાઇટ સ્લાઈસ માન્ય UTF-8 છે, અને તમે માન્યતા તપાસોના ઓવરહેડ પર ન આવવા માંગતા હો, તો ત્યાં આ ફંક્શનનું અસુરક્ષિત સંસ્કરણ છે, [`from_utf8_unchecked`], જેવું જ વર્તન છે પણ ચેક અવગણો છે.
    ///
    ///
    /// કાર્યક્ષમતા ખાતર, આ પદ્ધતિ vector ની નકલ ન કરવાની કાળજી લેશે.
    ///
    /// જો તમને `String` ને બદલે [`&str`] ની જરૂર હોય, તો [`str::from_utf8`] ને ધ્યાનમાં લો.
    ///
    /// આ પદ્ધતિનું inંધું [`into_bytes`] છે.
    ///
    /// # Errors
    ///
    /// જો પ્રદાન કરેલા બાઇટ્સ UTF-8 કેમ નથી તે વર્ણન સાથે સ્લાઈસ UTF-8 ન હોય તો [`Err`] આપે છે.તમે જે ઝેડવેક્ટર 0 ઝેડમાં ગયા હતા તે પણ શામેલ છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક બાઇટ્સ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // અમે જાણીએ છીએ કે આ બાઇટ્સ માન્ય છે, તેથી અમે `unwrap()` નો ઉપયોગ કરીશું.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ખોટો બાઇટ્સ:
    ///
    /// ```
    /// // vector માં કેટલાક અમાન્ય બાઇટ્સ
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// આ ભૂલ સાથે તમે શું કરી શકો છો તેના પર વધુ વિગતો માટે ડ00ક્સને [`FromUtf8Error`] જુઓ.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// બાઇટ્સની સ્લાઈસને અમાન્ય અક્ષરો સહિત, શબ્દમાળામાં ફેરવે છે.
    ///
    /// સ્ટ્રિંગ્સ બાઇટ્સ ([`u8`]) થી બનેલા છે, અને બાઇટ્સ ([`&[u8]`][byteslice]) ની સ્લાઈસ બાઇટ્સથી બનેલી છે, તેથી આ ફંક્શન બંને વચ્ચે ફેરવાય છે.બધી બાઇટની કટકા માન્ય શબ્દમાળાઓ નથી, તેમ છતાં: શબ્દમાળાઓ માન્ય UTF-8 હોવા આવશ્યક છે.
    /// આ રૂપાંતર દરમિયાન, `from_utf8_lossy()` કોઈપણ અમાન્ય UTF-8 સિક્વેન્સને [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] સાથે બદલશે, જે આના જેવું લાગે છે:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// જો તમને ખાતરી છે કે બાઇટ સ્લાઇસ માન્ય UTF-8 છે, અને તમે રૂપાંતરનો ઓવરહેડ ખર્ચ કરવા માંગતા નથી, તો આ ફંક્શનનું એક અસુરક્ષિત સંસ્કરણ, [`from_utf8_unchecked`] છે, જે સમાન વર્તન ધરાવે છે પરંતુ તપાસને અવગણે છે.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// આ ફંક્શન [`Cow<'a, str>`] આપે છે.જો અમારી બાઇટની સ્લાઇસ અમાન્ય UTF-8 છે, તો પછી તમારે બદલાના અક્ષરો શામેલ કરવાની જરૂર છે, જે શબ્દમાળાના કદને બદલશે, અને તેથી, એક `String` ની જરૂર પડશે.
    /// પરંતુ જો તે પહેલાથી માન્ય UTF-8 છે, તો અમને નવી ફાળવણીની જરૂર નથી.
    /// આ રીટર્ન પ્રકાર અમને બંને કેસ નિયંત્રિત કરવાની મંજૂરી આપે છે.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક બાઇટ્સ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ખોટો બાઇટ્સ:
    ///
    /// ```
    /// // કેટલાક અમાન્ય બાઇટ્સ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// યુટીએફ-16 - એન્કોડેડ ઝેડવેવેક્ટર 0 ઝેડ X01 એક્સને એક X00 એક્સમાં ડીકોડ કરો, જો `v` માં કોઈ અમાન્ય ડેટા હોય તો [`Err`] પરત ફરવું.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // આ એકત્રિત દ્વારા થતું નથી: : <Result<_, _>> () પ્રભાવના કારણોસર.
        // FIXME: જ્યારે #48994 બંધ હોય ત્યારે ફંક્શનને ફરીથી સરળ બનાવી શકાય છે.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// [the replacement character (`U+FFFD`)][U+FFFD] સાથે અમાન્ય ડેટાને બદલીને, UTF-16 - એન્કોડેડ સ્લાઇસ `v` ને `String` માં ડીકોડ કરો.
    ///
    /// [`from_utf8_lossy`] જે [`Cow<'a, str>`] આપે છે તેનાથી વિપરીત, `from_utf16_lossy` `String` પરત આપે છે કારણ કે UTF-16 થી UTF-8 રૂપાંતરને મેમરી ફાળવણીની જરૂર છે.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// એક `String` તેના કાચા ઘટકોને વિઘટિત કરે છે.
    ///
    /// અંતર્ગત ડેટા, શબ્દમાળાની લંબાઈ (બાઇટ્સ) અને ડેટાની ફાળવેલ ક્ષમતા (બાઇટ્સ) માં કાચા નિર્દેશક પરત આપે છે.
    /// આ તે જ ક્રમમાં સમાન દલીલો છે જે [`from_raw_parts`] ની દલીલો છે.
    ///
    /// આ ફંક્શનને બોલાવ્યા પછી, કlerલર એ `String` દ્વારા અગાઉ સંચાલિત મેમરી માટે જવાબદાર છે.
    /// આ કરવાનો એકમાત્ર રસ્તો કાચા પોઇન્ટર, લંબાઈ અને ક્ષમતાને [`from_raw_parts`] ફંક્શન સાથે પાછા `String` માં રૂપાંતરિત કરવાનો છે, ડિસ્ટ્રક્ટરને ક્લિનઅપ કરવા દે છે.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// લંબાઈ, ક્ષમતા અને નિર્દેશકથી નવું `String` બનાવે છે.
    ///
    /// # Safety
    ///
    /// આ તપાસ કરવામાં ન આવે તેવા આક્રમણકારોની સંખ્યાને લીધે, તે ખૂબ જ અસુરક્ષિત છે:
    ///
    /// * `buf` પરની મેમરી પહેલા સમાન ફાળવણીકાર દ્વારા ફાળવવામાં આવી હોવી જરૂરી છે પ્રમાણભૂત પુસ્તકાલય, બરાબર 1 ની આવશ્યક ગોઠવણી સાથે.
    /// * `length` `capacity` કરતા ઓછું અથવા સમાન હોવું જરૂરી છે.
    /// * `capacity` યોગ્ય મૂલ્ય હોવું જરૂરી છે.
    /// * `buf` પરના પ્રથમ `length` બાઇટ્સને માન્ય UTF-8 હોવું જરૂરી છે.
    ///
    /// આનું ઉલ્લંઘન એ ફાળવણીકારના આંતરિક ડેટા સ્ટ્રક્ચર્સને ભ્રષ્ટ કરવા જેવી સમસ્યાઓનું કારણ બની શકે છે.
    ///
    /// `buf` ની માલિકી `String` ને અસરકારક રીતે સ્થાનાંતરિત કરવામાં આવી છે જે પછી ઇચ્છા પર પોઇન્ટર દ્વારા નિર્દેશિત મેમરીની સામગ્રીને વિકૃત, ફરીથી વિકસિત કરી શકે છે અથવા બદલી શકે છે.
    /// ખાતરી કરો કે આ કાર્યને બોલાવ્યા પછી બીજું કંઇ પોઇન્ટરનો ઉપયોગ કરશે નહીં.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // જ્યારે vec_into_raw_parts સ્થિર થાય છે ત્યારે તેને ફિક્સ કરો.
    ///     // શબ્દમાળાના ડેટાને આપમેળે છોડતા અટકાવો
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// એક ઝેડ 0 વેક્ટર 0 ઝેડ બાઇટ્સને `String` માં રૂપાંતરિત કર્યા વગર તપાસો કે શબ્દમાળામાં માન્ય UTF-8 છે.
    ///
    /// વધુ વિગતો માટે સલામત સંસ્કરણ, [`from_utf8`] જુઓ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// આ ફંક્શન અસુરક્ષિત છે કારણ કે તે તપાસતું નથી કે તેમાં પસાર કરેલા બાઇટ્સ માન્ય UTF-8 છે.
    /// જો આ અવરોધનું ઉલ્લંઘન કરવામાં આવે છે, તો તે `String` ના future વપરાશકર્તાઓ સાથે મેમરી અસંતોષપૂર્ણ સમસ્યાઓનું કારણ બની શકે છે, કારણ કે બાકીના પ્રમાણભૂત પુસ્તકાલયમાં એમ માનવામાં આવે છે કે `શબ્દમાળાઓ માન્ય UTF-8 છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક બાઇટ્સ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` ને બાઇટ vector માં ફેરવે છે.
    ///
    /// આ `String` લે છે, તેથી આપણે તેની સામગ્રીની નકલ કરવાની જરૂર નથી.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// સંપૂર્ણ `String` ધરાવતી સ્ટ્રિંગ સ્લાઈસ કાractsે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// એક `String` ને પરિવર્તનીય શબ્દમાળાના ટુકડામાં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// આ `String` ના અંતમાં આપેલ સ્ટ્રિંગ સ્લાઈસ જોડે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// આ `શબ્દમાળાની ક્ષમતા, બાઇટ્સમાં આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ખાતરી કરે છે કે આ `શબ્દમાળાની ક્ષમતા તેની લંબાઈ કરતા ઓછામાં ઓછી `additional` બાઇટ્સ મોટી છે.
    ///
    /// વારંવાર પુનરાવર્તન અટકાવવા, જો તે પસંદ કરે તો `additional` બાઇટ્સથી વધુની ક્ષમતામાં વધારો થઈ શકે છે.
    ///
    ///
    /// જો તમને આ "at least" વર્તન ન જોઈએ, તો [`reserve_exact`] પદ્ધતિ જુઓ.
    ///
    /// # Panics
    ///
    /// જો નવી ક્ષમતા [`usize`] ઓવરફ્લો થાય તો ઝેડ પanનિક્સ 0 ઝેડ.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// આ ખરેખર ક્ષમતામાં વધારો કરી શકશે નહીં:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ની લંબાઈ 2 અને ક્ષમતા 10 છે
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // આપણી પાસે પહેલેથી જ એક વધારાની 8 ક્ષમતા હોવાથી, આને બોલાવે છે ...
    /// s.reserve(8);
    ///
    /// // ... ખરેખર વધતું નથી.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ખાતરી કરે છે કે આ `સ્ટ્રિંગની ક્ષમતા તેની લંબાઈ કરતા `additional` બાઇટ્સ મોટી છે.
    ///
    /// [`reserve`] પદ્ધતિનો ઉપયોગ કરવાનું ધ્યાનમાં લો સિવાય કે તમે ફાળવણીકાર કરતા વધુ સારી રીતે જાણો છો.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// જો નવી ક્ષમતા `usize` ઓવરફ્લો થાય તો ઝેડ પanનિક્સ 0 ઝેડ.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// આ ખરેખર ક્ષમતામાં વધારો કરી શકશે નહીં:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ની લંબાઈ 2 અને ક્ષમતા 10 છે
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // આપણી પાસે પહેલેથી જ એક વધારાની 8 ક્ષમતા હોવાથી, આને બોલાવે છે ...
    /// s.reserve_exact(8);
    ///
    /// // ... ખરેખર વધતું નથી.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// આપેલ `String` માં ઓછામાં ઓછા `additional` વધુ તત્વો શામેલ કરવાની ક્ષમતા અનામત રાખવાનો પ્રયાસ કરે છે.
    /// સંગ્રહમાં વારંવાર ફેરબદલ ટાળવા માટે સંગ્રહ વધુ જગ્યા અનામત રાખી શકે છે.
    /// `reserve` ને ક callingલ કર્યા પછી, ક્ષમતા `self.len() + additional` કરતા વધારે અથવા તેની બરાબર હશે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// # Errors
    ///
    /// જો ક્ષમતા ઓવરફ્લો થાય છે, અથવા ફાળવણીકાર નિષ્ફળતાની જાણ કરે છે, તો પછી ભૂલ પાછો આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // મેમરીનું પૂર્વ-અનામત, જો આપણે ન કરી શકીએ તો બહાર નીકળી રહ્યું છે
    ///     output.try_reserve(data.len())?;
    ///
    ///     // હવે આપણે જાણીએ છીએ કે આ અમારા જટિલ કાર્યની મધ્યમાં OOM ન કરી શકે
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// આપેલ `String` માં બરાબર `additional` વધુ તત્વો શામેલ કરવાની ન્યૂનતમ ક્ષમતા અનામત રાખવાનો પ્રયાસ કરે છે.
    ///
    /// `reserve_exact` ને ક callingલ કર્યા પછી, ક્ષમતા `self.len() + additional` કરતા વધારે અથવા તેની બરાબર હશે.
    /// જો ક્ષમતા પહેલેથી જ પૂરતી છે તો કંઇ કરતું નથી.
    ///
    /// નોંધ કરો કે ફાળવણીકાર વિનંતી કરતા સંગ્રહને વધુ જગ્યા આપી શકે છે.
    /// તેથી, ક્ષમતા ચોક્કસપણે ન્યૂનતમ હોવા પર વિશ્વાસ કરી શકાતી નથી.
    /// જો ઝેડ ફ્યુચર0 ઝેડ નિવેશની અપેક્ષા હોય તો `reserve` ને પ્રાધાન્ય આપો.
    ///
    /// # Errors
    ///
    /// જો ક્ષમતા ઓવરફ્લો થાય છે, અથવા ફાળવણીકાર નિષ્ફળતાની જાણ કરે છે, તો પછી ભૂલ પાછો આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // મેમરીનું પૂર્વ-અનામત, જો આપણે ન કરી શકીએ તો બહાર નીકળી રહ્યું છે
    ///     output.try_reserve(data.len())?;
    ///
    ///     // હવે આપણે જાણીએ છીએ કે આ અમારા જટિલ કાર્યની મધ્યમાં OOM ન કરી શકે
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// તેની લંબાઈને મેચ કરવા માટે આ `String` ની ક્ષમતાને સંકોચો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// નીચા બાઉન્ડ સાથે આ `String` ની ક્ષમતાને સંકોચો.
    ///
    /// ક્ષમતા ઓછામાં ઓછી લંબાઈ અને સપ્લાય કરેલ મૂલ્ય બંને જેટલી મોટી રહેશે.
    ///
    ///
    /// જો વર્તમાન ક્ષમતા નીચલી મર્યાદા કરતા ઓછી હોય, તો આ નો-opપ છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// આપેલ [`char`] ને આ `String` ના અંતમાં જોડે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// આ `સ્ટ્રિંગ`ની સામગ્રીની બાઇટ સ્લાઇસ આપે છે.
    ///
    /// આ પદ્ધતિનું inંધું [`from_utf8`] છે.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// આ `String` ને નિર્દિષ્ટ લંબાઈ સુધી ટૂંકી કરે છે.
    ///
    /// જો `new_len` એ શબ્દમાળાની વર્તમાન લંબાઈ કરતા વધારે છે, તો તેની કોઈ અસર થશે નહીં.
    ///
    ///
    /// નોંધો કે આ પદ્ધતિની શબ્દમાળાઓની ફાળવેલ ક્ષમતા પર કોઈ અસર નથી
    ///
    /// # Panics
    ///
    /// Panics જો `new_len` [`char`] બાઉન્ડ્રી પર ન આવે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// શબ્દમાળા બફરમાંથી છેલ્લું પાત્ર દૂર કરે છે અને તેને પાછું આપે છે.
    ///
    /// જો આ `String` ખાલી હોય તો [`None`] આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// આ `String` માંથી બાઇટ સ્થિતિ પર એક [`char`] દૂર કરે છે અને તેને પાછું આપે છે.
    ///
    /// આ એક *O*(*n*) isપરેશન છે, કારણ કે તેને બફરમાં દરેક ઘટકની નકલ કરવાની જરૂર છે.
    ///
    /// # Panics
    ///
    /// Panics જો `idx` એ `સ્ટ્રિંગ lengthની લંબાઈ કરતા મોટી અથવા બરાબર છે, અથવા જો તે [`char`] બાઉન્ડરી પર નથી.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` માં પેટર્ન `pat` ની બધી મેચોને દૂર કરો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// મેચોને પુનરાવર્તિત રીતે શોધી કા andીને દૂર કરવામાં આવશે, તેથી દાખલાઓ જ્યારે ઓવરલેપ થાય છે, ફક્ત પ્રથમ પેટર્ન જ દૂર કરવામાં આવશે:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // સલામતી: પ્રારંભ અને અંત પ્રતિ utf8 બાઇટ સીમાઓ પર હશે
        // શોધનાર ડ docક્સ
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// પૂર્વાનુમાન દ્વારા ઉલ્લેખિત ફક્ત અક્ષરો જ જાળવી રાખે છે.
    ///
    /// બીજા શબ્દોમાં કહીએ તો, બધા અક્ષરો `c` ને દૂર કરો જેમ કે `f(c)` `false` આપે છે.
    /// આ પદ્ધતિ સ્થાને કાર્ય કરે છે, દરેક અક્ષરની મૂળ ક્રમમાં બરાબર એક વખત મુલાકાત લે છે, અને જાળવેલ અક્ષરોનો ક્રમ સાચવે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// બાહ્ય સ્થિતિને અનુક્રમણિકાની જેમ ટ્રckingક કરવા માટે ચોક્કસ હુકમ ઉપયોગી થઈ શકે છે.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // આગલા ચાર પર આઇડીએક્સ દર્શાવો
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// આ `String` માં બાઇટ પોઝિશન પર એક પાત્ર દાખલ કરો.
    ///
    /// આ એક *O*(*n*) isપરેશન છે કારણ કે તેને બફરમાં દરેક ઘટકની નકલ કરવાની જરૂર છે.
    ///
    /// # Panics
    ///
    /// Panics જો `idx` `સ્ટ્રિંગ`ની લંબાઈ કરતા મોટી હોય અથવા જો તે [`char`] સીમા પર ન આવે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// બાઇટ પોઝિશન પર આ `String` માં સ્ટ્રિંગ સ્લાઈસ દાખલ કરે છે.
    ///
    /// આ એક *O*(*n*) isપરેશન છે કારણ કે તેને બફરમાં દરેક ઘટકની નકલ કરવાની જરૂર છે.
    ///
    /// # Panics
    ///
    /// Panics જો `idx` `સ્ટ્રિંગ`ની લંબાઈ કરતા મોટી હોય અથવા જો તે [`char`] સીમા પર ન આવે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// આ `String` ની સામગ્રીનો પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// # Safety
    ///
    /// આ ફંક્શન અસુરક્ષિત છે કારણ કે તે તપાસતું નથી કે તેમાં પસાર કરેલા બાઇટ્સ માન્ય UTF-8 છે.
    /// જો આ અવરોધનું ઉલ્લંઘન કરવામાં આવે છે, તો તે `String` ના future વપરાશકર્તાઓ સાથે મેમરી અસંતોષપૂર્ણ સમસ્યાઓનું કારણ બની શકે છે, કારણ કે બાકીના પ્રમાણભૂત પુસ્તકાલયમાં એમ માનવામાં આવે છે કે `શબ્દમાળાઓ માન્ય UTF-8 છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// આ `String` ની લંબાઈ, બાઇટ્સમાં, [`ચર્]] અથવા ગ્રાફિમ્સ નહીં, પરત કરે છે.
    /// બીજા શબ્દોમાં કહીએ તો, તે શબ્દ તે નથી હોતું જે માણસ શબ્દમાળાની લંબાઈને ધ્યાનમાં લે છે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// જો આ `String` ની શૂન્યની લંબાઈ હોય, અને અન્યથા `false`, `true` આપે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// આપેલ બાઇટ ઇન્ડેક્સ પર શબ્દમાળાને બે ભાગમાં વહેંચે છે.
    ///
    /// નવી ફાળવેલ `String` પરત કરે છે.
    /// `self` બાઇટ્સ `[0, at)`, અને પરત `String` માં બાઇટ્સ `[at, len)` શામેલ છે.
    /// `at` UTF-8 કોડ પોઇન્ટની સીમા પર હોવું આવશ્યક છે.
    ///
    /// નોંધ લો કે `self` ની ક્ષમતા બદલાતી નથી.
    ///
    /// # Panics
    ///
    /// Panics જો `at` એ `UTF-8` કોડ પોઇન્ટ સીમા પર નથી, અથવા જો તે શબ્દમાળાના છેલ્લા કોડ પોઇન્ટથી આગળ છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// બધી સામગ્રીને દૂર કરીને, આ `String` કાunી નાખે છે.
    ///
    /// જ્યારે આનો અર્થ છે કે `String` ની લંબાઈ શૂન્ય હશે, તે તેની ક્ષમતાને સ્પર્શતો નથી.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// ડ્રેઇનિંગ ઇટરેટર બનાવે છે જે `String` માં નિર્દિષ્ટ શ્રેણીને દૂર કરે છે અને દૂર કરેલી `chars` આપે છે.
    ///
    ///
    /// Note: તત્વ શ્રેણી દૂર કરવામાં આવે છે જો ઇટરેટર અંત સુધી પીવામાં ન આવે તો પણ.
    ///
    /// # Panics
    ///
    /// ઝેડ પanનિક્સ 0 ઝેડ જો પ્રારંભિક બિંદુ અથવા અંતિમ બિંદુ કોઈ [`char`] સીમા પર ન આવે, અથવા જો તે મર્યાદાથી બહાર હોય તો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // સ્ટ્રિંગથી β સુધી રેન્જને દૂર કરો
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // સંપૂર્ણ શ્રેણી શબ્દમાળાને સાફ કરે છે
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // મેમરી સલામતી
        //
        // Drain ના શબ્દમાળા સંસ્કરણમાં vector સંસ્કરણની મેમરી સલામતી સમસ્યાઓ નથી.
        // ડેટા ફક્ત સાદા બાઇટ્સ છે.
        // કારણ કે રેન્જ રિમૂવલ ડ્રropપમાં થાય છે, જો ઝેડડ્રેન 0 ઝેડ ઇટરેટર લીક થાય છે, તો તે દૂર થતું નથી.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // એક સાથે બે bણ લો.
        // ડ્રropપમાં, પુનરાવર્તન પૂર્ણ થાય ત્યાં સુધી &mut શબ્દમાળા .ક્સેસ કરવામાં આવશે નહીં.
        let self_ptr = self as *mut _;
        // સલામતી: `slice::range` અને `is_char_boundary` યોગ્ય બાઉન્ડ્સ તપાસ કરે છે.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// શબ્દમાળામાં નિર્દિષ્ટ શ્રેણીને દૂર કરે છે, અને આપેલ શબ્દમાળાથી તેને બદલી દે છે.
    /// આપેલ શબ્દમાળાની શ્રેણી જેટલી લંબાઈ હોવી જરૂરી નથી.
    ///
    /// # Panics
    ///
    /// ઝેડ પanનિક્સ 0 ઝેડ જો પ્રારંભિક બિંદુ અથવા અંતિમ બિંદુ કોઈ [`char`] સીમા પર ન આવે, અથવા જો તે મર્યાદાથી બહાર હોય તો.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // સ્ટ્રિંગથી until સુધી શ્રેણી બદલો
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // મેમરી સલામતી
        //
        // બદલો_આરેન્જમાં vector Splice ના મેમરી સલામતીના પ્રશ્નો નથી.
        // vector સંસ્કરણનું.ડેટા ફક્ત સાદા બાઇટ્સ છે.

        // ચેતવણી: આ ચલને જોડવું એ અનબાઉન્ડ (#81138) હશે
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ચેતવણી: આ ચલને જોડવું એ અનબાઉન્ડ (#81138) હશે
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ફરીથી `range` નો ઉપયોગ કરવો એ અવાસ્તવિક (#81138) હશે અમે એમ માનીએ છીએ કે `range` દ્વારા નોંધાયેલ સીમાઓ સમાન રહેશે, પરંતુ વિરોધી અમલ કોલ્સ વચ્ચે બદલાઈ શકે છે
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// આ `String` ને [`Box`]`<`[`str`] `>` માં રૂપાંતરિત કરે છે.
    ///
    /// આ કોઈપણ વધારાની ક્ષમતામાં ઘટાડો કરશે.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// [`U8`] ના બાઇટ્સની સ્લાઇસ પરત કરે છે જેને `String` માં રૂપાંતરિત કરવાનો પ્રયાસ કરવામાં આવ્યો હતો.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક અમાન્ય બાઇટ્સ
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` માં રૂપાંતરિત કરવાનો પ્રયાસ કરાયેલા બાઇટ્સ પરત આપે છે.
    ///
    /// ફાળવણી ટાળવા માટે આ પદ્ધતિ કાળજીપૂર્વક બનાવવામાં આવી છે.
    /// તે ભૂલનો ઉપયોગ કરશે, બાઇટ્સને બહાર કા .શે, જેથી બાઇટ્સની નકલ કરવાની જરૂર ન પડે.
    ///
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક અમાન્ય બાઇટ્સ
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// રૂપાંતર નિષ્ફળતા વિશે વધુ વિગતો મેળવવા માટે એક `Utf8Error` મેળવો.
    ///
    /// [`std::str`] દ્વારા પ્રદાન થયેલ [`Utf8Error`] પ્રકાર એ ભૂલ રજૂ કરે છે કે જે [`u8`] s ની સ્લાઈસને [`&str`] માં રૂપાંતરિત કરતી વખતે આવી શકે છે.
    /// આ અર્થમાં, તે `FromUtf8Error` નું એનાલોગ છે.
    /// તેનો ઉપયોગ કરવા પર વધુ વિગતો માટે તેના દસ્તાવેજીકરણ જુઓ.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// // vector માં કેટલાક અમાન્ય બાઇટ્સ
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // પ્રથમ બાઇટ અહીં અમાન્ય છે
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // કારણ કે આપણે `શબ્દમાળાઓ પર પુનરાવર્તન કરી રહ્યાં છીએ, તેથી આપણે પુનરાવર્તક તરફથી પ્રથમ શબ્દમાળા મેળવીને અને પછીના બધા શબ્દમાળાઓ ઉમેરીને ઓછામાં ઓછા એક ફાળવણીને ટાળી શકીએ છીએ.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // કારણ કે આપણે CoWs પર પુનરાવર્તન કરીએ છીએ, અમે (potentially) પ્રથમ વસ્તુ મેળવીને અને ત્યારબાદની બધી વસ્તુઓ ઉમેરીને ઓછામાં ઓછા એક ફાળવણીને ટાળી શકીએ છીએ.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// એક સગવડ પ્રોમ્પ્લ જે `&str` માટે પ્રોમ્પ્ટ કરે છે.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ખાલી `String` બનાવે છે.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// બે શબ્દમાળાઓ જોડવા માટે `+` operatorપરેટરને અમલમાં મૂકે છે.
///
/// આ ડાબી બાજુએ `String` લે છે અને તેના બફરનો ફરીથી ઉપયોગ કરે છે (જો જરૂરી હોય તો તેને વધારી રહ્યા છે).
/// નવું `String` ફાળવવાનું ટાળવું અને દરેક operationપરેશન પરની સંપૂર્ણ સામગ્રીની કyingપિ ટાળવા માટે આ કરવામાં આવે છે, જે *ઓ*(*n*^ 2) ને પુનરાવર્તિત કન્ટેન્ટેશન દ્વારા *એન*-બાઇટ શબ્દમાળા બનાવતી વખતે ચાલતા સમય તરફ દોરી જાય છે.
///
///
/// જમણી બાજુની તાર ફક્ત ઉધાર લેવામાં આવે છે;તેના સમાવિષ્ટો પરત `String` માં ક areપિ થયેલ છે.
///
/// # Examples
///
/// બે `શબ્દમાળાઓ પર ધ્યાન આપવું એ પ્રથમ મૂલ્ય દ્વારા લે છે અને બીજું ઉધાર લે છે:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ખસેડવામાં આવ્યું છે અને હવે તેનો ઉપયોગ અહીં થઈ શકશે નહીં.
/// ```
///
/// જો તમે પ્રથમ `String` નો ઉપયોગ કરવાનું ચાલુ રાખવા માંગતા હો, તો તમે તેને ક્લોન કરી શકો છો અને ક્લોનને બદલે ઉમેરી શકો છો:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` અહીં હજુ પણ માન્ય છે.
/// ```
///
/// `&str` કાપી નાંખ્યું પ્રથમ `String` માં રૂપાંતર કરીને કરી શકાય છે:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` માં ઉમેરવા માટે `+=` operatorપરેટરને અમલમાં મૂકે છે.
///
/// આ [`push_str`][String::push_str] પદ્ધતિ જેવી જ વર્તણૂક ધરાવે છે.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] માટેનો એક પ્રકાર ઉપનામ.
///
/// આ ઉપનામ પાછળની સુસંગતતા માટે અસ્તિત્વમાં છે, અને આખરે અવમૂલ્યન થઈ શકે છે.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// `String` માં મૂલ્યને રૂપાંતરિત કરવા માટે એક trait.
///
/// આ trait એ [`Display`] trait ને લાગુ કરનારા કોઈપણ પ્રકાર માટે આપમેળે અમલમાં મૂકવામાં આવે છે.
/// જેમ કે, `ToString` સીધા અમલમાં મૂકવા જોઈએ નહીં:
/// [`Display`] તેના બદલે અમલ થવો જોઈએ, અને તમને મફતમાં `ToString` અમલીકરણ મળશે.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// આપેલ મૂલ્યને `String` માં ફેરવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// આ અમલીકરણમાં, જો `Display` અમલીકરણમાં ભૂલ આપે છે, તો `to_string` પદ્ધતિ panics.
/// આ એક ખોટી `Display` અમલીકરણ સૂચવે છે કારણ કે `fmt::Write for String` ક્યારેય ભૂલને પાછો આપતો નથી.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // સામાન્ય માર્ગદર્શિકા એ સામાન્ય કાર્યોને ઇનલાઇન ન કરવી તે છે.
    // જો કે, આ પદ્ધતિથી `#[inline]` ને દૂર કરવાથી બિન-ઉપેક્ષિત રેગ્રેશન થાય છે.
    // તેને દૂર કરવાનો પ્રયાસ કરવાનો છેલ્લો પ્રયાસ, <https://github.com/rust-lang/rust/pull/74852> જુઓ.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` ને `String` માં ફેરવે છે.
    ///
    /// પરિણામ allocatedગલા પર ફાળવવામાં આવે છે.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: પરીક્ષણ લિબસ્ટેડમાં ખેંચે છે, જે અહીં ભૂલોનું કારણ બને છે
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// આપેલ બ boxક્સ્ડ `str` સ્લાઈસને `String` માં રૂપાંતરિત કરે છે.
    /// તે નોંધનીય છે કે `str` સ્લાઇસની માલિકી છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// આપેલ `String` ને માલિકીની બedક્સવાળી `str` સ્લાઇસમાં રૂપાંતરિત કરે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// શબ્દમાળાની ટુકડીને ઉધાર આપેલા ચલમાં ફેરવે છે.
    /// કોઈ apગલો ફાળવણી કરવામાં આવતી નથી, અને શબ્દમાળાની કiedપિ કરવામાં આવતી નથી.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// એક શબ્દમાળાને માલિકીના પ્રકારમાં ફેરવે છે.
    /// કોઈ apગલો ફાળવણી કરવામાં આવતી નથી, અને શબ્દમાળાની કiedપિ કરવામાં આવતી નથી.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// એક શબ્દમાળા સંદર્ભને ઉછીના ચલમાં ફેરવે છે.
    /// કોઈ apગલો ફાળવણી કરવામાં આવતી નથી, અને શબ્દમાળાની કiedપિ કરવામાં આવતી નથી.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// આપેલ `String` ને vector `Vec` માં રૂપાંતરિત કરે છે જે `u8` પ્રકારનાં મૂલ્યો ધરાવે છે.
    ///
    /// # Examples
    ///
    /// મૂળભૂત વપરાશ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` માટે ડ્રેઇનિંગ ઇટરેટર.
///
/// આ સ્ટ્રક્ટ [`String`] પર [`String`] મેથડ દ્વારા બનાવવામાં આવી છે.
/// વધુ માટે તેના દસ્તાવેજીકરણ જુઓ.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ડિસ્ટ્રક્ટરમાં&'મ્યુટ સ્ટ્રિંગ' તરીકે ઉપયોગમાં લેવામાં આવશે
    string: *mut String,
    /// ભાગની શરૂઆત દૂર કરવા માટે
    start: usize,
    /// ભાગનો અંત
    end: usize,
    /// દૂર કરવા માટે વર્તમાન બાકી રેન્જ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain નો ઉપયોગ કરો.
            // "Reaffirm" panic કોડ ફરીથી દાખલ કરવામાં આવે તે ટાળવા માટે બાઉન્ડ્સ તપાસ કરે છે.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// આ પુનરાવર્તકની બાકીની (પેટા) શબ્દમાળાને સ્લાઇસ તરીકે આપે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: જ્યારે સ્થિર થાય ત્યારે અસફળ AsRef નીચે ઉતરે છે.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ને સ્થિર કરતી વખતે અન-ટિપ્પણી.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for માટે
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ઝેડ 0 ડ્રેન0 ઝેડ <'એ> n એફએન as_ref(&self)-> અને [u8] for માટે <<aA AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}