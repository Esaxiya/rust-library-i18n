#![stable(feature = "rust1", since = "1.0.0")]

//! થ્રેડ-સુરક્ષિત સંદર્ભ-ગણતરીના નિર્દેશકો.
//!
//! વધુ વિગતો માટે [`Arc<T>`][Arc] દસ્તાવેજીકરણ જુઓ.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// સંદર્ભોની માત્રા પર નરમ મર્યાદા જે `Arc` પર કરવામાં આવી શકે છે.
///
/// આ મર્યાદાથી ઉપર જવાથી _exactly_ `MAX_REFCOUNT + 1` સંદર્ભો પર તમારા પ્રોગ્રામ (જો કે જરૂરી નથી) રદબાતલ થશે.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// થ્રેડસેનિટાઈઝર મેમરી વાડને સપોર્ટ કરતું નથી.
// આર્ક/નબળા અમલીકરણમાં ખોટા સકારાત્મક અહેવાલોને ટાળવા માટે તેના બદલે સુમેળ માટે અણુ લોડનો ઉપયોગ કરો.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// એક થ્રેડ-સુરક્ષિત સંદર્ભ-ગણતરી નિર્દેશક.'Arc' એટલે 'એટોમિકલી રેફરન્સ કાઉન્ટટેડ'.
///
/// પ્રકાર `Arc<T>`, Xગલામાં ફાળવવામાં આવેલા પ્રકાર `T` ની કિંમતની વહેંચાયેલ માલિકી પ્રદાન કરે છે.`Arc` પર [`clone`][clone] ને ઇન્વોક કરવું એ એક નવું `Arc` દાખલો ઉત્પન્ન કરે છે, જે સંદર્ભ ગણતરીમાં વધારો કરતી વખતે સ્રોત `Arc` જેવા asગલા પર સમાન ફાળવણી તરફ નિર્દેશ કરે છે.
/// જ્યારે આપેલ ફાળવણીનો છેલ્લો `Arc` પોઇન્ટર નાશ પામે છે, ત્યારે તે ફાળવણીમાં સંગ્રહિત મૂલ્ય (ઘણીવાર "inner value" તરીકે ઓળખાય છે) પણ છોડી દેવામાં આવે છે.
///
/// ઝેડ રસ્ટ0 ઝેડમાં શેર કરેલા સંદર્ભો ડિફ defaultલ્ટ રૂપે પરિવર્તનને મંજૂરી આપતા નથી, અને એક્સ04 એક્સ પણ તેનો અપવાદ નથી: તમે સામાન્ય રીતે `Arc` ની અંદરની કોઈ બાબતે પરિવર્તનશીલ સંદર્ભ મેળવી શકતા નથી.જો તમારે `Arc` દ્વારા પરિવર્તન કરવાની જરૂર હોય, તો [`Mutex`][mutex], [`RwLock`][rwlock] અથવા [`Atomic`][atomic] પ્રકારોમાંથી એકનો ઉપયોગ કરો.
///
/// ## થ્રેડ સલામતી
///
/// [`Rc<T>`] થી વિપરીત, `Arc<T>` તેની સંદર્ભ ગણતરી માટે અણુ ક્રિયાઓનો ઉપયોગ કરે છે.આનો અર્થ એ કે તે થ્રેડ-સલામત છે.ગેરલાભ એ છે કે સામાન્ય મેમરી thanક્સેસ કરતા અણુ ક્રિયાઓ વધુ ખર્ચાળ હોય છે.જો તમે થ્રેડો વચ્ચે સંદર્ભ-ગણતરીની ફાળવણી શેર કરી રહ્યાં નથી, તો નીચલા ઓવરહેડ માટે [`Rc<T>`] નો ઉપયોગ કરવાનું ધ્યાનમાં લો.
/// [`Rc<T>`] સલામત ડિફ defaultલ્ટ છે, કારણ કે કમ્પાઇલર થ્રેડો વચ્ચે [`Rc<T>`] મોકલવાના કોઈપણ પ્રયાસને પકડશે.
/// જો કે, લાઇબ્રેરી, પુસ્તકાલયના ગ્રાહકોને વધુ સુગમતા આપવા માટે, `Arc<T>` પસંદ કરી શકે છે.
///
/// `Arc<T>` [`Send`] અને [`Sync`] લાગુ કરશે ત્યાં સુધી `T` [`Send`] અને [`Sync`] ને લાગુ કરે છે.
/// તેને થ્રેડ-સલામત બનાવવા માટે તમે `T` માં નોન-થ્રેડ-સલામત પ્રકાર `T` કેમ મૂકી શકતા નથી?આ પ્રથમ થોડો પ્રતિ-સાહજિક હોઈ શકે છે: છેવટે, `Arc<T>` થ્રેડ સલામતીનો મુદ્દો નથી?કી આ છે: `Arc<T>` સમાન ડેટાની બહુવિધ માલિકી રાખવા માટે તેને થ્રેડ સુરક્ષિત બનાવે છે, પરંતુ તે તેના ડેટામાં થ્રેડ સલામતી ઉમેરતી નથી.
///
/// `આર્ક <` [`રેફસેલ ધ્યાનમાં લો<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] નથી અને જો `Arc<T>` હંમેશાં [`Send`] હોત, `આર્ક <` [`રેફસેલ<T>`]`>`પણ હશે.
/// પરંતુ તે પછી અમારી પાસે સમસ્યા છે:
/// [`RefCell<T>`] થ્રેડ સલામત નથી;તે બિન-અણુ operationsપરેશંસનો ઉપયોગ કરીને ઉધારની ગણતરી પર નજર રાખે છે.
///
/// અંતમાં, આનો અર્થ એ કે તમારે `Arc<T>` ને અમુક પ્રકારના [`std::sync`] પ્રકાર સાથે જોડવાની જરૂર પડી શકે છે, સામાન્ય રીતે [`Mutex<T>`][mutex].
///
/// ## `Weak` સાથે ચક્ર તોડવું
///
/// [`downgrade`][downgrade] પદ્ધતિ નોન-માલિકીનો [`Weak`] પોઇન્ટર બનાવવા માટે વાપરી શકાય છે.એક [`Weak`] નિર્દેશક એક `Arc` પર [`અપગ્રેડ`][અપગ્રેડ] ડી હોઈ શકે છે, પરંતુ જો ફાળવણીમાં સંગ્રહિત મૂલ્ય પહેલાથી જ છોડી દેવામાં આવી હોય તો આ [`None`] પરત કરશે.
/// બીજા શબ્દોમાં કહીએ તો, `Weak` પોઇન્ટર ફાળવણીની અંદરના મૂલ્યને જીવંત રાખતા નથી;જો કે, તેઓ ફાળવણી (મૂલ્ય માટેનો બેકિંગ સ્ટોર) જીવંત રાખે છે.
///
/// `Arc` પોઇંટર્સ વચ્ચેનું એક ચક્ર ક્યારેય વિલંબિત થશે નહીં.
/// આ કારણોસર, [`Weak`] નો ઉપયોગ ચક્રને તોડવા માટે થાય છે.ઉદાહરણ તરીકે, એક ઝાડમાં માતાપિતા ગાંઠોથી બાળકોમાં મજબૂત `Arc` પોઇન્ટર અને બાળકોથી તેમના માતાપિતા સુધીના [`Weak`] પોઇન્ટર હોઈ શકે છે.
///
/// # ક્લોનીંગ સંદર્ભો
///
/// અસ્તિત્વમાં રહેલા સંદર્ભ-ગણતરીના નિર્દેશકથી નવું સંદર્ભ બનાવવું એ [`Arc<T>`][Arc] અને [`Weak<T>`][Weak] માટે લાગુ `Clone` trait નો ઉપયોગ કરીને કરવામાં આવે છે.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // નીચે બે વાક્યરચના સમાન છે.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, અને foo એ બધા આર્ક્સ છે જે સમાન મેમરી સ્થાન પર નિર્દેશ કરે છે
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` આપમેળે `T` ([`Deref`][deref] trait દ્વારા) નો સંદર્ભ લો, જેથી તમે `Arc<T>` પ્રકારનાં મૂલ્ય પર `T` ની પદ્ધતિઓને ક callલ કરી શકો.`T` ની પદ્ધતિઓ સાથે નામના ક્લેશને ટાળવા માટે, `Arc<T>` ની પદ્ધતિઓ પોતે જ સંબંધિત કાર્યો છે, જેને [fully qualified syntax] નો ઉપયોગ કરીને કહેવામાં આવે છે:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `આર્ક<T>`Clone` જેવા traits ના અમલીકરણોને સંપૂર્ણ ગુણવત્તાવાળું સિન્ટેક્સનો ઉપયોગ કરીને પણ કહી શકાય.
/// કેટલાક લોકો સંપૂર્ણ રીતે લાયક સિન્ટેક્સનો ઉપયોગ કરવાનું પસંદ કરે છે, જ્યારે અન્ય મેથડ-ક callલ સિન્ટેક્સનો ઉપયોગ કરવાનું પસંદ કરે છે.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // પદ્ધતિ-ક callલ વાક્યરચના
/// let arc2 = arc.clone();
/// // સંપૂર્ણ રીતે લાયક વાક્યરચના
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` નો સ્વચાલિત સંદર્ભ લેતો નથી, કારણ કે આંતરિક મૂલ્ય પહેલાથી જ છોડી દેવામાં આવ્યું છે.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// થ્રેડો વચ્ચે કેટલાક બદલી ન શકાય તેવા ડેટા શેર કરી રહ્યાં છે:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// નોંધ લો કે આપણે અહીં * * પરીક્ષણો ** ચલાવતા નથી.
// જો કોઈ થ્રેડ મુખ્ય થ્રેડને આઉટલેવ કરે અને તે જ સમયે (કંઈક ડેડલોક્સ) બહાર નીકળી જાય તો windows બિલ્ડરો ખૂબ નાખુશ થાય છે, તેથી અમે ફક્ત આ પરીક્ષણો ન ચલાવીને આને સંપૂર્ણપણે ટાળીએ છીએ.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// પરિવર્તનશીલ [`AtomicUsize`] શેર કરી રહ્યું છે:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// સામાન્ય રીતે સંદર્ભ ગણતરીના વધુ ઉદાહરણો માટે [`rc` documentation][rc_examples] જુઓ.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] નું એક સંસ્કરણ છે જે વ્યવસ્થાપિત ફાળવણીનો બિન-માલિકીનો સંદર્ભ ધરાવે છે.
/// `Weak` પોઇન્ટર પર [`upgrade`] ને ક callingલ કરીને ફાળવણી isક્સેસ કરી શકાય છે, જે [`વિકલ્પ`] returns <`[`આર્ક]`આપે છે<T>>`.
///
/// `Weak` સંદર્ભ માલિકી તરફની ગણતરી કરતું નથી, તેથી તે ફાળવણીમાં સંગ્રહિત મૂલ્યને ઘટાડતા અટકાવશે નહીં, અને X01 એક્સ પોતે પણ હજી પણ હાજર હોવાના મૂલ્ય વિશે કોઈ બાંયધરી આપતું નથી.
///
/// જ્યારે તે [`અપગ્રેડ`] ડી.
/// જોકે નોંધ લો કે એક `Weak` સંદર્ભ *કરે છે* ફાળવણીની જાતે જ (બેકિંગ સ્ટોર) અવમૂલ્યન થવાથી અટકાવે છે.
///
/// એક `Weak` નિર્દેશક [`Arc`] દ્વારા સંચાલિત ફાળવણીના અસ્થાયી સંદર્ભને રાખવા માટે તેના આંતરિક મૂલ્યને ઘટાડતા અટકાવ્યા વિના ઉપયોગી છે.
/// [`Arc`] પોઇન્ટર વચ્ચેના પરિપત્ર સંદર્ભોને રોકવા માટે પણ તેનો ઉપયોગ થાય છે, કારણ કે પરસ્પર માલિકીનાં સંદર્ભો ક્યારેય [`Arc`] ને ક્યાંય છોડવા દેતા નથી.
/// ઉદાહરણ તરીકે, એક ઝાડમાં માતાપિતા ગાંઠોથી બાળકોમાં મજબૂત [`Arc`] પોઇંટર્સ, અને બાળકોથી તેમના માતાપિતા સુધીના `Weak` પોઇન્ટર હોઈ શકે છે.
///
/// `Weak` પોઇન્ટર મેળવવા માટેની લાક્ષણિક રીત, [`Arc::downgrade`] ને ક callલ કરવો.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // આ પ્રકારનું કદ enપ્ટિમાઇઝ કરવા માટે, ઇંગ્સમાં આ એક `NonNull` છે, પરંતુ તે આવશ્યક પોઇન્ટર નથી.
    //
    // `Weak::new` આને `usize::MAX` પર સેટ કરે છે જેથી તેને apગલા પર સ્થાન ફાળવવાની જરૂર ન પડે.
    // તે મૂલ્ય ક્યારેય નથી જે વાસ્તવિક નિર્દેશક પાસે હશે કારણ કે આરસીબોક્સમાં ઓછામાં ઓછું 2 ગોઠવણી છે.
    // આ ફક્ત ત્યારે જ શક્ય છે જ્યારે `T: Sized`;અસૂચિત `T` ક્યારેય ઝૂલતું નથી.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// સંભવિત ફીલ્ડ-ordર્ડરિંગ સામે આ repr(C) થી ઝેડ ફ્યુચર0 ઝેડ-પ્રૂફ છે, જે ટ્રાન્સમ્યુટેબલ આંતરિક પ્રકારનાં સલામત [into|from]_raw() સાથે દખલ કરશે.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX મૂલ્ય અસ્થાયી રૂપે "locking" માટે સેન્ટિનલ તરીકે કાર્ય કરે છે નબળા પોઇંટર્સને અપગ્રેડ કરવાની ક્ષમતા અથવા ડાઉનગ્રેડ મજબૂત લોકો;`make_mut` અને `get_mut` માં રેસ ટાળવા માટે આનો ઉપયોગ થાય છે.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// નવું `Arc<T>` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // નબળા નિર્દેશક ગણતરીને 1 તરીકે પ્રારંભ કરો જે નબળા નિર્દેશક છે જે બધા મજબૂત પોઇંટર્સ (kinda) દ્વારા ધરાવે છે, વધુ માહિતી માટે std/rc.rs જુઓ
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// પોતાનામાં નબળા સંદર્ભનો ઉપયોગ કરીને નવું `Arc<T>` બનાવે છે.
    /// આ ફંક્શન વળતર પહેલાં નબળા સંદર્ભને અપગ્રેડ કરવાનો પ્રયાસ કરવાથી `None` મૂલ્ય મળશે.
    /// જો કે, નબળા સંદર્ભને મુક્તપણે ક્લોન કરી શકાય છે અને પછીના સમયમાં ઉપયોગ માટે સંગ્રહિત કરી શકાય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // એકલા નબળા સંદર્ભ સાથે "uninitialized" સ્થિતિમાં આંતરિક બનાવો.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // તે મહત્વનું છે કે આપણે નબળા નિર્દેશકની માલિકી છોડીશું નહીં, નહીં તો `data_fn` રીટર્ન થાય ત્યાં સુધી મેમરી મુક્ત થઈ શકે.
        // જો આપણે ખરેખર માલિકી પસાર કરવા માંગતા હો, તો આપણે આપણા માટે વધારાના નબળા નિર્દેશક બનાવી શકીએ છીએ, પરંતુ આના પરિણામે નબળા સંદર્ભની ગણતરીના વધારાના અપડેટ્સ થશે જે કદાચ જરૂરી ન હોય.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // હવે આપણે આંતરિક કિંમતને યોગ્ય રીતે પ્રારંભ કરી શકીએ છીએ અને અમારા નબળા સંદર્ભને મજબૂત સંદર્ભમાં ફેરવી શકીએ છીએ.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ડેટા ફીલ્ડ ઉપર લખેલું કોઈપણ થ્રેડ્સ માટે દૃશ્યમાન હોવું આવશ્યક છે જે બિન-શૂન્ય મજબૂત ગણતરીનું નિરીક્ષણ કરે છે.
            // તેથી, `Weak::upgrade` માં `compare_exchange_weak` સાથે સિંક્રનાઇઝ કરવા માટે અમને ઓછામાં ઓછા "Release" needર્ડરિંગની જરૂર છે.
            //
            // "Acquire" ઓર્ડર જરૂરી નથી.
            // જ્યારે `data_fn` ની સંભવિત વર્તણૂકોનો વિચાર કરીએ ત્યારે, અમને ફક્ત તે જોવાની જરૂર છે કે તે બિન-અપગ્રેડેબલ `Weak` ના સંદર્ભમાં શું કરી શકે છે:
            //
            // - તે નબળા સંદર્ભ ગણતરીમાં વધારો કરી, `Weak` * ક્લોન કરી શકે છે.
            // - તે તે ક્લોન્સને છોડી શકે છે, નબળા સંદર્ભની ગણતરી ઘટાડે છે (પરંતુ ક્યારેય શૂન્ય નહીં).
            //
            // આ આડઅસરો કોઈ પણ રીતે અમને અસર કરતી નથી, અને ફક્ત સલામત કોડથી અન્ય કોઈ આડઅસર શક્ય નથી.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // મજબૂત સંદર્ભો સામૂહિક રૂપે વહેંચાયેલા નબળા સંદર્ભના હોવા જોઈએ, તેથી આપણા જૂના નબળા સંદર્ભ માટે ડિસ્ટ્રક્ટર ચલાવશો નહીં.
        //
        mem::forget(weak);
        strong
    }

    /// અનહિતીકૃત સમાવિષ્ટો સાથે એક નવું `Arc` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// એક્સિટિલાઇઝ્ડ સમાવિષ્ટો સાથે નવી `Arc` બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// નવું `Pin<Arc<T>>` બનાવે છે.
    /// જો `T` એ `Unpin` અમલમાં ન મૂક્યું, તો પછી `data` મેમરીમાં પિન થઈ જશે અને ખસેડવામાં અસમર્થ હશે.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// નવું `Arc<T>` બનાવે છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // નબળા નિર્દેશક ગણતરીને 1 તરીકે પ્રારંભ કરો જે નબળા નિર્દેશક છે જે બધા મજબૂત પોઇંટર્સ (kinda) દ્વારા ધરાવે છે, વધુ માહિતી માટે std/rc.rs જુઓ
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// બિનનિર્ધારિત સમાવિષ્ટો સાથે નવું `Arc` બનાવે છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// એક્સિટિલાઇઝ્ડ સામગ્રીઓ સાથે એક નવું `Arc` બનાવે છે, `0` બાઇટ્સથી મેમરી ભરેલી છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો આવે છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// આંતરિક મૂલ્ય પરત કરે છે, જો `Arc` માં બરાબર એક સચોટ સંદર્ભ હોય.
    ///
    /// નહિંતર, એક [`Err`] એ જ `Arc` સાથે પાછો ફર્યો હતો જે અંદર ગયો હતો.
    ///
    ///
    /// બાકી નબળા સંદર્ભો હોય તો પણ આ સફળ થશે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // ગર્ભિત મજબૂત-નબળા સંદર્ભને સાફ કરવા માટે નબળા નિર્દેશક બનાવો
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// અનિટિઆલાઇઝ્ડ સમાવિષ્ટો સાથે નવી પરમાણુ સંદર્ભ-ગણતરીની સ્લાઇસ બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// એક્સિટિલાઇઝ્ડ સમાવિષ્ટો સાથે નવી પરમાણુ સંદર્ભ-ગણતરીની સ્લાઇસ બનાવે છે, મેમરી `0` બાઇટ્સથી ભરેલી છે.
    ///
    ///
    /// આ પદ્ધતિના સાચા અને ખોટા વપરાશના ઉદાહરણો માટે [`MaybeUninit::zeroed`][zeroed] જુઓ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, અંદરની કિંમત ખરેખર આરંભિત સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક .લ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` માં રૂપાંતરિત કરે છે.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ની જેમ, અંદરની કિંમત ખરેખર આરંભિત સ્થિતિમાં છે તેની ખાતરી આપવા માટે ક .લ કરનારનું છે.
    ///
    /// જ્યારે સામગ્રી હજી પૂર્ણરૂપે પ્રારંભ થયેલ નથી ત્યારે આને કingલ કરવાથી તાત્કાલિક અસ્પષ્ટ વર્તન થાય છે.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // વિલંબિત આરંભ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// વીંટાળેલા પોઇન્ટરને પરત કરીને, `Arc` લે છે.
    ///
    /// મેમરી લિકને ટાળવા માટે, નિર્દેશકને પાછા [`Arc::from_raw`] નો ઉપયોગ કરીને `Arc` પર પાછા ફેરવવું આવશ્યક છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ડેટાને કાચો પોઇન્ટર પ્રદાન કરે છે.
    ///
    /// ગણતરીઓ કોઈપણ રીતે અસર કરતી નથી અને `Arc` પીવામાં આવતી નથી.
    /// `Arc` માં મજબૂત ગણતરીઓ છે ત્યાં સુધી નિર્દેશક માન્ય છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // સલામતી: આ Deref::deref અથવા RcBoxPtr::inner થઈ શકતું નથી કારણ કે
        // આ જેમ કે દા.ત. raw/mut પ્રોવેન્સન્સ જાળવી રાખવા માટે જરૂરી છે
        // `get_mut` `from_raw` દ્વારા આરસી પુન theપ્રાપ્ત થયા પછી નિર્દેશક દ્વારા લખી શકે છે.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// કાચા પોઇન્ટરથી `Arc<T>` બનાવે છે.
    ///
    /// કાચા પોઇન્ટર પહેલા [`Arc<U>::into_raw`][into_raw] પર ક callલ દ્વારા પરત ફર્યા હોવું આવશ્યક છે જ્યાં `U` નું કદ અને `T` જેવું સંરેખણ હોવું આવશ્યક છે.
    /// જો `U` `T` હોય તો આ તુચ્છ રૂપે સાચું છે.
    /// નોંધ લો કે જો `U` એ X01 એક્સ નથી પરંતુ તેનું કદ અને ગોઠવણી સમાન છે, તો આ મૂળભૂત રીતે વિવિધ પ્રકારનાં સંદર્ભ ટ્રાન્સમિટ કરવા જેવું છે.
    /// આ કિસ્સામાં કયા નિયંત્રણો લાગુ પડે છે તેના પર વધુ માહિતી માટે [`mem::transmute`][transmute] જુઓ.
    ///
    /// `from_raw` ના વપરાશકર્તાએ ખાતરી કરવી પડશે કે `T` નું કોઈ ચોક્કસ મૂલ્ય ફક્ત એક જ વાર ઘટી ગયું છે.
    ///
    /// આ ફંક્શન અસુરક્ષિત છે કારણ કે અયોગ્ય ઉપયોગથી મેમરી અસુરક્ષિત થઈ શકે છે, પછી ભલે `Arc<T>` ક્યારેય isક્સેસ ન કરે.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // લિકને અટકાવવા માટે એક `Arc` પર પાછા ફેરવો.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` પર વધુ ક callsલ્સ મેમરી-અસુરક્ષિત હશે.
    /// }
    ///
    /// // જ્યારે `x` ઉપરની અવકાશની બહાર ગઈ ત્યારે મેમરીને મુક્ત કરવામાં આવી, તેથી `x_ptr` હવે ઝૂલતું રહે છે!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // અસલ આર્કઇનર શોધવા માટે setફસેટને વિરુદ્ધ કરો.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// આ ફાળવણી માટે એક નવું [`Weak`] પોઇન્ટર બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // આ રિલેક્સ્ડ બરાબર છે કારણ કે અમે નીચે સીએએસમાં મૂલ્ય ચકાસીએ છીએ.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // નબળા કાઉન્ટર હાલમાં "locked" છે કે કેમ તે તપાસો;જો એમ હોય તો, સ્પિન.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: આ કોડ હાલમાં ઓવરફ્લો થવાની સંભાવનાને અવગણે છે
            // usize::MAX માં;ઓવરફ્લો સાથે વ્યવહાર કરવા માટે સામાન્ય રીતે આરસી અને આર્ક બંનેને સમાયોજિત કરવાની જરૂર છે.
            //

            // Clone() થી વિપરીત, આપણને `is_unique` તરફથી આવતા લેખન સાથે સુમેળ કરવા માટે આ એક્ક્વાયર રીડ બનવાની જરૂર છે, જેથી તે લખવા પહેલાંની ઘટનાઓ આ વાંચતા પહેલા થાય.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ખાતરી કરો કે અમે ઝૂલતા નબળાઈ બનાવતા નથી
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// આ ફાળવણીમાં [`Weak`] પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિ જાતે જ સલામત છે, પરંતુ તેનો યોગ્ય ઉપયોગ કરવા માટે વધારાની કાળજી લેવી જરૂરી છે.
    /// બીજો થ્રેડ કોઈપણ સમયે નબળી ગણતરીને બદલી શકે છે, આ પદ્ધતિને ક callingલ કરવા અને પરિણામ પર અભિનય કરવા સહિત.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // આ નિવેદન નિશ્ચયિક છે કારણ કે અમે થ્રેડો વચ્ચે `Arc` અથવા `Weak` શેર કર્યું નથી.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // જો નબળી ગણતરી હાલમાં લ lockedક કરેલી છે, તો લ takingક લેતા પહેલા ગણતરીનું મૂલ્ય 0 હતું.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// આ ફાળવણીમાં મજબૂત (`Arc`) પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// # Safety
    ///
    /// આ પદ્ધતિ જાતે જ સલામત છે, પરંતુ તેનો યોગ્ય ઉપયોગ કરવા માટે વધારાની કાળજી લેવી જરૂરી છે.
    /// બીજો થ્રેડ કોઈપણ સમયે મજબૂત ગણતરીને બદલી શકે છે, આ પદ્ધતિને ક callingલ કરવા અને પરિણામ પર અભિનય કરવા સહિત.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // આ નિવેદન નિશ્ચયિક છે કારણ કે અમે થ્રેડો વચ્ચે `Arc` શેર કર્યો નથી.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// એક પછી એક પ્રદાન કરેલા પોઇન્ટર સાથે સંકળાયેલ `Arc<T>` પર મજબૂત સંદર્ભ ગણતરીમાં વધારો.
    ///
    /// # Safety
    ///
    /// પોઇન્ટર `Arc::into_raw` દ્વારા પ્રાપ્ત થયેલ હોવું આવશ્યક છે, અને સંકળાયેલ `Arc` દાખલો માન્ય હોવો આવશ્યક છે (દા.ત.
    /// આ પદ્ધતિની અવધિ માટે મજબૂત ગણતરી ઓછામાં ઓછી 1 હોવી આવશ્યક છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // આ નિવેદન નિશ્ચયિક છે કારણ કે અમે થ્રેડો વચ્ચે `Arc` શેર કર્યો નથી.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // આર્કને ફરીથી જાળવો, પરંતુ મેન્યુઅલી ડ્રropપમાં લપેટીને ફરીથી ગણતરીને સ્પર્શશો નહીં
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // હવે ફરીથી ગણતરીમાં વધારો, પરંતુ નવી રીકાઉન્ટને પણ છોડશો નહીં
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// એક દ્વારા પ્રદાન કરેલા પોઇન્ટર સાથે સંકળાયેલ `Arc<T>` પરની મજબૂત સંદર્ભ ગણતરીમાં ઘટાડો.
    ///
    /// # Safety
    ///
    /// પોઇન્ટર `Arc::into_raw` દ્વારા પ્રાપ્ત થયેલ હોવું આવશ્યક છે, અને સંકળાયેલ `Arc` દાખલો માન્ય હોવો આવશ્યક છે (દા.ત.
    /// આ પદ્ધતિનો ઉપયોગ કરતી વખતે મજબૂત ગણતરી ઓછામાં ઓછી 1 હોવી આવશ્યક છે.
    /// આ પદ્ધતિનો ઉપયોગ અંતિમ `Arc` અને બેકિંગ સ્ટોરેજને છૂટા કરવા માટે થઈ શકે છે, પરંતુ અંતિમ `Arc` પ્રકાશિત થયા પછી ** ન બોલાવવા જોઈએ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // તે નિવેદનો નિરાશાવાદી છે કારણ કે અમે થ્રેડો વચ્ચે `Arc` શેર કર્યો નથી.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // આ અસંતોષ બરાબર છે કારણ કે જ્યારે આ આર્ક જીવંત છે ત્યારે અમને ખાતરી આપવામાં આવે છે કે આંતરિક નિર્દેશક માન્ય છે.
        // તદુપરાંત, આપણે જાણીએ છીએ કે `ArcInner` સ્ટ્રક્ચર પોતે જ `Sync` છે કારણ કે આંતરિક ડેટા પણ `Sync` છે, તેથી અમે આ સમાવિષ્ટો માટે સ્થિર નિર્દેશકને લોન આપી રહ્યા છીએ.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` નો બિન-ઇનલાઇન ભાગ.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // આ સમયે ડેટાને નષ્ટ કરો, ભલે આપણે બ allocક્સની ફાળવણી પોતે જ મુક્ત ન કરી શકીએ (ત્યાં હજી પણ આજુબાજુના નબળા નિર્દેશકો હોઈ શકે છે).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // બધા મજબૂત સંદર્ભો દ્વારા સામૂહિક રીતે યોજાયેલા નબળા રેફને છોડો
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// જો બે `આર્`કસ સમાન ફાળવણી તરફ નિર્દેશ કરે તો `true` આપે છે ([`ptr::eq`] સમાન શિરામાં).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// સંભવિત-અસૂચિત આંતરીક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `ArcInner<T>` ફાળવે છે જ્યાં મૂલ્ય પૂરા પાડવામાં આવ્યું છે.
    ///
    /// ફંક્શન `mem_to_arcinner` ને ડેટા પોઇન્ટર સાથે કહેવામાં આવે છે અને `ArcInner<T>` માટે એક (સંભવિત ચરબી)-પોઇન્ટર પાછું ફરવું જોઈએ.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // આપેલ મૂલ્ય લેઆઉટનો ઉપયોગ કરીને લેઆઉટની ગણતરી કરો.
        // પહેલાં, લેઆઉટની ગણતરી `&*(ptr as* const ArcInner<T>)` અભિવ્યક્તિ પર કરવામાં આવતી હતી, પરંતુ આણે ખોટી રીતે સહી કરેલ સંદર્ભ બનાવ્યો (#54908 જુઓ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// સંભવિત-અસૂચિત આંતરીક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `ArcInner<T>` ફાળવે છે જ્યાં મૂલ્યનું લેઆઉટ આપવામાં આવ્યું છે, જો ફાળવણી નિષ્ફળ જાય તો ભૂલ પાછો.
    ///
    ///
    /// ફંક્શન `mem_to_arcinner` ને ડેટા પોઇન્ટર સાથે કહેવામાં આવે છે અને `ArcInner<T>` માટે એક (સંભવિત ચરબી)-પોઇન્ટર પાછું ફરવું જોઈએ.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // આપેલ મૂલ્ય લેઆઉટનો ઉપયોગ કરીને લેઆઉટની ગણતરી કરો.
        // પહેલાં, લેઆઉટની ગણતરી `&*(ptr as* const ArcInner<T>)` અભિવ્યક્તિ પર કરવામાં આવતી હતી, પરંતુ આણે ખોટી રીતે સહી કરેલ સંદર્ભ બનાવ્યો (#54908 જુઓ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // આર્કિન્નર પ્રારંભ કરો
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// બિન-કદિત આંતરિક મૂલ્ય માટે પૂરતી જગ્યા સાથે એક `ArcInner<T>` ફાળવે છે.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // આપેલ મૂલ્યનો ઉપયોગ કરીને `ArcInner<T>` માટે ફાળવો.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // બાઇટ્સ તરીકે ક Copyપિ કરો મૂલ્ય
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ફાળવણીની સામગ્રીને છોડ્યા વિના મુક્ત કરો
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// આપેલ લંબાઈ સાથે એક `ArcInner<[T]>` ફાળવે છે.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// ટુકડાઓમાંથી તત્વોને નવી ફાળવેલ આર્ક <\[ટી\]> માં ક Copyપિ કરો
    ///
    /// અસુરક્ષિત કારણ કે કlerલરને કાં તો માલિકી લેવી જોઈએ અથવા `T: Copy` ને બાંધવું જોઈએ.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ચોક્કસ કદના જાણીતા ઇટરેટરથી `Arc<[T]>` બનાવે છે.
    ///
    /// વર્તન અનિશ્ચિત છે જો કદ ખોટું હોવું જોઈએ.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // ટી તત્વોની ક્લોનીંગ કરતી વખતે ઝેડપાનિક 0 ઝેડ રક્ષક.
        // ઝેડ 0 પicનિક 80 ઝેડની ઘટનામાં, નવા આર્કઇનરમાં લખેલા તત્વોને છોડી દેવામાં આવશે, પછી મેમરી મુક્ત થઈ જશે.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // પ્રથમ તત્વ તરફ નિર્દેશક
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // બધું ચોખ્ખું.રક્ષકને ભૂલી જાઓ જેથી તે નવા આર્કઇનરને મુક્ત ન કરે.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` માટે વપરાયેલી વિશેષતા trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` પોઇન્ટરનો ક્લોન બનાવે છે.
    ///
    /// આ તે જ ફાળવણીમાં બીજો નિર્દેશક બનાવે છે, મજબૂત સંદર્ભ ગણતરીમાં વધારો કરે છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // રિલેક્સ્ડ ઓર્ડરિંગનો ઉપયોગ અહીં ઠીક છે, કારણ કે મૂળ સંદર્ભનું જ્ otherાન અન્ય થ્રેડોને ભૂલથી objectબ્જેક્ટને કાtingી નાખવામાં રોકે છે.
        //
        // [Boost documentation][1] માં સમજાવ્યા મુજબ, સંદર્ભ કાઉન્ટર વધારવું હંમેશા મેમરી_ઓર્ડર_રલેક્સ્ડ સાથે કરી શકાય છે: objectબ્જેક્ટના નવા સંદર્ભો ફક્ત અસ્તિત્વમાં છે તે સંદર્ભમાંથી જ બનાવવામાં આવી શકે છે, અને હાલના સંદર્ભને એક થ્રેડથી બીજામાં પસાર કરવો એ પહેલાથી જ જરૂરી સુમેળ પ્રદાન કરવું આવશ્યક છે.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // તેમ છતાં, જો કોઈ `મેમ: : ભૂલીને આર્ક્સ હોય તેવા સંજોગોમાં આપણે મોટા પાયે રસીકરણ સામે રક્ષણ આપવાની જરૂર છે.
        // જો આપણે આ ન કરીએ તો ગણતરી ઓવરફ્લો થઈ શકે છે અને વપરાશકર્તાઓ મફતમાં ઉપયોગ કરશે.
        // `isize::MAX` એક્સ અબજ થ્રેડોસ એક જ સમયે સંદર્ભની ગણતરીમાં વધારો કરશે નહીં તે ધારણા પર અમે `isize::MAX` ને આડેધડ સંતૃપ્ત કરીએ છીએ.
        //
        // આ ઝેડ 0 ફ્રેન્ચ 0 ઝેડ ક્યારેય કોઈપણ વાસ્તવિક પ્રોગ્રામમાં લેવામાં આવશે નહીં.
        //
        // અમે અવગણવું કારણ કે આ પ્રકારનો પ્રોગ્રામ આશ્ચર્યજનક રીતે પાતળું છે, અને અમે તેને ટેકો આપવાની કાળજી લેતા નથી.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// આપેલ `Arc` માં પરિવર્તનશીલ સંદર્ભ બનાવે છે.
    ///
    /// જો સમાન ફાળવણીમાં અન્ય `Arc` અથવા [`Weak`] પોઇંટર્સ છે, તો પછી `make_mut` એક નવી ફાળવણી બનાવશે અને અનન્ય માલિકીની ખાતરી કરવા માટે આંતરિક મૂલ્ય પર [`clone`][clone] ને વિનંતી કરશે.
    /// આને ક્લોન onન-રાઇટ તરીકે પણ ઓળખવામાં આવે છે.
    ///
    /// નોંધો કે આ [`Rc::make_mut`] ની વર્તણૂકથી અલગ છે જે બાકીના `Weak` પોઇંટર્સને અલગ પાડે છે.
    ///
    /// [`get_mut`][get_mut] પણ જુઓ, જે ક્લોનીંગ કરતાં નિષ્ફળ જશે.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // કંઈપણ ક્લોન નહીં કરો
    /// let mut other_data = Arc::clone(&data); // આંતરિક ડેટાને ક્લોન નહીં કરે
    /// *Arc::make_mut(&mut data) += 1;         // ક્લોન્સ આંતરિક ડેટા
    /// *Arc::make_mut(&mut data) += 1;         // કંઈપણ ક્લોન નહીં કરો
    /// *Arc::make_mut(&mut other_data) *= 2;   // કંઈપણ ક્લોન નહીં કરો
    ///
    /// // હવે `data` અને `other_data` વિવિધ ફાળવણી તરફ નિર્દેશ કરે છે.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // નોંધ લો કે અમારી પાસે મજબૂત સંદર્ભ અને નબળા સંદર્ભ બંને છે.
        // આમ, અમારા મજબૂત સંદર્ભને મુક્ત કરવાથી, પોતે જ, મેમરીને વિક્ષેપિત કરશે નહીં.
        //
        // એક્સીવાયરનો ઉપયોગ એ સુનિશ્ચિત કરવા માટે કે અમે `weak` પરના કોઈપણ લખાણો જુએ છે જે `strong` પર પ્રકાશન પહેલાં લખે છે (એટલે કે ઘટાડો).
        // આપણી પાસે નબળી ગણતરી હોવાથી, આર્કઇન્નર પોતે ખંડિત થઈ શકે તેવી કોઈ સંભાવના નથી.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // બીજો મજબૂત નિર્દેશક અસ્તિત્વમાં છે, તેથી આપણે ક્લોન કરવું આવશ્યક છે.
            // ક્લોન કરેલ મૂલ્યને સીધા લખવાની મંજૂરી આપવા માટે પૂર્વ-ફાળવણી મેમરી.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ઉપરોક્ત આરામદાયક પૂરતા કારણ કે આ મૂળભૂત રૂપે એક optimપ્ટિમાઇઝેશન છે: અમે હંમેશાં નબળા પોઇંટર્સને પડતા મૂકવા સાથે દોડીએ છીએ.
            // સૌથી ખરાબ કિસ્સામાં, અમે બિનજરૂરી રીતે નવી આર્ક ફાળવી.
            //

            // અમે છેલ્લું મજબૂત રેફ કા removed્યું છે, પરંતુ ત્યાં વધારાના નબળા રેફ બાકી છે.
            // અમે સમાવિષ્ટોને નવા આર્કમાં ખસેડીશું, અને અન્ય નબળા રેફ્સને અમાન્ય કરીશું.
            //

            // નોંધ લો કે `weak` ના વાંચન માટે usize::MAX (એટલે કે, લ lockedક) મેળવવું શક્ય નથી, કારણ કે નબળા ગણતરીને ફક્ત એક મજબૂત સંદર્ભ સાથે થ્રેડ દ્વારા લ lockedક કરી શકાય છે.
            //
            //

            // આપણા પોતાના ગર્ભિત નબળા નિર્દેશકને સામાનિત કરો, જેથી તે જરૂરી મુજબ આર્કિન્નરને સાફ કરી શકે.
            //
            let _weak = Weak { ptr: this.ptr };

            // ફક્ત ડેટા ચોરી શકે છે, બાકી છે ફક્ત વેક્સ
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // અમે બંને પ્રકારનાં એકમાત્ર સંદર્ભ હતા;મજબૂત સંદર્ભ ગણતરી બેક અપ.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` ની જેમ, અસંતોષ બરાબર છે કારણ કે અમારો સંદર્ભ પ્રારંભ કરવા માટે ક્યાં તો અનન્ય હતો, અથવા સમાવિષ્ટોને ક્લોન કરવા પર એક બની ગયો હતો.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// આપેલ `Arc` માં પરિવર્તનીય સંદર્ભ આપે છે, જો સમાન ફાળવણીમાં અન્ય કોઈ `Arc` અથવા [`Weak`] પોઇન્ટર ન હોય તો.
    ///
    ///
    /// [`None`] પરત કરે છે અન્યથા, કારણ કે વહેંચાયેલ મૂલ્યનું પરિવર્તન કરવું સલામત નથી.
    ///
    /// [`make_mut`][make_mut] પણ જુઓ, જે અન્ય નિર્દેશકો હોય ત્યારે આંતરિક મૂલ્ય [`clone`][clone] કરશે.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // આ અસંતોષ બરાબર છે કારણ કે અમને ખાતરી આપવામાં આવી છે કે જે નિર્દેશક પાછો ફર્યો છે તે એકમાત્ર * પોઇન્ટર છે જે ક્યારેય ટી પર પાછા આવશે.
            // અમારી સંદર્ભની ગણતરી આ સમયે 1 હોવાની બાંયધરી આપવામાં આવી છે, અને અમારે આર્ક પોતે `mut` હોવો જરૂરી છે, તેથી અમે આંતરિક ડેટાના એકમાત્ર સંભવિત સંદર્ભને પરત કરી રહ્યા છીએ.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// આપેલ `Arc` માં કોઈ પણ તપાસ કર્યા વગર પરિવર્તનીય સંદર્ભ આપે છે.
    ///
    /// [`get_mut`] પણ જુઓ, જે સલામત છે અને યોગ્ય તપાસ કરે છે.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// તે જ ફાળવણીમાં અન્ય કોઈપણ `Arc` અથવા [`Weak`] પોઇંટરો પરત ઉધારની અવધિ માટે યોગ્ય ન હોવો જોઈએ.
    ///
    /// આ તુચ્છ રૂપે કેસ છે જો આવા કોઈ નિર્દેશકો અસ્તિત્વમાં નથી, ઉદાહરણ તરીકે `Arc::new` પછી તરત જ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // અમે "count" ફીલ્ડ્સને આવરી લેતા *સંદર્ભ* બનાવતા નથી તેની કાળજી રાખીએ છીએ, કારણ કે આ સંદર્ભ ગણતરીઓની એક સાથે સુલભતા ઉપનામ (દા.ત.
        // `Weak` દ્વારા).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// અંતર્ગત ડેટા માટે આ અનન્ય સંદર્ભ (નબળા રેફ્સ સહિત) છે કે કેમ તે નક્કી કરો.
    ///
    ///
    /// નોંધ લો કે આ માટે નબળા રેફ કાઉન્ટને લkingક કરવાની જરૂર છે.
    fn is_unique(&mut self) -> bool {
        // જો આપણે એકમાત્ર નબળા પોઇન્ટર ધારક હોઈએ છીએ, તો નબળા પોઇન્ટર ગણતરીને લ lockક કરો.
        //
        // અહીં એક્વિઝ્ડ લેબલ `weak` ગણતરીના ઘટાડા પહેલાં `strong` (ખાસ કરીને `Weak::drop` X) માં કોઈપણ લખવા સાથેના સંબંધો બનવાની ખાતરી કરે છે (`Weak::drop` દ્વારા, જે પ્રકાશનનો ઉપયોગ કરે છે).
        // જો અપગ્રેડ કરેલા નબળા રેફને ક્યારેય છોડવામાં ન આવે તો, અહીંનો સીએએસ નિષ્ફળ જશે તેથી અમને સુમેળ કરવાની કાળજી નથી.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` માં `strong` કાઉન્ટરના ઘટાડા સાથે સિંક્રનાઇઝ થવા માટે આ એક `Acquire` હોવું જરૂરી છે-એકમાત્ર happensક્સેસ ત્યારે થાય છે જ્યારે કોઈપણ જ્યારે છેલ્લું સંદર્ભ છોડી દેવામાં આવે છે.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // પ્રકાશન લેખન અહીં `downgrade` માં વાંચવા સાથે સુમેળ કરે છે, `strong` ના ઉપરના વાંચનને અસરકારક રીતે લખાણ પછી થતું અટકાવે છે.
            //
            //
            self.inner().weak.store(1, Release); // લોક છૂટો
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ના ઘટાડે છે.
    ///
    /// આ મજબૂત સંદર્ભ ગણતરીમાં ઘટાડો કરશે.
    /// જો મજબૂત સંદર્ભ ગણતરી શૂન્ય પર પહોંચે છે, તો પછી માત્ર અન્ય સંદર્ભો (જો કોઈ હોય તો) [`Weak`] છે, તેથી અમે આંતરિક મૂલ્ય `drop` કરીએ છીએ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // કંઈપણ છાપતો નથી
    /// drop(foo2);   // પ્રિન્ટ્સ "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // કારણ કે `fetch_sub` પહેલાથી જ અણુ છે, જ્યાં સુધી આપણે .બ્જેક્ટને કા deleteી નાખવાના ન હો ત્યાં સુધી અમારે અન્ય થ્રેડો સાથે સુમેળ કરવાની જરૂર નથી.
        // આ જ તર્ક એ `weak` ગણતરી માટે નીચે આપેલા `fetch_sub` ને લાગુ પડે છે.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ડેટાના ઉપયોગને ફરીથી ગોઠવવા અને ડેટાને કાtionી નાખવા માટે આ વાડની જરૂર છે.
        // કારણ કે તે `Release` તરીકે ચિહ્નિત થયેલ છે, સંદર્ભ ગણતરીમાં ઘટાડો આ `Acquire` વાડ સાથે સુમેળ કરે છે.
        // આનો અર્થ છે કે ડેટાનો ઉપયોગ સંદર્ભ ગણતરીમાં ઘટાડો કરતા પહેલા થાય છે, જે આ વાડ પહેલાં થાય છે, જે ડેટા કા ofી નાખતા પહેલા થાય છે.
        //
        // [Boost documentation][1] માં સમજાવ્યા મુજબ,
        //
        // > એકમાં theબ્જેક્ટની કોઈપણ સંભવિત enforceક્સેસને અમલમાં મૂકવી મહત્વપૂર્ણ છે
        // > કા threadવા પહેલાં * થવાનું (હાલના સંદર્ભ દ્વારા) થ્રેડ
        // > જુદા જુદા થ્રેડમાં .બ્જેક્ટ.આ એક "release" દ્વારા પ્રાપ્ત થયું છે
        // > સંદર્ભ છોડ્યા પછી કામગીરી (objectબ્જેક્ટની કોઈપણ accessક્સેસ
        // > આ સંદર્ભ દ્વારા સ્પષ્ટપણે પહેલાં થયું હોવું જોઈએ), અને એક
        // > "acquire" deleબ્જેક્ટને કાtingી નાખતા પહેલા કામગીરી.
        //
        // ખાસ કરીને, જ્યારે આર્કની સામગ્રી સામાન્ય રીતે પરિવર્તનશીલ હોય છે, ત્યારે મ્યુટેક્સ જેવી વસ્તુમાં આંતરિક લેખન શક્ય છે<T>.
        // કા deletedી નાખવામાં આવે ત્યારે મ્યુટેક્સ પ્રાપ્ત થયું ન હોવાથી, થ્રેડમાં લખવા માટે અમે તેના સુમેળ તર્ક પર વિશ્વાસ કરી શકતા નથી એ થ્રેડ બીમાં ચાલતા ડિસ્ટ્રક્ટરને દૃશ્યમાન છે.
        //
        //
        // એ પણ નોંધ લો કે અહીં એક્ક્વાયર વાડને કદાચ એક્ક્વાયર લોડ સાથે બદલી શકાય છે, જે અત્યંત વિરોધાભાસી પરિસ્થિતિઓમાં પ્રભાવ સુધારી શકે છે.[2] જુઓ.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// કોંક્રિટ પ્રકારના `Arc<dyn Any + Send + Sync>` ડાઉનકાસ્ટ કરવાનો પ્રયાસ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// કોઈપણ મેમરીને ફાળવ્યા વિના, નવું `Weak<T>` બનાવે છે.
    /// રીટર્ન વેલ્યુ પર [`upgrade`] પર કingલ કરવો હંમેશા [`None`] આપે છે.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// માહિતી ક્ષેત્ર વિશે કોઈ નિવેદનો કર્યા વગર સંદર્ભ ગણતરીઓને allowક્સેસ કરવા માટે સહાયકનો પ્રકાર.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// આ `Weak<T>` દ્વારા નિર્દેશિત Xબ્જેક્ટ `T` પર કાચો નિર્દેશક પાછો આપે છે.
    ///
    /// જો ત્યાં કેટલાક મજબૂત સંદર્ભો હોય તો જ નિર્દેશક માન્ય છે.
    /// નિર્દેશક ઝૂંટવું, અનલિએન્ડ કરેલું અથવા [`null`] અન્યથા હોઈ શકે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // બંને એક જ toબ્જેક્ટ તરફ નિર્દેશ કરે છે
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // અહીં મજબૂત તે જીવંત રાખે છે, તેથી અમે હજી પણ accessબ્જેક્ટને .ક્સેસ કરી શકીએ છીએ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // પરંતુ વધુ નહીં.
    /// // અમે weak.as_ptr() કરી શકીએ છીએ, પરંતુ નિર્દેશકને ક્સેસ કરવાથી અનિશ્ચિત વર્તન થઈ શકે છે.
    /// // assert_eq! ("હેલો", અસુરક્ષિત {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // જો પોઇંટર ઝૂલતો હોય, તો અમે સીધો જ મોકલ્યો હતો.
            // આ માન્ય પેલોડ સરનામું હોઈ શકતું નથી, કારણ કે પેલોડ ઓછામાં ઓછું આર્કઇનર એક્સ00 એક્સ તરીકે ગોઠવાયેલ છે.
            ptr as *const T
        } else {
            // સલામતી: જો is_dangling ખોટા વળતર આપે છે, તો પછી નિર્દેશક યોગ્ય નથી.
            // પેલોડ આ બિંદુએ છોડી શકાય છે, અને અમારે પ્રોવિન્સન્સ જાળવવું પડશે, તેથી કાચા પોઇન્ટર મેનીપ્યુલેશનનો ઉપયોગ કરો.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` લે છે અને તેને કાચા પોઇન્ટરમાં ફેરવે છે.
    ///
    /// આ નબળા નિર્દેશકને કાચા પોઇન્ટરમાં રૂપાંતરિત કરે છે, જ્યારે હજી પણ એક નબળા સંદર્ભની માલિકી સાચવે છે (નબળી ગણતરી આ કામગીરી દ્વારા સંશોધિત થતી નથી).
    /// તે [`from_raw`] સાથે પાછા `Weak<T>` માં ફેરવી શકાય છે.
    ///
    /// [`as_ptr`] ની જેમ પોઇન્ટરના લક્ષ્યને .ક્સેસ કરવા માટે સમાન નિયંત્રણો લાગુ પડે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] દ્વારા અગાઉ બનાવેલા કાચા પોઇન્ટરને પાછા `Weak<T>` માં ફેરવે છે.
    ///
    /// આનો ઉપયોગ સલામત રીતે મજબૂત સંદર્ભ મેળવવા માટે (પછીથી X01 એક્સ પર ક callingલ કરીને) અથવા `Weak<T>` છોડીને નબળા ગણતરીને દૂર કરવા માટે થઈ શકે છે.
    ///
    /// તે એક નબળા સંદર્ભની માલિકી લે છે ([`new`] દ્વારા બનાવેલા પોઇંટર્સના અપવાદ સિવાય, આ કંઈપણ ધરાવતા નથી; પદ્ધતિ હજી પણ તેમના પર કાર્ય કરે છે).
    ///
    /// # Safety
    ///
    /// પોઇન્ટર [`into_raw`] માંથી ઉદ્ભવ્યો હોવો જોઈએ અને હજી પણ તેના સંભવિત નબળા સંદર્ભની માલિકી હોવી જોઈએ.
    ///
    /// આ ક callingલ કરતી વખતે મજબૂત ગણતરી માટે 0 હોવાની મંજૂરી છે.
    /// તેમ છતાં, આ હાલમાં કાચા પોઇન્ટર તરીકે રજૂ કરાયેલા એક નબળા સંદર્ભની માલિકી લે છે (નબળી ગણતરી આ ઓપરેશન દ્વારા સુધારવામાં આવતી નથી) અને તેથી તે [`into_raw`] પર પહેલાંના ક callલ સાથે જોડી હોવી આવશ્યક છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // છેલ્લી નબળી ગણતરીમાં ઘટાડો.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ઇનપુટ પોઇન્ટર કેવી રીતે મેળવાય છે તેના સંદર્ભ માટે Weak::as_ptr જુઓ.

        let ptr = if is_dangling(ptr as *mut T) {
            // આ એક ઝૂલતું નબળું છે.
            ptr as *mut ArcInner<T>
        } else {
            // નહિંતર, અમને ખાતરી આપવામાં આવી છે કે નિર્દેશક નબળાઇથી આવે છે.
            // સલામત: ડેટા_ઓફસેટ ક callલ કરવા માટે સલામત છે, કારણ કે પી.ટી.આર. એક વાસ્તવિક (સંભવિત ઘટાડો) ટીનો સંદર્ભ આપે છે.
            let offset = unsafe { data_offset(ptr) };
            // આમ, આખું આરસીબોક્સ મેળવવા માટે અમે setફસેટને ઉલટાવીએ છીએ.
            // સલામતી: નિર્દેશક નબળાઇથી ઉત્પન્ન થયો છે, તેથી આ setફસેટ સલામત છે.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // સલામતી: હવે આપણે અસલ નબળા નિર્દેશકને પ્રાપ્ત કરી લીધું છે, તેથી નબળા બનાવી શકીએ છીએ.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` પોઇન્ટરને [`Arc`] પર અપગ્રેડ કરવાનો પ્રયાસ, જો સફળ થાય તો આંતરિક મૂલ્યના ઘટાડામાં વિલંબ થાય છે.
    ///
    ///
    /// જો આંતરિક મૂલ્ય ત્યારબાદ છોડી દેવામાં આવે તો [`None`] પરત કરે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // બધા મજબૂત પોઇંટરો નાશ.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // અમે ફેંચ_એડ્ડીની જગ્યાએ મજબૂત ગણતરીમાં વધારો કરવા માટે સીએએસ લૂપનો ઉપયોગ કરીએ છીએ કારણ કે આ કાર્ય ક્યારેય સંદર્ભ ગણતરીને શૂન્યથી એકમાં લેતું નથી.
        //
        //
        let inner = self.inner()?;

        // રિલેક્સ્ડ લોડ કારણ કે 0 નું કોઈપણ લેખન જે આપણે અવલોકન કરી શકીએ છીએ તે ક્ષેત્રને કાયમી શૂન્ય અવસ્થામાં છોડી દે છે (તેથી 0 નું એક "stale" વાંચવું સારું છે), અને અન્ય કોઈપણ મૂલ્યની ખાતરી નીચે સીએએસ દ્વારા કરવામાં આવે છે.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // અમે આ શા માટે કરીએ છીએ તેના માટે `Arc::clone` માં ટિપ્પણીઓ જુઓ (`mem::forget` માટે).
            if n > MAX_REFCOUNT {
                abort();
            }

            // રિલેક્સ્ડ નિષ્ફળતાના કેસ માટે સારું છે કારણ કે આપણને નવા રાજ્ય વિશે કોઈ અપેક્ષા નથી.
            // સફળતાના કેસને `Arc::new_cyclic` સાથે સુમેળ કરવા માટે એક્વિવાયર આવશ્યક છે, જ્યારે `Weak` સંદર્ભો પહેલાથી જ બનાવવામાં આવ્યા પછી આંતરિક મૂલ્ય પ્રારંભ કરી શકાય છે.
            // તે કિસ્સામાં, અમે સંપૂર્ણ પ્રારંભિક મૂલ્યનું નિરીક્ષણ કરવાની અપેક્ષા રાખીએ છીએ.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // નલ ઉપર તપાસવામાં
                Err(old) => n = old,
            }
        }
    }

    /// આ ફાળવણી તરફ નિર્દેશ કરતી મજબૂત (`Arc`) પોઇંટર્સની સંખ્યા મેળવે છે.
    ///
    /// જો `self`, [`Weak::new`] નો ઉપયોગ કરીને બનાવવામાં આવ્યો હતો, તો આ 0 પરત આવશે.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// આ ફાળવણી તરફ નિર્દેશ કરતી `Weak` પોઇંટર્સની સંખ્યાનો એક અંદાજ મેળવે છે.
    ///
    /// જો `self` એ [`Weak::new`] નો ઉપયોગ કરીને બનાવવામાં આવ્યો હતો, અથવા જો ત્યાં બાકી કોઈ મજબૂત પોઇંટર્સ નથી, તો આ 0 પરત આવશે.
    ///
    /// # Accuracy
    ///
    /// અમલીકરણની વિગતોને લીધે, જ્યારે અન્ય થ્રેડો સમાન ફાળવણી તરફ નિર્દેશ કરેલા કોઈપણ `આર્કે અથવા` નબળાઓને ચાલાકી કરી રહ્યા હોય ત્યારે પરત કરેલ મૂલ્ય બંને દિશામાં 1 દ્વારા બંધ થઈ શકે છે.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // આપણે જોયું છે કે નબળા ગણતરીને વાંચ્યા પછી ઓછામાં ઓછું એક મજબૂત નિર્દેશક હતું, તેથી આપણે જાણીએ છીએ કે નબળા ગણતરીને અવલોકન કરતી વખતે ગર્ભિત નબળા સંદર્ભ (જ્યારે પણ કોઈ મજબૂત સંદર્ભ જીવંત હોય ત્યારે હાજર હોય) આસપાસ હતો, અને તેથી સુરક્ષિત રીતે તેને બાદબાકી કરી શકીએ છીએ.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// જ્યારે નિર્દેશક ઝૂલતું હોય અને ત્યાં કોઈ ફાળવવામાં આવેલ `ArcInner` ન હોય ત્યારે `None` આપે છે, (એટલે કે, જ્યારે આ `Weak` `Weak::new` દ્વારા બનાવવામાં આવ્યું હતું).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // અમે "data" ફીલ્ડને આવરી લેતા એક સંદર્ભ બનાવવા * ન કરવા માટે ખૂબ કાળજી રાખીએ છીએ, કારણ કે આ ક્ષેત્ર એક સાથે પરિવર્તિત થઈ શકે છે (ઉદાહરણ તરીકે, જો છેલ્લા `Arc` છોડવામાં આવે છે, તો ડેટા ફીલ્ડને જગ્યાએ મૂકવામાં આવશે).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// જો બે નબળાઈ એક સમાન ફાળવણી તરફ નિર્દેશ કરે તો `true` આપે છે ([`ptr::eq`] જેવું જ), અથવા જો બંને કોઈ ફાળવણી તરફ નિર્દેશ કરતા નથી (કારણ કે તે `Weak::new()`) સાથે બનાવવામાં આવ્યા હતા.
    ///
    ///
    /// # Notes
    ///
    /// કારણ કે આ નિર્દેશકોની તુલના કરે છે તેનો અર્થ એ કે `Weak::new()` એકબીજાને સમાન કરશે, તેમ છતાં તેઓ કોઈપણ ફાળવણી તરફ નિર્દેશ કરતા નથી.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ની તુલના.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// તે જ ફાળવણી તરફ નિર્દેશ કરે છે તે `Weak` પોઇન્ટરનો ક્લોન બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // શા માટે આરામ કરવામાં આવે છે તે માટે Arc::clone() માં ટિપ્પણીઓ જુઓ.
        // આ ફેચ_એડ્ડ (લ ignoringકની અવગણના) નો ઉપયોગ કરી શકે છે કારણ કે નબળી ગણતરી ફક્ત ત્યારે જ લ lockedક હોય છે જ્યાં *કોઈ અન્ય* નબળા નિર્દેશકો અસ્તિત્વમાં નથી.
        //
        // (તેથી અમે તે કિસ્સામાં આ કોડ ચલાવી શકીએ નહીં).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // અમે આ શા માટે કરીએ છીએ તેના માટે Arc::clone() માં ટિપ્પણીઓ જુઓ (mem::forget માટે).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// મેમરીની ફાળવણી કર્યા વિના, એક નવું `Weak<T>` બનાવે છે.
    /// રીટર્ન વેલ્યુ પર [`upgrade`] પર કingલ કરવો હંમેશા [`None`] આપે છે.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` પોઇન્ટરને છોડે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // કંઈપણ છાપતો નથી
    /// drop(foo);        // પ્રિન્ટ્સ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // જો આપણે શોધી કા .ીએ કે આપણે છેલ્લા નબળા નિર્દેશક હતા, તો પછી ડેટાને સંપૂર્ણ રીતે ડિલવોકેટ કરવાનો સમય છે.મેમરી ઓર્ડરિંગ્સ વિશે Arc::drop() માં ચર્ચા જુઓ
        //
        // અહીં લ lockedક કરેલી સ્થિતિની તપાસ કરવી જરૂરી નથી, કારણ કે નબળી ગણતરી ફક્ત ત્યારે જ લ beક થઈ શકે છે જો ત્યાં એક નબળા રેફ હોય, એટલે કે ડ્રોપ પછીથી બાકી રહેલા નબળા રેફ પર ચલાવી શકે છે, જે ફક્ત લોક છૂટા થયા પછી જ થઈ શકે છે.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// અમે આ વિશેષતા અહીં કરી રહ્યા છીએ, અને `&T` પર વધુ સામાન્ય optimપ્ટિમાઇઝેશન તરીકે નહીં, કારણ કે તે અન્યથા રેફ્સ પરની બધી સમાનતા તપાસમાં ખર્ચ ઉમેરશે.
/// અમે ધારીએ છીએ કે `આર્`ક્સનો ઉપયોગ મોટા મૂલ્યો સ્ટોર કરવા માટે થાય છે, જે ક્લોન કરવામાં ધીમું હોય છે, પરંતુ સમાનતાની તપાસ માટે પણ ભારે હોય છે, જેના કારણે આ ખર્ચ વધુ સરળતાથી ચૂકવવામાં આવે છે.
///
/// તેમાં બે 00&T`s કરતા બે `Arc` ક્લોન હોવાની સંભાવના છે, જે સમાન મૂલ્ય તરફ નિર્દેશ કરે છે.
///
/// અમે ફક્ત ત્યારે જ કરી શકીએ છીએ જ્યારે `T: Eq` `PartialEq` તરીકે ઇરાદાપૂર્વક અસ્પષ્ટ હોઈ શકે.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// બે `આર્કેસ માટે સમાનતા.
    ///
    /// બે `આર્ક સમાન છે જો તેમના આંતરિક મૂલ્યો સમાન હોય, ભલે તે વિવિધ ફાળવણીમાં સંગ્રહિત હોય.
    ///
    /// જો `T` પણ `Eq` (સમાનતાના સૂચક પ્રતિક્રિયા) ને લાગુ કરે છે, તો સમાન ફાળવણીનો નિર્દેશ કરે છે તે બે `આર્ક હંમેશા સમાન હોય છે.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// બે `આર્કેસ માટે અસમાનતા.
    ///
    /// જો તેમના આંતરિક મૂલ્યો અસમાન હોય તો બે `આર્ક અસમાન હોય છે.
    ///
    /// જો `T` પણ `Eq` (સમાનતાના સૂચક પ્રતિક્રિયા) ને લાગુ કરે છે, તો સમાન મૂલ્ય તરફ નિર્દેશ કરતી બે `આર્ક ક્યારેય અસમાન હોતી નથી.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// બે `આર્કેસ માટે આંશિક તુલના.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `partial_cmp()` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// બે `આર્કેસ માટે તુલના કરતા ઓછી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `<` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Than આર્ક'ઝની તુલના' કરતા ઓછી અથવા બરાબર '.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `<=` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// બે `આર્કેઝ માટે વધુ સરખામણી.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `>` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Than આર્કા'ની તુલના' કરતા વધારે અથવા બરાબર '.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `>=` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// બે `આર્કેસ માટે તુલના.
    ///
    /// બંનેની તુલના તેમના આંતરિક મૂલ્યો પર `cmp()` ક callingલ કરીને કરવામાં આવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` માટેના `Default` મૂલ્ય સાથે, એક નવો `Arc<T>` બનાવે છે.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// સંદર્ભ-ગણાતી સ્લાઈસ ફાળવો અને cl v` ની આઇટમ્સની ક્લોનિંગ કરીને તેને ભરો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// સંદર્ભ-ગણાતા `str` ને ફાળવો અને તેમાં `v` ની ક copyપિ બનાવો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// સંદર્ભ-ગણાતા `str` ને ફાળવો અને તેમાં `v` ની ક copyપિ બનાવો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// નવા, સંદર્ભ-ગણતરીના ફાળવણીમાં બedક્સ્ડ objectબ્જેક્ટ ખસેડો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// સંદર્ભ-ગણાતી સ્લાઈસ ફાળવો અને તેમાં વસ્તુઓ ખસેડો.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec ને તેની મેમરી મુક્ત કરવાની મંજૂરી આપો, પરંતુ તેની સામગ્રીને નષ્ટ ન કરો
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` માં દરેક તત્વ લે છે અને તેને `Arc<[T]>` માં એકત્રિત કરે છે.
    ///
    /// # પ્રભાવ લાક્ષણિકતાઓ
    ///
    /// ## સામાન્ય કેસ
    ///
    /// સામાન્ય કિસ્સામાં, `Arc<[T]>` માં એકત્રિત કરવાનું પ્રથમ `Vec<T>` માં એકત્રિત કરીને કરવામાં આવે છે.તે છે, જ્યારે નીચે લખતા હો ત્યારે:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// આ જેમ વર્તે છે જેમ કે આપણે લખ્યું છે:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ફાળવણીનો પ્રથમ સેટ અહીં થાય છે.
    ///     .into(); // `Arc<[T]>` માટે બીજું ફાળવણી અહીં થાય છે.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// આ `Vec<T>` બાંધવા માટે જરૂરી તેટલી વખત ફાળવણી કરશે અને પછી તે `Vec<T>` ને `Arc<[T]>` માં ફેરવવા માટે એકવાર ફાળવવામાં આવશે.
    ///
    ///
    /// ## જાણીતી લંબાઈના ઇટરેટર્સ
    ///
    /// જ્યારે તમારું `Iterator` `TrustedLen` લાગુ કરે છે અને ચોક્કસ કદનું હોય ત્યારે, `Arc<[T]>` માટે એક ફાળવણી કરવામાં આવશે.દાખ્લા તરીકે:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // અહીં ફક્ત એક જ ફાળવણી થાય છે.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` માં એકત્રિત કરવા માટે વપરાયેલી વિશેષતા trait.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // આ એક `TrustedLen` પુનરાવર્તક માટેનો કેસ છે.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // સલામતી: આપણને ખાતરી કરવાની જરૂર છે કે પુનરાવર્તકની ચોક્કસ લંબાઈ છે અને અમારી પાસે છે.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // સામાન્ય અમલીકરણ પર પાછા ફરો.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// પોઇન્ટરના પાછળના પેલોડ માટે `ArcInner` ની અંદર setફસેટ મેળવો.
///
/// # Safety
///
/// નિર્દેશકએ T ના પહેલાના માન્ય દાખલા પર (અને તેના માટે માન્ય મેટાડેટા હોવું જોઈએ) નિર્દેશ કરવું આવશ્યક છે, પરંતુ ટીને છોડી દેવાની મંજૂરી છે.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // આર્કઇન્નરના અંતમાં વસાહતી મૂલ્યને સંરેખિત કરો.
    // કારણ કે આરસીબોક્સ એ repr(C) છે, તે હંમેશા મેમરીમાં છેલ્લું ક્ષેત્ર રહેશે.
    // સલામતી: ફક્ત અનઇસીઇઝ્ડ પ્રકારો જ શક્ય છે કાપી નાંખેલ ઝેડટ્રેટ 0 ઝેડ objectsબ્જેક્ટ્સ
    // અને બાહ્ય પ્રકારો, align_of_val_raw ની આવશ્યકતાઓને સંતોષવા માટે ઇનપુટ સલામતી આવશ્યકતા હાલમાં પૂરતી છે;આ તે ભાષાનું અમલીકરણ વિગત છે કે જે std ની બહાર ન હોઈ શકે.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}