//! Windows SEH
//!
//! Windows પર (હાલમાં ફક્ત MSVC પર), ડિફ theલ્ટ અપવાદ હેન્ડલિંગ મિકેનિઝમ સ્ટ્રક્ચર્ડ અપવાદ હેન્ડલિંગ (SEH) છે.
//! આ કમ્પાઈલર ઇન્ટર્નલની બાબતમાં ડ્વાર્ફ-આધારિત અપવાદ હેન્ડલિંગ (દા.ત., અન્ય unix પ્લેટફોર્મ શું વાપરે છે) કરતા તદ્દન અલગ છે, તેથી એલએલવીએમને એસઇએચ માટે વધારાના સપોર્ટનો સારો વ્યવહાર કરવો જરૂરી છે.
//!
//! ટૂંકમાં, અહીં જે થાય છે તે છે:
//!
//! 1. એક્સ 100 એક્સ ફંક્શન સી ++ ફેંકવા માટે ધોરણ Windows ફંક્શન `_CxxThrowException` ને ક callsલ કરે છે-અપવાદની જેમ, અનવindingન્ડિંગ પ્રક્રિયાને ટ્રિગર કરે છે.
//! 2.
//! કમ્પાઇલર દ્વારા જનરેટ થયેલ બધા ઉતરાણ પેડ્સ સીઆરટીમાં ફંક્શન, પર્સનાલિટી ફંક્શન `__CxxFrameHandler3` નો ઉપયોગ કરે છે, અને Windows માં અનઇન્ડિંગ કોડ આ પર્સનાલિટી ફંક્શનનો ઉપયોગ સ્ટેક પરના બધા ક્લિનઅપ કોડને એક્ઝેક્યુટ કરવા માટે કરશે.
//!
//! 3. `invoke` પરના બધા કમ્પાઇલર-જનરેટેડ ક callsલ્સમાં એક લેન્ડિંગ પેડ છે જે `cleanuppad` LLVM સૂચના તરીકે સેટ કરે છે, જે ક્લિનઅપ રૂટિનની શરૂઆત સૂચવે છે.
//! વ્યક્તિત્વ (સીઆરટીમાં વ્યાખ્યાયિત પગલું 2 માં) સફાઇ દિનચર્યાઓ ચલાવવા માટે જવાબદાર છે.
//! 4. આખરે `try` આંતરિક (કમ્પાઇલર દ્વારા પેદા થયેલ) માં "catch" કોડ એક્ઝેક્યુટ થાય છે અને સૂચવે છે કે નિયંત્રણ Rust પર પાછા આવવું જોઈએ.
//! આ એક `catchswitch` વત્તા XL1M સૂચના દ્વારા LLVM IR દ્રષ્ટિએ કરવામાં આવે છે, છેવટે `catchret` સૂચનાથી પ્રોગ્રામમાં સામાન્ય નિયંત્રણ પાછું આપે છે.
//!
//! gcc-આધારિત અપવાદ હેન્ડલિંગમાંથી કેટલાક વિશિષ્ટ તફાવતો છે:
//!
//! * ઝેડ રસ્ટ0 ઝેડમાં કોઈ કસ્ટમ વ્યક્તિત્વનું કાર્ય નથી, તે તેના બદલે *હંમેશા*`__CxxFrameHandler3` છે.આ ઉપરાંત, કોઈ વધારાનું ફિલ્ટરિંગ કરવામાં આવતું નથી, તેથી અમે કોઈપણ સી ++ અપવાદોને પકડીએ છીએ જે આપણે ફેંકી રહ્યા છીએ તેવું લાગે છે.
//! નોંધ લો કે ઝેડ રસ્ટ0 ઝેડમાં અપવાદ ફેંકવું એ કોઈપણ રીતે નિર્ધારિત વર્તન છે, તેથી આ સારું હોવું જોઈએ.
//! * અમને અનડિન્ડિંગ બાઉન્ડ્રી પર, ખાસ કરીને એક `Box<dyn Any + Send>` પર વહન કરવા માટે થોડો ડેટા મળ્યો છે.વામન અપવાદોની જેમ આ બંને પોઇન્ટર પણ અપવાદમાં જ પેલોડ તરીકે સંગ્રહિત છે.
//! એમએસવીસી પર, તેમ છતાં, વધારાના apગલાની ફાળવણીની કોઈ જરૂર નથી કારણ કે ફિલ્ટર ફંક્શન્સ ચલાવવામાં આવતી વખતે ક theલ સ્ટેક સચવાય છે.
//! આનો અર્થ એ છે કે નિર્દેશકો સીધા `_CxxThrowException` પર પસાર થાય છે જે પછીથી `try` આંતરિકના સ્ટેક ફ્રેમમાં લખવા માટે ફિલ્ટર ફંક્શનમાં પુન .પ્રાપ્ત થાય છે.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // આને વિકલ્પ બનાવવાની જરૂર છે કારણ કે આપણે સંદર્ભ દ્વારા અપવાદને પકડીએ છીએ અને તેનો વિનાશક સી ++ રનટાઇમ દ્વારા ચલાવવામાં આવે છે.
    // જ્યારે અમે બ theક્સને અપવાદની બહાર લઈ જઈએ છીએ, ત્યારે આપણે તેના અપનાશકને બ doubleક્સને ડબલ-ડ્રોપ કર્યા વિના ચલાવવા માટે તેના અપનાશકને માન્ય સ્થિતિમાં છોડી દેવાની જરૂર છે.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// પ્રથમ, સંપૂર્ણ વ્યાખ્યાઓનો સંપૂર્ણ સમૂહ.અહીં કેટલાક પ્લેટફોર્મ-વિશિષ્ટ ઓડિટીઝ છે, અને ઘણું બધું જે ફક્ત LLVM માંથી સ્પષ્ટપણે નકલ કરવામાં આવ્યું છે.આ બધાનો હેતુ એ `_CxxThrowException` પર ક callલ દ્વારા નીચે `panic` ફંક્શનને અમલમાં મૂકવાનો છે.
//
// આ કાર્ય બે દલીલો લે છે.પ્રથમ તે ડેટાનો નિર્દેશક છે જેમાં આપણે પસાર થઈ રહ્યા છીએ, જે આ કિસ્સામાં અમારું ઝેડટ્રેટ 0 ઝેડ .બ્જેક્ટ છે.શોધવા માટે ખૂબ સુંદર!આગળ, જોકે, વધુ જટિલ છે.
// આ એક `_ThrowInfo` સ્ટ્રક્ચરનો નિર્દેશક છે, અને તે સામાન્ય રીતે ફક્ત ફેંકાયેલા અપવાદનું વર્ણન કરવા માટે બનાવાયેલ છે.
//
// હાલમાં આ પ્રકારનાં [1] ની વ્યાખ્યા થોડી રુવાંટીવાળું છે, અને મુખ્ય વિચિત્રતા (અને articleનલાઇન લેખથી તફાવત) એ છે કે 32-બીટ પર પોઇંટરો પોઇંટરો છે પરંતુ 64-બીટ પર પોઇંટર્સ 32-બીટ seફસેટ્સ તરીકે દર્શાવવામાં આવ્યા છે `__ImageBase` પ્રતીક.
//
// આને વ્યક્ત કરવા માટે નીચેના મોડ્યુલોમાં `ptr_t` અને `ptr!` મેક્રોનો ઉપયોગ કરવામાં આવે છે.
//
// આ પ્રકારની કામગીરી માટે એલએલવીએમ બહાર કાitsે છે તે પ્રકારનાં વ્યાખ્યાઓની માર્ગ પણ નજીકથી અનુસરે છે.ઉદાહરણ તરીકે, જો તમે આ સી ++ કોડને એમએસવીસી પર કમ્પાઇલ કરો અને એલએલવીએમ આઈઆર બહાર કા: ો:
//
//      #include <stdint.h>
//
//      સ્ટ્રક્ટ રસ્ટ_પેનિક {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      રદબાતલ foo() { rust_panic a = {0, 1};
//          ફેંકવું;}
//
// તે આવશ્યકપણે આપણે અનુકરણ કરવાનો પ્રયાસ કરી રહ્યા છીએ.નીચે આપેલા મોટાભાગનાં સ્થિર મૂલ્યો ફક્ત એલએલવીએમથી જ નકલ કરવામાં આવ્યા હતા,
//
// કોઈ પણ સંજોગોમાં, આ માળખાં બધાં સમાન રીતે બાંધવામાં આવે છે, અને તે આપણા માટે કંઈક અંશે વર્બોઝ છે.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// નોંધ લો કે આપણે અહીં ઇંગલિશિંગ નામના મેંગલિંગના નિયમોની અવગણના કરીએ છીએ: અમે સી X+ ને X0Rust0Z panics ને ફક્ત `struct rust_panic` ઘોષિત કરીને પકડવામાં સમર્થ થવા માંગતા નથી.
//
//
// ફેરફાર કરતી વખતે, ખાતરી કરો કે ટાઇપ નામની શબ્દમાળા `compiler/rustc_codegen_llvm/src/intrinsic.rs` માં વપરાયેલી સાથે બરાબર બંધબેસે છે.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // અહીં અગ્રણી `\x01` બાઇટ એ LLVM ને `_` કેરેક્ટર સાથે ઉપસર્જન જેવા અન્ય કોઈ મેંગલિંગને લાગુ ન કરવા માટે ખરેખર એક જાદુઈ સંકેત છે.
    //
    //
    // આ પ્રતીક એ સી ++ ના `std::type_info` દ્વારા વપરાયેલ વ vટેબલ છે.
    // પ્રકાર `std::type_info` ના પ્રકારનાં desબ્જેક્ટ્સ, પ્રકારનાં વર્ણનાત્મક, આ કોષ્ટકનો નિર્દેશક છે.
    // પ્રકારનાં વર્ણનાકર્તાઓને ઉપર નિર્ધારિત સી ++ ઇએચ સ્ટ્રક્ચર્સ દ્વારા સંદર્ભિત કરવામાં આવે છે અને અમે નીચે બાંધીએ છીએ.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// આ પ્રકારનું વર્ણનકર્તા ફક્ત જ્યારે અપવાદ ફેંકતા હોય ત્યારે વપરાય છે.
// કેચ ભાગ ટ્રાય ઇન્ટર્નિક દ્વારા નિયંત્રિત કરવામાં આવે છે, જે તેનું પોતાનું ટાઇપડેસ્ક્રિપ્ટર બનાવે છે.
//
// આ સારું છે કારણ કે એમએસવીસી રનટાઇમ નિર્દેશક સમાનતાને બદલે ટાઇપડેસ્ક્રિપ્ટર્સને મેચ કરવા માટે ટાઇપ નામ પર શબ્દમાળા તુલનાનો ઉપયોગ કરે છે.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// ડિસ્ટ્રક્ટરનો ઉપયોગ જો સી ++ કોડ અપવાદને કેપ્ચર કરવાનું નક્કી કરે છે અને તેનો પ્રચાર કર્યા વિના છોડે છે.
// પ્રયાસ આંતરિકનો કેચ ભાગ અપવાદ objectબ્જેક્ટનો પ્રથમ શબ્દ 0 પર સેટ કરશે જેથી તે ડિસ્ટ્રક્ટર દ્વારા છોડવામાં આવે.
//
// નોંધ લો કે x86 Windows ડિફ defaultલ્ટ "C" ક callingલિંગ સંમેલનને બદલે સી ++ સભ્ય કાર્યો માટે "thiscall" ક callingલિંગ સંમેલનનો ઉપયોગ કરે છે.
//
// અપવાદ_કોપી ફંક્શન અહીં થોડું વિશિષ્ટ છે: તે એમએસવીસી રનટાઈમ દ્વારા એક્સ એક્સએક્સએક્સ બ્લ blockક હેઠળ વિનંતી કરવામાં આવી છે અને ઝેડ 0 સ્પેનિક્સ ઝેડ જે આપણે અહીં જનરેટ કરીએ છીએ તે અપવાદની નકલના પરિણામ રૂપે ઉપયોગમાં લેવામાં આવશે.
//
// આનો ઉપયોગ સી ++ રનટાઇમ દ્વારા std::exception_ptr સાથેના અપવાદોને કેપ્ચર કરવાને ટેકો આપવા માટે થાય છે, જેને આપણે સમર્થન આપી શકતા નથી કારણ કે બ Boxક્સ<dyn Any>ક્લોનેબલ નથી.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _સીએક્સએક્સટીએક્સએક્સપ્શન સંપૂર્ણ રીતે આ સ્ટેક ફ્રેમ પર એક્ઝેક્યુટ કરે છે, તેથી અન્યથા `data` ને apગલામાં સ્થાનાંતરિત કરવાની જરૂર નથી.
    // અમે ફક્ત આ કાર્ય માટે સ્ટેક પોઇન્ટર પસાર કરીએ છીએ.
    //
    // મેન્યુઅલી ડ્રોપ અહીં આવશ્યક છે કારણ કે આપણે અનઇન્ડિંગ કરતી વખતે અપવાદને છોડી દેવા માંગતા નથી.
    // તેના બદલે તે અપવાદ_કાલીનઅપ દ્વારા છોડી દેવામાં આવશે જે સી ++ રનટાઇમ દ્વારા શરૂ કરવામાં આવશે.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // આ ... આશ્ચર્યજનક લાગે છે, અને વાજબી રૂપે.32-બીટ એમએસવીસી પર આ બંધારણ વચ્ચેના નિર્દેશકો ફક્ત તે જ છે, પોઇન્ટર.
    // 64-બીટ એમએસવીસી પર, તેમછતાં, સ્ટ્રક્ચર્સ વચ્ચેના પોઇન્ટર, `__ImageBase` થી 32-બીટ seફસેટ્સ તરીકે દર્શાવવામાં આવ્યા છે.
    //
    // પરિણામે, 32-બીટ એમએસવીસી પર અમે ઉપરના. સ્થિરસ્ત્રોમાં આ બધા પોઇન્ટર જાહેર કરી શકીએ છીએ.
    // -64-બીટ એમએસવીસી પર, આપણે સ્ટેટિક્સમાં પોઇંટરોના બાદબાકીને વ્યક્ત કરવી પડશે, જે ઝેડ રસ્ટ0 ઝેડ હાલમાં મંજૂરી આપતું નથી, તેથી અમે ખરેખર તે કરી શકતા નથી.
    //
    // આગળની શ્રેષ્ઠ વસ્તુ, તે પછી આ સ્ટ્રક્ચર્સને રનટાઈમ પર ભરવાની છે (ગભરાવું તે પહેલાથી જ "slow path" છે).
    // તેથી અહીં અમે આ બધા પોઇન્ટર ફીલ્ડ્સને 32-બીટ પૂર્ણાંકો તરીકે ફરીથી વ્યાખ્યાયિત કરીએ છીએ અને ત્યારબાદ તેમાં સંબંધિત મૂલ્ય સ્ટોર કરીએ છીએ (પરમાણુ રૂપે, એક સાથે ઝેડ 0 સ્પેનિક્સ 0 ઝેડ થઈ શકે છે).
    //
    // તકનીકી રૂપે રનટાઇમ આ ક્ષેત્રોનું સંભવત read વાંચન કરશે, પરંતુ સિદ્ધાંતમાં તેઓએ ક્યારેય *ખોટું* મૂલ્ય વાંચ્યું નથી તેથી તે ખૂબ ખરાબ હોવું જોઈએ નહીં ...
    //
    // કોઈ પણ સંજોગોમાં, આપણે સ્ટેટિક્સમાં વધુ કામગીરી વ્યક્ત ન કરી શકીએ ત્યાં સુધી આપણે મૂળરૂપે આવું કંઈક કરવાની જરૂર છે (અને આપણે ક્યારેય સક્ષમ નહીં હોઈ શકીએ).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // અહીં નૂલ પેલોડનો અર્થ છે કે અમે અહીં ___ રસ્ટટ્રીના (...) ના કેચમાંથી આવ્યા.
    // જ્યારે ઝેન-00 રસ્ટ0 ઝેડ વિદેશી અપવાદ પકડે છે ત્યારે આ થાય છે.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// કમ્પાઇલર દ્વારા અસ્તિત્વમાં રહેવા માટે આ જરૂરી છે (દા.ત., તે લેંગ આઇટમ છે), પરંતુ તે ખરેખર કમ્પાઈલર દ્વારા કદી કહેવામાં આવતું નથી કારણ કે __C_specific_handler અથવા _except_handler3 એ હંમેશાં વપરાયેલ વ્યક્તિત્વનું કાર્ય છે.
//
// તેથી આ માત્ર એક અવગણના કરતો સ્ટબ છે.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}