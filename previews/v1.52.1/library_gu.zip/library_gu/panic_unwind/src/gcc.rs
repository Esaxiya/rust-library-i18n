//! libgcc/libunwind (કેટલાક સ્વરૂપે) દ્વારા સમર્થિત panics ની અમલીકરણ.
//!
//! અપવાદને નિયંત્રિત કરવા અને સ્ટેક અનવંધીને લગતા પૃષ્ઠભૂમિ માટે, કૃપા કરીને "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) અને તેનાથી લિંક કરેલા દસ્તાવેજો જુઓ.
//! આ પણ સારા વાંચે છે:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ટૂંકું સાર
//!
//! અપવાદ હેન્ડલિંગ બે તબક્કામાં થાય છે: એક શોધ તબક્કો અને સફાઇ તબક્કો.
//!
//! બંને તબક્કામાં અનવિન્દર સ્ટેક ફ્રેમમાંથી વર્તમાન પ્રક્રિયાના મોડ્યુલોના વિભાગોને ખોલી નાખતી માહિતીનો ઉપયોગ કરીને ઉપરથી નીચે સ્ટેક ફ્રેમ્સ વksક કરે છે ("module" અહીં ઓએસ મોડ્યુલનો સંદર્ભ આપે છે, એટલે કે એક્ઝેક્યુટેબલ અથવા ડાયનેમિક લાઇબ્રેરી).
//!
//!
//! દરેક સ્ટેક ફ્રેમ માટે, તે સંલગ્ન "personality routine" ને બોલાવે છે, જેનું સરનામું પણ અનઇન્ડ માહિતી વિભાગમાં સંગ્રહિત છે.
//!
//! શોધના તબક્કામાં, વ્યક્તિત્વના રૂટિનનું કામ એ અપવાદ objectબ્જેક્ટ ફેંકી દેવામાં આવે છે તેની તપાસ કરવી અને તે સ્ટેક ફ્રેમમાં પકડવું જોઈએ કે કેમ તે નક્કી કરવું.એકવાર હેન્ડલર ફ્રેમની ઓળખ થઈ જાય, પછી સફાઇનો તબક્કો શરૂ થાય છે.
//!
//! સફાઇના તબક્કામાં, અનવિન્દર ફરીથી દરેક વ્યક્તિત્વના નિત્યક્રમને આમંત્રણ આપે છે.
//! આ સમયે તે નક્કી કરે છે કે વર્તમાન સ્ટેક ફ્રેમ માટે કયો (જો કોઈ હોય તો) ક્લીનઅપ કોડ ચલાવવાની જરૂર છે.જો એમ હોય તો, નિયંત્રણ ફંક્શન બ bodyડીમાં, ખાસ ઝેડ 0 ફ્રેન્ચ0 ઝેડ પર સ્થાનાંતરિત કરવામાં આવે છે, એક્સ 100 એક્સ, જે ડિસ્ટ્રક્ટરને બોલાવે છે, મેમરીને મુક્ત કરે છે, વગેરે.
//! લેન્ડિંગ પેડના અંતે, નિયંત્રણ અનવિંદર અને અનઇન્ડિંગ રિઝ્યુમ્સમાં પાછા સ્થાનાંતરિત થાય છે.
//!
//! એકવાર સ્ટેક હેન્ડલર ફ્રેમ સ્તરે અવિરત થઈ જાય, અનડિન્ડિંગ સ્ટોપ્સ અને છેલ્લા વ્યક્તિત્વના નિયમિત રૂપે કેચ બ્લ blockકમાં નિયંત્રણ સ્થાનાંતરિત થાય છે.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust નો અપવાદ વર્ગ ઓળખકર્તા.
// વ્યક્તિત્વના દિનચર્યાઓ દ્વારા આનો ઉપયોગ તે નક્કી કરવા માટે થાય છે કે શું અપવાદ તેમના પોતાના રનટાઈમ દ્વારા ફેંકી દેવામાં આવ્યો હતો.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 રસ્ટ-વિક્રેતા, ભાષા
    0x4d4f5a_00_52555354
}

// દરેક આર્કિટેક્ચર માટે રજિસ્ટર ID ને એલએલવીએમના TargetLowering::getExceptionPointerRegister() અને TargetLowering::getExceptionSelectorRegister() થી ઉપાડવામાં આવ્યા હતા, પછી રજિસ્ટર વ્યાખ્યા કોષ્ટકો (સામાન્ય રીતે<arch>નોંધણી કરાવો, "DwarfRegNum" માટે શોધ કરો).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register પણ જુઓ.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // ઇએએક્સ, ઇડીએક્સ

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // આરએક્સ, આરડીએક્સ

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// નીચેનો કોડ GCC ના સી અને સી ++ વ્યક્તિત્વના દિનચર્યાઓ પર આધારિત છે.સંદર્ભ માટે, જુઓ:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI વ્યક્તિત્વ નિયમિત.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS તે SjLj અનવિન્ડિંગનો ઉપયોગ કરે છે તેના બદલે ડિફ defaultલ્ટ રૂટિનનો ઉપયોગ કરે છે.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // એઆરએમ પરના બેકટ્રેસિસ રાજ્ય સાથેની વ્યક્તિત્વને નિયમિત કહેશે==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // તે સંજોગોમાં અમે સ્ટેકને અનિવાઈન્ડ કરવાનું ચાલુ રાખીએ છીએ, નહીં તો આપણા બધા બેક્રેસેસ __rust_try પર સમાપ્ત થાય છે
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // ડ્વાર્ફ અનવિન્દર ધારે છે કે _ઉનવિન્ડ_કોન્ટેક્સ્ટ ફંક્શન અને એલએસડીએ પોઇંટર્સ જેવી વસ્તુઓ ધરાવે છે, જો કે એઆરએમ એએબીએબીએ તેમને અપવાદ objectબ્જેક્ટમાં મૂકી છે.
            // _Unwind_GetLanguageSpecificData() જેવા કાર્યોની સહીઓ સાચવવા માટે, જે ફક્ત સંદર્ભ નિર્દેશક લે છે, GCC વ્યક્તિત્વ દિનચર્યા સંદર્ભમાં પોઇંટરને અપવાદો-વિષયમાં સંતાડે છે, એઆરએમના "scratch register" (r12) માટે આરક્ષિત સ્થાનનો ઉપયોગ કરીને.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... વધુ સિધ્ધાંતિક અભિગમ એ એઆરએમની _ઉનવિન્ડ_સંબંધની સંપૂર્ણ વ્યાખ્યા આપણી લિબનવિન્ડ બાઈન્ડિંગ્સમાં પ્રદાન કરવી અને ત્યાંથી સીધા જ, DWARF સુસંગતતા કાર્યોને બાયપાસ કરીને જરૂરી ડેટા લાવવાની રહેશે.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI એ અપવાદ objectબ્જેક્ટની અવરોધ કેશમાં એસપી મૂલ્યને અપડેટ કરવા માટે વ્યક્તિત્વની દિનચર્યાની આવશ્યકતા છે.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // એઆરએમ એએચબીઆઈ પર વ્યક્તિત્વની નિત્યક્રમ પાછા ફરતા પહેલા ખરેખર એક જ સ્ટેક ફ્રેમને અનડિઇન્ડ કરવા માટે જવાબદાર છે (એઆરએમ ઇએહાબી સે.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc માં વ્યાખ્યાયિત
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ડિફaultલ્ટ વ્યક્તિત્વનો નિયમિત, જે મોટાભાગના લક્ષ્યો પર અને આડકતરી રીતે એસઇએચ દ્વારા Windows x86_64 પર વપરાય છે.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 મિનડબ્લ્યુ લક્ષ્યો પર, અનઇન્ડિંગ મિકેનિઝમ એસઇએચ છે જોકે અનવિન્ડ હેન્ડલર ડેટા (ઉર્ફે એલએસડીએ) ઝેડ 0 સીસીસી 0 ઝેડ-સુસંગત એન્કોડિંગનો ઉપયોગ કરે છે.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // આપણા મોટાભાગના લક્ષ્યો માટે વ્યક્તિત્વની દિનચર્યા.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // વળતર સરનામું પોઇન્ટ્સ 1 બાઇટ ક theલ સૂચનાથી પાછલા, જે એલએસડીએ રેન્જ ટેબલમાં આગલી આઇપી રેન્જમાં હોઈ શકે.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ફ્રેમ અનઇન્ડ માહિતી નોંધણી
//
// દરેક મોડ્યુલની છબીમાં એક ફ્રેમ અનઇન્ડ માહિતી વિભાગ (સામાન્ય રીતે ".eh_frame") શામેલ હોય છે.જ્યારે મોડ્યુલ પ્રક્રિયામાં loaded/unloaded છે, ત્યારે અનવિન્દરને મેમરીમાં આ વિભાગના સ્થાન વિશે જાણ કરવી આવશ્યક છે.પ્લેટફોર્મ દ્વારા અલગ પડે છે તે પ્રાપ્ત કરવાની પદ્ધતિઓ.
// કેટલાક (દા.ત., Linux) પર, અનવિન્દર, જાતે જ અનઇન્ડ માહિતી વિભાગો શોધી શકે છે (ગતિશીલ રીતે હાલમાં લોડ થયેલ મોડ્યુલોને dl_iterate_phdr() API and finding their ".eh_frame" sections) દ્વારા ગણીને; અન્ય, Windows જેવા, અનવિંદર એપીઆઈ દ્વારા તેમના અનવિન્ડ માહિતી વિભાગોને સક્રિય રીતે રજીસ્ટર કરવા માટે મોડ્યુલોની જરૂર પડે છે.
//
//
// આ મોડ્યુલ બે પ્રતીકોને નિર્ધારિત કરે છે કે જે GCC રનટાઇમ સાથે અમારી માહિતીની નોંધણી કરવા માટે rsbegin.rs થી સંદર્ભિત અને ક calledલ કરવામાં આવે છે.
// સ્ટેક અનઇન્ડિંગનું અમલીકરણ (હમણાં માટે) લિબગસીસી_એહ માટે મુલતવી રાખવામાં આવ્યું છે, જો કે ઝેડ રસ્ટ0 ઝેડ ઝેક 0 ક્રેટ્સ 0 ઝેડ કોઈપણ ઝેડ 0 જીસીસી 0 ઝેડ રનટાઈમ સાથે સંભવિત અથડામણને ટાળવા માટે આ ઝેડ રસ્ટ0 ઝેડ-વિશિષ્ટ એન્ટ્રી પોઇન્ટનો ઉપયોગ કરે છે.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}