//! *ઇમ્સ્ક્રિપ્ટન* લક્ષ્ય માટે અનઇન્ડિંગ.
//!
//! જ્યારે ઝેડ રરસ્ટ0 ઝેડનો સામાન્ય અનડિન્ડિંગ અમલીકરણ, જે Unix પ્લેટફોર્મ્સ માટે સીધા જ લિબુનવિન્ડ એપીઆઇમાં ક callsલ કરે છે, એમ સ્ક્રિપ્ટિન પર અમે તેના બદલે સી ++ અનઇન્ડિંગ એપીઆઇમાં ક .લ કરીએ છીએ.
//! આ ફક્ત એક એક્સ્પેડિયન્સી છે કારણ કે એમસ્ક્રીપ્ટેનનો રનટાઇમ હંમેશાં તે API નો અમલ કરે છે અને લિબનવિન્ડને લાગુ કરતું નથી.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// આ સી ++ માં std::type_info ના લેઆઉટ સાથે મેળ ખાય છે
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // અહીં અગ્રણી `\x01` બાઇટ એ LLVM ને `_` કેરેક્ટર સાથે ઉપસર્જન જેવા અન્ય કોઈ મેંગલિંગને લાગુ ન કરવા માટે ખરેખર એક જાદુઈ સંકેત છે.
    //
    //
    // આ પ્રતીક એ સી ++ ના `std::type_info` દ્વારા વપરાયેલ વ vટેબલ છે.
    // પ્રકાર `std::type_info` ના પ્રકારનાં desબ્જેક્ટ્સ, પ્રકારનાં વર્ણનાત્મક, આ કોષ્ટકનો નિર્દેશક છે.
    // પ્રકારનાં વર્ણનાકર્તાઓને ઉપર નિર્ધારિત સી ++ ઇએચ સ્ટ્રક્ચર્સ દ્વારા સંદર્ભિત કરવામાં આવે છે અને અમે નીચે બાંધીએ છીએ.
    //
    // નોંધ લો કે વાસ્તવિક કદ 3 યુઝાઇઝ કરતા વધુ મોટું છે, પરંતુ અમારે ફક્ત ત્રીજા તત્વ તરફ નિર્દેશ કરવા માટે અમારા વ vટેબલની જરૂર છે.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info રસ્ટ_પેનિક વર્ગ માટે
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // સામાન્ય રીતે આપણે .as_ptr().add(2) નો ઉપયોગ કરીશું પરંતુ આ એક કોન્સ્ટ સંદર્ભમાં કામ કરતું નથી.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // આ ઇરાદાપૂર્વક સામાન્ય નામ મેંગલિંગ યોજનાનો ઉપયોગ કરતું નથી કારણ કે અમે સી ++ ઝેડ 0 રસ્ટ0 ઝેડ 0 ઝેડપાનિક્સ 0 ઝેડને ઉત્પન્ન કરવા અથવા પકડવા માટે સક્ષમ થવા માંગતા નથી.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // આ જરૂરી છે કારણ કે સી ++ કોડ અમારા એક્ઝેક્યુશનને std::exception_ptr સાથે કેપ્ચર કરી શકે છે અને તેને ઘણી વખત પુનthવિચારણા કરી શકે છે, કદાચ બીજા થ્રેડમાં પણ.
    //
    //
    caught: AtomicBool,

    // આને વિકલ્પ બનાવવાની જરૂર છે કારણ કે'sબ્જેક્ટનું જીવનકાળ સી ++ સિમેંટિક્સને અનુસરે છે: જ્યારે કેચ_અનવિન્ડ બ theક્સને અપવાદની બહાર ખસેડે છે ત્યારે તે અપવાદ objectબ્જેક્ટને માન્ય સ્થિતિમાં છોડી દેવી જ જોઇએ કારણ કે તેનો ડિસ્ટ્રક્ટર હજી પણ __cxa_end_catch દ્વારા ક beલ કરે છે.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try ખરેખર આપણને આ સ્ટ્રક્ચરનો નિર્દેશ આપે છે.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() ને panic ની મંજૂરી નથી, તેથી અમે તેના બદલે ફક્ત છોડી દેવું.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}