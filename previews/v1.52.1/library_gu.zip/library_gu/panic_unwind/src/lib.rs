//! ઝેડ 0 પindingનિક્સ 0 ઝેડની અમલીકરણ સ્ટેક અનઇન્ડિંગ દ્વારા
//!
//! આ ઝેડ 0 ક્રેટ 0 ઝેડ ઝેસ્ટ 0 રસ્ટ0 ઝેડમાં ઝેડ 0 પેનિક્સ 0 ઝેડનો અમલીકરણ છે જે "most native" સ્ટેક અનડિન્ડિંગ મિકેનિઝમનો ઉપયોગ કરીને પ્લેટફોર્મ માટે કમ્પાઈલ કરવામાં આવી રહ્યું છે.
//! આને હાલમાં ત્રણ ડોલમાં આવશ્યકરૂપે વર્ગીકૃત કરવામાં આવે છે:
//!
//! 1. એમએસવીસી લક્ષ્યો `seh.rs` ફાઇલમાં SEH નો ઉપયોગ કરે છે.
//! 2. ઇમ્સ્ક્રિપ્ટન `emcc.rs` ફાઇલમાં સી ++ અપવાદોનો ઉપયોગ કરે છે.
//! 3. અન્ય બધા લક્ષ્યો libunwind/libgcc એક્સ ફાઇલમાં libunwind/libgcc નો ઉપયોગ કરે છે.
//!
//! દરેક અમલીકરણ વિશે વધુ દસ્તાવેજો સંબંધિત મોડ્યુલમાં મળી શકે છે.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` મીરી સાથે બિનઉપયોગી છે, તેથી મૌન ચેતવણીઓ.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // ઝેડ રસ્ટ0 ઝેડ રનટાઈમની પ્રારંભિક objectsબ્જેક્ટ્સ આ પ્રતીકો પર આધારિત છે, તેથી તેમને સાર્વજનિક બનાવો.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // લક્ષ્યાંક કે જે અનિવાઈન્ડને સપોર્ટ કરતું નથી.
        // - arch=wasm32
        // - OS=કંઈ નથી ("bare metal" લક્ષ્યો)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // મીરી રનટાઇમનો ઉપયોગ કરો.
        // અમને હજી પણ ઉપરનો સામાન્ય રનટાઇમ લોડ કરવાની જરૂર છે, કારણ કે ઝેડ ર્રસ્ટક0 ઝેડ ત્યાંથી અમુક લ langંગ વસ્તુઓની વ્યાખ્યા કરે તેવી અપેક્ષા રાખે છે.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // વાસ્તવિક રનટાઇમનો ઉપયોગ કરો.
        use real_imp as imp;
    }
}

extern "C" {
    /// જ્યારે ઝેડ 0 સ્પેનિક્સ ઝેડ objectબ્જેક્ટને `catch_unwind` ની બહાર છોડી દેવામાં આવે ત્યારે લીબસ્ટેડમાં હેન્ડલર કહેવાતું.
    ///
    fn __rust_drop_panic() -> !;

    /// જ્યારે વિદેશી અપવાદ પકડાય ત્યારે લિબસ્ટીડમાં હેન્ડલર કહેવામાં આવે છે.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// અપવાદ વધારવા માટે પ્રવેશ બિંદુ, ફક્ત પ્લેટફોર્મ-વિશિષ્ટ અમલીકરણ માટેના પ્રતિનિધિઓ.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}