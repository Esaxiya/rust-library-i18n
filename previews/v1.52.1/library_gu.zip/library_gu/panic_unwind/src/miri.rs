//! મીરી માટે અનડિન્ડિંગ ઝેડ 0 પ .નિક્સ 0 ઝેડ.
use alloc::boxed::Box;
use core::any::Any;

// મીરી એન્જિન જે પ્રકારનો પેલોડ અમારા માટે અનઇન્ડિંગ દ્વારા ફેલાવે છે.
// પોઇન્ટર-કદનું હોવું આવશ્યક છે.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// અનિઇન્ડિંગ શરૂ કરવા માટે મીરી-પ્રદાન કરેલ બાહ્ય કાર્ય.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // અમે `miri_start_panic` પર જે પેલોડ પસાર કરીએ છીએ તે બરાબર દલીલ હશે જે આપણે નીચે `cleanup` માં મેળવીએ છીએ.
    // તેથી આપણે કંઈક પોઇન્ટર-સાઇઝ મેળવવા માટે તેને ફક્ત એકવાર બ upક્સ અપ કરીએ છીએ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // અંતર્ગત `Box` પુનoverપ્રાપ્ત કરો.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}