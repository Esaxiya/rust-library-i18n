// rsbegin.o અને rsend.o એ કહેવાતા "compiler runtime startup objects" છે.
// કમ્પાઇલર રનટાઇમને યોગ્ય રીતે પ્રારંભ કરવા માટે આવશ્યક કોડ શામેલ છે.
//
// જ્યારે એક્ઝેક્યુટેબલ અથવા ડાઇલીબ છબી જોડાયેલી હોય, ત્યારે આ બંને objectબ્જેક્ટ ફાઇલો વચ્ચેનો બધા વપરાશકર્તા કોડ અને લાઇબ્રેરીઓ "sandwiched" હોય છે, તેથી rsbegin.o નો કોડ અથવા ડેટા છબીના સંબંધિત ભાગોમાં પ્રથમ બને છે, જ્યારે rsend.o માંથી કોડ અને ડેટા છેલ્લી બને છે.
// આ અસરનો પ્રારંભિક અથવા વિભાગના અંતમાં પ્રતીકો મૂકવા માટે, તેમજ કોઈપણ જરૂરી હેડર અથવા ફૂટર દાખલ કરવા માટે વાપરી શકાય છે.
//
// નોંધ લો કે વાસ્તવિક મોડ્યુલ પ્રવેશ બિંદુ સી રનટાઇમ સ્ટાર્ટઅપ objectબ્જેક્ટ (સામાન્ય રીતે `crtX.o` કહેવામાં આવે છે) માં સ્થિત થયેલ છે, જે પછી અન્ય રનટાઇમ ઘટકોના પ્રારંભિક ક callલબksક્સની માંગ કરે છે (હજી સુધી અન્ય કોઈ વિશેષ છબી વિભાગ દ્વારા નોંધાયેલ છે).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // સ્ટેક ફ્રેમ અનવિન્ડ માહિતી વિભાગની શરૂઆતના ચિહ્નો
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // અનવિન્દરની આંતરિક બુક રાખવા માટે સ્ક્રેચ સ્પેસ.
    // આને 00 GCC/unwind-dw2-fde.h માં `struct object` તરીકે વ્યાખ્યાયિત કરવામાં આવી છે.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration માહિતીને અનઇન્ડ કરો.
    // લિબપicનિક_ અનવિન્ડના ડ docક્સ જુઓ.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // મોડ્યુલ સ્ટાર્ટઅપ પર અનઇન્ડ માહિતી રજીસ્ટર કરો
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // શટડાઉન પર નોંધણી રદ કરો
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // મિનડબ્લ્યુ-વિશિષ્ટ init/uninit રૂટિન નોંધણી
    pub mod mingw_init {
        // મીનડબ્લ્યુના સ્ટાર્ટઅપ objectsબ્જેક્ટ્સ (crt0.o/dllcrt0.o) .ctors અને .dtors વિભાગોમાં સ્ટાર્ટઅપ અને એક્ઝિટ પરના વૈશ્વિક કન્સ્ટ્રકટરોની વિનંતી કરશે.
        // ડીએલએલના કિસ્સામાં, જ્યારે ડીએલએલ લોડ અને અનલોડ કરવામાં આવે ત્યારે આ કરવામાં આવે છે.
        //
        // કડી કરનાર ભાગોને સ sortર્ટ કરશે, જે સુનિશ્ચિત કરે છે કે સૂચિના અંતમાં આપણી કbacલબbacક્સ સ્થિત છે.
        // કન્સ્ટ્રકટર્સ વિપરીત ક્રમમાં ચલાવવામાં આવતાં હોવાથી, આ ખાતરી કરે છે કે આપણી ક callલબbacક્સ પ્રથમ અને છેલ્લી ચલાવવામાં આવેલી છે.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: સી પ્રારંભિક ક callલબેક્સ
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .ડિટર્સ. *: સી ટર્મિનેશન ક callલબેક્સ
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}