//! `compiler-rt` લાઇબ્રેરીના પ્રોફાઇલર ભાગને કમ્પાઇલ કરે છે.
//!
//! વિગતો માટે લિબકમ્પ્લર_બિલ્ટીન્સ ઝેડક્રેટ 0 ઝેડ માટેના build.rs જુઓ.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` ડાયરેક્ટિવ્સ હાલમાં બહાર કા .વામાં આવ્યાં નથી અને બિલ્ડ સ્ક્રિપ્ટ
    // આ સ્રોત ફાઇલો અથવા તેમાં શામેલ હેડરોમાં પરિવર્તન પર ફરીથી ચાલશે નહીં.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // આ ફાઇલનું નામ એલએલવીએમ 10 માં રાખવામાં આવ્યું છે.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // આ ફાઇલો એલએલવીએમ 11 માં ઉમેરવામાં આવી હતી.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // એમએસવીસી પર વધારાની લાઇબ્રેરીઓ ખેંચશો નહીં
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc ની વિવિધ સુવિધાઓ અને આવા બંધ કરો, મોટે ભાગે કમ્પાઇલર-આરટીની બિલ્ડ સિસ્ટમની નકલ પહેલાથી જ છે
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // ધારો કે આપણે જે યુનિક્સનું નિર્માણ કરી રહ્યા છીએ તેમાં fnctl() ઉપલબ્ધ છે
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS ક્યારે સેટ કરવા તે માટે આ ખૂબ સરસ ઉપચારાત્મક હોવું જોઈએ
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // નોંધો કે જો આપણે ચલાવવા જઈશું તો આ અસ્તિત્વમાં હોવું જોઈએ (અન્યથા આપણે પ્રોફાઇલર બિલ્ટિન્સ બિલકુલ બનાવતા નથી).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}