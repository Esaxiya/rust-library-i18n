# `rustc-std-workspace-std` crate

Погледнете ја документацијата за `rustc-std-workspace-core` crate.