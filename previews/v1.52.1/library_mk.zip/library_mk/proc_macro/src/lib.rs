//! Библиотека за поддршка на макроавтори при дефинирање на нови макроа.
//!
//! Оваа библиотека, обезбедена од стандардната дистрибуција, обезбедува типови потрошени во интерфејсите на процедурално дефинирани макро дефиниции, како што се макроата слични на функциите `#[proc_macro]`, макро атрибутите `#[proc_macro_attribute]` и прилагодените атрибути на изведбата "#[proc_macro_derive]".
//!
//!
//! Погледнете [the book] за повеќе.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Одредува дали proc_macro е достапен за тековната програма.
///
/// Proc_macro crate е наменет само за употреба во спроведувањето на процедуралните макроа.Сите функции во овој crate panic ако се повикани однадвор на процедурално макро, како на пример од скрипта за градење или тест единица или обичен бинарен Rust.
///
/// Со оглед на библиотеките Rust кои се дизајнирани да поддржуваат случаи и за макро и за макро употреба, `proc_macro::is_available()` обезбедува начин без паника да открие дали е моментално достапна инфраструктурата потребна за користење на API на proc_macro.
/// Враќа вистинито ако се повика од внатрешноста на процедуралното макро, неточно ако се повика од кое било друго бинарно подрачје.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Главниот тип обезбеден од овој crate, што претставува апстрактен проток на tokens, или, поточно, низа од дрвја token.
/// Типот обезбедува интерфејси за повторување над тие дрвја token и, обратно, собирајќи голем број дрвја token во еден поток.
///
///
/// Ова е и влез и излез на дефинициите `#[proc_macro]`, `#[proc_macro_attribute]` и `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Грешка вратена од `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Враќа празен `TokenStream` кој не содржи дрвја token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Проверува дали овој `TokenStream` е празен.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Обидите да се пробие низата во tokens и да се анализираат тие tokens во поток token.
/// Може да пропадне од повеќе причини, на пример, ако низата содржи неизбалансирани разграничувачи или карактери што не постојат на јазикот.
///
/// Сите tokens во парсиран проток добиваат `Span::call_site()` распони.
///
/// NOTE: некои грешки може да предизвикаат panics наместо да го вратат `LexError`.Го задржуваме правото да ги смениме овие грешки во `LexError` подоцна.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Го печати потокот token како низа за која се претпоставува дека може да се претвори во загуба без загуба во истиот поток token (распон на модули), освен евентуално `TokenTree: : Group`s со разграничувачи `Delimiter::None` и негативни нумерички букви.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Печати token во форма погодна за дебагирање.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Создава поток token што содржи едно token дрво.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Собира голем број дрвја token во еден поток.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Една операција "flattening" на потоците token, собира дрвја token од повеќе потоци token во еден поток.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Користете оптимизирана имплементација if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Јавни детали за имплементација за типот `TokenStream`, како што се повторувачи.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Итератор над `TokenTree` на`TokenStream`.
    /// Повторувањето е "shallow", на пример, повторувачот не се повлекува во разграничени групи и враќа цели групи како дрвја token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` прифаќа произволно tokens и се шири во `TokenStream` опишувајќи го влезот.
/// На пример, `quote!(a + b)` ќе произведе израз, кој, кога ќе се оцени, ги конструира `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Отстранувањето е направено со `$` и работи со преземање на единствениот следен идентитет како нецитиран поим.
/// За да го цитирате самиот `$`, користете `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Регион на изворен код, заедно со информации за макро проширување.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Создава нов `Diagnostic` со дадениот `message` на распон `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Опсег што се решава на страницата за макро дефинирање.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Просторот на повикување на тековната процедурална макро.
    /// Идентификаторите создадени со овој распон ќе бидат решени како да се напишани директно на локацијата за макро повик (хигиена на страницата за повици) и другиот код на страницата за макро повик ќе може да се однесува и на нив.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Опсег што претставува хигиена на `macro_rules`, а понекогаш се решава на страницата за макро дефинирање (локални променливи, етикети, `$crate`), а понекогаш и на страницата за макро повици (сè друго).
    ///
    /// Локацијата на распонот е преземена од страницата за повици.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Оригиналната изворна датотека во која се посочува овој распон.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` за tokens во претходната макро експанзија од која беше генериран `self`, доколку ги има.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Опсегот на изворниот код од кој е генериран `self`.
    /// Ако овој `Span` не е генериран од други макро проширувања, тогаш повратната вредност е иста како `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Го добива почетниот line/column во изворната датотека за овој распон.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Добива крај line/column во изворната датотека за овој распон.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Создава нов распон кој ги опфаќа `self` и `other`.
    ///
    /// Враќа `None` ако `self` и `other` се од различни датотеки.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Создава нов распон со истата информација line/column како `self`, но тоа ги решава симболите како да се на `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Создава нов распон со исто однесување со резолуција на име како `self`, но со информациите line/column на `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Споредува со распоните за да види дали се еднакви.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Го враќа изворниот текст зад распон.
    /// Ова го зачувува оригиналниот изворен код, вклучувајќи празни места и коментари.
    /// Враќа резултат само ако распонот одговара на реалниот изворен код.
    ///
    /// Note: Забележливиот резултат на макро треба да се потпира само на tokens, а не на овој изворен текст.
    ///
    /// Резултатот од оваа функција е најголем напор да се користи само за дијагностика.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Печати распон во форма погодна за дебагирање.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Парен ред-колона што претставува почеток или крај на `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-индексираната линија во изворната датотека на која распонот започнува или завршува (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Индексираната колона 0 (со знаци UTF-8) во изворната датотека на која распонот започнува или завршува (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Изворната датотека на даден `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ја добива патеката до оваа изворна датотека.
    ///
    /// ### Note
    /// Ако распонот на кодови поврзан со овој `SourceFile` е генериран од надворешно макро, ова макро, ова можеби не е вистинска патека на системот на датотеки.
    /// Користете [`is_real`] за да проверите.
    ///
    /// Исто така, забележете дека дури и ако `is_real` врати `true`, ако `--remap-path-prefix` е донесен на командната линија, патеката како што е дадена можеби не е валидна.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Враќа `true` ако оваа изворна датотека е вистинска изворна датотека и не е генерирана од експанзија на надворешно макро.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ова е пробив сè додека не се имплементираат интеркратните распони и можеме да имаме вистински изворни датотеки за распони генерирани во надворешни макроа.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Еден token или ограничена низа token дрвја (на пример, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Поток token опкружен со разграничувачи на загради.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Идентификатор.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Единствен карактер на интерпункција (`+ ', `,`, `$`, итн.)
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Буквален карактер (`'a'`), низа (`"hello"`), број (`2.3`) итн.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Го враќа распонот на ова дрво, делегирајќи се на методот `span` на содржаниот token или ограничен поток.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Конфигурира распон за *само овој token*.
    ///
    /// Забележете дека ако овој token е `Group`, тогаш овој метод нема да го конфигурира распонот на секоја од внатрешните tokens, ова едноставно ќе делегира на методот `set_span` на секоја варијанта.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Печати дрво token во форма погодна за дебагирање.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Секој од нив го има името во типот на структурата во изведеното дебагирање, затоа не се оптеретувајте со дополнителен слој на индирекција
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Го печати дрвото token како низа што се претпоставува дека може без загуби да се претвори во истото дрво token (распон на модули), освен евентуално `TokenTree: : Group`s со разграничувачи `Delimiter::None` и негативни нумерички букви.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ограничен поток token.
///
/// `Group` внатрешно содржи `TokenStream` кој е опкружен со `Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Опишува како се разграничува низа од дрвја token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Имплицитен разграничувач, кој може, на пример, да се појави околу tokens кој доаѓа од "macro variable" `$var`.
    /// Важно е да се зачуваат приоритетите на операторот во случаи како `$var * 3` каде `$var` е `1 + 2`.
    /// Имплицитните разграничувачи може да не преживеат во тркалезна патека на поток token низ низа.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Создава нов `Group` со дадениот разграничувач и поток token.
    ///
    /// Овој конструктор ќе го постави распонот на оваа група на `Span::call_site()`.
    /// За да го промените распонот, можете да го користите методот `set_span` подолу.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Го враќа разделувачот на овој `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Враќа `TokenStream` на tokens што се ограничени во овој `Group`.
    ///
    /// Забележете дека вратениот поток token не вклучува разграничувач вратен погоре.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Го враќа распонот за раздвојувачите на овој поток token, опфаќајќи го целиот `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Го враќа распонот покажувајќи на разграничувачот на почетната група.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Го враќа распонот покажувајќи на разграничувачот на затворање на оваа група.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Конфигурира распон за разграничувачи на оваа `Група`, но не и за нејзините внатрешни tokens.
    ///
    /// Овој метод нема ** да го постави распонот на сите внатрешни tokens опфатени од оваа група, туку напротив, тој ќе го постави само распонот на разграничувачот tokens на ниво на `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ја печати групата како низа што треба да се претвори во загуба без загуби во истата група (модули), освен за `TokenTree: : Group` со разграничувачи `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` е единствен карактер на интерпункција како `+`, `-` или `#`.
///
/// Оператори со повеќе карактери како `+=` се претставени како два примери на `Punct` со различни форми на `Spacing` вратени.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Дали `Punct` е веднаш следен од друг `Punct` или следен од друг token или бел простор.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// на пример, `+` е `Alone` во `+ =`, `+ident` или `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// на пример, `+` е `Joint` во `+=` или `'#`.
    /// Дополнително, единечен понуда `'` може да се приклучи со идентификатори за да формира животно време `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Создава нов `Punct` од дадениот карактер и проред.
    /// Аргументот `ch` мора да биде валиден карактер на интерпункција дозволен од јазикот, во спротивно функцијата ќе биде panic.
    ///
    /// Вратениот `Punct` ќе го има стандардниот распон на `Span::call_site()` што може дополнително да се конфигурира со методот `set_span` подолу.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ја враќа вредноста на овој карактер на интерпункција како `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Го враќа растојанието на овој карактер на интерпункција, што покажува дали веднаш следи друг `Punct` во потокот token, така што тие потенцијално може да се комбинираат во оператор со повеќе карактери (`Joint`), или по него следи некој друг token или бел простор (`Alone`), така што операторот сигурно има заврши
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Го враќа распонот за овој карактер на интерпункција.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Конфигурирајте го распонот за овој карактер на интерпункција.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Го печати карактерот на интерпункција како низа што треба да се претвори во загуба без загуби во истиот знак.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Идентификатор (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Создава нов `Ident` со дадениот `string` како и наведениот `span`.
    /// Аргументот `string` мора да биде валиден идентификатор дозволен од јазикот (вклучувајќи клучни зборови, на пр. `self` или `fn`).Во спротивно, функцијата ќе биде panic.
    ///
    /// Забележете дека `span`, моментално во rustc, ги конфигурира хигиенските информации за овој идентификатор.
    ///
    /// Од овој пат, `Span::call_site()` експлицитно се определува за хигиена "call-site", што значи дека идентификаторите создадени со овој распон ќе бидат решени како да се напишани директно на локацијата на макро повикот, а другиот код на страницата за макро повик ќе може да се однесува на исто така и нив.
    ///
    ///
    /// Подоцнежните опсези како `Span::def_site()` ќе овозможат да се вклучат во хигиената "definition-site", што значи дека идентификаторите создадени со овој распон ќе бидат решени на локацијата на макро дефиницијата и другиот код на страницата за макро повик нема да може да се однесува на нив.
    ///
    /// Поради сегашната важност на хигиената, овој конструктор, за разлика од другите tokens, бара `Span` да биде наведен при конструкцијата.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Исто како `Ident::new`, но создава суров идентификатор (`r#ident`).
    /// Аргументот `string` е валиден идентификатор дозволен од јазикот (вклучувајќи клучни зборови, на пр. `fn`).
    /// Клучни зборови што се употребливи во сегментите на патеките (на пр
    /// `self`, `super`) не се поддржани и ќе предизвикаат panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Го враќа распонот на овој `Ident`, опфаќајќи ја целата низа вратена од [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Конфигурира распон на овој `Ident`, веројатно менувајќи го неговиот хигиенски контекст.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Го печати идентификаторот како низа што треба да се претвори во загуба без загуби во истиот идентификатор.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Буквална низа (`"hello"`), бајт низа (`b"hello"`), карактер (`'a'`), бајт карактер (`b'a'`), цел број или подвижна точка со или без наставка (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Буловите буквали како `true` и `false` не припаѓаат тука, тие се `Ident` s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Создава нов суфикс цел број буквален со наведената вредност.
        ///
        /// Оваа функција ќе создаде цел број како `1u32` каде што определената цел број е првиот дел од token и интегралот исто така се суфиксира на крајот.
        /// Буквите создадени од негативни броеви може да не преживеат кружни патувања низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
        ///
        ///
        /// Буквалите создадени преку овој метод имаат стандардно распон на `Span::call_site()`, што може да се конфигурира со методот `set_span` подолу.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Создава нов несуфициран цел број буквален со наведената вредност.
        ///
        /// Оваа функција ќе создаде цел број како `1` каде што наведената цел број е првиот дел од token.
        /// Ниту една наставка не е наведена на овој token, што значи дека повиците како `Literal::i8_unsuffixed(1)` се еквивалентни на `Literal::u32_unsuffixed(1)`.
        /// Буквите создадени од негативни броеви може да не преживеат реприза низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
        ///
        ///
        /// Буквалите создадени преку овој метод имаат стандардно распон на `Span::call_site()`, што може да се конфигурира со методот `set_span` подолу.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Создава нова несуфицирана буквална подвижна точка.
    ///
    /// Овој конструктор е сличен на оној како `Literal::i8_unsuffixed` каде што вредноста на пловичката се емитува директно во token но не се користи додавка, па затоа може да се заклучи дека е `f64` подоцна во компајлерот.
    ///
    /// Буквите создадени од негативни броеви може да не преживеат реприза низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
    ///
    /// # Panics
    ///
    /// Оваа функција бара одредениот плови да биде конечен, на пример, ако е бесконечност или NaN оваа функција ќе биде panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Создава нова наставка со подвижна буква буква.
    ///
    /// Овој конструктор ќе создаде буквална буква како `1.0f32` каде што наведената вредност е претходниот дел на token и `f32` е наставка на token.
    /// Овој token секогаш ќе се заклучи дека е `f32` во компајлерот.
    /// Буквите создадени од негативни броеви може да не преживеат реприза низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
    ///
    ///
    /// # Panics
    ///
    /// Оваа функција бара одредениот плови да биде конечен, на пример, ако е бесконечност или NaN оваа функција ќе биде panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Создава нова несуфицирана буквална подвижна точка.
    ///
    /// Овој конструктор е сличен на оној како `Literal::i8_unsuffixed` каде што вредноста на пловичката се емитува директно во token но не се користи додавка, па затоа може да се заклучи дека е `f64` подоцна во компајлерот.
    ///
    /// Буквите создадени од негативни броеви може да не преживеат реприза низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
    ///
    /// # Panics
    ///
    /// Оваа функција бара одредениот плови да биде конечен, на пример, ако е бесконечност или NaN оваа функција ќе биде panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Создава нова наставка со подвижна буква буква.
    ///
    /// Овој конструктор ќе создаде буквална буква како `1.0f64` каде што наведената вредност е претходниот дел на token и `f64` е наставка на token.
    /// Овој token секогаш ќе се заклучи дека е `f64` во компајлерот.
    /// Буквите создадени од негативни броеви може да не преживеат реприза низ `TokenStream` или жици и може да се поделат на два tokens (`-` и позитивна буква).
    ///
    ///
    /// # Panics
    ///
    /// Оваа функција бара одредениот плови да биде конечен, на пример, ако е бесконечност или NaN оваа функција ќе биде panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Стринг буквално.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Карактер буквален.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Бајт низа буквална.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Го враќа распонот опфаќајќи ја оваа буквална.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Конфигурира распон поврзан за оваа буквална.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Враќа `Span` што е подмножество на `self.span()` што содржи само изворни бајти во опсег `range`.
    /// Враќа `None` ако посакуваниот распон е надвор од границите на `self`.
    ///
    // FIXME(SergioBenitez): проверете дали опсегот на бајти започнува и завршува на границата UTF-8 на изворот.
    // во спротивно, веројатно е дека panic ќе се појави на друго место кога ќе се отпечати изворниот текст.
    // FIXME(SergioBenitez): нема начин корисникот да знае на што всушност мапира `self.span()`, така што овој метод во моментов може да се нарече само слепо.
    // На пример, `to_string()` за карактерот 'c' враќа "'\u{63}'";нема начин корисникот да знае дали изворниот текст бил 'c' или дали бил '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) нешто слично на `Option::cloned`, но за `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Забелешка, мостот обезбедува само `to_string`, имплементирајте `fmt::Display` врз основа на него (обратна од вообичаената врска помеѓу нив).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ја печати буквалната како низа што треба да се претвори во загуба без загуби во истата буква (освен за можно заокружување на буквали со подвижна точка).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Следен пристап до променливите на околината.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Вратете ја променливата за околината и додајте ја за да изградите информации за зависност.
    /// Системот за изградба што го извршува компајлерот ќе знае дека до променливата се пристапи за време на компилацијата и ќе може да се повтори изградбата кога ќе се смени вредноста на таа променлива.
    ///
    /// Покрај следењето на зависност, оваа функција треба да биде еквивалентна на `env::var` од стандардната библиотека, освен што аргументот мора да биде UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}