# `rustc-std-workspace-core` crate

Овој crate е сјаен и празен crate кој едноставно зависи од `libcore` и ја реекспортира целата нејзина содржина.
crate е суштината на зајакнување на стандардната библиотека да зависи од crates од crates.io

Crates на crates.io дека стандардната библиотека зависи од тоа да зависи од `rustc-std-workspace-core` crate од crates.io, кој е празен.

Ние користиме `[patch]` за да го надминеме во овој crate во ова складиште.
Како резултат, crates на crates.io ќе повлече зависност edge до `libcore`, верзијата дефинирана во ова складиште.
Тоа треба да ги повлече сите рабови на зависност за да се осигури дека Cargo успешно го гради crates!

Забележете дека crates на crates.io треба да зависи од овој crate со името `core` за сè да работи правилно.За да го направат тоа, тие можат да користат:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Преку употреба на копчето `package`, crate се преименува во `core`, што значи дека ќе изгледа

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

кога Cargo го повикува компајлерот, задоволувајќи ја имплицитната директива `extern crate core` инјектирана од компајлерот.




