// rsbegin.o и rsend.o се т.н. "compiler runtime startup objects".
// Тие содржат код потребен за правилно иницијализирање на времето на траење на компајлерот.
//
// Кога е поврзана извршна слика или dylib, сите кориснички кодови и библиотеки се "sandwiched" помеѓу овие две датотеки со објекти, така што кодот или податоците од rsbegin.o стануваат први во соодветните делови на сликата, додека кодот и податоците од rsend.o стануваат последни.
// Овој ефект може да се користи за поставување симболи на почетокот или на крајот од делот, како и за вметнување на сите потребни заглавија или подножја.
//
// Забележете дека вистинската влезна точка на модулот се наоѓа во објектот за стартување во траење C (обично се нарекува `crtX.o`), кој потоа се повикува на повици за иницијализација на другите компоненти за време на траење (регистрирани преку друг посебен дел за слика).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Обележува почеток на рамката за магацинот одмотајте го делот за информации
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Простор за гребење за внатрешно водење книги.
    // Ова е дефинирано како `struct object` во $ GCC/libgcc/развивам-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Одвртете ги рутините со информации за registration/deregistration.
    // Погледнете ги документите за libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // регистрирајте ги одмотувајте информации за стартување на модулот
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // откажете се од исклучување
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Рутинска регистрација специфична за MinGW init/uninit
    pub mod mingw_init {
        // Стартните објекти на MinGW (crt0.o/dllcrt0.o) ќе се повикаат на глобалните конструктори во деловите .ctors и .dtors при стартување и излез.
        // Во случај на DLL, ова се прави кога DLL се вчитува и истоварува.
        //
        // Линкерот ќе ги сортира деловите, што гарантира дека нашите повратни информации се наоѓаат на крајот од списокот.
        // Бидејќи конструкторите се извршуваат во обратен редослед, ова осигурува дека нашите повратен повик се првите и последните извршени.
        //
        //

        #[link_section = ".ctors.65535"] // .ктори: *: Повратни информации за иницијализација на C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .доктори. *: Повратни информации за завршување на Ц.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}