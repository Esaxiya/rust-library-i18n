//! Traits за конверзии помеѓу типови.
//!
//! traits во овој модул обезбедува начин за претворање од еден во друг тип.
//! Секој trait служи за различна намена:
//!
//! - Имплементирајте [`AsRef`] trait за ефтини конверзии од референца до референца
//! - Имплементирајте [`AsMut`] trait за ефтини конверзии што може да се менуваат во мутабилни
//! - Имплементирајте [`From`] trait за трошење конверзии од вредност во вредност
//! - Имплементирајте [`Into`] trait за трошење конверзии од вредност до вредност во типови надвор од тековната crate
//! - [`TryFrom`] и [`TryInto`] traits се однесуваат како [`From`] и [`Into`], но треба да се спроведат кога конверзијата може да пропадне.
//!
//! traits во овој модул често се користат како trait bounds за генерички функции, така што се поддржани аргументи од повеќе типови.Погледнете ја документацијата за секој trait за примери.
//!
//! Како автор на библиотека, секогаш треба да претпочитате да ги имплементирате [`From<T>`][`From`] или [`TryFrom<T>`][`TryFrom`] отколку [`Into<U>`][`Into`] или [`TryInto<U>`][`TryInto`], бидејќи [`From`] и [`TryFrom`] обезбедуваат поголема флексибилност и нудат еквивалентни имплементации [`Into`] или [`TryInto`] бесплатно, благодарение на имплементација на ќебе во стандардната библиотека.
//! Кога таргетирате верзија пред Rust 1.41, можеби ќе треба да се имплементираат [`Into`] или [`TryInto`] директно при конвертирање во тип надвор од сегашниот crate.
//!
//! # Општи имплементации
//!
//! - [`AsRef`] и автоматско пренасочување [`AsMut`] ако внатрешниот тип е референца
//! - [" Од`] " <U>за</u> Т` <U>подразбира [" Во`]`</u><T><U>за У`</u>
//! - [`TryFrom`]`<U>за T` подразбира [`TryInto`] '</u><T><U>за У`</u>
//! - [`From`] и [`Into`] се рефлексивни, што значи дека сите типови можат самите `into` и самите `from`
//!
//! Погледнете го секој trait за примери за употреба.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функција на идентитет.
///
/// Две работи се важни да се забележат за оваа функција:
///
/// - Тоа не е секогаш еквивалентно на затворање како `|x| x`, бидејќи затворањето може да го принуди `x` во друг тип.
///
/// - Го поместува влезот `x` пренесен на функцијата.
///
/// Иако може да изгледа чудно да имате функција што само го враќа влезот, има неколку интересни употреби.
///
///
/// # Examples
///
/// Користење на `identity` за да не правите ништо во низа други, интересни функции:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Да се преправаме дека додавањето на една е интересна функција.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Користење на `identity` како основна кутија "do nothing" во условно:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Направете поинтересни работи ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Користење на `identity` за да ги задржите варијантите `Some` на повторувач на `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Се користи за да се направи ефтина конверзија од референца до референца.
///
/// Овој trait е сличен на [`AsMut`] кој се користи за конвертирање помеѓу променливи референци.
/// Ако треба да направите скапа конверзија, подобро е да го имплементирате [`From`] со тип `&T` или да напишете сопствена функција.
///
/// `AsRef` има ист потпис како [`Borrow`], но [`Borrow`] е различен во неколку аспекти:
///
/// - За разлика од `AsRef`, [`Borrow`] има ќебе за секој `T` и може да се користи за прифаќање или референца или вредност.
/// - [`Borrow`] исто така, бара [`Hash`], [`Eq`] и [`Ord`] за позајмената вредност да бидат еквивалентни на оние со сопственичка вредност.
/// Поради оваа причина, ако сакате да позајмите само едно поле на структурата, можете да го имплементирате `AsRef`, но не и [`Borrow`].
///
/// **Note: Овој trait не смее да пропадне **.Ако конверзијата не успее, користете посветен метод што враќа [`Option<T>`] или [`Result<T, E>`].
///
/// # Општи имплементации
///
/// - `AsRef` автоматско пренасочување ако внатрешниот тип е референца или променлива референца (на пр.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Со користење на trait bounds можеме да прифатиме аргументи од различни типови сè додека тие можат да се претворат во наведениот тип `T`.
///
/// На пример: Со создавање на општа функција што зема `AsRef<str>`, изразуваме дека сакаме да ги прифатиме сите референци што можат да се претворат во [`&str`] како аргумент.
/// Бидејќи и [`String`] и [`&str`] спроведуваат `AsRef<str>`, можеме да ги прифатиме и двете како аргумент за влез.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ја извршува конверзијата.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Се користи за да се направи ефтина референтна конверзија што може да се менува во мутабилна.
///
/// Овој trait е сличен на [`AsRef`], но се користи за конвертирање помеѓу менливи референци.
/// Ако треба да направите скапа конверзија, подобро е да го имплементирате [`From`] со тип `&mut T` или да напишете сопствена функција.
///
/// **Note: Овој trait не смее да пропадне **.Ако конверзијата не успее, користете посветен метод што враќа [`Option<T>`] или [`Result<T, E>`].
///
/// # Општи имплементации
///
/// - `AsMut` автоматско пренасочување ако внатрешниот тип е изменлива референца (на пр.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Користејќи го `AsMut` како trait bound за генеричка функција, можеме да ги прифатиме сите непроменливи референци што можат да се претворат во тип `&mut T`.
/// Бидејќи [`Box<T>`] спроведува `AsMut<T>`, можеме да напишеме функција `add_one` што ги зема сите аргументи што можат да се претворат во `&mut u64`.
/// Бидејќи [`Box<T>`] спроведува `AsMut<T>`, `add_one` прифаќа аргументи од типот `&mut Box<u64>` исто така:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ја извршува конверзијата.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Конверзија вредност во вредност што ја троши влезната вредност.Спротивно на [`From`].
///
/// Треба да се избегне имплементација на [`Into`] и наместо тоа да се имплементира [`From`].
/// Спроведувањето на [`From`] автоматски обезбедува еден со имплементација на [`Into`] благодарение на имплементацијата на ќебето во стандардната библиотека.
///
/// Претпочитајте да користите [`Into`] наместо [`From`] кога одредувате trait bounds на општа функција за да се осигурате дека може да се користат и типови што само го спроведуваат [`Into`].
///
/// **Note: Овој trait не смее да пропадне **.Ако конверзијата не успее, користете [`TryInto`].
///
/// # Општи имплементации
///
/// - ["Од"] "<T>за U` подразбира `Into<U> for T`
/// - [`Into`] е рефлексивен, што значи дека `Into<T> for T` е имплементиран
///
/// # Имплементација на [`Into`] за конверзии во надворешни типови во старите верзии на Rust
///
/// Пред Rust 1.41, ако типот на дестинација не беше дел од тековниот crate, тогаш не можевте директно да го имплементирате [`From`].
/// На пример, земете го овој код:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ова нема да успее да се состави во постарите верзии на јазикот бидејќи правилата за сирачиња на Rust порано беа малку построги.
/// За да го заобиколите ова, можете директно да го имплементирате [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Важно е да се разбере дека [`Into`] не обезбедува [`From`] имплементација (како [`From`] со [`Into`]).
/// Затоа, секогаш треба да се обидете да го имплементирате [`From`], а потоа да се вратите на [`Into`] ако [`From`] не може да се спроведе.
///
/// # Examples
///
/// [`String`] имплементира ["Во"] "<" ["Вец"] "<" ["u8"] ">>:
///
/// Со цел да изразиме дека сакаме генеричка функција да ги земе сите аргументи што можат да се претворат во одреден тип `T`, можеме да користиме trait bound од ["Into"]<T>`
///
/// На пример: Функцијата `is_hello` ги зема сите аргументи што можат да се претворат во [`Vec`]``` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ``88```` ```` `.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ја извршува конверзијата.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Се користи за вршење на конверзии од вредност во вредност при трошење на влезната вредност.Тоа е реципроцитет на [`Into`].
///
/// Секогаш треба да се претпочита имплементирање на `From` отколку [`Into`] затоа што имплементацијата на `From` автоматски му овозможува имплементација на [`Into`] благодарение на имплементацијата на ќебето во стандардната библиотека.
///
///
/// Имплементирајте [`Into`] само кога таргетирате верзија пред Rust 1.41 и претворате во тип надвор од сегашниот crate.
/// `From` не беше во можност да ги направи овие типови на конверзии во претходните верзии поради правилата за сирачиња на Rust.
/// Погледнете [`Into`] за повеќе детали.
///
/// Претпочитајте да го користите [`Into`] наместо `From` кога одредувате trait bounds на општа функција.
/// На овој начин, типовите кои директно го спроведуваат [`Into`] може да се користат и како аргументи.
///
/// `From` е исто така многу корисен при вршење ракување со грешки.Кога се конструира функција што е способна да не успее, типот на поврат генерално ќе биде од формата `Result<T, E>`.
/// `From` trait го поедноставува управувањето со грешките со дозволување на функција да врати еден тип на грешка што вметнува повеќе типови грешки.Погледнете во делот "Examples" и [the book][book] за повеќе детали.
///
/// **Note: Овој trait не смее да пропадне **.Ако конверзијата не успее, користете [`TryFrom`].
///
/// # Општи имплементации
///
/// - `From<T> for U` имплицира [" Во`] <U>за Т`</u>
/// - `From` е рефлексивен, што значи дека `From<T> for T` е имплементиран
///
/// # Examples
///
/// [`String`] спроведува `From<&str>`:
///
/// Експлицитна конверзија од `&str` во низа се прави на следниов начин:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Додека извршувате ракување со грешки, често е корисно да се имплементира `From` за вашиот тип на грешка.
/// Преобразувајќи ги основните типови на грешки во наш сопствен прилагоден тип на грешка што го инкапсулира основниот тип на грешка, можеме да вратиме еден вид грешка без да изгубиме информации за основната причина.
/// Операторот '?' автоматски го претвора основниот тип на грешка во наш прилагоден тип грешка со повикување на `Into<CliError>::into`, кој автоматски се обезбедува при спроведување на `From`.
/// Компајлерот потоа заклучува која имплементација на `Into` треба да се користи.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ја извршува конверзијата.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Обид за конверзија што троши `self`, што може да биде скапо или не.
///
/// Авторите на библиотеката обично не треба директно да го спроведуваат овој trait, но треба да претпочитаат имплементација на [`TryFrom`] trait, кој нуди поголема флексибилност и обезбедува еквивалентна имплементација `TryInto` бесплатно, благодарение на имплементација на ќебе во стандардната библиотека.
/// За повеќе информации во врска со ова, видете ја документацијата за [`Into`].
///
/// # Спроведување на `TryInto`
///
/// Ова ги трпи истите ограничувања и размислувања како и спроведувањето на [`Into`], видете таму за детали.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Типот вратен во случај на грешка при конверзија.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ја извршува конверзијата.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Едноставни и безбедни конверзии што може да пропаднат на контролиран начин под некои околности.Тоа е реципроцитет на [`TryInto`].
///
/// Ова е корисно кога правите конверзија на тип што може тривијално да успее, но исто така може да има потреба од специјално ракување.
/// На пример, не постои начин да се претвори [`i64`] во [`i32`] со употреба на [`From`] trait, бидејќи [`i64`] може да содржи вредност што [`i32`] не може да ја претстави и затоа конверзијата би изгубила податоци.
///
/// Ова може да се справи со скратување на [`i64`] на [`i32`] (во суштина давање на модулот за вредност на [i64 »] [`i32::MAX`]) или со едноставно враќање на [`i32::MAX`], или со некој друг метод.
/// [`From`] trait е наменет за совршени конверзии, така што `TryFrom` trait го информира програмерот кога конверзијата на тип може да биде лоша и им дозволува да одлучат како да се справат со тоа.
///
/// # Општи имплементации
///
/// - `TryFrom<T> for U` подразбира [`TryInto`]`<U>за T`</u>
/// - [`try_from`] е рефлексивен, што значи дека `TryFrom<T> for T` е имплементиран и не може да пропадне-поврзаниот тип `Error` за повикување `T::try_from()` на вредност од типот `T` е [`Infallible`].
/// Кога типот [`!`] се стабилизира, [`Infallible`] и [`!`] ќе бидат еквивалентни.
///
/// `TryFrom<T>` може да се спроведе на следниов начин:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Како што е опишано, [`i32`] спроведува `TryFrom <` [`i64`]`>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Тивко го скратува `big_number`, бара откривање и ракување со скратувањето по фактот.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Враќа грешка затоа што `big_number` е преголем за да се вклопи во `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Враќа `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Типот вратен во случај на грешка при конверзија.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ја извршува конверзијата.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ОПШТИ ИМПЛС
////////////////////////////////////////////////////////////////////////////////

// Како што се крева над&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Како лифтови над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): заменете ги горенаведените знаци за&/&mut со следново поопшто:
// // Како лифтови над Дереф
// импл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Големина> AsRef <U>за D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut крева над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): заменете го горенаведениот знак за &mut со следниов поопшт:
// // AsMut се крева над DerefMut
// импл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Големина> AsMut <U>за D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Од имплицира Во
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Од (а со тоа и во) е рефлексивно
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Белешка за стабилноста:** Овој проблем сè уште не постои, но ние сме "reserving space" да го додадеме во future.
/// Погледнете [rust-lang/rust#64715][#64715] за детали.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): наместо тоа направете принципиелна поправка.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom имплицира TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Безгрешните конверзии се семантички еквивалентни на грешни конверзии со ненаселен тип на грешка.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОНИ ИМПЛС
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ТИП БЕЗ ГРЕШКА
////////////////////////////////////////////////////////////////////////////////

/// Вид на грешка за грешки што никогаш не можат да се појават.
///
/// Бидејќи овој енум нема варијанта, вредност од овој тип всушност никогаш не може да постои.
/// Ова може да биде корисно за генерички API кои користат [`Result`] и го парамеризираат типот на грешка, за да се покаже дека резултатот е секогаш [`Ok`].
///
/// На пример, [`TryFrom`] trait (конверзија што враќа [`Result`]) има ќебе за сите видови каде што постои обратна имплементација [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Компатибилност Future
///
/// Овој enum ја има истата улога како [the `!`“never”type][never], што е нестабилно во оваа верзија на Rust.
/// Кога `!` се стабилизира, ние планираме да го направиме `Infallible` тип алијас на него:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …И на крајот амортизирајте го `Infallible`.
///
/// Сепак, постои еден случај кога синтаксата `!` може да се користи пред да се стабилизира `!` како полноправен тип: во позиција на тип на враќање на функцијата.
/// Поточно, можни се имплементации за два различни типа на покажувачи на функции:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Со оглед на тоа што `Infallible` е енум, овој код е валиден.
/// Меѓутоа, кога `Infallible` станува псевдоним за never type, двата импликации ќе започнат да се преклопуваат и затоа ќе бидат забранети со правилата за кохерентност на јазикот trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}