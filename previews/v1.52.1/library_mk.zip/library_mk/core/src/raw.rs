#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Содржи структурни дефиниции за изгледот на вградените типови на компајлери.
//!
//! Тие можат да се користат како цели на трансмути во небезбеден код за директно манипулирање со сировите репрезентации.
//!
//!
//! Нивната дефиниција секогаш треба да одговара на ABI дефиниран во `rustc_middle::ty::layout`.
//!

/// Претставата на trait објект како `&dyn SomeTrait`.
///
/// Овој структур има ист распоред како и типовите како `&dyn SomeTrait` и `Box<dyn AnotherTrait>`.
///
/// `TraitObject` гарантирано одговара на распоредот, но не е од типот на објектите trait (на пр., полињата не се директно достапни на `&dyn SomeTrait`) ниту го контролира тој распоред (со промена на дефиницијата нема да се промени изгледот на `&dyn SomeTrait`).
///
/// Тој е дизајниран само за употреба од небезбеден код кој треба да манипулира со деталите на ниско ниво.
///
/// Не постои начин генерички да се повикуваат на сите trait објекти, така што единствениот начин да се создадат вредности од овој тип е со функции како [`std::mem::transmute`][transmute].
/// Слично на тоа, единствениот начин да се создаде вистински trait објект од `TraitObject` вредност е `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Синтетизирање на објект trait со несовпаѓачки типови-оној каде што vtable не одговара на типот на вредноста на која покажува покажувачот на податоци-многу веројатно ќе доведе до недефинирано однесување.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // пример trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // нека компајлерот направи trait објект
/// let object: &dyn Foo = &value;
///
/// // погледнете ја суровата застапеност
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // покажувачот на податоци е адреса на `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // Конструирај нов објект, покажувајќи на друг `i32`, внимавајќи да го користиш `i32` vtable од `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // треба да работи исто како да сме конструирале trait предмет директно од `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}