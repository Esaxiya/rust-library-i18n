macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Најмалата вредност што може да ја претстави овој цел број.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Најголемата вредност што може да ја претстави овој цел број.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Големината на овој тип цел број во битови.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Конвертира парче стринг во дадена основа во цел број.
        ///
        /// Низата се очекува да биде опционален знак `+` проследен со цифри.
        ///
        /// Водечкиот и заостануваниот бел простор претставуваат грешка.
        /// Бројките се подмножество на овие знаци, во зависност од `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Оваа функција panics ако `radix` не е во опсег од 2 до 36.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Го враќа бројот на оние во бинарната претстава на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Го враќа бројот на нули во бинарната претстава на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Го враќа бројот на водечки нули во бинарната претстава на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Го враќа бројот на заостанувачки нули во бинарната претстава на `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Го враќа бројот на водечки во бинарната претстава на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Го враќа бројот на заостанати во бинарната претстава на `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Ги поместува битовите налево со одредена количина, `n`, завиткувајќи ги скратените битови до крајот на добиениот цел број.
        ///
        ///
        /// Забележете дека ова не е иста операција со менувачот `<<`!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Ги префрла битовите надесно за одредена количина, `n`, завиткувајќи ги скратените битови на почетокот на добиениот цел број.
        ///
        ///
        /// Забележете дека ова не е иста операција со менувачот `>>`!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Го менува редоследот на бајти на цел број.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Го менува редоследот на битови во цел број.
        /// Најмалку значајниот бит станува најзначаен бит, вториот најмалку значаен бит станува втор најзначаен бит, итн.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Конвертира цел број од голем ендијан во крајност на целта.
        ///
        /// На големиот ендијан ова е забрането работење.
        /// На малку ендијан, бајтите се менуваат.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } друго {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Конвертира цел број од малку ендијан во крајност на целта.
        ///
        /// На малку ендијан ова е забрането работење.
        /// На голем ендијан, бајтите се заменуваат.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } друго {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Го претвора `self` во голем ендијан од крајноста на целта.
        ///
        /// На големиот ендијан ова е забрането работење.
        /// На малку ендијан, бајтите се менуваат.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } друго { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // или да не биде?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Го претвора `self` во малку ендијан од крајноста на целта.
        ///
        /// На малку ендијан ова е забрането работење.
        /// На голем ендијан, бајтите се заменуваат.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } друго { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Проверено собирање на цел број.
        /// Пресметува `self + rhs`, враќајќи го `None` ако се случи прелевање.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Нештигирано собирање на цел број.Пресметува `self + rhs`, под претпоставка дека не може да дојде до прелевање.
        /// Ова резултира во недефинирано однесување кога
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Проверено одземање на цел број.
        /// Пресметува `self - rhs`, враќајќи го `None` ако се случи прелевање.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено одземање на цел број.Пресметува `self - rhs`, под претпоставка дека не може да дојде до прелевање.
        /// Ова резултира во недефинирано однесување кога
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Проверено множење со цел број.
        /// Пресметува `self * rhs`, враќајќи го `None` ако се случи прелевање.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено множење со цел број.Пресметува `self * rhs`, под претпоставка дека не може да дојде до прелевање.
        /// Ова резултира во недефинирано однесување кога
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Проверена поделба на цел број.
        /// Пресметува `self / rhs`, враќајќи го `None` ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗБЕДНОСТ: поделено со нула е проверено погоре и непотпишаните типови немаат други
                // режими на неуспех за поделба
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Проверена евклидовска поделба.
        /// Пресметува `self.div_euclid(rhs)`, враќајќи го `None` ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Проверено остаток од цел број.
        /// Пресметува `self % rhs`, враќајќи го `None` ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗБЕДНОСТ: поделено со нула е проверено погоре и непотпишаните типови немаат други
                // режими на неуспех за поделба
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Проверено евклидово модуло.
        /// Пресметува `self.rem_euclid(rhs)`, враќајќи го `None` ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Проверена негација.Пресметува `-self`, враќајќи го `None` освен ако `self==
        /// 0`.
        ///
        /// Забележете дека негирањето на кој било позитивен цел број ќе се прелее.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена смена налево.
        /// Пресметува `self << rhs`, враќајќи го `None` ако `rhs` е поголем или еднаков на бројот на битови во `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена смена надесно.
        /// Пресметува `self >> rhs`, враќајќи го `None` ако `rhs` е поголем или еднаков на бројот на битови во `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена експоненцијација.
        /// Пресметува `self.pow(exp)`, враќајќи го `None` ако се случи прелевање.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // од екс!=0, конечно истекот мора да биде 1.
            // Одделете се со последниот бит на експонентот одделно, бидејќи квадрирањето на основата потоа не е потребно и може да предизвика непотребно прелевање.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Заситување на собирање на цел број.
        /// Пресметува `self + rhs`, заситувајќи се на нумерички граници наместо да се прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Заситување на целото одземање.
        /// Пресметува `self - rhs`, заситувајќи се на нумерички граници наместо да се прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Заситено множење со цел број.
        /// Пресметува `self * rhs`, заситувајќи се на нумерички граници наместо да се прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Заситување на експоненцијацијата на цел број.
        /// Пресметува `self.pow(exp)`, заситувајќи се на нумерички граници наместо да се прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Завиткување на додаток (modular).
        /// Пресметува `self + rhs`, обвиткувајќи се на границата од типот.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Завиткување на одземањето (modular).
        /// Пресметува `self - rhs`, обвиткувајќи се на границата од типот.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Завиткување на множењето (modular).
        /// Пресметува `self * rhs`, обвиткувајќи се на границата од типот.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Имајте предвид дека овој пример е споделен помеѓу целите типови.
        /// Што објаснува зошто тука се користи `u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Завиткување на поделбата (modular).Пресметува `self / rhs`.
        /// Завитканата поделба на непотпишаните типови е само нормална поделба.
        /// Нема шанси некогаш да се случи завиткување.
        /// Оваа функција постои, така што сите операции се сметаат за операциите за завиткување.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Завиткување на Евклидовата поделба.Пресметува `self.div_euclid(rhs)`.
        /// Завитканата поделба на непотпишаните типови е само нормална поделба.
        /// Нема шанси некогаш да се случи завиткување.
        /// Оваа функција постои, така што сите операции се сметаат за операциите за завиткување.
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, ова е точно еднакво на `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Завиткување на остатокот од (modular).Пресметува `self % rhs`.
        /// Пресметката на завиткан остаток на непотпишаните типови е само редовна пресметка на остатокот.
        ///
        /// Нема шанси некогаш да се случи завиткување.
        /// Оваа функција постои, така што сите операции се сметаат за операциите за завиткување.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Завиткување на евклидовиот модул.Пресметува `self.rem_euclid(rhs)`.
        /// Пресметката на завитканиот модул на непотпишаните типови е само редовна пресметка на остатокот.
        /// Нема шанси некогаш да се случи завиткување.
        /// Оваа функција постои, така што сите операции се сметаат за операциите за завиткување.
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, ова е точно еднакво на `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Завиткување на негацијата (modular).
        /// Пресметува `-self`, обвиткувајќи се на границата од типот.
        ///
        /// Бидејќи непотпишаните типови немаат негативни еквиваленти, сите апликации на оваа функција ќе се завиткаат (освен `-0`).
        /// За вредности помали од максимумот на соодветниот потпишан тип, резултатот е ист како да се фрли соодветната потпишана вредност.
        ///
        /// Кои поголеми вредности се еквивалентни на `MAX + 1 - (val - MAX - 1)` каде што `MAX` е соодветниот потпишан тип на максимум.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Имајте предвид дека овој пример е споделен помеѓу целите типови.
        /// Што објаснува зошто тука се користи `i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Битско поместување на левата страна без Panic;
        /// дава `self << mask(rhs)`, каде `mask` ги отстранува сите битови од висок ред на `rhs` што би предизвикало поместувањето да го надмине бит-ширината на типот.
        ///
        /// Забележете дека ова *не е* исто со ротација лево;RHS-от за завиткување-лево е ограничен на опсегот од типот, наместо битовите изместени од LHS да бидат вратени на другиот крај.
        /// Сите примитивни интегрални типови спроведуваат [`rotate_left`](Self::rotate_left) функција, што може да биде она што го сакате наместо тоа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // БЕЗБЕДНОСТ: маскирањето од типот на бит-големина гарантира дека не се менуваме
            // надвор од границите
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Битско поместување-десно без Panic;
        /// дава `self >> mask(rhs)`, каде `mask` ги отстранува сите битови од висок ред на `rhs` што би предизвикало поместувањето да го надмине бит-ширината на типот.
        ///
        /// Имајте на ум дека ова *не е* исто како ротација-десно;RHS-от за завиткување-десно е ограничен на опсегот од типот, наместо битовите изместени од LHS да бидат вратени на другиот крај.
        /// Сите примитивни интегрални типови спроведуваат [`rotate_right`](Self::rotate_right) функција, што може да биде она што го сакате наместо тоа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // БЕЗБЕДНОСТ: маскирањето од типот на бит-големина гарантира дека не се менуваме
            // надвор од границите
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Завиткување на експоненцијацијата (modular).
        /// Пресметува `self.pow(exp)`, обвиткувајќи се на границата од типот.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // од екс!=0, конечно истекот мора да биде 1.
            // Одделете се со последниот бит на експонентот одделно, бидејќи квадрирањето на основата потоа не е потребно и може да предизвика непотребно прелевање.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Пресметува `self` + `rhs`
        ///
        /// Враќа збир на додаток заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Ако се случи прелевање, тогаш завитканата вредност се враќа.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Пресметува `self`, `rhs`
        ///
        /// Враќа парче од одземањето заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Ако се случи прелевање, тогаш завитканата вредност се враќа.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Пресметува множење на `self` и `rhs`.
        ///
        /// Враќа тројка од множењето заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Ако се случи прелевање, тогаш завитканата вредност се враќа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Имајте предвид дека овој пример е споделен помеѓу целите типови.
        /// Што објаснува зошто тука се користи `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Го пресметува делителот кога `self` е поделен со `rhs`.
        ///
        /// Враќа тројка на делителот заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Забележете дека за непотпишаните цели броеви никогаш не се појавува прелевање, така што втората вредност е секогаш `false`.
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Пресметува количник на Евклидовата поделба `self.div_euclid(rhs)`.
        ///
        /// Враќа тројка на делителот заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Забележете дека за непотпишаните цели броеви никогаш не се појавува прелевање, така што втората вредност е секогаш `false`.
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, ова е точно еднакво на `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Го пресметува остатокот кога `self` се дели со `rhs`.
        ///
        /// Враќа тројка од остатокот по делење заедно со булово означувајќи дали ќе настане аритметичко прелевање.
        /// Забележете дека за непотпишаните цели броеви никогаш не се појавува прелевање, така што втората вредност е секогаш `false`.
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Го пресметува остатокот `self.rem_euclid(rhs)` како да е според Евклидовата поделба.
        ///
        /// Враќа тројка на модулот по делење заедно со булово означувајќи дали ќе се појави аритметичко прелевање.
        /// Забележете дека за непотпишаните цели броеви никогаш не се појавува прелевање, така што втората вредност е секогаш `false`.
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, оваа операција е точно еднаква на `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Негатира себеси во преполн начин.
        ///
        /// Враќа `!self + 1` користејќи операции за завиткување за да ја врати вредноста што претставува негација на оваа непотпишана вредност.
        /// Забележете дека за позитивни непотпишани вредности секогаш се појавува прелевање, но негацијата на 0 не се прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Се менува самостојно оставено од `rhs` битови.
        ///
        /// Враќа тројка на поместената верзија на себе заедно со булово означувајќи дали вредноста на смената била поголема или еднаква на бројот на битови.
        /// Ако вредноста на смената е преголема, тогаш вредноста е маскирана (N-1) каде N е бројот на битови, а оваа вредност потоа се користи за извршување на смената.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Се менува самостојно со `rhs` бита.
        ///
        /// Враќа тројка на поместената верзија на себе заедно со булово означувајќи дали вредноста на смената била поголема или еднаква на бројот на битови.
        /// Ако вредноста на смената е преголема, тогаш вредноста е маскирана (N-1) каде N е бројот на битови, а оваа вредност потоа се користи за извршување на смената.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Се подигнува себеси до моќноста на `exp`, користејќи експоненцијација со квадрат.
        ///
        /// Враќа тројка на експоненцијацијата заедно со bool што укажува на тоа дали се случил прелевање.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, точно));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Простор за гребење за складирање на резултати од преполнување_мул.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // од екс!=0, конечно истекот мора да биде 1.
            // Одделете се со последниот бит на експонентот одделно, бидејќи квадрирањето на основата потоа не е потребно и може да предизвика непотребно прелевање.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Се подигнува себеси до моќноста на `exp`, користејќи експоненцијација со квадрат.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // од екс!=0, конечно истекот мора да биде 1.
            // Одделете се со последниот бит на експонентот одделно, бидејќи квадрирањето на основата потоа не е потребно и може да предизвика непотребно прелевање.
            //
            //
            acc * base
        }

        /// Врши евклидова поделба.
        ///
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, ова е точно еднакво на `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Пресметува најмал дел од `self (mod rhs)`.
        ///
        /// Бидејќи, за позитивните цели броеви, сите вообичаени дефиниции за поделба се еднакви, ова е точно еднакво на `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Оваа функција ќе биде panic ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Враќа `true` ако и само ако `self == 2^k` за некои `k`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Враќа една помалку од следната моќност од две.
        // (За 8u8 следната моќност на два е 8u8 и за 6u8 таа е 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Овој метод не може да се прелее, бидејќи во случаите на претекување `next_power_of_two` тој завршува со враќање на максималната вредност на типот и може да врати 0 за 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // БЕЗБЕДНОСТ: Бидејќи `p > 0`, тој не може да се состои целосно од водечки нули.
            // Тоа значи дека промената е секогаш во граници, а некои процесори (како што е Intel pre-haswell) имаат поефикасни ctlz суштински кога аргументот не е нула.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Враќа најмала моќност од две поголема или еднаква на `self`.
        ///
        /// Кога повратната вредност се прелева (т.е. `self > (1 << (N-1))` за тип `uN`), таа panics во режим на дебагирање и повратната вредност се завиткуваат до 0 во режимот на ослободување (единствената ситуација во која методот може да врати 0).
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Враќа најмала моќност од две поголема или еднаква на `n`.
        /// Ако следната моќност на двајца е поголема од максималната вредност на типот, `None` се враќа, инаку моќноста на двајца е завиткана во `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Враќа најмала моќност од две поголема или еднаква на `n`.
        /// Ако следната моќност на двајца е поголема од максималната вредност на типот, повратната вредност е завиткана во `0`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Вратете ја репрезентацијата на меморијата на овој цел број како бајт-низа по редослед по бајт од голем ендијан (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Вратете ја репрезентацијата на меморијата на овој цел број како бајт низа по редослед на малку ендијански бајти.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Вратете ја репрезентацијата на меморијата на овој цел број како бајт-низа по редослед по природен бајт.
        ///
        /// Бидејќи се користи природната крајност на целната платформа, преносливиот код треба да користи [`to_be_bytes`] или [`to_le_bytes`], како што е соодветно, наместо тоа.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     бајти, ако cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } друго {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗБЕДНОСТ: Звук на конст, бидејќи интегралите се едноставни стари типови на податоци, така што можеме секогаш
        // преточи ги во низи на бајти
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // БЕЗБЕДНОСТ: цели броеви се обични стари типови на податоци, така што секогаш можеме да ги менуваме
            // низи на бајти
            unsafe { mem::transmute(self) }
        }

        /// Вратете ја репрезентацијата на меморијата на овој цел број како бајт-низа по редослед по природен бајт.
        ///
        ///
        /// [`to_ne_bytes`] треба да се претпочита пред ова секогаш кога е можно.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// нека бајти= num.as_ne_bytes();
        /// assert_eq!(
        ///     бајти, ако cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } друго {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // БЕЗБЕДНОСТ: цели броеви се обични стари типови на податоци, така што секогаш можеме да ги менуваме
            // низи на бајти
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Создадете природна цел број на ендијан од неговото претставување како бајт-низа во голем ендијан.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користете std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * влез=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Создадете природна цел број на ендијан од неговото претставување како бајт-низа во малку ендијан.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користете std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * влез=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Создадете природна цел број на ендијан од нејзината мемориска репрезентација како бајт-низа во родната крајност.
        ///
        /// Бидејќи се користи природната крајност на целната платформа, преносливиот код најверојатно сака да користи [`from_be_bytes`] или [`from_le_bytes`], како што е соодветно, наместо тоа.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } друго {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користете std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * влез=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗБЕДНОСТ: Звук на конст, бидејќи интегралите се едноставни стари типови на податоци, така што можеме секогаш
        // трансмут на нив
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // БЕЗБЕДНОСТ: цели броеви се обични стари типови на податоци, така што секогаш можеме да им се пренесуваме
            unsafe { mem::transmute(bytes) }
        }

        /// Новиот код треба да претпочита да се користи
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Ја враќа најмалата вредност што може да ја претстави овој цел број.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Новиот код треба да претпочита да се користи
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Ја враќа најголемата вредност што може да ја претстави овој цел број.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}