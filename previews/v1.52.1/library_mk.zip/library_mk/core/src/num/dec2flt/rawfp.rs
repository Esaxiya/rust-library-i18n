//! Битче за малку на позитивни плови IEEE 754.Негативните броеви не се постапуваат и не треба да се ракуваат.
//! Нормалните броеви на подвижна точка имаат канонска претстава како (frac, exp) така што вредноста е 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) каде N е бројот на битови.
//!
//! Потнормалните се малку различни и чудни, но важи истиот принцип.
//!
//! Сепак, тука ги претставуваме како (сиг, к) со f позитивно, така што вредноста е f *
//! 2 <sup>д</sup> .Покрај тоа што го прави "hidden bit" експлицитен, ова го менува експонентот со таканаречената промена на мантиса.
//!
//! На друг начин, нормално плови се запишуваат како (1), но тука се напишани како (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) го нарекуваме **фракционо претставување** и (2)**интегрално претставување**.
//!
//! Многу функции во овој модул се справуваат само со нормални броеви.Рутините dec2flt конзервативно го заземаат универзално-правилниот бавен пат (Алгоритам М) за многу мали и многу големи броеви.
//! На тој алгоритам му треба само next_float() кој се справува со потнормални и нули.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Помошник trait за да се избегне удвојување во основа на целиот код за конверзија за `f32` и `f64`.
///
/// Погледнете го коментарот на докторот за родителскиот модул зошто е тоа потребно.
///
/// Дали **никогаш не треба** да се спроведува за други типови или да се користи надвор од модулот dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Тип користен од `to_bits` и `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Врши необработена трансмутација во цел број.
    fn to_bits(self) -> Self::Bits;

    /// Врши необработена трансмутација од цел број.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ја враќа категоријата во која спаѓа овој број.
    fn classify(self) -> FpCategory;

    /// Ги враќа мантисата, експонентот и знакот како цели броеви.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Декодира плови.
    fn unpack(self) -> Unpacked;

    /// Фрла од мал цел број што може точно да се претстави.
    /// Panic ако целиот број не може да се претстави, другиот код во овој модул се грижи никогаш да не дозволи тоа да се случи.
    fn from_int(x: u64) -> Self;

    /// Ја добива вредноста 10 <sup>e</sup> од претходно пресметаната табела.
    /// Panics за `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Што вели името.
    /// Полесно е да се тврди кодот отколку да се жонглира со интринци и да се надева дека постојаната LLVM преклопува
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Конзервативна врзана за децималните цифри на влезовите што не можат да произведат прелевање или нула или
    /// поднормални.Веројатно децималниот експонент на максималната нормална вредност, па оттука и името.
    const MAX_NORMAL_DIGITS: usize;

    /// Кога најзначајната децимална цифра има место поголема од оваа, бројот секако е заокружен до бесконечност.
    ///
    const INF_CUTOFF: i64;

    /// Кога најзначајната децимална цифра има вредност помала од оваа, бројот сигурно се заокружува на нула.
    ///
    const ZERO_CUTOFF: i64;

    /// Бројот на битови во експонентот.
    const EXP_BITS: u8;

    /// Број на битови во значењето,*вклучувајќи* скриен бит.
    const SIG_BITS: u8;

    /// Бројот на битови во значењето и * со исклучок на скриениот бит.
    const EXPLICIT_SIG_BITS: u8;

    /// Максималниот правен експонент при фракционо застапување.
    const MAX_EXP: i16;

    /// Минимален правен експонент при фракционо претставување, со исклучок на поднормалните.
    const MIN_EXP: i16;

    /// `MAX_EXP` за интегрална репрезентација, т.е. со применетата смена.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` кодирани (т.е. со пристрасност на офсет)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` за интегрална репрезентација, т.е. со применетата смена.
    const MIN_EXP_INT: i16;

    /// Максималното нормализирано значење и во интегрална репрезентација.
    const MAX_SIG: u64;

    /// Минималното нормализирано значење и во интегрална репрезентација.
    const MIN_SIG: u64;
}

// Претежно решение за #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Ги враќа мантисата, експонентот и знакот како цели броеви.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Пристрасност на експонентите + смена на мантиса
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe е неизвесно дали `as` правилно заокружува на сите платформи.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Ги враќа мантисата, експонентот и знакот како цели броеви.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Пристрасност на експонентите + смена на мантиса
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe е неизвесно дали `as` правилно заокружува на сите платформи.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Конвертира `Fp` во најблискиот тип на плови машина.
/// Не се справува со субнормални резултати.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f е 64 битна, така што xe има промена на мантисата 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Заокружете ги 64-битните знаци и битовите T::SIG_BITS со полу-рамномерно.
/// Не се справува со прелевање на експонентите.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Прилагодете ја смената на мантиса
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Инверзна `RawFloat::unpack()` за нормализирани броеви.
/// Panics ако знакот или експонентот не се валидни за нормализирани броеви.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Отстранете го скриениот бит
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Прилагодете го експонентот за пристрасност на експонентите и промена на мантиса
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Остави бит знак на 0 ("+"), сите наши броеви се позитивни
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Конструирај потнормално.Дозволена е мантиса од 0 и конструира нула.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Шифрираниот експонент е 0, знакот бит е 0, така што треба само да ги интерпретираме битовите.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Приближен бигнум со Fp.Заокружува во рамките на 0.5 ULP со полу-рамномерно.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ние ги отсекуваме сите битови пред индексот `start`, т.е. ефективно се поместуваме десно за количина `start`, така што ова е исто така потребниот експонент.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Заокружете (half-to-even) во зависност од скратените битови.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Го наоѓа најголемиот број на подвижна точка строго помал од аргументот.
/// Не се справува со поднормални, нула или експонентни подливи.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Пронајдете го најмалиот број на подвижна точка строго поголем од аргументот.
// Оваа операција е заситена, т.е. next_float(inf) ==инф.
// За разлика од повеќето кодови во овој модул, оваа функција се справува со нула, субнормални и бесконечности.
// Сепак, како и сите други кодови овде, тој не се занимава со NaN и негативни броеви.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ова изгледа премногу добро за да биде вистина, но работи.
        // 0.0 е кодиран како збор кој е нула.Поднормалите се 0x000m ... m каде m е мантисата.
        // Особено, најмалата субнормална е 0x0 ... 01 и најголемата е 0x000F ... F.
        // Најмалиот нормален број е 0x0010 ... 0, така што работи и овој аголен случај.
        // Ако инкрементот се прелева со мантисата, битот за носење го зголемува експонентот како што сакаме и битовите мантиса стануваат нула.
        // Поради скриената конвенција за битови, ова е токму она што го сакаме!
        // Конечно, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}