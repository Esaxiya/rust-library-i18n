//! Валидирање и распаѓање на децимална низа од формата:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Со други зборови, стандардна синтакса на подвижна точка, со два исклучоци: Без знак и без ракување со "inf" и "NaN".Со нив управува функцијата на возачот (super::dec2flt).
//!
//! Иако препознавањето на валидни влезови е релативно лесно, овој модул исто така треба да ги отфрли безбројните невалидни варијации, никогаш panic, и да изврши бројни проверки на кои другите модули се потпираат за да не panic (или претекување) за возврат.
//!
//! Да бидат работите уште полоши, сето тоа се случува со едно поминување преку влезот.
//! Затоа, бидете претпазливи кога менувате што било, и проверете повторно со другите модули.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Интересните делови од децимална низа.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Декалниот експонент, гарантирано дека има помалку од 18 децимални цифри.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Проверува дали влезната низа е валиден број на подвижна точка и ако е така, лоцирајте го интегралниот дел, дробниот дел и експонентот во него.
/// Не ракува со знаци.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Без цифри пред 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Потребна е барем една цифра пред или по точката.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Несакано ѓубре по фракционо дел
            }
        }
        _ => Invalid, // Заостанатиот ѓубре по низата од прва цифра
    }
}

/// Издвојува децимални цифри до првиот нецифрен знак.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Извлекување експонент и проверка на грешка.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Несакано ѓубре по експонент
    }
    if number.is_empty() {
        return Invalid; // Празен експонент
    }
    // Во овој момент, сигурно имаме валидна низа цифри.Можеби е премногу долго за да се стави во `i64`, но ако е толку огромен, влезот е сигурно нула или бесконечност.
    // Бидејќи секоја нула во децималните цифри го прилагодува експонентот само со +/-1, при експ=10 ^ 18 влезот треба да биде 17 егзабајт (!) нули за да се доближи дури и далеку од конечен.
    //
    // Ова не е точно случај на употреба, треба да го задоволиме.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}