//! Алатни функции за bignums кои немаат премногу смисла да се претворат во методи.

// FIXME Името на овој модул е малку жално, бидејќи и другите модули увезуваат `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Тестирајте дали скратењето на сите битови помалку значајни од `ones_place` воведува релативна грешка помала, еднаква или поголема од 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ако сите преостанати битови се нула, тоа е= 0.5 ULP, инаку> 0.5 Ако нема повеќе битови (half_bit==0), подолу исто така правилно враќа Еднакво.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Конвертира низа ASCII што содржи само децимални цифри во `u64`.
///
/// Не извршува проверки за прелевање или невалидни знаци, па ако повикувачот не е внимателен, резултатот е лажен и може да panic (иако нема да биде `unsafe`).
/// Дополнително, празните низи се третираат како нула.
/// Оваа функција постои затоа што
///
/// 1. користењето на `FromStr` на `&[u8]` бара `from_utf8_unchecked`, што е лошо и
/// 2. спојувањето заедно на резултатите од `integral.parse()` и `fractional.parse()` е покомплицирано од целата оваа функција.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Конвертира низа од ASCII цифри во бињум.
///
/// Како `from_str_unchecked`, оваа функција се потпира на анализаторот за да се искорени нецифрените.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Открива бигнум во 64-битен цел број.Panics ако бројот е премногу голем.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Извлекува низа битови.

/// Индексот 0 е најмалку значаен бит и опсегот е полуотворен како и обично.
/// Panics доколку биде побарано да извлече повеќе битови отколку што се вклопуваат во типот на поврат.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}