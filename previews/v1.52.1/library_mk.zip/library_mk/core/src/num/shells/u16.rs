//! Константи за 16-битниот непотпишан цел број.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Новиот код треба да ги користи поврзаните константи директно на примитивниот тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }