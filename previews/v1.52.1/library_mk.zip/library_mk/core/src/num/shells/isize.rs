//! Константи за типот на цел број со големина на покажувачот.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Новиот код треба да ги користи поврзаните константи директно на примитивниот тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }