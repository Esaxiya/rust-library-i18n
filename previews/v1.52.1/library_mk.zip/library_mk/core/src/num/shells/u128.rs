//! Константи за 128-битниот непотпишан цел број.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Новиот код треба да ги користи поврзаните константи директно на примитивниот тип.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }