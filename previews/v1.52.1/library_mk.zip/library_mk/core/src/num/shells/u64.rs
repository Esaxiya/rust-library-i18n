//! Константи за 64-битниот непотпишан цел број.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Новиот код треба да ги користи поврзаните константи директно на примитивниот тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }