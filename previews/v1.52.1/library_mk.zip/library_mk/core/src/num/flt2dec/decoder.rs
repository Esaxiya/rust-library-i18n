//! Декодира вредност на подвижна точка во одделни делови и опсези на грешки.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодирана непотпишана конечна вредност, таква што:
///
/// - Оригиналната вредност е еднаква на `mant * 2^exp`.
///
/// - Било кој број од `(mant - minus)*2^exp` до `(mant + plus)* 2^exp` ќе се заокружи на оригиналната вредност.
/// Опсегот е вклучен само кога `inclusive` е `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Скалираната мантиса.
    pub mant: u64,
    /// Долниот опсег на грешки.
    pub minus: u64,
    /// Горниот опсег на грешки.
    pub plus: u64,
    /// Споделениот експонент во основата 2.
    pub exp: i16,
    /// Точно кога опсегот на грешки е вклучен.
    ///
    /// Во IEEE 754, ова е точно кога оригиналната мантиса беше изедначена.
    pub inclusive: bool,
}

/// Декодирана непотпишана вредност.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Бесконечности, или позитивни или негативни.
    Infinite,
    /// Нула, или позитивна или негативна.
    Zero,
    /// Конечни броеви со понатамошно декодирани полиња.
    Finite(Decoded),
}

/// Тип на подвижна точка што може да се `декодира`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Минимална позитивна нормализирана вредност.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Враќа знак (точно кога е негативен) и `FullDecoded` вредност од даден број на подвижна точка.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // соседи: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode секогаш го зачувува експонентот, така што мантисата е намалена за субнормални.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // соседи: (максимум, експ, 1)-(минормантен, истечен)-(миннормант + 1, истек)
                // каде максимум=минормантен * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // соседи: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}