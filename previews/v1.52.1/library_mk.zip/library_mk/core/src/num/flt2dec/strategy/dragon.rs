//! Речиси директен (но малку оптимизиран) Rust превод на слика 3 од " Брзо и прецизно печатење на броеви со подвижна точка` [^ 1].
//!
//!
//! [^1]: Burger, РГ и Дибвиг, РК 1996. Печатење броеви со подвижна точка
//!   брзо и прецизно.SIGPLAN Не.31, 5 (мај 1996 година), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// пресметани низи на `Дигит` за 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// употреблив само кога `x < 16 * scale`;`scaleN` треба да биде `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Имплементација на најкраткиот режим за Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // се знае дека бројот `v` во формат е:
    // - еднаква на `mant * 2^exp`;
    // - претходи `(mant - 2 *minus)* 2^exp` во оригинален тип;и
    // - проследено со `(mant + 2 *plus)* 2^exp` во оригинален тип.
    //
    // очигледно, `minus` и `plus` не можат да бидат нула.(за бесконечности, ние користиме вредности надвор од опсегот.) Исто така, претпоставуваме дека се генерира барем една цифра, т.е. `mant` не може да биде нула исто така.
    //
    // ова исто така значи дека кој било број помеѓу `low = (mant - minus)*2^exp` и `high = (mant + plus)* 2^exp` ќе биде прикажан на овој точно број на подвижна точка, со вклучени граници кога оригиналната мантиса била рамномерна (т.е. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` е `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // проценете `k_0` од оригиналните влезови што го задоволуваат `10^(k_0-1) < high <= 10^(k_0+1)`.
    // тесно врзаниот `k` задоволувачки `10^(k-1) < high <= 10^k` се пресметува подоцна.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // претворете го `{mant, plus, minus} * 2^exp` во дробна форма така што:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // подели `mant` со `10^k`.сега `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // поправка кога `mant + plus > scale` (или `>=`).
    // ние всушност не го менуваме `scale`, бидејќи наместо тоа можеме да го прескокнеме првичното множење.
    // сега `scale < mant + plus <= scale * 10` и подготвени сме да генерираме цифри.
    //
    // имајте во предвид дека `d[0]` * може да биде нула, кога `scale - plus < mant < scale`.
    // во овој случај, состојбата на заокружување (`up` подолу) ќе се активира веднаш.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // еквивалентно на скалирање на `scale` со 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кеш меморија `(2, 4, 8) * scale` за генерирање на цифри.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инваријанти, каде што `d[0..n-1]` се генерирани досега цифри:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (со тоа `mant / scale < 10`) каде `d[i..j]` е кратенка за `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // генерирајте една цифра: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ова е поедноставен опис на модифицираниот алгоритам Dragon.
        // многу аргументи за средни изводи и комплетност се изоставени за полесно.
        //
        // започнете со модифицирани инваријанти, бидејќи го ажуриравме `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // претпоставуваме дека `d[0..n-1]` е најкратката претстава помеѓу `low` и `high`, т.е. `d[0..n-1]` ги задоволува и двете од следниве, но `d[0..n-2]` не:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (бијективност: цифри во круг до `v`);и
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (последната цифра е точна).
        //
        // вториот услов се поедноставува до `2 * mant <= scale`.
        // решавањето на инваријанти во однос на `mant`, `low` и `high` дава поедноставна верзија на првиот услов: `-plus < mant < minus`.
        // од `-plus < 0 <= mant`, имаме точна најкратка претстава кога `mant < minus` и `2 * mant <= scale`.
        // (првиот станува `mant <= minus` кога оригиналната мантиса е рамномерна.)
        //
        // кога втората не држи (`2 * mant> скала`), треба да ја зголемиме последната цифра.
        // ова е доволно за враќање на таа состојба: веќе знаеме дека генерацијата на цифри гарантира `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // во овој случај, првиот услов станува `-plus < mant - scale < minus`.
        // од `mant < scale` по генерацијата, имаме `scale < mant + plus`.
        // (повторно, ова станува `scale <= mant + plus` кога оригиналната мантиса е рамномерна.)
        //
        // накратко:
        // - стоп и заокружување на `down` (чувајте цифри како што е) кога `mant < minus` (или `<=`).
        // - запрете и заокружете `up` (зголемете ја последната цифра) кога `scale < mant + plus` (или `<=`).
        // - продолжете да генерирате поинаку.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // имаме најкратка репрезентација, продолжете со заокружувањето

        // вратете ги инваријантите.
        // ова го прави алгоритмот секогаш да завршува: `minus` и `plus` секогаш се зголемува, но `mant` е исечен модул `scale` и `scale` е фиксен.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // заокружувањето се случува кога i) е активиран само условот за заокружување или ii) и двата услови биле активирани и прекинувањето на вратоврската претпочита заокружување.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ако заокружувањето ја промени должината, експонентот исто така треба да се смени.
        // се чини дека оваа состојба е многу тешко да се задоволи (е можно невозможна), но ние сме само безбедни и доследни тука.
        //
        // БЕЗБЕДНОСТ: ја иницијализиравме таа меморија погоре.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // БЕЗБЕДНОСТ: ја иницијализиравме таа меморија погоре.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Точната и фиксна реализација на режимот за Змеј.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // проценете `k_0` од оригиналните влезови што го задоволуваат `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // подели `mant` со `10^k`.сега `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // поправка кога `mant + plus >= scale`, каде `plus / scale = 10^-buf.len() / 2`.
    // со цел да го задржиме бигнумот со фиксна големина, ние всушност користиме `mant + floor(plus) >= scale`.
    // ние всушност не го менуваме `scale`, бидејќи наместо тоа можеме да го прескокнеме првичното множење.
    // повторно со најкраток алгоритам, `d[0]` може да биде нула, но на крајот ќе се заокружи.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // еквивалентно на скалирање на `scale` со 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ако работиме со ограничување на последната цифра, треба да го скратиме тампонот пред реалното рендерирање за да избегнеме двојно заокружување.
    //
    // забележете дека треба да го зголемиме тампонот повторно кога ќе се случи заокружување!
    let mut len = if k < limit {
        // упс, дури не можеме да произведеме *една* цифра.
        // ова е можно кога, да речеме, имаме нешто како 9.5 и се заокружува на 10.
        // враќаме празен тампон, со исклучок на подоцнежниот случај на заокружување што се случува кога `k == limit` и треба да произведе точно една цифра.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кеш меморија `(2, 4, 8) * scale` за генерирање на цифри.
        // (ова може да биде скапо, затоа не ги пресметувајте кога пуферот е празен.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // следните цифри се сите нули, ние застануваме тука не *обидувајте се* да извршите заокружување!наместо тоа, пополнете ги преостанатите цифри.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // БЕЗБЕДНОСТ: ја иницијализиравме таа меморија погоре.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // заокружување ако застанеме во средина на цифрите ако следните цифри се точно 5000 ..., проверете ја претходната цифра и обидете се да заокружите на рамномерно (т.е. избегнувајте заокружување кога претходната цифра е рамномерна).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // БЕЗБЕДНОСТ: `buf[len-1]` е иницијализиран.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ако заокружувањето ја промени должината, експонентот исто така треба да се смени.
        // но од нас е побаран фиксен број на цифри, затоа не менувајте го тампонот ...
        // БЕЗБЕДНОСТ: ја иницијализиравме таа меморија погоре.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... освен ако не ни биде побарана фиксна прецизност наместо тоа.
            // исто така треба да провериме дека, ако оригиналниот тампон бил празен, дополнителната цифра може да се додаде само кога `k == limit` (случај edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // БЕЗБЕДНОСТ: ја иницијализиравме таа меморија погоре.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}