//! Константи специфични за типот на подвижна точка со двојна прецизност `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Математички значајни броеви се дадени во под-модулот `consts`.
//!
//! За константите дефинирани директно во овој модул (различен од оние дефинирани во под-модулот `consts`), новиот код наместо тоа треба да ги користи придружните константи дефинирани директно на типот `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Радиксот или основата на внатрешната претстава на `f64`.
/// Наместо тоа, користете [`f64::RADIX`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // наменет начин
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Број на значајни цифри во основата 2.
/// Наместо тоа, користете [`f64::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // наменет начин
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Приближен број на значајни цифри во основата 10.
/// Наместо тоа, користете [`f64::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // наменет начин
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] вредност за `f64`.
/// Наместо тоа, користете [`f64::EPSILON`].
///
/// Ова е разликата помеѓу `1.0` и следниот поголем репрезентативен број.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // наменет начин
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Најмала конечна вредност на `f64`.
/// Наместо тоа, користете [`f64::MIN`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // наменет начин
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Најмала позитивна нормална вредност на `f64`.
/// Наместо тоа, користете [`f64::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // наменет начин
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Најголема конечна вредност на `f64`.
/// Наместо тоа, користете [`f64::MAX`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // наменет начин
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Една поголема од минималната можна нормална моќност од 2 експоненти.
/// Наместо тоа, користете [`f64::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // наменет начин
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Максимална можна моќност од 2 експоненти.
/// Наместо тоа, користете [`f64::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // наменет начин
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Минимална можна нормална моќност од 10 експонент.
/// Наместо тоа, користете [`f64::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // наменет начин
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Максимална можна моќност од 10 експонент.
/// Наместо тоа, користете [`f64::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // наменет начин
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Не е број (NaN).
/// Наместо тоа, користете [`f64::NAN`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // наменет начин
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Бесконечност (∞).
/// Наместо тоа, користете [`f64::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // наменет начин
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Негативна бесконечност (−∞).
/// Наместо тоа, користете [`f64::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // амортизиран начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // наменет начин
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Основни математички константи.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: заменете со математички константи од cmath.

    /// Константа на Архимед (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Константа на полн круг (τ)
    ///
    /// Еднакво на 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Бројот на Ојлер (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Радиксот или основата на внатрешната претстава на `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Број на значајни цифри во основата 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Приближен број на значајни цифри во основата 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] вредност за `f64`.
    ///
    /// Ова е разликата помеѓу `1.0` и следниот поголем репрезентативен број.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Најмала конечна вредност на `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Најмала позитивна нормална вредност на `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Најголема конечна вредност на `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Една поголема од минималната можна нормална моќност од 2 експоненти.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Максимална можна моќност од 2 експоненти.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Минимална можна нормална моќност од 10 експонент.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Максимална можна моќност од 10 експонент.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Не е број (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Бесконечност (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Негативна бесконечност (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Враќа `true` ако оваа вредност е `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` е јавно недостапен во libcore поради загриженост за преносливост, затоа оваа имплементација е за приватна употреба внатрешно.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Враќа `true` ако оваа вредност е позитивна бесконечност или негативна бесконечност, и `false` поинаку.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Враќа `true` ако овој број не е бесконечен ниту `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Нема потреба да се ракувате со NaN одделно: ако самостојно е NaN, споредбата не е точна, точно како што се посакува.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Враќа `true` ако бројот е [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Вредностите помеѓу `0` и `min` се потнормални.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Враќа `true` ако бројот не е нула, бесконечен, [subnormal] или `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Вредностите помеѓу `0` и `min` се потнормални.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Ја враќа категоријата подвижна точка на бројот.
    /// Ако само еден имот ќе се тестира, обично е побрзо да се користи специфичниот предикат наместо тоа.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Враќа `true` ако `self` има позитивен знак, вклучително и `+0.0`, `NaN` со позитивен знак и позитивна бесконечност.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Враќа `true` ако `self` има негативен знак, вклучително и `-0.0`, `NaN` со негативен бит знак и негативна бесконечност.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Зема реципрочен (inverse) на број, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Конвертира радијани во степени.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Поделбата тука е правилно заокружена во однос на вистинската вредност од 180/π.
        // (Ова се разликува од f32, каде што мора да се користи константа за да се обезбеди правилно заокружен резултат.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Конвертира степени во радијани.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Враќа максимум од двата броја.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ако еден од аргументите е NaN, тогаш другиот аргумент се враќа.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Враќа минимум од двата броја.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ако еден од аргументите е NaN, тогаш другиот аргумент се враќа.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Заокружува кон нула и се претвора во кој било примитивен цел број, под претпоставка дека вредноста е конечна и се вклопува во тој тип.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Вредноста мора:
    ///
    /// * Да не биде `NaN`
    /// * Да не биде бесконечно
    /// * Бидете репрезентативни во повратниот тип `Int`, откако ќе го скратите неговиот дел од дел
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Сурова трансмутација на `u64`.
    ///
    /// Ова во моментов е идентично со `transmute::<f64, u64>(self)` на сите платформи.
    ///
    /// Погледнете `from_bits` за одредена дискусија за преносливоста на оваа операција (скоро и да нема проблеми).
    ///
    /// Забележете дека оваа функција е различна од `as` кастинг, кој се обидува да ја зачува *нумеричката* вредност, а не битната вредност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() не кастира!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // БЕЗБЕДНОСТ: `u64` е обичен стар тип на дата, така што секогаш можеме да му се пренесуваме
        unsafe { mem::transmute(self) }
    }

    /// Сурова трансмутација од `u64`.
    ///
    /// Ова во моментов е идентично со `transmute::<u64, f64>(v)` на сите платформи.
    /// Излезе дека ова е неверојатно преносливо, од две причини:
    ///
    /// * Floats и Ints ја имаат истата крајност на сите поддржани платформи.
    /// * IEEE-754 многу прецизно го специфицира распоредот на битови на плови.
    ///
    /// Сепак, постои една забелешка: пред верзијата на IEEE-754 од 2008 година, како да се интерпретира битот за сигнализација NaN всушност не беше наведен.
    /// Повеќето платформи (особено x86 и ARM) го избраа толкувањето кое на крајот беше стандардизирано во 2008 година, но некои не (особено МИПС).
    /// Како резултат, сите сигнални NaN на MIPS се тивки NaN на x86 и обратно.
    ///
    /// Наместо да се обидува да ја зачува крос-платформата за сигнализација, оваа имплементација фаворизира зачувување на точните битови.
    /// Ова значи дека сите носивост кодирани во NaN ќе бидат зачувани дури и ако резултатот од овој метод е испратен преку мрежата од x86 машина до MIPS.
    ///
    ///
    /// Ако резултатите од овој метод се манипулирани само од истата архитектура што ги произведувала, тогаш нема никаква загриженост за преносливост.
    ///
    /// Ако влезот не е NaN, тогаш нема загриженост за преносливост.
    ///
    /// Ако не се грижите за сигнализирање (многу веројатно), тогаш нема никаква загриженост за преносливост.
    ///
    /// Забележете дека оваа функција е различна од `as` кастинг, кој се обидува да ја зачува *нумеричката* вредност, а не битната вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // БЕЗБЕДНОСТ: `u64` е обичен стар тип на дата, така што секогаш можеме да го трансмутираме од него
        // Излезе дека безбедносните проблеми со sNaN беа претерани!Ура!
        unsafe { mem::transmute(v) }
    }

    /// Вратете ја репрезентацијата на меморијата на овој број на подвижна точка како бајт-низа по редослед Бајт (network) на голем ендијан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Вратете ја репрезентацијата на меморијата на овој број на подвижна точка како низа бајти по редослед на малку ендијански бајти.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Вратете ја репрезентацијата на меморијата на овој број на подвижна точка како низа бајти по редослед по природен бајт.
    ///
    /// Бидејќи се користи природната крајност на целната платформа, преносливиот код треба да користи [`to_be_bytes`] или [`to_le_bytes`], како што е соодветно, наместо тоа.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Вратете ја репрезентацијата на меморијата на овој број на подвижна точка како низа бајти по редослед по природен бајт.
    ///
    ///
    /// [`to_ne_bytes`] треба да се претпочита пред ова секогаш кога е можно.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // БЕЗБЕДНОСТ: `f64` е обичен стар тип на дата, така што секогаш можеме да му се пренесуваме
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Создадете вредност на подвижна точка од нејзината претстава како бајт-низа во голем ендијан.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Креирајте вредност на подвижна точка од нејзината претстава како бајт низа во малку ендијан.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Создадете вредност на подвижна точка од нејзината репрезентација како бајт-низа во мајчин ендијан.
    ///
    /// Бидејќи се користи природната крајност на целната платформа, преносливиот код најверојатно сака да користи [`from_be_bytes`] или [`from_le_bytes`], како што е соодветно, наместо тоа.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Враќа подредување помеѓу себе и другите вредности.
    /// За разлика од стандардната делумна споредба помеѓу броевите на подвижна точка, оваа споредба секогаш произведува подредување во согласност со предикатот на вкупната нарачка како што е дефинирано во IEEE 754 (ревизија 2008 година) стандард на подвижна точка.
    /// Вредностите се подредуваат по следниот редослед:
    /// - Негативно тивко NaN
    /// - Негативна сигнализација за NaN
    /// - Негативна бесконечност
    /// - Негативни броеви
    /// - Негативни субнормални броеви
    /// - Негативна нула
    /// - Позитивна нула
    /// - Позитивни субнормални броеви
    /// - Позитивни броеви
    /// - Позитивна бесконечност
    /// - Позитивна сигнализација за NaN
    /// - Позитивен тивок NaN
    ///
    /// Забележете дека оваа функција не секогаш се согласува со [`PartialOrd`] и [`PartialEq`] имплементациите на `f64`.Особено, тие сметаат дека негативната и позитивната нула се еднакви, додека `total_cmp` не.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Во случај на негативи, превртете ги сите битови, освен знакот, за да постигнете сличен распоред како комплементите на двата комплементи
        //
        // Зошто работи ова?Плови IEEE 754 се состојат од три полиња:
        // Знак бит, експонент и мантиса.Множеството експонентни и полиња мантиса како целина имаат својство дека нивниот бит-редослед е еднаков на нумеричката големина каде што е дефинирана големината.
        // Големината не е нормално дефинирана на NaN вредностите, но IEEE 754 totalOrder ги дефинира NaN вредностите, исто така, за да се следи редоследот на бит.Ова води до редослед објаснет во коментарот на документот.
        // Сепак, претставата на големината е иста за негативни и позитивни броеви-само бит-знакот е различен.
        // За лесно да ги споредиме пловите како потпишани цел број, треба да ги превртиме битовите на експонентот и мантисата во случај на негативни броеви.
        // Ние ефикасно ги претвораме броевите во форма "two's complement".
        //
        // За да го превртуваме, конструираме маска и XOR против неа.
        // Бесправно пресметуваме маска "all-ones except for the sign bit" од негативно-потпишани вредности: десно менувачки знак го продолжува целиот број, па маската "fill" ја обележуваме со битови за знаци, а потоа ја претвораме во непотпишана за да притиснеме уште еден нула-бит.
        //
        // На позитивни вредности, маската е со сите нули, па затоа е забрането работење.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Ограничете ја вредноста на одреден интервал освен ако не е NaN.
    ///
    /// Враќа `max` ако `self` е поголем од `max` и `min` ако `self` е помал од `min`.
    /// Инаку ова враќа `self`.
    ///
    /// Забележете дека оваа функција враќа NaN ако и почетната вредност беше NaN.
    ///
    /// # Panics
    ///
    /// Panics ако `min > max`, `min` е NaN или `max` е NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}