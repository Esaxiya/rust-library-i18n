//! Ова е внатрешен модул што го користи ifmt!времетраењеОвие структури се емитуваат во статички низи за да се компајлираат стрингови пред време.
//!
//! Овие дефиниции се слични на нивните еквиваленти на `ct`, но се разликуваат по тоа што тие можат статички да се распределат и да бидат малку оптимизирани за време на траење
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Можни усогласувања што може да се побараат како дел од директивата за форматирање.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Индикација дека содржината треба да се порамнува лево.
    Left,
    /// Индикација дека содржината треба да биде подредена десно.
    Right,
    /// Индикација дека содржината треба да биде подредена во центарот.
    Center,
    /// Не беше побарано усогласување.
    Unknown,
}

/// Користено од спецификаторите [width](https://doc.rust-lang.org/std/fmt/#width) и [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Наведено со буквален број, ја зачувува вредноста
    Is(usize),
    /// Наведени со употреба на синтакса `$` и `*`, го зачувуваат индексот во `args`
    Param(usize),
    /// Не е одредено
    Implied,
}