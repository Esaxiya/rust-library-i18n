#![stable(feature = "futures_api", since = "1.36.0")]

//! Асинхрони вредности.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Овој тип е потребен затоа што:
///
/// а) Генераторите не можат да спроведат `for<'a, 'b> Generator<&'a mut Context<'b>>`, затоа треба да поминеме суров покажувач (види <https://github.com/rust-lang/rust/issues/68923>).
///
/// б) Сурови покажувачи и `NonNull` не се `Send` или `Sync`, така што тоа би го направило секој future non-Send/Sync исто така, и ние не го сакаме тоа.
///
/// Исто така го поедноставува намалувањето на HIR за `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Завиткајте генератор во future.
///
/// Оваа функција враќа `GenFuture` под, но го крие во `impl Trait` за да даде подобри пораки за грешки (`impl Future` отколку `GenFuture<[closure.....]>`).
///
// Ова е `const` за да избегнеме дополнителни грешки откако ќе се опоравиме од `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ние се потпираме на фактот дека async/await futures се недвижни со цел да создадеме самореферентни позајмици во основниот генератор.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // БЕЗБЕДНОСТ: Безбедно затоа што сме !Unpin + !Drop и ова е само проекција на поле.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Продолжете со генераторот, претворајќи го `&mut Context` во суровин покажувач `NonNull`.
            // Намалувањето `.await` безбедно ќе го врати назад кон `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `cx.0` е валиден покажувач
    // што ги исполнува сите барања за променлива референца.
    unsafe { &mut *cx.0.as_ptr().cast() }
}