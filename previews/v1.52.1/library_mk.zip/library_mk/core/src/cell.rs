//! Контејнери што можат да се споделат.
//!
//! Безбедноста на меморијата Rust се заснова на ова правило: Со оглед на објект `T`, можно е да имате само едно од следниве:
//!
//! - Имајќи неколку непроменливи референци (`&T`) на објектот (познато и како **алијасирање**).
//! - Имање на една променлива референца (`&mut T`) на објектот (позната и како **подвижност**).
//!
//! Ова е спроведено од компајлерот Rust.Сепак, постојат ситуации кога ова правило не е доволно флексибилно.Понекогаш се бара да има повеќе препораки за некој предмет, а сепак да мутира.
//!
//! Мобилните контејнери што можат да се споделат, постојат за да се дозволи подвижност на контролиран начин, дури и во присуство на алиазирање.И [`Cell<T>`] и [`RefCell<T>`] дозволуваат да се прави ова на еден навој начин.
//! Сепак, ниту `Cell<T>` ниту `RefCell<T>` не се безбедни за конец (тие не го имплементираат [`Sync`]).
//! Ако треба да направите псевдонимување и мутација помеѓу повеќе нишки, можно е да се користат типови [`Mutex<T>`], [`RwLock<T>`] или [`atomic`].
//!
//! Вредностите на типовите `Cell<T>` и `RefCell<T>` може да се мутираат преку споделени референци (т.е.
//! заеднички тип `&T`), додека повеќето типови Rust можат да се мутираат само преку уникатни референци (`&mut T`).
//! Ние велиме дека `Cell<T>` и `RefCell<T>` обезбедуваат " внатрешна променливост`, за разлика од типичните типови Rust кои покажуваат " наследна подвижност`.
//!
//! Видовите клетки доаѓаат во два вкуса: `Cell<T>` и `RefCell<T>`.`Cell<T>` спроведува внатрешна променливост со поместување на вредностите во и надвор од `Cell<T>`.
//! За да користите референци наместо вредности, мора да се користи типот `RefCell<T>`, стекнувајќи заклучување за запишување пред мутирање.`Cell<T>` обезбедува методи за добивање и промена на тековната вредност на ентериерот:
//!
//!  - За типовите што го имплементираат [`Copy`], методот [`get`](Cell::get) ја враќа тековната внатрешна вредност.
//!  - За типовите кои го имплементираат [`Default`], методот [`take`](Cell::take) ја заменува моменталната вредност на внатрешноста со [`Default::default()`] и ја враќа заменетата вредност.
//!  - За сите видови, методот [`replace`](Cell::replace) ја заменува тековната вредност на ентериерот и ја враќа заменетата вредност, а методот [`into_inner`](Cell::into_inner) го троши `Cell<T>` и ја враќа внатрешната вредност.
//!  Дополнително, методот [`set`](Cell::set) ја заменува внатрешната вредност, паѓајќи ја заменетата вредност.
//!
//! `RefCell<T>` ги користи животите на Rust за да спроведе " динамично позајмување`, процес според кој може да се бара привремен, ексклузивен, непроменлив пристап до внатрешната вредност.
//! Бороус за `RefCell`<T>`s се следат 'при траење', за разлика од мајчините референтни типови на Rust кои целосно се следат статички, во времето на компајлирање.
//! Бидејќи заемите за `RefCell<T>` се динамични, можно е да се обиде да позајми вредност што е веќе заемно позајмена;кога тоа ќе се случи, тоа резултира со нишка panic.
//!
//! # Кога да се избере внатрешна променливост
//!
//! Почестата наследна мотабилност, каде што мора да се има единствен пристап за да мутираме вредност, е еден од клучните јазични елементи што му овозможува на Rust да расудува силно за псевдоним на покажувачот, статички спречувајќи грешки при паѓање.
//! Поради тоа, се претпочита наследна подвижност, а внатрешната променливост е нешто како последно средство.
//! Бидејќи типовите клетки овозможуваат мутација таму каде што инаку не би била дозволена, постојат случаи кога внатрешната подвижност е соодветна, па дури и *мора* да се користи, на пр.
//!
//! * Воведување на променливост 'inside' на нешто непроменливо
//! * Детали за имплементација на логички непроменливи методи.
//! * Мутирање на имплементациите на [`Clone`].
//!
//! ## Воведување на променливост 'inside' на нешто непроменливо
//!
//! Многу споделени типови на паметни покажувачи, вклучително и [`Rc<T>`] и [`Arc<T>`], даваат контејнери што можат да се клонираат и споделат помеѓу повеќе страни.
//! Бидејќи содржаните вредности можат да бидат повеќекратно-алијазни, тие можат да се позајмат само со `&`, а не со `&mut`.
//! Без ќелии, би било невозможно воопшто да се мутираат податоците во овие паметни покажувачи.
//!
//! Многу е вообичаено тогаш да се стави `RefCell<T>` внатре споделени типови на покажувачи за повторно да се воведе подвижност:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Создадете нов блок за да го ограничите обемот на динамичкото позајмување
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Забележете дека ако не дозволевме претходното позајмување на меморијата да излезе од опсегот, тогаш последователното позајмување ќе предизвикаше динамична нишка panic.
//!     //
//!     // Ова е најголемата опасност од користење на `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Забележете дека овој пример користи `Rc<T>`, а не `Arc<T>`.`RefCell<T>`s се за сценарија со еден навој.Размислете за употреба на [`RwLock<T>`] или [`Mutex<T>`] ако ви треба споделена подвижност во ситуација со повеќе нишки.
//!
//! ## Детали за имплементација на логички непроменливи методи
//!
//! Повремено може да биде пожелно во API да не се открие дека се случува мутација "under the hood".
//! Ова може да биде затоа што логично операцијата е непроменлива, но на пр., Кеширањето го принудува спроведувањето да изврши мутација;или затоа што мора да користите мутација за да го имплементирате методот trait кој првично беше дефиниран за да се земе `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Скапата пресметка оди овде
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутирање на имплементациите на `Clone`
//!
//! Ова е едноставно посебен, но вообичаен случај од претходниот: криење на неподвижност за операции што се чини дека се непроменливи.
//! [`clone`](Clone::clone) методот се очекува да не ја смени изворната вредност и е прогласен за `&self`, а не `&mut self`.
//! Затоа, секоја мутација што се случува во методот `clone` мора да користи типови клетки.
//! На пример, [`Rc<T>`] ги одржува своите референтни броеви во рамките на `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Местоположба на меморија.
///
/// # Examples
///
/// Во овој пример, можете да видите дека `Cell<T>` овозможува мутација во непроменлива структура.
/// Со други зборови, тој овозможува "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ГРЕШКА: `my_struct` е непроменлива
/// // my_struct.regular_field =нова_вредност;
///
/// // РАБОТИ: иако `my_struct` е непроменлив, `special_field` е `Cell`,
/// // што секогаш може да се мутира
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Создава `Cell<T>`, со вредноста `Default` за Т.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Создава нов `Cell` што ја содржи дадената вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ја поставува содржаната вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Разменувајте ги вредностите на две ќелии.
    /// Разликата со `std::mem::swap` е што оваа функција не бара референца за `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЕЗБЕДНОСТ: Ова може да биде ризично ако се повика од одделни нишки, но `Cell`
        // е `!Sync`, така што ова нема да се случи.
        // Ова исто така нема да поништи ниту еден покажувач бидејќи `Cell` се грижи ништо друго да не покажува во ниту еден од овие `ќелии.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ја заменува содржаната вредност со `val` и ја враќа старата содржана вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЕЗБЕДНОСТ: Ова може да предизвика раси на податоци ако се повикаат од посебна нишка,
        // но `Cell` е `!Sync` па ова нема да се случи.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Ја одвиткува вредноста.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Враќа копија од содржаната вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЕЗБЕДНОСТ: Ова може да предизвика раси на податоци ако се повикаат од посебна нишка,
        // но `Cell` е `!Sync` па ова нема да се случи.
        unsafe { *self.value.get() }
    }

    /// Ја ажурира содржаната вредност користејќи функција и ја враќа новата вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Враќа суров покажувач на основните податоци во оваа ќелија.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Враќа непроменлива референца на основните податоци.
    ///
    /// Овој повик позајмува `Cell` немирно (во време на компајлирање) што гарантира дека ја поседуваме единствената референца.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Враќа `&Cell<T>` од `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЕЗБЕДНОСТ: `&mut` обезбедува единствен пристап.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ја зема вредноста на ќелијата, оставајќи го `Default::default()` на своето место.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Враќа `&[Cell<T>]` од `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЕЗБЕДНОСТ: `Cell<T>` има ист распоред на меморија како `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Локација на менлива меморија со динамички проверени правила за позајмување
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Грешка вратена од [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Грешка вратена од [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Позитивните вредности претставуваат број на активни `Ref`.Негативните вредности го претставуваат бројот на активни `RefMut`.
// Повеќе `RefMut` можат да бидат активни истовремено само ако се однесуваат на различни, не-преклопувачки компоненти на `RefCell` (на пример, различни опсези на парче).
//
// `Ref` и `RefMut` се обем со два збора, и затоа веројатно нема да има доволно `Ref` s или `RefMut` за да прелее половина од опсегот `usize`.
// Така, `BorrowFlag` веројатно никогаш нема да се прелее или да се прелее.
// Сепак, ова не е гаранција, бидејќи патолошка програма може постојано да креира, а потоа mem::forget `Ref`s или`RefMut`s.
// Така, целиот код мора експлицитно да провери дали има прелевање и прелевање, за да се избегне несигурност или барем да се однесува правилно во случај да се случи прелевање или прелевање (на пр., Видете BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Создава нов `RefCell` кој содржи `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Го троши `RefCell`, враќајќи ја завитканата вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Бидејќи оваа функција зема `self` (`RefCell`) по вредност, компајлерот статички потврдува дека не е позајмен во моментот.
        //
        self.value.into_inner()
    }

    /// Ја заменува завитканата вредност со нова, враќајќи ја старата вредност, без деинцијализирање на ниту една.
    ///
    ///
    /// Оваа функција одговара на [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ако вредноста е моментално позајмена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ја заменува завитканата вредност со нова пресметана од `f`, враќајќи ја старата вредност, без деинцијализирање на ниту една.
    ///
    ///
    /// # Panics
    ///
    /// Panics ако вредноста е моментално позајмена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ја менува завитканата вредност на `self` со завитканата вредност на `other`, без деинцијализирање на ниту една.
    ///
    ///
    /// Оваа функција одговара на [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Незаменливо ја позајмува завитканата вредност.
    ///
    /// Заемот трае сè додека вратениот `Ref` не излезе од опсегот.
    /// Во исто време може да се земат повеќе непроменливи позајмици.
    ///
    /// # Panics
    ///
    /// Panics ако вредноста во моментов е заемно позајмена.
    /// За варијанта без паника, користете [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Пример за panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Незаменливо ја позајмува завитканата вредност, враќајќи грешка ако вредноста во моментов е заемно позајмена.
    ///
    ///
    /// Заемот трае сè додека вратениот `Ref` не излезе од опсегот.
    /// Во исто време може да се земат повеќе непроменливи позајмици.
    ///
    /// Ова е варијанта на паника за [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЕЗБЕДНОСТ: `BorrowRef` гарантира дека има само непроменлив пристап
            // до вредноста додека се позајмува.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Незаменливо ја позајмува завитканата вредност.
    ///
    /// Заемот трае сè додека вратениот `RefMut` или целиот `RefMut` што произлегува од него, не излезе од опсегот.
    ///
    /// Вредноста не може да се позајми додека е активна оваа позајмица.
    ///
    /// # Panics
    ///
    /// Panics ако вредноста е моментално позајмена.
    /// За варијанта без паника, користете [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Пример за panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Незаменливо ја позајмува завитканата вредност, враќајќи грешка ако вредноста е позајмена.
    ///
    ///
    /// Заемот трае сè додека вратениот `RefMut` или целиот `RefMut` што произлегува од него, не излезе од опсегот.
    /// Вредноста не може да се позајми додека е активна оваа позајмица.
    ///
    /// Ова е варијанта на паника за [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЕЗБЕДНОСТ: `BorrowRef` гарантира уникатен пристап.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Враќа суров покажувач на основните податоци во оваа ќелија.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Враќа непроменлива референца на основните податоци.
    ///
    /// Овој повик позајмува `RefCell` неисполнето (во време на компајлирање) така што нема потреба од динамички проверки.
    ///
    /// Сепак бидете претпазливи: овој метод очекува `self` да биде променлив, што обично не е случај кога се користи `RefCell`.
    ///
    /// Погледнете го методот [`borrow_mut`] наместо тоа, ако `self` не е податлив.
    ///
    /// Исто така, ве молиме, бидете свесни дека овој метод е само за посебни околности и обично не е она што го сакате.
    /// Во случај на сомнеж, наместо тоа, користете [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Врати го ефектот на протеконите заштитници врз состојбата на позајмување на `RefCell`.
    ///
    /// Овој повик е сличен на [`get_mut`], но поспецијализиран.
    /// Го позајмува `RefCell` неизвесно за да се осигури дека нема заеми и потоа ги ресетира состојбите што ги следи заедничките позајмици.
    /// Ова е релевантно ако протекоа некои позајмици `Ref` или `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Незаменливо ја позајмува завитканата вредност, враќајќи грешка ако вредноста во моментов е заемно позајмена.
    ///
    /// # Safety
    ///
    /// За разлика од `RefCell::borrow`, овој метод е небезбеден затоа што не враќа `Ref`, оставајќи го знамето на позајмицата недопрено.
    /// Незаменливото позајмување на `RefCell` додека е упатена референцата со овој метод е недефинирано однесување.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЕЗБЕДНОСТ: Проверуваме дека никој не пишува активно сега, но така е
            // одговорност на повикувачот да осигура дека никој не пишува додека вратената референца не е во употреба.
            // Исто така, `self.value.get()` се однесува на вредноста што ја поседува `self` и со тоа се гарантира дека важи за целиот животен век на `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ја зема завитканата вредност, оставајќи го `Default::default()` на своето место.
    ///
    /// # Panics
    ///
    /// Panics ако вредноста е моментално позајмена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ако вредноста во моментов е заемно позајмена.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Создава `RefCell<T>`, со вредноста `Default` за Т.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ако вредноста или во `RefCell` е моментално позајмена.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Зголемувањето на позајмицата може да резултира во нечитлива вредност (<=0) во овие случаи:
            // 1. Тоа беше <0, т.е. има заеми за запишување, така што не можеме да дозволиме читање на позајмица заради правилата за резиме на Rust
            // 2.
            // Беше isize::MAX (максималниот износ на позајмици за читање) и се прелеа во isize::MIN (максималниот износ на позајмици за пишување) така што не можеме да дозволиме дополнително позајмување за читање бидејќи изолирањето не може да претставува толку многу позајмици за читање (ова може да се случи само ако вие mem::forget повеќе од мала постојана количина на `Ref`, што не е добра практика)
            //
            //
            //
            //
            None
        } else {
            // Зголемувањето на позајмицата може да резултира со вредност на читање (> 0) во овие случаи:
            // 1. Беше=0, односно не беше позајмено, а ние го земаме првото прочитано позајмување
            // 2. Тоа беше> 0 и <isize::MAX, т.е.
            // имаше заеми за читање, а изолирањето е доволно големо за да претставува едно повеќе читано позајмување
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Бидејќи овој Ref постои, знаеме дека знамето за позајмица е заем за читање.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Спречете бројачот на позајмица да се прелее во пишување.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Завитка позајмена референца за вредност во полето `RefCell`.
/// Вид на обвивка за непроменливо позајмена вредност од `RefCell<T>`.
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Копира `Ref`.
    ///
    /// `RefCell` е веќе непроменливо позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `Ref::clone(...)`.
    /// Имплементација `Clone` или метод би попречил во широката употреба на `r.borrow().clone()` за клонирање на содржината на `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Прави нов `Ref` за компонента на позајмените податоци.
    ///
    /// `RefCell` е веќе непроменливо позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `Ref::map(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Прави нов `Ref` за изборна компонента на позајмените податоци.
    /// Оригиналниот штитник се враќа како `Err(..)` ако затворачот се врати `None`.
    ///
    /// `RefCell` е веќе непроменливо позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `Ref::filter_map(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Го дели `Ref` на повеќе `Ref` за различни компоненти на позајмените податоци.
    ///
    /// `RefCell` е веќе непроменливо позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `Ref::map_split(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Претворете во повикување на основните податоци.
    ///
    /// Основната `RefCell` никогаш повеќе не може да биде заемно позајмена и секогаш ќе се појавува веќе непроменливо позајмена.
    ///
    /// Не е добра идеја да истекувате повеќе од постојан број на препораки.
    /// `RefCell` може повторно да се позајми неповратно, доколку се случиле само помал број на протекувања.
    ///
    /// Ова е поврзана функција што треба да се користи како `Ref::leak(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Со заборавање на овој Ref, осигуруваме дека бројачот на позајмици во RefCell не може да се врати на НЕУПОТРЕБЕН во текот на животот `'b`.
        // За ресетирање на состојбата за референтно следење ќе биде потребна единствена референца на позајмената RefCell.
        // Не може да се креираат понатамошни променливи препораки од оригиналната ќелија.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Прави нов `RefMut` за компонента на позајмените податоци, на пример, варијанта на енум.
    ///
    /// `RefCell` е веќе заемно позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `RefMut::map(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): поправи позајмица-чек
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Прави нов `RefMut` за изборна компонента на позајмените податоци.
    /// Оригиналниот штитник се враќа како `Err(..)` ако затворачот се врати `None`.
    ///
    /// `RefCell` е веќе заемно позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `RefMut::filter_map(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): поправи позајмица-чек
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЕЗБЕДНОСТ: функцијата се задржува на ексклузивна референца за времетраењето
        // од неговиот повик преку `orig`, а покажувачот се деферира само во внатрешноста на повикот за функција никогаш не дозволувајќи ексклузивна референца да избега.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЕЗБЕДНОСТ: исто како и погоре.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Го дели `RefMut` во повеќе `RefMut` за различни компоненти на позајмените податоци.
    ///
    /// Основниот `RefCell` ќе остане немирно позајмен сè додека и двата вратени `RefMut` не излезат од опсегот.
    ///
    /// `RefCell` е веќе заемно позајмен, така што ова не може да пропадне.
    ///
    /// Ова е поврзана функција што треба да се користи како `RefMut::map_split(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Претворете во неспокоен повик за основните податоци.
    ///
    /// Основната `RefCell` не може повторно да се позајми и секогаш ќе се појавува веќе немирно позајмена, со што вратената референца е единствена за внатрешноста.
    ///
    ///
    /// Ова е поврзана функција што треба да се користи како `RefMut::leak(...)`.
    /// Методот се меша со истоимените методи на содржината на `RefCell` што се користи преку `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Заборавајќи го овој BorrowRefMut, осигуруваме дека бројачот на позајмици во RefCell не може да се врати на НЕИскористениот во текот на животот `'b`.
        // За ресетирање на состојбата за референтно следење ќе биде потребна единствена референца на позајмената RefCell.
        // Во тој животен век не може да се креираат понатамошни препораки од оригиналната ќелија, со што тековното позајмување е единствената референца за преостанатиот животен век.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: За разлика од BorrowRefMut::clone, се повикува ново да се создаде почетната
        // непроменлива референца и затоа во моментов не смее да има постоечки препораки.
        // Така, додека клонот ја зголемува непроменливата пресметка, овде ние експлицитно дозволуваме преминување од НЕУПОТРЕБЕН во НЕУПОТРЕБЕН,
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонира `BorrowRefMut`.
    //
    // Ова е валидно само ако секој `BorrowRefMut` се користи за следење на неспорно упатување на посебен, опсег на непокривање на оригиналниот објект.
    //
    // Ова не е во смисла на клон, така што кодот не го повикува ова имплицитно.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Спречете го бројачот на позајмици да не тече под вода
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Вид на обвивка за заемно позајмена вредност од `RefCell<T>`.
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Основно примитивно за внатрешно менливост во Rust.
///
/// Ако имате референца `&T`, тогаш нормално во Rust компајлерот извршува оптимизации засновани врз знаењето дека `&T` упатува на непроменливи податоци.Мутирањето на тие податоци, на пример преку псевдоним или со трансмутирање на `&T` во `&mut T`, се смета за недефинирано однесување.
/// `UnsafeCell<T>` се исклучува од гаранцијата за непроменливост за `&T`: споделена референца `&UnsafeCell<T>` може да укаже на податоци што се мутираат.Ова се вика "interior mutability".
///
/// Сите други типови што овозможуваат внатрешна променливост, како што се `Cell<T>` и `RefCell<T>`, внатрешно користат `UnsafeCell` за да ги завиткаат своите податоци.
///
/// Забележете дека само гаранцијата за непроменливост на споделените референци е под влијание на `UnsafeCell`.Единствената гаранција за непроменливите референци не е засегната.*Нема* легален начин да се добие псевдоним `&mut`, дури ни со `UnsafeCell<T>`.
///
/// Самиот `UnsafeCell` API е технички многу едноставен: [`.get()`] ви дава суров покажувач `*mut T` до неговата содржина.До _you_ зависи како дизајнер на апстракција правилно да го користи тој суров покажувач.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Прецизните правила за псевдонимување на Rust се малку во тек, но главните поенти не се спорни:
///
/// - Ако создадете безбедна референца со цел живот `'a` (или референца `&T` или `&mut T`) што е достапна со безбеден код (на пример, затоа што сте ги вратиле), тогаш не смеете да пристапувате до податоците на кој било начин што е во спротивност со таа референца за остатокот од `'a`.
/// На пример, ова значи дека ако го земете `*mut T` од `UnsafeCell<T>` и го фрлите на `&T`, тогаш податоците во `T` мора да останат непроменливи (секако, да се најдат сите податоци за `UnsafeCell` во `T`), се додека не истече животот на тој референт.
/// Слично на тоа, ако креирате референца `&mut T` што се ослободува на безбеден код, тогаш не смеете да пристапувате до податоците во `UnsafeCell` додека не истече таа референца.
///
/// - Во секое време, мора да избегнувате трки со податоци.Ако повеќе нишки имаат пристап до истиот `UnsafeCell`, тогаш секое запишување мора да има соодветно случување пред да се однесува на сите други пристапи (или да се користи атомика).
///
/// За да се помогне при правилен дизајн, следниве сценарија се експлицитно прогласени за легални за код со една нишка:
///
/// 1. Референцата `&T` може да се објави на безбеден код и таму може да постои со други референци `&T`, но не и со `&mut T`
///
/// 2. Може да се објави референца `&mut T` на безбеден код, доколку со него не постои ниту друг `&mut T` ниту `&T`.`&mut T` секогаш мора да биде уникатен.
///
/// Имајте на ум дека додека мутирањето на содржината на `&UnsafeCell<T>` (дури и додека другите референци за `&UnsafeCell<T>` алијас на ќелијата) е во ред (под услов да ги примените горенаведените инваријанти на друг начин), сепак е недефинирано однесување да имате повеќе алијаси `&mut UnsafeCell<T>`.
/// Тоа е, `UnsafeCell` е обвивка дизајнирана да има посебна интеракција со _shared_ accesses (_i.e._, преку референца `&UnsafeCell<_>`);нема никаква магија кога се занимаваме со _exclusive_ accesses (_e.g._, преку `&mut UnsafeCell<_>`): ниту ќелијата ниту завитканата вредност не смеат да бидат псевдоними за времетраењето на тој заем `&mut`.
///
/// Ова е прикажано од приклучокот [`.get_mut()`], што е _safe_ getter што дава `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Еве еден пример во кој се прикажува како силно да се мутира содржината на `UnsafeCell<_>` и покрај тоа што има повеќе референци со алијас на ќелијата:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Добијте повеќе/истовремени/споделени препораки на истиот `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЕЗБЕДНОСТ: во рамките на овој опсег нема други препораки за содржината на `x`,
///     // така, нашата е ефективна единствена.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- позајми-+
///     *p1_exclusive += 27; // |
/// } // <---------- не може да оди подалеку од оваа точка -------------------+
///
/// unsafe {
///     // БЕЗБЕДНОСТ: во рамките на овој опсег никој не очекува да има ексклузивен пристап до содржината на `x`,
///     // за да можеме истовремено да имаме повеќе споделени пристапи.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Следниот пример го прикажува фактот дека ексклузивниот пристап до `UnsafeCell<T>` подразбира ексклузивен пристап до неговиот `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // со ексклузивни пристапи,
///                         // `UnsafeCell` е про transparentирна обвивка без опции, затоа нема потреба за `unsafe` тука.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Добијте единствена референца за проверка на времето за компајлирање на `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Со ексклузивна референца, можеме да ја мутираме содржината бесплатно.
/// *p_unique.get_mut() = 0;
/// // Или, еквивалентно:
/// x = UnsafeCell::new(0);
///
/// // Кога ја поседуваме вредноста, можеме да ја извлечеме содржината бесплатно.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Конструира нова инстанца на `UnsafeCell` што ќе ја завитка одредената вредност.
    ///
    ///
    /// Целиот пристап до внатрешната вредност преку методите е `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Ја одвиткува вредноста.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Добива неспокоен покажувач до завитканата вредност.
    ///
    /// Ова може да се пренесе на покажувач од секаков вид.
    /// Осигурете се дека пристапот е единствен (нема активни препораки, неспојлив или не) кога се емитува на `&mut T` и осигурете се дека нема никакви мутации или променливи псевдоними кога се емитуваат на `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Можеме само да го фрлиме покажувачот од `UnsafeCell<T>` до `T` поради #[repr(transparent)].
        // Ова го искористува специјалниот статус на libstd, нема гаранција за корисничкиот код дека ова ќе работи во future верзии на компајлерот!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Враќа непроменлива референца на основните податоци.
    ///
    /// Овој повик го позајмува `UnsafeCell` немирно (во време на компајлирање) што гарантира дека ја поседуваме единствената референца.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Добива неспокоен покажувач до завитканата вредност.
    /// Разликата со [`get`] е што оваа функција прифаќа суров покажувач, што е корисно за да се избегне создавање на привремени референци.
    ///
    /// Резултатот може да се фрли на покажувач од секаков вид.
    /// Осигурете се дека пристапот е единствен (нема активни препораки, неспојлив или не) кога се емитува на `&mut T` и осигурете се дека нема никакви мутации или променливи псевдоними кога се емитуваат на `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Постепено иницијализирање на `UnsafeCell` бара `raw_get`, бидејќи повикувањето на `get` ќе бара создавање упатување на неницијализирани податоци:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Можеме само да го фрлиме покажувачот од `UnsafeCell<T>` до `T` поради #[repr(transparent)].
        // Ова го искористува специјалниот статус на libstd, нема гаранција за корисничкиот код дека ова ќе работи во future верзии на компајлерот!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Создава `UnsafeCell`, со вредноста `Default` за Т.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}