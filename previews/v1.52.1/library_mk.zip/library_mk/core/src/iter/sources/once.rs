use crate::iter::{FusedIterator, TrustedLen};

/// Создава повторувач што дава елемент точно еднаш.
///
/// Ова обично се користи за прилагодување на една вредност во [`chain()`] од други видови повторувања.
/// Можеби имате итератор кој опфаќа скоро сè, но ви треба дополнителен специјален случај.
/// Можеби имате функција што работи на повторувачи, но треба да процесирате само една вредност.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // едниот е најосамениот број
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само еден, тоа е сè што добиваме
/// assert_eq!(None, one.next());
/// ```
///
/// Ланење заедно со друг повторувач.
/// Да речеме дека сакаме да повторуваме над секоја датотека од директориумот `.foo`, но исто така и датотека за конфигурација,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // треба да претвориме од повторувач на DirEntry-и во повторувач на PathBufs, па затоа користиме мапа
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сега, нашиот повторувач само за нашата конфигурациска датотека
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // синџири ги двата повторувачи заедно во еден голем повторувач
/// let files = dirs.chain(config);
///
/// // ова ќе ни ги даде сите датотеки во .foo, како и .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Итератор кој дава елемент точно еднаш.
///
/// Овој `struct` е создаден од функцијата [`once()`].Погледнете ја нејзината документација за повеќе.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}