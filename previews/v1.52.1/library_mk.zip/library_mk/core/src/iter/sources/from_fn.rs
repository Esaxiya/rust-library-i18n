use crate::fmt;

/// Создава нов повторувач каде што секоја повторување го повикува предвиденото затворање `F: FnMut() -> Option<T>`.
///
/// Ова овозможува креирање на сопствен повторувач со какво било однесување без употреба на повеќе глаголна синтакса на создавање на посебен тип и имплементација на [`Iterator`] trait за него.
///
/// Забележете дека повторувачот `FromFn` не прави претпоставки за однесувањето на затворањето, и затоа конзервативно не спроведува [`FusedIterator`] или не го надминува [`Iterator::size_hint()`] од неговиот стандарден `(0, None)`.
///
///
/// Затворањето може да користи снимања и неговата околина за да ја следи состојбата низ повторувања.Во зависност од тоа како се користи повторувачот, ова може да бара специфицирање на клучниот збор [`move`] на затворањето.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ајде повторно да го имплементираме повторувачот на бројачот од [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Зголемете го нашиот број.Ова е причината зошто започнавме на нула.
///     count += 1;
///
///     // Проверете дали сме завршиле со броење или не.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Итератор каде секоја повторување го повикува предвиденото затворање `F: FnMut() -> Option<T>`.
///
/// Овој `struct` е создаден од функцијата [`iter::from_fn()`].
/// Погледнете ја нејзината документација за повеќе.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}