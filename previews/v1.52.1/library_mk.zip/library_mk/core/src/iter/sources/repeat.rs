use crate::iter::{FusedIterator, TrustedLen};

/// Создава нов повторувач што бесконечно повторува еден елемент.
///
/// Функцијата `repeat()` повторува единствена вредност одново и одново.
///
/// Бесконечни повторувачи како `repeat()` често се користат со адаптери како [`Iterator::take()`], со цел да се направат конечни.
///
/// Ако типот на елементот на повторувачот што ви треба не го спроведува `Clone` или ако не сакате да го зачувате повторениот елемент во меморијата, наместо тоа, можете да ја користите функцијата [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // бројот четири 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // с, уште четири
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Одење конечно со [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // тој последен пример беше премногу четири.Да имаме само четири четворки.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... и сега завршивме
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Итератор кој бесконечно повторува елемент.
///
/// Овој `struct` е создаден од функцијата [`repeat()`].Погледнете ја нејзината документација за повеќе.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}