use crate::iter::{FusedIterator, TrustedLen};

/// Создава нов повторувач кој бесконечно повторува елементи од типот `A` со примена на предвиденото затворање, повторувачот, `F: FnMut() -> A`.
///
/// Функцијата `repeat_with()` го повикува повторувачот одново и одново.
///
/// Бесконечни повторувачи како `repeat_with()` често се користат со адаптери како [`Iterator::take()`], со цел да се направат конечни.
///
/// Ако типот на елементот на повторувачот што ви треба го спроведува [`Clone`], и во ред е да го задржите изворниот елемент во меморијата, наместо тоа, треба да ја користите функцијата [`repeat()`].
///
///
/// Итератор произведен од `repeat_with()` не е [`DoubleEndedIterator`].
/// Ако ви треба `repeat_with()` да вратите [`DoubleEndedIterator`], отворете проблем со GitHub во кој се објаснува случајот за употреба.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // да претпоставиме дека имаме одредена вредност од типот што не е `Clone` или кој не сака да го има во меморијата само затоа што е скап:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // одредена вредност засекогаш:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Користење на мутација и ограничување:
///
/// ```rust
/// use std::iter;
///
/// // Од нулата до третата моќност на два:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... и сега завршивме
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Итератор кој бесконечно повторува елементи од типот `A` со примена на предвидениот затворач `F: FnMut() -> A`.
///
///
/// Овој `struct` е создаден од функцијата [`repeat_with()`].
/// Погледнете ја нејзината документација за повеќе.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}