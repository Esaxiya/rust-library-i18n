use crate::iter::{FusedIterator, TrustedLen};

/// Создава итератор кој мрзливо генерира вредност точно еднаш со повикување на предвиденото затворање.
///
/// Ова обично се користи за прилагодување на генератор со една вредност во [`chain()`] од други видови повторувања.
/// Можеби имате итератор кој опфаќа скоро сè, но ви треба дополнителен специјален случај.
/// Можеби имате функција што работи на повторувачи, но треба да процесирате само една вредност.
///
/// За разлика од [`once()`], оваа функција мрзливо ќе ја генерира вредноста на барање.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // едниот е најосамениот број
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само еден, тоа е сè што добиваме
/// assert_eq!(None, one.next());
/// ```
///
/// Ланење заедно со друг повторувач.
/// Да речеме дека сакаме да повторуваме над секоја датотека од директориумот `.foo`, но исто така и датотека за конфигурација,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // треба да претвориме од повторувач на DirEntry-и во повторувач на PathBufs, па затоа користиме мапа
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сега, нашиот повторувач само за нашата конфигурациска датотека
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // синџири ги двата повторувачи заедно во еден голем повторувач
/// let files = dirs.chain(config);
///
/// // ова ќе ни ги даде сите датотеки во .foo, како и .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Итератор што дава единствен елемент од типот `A` со примена на предвидениот затворач `F: FnOnce() -> A`.
///
///
/// Овој `struct` е создаден од функцијата [`once_with()`].
/// Погледнете ја нејзината документација за повеќе.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}