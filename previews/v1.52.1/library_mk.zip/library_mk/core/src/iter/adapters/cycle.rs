use crate::{iter::FusedIterator, ops::Try};

/// Итератор кој се повторува бесконечно.
///
/// Овој `struct` е создаден со методот [`cycle`] на [`Iterator`].
/// Погледнете ја нејзината документација за повеќе.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // повторувачот на циклусот е или празен или бесконечен
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // целосно повторете го тековниот повторувач.
        // ова е потребно затоа што `self.iter` може да биде празен дури и кога `self.orig` не е
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // завршете целосен циклус, следете дали циклусниот повторувач е празен или не.
        // треба да се вратиме рано во случај на празен повторувач за да спречиме бесконечна јамка
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Нема `fold` пречекорување, бидејќи `fold` нема многу смисла за `Cycle` и не можеме да направиме ништо подобро од стандардното.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}