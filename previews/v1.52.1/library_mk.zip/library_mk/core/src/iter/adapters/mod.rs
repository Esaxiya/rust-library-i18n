use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Овој trait обезбедува преоден пристап до изворната фаза во цевководот интератер-адаптер под услови што
/// * самиот извор на повторувач `S` го спроведува `SourceIter<Source = S>`
/// * постои делегирачка имплементација на овој trait за секој адаптер во цевководот помеѓу изворот и потрошувачот на гасоводот.
///
/// Кога изворот е сопственик на структурата на повторувачот (обично се нарекува `IntoIter`), ова може да биде корисно за специјализирање на имплементациите на [`FromIterator`] или за враќање на преостанатите елементи откако делумно ќе се исцрпи повторувачот.
///
///
/// Имајте на ум дека имплементациите не мора да обезбедуваат пристап до најголемиот внатрешен извор на гасоводот.Адектуелен среден адаптер може со нетрпение да процени дел од гасоводот и да го изложи неговото внатрешно складирање како извор.
///
/// trait е небезбеден затоа што имплементаторите мора да ги следат дополнителните безбедносни својства.
/// Погледнете [`as_inner`] за детали.
///
/// # Examples
///
/// Преземање на делумно потрошен извор:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Изворна фаза во гасоводот на повторувачот.
    type Source: Iterator;

    /// Преземете го изворот на гасоводот итератор.
    ///
    /// # Safety
    ///
    /// Спроведувањето на мора да ја врати истата непроменлива референца за нивниот животен век, освен ако не се замени со повикувач.
    /// Повикувачите можат да ја заменат референцата само кога ќе престанат со повторување и ќе го испуштат гасоводот со повторувач по извлекувањето на изворот.
    ///
    /// Ова значи дека адаптерите на повторувачот можат да се потпрат на изворот што не се менува за време на повторувањето, но не можат да се потпрат на тоа во имплементациите на Drop.
    ///
    /// Спроведувањето на овој метод значи дека адаптарите се одрекуваат од пристапот само до приватниот извор и можат да се потпрат само на гаранциите направени врз основа на типовите на приемниците на методот.
    /// Недостатокот на ограничен пристап исто така бара адаптерите да го поддржуваат јавниот API на изворот дури и кога имаат пристап до неговите внатрешни.
    ///
    /// Повикувачите за возврат мора да очекуваат изворот да биде во која било состојба што е во согласност со нејзиниот јавен API, бидејќи адаптерите што седат помеѓу него и изворот имаат ист пристап.
    /// Особено, адаптер може да потроши повеќе елементи отколку што е строго потребно.
    ///
    /// Главната цел на овие барања е да се дозволи потрошувачот на гасоводот да користи
    /// * што и да остане во изворот откако ќе престане повторувањето
    /// * меморијата што стана неискористена со унапредување на повторувач што троши
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Адаптер за повторувач што произведува излез се додека основниот итератор произведува вредности `Result::Ok`.
///
///
/// Ако се појави грешка, повторувачот застанува и грешката се зачувува.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Обработете го дадениот повторувач како да дава `T` наместо `Result<T, _>`.
/// Било какви грешки ќе го запрат внатрешниот повторувач и целокупниот резултат ќе биде грешка.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}