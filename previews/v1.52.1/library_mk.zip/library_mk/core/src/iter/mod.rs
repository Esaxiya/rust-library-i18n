//! Компонирана надворешна повторување.
//!
//! Ако сте се нашле со колекција од некаков вид и имате потреба да извршите операција врз елементите на наведената колекција, брзо ќе наидете на 'iterators'.
//! Итераторите многу се користат во идиоматичниот код Rust, па затоа вреди да се запознаете со нив.
//!
//! Пред да објасните повеќе, да разговараме за тоа како е структуриран овој модул:
//!
//! # Organization
//!
//! Овој модул е во голема мера организиран според типот:
//!
//! * [Traits] се основниот дел: овие traits дефинираат каков вид повторувачи постојат и што можете да направите со нив.Методите на овие traits вреди да се вложи дополнително време за студирање.
//! * [Functions] дадете неколку корисни начини да создадете некои основни повторувачи.
//! * [Structs] честопати се повратни типови на различни методи на traits на овој модул.Обично ќе сакате да го погледнете методот што го создава `struct`, наместо самиот `struct`.
//! За повеќе детали во врска со причината, видете " [Имплементирање на Iterator](#имплементација-итератор)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Тоа е тоа!Ајде да копаме во повторувачи.
//!
//! # Iterator
//!
//! Срцето и душата на овој модул е [`Iterator`] trait.Јадрото на [`Iterator`] изгледа вака:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Итераторот има метод, [`next`], кој кога ќе се повика, враќа [" Опција`] " <Item>`
//! [`next`] ќе го врати [`Some(Item)`] сè додека има елементи и откако сите ќе бидат исцрпени, ќе го врати `None` за да покаже дека повторувањето е завршено.
//! Индивидуалните повторувачи можат да изберат да продолжат со повторување и затоа повикувањето [`next`] повторно може или не може на крајот да започне повторно да го враќа [`Some(Item)`] во одреден момент (на пример, видете [`TryIter`]).
//!
//!
//! Комплетната дефиниција на [" Итератор`] вклучува и низа други методи, но тие се стандардни методи, изградени на врвот на [`next`] и така ќе ги добиете бесплатно.
//!
//! Итераторите се исто така композибилни и вообичаено е да се синџират заедно за да се направат посложени форми на обработка.Погледнете го делот [Adapters](#adapters) подолу за повеќе детали.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Трите форми на повторување
//!
//! Постојат три вообичаени методи кои можат да создадат повторувачи од колекција:
//!
//! * `iter()`, што се повторува преку `&T`.
//! * `iter_mut()`, што се повторува преку `&mut T`.
//! * `into_iter()`, што се повторува преку `T`.
//!
//! Различни работи во стандардната библиотека можат да спроведат една или повеќе од трите, каде што е соодветно.
//!
//! # Спроведува Итератор
//!
//! Креирање на повторувач за свој вклучува два чекори: создавање `struct` за да ја задржи состојбата на повторувачот, и потоа спроведување на [`Iterator`] за тој `struct`.
//! Затоа, има многу структури во овој модул: има по еден за секој повторувач и адаптер за повторувач.
//!
//! Ајде да направиме повторувач по име `Counter` кој се смета од `1` до `5`:
//!
//! ```
//! // Прво, структурата:
//!
//! /// Итератор кој брои од еден до пет
//! struct Counter {
//!     count: usize,
//! }
//!
//! // сакаме нашиот број да започне од еден, па да додадеме метод new() за да ви помогнеме.
//! // Ова не е строго потребно, но е погодно.
//! // Забележете дека започнуваме `count` на нула, ќе видиме зошто во спроведувањето `next()`'s подолу.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Потоа, ние го имплементираме `Iterator` за нашиот `Counter`:
//!
//! impl Iterator for Counter {
//!     // ќе сметаме со количината
//!     type Item = usize;
//!
//!     // next() е единствениот потребен метод
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Зголемете го нашиот број.Ова е причината зошто започнавме на нула.
//!         self.count += 1;
//!
//!         // Проверете дали сме завршиле со броење или не.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // И сега можеме да го користиме!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Повикувањето на [`next`] на овој начин станува повторливо.Rust има конструкција што може да повика [`next`] на вашиот повторувач, сè додека не достигне `None`.Ајде да преминеме на тоа следно.
//!
//! Исто така, забележете дека `Iterator` обезбедува стандардна имплементација на методи како што се `nth` и `fold` кои го повикуваат `next` внатрешно.
//! Сепак, исто така е можно да се напише прилагодено спроведување на методи како `nth` и `fold` ако повторувач може да ги пресмета поефикасно без да повика `next`.
//!
//! # `for` петелки и `IntoIterator`
//!
//! Синтаксата на јамката `for` на Rust е всушност шеќер за повторувачи.Еве основен пример за `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ова ќе ги отпечати броевите еден до пет, секој на својата линија.Но, тука ќе забележите нешто: ние никогаш не повикавме ништо на нашиот vector да произведеме повторувач.Што дава?
//!
//! Во стандардната библиотека има trait за претворање на нешто во повторувач: [`IntoIterator`].
//! Овој trait има еден метод, [`into_iter`], кој го претвора она што го спроведува [`IntoIterator`] во повторувач.
//! Ајде повторно да ја разгледаме таа јамка `for` и во што компајлерот ја претвора:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Де-шеќери во Rust во:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Прво, ја повикуваме `into_iter()` на вредноста.Потоа, се поклопуваме на повторувачот што се враќа, повикувајќи се на [`next`] повеќе и повеќе додека не видиме `None`.
//! Во тој момент, ние `break` излеговме од јамката и завршивме со повторување.
//!
//! Тука има уште еден суптилен дел: стандардната библиотека содржи интересна имплементација на [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Со други зборови, сите [" Iterator`] го спроведуваат [`IntoIterator`], само со враќање на себе.Ова значи две работи:
//!
//! 1. Ако пишувате [`Iterator`], можете да го користите со јамка `for`.
//! 2. Ако креирате колекција, имплементирањето на [`IntoIterator`] за тоа ќе овозможи вашата колекција да се користи со јамката `for`.
//!
//! # Повторување по референца
//!
//! Бидејќи [`into_iter()`] зема `self` по вредност, користејќи `for` јамка за повторување над колекција ја троши таа колекција.Честопати, можеби ќе сакате да повторите некоја колекција без да ја потрошите.
//! Многу колекции нудат методи кои обезбедуваат повторувачи во однос на референците, конвенционално наречени `iter()` и `iter_mut()` соодветно:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` сè уште е во сопственост на оваа функција.
//! ```
//!
//! Ако колекцијата тип `C` обезбедува `iter()`, таа обично имплементира `IntoIterator` и за `&C`, со имплементација што само повикува `iter()`.
//! Исто така, колекцијата `C` што обезбедува `iter_mut()` генерално спроведува `IntoIterator` за `&mut C` со делегирање на `iter_mut()`.Ова овозможува удобен стенопис:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // исто како и `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // исто како и `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Додека многу колекции нудат `iter()`, не сите нудат `iter_mut()`.
//! На пример, мутирање на копчињата на [`HashSet<T>`] или [`HashMap<K, V>`] може да ја стави колекцијата во неконзистентна состојба ако се смени хаш-клучот, па затоа овие колекции нудат само `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Функциите што земаат [`Iterator`] и враќаат друг [`Iterator`] честопати се нарекуваат " адаптери за повторувачи`, бидејќи тие се форма на " адаптер`
//! pattern'.
//!
//! Заедничките адаптери за повторувачи вклучуваат [`map`], [`take`] и [`filter`].
//! За повеќе, видете ја нивната документација.
//!
//! Ако адаптер за повторувач panics, повторувачот ќе биде во неодредена (но безбедна меморија) состојба.
//! Оваа состојба, исто така, не е загарантирана да остане иста во верзиите на Rust, па затоа треба да избегнувате да се потпирате на точните вредности вратени од повторувачот што се испаничи.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторите (и повторувачот [adapters](#adapters)) се *мрзливи*. Ова значи дека само создавањето повторувач не е _do_ во целина. Ништо навистина не се случува додека не се јавите во [`next`].
//! Ова понекогаш е извор на конфузија при креирање повторувач исклучиво заради неговите несакани ефекти.
//! На пример, методот [`map`] повикува затворање на секој елемент што го повторува:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ова нема да печати никакви вредности, бидејќи ние создадовме само повторувач, наместо да го користиме.Компајлерот ќе не предупреди за ваквото однесување:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Идиоматски начин да напишете [`map`] за неговите несакани ефекти е да користите јамка `for` или да се јавите на методот [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Друг вообичаен начин да се оцени повторувачот е да се користи методот [`collect`] за да се произведе нова колекција.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Повторувачите не мора да бидат конечни.Како пример, опсегот со отворен крај е бесконечен повторувач:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Вообичаено е да се користи адаптерот за повторувач [`take`] за да се претвори бесконечен повторувач во конечен:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ова ќе ги отпечати броевите `0` до `4`, секој на својата линија.
//!
//! Имајте на ум дека методите на бесконечни повторувачи, дури и оние за кои резултатот може да се одреди математички во конечно време, може да не завршат.
//! Поточно, методите како што е [`min`], кои во општ случај бараат прелистување на секој елемент во повторувачот, веројатно нема успешно да се вратат за ниеден бесконечен повторувач.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // О не!Бесконечна јамка!
//! // `ones.min()` предизвикува бесконечна јамка, затоа нема да ја достигнеме оваа точка!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;