use crate::ops::{ControlFlow, Try};

/// Итератор што може да дава елементи од двата краја.
///
/// Нешто што го имплементира `DoubleEndedIterator` има една дополнителна можност во однос на нешто што го спроведува [`Iterator`]: можност за земање на `Item` од задната страна, како и од предната страна.
///
///
/// Важно е да се напомене дека и напред и назад работат на ист опсег и не преминуваат: повторувањето завршува кога ќе се сретнат на средина.
///
/// На сличен начин со протоколот [`Iterator`], еднаш `DoubleEndedIterator` го враќа [`None`] од [`next_back()`], повикувајќи го повторно може да го врати [`Some`] повторно или не.
/// [`next()`] и [`next_back()`] се заменливи за оваа намена.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Отстранува и враќа елемент од крајот на повторувачот.
    ///
    /// Враќа `None` кога нема повеќе елементи.
    ///
    /// Документите [trait-level] содржат повеќе детали.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Елементите дадени со методите на `DoubleEndedIterator` може да се разликуваат од оние што ги даваат методите на [Iterator]]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Го напредува повторувачот одзади со елементи `n`.
    ///
    /// `advance_back_by` е обратна верзија на [`advance_by`].Овој метод со нетрпение ќе ги прескокне елементите `n` почнувајќи од задната страна со повикување на [`next_back`] до `n` пати додека не се сретне [`None`].
    ///
    /// `advance_back_by(n)` ќе врати [`Ok(())`] ако повторувачот успешно напредува за `n` елементи, или [`Err(k)`] ако се сретне [`None`], каде `k` е бројот на елементи со коишто напредувачот пред да истече елементи (т.е.
    /// должината на повторувачот).
    /// Забележете дека `k` е секогаш помал од `n`.
    ///
    /// Повикувањето на `advance_back_by(0)` не троши никакви елементи и секогаш враќа [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // само `&3` беше прескокнат
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Го враќа `n`-тиот елемент од крајот на повторувачот.
    ///
    /// Ова во суштина е обратна верзија на [`Iterator::nth()`].
    /// Иако како и повеќето операции за индексирање, броењето започнува од нула, така што `nth_back(0)` ја враќа првата вредност од крајот, `nth_back(1)` втората, итн.
    ///
    ///
    /// Забележете дека сите елементи помеѓу крајот и вратениот елемент ќе бидат потрошени, вклучително и вратениот.
    /// Ова исто така значи дека повикувањето `nth_back(0)` повеќе пати на ист повторувач ќе врати различни елементи.
    ///
    /// `nth_back()` ќе врати [`None`] ако `n` е поголема или еднаква на должината на повторувачот.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Повикувањето на `nth_back()` повеќе пати не го враќа назад повторувачот:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Враќање на `None` ако има помалку од `n + 1` елементи:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ова е обратна верзија на [`Iterator::try_fold()`]: потребни се елементи почнувајќи од задниот дел на повторувачот.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Бидејќи е во краток спој, останатите елементи се сè уште достапни преку повторувачот.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод на повторувач кој ги намалува елементите на повторувачот на една, крајна вредност, почнувајќи од задната страна.
    ///
    /// Ова е обратна верзија на [`Iterator::fold()`]: потребни се елементи почнувајќи од задниот дел на повторувачот.
    ///
    /// `rfold()` зема два аргументи: почетна вредност и затворање со два аргументи: 'accumulator' и елемент.
    /// Затворањето ја враќа вредноста што треба да ја има акумулаторот за следното повторување.
    ///
    /// Почетната вредност е вредноста што акумулаторот ќе ја има на првиот повик.
    ///
    /// Откако ќе го примените ова затворање на секој елемент на повторувачот, `rfold()` го враќа акумулаторот.
    ///
    /// Оваа операција понекогаш се нарекува 'reduce' или 'inject'.
    ///
    /// Преклопувањето е корисно секогаш кога имате колекција од нешто, и сакате да произведете единствена вредност од тоа.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // збирот на сите елементи на a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Овој пример гради низа, почнувајќи со почетна вредност и продолжувајќи со секој елемент од задната страна до предната страна:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Пребарува елемент на повторувач од задната страна што задоволува предикат.
    ///
    /// `rfind()` зафаќа затворање што враќа `true` или `false`.
    /// Го применува ова затворање на секој елемент од повторувачот, почнувајќи од крајот, и ако некој од нив врати `true`, тогаш `rfind()` враќа [`Some(element)`].
    /// Ако сите вратат `false`, тоа враќа [`None`].
    ///
    /// `rfind()` е краток спој;со други зборови, тој ќе престане да се обработува веднаш штом затворањето се врати `true`.
    ///
    /// Бидејќи `rfind()` зема референца, и многу повторувачи повторуваат над референците, ова доведува до евентуално збунувачка ситуација кога аргументот е двојна референца.
    ///
    /// Овој ефект можете да го видите во примерите подолу, со `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Запирање на првиот `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}