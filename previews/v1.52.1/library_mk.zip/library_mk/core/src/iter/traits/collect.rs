/// Конверзија од [`Iterator`].
///
/// Со имплементирање на `FromIterator` за еден вид, дефинирате како ќе се креира од повторувач.
/// Ова е вообичаено за типови кои опишуваат колекција од некаков вид.
///
/// [`FromIterator::from_iter()`] ретко се нарекува експлицитно и наместо тоа се користи преку методот [`Iterator::collect()`].
///
/// Погледнете ја документацијата [`Iterator::collect()`]'s за повеќе примери.
///
/// Исто така види: [`IntoIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Користење на [`Iterator::collect()`] за имплицитно користење на `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Спроведување на `FromIterator` за вашиот тип:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Збирка примерок, тоа е само обвивка над Вец<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ајде да му дадеме неколку методи за да можеме да создадеме еден и да додадеме работи на него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и ќе го имплементираме FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Сега можеме да направиме нов повторувач ...
/// let iter = (0..5).into_iter();
///
/// // ... и направете MyCollection од него
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // собери и дела!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Создава вредност од повторувач.
    ///
    /// Погледнете го [module-level documentation] за повеќе.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Конверзија во [`Iterator`].
///
/// Со имплементирање на `IntoIterator` за еден вид, дефинирате како ќе се претвори во повторувач.
/// Ова е вообичаено за типови кои опишуваат колекција од некаков вид.
///
/// Една придобивка од спроведувањето на `IntoIterator` е тоа што вашиот тип ќе биде [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Исто така види: [`FromIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Спроведување на `IntoIterator` за вашиот тип:
///
/// ```
/// // Збирка примерок, тоа е само обвивка над Вец<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ајде да му дадеме неколку методи за да можеме да создадеме еден и да додадеме работи на него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и ќе го имплементираме IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Сега можеме да направиме нова колекција ...
/// let mut c = MyCollection::new();
///
/// // ... додадете некои работи на тоа ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... и потоа претворете го во Итератор:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Вообичаено е да се користи `IntoIterator` како trait bound.Ова овозможува да се смени типот на собирање на влез, сè додека сè уште е повторувач.
/// Дополнителни граници може да се специфицираат со ограничување на
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Тип на елементи што се повторуваат.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Во кој вид повторувач го претвораме ова?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Создава повторувач од вредност.
    ///
    /// Погледнете го [module-level documentation] за повеќе.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Проширете ја колекцијата со содржината на повторувачот.
///
/// Итераторите произведуваат низа вредности, а збирките може да се сметаат и како низа вредности.
/// `Extend` trait го премостува овој јаз, што ви овозможува да ја проширите колекцијата со вклучување на содржината на тој повторувач.
/// Кога продолжувате колекција со веќе постоечки клуч, тој запис се ажурира или, во случај на колекции што дозволуваат повеќе записи со еднакви клучеви, тој запис се вметнува.
///
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // Може да продолжите низа со некои карактери:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Спроведување на `Extend`:
///
/// ```
/// // Збирка примерок, тоа е само обвивка над Вец<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ајде да му дадеме неколку методи за да можеме да создадеме еден и да додадеме работи на него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // бидејќи MyCollection има список на i32, ние спроведуваме Extend for i32
/// impl Extend<i32> for MyCollection {
///
///     // Ова е малку поедноставно со потписот на бетонски тип: можеме да повикаме продолжување на сè што може да се претвори во Итератор што ни дава i32s.
///     // Затоа што ни треба i32s за да ги ставиме во MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Имплементацијата е многу јасна: проверете низ повторувачот и add() секој елемент за нас самите.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ајде да ја прошириме нашата колекција со уште три броја
/// c.extend(vec![1, 2, 3]);
///
/// // ги додадовме овие елементи на крајот
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Проширува колекција со содржината на повторувачот.
    ///
    /// Бидејќи ова е единствениот потребен метод за овој trait, документите [trait-level] содржат повеќе детали.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // Може да продолжите низа со некои карактери:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Проширува колекција со точно еден елемент.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Резервира капацитет во збирка за даден број дополнителни елементи.
    ///
    /// Стандардната имплементација не прави ништо.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}