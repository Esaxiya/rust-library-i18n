// игнорирај ја уредната должина на датотеката Оваа датотека скоро исклучиво се состои од дефиниција за `Iterator`.
// Не можеме да го поделиме тоа на повеќе датотеки.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Интерфејс за работа со повторувачи.
///
/// Ова е главниот повторувач trait.
/// За повеќе информации за концептот на повторувачи генерално, видете во [module-level documentation].
/// Особено, можеби ќе сакате да знаете како да [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Тип на елементи што се повторуваат.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Го напредува повторувачот и ја враќа следната вредност.
    ///
    /// Враќа [`None`] кога ќе заврши повторувањето.
    /// Индивидуалните имплементации на повторувачот може да изберат да продолжат со повторување и затоа повикувањето на `next()` повторно може или не може на крајот да започне повторно да го враќа [`Some(Item)`] во одреден момент.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Повик до next() ја враќа следната вредност ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... и тогаш Ништо откако ќе заврши.
    /// assert_eq!(None, iter.next());
    ///
    /// // Повеќе повици може да се вратат или не `None`.Еве, тие секогаш ќе го сторат тоа.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Ги враќа границите на преостанатата должина на повторувачот.
    ///
    /// Поточно, `size_hint()` враќа тројка каде што првиот елемент е долната, а вториот елемент е горната.
    ///
    /// Втората половина од враќаниот дел што се враќа е ["Опција"] "<" ["употреба"] ">".
    /// [`None`] тука значи дека или не постои позната горна граница, или горната граница е поголема од [`usize`].
    ///
    /// # Белешки за имплементација
    ///
    /// Не се применува дека имплементацијата на повторувачот го дава декларираниот број на елементи.Итераторот на кабриолет може да даде помалку од долната или повеќе од горната граница на елементите.
    ///
    /// `size_hint()` првенствено е наменет да се користи за оптимизација како што е резервирање простор за елементите на повторувачот, но не смее да се верува дека пр. пропуштање граници во небезбеден код.
    /// Неправилното спроведување на `size_hint()` не треба да доведе до нарушувања на безбедноста на меморијата.
    ///
    /// Со тоа, имплементацијата треба да обезбеди точна проценка, бидејќи во спротивно тоа би било кршење на протоколот на trait.
    ///
    /// Стандардната имплементација се враќа ``(0,`` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ````
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Покомплексен пример:
    ///
    /// ```
    /// // Парните броеви од нула до десет.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Можеби ќе повториме од нула до десет пати.
    /// // Знаејќи дека тоа е точно пет, не би било можно без да се изврши filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Да додадеме уште пет броеви со chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // сега и двете граници се зголемени за пет
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Враќање на `None` за горната граница:
    ///
    /// ```
    /// // бесконечен повторувач нема горна и максимална можна долна граница
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Го троши повторувачот, сметајќи го бројот на повторувања и враќајќи го.
    ///
    /// Овој метод ќе повикува [`next`] постојано додека не се сретне [`None`], враќајќи го бројот на пати што го видел [`Some`].
    /// Забележете дека [`next`] треба да се повика барем еднаш дури и ако повторувачот нема никакви елементи.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Однесување на прелевање
    ///
    /// Методот не заштитува од прелевање, така што броењето елементи на повторувач со повеќе од [`usize::MAX`] елементи или создава погрешен резултат или panics.
    ///
    /// Ако се овозможени тврдења за дебагирање, гарантирано е panic.
    ///
    /// # Panics
    ///
    /// Оваа функција може да биде panic ако повторувачот има повеќе од [`usize::MAX`] елементи.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Го троши повторувачот, враќајќи го последниот елемент.
    ///
    /// Овој метод ќе го оценува повторувачот сè додека не го врати [`None`].
    /// Додека го прави тоа, тој води евиденција за тековниот елемент.
    /// По враќањето на [`None`], `last()` потоа ќе го врати последниот елемент што го видел.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Го унапредува повторувачот според елементите `n`.
    ///
    /// Овој метод со нетрпение ќе ги прескокне `n` елементите со повикување на [`next`] до `n` пати додека не се сретне [`None`].
    ///
    /// `advance_by(n)` ќе врати [`Ok(())`][Ok] ако повторувачот успешно напредува за `n` елементи, или [`Err(k)`][Err] ако се сретне [`None`], каде `k` е бројот на елементи со коишто напредувачот пред да истече елементи (т.е.
    /// должината на повторувачот).
    /// Забележете дека `k` е секогаш помал од `n`.
    ///
    /// Повикувањето на `advance_by(0)` не троши никакви елементи и секогаш враќа [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // само `&4` беше прескокнат
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Го враќа `n`-тиот елемент на повторувачот.
    ///
    /// Како и повеќето операции со индексирање, броењето започнува од нула, така што `nth(0)` ја враќа првата вредност, `nth(1)` втората, итн.
    ///
    /// Забележете дека сите претходни елементи, како и вратениот елемент, ќе бидат потрошени од повторувачот.
    /// Тоа значи дека претходните елементи ќе бидат отфрлени, а исто така и дека повикувањето `nth(0)` повеќе пати на ист повторувач ќе врати различни елементи.
    ///
    ///
    /// `nth()` ќе врати [`None`] ако `n` е поголема или еднаква на должината на повторувачот.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Повикувањето на `nth()` повеќе пати не го враќа назад повторувачот:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Враќање на `None` ако има помалку од `n + 1` елементи:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Создава повторувач почнувајќи од истата точка, но зачекорувајќи според дадената количина на секоја повторување.
    ///
    /// Белешка 1: Првиот елемент на повторувачот секогаш ќе се врати, без оглед на дадениот чекор.
    ///
    /// Белешка 2: Времето во кое се влечат игнорираните елементи не е фиксирано.
    /// `StepBy` се однесува како секвенцата `next(), nth(step-1), nth(step-1),…`, но исто така е слободно да се однесува како низата
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Кој начин се користи може да се смени за некои повторувачи од причини за изведба.
    /// Вториот начин ќе го унапреди повторувачот порано и може да троши повеќе предмети.
    ///
    /// `advance_n_and_return_first` е еквивалентно на:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Методот ќе биде panic ако дадениот чекор е `0`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Зема два повторувачи и креира нов повторувач во низа.
    ///
    /// `chain()` ќе врати нов повторувач кој прво ќе повторува над вредностите од првиот повторувач, а потоа над вредностите од вториот повторувач.
    ///
    /// Со други зборови, тој поврзува два повторувачи заедно, во еден синџир.🔗
    ///
    /// [`once`] најчесто се користи за прилагодување на единствена вредност во синџир на други видови повторувања.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи аргументот на `chain()` користи [`IntoIterator`], можеме да пренесеме сè што може да се претвори во [`Iterator`], не само самиот [`Iterator`].
    /// На пример, парчињата (`&[T]`) имплементираат [`IntoIterator`], и така можат директно да се пренесат на `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако работите со Windows API, можеби ќе сакате да го претворите [`OsStr`] во `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Скока' два повторувачи во еден повторувач на парови.
    ///
    /// `zip()` враќа нов повторувач што ќе повторува над двајца други повторувачи, враќајќи збир каде првиот елемент доаѓа од првиот повторувач, а вториот елемент доаѓа од вториот повторувач.
    ///
    ///
    /// Со други зборови, тој посочува два повторувачи заедно, во еден.
    ///
    /// Ако било кој повторувач го врати [`None`], [`next`] од патентот повторувач ќе го врати [`None`].
    /// Ако првиот повторувач врати [`None`], `zip` ќе се сврти во краток спој и `next` нема да биде повикан на вториот повторувач.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи аргументот на `zip()` користи [`IntoIterator`], можеме да пренесеме сè што може да се претвори во [`Iterator`], не само самиот [`Iterator`].
    /// На пример, парчињата (`&[T]`) имплементираат [`IntoIterator`], и така можат директно да се пренесат на `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` често се користи за патент на бесконечен повторувач до конечен.
    /// Ова работи затоа што конечниот повторувач на крајот ќе го врати [`None`], завршувајќи го патентот.Затворањето со `(0..)` може многу да личи на [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Создава нов повторувач кој поставува копија од `separator` помеѓу соседните ставки на оригиналниот повторувач.
    ///
    /// Во случај `separator` да не спроведува [`Clone`] или треба да се пресметува секој пат, користете [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Првиот елемент од `a`.
    /// assert_eq!(a.next(), Some(&100)); // Сепараторот.
    /// assert_eq!(a.next(), Some(&1));   // Следниот елемент од `a`.
    /// assert_eq!(a.next(), Some(&100)); // Сепараторот.
    /// assert_eq!(a.next(), Some(&2));   // Последниот елемент од `a`.
    /// assert_eq!(a.next(), None);       // Итераторот е завршен.
    /// ```
    ///
    /// `intersperse` може да биде многу корисно да се придружите на предметите на повторувачот користејќи заеднички елемент:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Создава нов повторувач кој става ставка генерирана од `separator` помеѓу соседните ставки на оригиналниот повторувач.
    ///
    /// Затворањето ќе се повика точно еднаш кога ќе се постави ставка помеѓу две соседни ставки од основниот повторувач;
    /// конкретно, затворањето не се повикува ако основниот повторувач дава помалку од две ставки и откако ќе се даде последната ставка.
    ///
    ///
    /// Ако ставката на повторувачот спроведува [`Clone`], можеби е полесно да се користи [`intersperse`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Првиот елемент од `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Сепараторот.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Следниот елемент од `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Сепараторот.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Последниот елемент од од `v`.
    /// assert_eq!(it.next(), None);               // Итераторот е завршен.
    /// ```
    ///
    /// `intersperse_with` може да се користи во ситуации кога треба да се пресмета сепараторот:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Затворањето неспорно го позајмува својот контекст за да генерира ставка.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Затвора и создава повторувач што го повикува затворањето на секој елемент.
    ///
    /// `map()` трансформира еден повторувач во друг, со својот аргумент:
    /// нешто што го спроведува [`FnMut`].Произведува нов повторувач кој го нарекува ова затворање на секој елемент од оригиналниот повторувач.
    ///
    /// Ако вешти размислувате во типови, можете да помислите на `map()` вака:
    /// Ако имате повторувач што ви дава елементи од некој тип `A`, и сакате повторувач од некој друг тип `B`, можете да користите `map()`, поминувајќи затворач што зема `A` и враќа `B`.
    ///
    ///
    /// `map()` е концептуално слична на јамка [`for`].Сепак, бидејќи `map()` е мрзлив, тој најдобро се користи кога веќе работите со други повторувачи.
    /// Ако правите некој вид на јамка за несакан ефект, се смета дека е поидиотмично да се користи [`for`] отколку `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако правите некаков несакан ефект, претпочитајте [`for`] отколку `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // не го прави ова:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // нема ни да се изврши, бидејќи е мрзливо.Rust ќе ве предупреди за ова.
    ///
    /// // Наместо тоа, користете за:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Повикува затворање на секој елемент од повторувач.
    ///
    /// Ова е еквивалентно на користење на јамка [`for`] на повторувачот, иако `break` и `continue` не се можни од затворање.
    /// Општо е поидиотматично да се користи јамка `for`, но `for_each` може да биде подобар читлив кога обработувате предмети на крајот од подолгите ланци на повторувачи.
    ///
    /// Во некои случаи, `for_each` исто така може да биде побрз од јамка, бидејќи ќе користи внатрешна повторување на адаптери како `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// За толку мал пример, јамка `for` може да биде почиста, но `for_each` може да се претпочита да се задржи функционален стил со подолги повторувачи:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Создава повторувач кој користи затворач за да утврди дали треба да се даде елемент.
    ///
    /// Со оглед на елемент, затворањето мора да врати `true` или `false`.Враќаниот повторувач ќе ги даде само елементите за кои затворањето се враќа точно.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи затворањето пренесено на `filter()` зема референца, и многу повторувачи повторуваат преку референците, ова доведува до евентуално збунувачка ситуација, кога типот на затворањето е двојна референца:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // потребни се два *!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Вообичаено е да се користи деструктуирање на аргументот за да се отстрани еден:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // и&и *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// или двете:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // два &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// од овие слоеви.
    ///
    /// Забележете дека `iter.filter(f).next()` е еквивалентно на `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Создава повторувач што филтрира и мапира.
    ///
    /// Враќаниот повторувач ја дава само `вредноста` за која испорачаниот затворач ја враќа `Some(value)`.
    ///
    /// `filter_map` може да се искористи за да се направат ланци на [`filter`] и [`map`] поконцизни.
    /// Примерот подолу покажува како `map().filter().map()` може да се скрати на еден повик на `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Еве го истиот пример, но со [`filter`] и [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Создава повторувач кој го дава тековниот број на повторувања, како и следната вредност.
    ///
    /// Враќаниот повторувач дава парови `(i, val)`, каде `i` е тековниот индекс на повторување и `val` е вредноста вратена од повторувачот.
    ///
    ///
    /// `enumerate()` го зачувува својот број како [`usize`].
    /// Ако сакате да сметате со цел цел број различна големина, функцијата [`zip`] обезбедува слична функционалност.
    ///
    /// # Однесување на прелевање
    ///
    /// Методот не заштитува од прелевање, така што набројувајќи повеќе од [`usize::MAX`] елементи или произведува погрешен резултат или panics.
    /// Ако се овозможени тврдења за дебагирање, гарантирано е panic.
    ///
    /// # Panics
    ///
    /// Враќаниот повторувач може да биде panic ако индексот што треба да се врати ќе прелее [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Создава повторувач што може да го користи [`peek`] за да го погледне следниот елемент на повторувачот без да го потроши.
    ///
    /// Додава метод [`peek`] на повторувач.Погледнете ја нејзината документација за повеќе информации.
    ///
    /// Забележете дека основниот повторувач е сè уште напреден кога [`peek`] е повикан за прв пат: Со цел да се добие следниот елемент, [`next`] се повикува на основниот повторувач, па оттука и несакани ефекти (т.е.
    ///
    /// нешто друго освен преземање на следната вредност) на методот [`next`] ќе се појави.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() нека видиме во future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // можеме да peek() повеќе пати, повторувачот нема да напредува
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // откако ќе заврши итераторот, така е и peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Создава повторувач што ќе ги " прескокне` елементите врз основа на предикатот.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` го зема затворањето како аргумент.Willе го повика ова затворање на секој елемент од повторувачот и ќе ги игнорира елементите додека не го врати `false`.
    ///
    /// По враќањето на `false`, работата на `skip_while()`'s е завршена и остатокот на елементите се дава.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи затворањето пренесено на `skip_while()` зема референца, и многу повторувачи повторуваат преку референците, ова доведува до можна збунувачка ситуација, каде типот на аргументот за затворање е двојна референца:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // потребни се два *!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Запирање по почетниот `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // иако ова ќе беше лажно, бидејќи веќе добивме лажна, skip_while() не се користи повеќе
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Создава повторувач што дава елементи засновани врз предикатив.
    ///
    /// `take_while()` го зема затворањето како аргумент.Callе го повика ова затворање на секој елемент од повторувачот и ќе даде елементи додека враќа `true`.
    ///
    /// По враќањето на `false`, работата на `take_while()`'s е завршена, а останатите елементи се игнорираат.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи затворањето пренесено на `take_while()` зема референца, и многу повторувачи повторуваат преку референците, ова доведува до евентуално збунувачка ситуација, кога типот на затворањето е двојна референца:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // потребни се два *!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Запирање по почетниот `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Имаме повеќе елементи што се помалку од нула, но бидејќи веќе добивме лажна, take_while() не се користи повеќе
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бидејќи `take_while()` треба да ја разгледа вредноста за да види дали треба да се вклучи или не, со повторување на потрошувачите ќе се види дека е отстранета:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` повеќе не е таму, бидејќи се потроши за да се види дали повторувањето треба да престане, но не беше повторно ставено во повторувачот.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Создава повторувач кој дава елементи базирани на предикат и мапи.
    ///
    /// `map_while()` го зема затворањето како аргумент.
    /// Callе го повика ова затворање на секој елемент од повторувачот и ќе даде елементи додека враќа [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Еве го истиот пример, но со [`take_while`] и [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Запирање по почетниот [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Имаме повеќе елементи што можат да се вклопат во u32 (4, 5), но `map_while` врати `None` за `-3` (како што `predicate` врати `None`) и `collect` застанува на првиот среден `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Бидејќи `map_while()` треба да ја разгледа вредноста за да види дали треба да се вклучи или не, со повторување на потрошувачите ќе се види дека е отстранета:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` повеќе не е таму, бидејќи се потроши за да се види дали повторувањето треба да престане, но не беше повторно ставено во повторувачот.
    ///
    /// Забележете дека за разлика од [`take_while`], овој повторувач **не е споен**.
    /// Исто така, не е прецизирано што враќа овој повторувач по враќањето на првиот [`None`].
    /// Ако ви треба споен повторувач, користете [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Создава повторувач што ги прескокнува првите елементи на `n`.
    ///
    /// Откако ќе бидат потрошени, остатокот на елементите се дава.
    /// Наместо да го надминете овој метод директно, наместо тоа, надминете го методот `nth`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Создава повторувач што ги дава своите први елементи `n`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` често се користи со бесконечен повторувач, за да се направи конечен:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако се достапни помалку од `n` елементи, `take` ќе се ограничи на големината на основниот повторувач:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Адаптер за повторувач сличен на [`fold`] кој има внатрешна состојба и произведува нов повторувач.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` зазема два аргументи: почетна вредност што ја зафаќа внатрешната состојба и затворање со два аргументи, првиот е неспојлива референца за внатрешната состојба и вториот е повторувачки елемент.
    ///
    /// Затворањето може да и додели на внатрешната состојба да ја дели состојбата помеѓу повторувањата.
    ///
    /// При повторување, затворањето ќе се примени на секој елемент на повторувачот и повратната вредност од затворањето, [`Option`], ја дава повторувачот.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // секоја повторување, ќе ја помножиме државата со елементот
    ///     *state = *state * x;
    ///
    ///     // тогаш, ќе дадеме негација на државата
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Создава повторувач кој работи како мапа, но ја израмнува вгнездената структура.
    ///
    /// Адаптерот [`map`] е многу корисен, но само кога аргументот за затворање произведува вредности.
    /// Ако наместо тоа произведува повторувач, има дополнителен слој на индирекција.
    /// `flat_map()` ќе го отстрани овој дополнителен слој самостојно.
    ///
    /// Можете да помислите на `flat_map(f)` како семантички еквивалент на ["мапа"] пинг, а потоа ["изедначи"] како во `map(f).flatten()`.
    ///
    /// Друг начин на размислување за `flat_map()`: затворањето на [map]] враќа по една ставка за секој елемент, а затворањето `flat_map()`'s враќа повторувач за секој елемент.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() враќа повторувач
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Создава повторувач кој ја израмнува вгнездената структура.
    ///
    /// Ова е корисно кога имате повторувач на повторувачи или повторувач на работи што можат да се претворат во повторувачи и сакате да отстраните едно ниво на индирекција.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Мапирање и потоа израмнување:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() враќа повторувач
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ова исто така можете да го напишете во смисла на [`flat_map()`], што е подобро во овој случај, бидејќи прецизно ја пренесува намерата:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() враќа повторувач
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Израмнувањето отстранува само едно ниво на гнездење истовремено:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Овде гледаме дека `flatten()` не извршува израмнување "deep".
    /// Наместо тоа, само едно ниво на гнездење е отстрането.Тоа е, ако `flatten()` сте тродимензионална низа, резултатот ќе биде дводимензионален, а не еднодимензионален.
    /// За да добиете еднодимензионална структура, треба повторно да `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Создава повторувач кој завршува по првиот [`None`].
    ///
    /// Откако итераторот ќе го врати [`None`], повиците future може или не може да дадат [`Some(T)`] повторно.
    /// `fuse()` прилагодува повторувач, осигурувајќи дека откако ќе се даде [`None`], тој секогаш ќе го враќа [`None`] засекогаш.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // повторувач што се менува помеѓу Некој и Ништо
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ако е рамномерно, Some(i32), друго Нема
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // можеме да видиме како нашиот повторувач оди напред и назад
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // сепак, откако ќе го осигураме ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // секогаш ќе го врати `None` по првиот пат.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Дали нешто со секој елемент на повторувач, пренесувајќи ја вредноста.
    ///
    /// Кога користите повторувачи, честопати ќе синџирате неколку од нив заедно.
    /// Додека работите на таков код, можеби ќе сакате да проверите што се случува на различни делови во цевководот.За да го направите тоа, вметнете повик до `inspect()`.
    ///
    /// Почесто е `inspect()` да се користи како алатка за дебагирање отколку да постои во вашиот краен код, но апликациите може да сметаат дека е корисно во одредени ситуации кога треба да се најават грешки пред да бидат отфрлени.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // оваа секвенца на повторувачот е комплексна.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ајде да додадеме неколку повици inspect() за да испитаме што се случува
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ова ќе отпечати:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Грешки во најавување пред да ги отфрлите:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ова ќе отпечати:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Затегнува повторувач, наместо да го троши.
    ///
    /// Ова е корисно за да се дозволи примена на адаптери за повторувач додека се уште се задржува сопственоста на оригиналниот повторувач.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ако се обидеме повторно да го користиме iter, тоа нема да работи.
    /// // Следната линија дава "грешка: употреба на преместена вредност: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ајде да го пробаме повторно
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // наместо тоа, додаваме .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // сега ова е во ред:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Трансформира итератор во колекција.
    ///
    /// `collect()` може да земе сè што може да се повтори, и да го претвори во релевантна колекција.
    /// Ова е една од помоќните методи во стандардната библиотека, користена во различни контексти.
    ///
    /// Најосновната шема во која се користи `collect()` е да се претвори една колекција во друга.
    /// Земате колекција, јавете се на [`iter`] на неа, направете еден куп трансформации, а потоа `collect()` на крајот.
    ///
    /// `collect()` исто така може да создаде примери од типови што не се типични збирки.
    /// На пример, [`String`] може да се изгради од [`char`] и, повторувач на [`Result<T, E>`][`Result`] ставки може да се собере во `Result<Collection<T>, E>`.
    ///
    /// Погледнете ги примерите подолу за повеќе.
    ///
    /// Бидејќи `collect()` е толку општ, може да предизвика проблеми со заклучокот за типот.
    /// Како такво, `collect()` е еден од ретките пати кога ќе ја видите синтаксата пријатно позната како 'turbofish': `::<>`.
    /// Ова му помага на алгоритмот за заклучок да разбере конкретно во која колекција се обидувате да соберете.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Забележете дека ни требаше `: Vec<i32>` од левата страна.Ова е затоа што би можеле да собереме, на пример, [`VecDeque<T>`] наместо:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Користете 'turbofish' наместо да коментирате `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Бидејќи `collect()` се грижи само за она што го собирате, сепак можете да користите делумно навестување за типот, `_`, со турбофилот:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Користејќи `collect()` за да направите [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ако имате список со [`Резултат<T, E>`][" Резултат `], можете да користите `collect()` за да видите дали некој од нив не успеал:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ни ја дава првата грешка
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ни ја дава листата на одговори
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Потрошува итератор, создавајќи две колекции од него.
    ///
    /// Предикатот предаден на `partition()` може да врати `true`, или `false`.
    /// `partition()` враќа пар, сите елементи за кои вратил `true` и сите елементи за кои вратил `false`.
    ///
    ///
    /// Видете исто така [`is_partitioned()`] и [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Подредување на елементите на овој повторувач *на место* според дадениот предикат, така што сите што враќаат `true` претходи на сите оние што враќаат `false`.
    ///
    /// Го враќа бројот на пронајдени `true` елементи.
    ///
    /// Релативниот редослед на партиционираните ставки не се одржува.
    ///
    /// Видете исто така [`is_partitioned()`] и [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Поделба на место помеѓу парови и коефициенти
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: треба да се грижиме дали пребројувањето се прелева?Единствениот начин да се има повеќе од
        // `usize::MAX` непроменливата референца е со ZST, кои не се корисни за поделба ...

        // Овие функции за затворање "factory" постојат за да се избегне генеричноста во `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Повторно пронајдете го првиот `false` и заменете го со последниот `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Проверува дали елементите на овој повторувач се поделени според дадениот предикат, така што сите што враќаат `true` им претходи на сите што враќаат `false`.
    ///
    ///
    /// Видете исто така [`partition()`] и [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Или сите ставки тестираат `true`, или првата клаузула запира на `false` и проверуваме дека нема повеќе `true` ставки после тоа.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Метод на повторувач кој ја применува функцијата се додека таа успешно се враќа, произведувајќи единствена, крајна вредност.
    ///
    /// `try_fold()` зема два аргументи: почетна вредност и затворање со два аргументи: 'accumulator' и елемент.
    /// Затворањето или успешно се враќа, со вредноста што треба да ја има акумулаторот за следното повторување, или враќа дефект, со вредност на грешка што се шири назад до повикувачот (short-circuiting).
    ///
    ///
    /// Почетната вредност е вредноста што акумулаторот ќе ја има на првиот повик.Ако примената на затворањето успее против секој елемент на повторувачот, `try_fold()` го враќа последниот акумулатор како успех.
    ///
    /// Преклопувањето е корисно секогаш кога имате колекција од нешто, и сакате да произведете единствена вредност од тоа.
    ///
    /// # Белешка до имплементаторите
    ///
    /// Неколку други методи (forward) имаат стандардна имплементација во смисла на оваа, затоа обидете се да го имплементирате експлицитно ако може да стори нешто подобро од стандардната имплементација на јамката `for`.
    ///
    /// Особено, обидете се да го имате овој повик `try_fold()` на внатрешните делови од кои е составен овој повторувач.
    /// Доколку се потребни повеќе повици, операторот `?` може да биде погоден за синџирирање на вредноста на акумулаторот, но внимавајте на сите инваријанти што треба да бидат поддржани пред тие рани враќања.
    /// Ова е метод `&mut self`, така што повторувањето треба да се продолжи откако ќе погрешите грешка тука.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // проверената сума на сите елементи на низата
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Оваа сума се прелева при додавање на елементот 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Бидејќи е во краток спој, останатите елементи се сè уште достапни преку повторувачот.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод на повторувач кој применува грешна функција на секоја ставка во повторувачот, запирајќи на првата грешка и враќајќи ја таа грешка.
    ///
    ///
    /// Ова исто така може да се сфати како пропадна форма на [`for_each()`] или како верзија на [`try_fold()`] без државјанство.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Кратко се спои, така што останатите ставки сè уште се во повторувачот:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Преклопува секој елемент во акумулатор со примена на операција, враќајќи го крајниот резултат.
    ///
    /// `fold()` зема два аргументи: почетна вредност и затворање со два аргументи: 'accumulator' и елемент.
    /// Затворањето ја враќа вредноста што треба да ја има акумулаторот за следното повторување.
    ///
    /// Почетната вредност е вредноста што акумулаторот ќе ја има на првиот повик.
    ///
    /// Откако ќе го примените ова затворање на секој елемент на повторувачот, `fold()` го враќа акумулаторот.
    ///
    /// Оваа операција понекогаш се нарекува 'reduce' или 'inject'.
    ///
    /// Преклопувањето е корисно секогаш кога имате колекција од нешто, и сакате да произведете единствена вредност од тоа.
    ///
    /// Note: `fold()` и слични методи што го поминуваат целиот повторувач, може да не завршат за бесконечни повторувачи, дури и на traits за кои резултатот може да се одреди во конечно време.
    ///
    /// Note: [`reduce()`] може да се користи за употреба на првиот елемент како почетна вредност, ако типот на акумулаторот и типот на ставка се исти.
    ///
    /// # Белешка до имплементаторите
    ///
    /// Неколку други методи (forward) имаат стандардна имплементација во смисла на оваа, затоа обидете се да го имплементирате експлицитно ако може да стори нешто подобро од стандардната имплементација на јамката `for`.
    ///
    ///
    /// Особено, обидете се да го имате овој повик `fold()` на внатрешните делови од кои е составен овој повторувач.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // збир на сите елементи на низата
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ајде да прошетаме низ секој чекор од повторувањето тука:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// И така, нашиот конечен резултат, `6`.
    ///
    /// Вообичаено е луѓето кои не користеле многу повторувачи да користат јамка `for` со список на работи за да создадат резултат.Оние може да се претворат во `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // за јамка:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // тие се исти
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ги намалува елементите на еден, со повеќекратна примена на операција за намалување.
    ///
    /// Ако повторувачот е празен, враќа [`None`];во спротивно, го враќа резултатот од намалувањето.
    ///
    /// За повторувачи со најмалку еден елемент, ова е исто како [`fold()`] со првиот елемент на повторувачот како почетна вредност, преклопувајќи го секој следен елемент во него.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Пронајдете ја максималната вредност:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Испитува дали секој елемент на повторувачот одговара на предикатот.
    ///
    /// `all()` зафаќа затворање што враќа `true` или `false`.Го применува ова затворање на секој елемент од повторувачот, и ако сите вратат `true`, тогаш тоа го прави и `all()`.
    /// Ако некој од нив врати `false`, тој враќа `false`.
    ///
    /// `all()` е краток спој;со други зборови, тој ќе престане да обработува веднаш штом најде `false`, со оглед на тоа што и да се случи друго, резултатот ќе биде и `false`.
    ///
    ///
    /// Празен повторувач враќа `true`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Запирање на првиот `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Испитува дали некој елемент од повторувачот одговара на предикатот.
    ///
    /// `any()` зафаќа затворање што враќа `true` или `false`.Го применува ова затворање на секој елемент на повторувачот, и ако некој од нив врати `true`, тогаш тоа го прави и `any()`.
    /// Ако сите вратат `false`, тоа враќа `false`.
    ///
    /// `any()` е краток спој;со други зборови, тој ќе престане да обработува веднаш штом најде `true`, со оглед на тоа што и да се случи друго, резултатот ќе биде и `true`.
    ///
    ///
    /// Празен повторувач враќа `false`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Запирање на првиот `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Пребарува елемент на повторувач што задоволува предикат.
    ///
    /// `find()` зафаќа затворање што враќа `true` или `false`.
    /// Го применува ова затворање на секој елемент од повторувачот, и ако некој од нив врати `true`, тогаш `find()` враќа [`Some(element)`].
    /// Ако сите вратат `false`, тоа враќа [`None`].
    ///
    /// `find()` е краток спој;со други зборови, тој ќе престане да се обработува веднаш штом затворањето се врати `true`.
    ///
    /// Бидејќи `find()` зема референца, и многу повторувачи повторуваат над референците, ова доведува до евентуално збунувачка ситуација кога аргументот е двојна референца.
    ///
    /// Овој ефект можете да го видите во примерите подолу, со `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Запирање на првиот `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Забележете дека `iter.find(f)` е еквивалентно на `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Ја применува функцијата на елементите на повторувачот и го враќа првиот резултат кој нема.
    ///
    ///
    /// `iter.find_map(f)` е еквивалентно на `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Ја применува функцијата на елементите на повторувачот и го враќа првиот вистински резултат или првата грешка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Пребарува елемент во повторувач, враќајќи го неговиот индекс.
    ///
    /// `position()` зафаќа затворање што враќа `true` или `false`.
    /// Го применува ова затворање на секој елемент од повторувачот, и ако некој од нив врати `true`, тогаш `position()` враќа [`Some(index)`].
    /// Ако сите вратат `false`, тоа враќа [`None`].
    ///
    /// `position()` е краток спој;со други зборови, тој ќе престане да се обработува веднаш штом најде `true`.
    ///
    /// # Однесување на прелевање
    ///
    /// Методот не заштитува од прелевање, така што ако има повеќе од [`usize::MAX`] елементи што не се совпаѓаат, или произведува погрешен резултат или panics.
    ///
    /// Ако се овозможени тврдења за дебагирање, гарантирано е panic.
    ///
    /// # Panics
    ///
    /// Оваа функција може да биде panic ако повторувачот има повеќе од `usize::MAX` елементи што не се совпаѓаат.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Запирање на првиот `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Вратениот индекс зависи од состојбата на повторувачот
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Пребарува елемент во повторувач од десно, враќајќи го неговиот индекс.
    ///
    /// `rposition()` зафаќа затворање што враќа `true` или `false`.
    /// Го применува ова затворање на секој елемент на повторувачот, почнувајќи од крајот, и ако некој од нив врати `true`, тогаш `rposition()` враќа [`Some(index)`].
    ///
    /// Ако сите вратат `false`, тоа враќа [`None`].
    ///
    /// `rposition()` е краток спој;со други зборови, тој ќе престане да се обработува веднаш штом најде `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Запирање на првиот `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // сè уште можеме да користиме `iter`, бидејќи има повеќе елементи.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Нема потреба од проверка на прелевање тука, бидејќи `ExactSizeIterator` имплицира дека бројот на елементи се вклопува во `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Го враќа максималниот елемент на повторувачот.
    ///
    /// Ако неколку елементи се подеднакво максимални, се враќа последниот елемент.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Го враќа минималниот елемент на повторувачот.
    ///
    /// Ако неколку елементи се еднакво минимум, првиот елемент се враќа.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Го враќа елементот што ја дава максималната вредност од наведената функција.
    ///
    ///
    /// Ако неколку елементи се подеднакво максимални, се враќа последниот елемент.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Го враќа елементот што ја дава максималната вредност во однос на наведената функција за споредба.
    ///
    ///
    /// Ако неколку елементи се подеднакво максимални, се враќа последниот елемент.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Го враќа елементот што ја дава минималната вредност од наведената функција.
    ///
    ///
    /// Ако неколку елементи се еднакво минимум, првиот елемент се враќа.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Го враќа елементот што ја дава минималната вредност во однос на наведената функција за споредба.
    ///
    ///
    /// Ако неколку елементи се еднакво минимум, првиот елемент се враќа.
    /// Ако повторувачот е празен, [`None`] се враќа.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ја менува насоката на повторувачот.
    ///
    /// Обично, повторувачите се повторуваат одлево надесно.
    /// По користењето на `rev()`, повторувачот наместо тоа ќе повтори од десно кон лево.
    ///
    /// Ова е можно само ако повторувачот има крај, така што `rev()` работи само на [" DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Конвертира повторувач на парови во пар контејнери.
    ///
    /// `unzip()` троши цел повторувач на парови, произведувајќи две колекции: една од левите елементи на паровите и друга од десните елементи.
    ///
    ///
    /// Оваа функција е, во извесна смисла, спротивна на [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Создава повторувач кој ги копира сите негови елементи.
    ///
    /// Ова е корисно кога имате повторувач над `&T`, но ви треба повторувач над `T`.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // копиран е ист како .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Создава итератор кој ['клонира]] ги сите негови елементи.
    ///
    /// Ова е корисно кога имате повторувач над `&T`, но ви треба повторувач над `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // клониран е ист како .map(|&x| x), за цели броеви
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Повторува повторувач бесконечно.
    ///
    /// Наместо да застане на [`None`], повторувачот наместо да започне повторно, од самиот почеток.По повторувањето, повторно ќе започне на почетокот.И повторно.
    /// И повторно.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Ги сумира елементите на повторувачот.
    ///
    /// Го зема секој елемент, ги додава заедно и го враќа резултатот.
    ///
    /// Празен повторувач ја враќа нултата вредност од типот.
    ///
    /// # Panics
    ///
    /// Кога се повикувате на `sum()` и се враќа примитивен цел број, овој метод ќе биде panic ако пресметката се прелева и тврдењата за дебагирање се овозможени.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Го повторува целиот повторувач, множејќи ги сите елементи
    ///
    /// Празен повторувач ја враќа една вредност од типот.
    ///
    /// # Panics
    ///
    /// Кога се повикува `product()` и се враќа примитивен цел број, методот ќе биде panic ако пресметката се прелева и тврдењата за дебагирање се овозможени.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ги споредува елементите на овој [`Iterator`] со оние на другиот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ги споредува елементите на овој [`Iterator`] со оние на друг во однос на наведената функција за споредба.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ги споредува елементите на овој [`Iterator`] со оние на другиот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ги споредува елементите на овој [`Iterator`] со оние на друг во однос на наведената функција за споредба.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Определува дали елементите на овој [`Iterator`] се еднакви на другите.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Одредува дали елементите на овој [`Iterator`] се еднакви на оние на другиот во однос на наведената функција за еднаквост.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Одредува дали елементите на овој [`Iterator`] се нееднакви со оние на другиот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Одредува дали елементите на овој [`Iterator`] се [lexicographically](Ord#lexicographical-comparison) помалку од оние на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Одредува дали елементите на овој [`Iterator`] се [lexicographically](Ord#lexicographical-comparison) помалку или еднакви на оние на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Одредува дали елементите на овој [`Iterator`] се [lexicographically](Ord#lexicographical-comparison) поголеми од оние на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Одредува дали елементите на овој [`Iterator`] се [lexicographically](Ord#lexicographical-comparison) поголеми или еднакви на оние на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Проверува дали елементите на овој повторувач се подредени.
    ///
    /// Тоа е, за секој елемент `a` и неговиот следен елемент `b`, `a <= b` мора да има.Ако повторувачот даде точно нула или еден елемент, `true` се враќа.
    ///
    /// Забележете дека ако `Self::Item` е само `PartialOrd`, но не и `Ord`, горенаведената дефиниција имплицира дека оваа функција враќа `false` ако две последователни ставки не се споредливи.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Проверува дали елементите на овој повторувач се подредени користејќи ја дадената функција за споредување.
    ///
    /// Наместо да користи `PartialOrd::partial_cmp`, оваа функција ја користи дадената функција `compare` за да одреди подредување на два елементи.
    /// Освен тоа, тоа е еквивалентно на [`is_sorted`];видете ја нејзината документација за повеќе информации.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Проверува дали елементите на овој повторувач се подредени со помош на дадената функција за извлекување клучеви.
    ///
    /// Наместо да се споредуваат елементите на повторувачот директно, оваа функција ги споредува клучевите на елементите, како што е утврдено со `f`.
    /// Освен тоа, тоа е еквивалентно на [`is_sorted`];видете ја нејзината документација за повеќе информации.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Погледнете [TrustedRandomAccess]
    // Невообичаено име е да се избегнат судири со имиња во резолуцијата на методот, видете #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}