/// Итератор кој ја знае својата точна должина.
///
/// Многумина [" Итератор`] не знаат колку пати ќе повторат, но некои знаат.
/// Ако повторувачот знае колку пати може да повтори, обезбедувањето пристап до тие информации може да биде корисно.
/// На пример, ако сакате да повторите назад, добар почеток е да знаете каде е крајот.
///
/// При спроведување на `ExactSizeIterator`, мора да го имплементирате и [`Iterator`].
/// При тоа, имплементацијата на [`Iterator::size_hint`]*мора* да ја врати точната големина на повторувачот.
///
/// Методот [`len`] има стандардна имплементација, затоа обично не треба да ја спроведувате.
/// Како и да е, можеби ќе можете да обезбедите поефикасна имплементација од стандардната, така што ќе го надминете во овој случај има смисла.
///
///
/// Забележете дека овој trait е безбеден trait и како таков *не* и *не* може да гарантира дека вратената должина е точна.
/// Ова значи дека кодот `unsafe` ** не смее да се потпира на исправноста на [`Iterator::size_hint`].
/// Нестабилниот и небезбеден [`TrustedLen`](super::marker::TrustedLen) trait ја дава оваа дополнителна гаранција.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // конечен опсег точно знае колку пати ќе се повторува
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Во [module-level docs], ние имплементиравме [`Iterator`], `Counter`.
/// Да го спроведеме `ExactSizeIterator` и за тоа:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Лесно можеме да го пресметаме преостанатиот број повторувања.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // И сега можеме да го користиме!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Ја враќа точната должина на повторувачот.
    ///
    /// Имплементацијата гарантира дека повторувачот ќе врати точно `len()` повеќе пати од вредноста [`Some(T)`], пред да го врати [`None`].
    ///
    /// Овој метод има стандардна имплементација, затоа обично не треба да го спроведувате директно.
    /// Меѓутоа, ако можете да обезбедите поефикасна имплементација, можете да го сторите тоа.
    /// Погледнете ги документите [trait-level] за пример.
    ///
    /// Оваа функција ги има истите безбедносни гаранции како и функцијата [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // конечен опсег точно знае колку пати ќе се повторува
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ова тврдење е премногу дефанзивно, но го проверува непроменливиот
        // гарантирано со trait.
        // Ако овој trait беше rust-внатрешен, би можеле да користиме debug_assert !;тврди_ек!ќе ги провери и сите имплементации на корисниците на Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Враќа `true` ако повторувачот е празен.
    ///
    /// Овој метод има стандардна имплементација со употреба на [`ExactSizeIterator::len()`], затоа не треба сами да ја имплементирате.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}