//! `Clone` trait за типови што не можат да бидат " имплицитно копирани`.
//!
//! Во Rust, некои едноставни типови се "implicitly copyable" и кога ќе ги доделите или ќе ги предадете како аргументи, приемникот ќе добие копија, оставајќи ја оригиналната вредност на место.
//! Овие типови не бараат распределување за копирање и немаат финализатори (т.е. не содржат кутии во сопственост или имплементираат [`Drop`]), така што компајлерот ги смета за ефтини и безбедни за копирање.
//!
//! За други видови, копиите мора да се направат експлицитно, со конвенција, спроведувајќи го [`Clone`] trait и повикувајќи се на методот [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Пример за основна употреба:
//!
//! ```
//! let s = String::new(); // Тип на стринг спроведува Клон
//! let copy = s.clone(); // за да можеме да го клонираме
//! ```
//!
//! За лесно спроведување на Clone trait, можете да користите и `#[derive(Clone)]`.Пример:
//!
//! ```
//! #[derive(Clone)] // го додаваме Клонот trait на структурата на Морфеј
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // и сега можеме да го клонираме!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Заеднички trait за можноста за експлицитно дуплирање на објект.
///
/// Разликите од [`Copy`] во тоа [`Copy`] се имплицитни и крајно ефтини, додека `Clone` е секогаш експлицитни и може да бидат скапи или не.
/// Со цел да се применат овие карактеристики, Rust не ви дозволува повторно да го извршувате [`Copy`], но може повторно да го извршите `Clone` и да извршите произволен код.
///
/// Бидејќи `Clone` е поопшт од [`Copy`], можете автоматски да направите што било [`Copy`] да биде `Clone` исто така.
///
/// ## Derivable
///
/// Овој trait може да се користи со `#[derive]` ако сите полиња се `Clone`.`Изведете`д имплементација на [`Clone`] повикува на [`clone`] на секое поле.
///
/// [`clone`]: Clone::clone
///
/// За генеричка структура, `#[derive]` го спроведува `Clone` условно со додавање на врзан `Clone` на генеричките параметри.
///
/// ```
/// // `derive` спроведува Клон за читање<T>кога Т е Клон.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Како можам да го имплементирам `Clone`?
///
/// Видовите кои се [`Copy`] треба да имаат тривијална имплементација на `Clone`.Поформално:
/// ако `T: Copy`, `x: T` и `y: &T`, тогаш `let x = y.clone();` е еквивалентно на `let x = *y;`.
/// Рачните имплементации треба да бидат внимателни за да се поддржи оваа непроменлива;сепак, небезбедниот код не смее да се потпира на него за да се осигури безбедноста на меморијата.
///
/// Пример е генеричка структура која држи покажувач на функција.Во овој случај, имплементацијата на `Clone` не може да се " изведе`, туку може да се спроведе како:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Дополнителни имплементатори
///
/// Покрај [implementors listed below][impls], следниве типови исто така го имплементираат `Clone`:
///
/// * Видови ставки на функции (т.е. посебни типови дефинирани за секоја функција)
/// * Видови на покажувачи на функции (на пр., `fn() -> i32`)
/// * Типови на низи, за сите големини, ако типот на ставка исто така спроведува `Clone` (на пример, `[i32; 123456]`)
/// * Двојни типови, ако секоја компонента исто така спроведува `Clone` (на пример, `()`, `(i32, bool)`)
/// * Видови на затворање, ако не зафаќаат никаква вредност од околината или ако сите такви зафатени вредности го спроведуваат `Clone` самите.
///   Имајте на ум дека променливите зафатени со споделена референца секогаш спроведуваат `Clone` (дури и ако референтот не го прави тоа), додека променливите зафатени со променливата референца никогаш не спроведуваат `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Враќа копија од вредноста.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str спроведува Клон
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Извршува задача за копирање од `source`.
    ///
    /// `a.clone_from(&b)` е еквивалентно на `a = b.clone()` по функционалност, но може да се преброди за повторна употреба на ресурсите на `a` за да се избегнат непотребни алокации.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Изведете макро генерирање на импликација на trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): овие стилови се користат единствено од#[изведи] за да се тврди дека секоја компонента од типот спроведува Клон или копија.
//
//
// Овие удари никогаш не треба да се појавуваат во корисничкиот код.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Имплементација на `Clone` за примитивни типови.
///
/// Имплементациите што не можат да се опишат во Rust се спроведуваат во `traits::SelectionContext::copy_clone_conditions()` во `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Заедничките референци можат да се клонираат, но неспособните препораки *не можат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Заедничките референци можат да се клонираат, но неспособните препораки *не можат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}