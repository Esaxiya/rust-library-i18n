#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Обезбедува тип на метаподатоци на покажувачот од кој било вид насочен.
///
/// # Метаподатоци за покажувачот
///
/// Сурови типови на покажувачи и референтни типови во Rust може да се сметаат како направени од два дела:
/// покажувач на податоци што содржи мемориска адреса на вредноста и некои метаподатоци.
///
/// За типовите со статична големина (кои ги имплементираат `Sized` traits), како и за типовите `extern`, за индикаторите се вели дека се " тенки`: метаподатоците се со нула големина и нивниот вид е `()`.
///
///
/// Покажувачите за [dynamically-sized types][dst] се вели дека се " широки`или " дебели`, тие имаат метаподатоци со не-нула големина:
///
/// * За ударите чие последно поле е DST, метаподатоците се метаподатоците за последното поле
/// * За типот `str`, метаподатоците се должина во бајти како `usize`
/// * За типови парчиња како `[T]`, метаподатоците се должина во ставките како `usize`
/// * За trait објекти како `dyn SomeTrait`, метаподатоците се [`DynMetadata<Self>`][DynMetadata] (на пр. `DynMetadata<dyn SomeTrait>`)
///
/// Во future, јазикот Rust може да добие нови видови типови што имаат различни метаподатоци за покажувачот.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Поентата на овој trait е неговиот поврзан тип `Metadata`, што е `()` или `usize` или `DynMetadata<_>` како што е опишано погоре.
/// Автоматски се спроведува за секој тип.
/// Може да се претпостави дека се спроведува во генерички контекст, дури и без соодветна обврска.
///
/// # Usage
///
/// Сурови покажувачи може да се распаднат во компонентите за адреса на податоци и метаподатоци со нивниот метод [`to_raw_parts`].
///
/// Алтернативно, само-метаподатоците можат да се извлечат со функцијата [`metadata`].
/// Референцата може да се пренесе на [`metadata`] и имплицитно да се присили.
///
/// Покажувачот (possibly-wide) може да се состави заедно од неговата адреса и метаподатоците со [`from_raw_parts`] или [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Вид за метаподатоци во покажувачи и упатувања на `Self`.
    #[lang = "metadata_type"]
    // NOTE: Чувајте го trait bounds во `static_assert_expected_bounds_for_metadata`
    //
    // во `library/core/src/ptr/metadata.rs` во синхронизација со оние тука:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Покажувачите за типови кои го спроведуваат овој алијас trait се " тенки`.
///
/// Ова вклучува типови со статичка големина и типови `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: не стабилизирајте го ова пред да не бидат стабилни алијасите на trait во јазикот?
pub trait Thin = Pointee<Metadata = ()>;

/// Извлечете ја компонентата метаподатоци на покажувачот.
///
/// Вредностите од типот `*mut T`, `&T` или `&mut T` може да се пренесат директно на оваа функција, бидејќи тие имплицитно се принудуваат на `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕЗБЕДНОСТ: Пристапот до вредноста од синдикатот `PtrRepr` е безбеден бидејќи * const T
    // и PtrComponents<T>ги имаат истите распореди на меморија.
    // Само std може да ја даде оваа гаранција.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Формира суров покажувач (possibly-wide) од адреса на податоци и метаподатоци.
///
/// Оваа функција е безбедна, но вратениот покажувач не е нужно безбеден за пренасочување.
/// За парчиња, видете ја документацијата на [`slice::from_raw_parts`] за безбедносни барања.
/// За објектите trait, метаподатоците мора да доаѓаат од покажувачот до истиот основен зголемен тип.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕЗБЕДНОСТ: Пристапот до вредноста од синдикатот `PtrRepr` е безбеден бидејќи * const T
    // и PtrComponents<T>ги имаат истите распореди на меморија.
    // Само std може да ја даде оваа гаранција.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ја извршува истата функционалност како [`from_raw_parts`], освен што се враќа суров покажувач `*mut`, за разлика од суровиот покажувач `* const`.
///
///
/// Погледнете ја документацијата за [`from_raw_parts`] за повеќе детали.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕЗБЕДНОСТ: Пристапот до вредноста од синдикатот `PtrRepr` е безбеден бидејќи * const T
    // и PtrComponents<T>ги имаат истите распореди на меморија.
    // Само std може да ја даде оваа гаранција.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Потребно е упатство за да се избегне врската `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Потребно е упатство за да се избегне врската `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метаподатоците за тип на објект `Dyn = dyn SomeTrait` trait.
///
/// Тоа е покажувач за vtable (виртуелна табела за повици) што ги претставува сите потребни информации за манипулирање со бетонскиот тип зачуван во trait објект.
/// Табелата, особено содржи:
///
/// * големина на типот
/// * усогласување на типот
/// * покажувач кон типот `drop_in_place` impl (може да биде забрането работење за обични стари податоци)
/// * покажувачи на сите методи за спроведување на типот на trait
///
/// Забележете дека првите три се посебни затоа што се неопходни за распределување, испуштање и распределување на кој било објект trait.
///
/// Можно е да се именува овој структурен тип со параметар кој не е објект `dyn` trait (на пример `DynMetadata<u64>`), но не и да се добие значајна вредност на тој структура.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Заеднички префикс на сите vtables.Следат индикатори за функции за методите trait.
///
/// Детали за приватна имплементација на `DynMetadata::size_of` итн.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ја враќа големината на типот поврзан со оваа табела.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Го враќа порамнувањето на типот поврзан со оваа табела.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ги враќа големината и порамнувањето заедно како `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕЗБЕДНОСТ: компајлерот ја емитираше оваа табела за бетонски тип Rust кој
        // се знае дека има валиден распоред.Истото образложение како и во `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Прирачник се потребни за да се избегнат границите на `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}