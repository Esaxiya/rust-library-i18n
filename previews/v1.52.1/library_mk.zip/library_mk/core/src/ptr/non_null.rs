use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` но не-нула и коваријанта.
///
/// Ова е често правилната работа што треба да се користи при градење структури на податоци користејќи сирови покажувачи, но во крајна линија е поопасна за употреба поради нејзините дополнителни својства.Ако не сте сигурни дали треба да користите `NonNull<T>`, само користете `*mut T`!
///
/// За разлика од `*mut T`, покажувачот секогаш мора да не е ништовен, дури и ако покажувачот никогаш не е деференциран.Ова е така за да може анкетите да ја користат оваа забранета вредност како дискриминатор-`Option<NonNull<T>>` има иста големина како `* mut T`.
/// Сепак, покажувачот сè уште може да висат ако не е деференциран.
///
/// За разлика од `*mut T`, `NonNull<T>` е избран да биде коваријант во однос на `T`.Ова овозможува да се користи `NonNull<T>` при градење на типови на коваријанти, но се воведува ризик од непроменетост ако се користи во тип што всушност не треба да биде коваријант.
/// (Спротивниот избор беше направен за `*mut T`, иако технички несигурноста може да биде предизвикана само од повик на небезбедни функции.)
///
/// Коваријансата е точна за повеќето безбедни апстракции, како што се `Box`, `Rc`, `Arc`, `Vec` и `LinkedList`.Ова е случај затоа што тие обезбедуваат јавен API кој ги следи нормалните споделени XOR променливи правила на Rust.
///
/// Ако вашиот тип не може безбедно да биде коваријантен, мора да бидете сигурни дека содржи некое дополнително поле за да обезбедите непроменливост.Честопати, ова поле ќе биде од типот [`PhantomData`] како `PhantomData<Cell<T>>` или `PhantomData<&'a mut T>`.
///
/// Забележете дека `NonNull<T>` има инстанца `From` за `&T`.Сепак, ова не го менува фактот дека мутирањето преку (покажувачот изведен од а) споделена референца е недефинирано однесување, освен ако мутацијата не се случи внатре во [`UnsafeCell<T>`].Истото важи и за создавање на променлива референца од споделена референца.
///
/// Кога ја користите оваа инстанца `From` без `UnsafeCell<T>`, ваша одговорност е да осигурате дека `as_mut` никогаш не се повикува, а `as_ptr` никогаш не се користи за мутација.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` покажувачите не се `Send` затоа што податоците што ги упатуваат може да бидат алијас.
// Забелешка, ова прашање е непотребно, но треба да обезбеди подобри пораки за грешки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` покажувачите не се `Sync` затоа што податоците што ги упатуваат може да бидат алијас.
// Забелешка, ова прашање е непотребно, но треба да обезбеди подобри пораки за грешки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Создава нов `NonNull` кој е зависен, но добро усогласен.
    ///
    /// Ова е корисно за иницијализирање на типови кои мрзеливо ги распределуваат, како што прави `Vec::new`.
    ///
    /// Забележете дека вредноста на покажувачот потенцијално може да претставува валиден покажувач на `T`, што значи дека ова не смее да се користи како "not yet initialized" сентинел вредност.
    /// Видовите што мрзеливо ги распределуваат, мораат да ја следат иницијализацијата со некои други средства.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗБЕДНОСТ: mem::align_of() враќа не-нула употреба, која потоа се исфрла
        // до * мут Т.
        // Затоа, `ptr` не е ништовен и се почитуваат условите за повикување на new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Враќа споделени препораки за вредноста.За разлика од [`as_ref`], ова не бара вредноста да биде иницијализирана.
    ///
    /// За променливиот колега, видете [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде правилно порамнет.
    ///
    /// * Мора да биде "dereferencable" во смисла дефинирана во [the module documentation].
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///
    ///   Особено, за времетраење на овој животен век, меморијата кон која покажувачот не смее да се менува (освен во `UnsafeCell`).
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за упатување.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Враќа уникатни упатувања на вредноста.За разлика од [`as_mut`], ова не бара вредноста да биде иницијализирана.
    ///
    /// За споделениот колега видете [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде правилно порамнет.
    ///
    /// * Мора да биде "dereferencable" во смисла дефинирана во [the module documentation].
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///
    ///   Особено, за времетраењето на овој животен век, меморијата на која покажувачот не смее да има пристап (прочитана или напишана) преку кој било друг покажувач.
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за упатување.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Создава нов `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` мора да биде не-ништовен.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `ptr` не е ништовен.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Создава нов `NonNull` ако `ptr` не е ништовен.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗБЕДНОСТ: Покажувачот е веќе проверен и не е ништовен
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ја извршува истата функционалност како [`std::ptr::from_raw_parts`], освен што се враќа `NonNull` покажувач, за разлика од сировиот покажувач `*const`.
    ///
    ///
    /// Погледнете ја документацијата за [`std::ptr::from_raw_parts`] за повеќе детали.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕЗБЕДНОСТ: Резултатот од `ptr::from::raw_parts_mut` не е ништовен, бидејќи `data_address` е.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Распаѓајте (можеби широк) покажувач во компонентите за адреса и метаподатоци.
    ///
    /// Покажувачот подоцна може да се реконструира со [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Го стекнува основниот покажувач `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Враќа споделена референца за вредноста.Ако вредноста може да биде неиницијализирана, наместо тоа мора да се користи [`as_uninit_ref`].
    ///
    /// За променливиот колега, видете [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде правилно порамнет.
    ///
    /// * Мора да биде "dereferencable" во смисла дефинирана во [the module documentation].
    ///
    /// * Покажувачот мора да покаже на иницијализирана инстанца на `T`.
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///
    ///   Особено, за времетраење на овој животен век, меморијата кон која покажувачот не смее да се менува (освен во `UnsafeCell`).
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    /// (Делот за иницијализирање сè уште не е целосно одлучен, но сè додека не биде тоа, единствениот безбеден пристап е да се осигура дека тие навистина се иницијализирани.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за упатување.
        unsafe { &*self.as_ptr() }
    }

    /// Враќа единствена референца за вредноста.Ако вредноста може да биде неиницијализирана, наместо тоа мора да се користи [`as_uninit_mut`].
    ///
    /// За споделениот колега видете [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде правилно порамнет.
    ///
    /// * Мора да биде "dereferencable" во смисла дефинирана во [the module documentation].
    ///
    /// * Покажувачот мора да покаже на иницијализирана инстанца на `T`.
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///
    ///   Особено, за времетраењето на овој животен век, меморијата на која покажувачот не смее да има пристап (прочитана или напишана) преку кој било друг покажувач.
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    /// (Делот за иницијализирање сè уште не е целосно одлучен, но сè додека не биде тоа, единствениот безбеден пристап е да се осигура дека тие навистина се иницијализирани.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за изменлива референца.
        unsafe { &mut *self.as_ptr() }
    }

    /// Фрла на покажувач од друг тип.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕЗБЕДНОСТ: `self` е `NonNull` покажувач кој нужно не е ништовен
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Создава не-нула сурова парче од тенок покажувач и должина.
    ///
    /// Аргументот `len` е бројот на **елементи**, а не бројот на бајти.
    ///
    /// Оваа функција е безбедна, но деференцирањето на повратната вредност е небезбедно.
    /// Погледнете ја документацијата за [`slice::from_raw_parts`] за безбедносни барања.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // креирајте парче покажувач кога започнувате со покажувач до првиот елемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Забележете дека овој пример вештачки демонстрира употреба на овој метод, но `нека парче= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕЗБЕДНОСТ: `data` е `NonNull` покажувач кој нужно не е ништовен
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ја враќа должината на несуптилното сурово парче.
    ///
    /// Вратената вредност е бројот на **елементи**, а не бројот на бајти.
    ///
    /// Оваа функција е безбедна, дури и кога не-нултата сурова парче не може да се пренасочи на парче, бидејќи покажувачот нема валидна адреса.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Враќа покажувач кој не е ништовен во тампонот на парчето.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕЗБЕДНОСТ: Знаеме дека `self` не е ништовен.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Враќа суров покажувач во тампонот на парчето.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Враќа споделена референца на парче евентуално неиницијализирани вредности.За разлика од [`as_ref`], ова не бара вредноста да биде иницијализирана.
    ///
    /// За променливиот колега, видете [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде [valid] за читање за `ptr.len() * mem::size_of::<T>()` многу бајти и тој мора да биде правилно порамнет.Ова особено значи:
    ///
    ///     * Целиот опсег на меморија на ова парче мора да биде содржан во еден распределен објект!
    ///       Парчињата никогаш не можат да се протегаат низ повеќе доделени објекти.
    ///
    ///     * Покажувачот мора да биде порамнет дури и за парчиња со нула должина.
    ///     Една од причините за ова е што оптимизациите на распоредот на енумот може да се потпрат на упатството на референците (вклучувајќи парчиња од која било должина) и да не се ништовни за да се разликуваат од другите податоци.
    ///
    ///     Можете да добиете покажувач што може да се користи како `data` за парчиња со нула должина користејќи [`NonNull::dangling()`].
    ///
    /// * Вкупната големина `ptr.len() * mem::size_of::<T>()` на парчето не смее да биде поголема од `isize::MAX`.
    ///   Погледнете ја безбедносната документација на [`pointer::offset`].
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///   Особено, за времетраење на овој животен век, меморијата кон која покажувачот не смее да се менува (освен во `UnsafeCell`).
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    ///
    /// Видете исто така [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Враќа уникатно упатување на парче евентуално неиницијализирани вредности.За разлика од [`as_mut`], ова не бара вредноста да биде иницијализирана.
    ///
    /// За споделениот колега видете [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Кога го повикувате овој метод, мора да бидете сигурни дека сето следново е точно:
    ///
    /// * Покажувачот мора да биде [valid] за читање и запишување за `ptr.len() * mem::size_of::<T>()` многу бајти, и тој мора да биде правилно порамнет.Ова особено значи:
    ///
    ///     * Целиот опсег на меморија на ова парче мора да биде содржан во еден распределен објект!
    ///       Парчињата никогаш не можат да се протегаат низ повеќе доделени објекти.
    ///
    ///     * Покажувачот мора да биде порамнет дури и за парчиња со нула должина.
    ///     Една од причините за ова е што оптимизациите на распоредот на енумот може да се потпрат на упатството на референците (вклучувајќи парчиња од која било должина) и да не се ништовни за да се разликуваат од другите податоци.
    ///
    ///     Можете да добиете покажувач што може да се користи како `data` за парчиња со нула должина користејќи [`NonNull::dangling()`].
    ///
    /// * Вкупната големина `ptr.len() * mem::size_of::<T>()` на парчето не смее да биде поголема од `isize::MAX`.
    ///   Погледнете ја безбедносната документација на [`pointer::offset`].
    ///
    /// * Вие мора да ги применувате правилата за алијасирање на Rust, бидејќи вратениот животен век `'a` е произволно избран и не мора да го одразува вистинскиот животен век на податоците.
    ///   Особено, за времетраењето на овој животен век, меморијата на која покажувачот не смее да има пристап (прочитана или напишана) преку кој било друг покажувач.
    ///
    /// Ова се однесува дури и ако резултатот од овој метод е неискористен!
    ///
    /// Видете исто така [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ова е безбедно бидејќи `memory` важи за читање и запишување за `memory.len()` многу бајти.
    /// // Забележете дека повикувањето на `memory.as_mut()` не е дозволено овде, бидејќи содржината може да биде неиницијализирана.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Враќа суров покажувач на елемент или под-парче, без да провери граници.
    ///
    /// Повикувањето на овој метод со индекс надвор од границите или кога `self` не е референциран е *[недефинирано однесување]* дури и ако резултирачкиот покажувач не се користи.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕЗБЕДНОСТ: повикувачот гарантира дека `self` е референциран и дека `index` е во граници.
        // Како последица на тоа, покажувачот што може да се добие не може да биде NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕЗБЕДНОСТ: Уникатен покажувач не може да биде ништовен, така што условите за
        // new_unchecked() се почитуваат.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗБЕДНОСТ: Променливата референца не може да биде ништовна.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕЗБЕДНОСТ: Упатувањето не може да биде ништовно, па затоа условите за
        // new_unchecked() се почитуваат.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}