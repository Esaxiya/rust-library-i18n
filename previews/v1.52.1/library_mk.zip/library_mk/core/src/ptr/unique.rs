use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Обвитка околу суров не-нулта `*mut T` што означува дека поседувачот на оваа обвивка е сопственик на референтот.
/// Корисно е за градење апстракции како `Box<T>`, `Vec<T>`, `String` и `HashMap<K, V>`.
///
/// За разлика од `*mut T`, `Unique<T>` се однесува "as if" тоа беше пример на `T`.
/// Имплементира `Send`/`Sync` ако `T` е `Send`/`Sync`.
/// Тоа исто така подразбира вид на силно псевдонимско гарантирање кое може да се очекува на пример за `T`:
/// референцата на покажувачот не треба да се модифицира без единствена патека до нејзиното сопственост.
///
/// Ако не сте сигурни дали е правилно да користите `Unique` за вашите цели, размислете да користите `NonNull`, кој има послаба семантика.
///
///
/// За разлика од `*mut T`, покажувачот секогаш мора да не е ништовен, дури и ако покажувачот никогаш не се повикува на референца.
/// Ова е така за да може анкетите да ја користат оваа забранета вредност како дискриминатор-`Option<Unique<T>>` има иста големина како `Unique<T>`.
/// Сепак, покажувачот сè уште може да висат ако не е деференциран.
///
/// За разлика од `*mut T`, `Unique<T>` е коваријанта во однос на `T`.
/// Ова секогаш треба да биде правилно за секаков вид што ги поддржува барањата за уникација на Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: овој маркер нема последици по варијансата, но е неопходен
    // за Dropck да разбере дека логично поседуваме `T`.
    //
    // За детали, видете:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` покажувачите се `Send` ако `T` е `Send` бидејќи податоците што ги упатуваат се необјективни.
/// Забележете дека оваа непроменлива непроменлива не е засилена од типот систем;апстракцијата со употреба на `Unique` мора да ја спроведе.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` покажувачите се `Sync` ако `T` е `Sync` бидејќи податоците што ги упатуваат се необјективни.
/// Забележете дека оваа непроменлива непроменлива не е засилена од типот систем;апстракцијата со употреба на `Unique` мора да ја спроведе.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Создава нов `Unique` кој е зависен, но добро усогласен.
    ///
    /// Ова е корисно за иницијализирање на типови кои мрзеливо ги распределуваат, како што прави `Vec::new`.
    ///
    /// Забележете дека вредноста на покажувачот потенцијално може да претставува валиден покажувач на `T`, што значи дека ова не смее да се користи како "not yet initialized" сентинел вредност.
    /// Видовите што мрзеливо ги распределуваат, мораат да ја следат иницијализацијата со некои други средства.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗБЕДНОСТ: mem::align_of() враќа важечки покажувач кој не е ништовен.На
        // така се почитуваат условите за повикување на new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Создава нов `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` мора да биде не-ништовен.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `ptr` не е ништовен.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Создава нов `Unique` ако `ptr` не е ништовен.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗБЕДНОСТ: Покажувачот е веќе проверен и не е ништовен.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Го стекнува основниот покажувач `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ја деференцира содржината.
    ///
    /// Резултираниот животен век е обврзан да биде сам, така што ова се однесува "as if", всушност беше пример за Т кој се позајмува.
    /// Ако е потребен подолг животен век на (unbound), користете `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за упатување.
        unsafe { &*self.as_ptr() }
    }

    /// Непосредно ги дереференцира содржините.
    ///
    /// Резултираниот животен век е обврзан да биде сам, така што ова се однесува "as if", всушност беше пример за Т кој се позајмува.
    /// Ако е потребен подолг животен век на (unbound), користете `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` ги исполнува сите
        // барања за изменлива референца.
        unsafe { &mut *self.as_ptr() }
    }

    /// Фрла на покажувач од друг тип.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕЗБЕДНОСТ: Unique::new_unchecked() создава нов уникатен и потребен
        // дадениот покажувач да не биде ништовен.
        // Бидејќи поминуваме себеси како покажувач, тој не може да биде ништовен.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗБЕДНОСТ: Променливата референца не може да биде ништовна
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}