#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Се проширува или на `$crate::panic::panic_2015` или `$crate::panic::panic_2021` во зависност од изданието на повикувачот.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Тврди дека два израза се еднакви едни на други (користејќи [`PartialEq`]).
///
/// На panic, ова макро ќе ги отпечати вредностите на изразите со нивните репрезентации за дебагирање.
///
///
/// Како и [`assert!`], и оваа макро има втора форма, каде што може да се обезбеди прилагодена порака panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Реборровите подолу се намерни.
                    // Без нив, слотот за стек за позајмица се иницијализира дури и пред да се споредат вредностите, што доведува до забележително забавување.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Реборровите подолу се намерни.
                    // Без нив, слотот за стек за позајмица се иницијализира дури и пред да се споредат вредностите, што доведува до забележително забавување.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Тврди дека два израза не се еднакви едни на други (со употреба на [`PartialEq`]).
///
/// На panic, ова макро ќе ги отпечати вредностите на изразите со нивните репрезентации за дебагирање.
///
///
/// Како и [`assert!`], и оваа макро има втора форма, каде што може да се обезбеди прилагодена порака panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Реборровите подолу се намерни.
                    // Без нив, слотот за стек за позајмица се иницијализира дури и пред да се споредат вредностите, што доведува до забележително забавување.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Реборровите подолу се намерни.
                    // Без нив, слотот за стек за позајмица се иницијализира дури и пред да се споредат вредностите, што доведува до забележително забавување.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Тврди дека буловиот израз е `true` при извршување.
///
/// Ова ќе се повика на макро [`panic!`] ако дадениот израз не може да се оцени до `true` при извршувањето.
///
/// Како [`assert!`], и оваа макро има втора верзија, каде што може да се обезбеди прилагодена порака panic.
///
/// # Uses
///
/// За разлика од [`assert!`], изјавите `debug_assert!` се овозможени само во неоптимизирани градови по дифолт.
/// Оптимизираното градење нема да ги извршува изјавите `debug_assert!` освен ако `-C debug-assertions` не биде предаден на компајлерот.
/// Ова го прави `debug_assert!` корисен за проверки кои се премногу скапи за да бидат присутни во изградбата на ослободување, но може да бидат корисни за време на развојот.
/// Резултатот од проширувањето на `debug_assert!` секогаш се проверува како тип.
///
/// Непроверено тврдење овозможува програма во неконзистентна состојба да продолжи да работи, што може да има неочекувани последици, но не воведува несигурност сè додека тоа се случува само во безбеден код.
///
/// Трошоците за изведба на тврдењата, сепак, не се мерат воопшто.
/// Заменувањето на [`assert!`] со `debug_assert!` се охрабрува само по темелно профилирање, и што е уште поважно, само во безбеден код!
///
/// # Examples
///
/// ```
/// // пораката panic за овие тврдења е низирана вредност на дадениот израз.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // многу едноставна функција
/// debug_assert!(some_expensive_computation());
///
/// // тврди со сопствена порака
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Тврди дека два израза се еднакви едни на други.
///
/// На panic, ова макро ќе ги отпечати вредностите на изразите со нивните репрезентации за дебагирање.
///
/// За разлика од [`assert_eq!`], изјавите `debug_assert_eq!` се овозможени само во неоптимизирани градови по дифолт.
/// Оптимизираното градење нема да ги извршува изјавите `debug_assert_eq!` освен ако `-C debug-assertions` не биде предаден на компајлерот.
/// Ова го прави `debug_assert_eq!` корисен за проверки кои се премногу скапи за да бидат присутни во изградбата на ослободување, но може да бидат корисни за време на развојот.
///
/// Резултатот од проширувањето на `debug_assert_eq!` секогаш се проверува како тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Тврди дека два израза не се еднакви едни на други.
///
/// На panic, ова макро ќе ги отпечати вредностите на изразите со нивните репрезентации за дебагирање.
///
/// За разлика од [`assert_ne!`], изјавите `debug_assert_ne!` се овозможени само во неоптимизирани градови по дифолт.
/// Оптимизираното градење нема да ги извршува изјавите `debug_assert_ne!` освен ако `-C debug-assertions` не биде предаден на компајлерот.
/// Ова го прави `debug_assert_ne!` корисен за проверки кои се премногу скапи за да бидат присутни во изградбата на ослободување, но може да бидат корисни за време на развојот.
///
/// Резултатот од проширувањето на `debug_assert_ne!` секогаш се проверува како тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Враќа дали дадениот израз одговара на некој од дадените обрасци.
///
/// Како во изразот `match`, моделот по избор може да биде проследен со `if` и заштитнички израз што има пристап до имињата врзани за моделот.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Открива резултат или ја шири неговата грешка.
///
/// Операторот `?` е додаден да го замени `try!` и треба да се користи наместо тоа.
/// Понатаму, `try` е резервиран збор во Rust 2018, па ако мора да го користите, ќе треба да го користите [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` одговара на дадениот [`Result`].Во случај на варијанта `Ok`, изразот има вредност на завитканата вредност.
///
/// Во случај на варијанта `Err`, таа ја враќа внатрешната грешка.`try!` потоа извршува конверзија користејќи `From`.
/// Ова обезбедува автоматска конверзија помеѓу специјализирани грешки и поопшти.
/// Резултирачката грешка веднаш се враќа.
///
/// Заради раното враќање, `try!` може да се користи само во функции што враќаат [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Префериран метод за брзо враќање на грешките
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Претходниот метод за брзо враќање на грешките
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ова е еквивалентно на:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Пишува форматирани податоци во тампон.
///
/// Оваа макро прифаќа 'writer', низа формат и список на аргументи.
/// Аргументите ќе бидат форматирани според наведената низа формат и резултатот ќе биде предаден на писателот.
/// Писателот може да има каква било вредност со методот `write_fmt`;генерално, ова доаѓа од имплементација или на [`fmt::Write`] или на [`io::Write`] trait.
/// Макро враќа што и да се врати методот `write_fmt`;најчесто [`fmt::Result`] или [`io::Result`].
///
/// Погледнете [`std::fmt`] за повеќе информации за синтаксата на низата формат.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модулот може да увезува и `std::fmt::Write` и `std::io::Write` и да повикува `write!` на објекти што ги спроведуваат или, бидејќи предметите обично не ги имплементираат обете.
///
/// Сепак, модулот мора да го увезе квалификуваниот traits за нивните имиња да не се во конфликт:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // користи fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // користи io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Оваа макро може да се користи и при поставувања на `no_std`.
/// Во поставувањето `no_std` вие сте одговорни за деталите за имплементација на компонентите.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Напишете форматирани податоци во тампон, со додадена нова линија.
///
/// На сите платформи, новата линија е карактерот LINE FEED само (`\n`/`U+000A`) (нема дополнителен CARRIAGE RETURN (`\r`/`U+000D`)).
///
/// За повеќе информации, видете [`write!`].За информации за синтаксата на низата формат, видете [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модулот може да увезува и `std::fmt::Write` и `std::io::Write` и да повикува `write!` на објекти што ги спроведуваат или, бидејќи предметите обично не ги имплементираат обете.
/// Сепак, модулот мора да го увезе квалификуваниот traits за нивните имиња да не се во конфликт:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // користи fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // користи io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Укажува на недостижен код.
///
/// Ова е корисно во секое време кога компајлерот не може да утврди дека некој код не е достапен.На пример:
///
/// * Натпревар на оружје со услови на чување
/// * Јамки кои динамички завршуваат.
/// * Итератори кои динамички завршуваат.
///
/// Ако се утврди дека неточно е утврдено дека кодот е недостижен, програмата веднаш завршува со [`panic!`].
///
/// Небезбедниот пандан на оваа макро е функцијата [`unreachable_unchecked`], што ќе предизвика недефинирано однесување доколку се достигне кодот.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ова секогаш ќе биде [`panic!`].
///
/// # Examples
///
/// Натпреварувачки раце:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // компајлирај грешка ако е коментирана
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // една од најсиромашните имплементации на x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Укажува на неимплементиран код со паника со порака "not implemented".
///
/// Ова му овозможува на вашиот код да провери тип, што е корисно ако прототипирате или спроведувате trait за кој се потребни повеќе методи кои не планирате да ги користите сите.
///
/// Разликата помеѓу `unimplemented!` и [`todo!`] е дека додека `todo!` пренесува намера да ја спроведе функционалноста подоцна и пораката е "not yet implemented", `unimplemented!` не дава такви тврдења.
/// Неговата порака е "not implemented".
/// Исто така, некои ИДИ ќе означат `todo!` S.
///
/// # Panics
///
/// Ова секогаш ќе биде [`panic!`] бидејќи `unimplemented!` е само стенографија за `panic!` со фиксна, специфична порака.
///
/// Како и `panic!`, и оваа макро има втора форма за прикажување на сопствени вредности.
///
/// # Examples
///
/// Кажете дека имаме trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Ние сакаме да ја имплементираме `Foo` за 'MyStruct', но од некоја причина има смисла само да се спроведе функцијата `bar()`.
/// `baz()` и `qux()` сепак ќе треба да бидат дефинирани во нашата имплементација на `Foo`, но можеме да користиме `unimplemented!` во нивните дефиниции за да дозволиме да се состави нашиот код.
///
/// Сè уште сакаме нашата програма да престане да работи ако се постигнат неимплементираните методи.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Нема смисла за `baz` a `MyStruct`, па затоа воопшто немаме логика тука.
/////
///         // Ова ќе го прикаже "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Имаме одредена логика тука, можеме да додадеме порака до неимплементирана!да го прикажеме нашиот пропуст.
///         // Ова ќе прикаже: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Укажува на недовршен код.
///
/// Ова може да биде корисно ако прототипирате и барате само проверка на типот на кодот.
///
/// Разликата помеѓу [`unimplemented!`] и `todo!` е дека додека `todo!` пренесува намера да ја спроведе функционалноста подоцна и пораката е "not yet implemented", `unimplemented!` не дава такви тврдења.
/// Неговата порака е "not implemented".
/// Исто така, некои ИДИ ќе означат `todo!` S.
///
/// # Panics
///
/// Ова секогаш ќе биде [`panic!`].
///
/// # Examples
///
/// Еве пример за некои тековни кодови.Имаме trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Ние сакаме да го имплементираме `Foo` на еден од нашите типови, но исто така сакаме прво да работиме само на `bar()`.За да се состави нашиот код, треба да имплементираме `baz()`, за да можеме да користиме `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // спроведувањето оди тука
///     }
///
///     fn baz(&self) {
///         // да не се грижиме за спроведување на baz() засега
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ние дури и не користиме baz(), затоа е добро.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Дефиниции на вградени макроа.
///
/// Повеќето од макро својствата (стабилност, видливост итн.) Се земени од изворниот код тука, со исклучок на функциите за проширување што ги трансформираат макро влезовите во излези, тие функции ги обезбедува компајлерот.
///
///
pub(crate) mod builtin {

    /// Причинува компилацијата да не успее со дадената порака за грешка кога ќе се сретне.
    ///
    /// Оваа макро треба да се користи кога crate користи стратегија за условна компилација за да обезбеди подобри пораки за грешки за погрешни услови.
    ///
    /// Тоа е форма на ниво на компајлер на [`panic!`], но емитува грешка за време на *компилацијата* отколку за *време на траење*.
    ///
    /// # Examples
    ///
    /// Два такви примери се макроа и `#[cfg]` средини.
    ///
    /// Испуштете подобра грешка на компајлерот ако макро е донесено со невалидни вредности.
    /// Без последната branch, компајлерот сè уште емитува грешка, но пораката за грешката не ги споменува двете валидни вредности.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Испуштете грешка од компајлерот ако една од низата карактеристики не е достапна.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Конструира параметри за другите макроа за форматирање на низата.
    ///
    /// Ова макро функционира со земање на низа за форматирање буквално што содржи `{}` за секој дополнителен аргумент.
    /// `format_args!` ги подготвува дополнителните параметри за да осигури дека излезот може да се толкува како низа и ги канонизира аргументите во еден вид.
    /// Секоја вредност што го спроведува [`Display`] trait може да се пренесе на `format_args!`, како и секоја имплементација на [`Debug`] да се пренесе на `{:?}` во рамките на низата за форматирање.
    ///
    ///
    /// Оваа макро произведува вредност од типот [`fmt::Arguments`].Оваа вредност може да се пренесе на макроата во рамките на [`std::fmt`] за извршување корисна пренасочување.
    /// Сите други макроа за форматирање ([" формат!`], [`write!`], [`println!`], итн.) Се проксираат преку оваа.
    /// `format_args!`, за разлика од добиените макроа, ги избегнува распределбите на грамадите.
    ///
    /// Можете да ја користите вредноста [`fmt::Arguments`] што `format_args!` ја враќа во контексти `Debug` и `Display` како што се гледа подолу.
    /// Примерот, исто така, покажува дека `Debug` и `Display` формат на иста работа: интерполираната низа формат во `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// За повеќе информации, видете ја документацијата во [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Исто како `format_args`, но на крајот додава нова линија.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Прегледува променлива на околината во времето на компајлирање.
    ///
    /// Ова макро ќе се прошири на вредноста на именуваната променлива на околината во времето на компајлирање, давајќи израз од типот `&'static str`.
    ///
    ///
    /// Ако променливата на околината не е дефинирана, тогаш ќе се емитува грешка во компилацијата.
    /// За да не испуштите грешка при компајлирање, наместо тоа, користете макро [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Можете да ја прилагодите пораката за грешка со поминување на низа како втор параметар:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ако променливата на животната средина `documentation` не е дефинирана, ќе ја добиете следнава грешка:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// По избор ја проверува променливата на околината во времето на компајлирање.
    ///
    /// Ако именуваната променлива на околината е присутна во времето на компајлирање, ова ќе се прошири во израз од типот `Option<&'static str>` чија вредност е `Some` од вредноста на променливата на околината.
    /// Ако променливата на околината не е присутна, тогаш ова ќе се прошири на `None`.
    /// Погледнете [`Option<T>`][Option] за повеќе информации за овој тип.
    ///
    /// Никогаш не се емитува грешка во времето на компајлирање кога се користи оваа макро, без оглед дали е присутна променливата на околината или не.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ги спојува идентификаторите во еден идентификатор.
    ///
    /// Оваа макро зема кој било број идентификатори одделени со запирка и ги спојува сите во едно, давајќи израз што е нов идентификатор.
    /// Забележете дека хигиената го прави такво што ова макро не може да снима локални променливи.
    /// Исто така, како општо правило, макроата се дозволени само во ставката, изјавата или изразната позиција.
    /// Тоа значи дека додека можете да ја користите оваа макро за повикување на постојните променливи, функции или модули итн., Не можете да дефинирате нова со неа.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ несреќи! (ново, забавно, име) { }//не е употребливо на овој начин!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Соединува буквали во статичка нишка.
    ///
    /// Оваа макро зема секаков број буквали разделени со запирка, давајќи израз од типот `&'static str`, што ги претставува сите буквали, споени лево-десно.
    ///
    ///
    /// Буквалите од цел број и подвижна точка се низираат со цел да бидат споени.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Се проширува до бројот на линијата на кој е повикан.
    ///
    /// Со [`column!`] и [`file!`], овие макроа обезбедуваат информации за дебагирање за програмерите за локацијата во рамките на изворот.
    ///
    /// Проширениот израз има тип `u32` и е базиран на 1, така што првата линија во секоја датотека оценува на 1, втората на 2, итн.
    /// Ова е во согласност со пораките за грешки од обичните компајлери или популарни уредници.
    /// Вратината линија не е * ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** *--------------------
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Се проширува до бројот на колоната на која е повикана.
    ///
    /// Со [`line!`] и [`file!`], овие макроа обезбедуваат информации за дебагирање за програмерите за локацијата во рамките на изворот.
    ///
    /// Проширениот израз има тип `u32` и е заснован на 1, така што првата колона во секоја линија оценува на 1, втората на 2, итн.
    /// Ова е во согласност со пораките за грешки од обичните компајлери или популарни уредници.
    /// Вратината колона не е * ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Се проширува до името на датотеката во која е повикана.
    ///
    /// Со [`line!`] и [`column!`], овие макроа обезбедуваат информации за дебагирање за програмерите за локацијата во рамките на изворот.
    ///
    /// Проширениот израз има тип `&'static str`, а вратената датотека не е повикување на самата макро `file!`, туку е прва макро повикување што води до повикување на макро `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Ги стрифицира своите аргументи.
    ///
    /// Оваа макро ќе даде израз од типот `&'static str` што е низа од сите tokens пренесени во макро.
    /// Не се ставаат ограничувања на синтаксата на самата макро повикување.
    ///
    /// Забележете дека проширените резултати од влезот tokens може да се променат во future.Треба да бидете претпазливи ако се потпрете на излезот.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Вклучува кодирана датотека UTF-8 како низа.
    ///
    /// Датотеката се наоѓа во однос на тековната датотека (слично како се наоѓаат модулите).
    /// Обезбедената патека се толкува на специфичен начин на платформа во времето на компајлирање.
    /// Така, на пример, повик со Windows патека што содржи задни трепки `\` не би се составил правилно на Unix.
    ///
    ///
    /// Оваа макро ќе даде израз од типот `&'static str` што е содржината на датотеката.
    ///
    /// # Examples
    ///
    /// Да претпоставиме дека има две датотеки во истиот директориум со следната содржина:
    ///
    /// Датотека 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Датотека 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Составувањето 'main.rs' и извршувањето на добиената бинарна верзија ќе го отпечати "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Вклучува датотека како повикување на низа бајти.
    ///
    /// Датотеката се наоѓа во однос на тековната датотека (слично како се наоѓаат модулите).
    /// Обезбедената патека се толкува на специфичен начин на платформа во времето на компајлирање.
    /// Така, на пример, повик со Windows патека што содржи задни трепки `\` не би се составил правилно на Unix.
    ///
    ///
    /// Оваа макро ќе даде израз од типот `&'static [u8; N]` што е содржината на датотеката.
    ///
    /// # Examples
    ///
    /// Да претпоставиме дека има две датотеки во истиот директориум со следната содржина:
    ///
    /// Датотека 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Датотека 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Составувањето 'main.rs' и извршувањето на добиената бинарна верзија ќе го отпечати "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Се проширува на низа што ја претставува тековната патека на модулот.
    ///
    /// Тековната патека на модулот може да се смета како хиерархија на модулите што водат назад до crate root.
    /// Првата компонента на патеката што се враќа е името на crate што моментално се составува.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ги проценува буловите комбинации на знамињата за конфигурација во времето на компајлирање.
    ///
    /// Покрај атрибутот `#[cfg]`, ова макро е предвидено за да се овозможи проценка на буловиот израз на знамињата за конфигурација.
    /// Ова често доведува до помалку удвоени кодови.
    ///
    /// Синтаксата дадена на оваа макро е иста синтакса како и атрибутот [`cfg`].
    ///
    /// `cfg!`, за разлика од `#[cfg]`, не отстранува никаков код и само проценува како точно или неточно.
    /// На пример, сите блокови во изразот if/else треба да бидат валидни кога се користи `cfg!` за состојбата, без оглед на тоа што оценува `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Разделува датотека како израз или ставка според контекстот.
    ///
    /// Датотеката се наоѓа во однос на тековната датотека (слично како се наоѓаат модулите).Обезбедената патека се толкува на специфичен начин на платформа во времето на компајлирање.
    /// Така, на пример, повик со Windows патека што содржи задни трепки `\` не би се составил правилно на Unix.
    ///
    /// Користењето на оваа макро е често лоша идеја, затоа што ако датотеката се анализира како израз, нехигиенски ќе се стави во околниот код.
    /// Ова може да резултира во променливи или функции кои се различни од она што ја очекува датотеката ако има варијабли или функции што имаат исто име во тековната датотека.
    ///
    ///
    /// # Examples
    ///
    /// Да претпоставиме дека има две датотеки во истиот директориум со следната содржина:
    ///
    /// Датотека 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Датотека 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Составувањето 'main.rs' и извршувањето на добиената бинарна верзија ќе го отпечати "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Тврди дека буловиот израз е `true` при извршување.
    ///
    /// Ова ќе се повика на макро [`panic!`] ако дадениот израз не може да се оцени до `true` при извршувањето.
    ///
    /// # Uses
    ///
    /// Тврдењата секогаш се проверуваат и во дебагирање и во градење пораки и не можат да бидат оневозможени.
    /// Погледнете [`debug_assert!`] за тврдења што не се стандардно овозможени во градите на изданија.
    ///
    /// Небезбедниот код може да се потпре на `assert!` за да ги спроведе инваријантите за време на траење кои, доколку се прекршат, може да доведат до небезбедност.
    ///
    /// Другите случаи на употреба на `assert!` вклучуваат тестирање и спроведување на инваријанти на времетраење во безбеден код (чие прекршување не може да резултира во несигурност).
    ///
    ///
    /// # Прилагодени пораки
    ///
    /// Оваа макро има втора форма, каде што може да се обезбеди прилагодена порака panic со или без аргументи за форматирање.
    /// Погледнете [`std::fmt`] за синтакса за оваа форма.
    /// Изразите што се користат како аргументи на форматот ќе се оценуваат само ако тврдењето не успее.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // пораката panic за овие тврдења е низирана вредност на дадениот израз.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // многу едноставна функција
    ///
    /// assert!(some_computation());
    ///
    /// // тврди со сопствена порака
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Вметнато склопување.
    ///
    /// Прочитајте го [unstable book] за употребата.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Внатрешно склопување во стил на LLVM.
    ///
    /// Прочитајте го [unstable book] за употребата.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Внатрешно склопување на ниво на модул.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Отпечатоците го поминаа tokens во стандардниот излез.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Овозможува или оневозможува функционалност за пронаоѓање што се користи за дебагирање на други макроа.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Атрибут макро се користи за примена на изведени макроа.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Атрибут макро се применува на функција за да се претвори во единица тест.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Атрибут макро се применува на функција да се претвори во репер тест.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Детал за имплементација на макроата `#[test]` и `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Атрибутната макро се применува на статичка за да се регистрира како глобален алокатор.
    ///
    /// Видете исто така [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Го чува предметот на којшто се применува ако поминатиот пат е достапен и го отстранува на друг начин.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ги проширува сите атрибути `#[cfg]` и `#[cfg_attr]` во фрагментот на кодот на кој се применува.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Нестабилен детал за имплементација на компајлерот `rustc`, не користете.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Нестабилен детал за имплементација на компајлерот `rustc`, не користете.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}