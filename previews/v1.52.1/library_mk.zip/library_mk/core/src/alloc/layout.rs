use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Додека оваа функција се користи на едно место и нејзината имплементација може да се истакне, претходните обиди да го сторат тоа го направија rustc побавен:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Распоред на блок меморија.
///
/// Еден пример на `Layout` опишува одреден распоред на меморијата.
/// Изградувате `Layout` up како влез за да му дадете на алокаторот.
///
/// Сите распореди имаат поврзана големина и усогласување моќност од два.
///
/// (Забележете дека *не е задолжително* распоредот да има не-нула големина, иако `GlobalAlloc` бара сите барања за меморија да бидат не-нула во големина.
/// Повикувачот мора или да осигури дека ваквите услови се исполнети, да користи специфични алокатори со полабави барања или да го користи поблагиот интерфејс `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // големината на бараниот блок меморија, измерена во бајти.
    size_: usize,

    // усогласување на бараниот блок меморија, мерено во бајти.
    // осигуруваме дека ова е секогаш моќност на два, бидејќи API како `posix_memalign` го бара тоа и е разумно ограничување да се наметне на конструкторите на Layout.
    //
    //
    // (Сепак, аналогно не бараме `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Конструира `Layout` од дадени `size` и `align` или враќа `LayoutError` ако не е исполнет некој од следниве услови:
    ///
    /// * `align` не смее да биде нула,
    ///
    /// * `align` мора да биде моќ на двајца,
    ///
    /// * `size`, кога е заокружен до најблискиот множител на `align`, не смее да се прелива (т.е., заоблената вредност мора да биде помала или еднаква на `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (моќта на два подразбира порамнување!=0.)

        // Заоблената големина е:
        //   size_rounded_up=(големина + порамнување, 1)&! (порамни, 1);
        //
        // Ние знаеме од горе дека усогласување!=0.
        // Ако додавањето (порамни, 1) не се прелее, тогаш заокружувањето ќе биде добро.
        //
        // Обратно, и-маскирањето со! (Порамни, 1) ќе ги одземе битовите со низок редослед.
        // Така, ако се случи прелевање со збирот,&-маската не може да одземе доволно за да го врати овој прелевање.
        //
        //
        // Горе посочува дека проверката за прелевање на збир е истовремено неопходна и доволна.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕЗБЕДНОСТ: условите за `from_size_align_unchecked` биле
        // проверено погоре.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Создава распоред, заобиколувајќи ги сите проверки.
    ///
    /// # Safety
    ///
    /// Оваа функција е небезбедна бидејќи не ги потврдува предусловите од [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕЗБЕДНОСТ: повикувачот мора да осигури дека `align` е поголем од нула.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Минималната големина во бајти за мемориски блок од овој распоред.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Минимално порамнување на бајти за мемориски блок од овој распоред.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Конструира `Layout` погоден за држење вредност од типот `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕЗБЕДНОСТ: усогласувањето е загарантирано од Rust дека е моќност на два и
        // обемот + усогласување на комбо е загарантиран да се вклопи во нашиот адресен простор.
        // Како резултат, користете го неконтролираниот конструктор тука за да избегнете вметнување код што panics ако не е доволно оптимизиран.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Произведува распоред опишувајќи запис што може да се искористи за да се распредели структурата на поддршката за `T` (што може да биде trait или друг неизмерен тип како парче).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗБЕДНОСТ: видете го образложението во `new` зашто ова ја користи небезбедната варијанта
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Произведува распоред опишувајќи запис што може да се искористи за да се распредели структурата на поддршката за `T` (што може да биде trait или друг неизмерен тип како парче).
    ///
    /// # Safety
    ///
    /// Оваа функција е безбедна за повикување само ако важат следниве услови:
    ///
    /// - Ако `T` е `Sized`, оваа функција е секогаш безбедна за повикување.
    /// - Ако големина на опашката на `T` е:
    ///     - [slice], тогаш должината на парчето опашка мора да биде интелијализиран цел број, а големината на *целата вредност*(динамична должина на опашката + статички префикс со големина) мора да се вклопи во `isize`.
    ///     - [trait object], тогаш vtable дел од покажувачот мора да укаже на валидна vtable за типот `T` стекнат со обемнување на големината, а големината на *целата вредност*(динамична должина на опашката + префикс со статичка големина) мора да се вклопи во `isize`.
    ///
    ///     - (unstable) [extern type], тогаш оваа функција е секогаш безбедна за повикување, но може panic или на друг начин да ја врати погрешната вредност, бидејќи изгледот на надворешниот тип не е познат.
    ///     Ова е исто однесување како [`Layout::for_value`] при повикување на опашка од надворешен тип.
    ///     - во спротивно, не е дозволено конзервативно да се повикува оваа функција.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕЗБЕДНОСТ: ние ги пренесуваме предусловите на овие функции до повикувачот
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗБЕДНОСТ: видете го образложението во `new` зашто ова ја користи небезбедната варијанта
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Создава `NonNull` кој е зависен, но добро усогласен за овој распоред.
    ///
    /// Забележете дека вредноста на покажувачот потенцијално може да претставува валиден покажувач, што значи дека ова не смее да се користи како вредност за чувар "not yet initialized".
    /// Видовите што мрзеливо ги распределуваат, мораат да ја следат иницијализацијата со некои други средства.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕЗБЕДНОСТ: усогласувањето е загарантирано дека не е нула
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Создава распоред што го опишува записот што може да содржи вредност на истиот распоред како `self`, но исто така е усогласен со порамнувањето `align` (мерено во бајти).
    ///
    ///
    /// Ако `self` веќе го исполнува пропишаното усогласување, тогаш се враќа `self`.
    ///
    /// Забележете дека овој метод не додава никакво полнење на вкупната големина, без оглед на тоа дали вратениот распоред има различно порамнување.
    /// Со други зборови, ако `K` има големина 16, `K.align_to(32)`*сепак* ќе има големина 16.
    ///
    /// Враќа грешка ако комбинацијата на `self.size()` и дадениот `align` ги крши условите наведени во [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ја враќа количината на баласт што мора да ја вметнеме по `self` за да се осигураме дека следнава адреса ќе задоволи `align` (мерена во бајти).
    ///
    /// на пример, ако `self.size()` е 9, тогаш `self.padding_needed_for(4)` враќа 3, затоа што тоа е минималниот број бајти за полнење што е потребно за да се добие 4-порамнета адреса (под претпоставка дека соодветниот мемориски блок започнува од 4-порамнета адреса).
    ///
    ///
    /// Вратината вредност на оваа функција нема значење ако `align` не е моќност на два.
    ///
    /// Забележете дека алатката за вратената вредност бара `align` да биде помала или еднаква на порамнувањето на почетната адреса за целиот распределен блок меморија.Еден начин да се задоволи ова ограничување е да се обезбеди `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Заокружената вредност е:
        //   len_rounded_up=(len + align, 1)&! (порамни, 1);
        // и потоа ја враќаме разликата во баласт: `len_rounded_up - len`.
        //
        // Ние користиме модуларна аритметика низ:
        //
        // 1. усогласувањето е загарантирано дека е> 0, затоа порамнувај, 1 е секогаш валидно.
        //
        // 2.
        // `len + align - 1` може да се прелее најмногу за `align - 1`, така што&-маската со `!(align - 1)` ќе осигури дека во случај на прелевање, `len_rounded_up` самото ќе биде 0.
        //
        //    Така, вратеното полнење, кога се додава на `len`, дава 0, што тривијално ја задоволува трасата `align`.
        //
        // (Се разбира, обидите да се распределат блокови меморија чија големина и полнење се прелеваат на горенаведениот начин, треба да предизвикаат алокаторот да донесе грешка во секој случај.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Создава распоред со заокружување на големината на овој распоред до повеќекратно порамнување на изгледот.
    ///
    ///
    /// Ова е еквивалентно на додавање на резултатот од `padding_needed_for` во моменталната големина на изгледот.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ова не може да се прелее.Цитирање од непроменетиот распоред:
        // > `size`, кога се заокружуваат до најблискиот множител на `align`,
        // > не смее да се прелева (т.е., заоблената вредност мора да биде помала од
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Создава распоред што го опишува записот за `n` примероци на `self`, со соодветно количество на полнење помеѓу секое за да се осигура дека на секоја инстанца и е дадена бараната големина и порамнување.
    /// За успех, се враќа `(k, offs)` каде `k` е распоредот на низата и `offs` е растојанието помеѓу почетокот на секој елемент во низата.
    ///
    /// При аритметичко прелевање, се враќа `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ова не може да се прелее.Цитирање од непроменетиот распоред:
        // > `size`, кога се заокружуваат до најблискиот множител на `align`,
        // > не смее да се прелева (т.е., заоблената вредност мора да биде помала од
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕЗБЕДНОСТ: self.align е веќе познато дека е валиден, а алоцираната големина е
        // поместено веќе.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Создава распоред што го опишува записот за `self` проследен со `next`, вклучувајќи ги и сите потребни полнења за да се осигура дека `next` ќе биде правилно порамнет, но *без заостанувачко пополнување*.
    ///
    /// Со цел да се совпадне распоредот на репрезентацијата C `repr(C)`, треба да се јавите во `pad_to_align` откако ќе го продолжите распоредот со сите полиња.
    /// (Не постои начин да се совпадне стандардниот изглед на репрезентацијата Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Забележете дека усогласувањето на добиениот распоред ќе биде максимум од оние на `self` и `next`, со цел да се обезбеди усогласување на двата дела.
    ///
    /// Враќа `Ok((k, offset))`, каде `k` е распоред на сврзаниот запис и `offset` е релативна локација, во бајти, на почетокот на `next` вграден во сврзаниот запис (под претпоставка дека самиот запис започнува со неутрализирање 0).
    ///
    ///
    /// При аритметичко прелевање, се враќа `LayoutError`.
    ///
    /// # Examples
    ///
    /// Да се пресмета распоредот на структурата `#[repr(C)]` и пребивањата на полињата од распоредите на нејзините полиња:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не заборавајте да финализирате со `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // тест дека работи
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Создава распоред што го опишува записот за `n` примероци на `self`, без пополнување помеѓу секоја инстанца.
    ///
    /// Забележете дека, за разлика од `repeat`, `repeat_packed` не гарантира дека повторуваните примери на `self` ќе бидат правилно порамнети, дури и ако дадената инстанца на `self` е правилно порамнета.
    /// Со други зборови, ако изгледот вратен од `repeat_packed` се користи за распределување на низа, не е гарантирано дека сите елементи во низата ќе бидат правилно порамнети.
    ///
    /// При аритметичко прелевање, се враќа `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Создава распоред што го опишува записот за `self` проследен со `next` без дополнително полнење помеѓу нив.
    /// Бидејќи не е вметната баласт, порамнувањето на `next` е ирелевантно и воопшто не е вметнато * во добиениот изглед.
    ///
    ///
    /// При аритметичко прелевање, се враќа `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Создава распоред што го опишува записот за `[T; n]`.
    ///
    /// При аритметичко прелевање, се враќа `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметрите дадени на `Layout::from_size_align` или на некој друг конструктор `Layout` не ги задоволуваат неговите документирани ограничувања.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ова ни треба за повратно влијание на грешка trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}