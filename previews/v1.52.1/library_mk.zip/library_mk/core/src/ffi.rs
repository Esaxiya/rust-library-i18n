#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Комунални услуги поврзани со врски за поврзување (FFI) со странска функција.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Еквивалентно на типот `void` на Ц кога се користи како [pointer].
///
/// Во суштина, `*const c_void` е еквивалентно на C's `const void*` и `*mut c_void` е еквивалентно на C's `void*`.
/// Со тоа, ова не е * исто што и типот X на `void`, што е тип `()` на Rust.
///
/// За моделирање на покажувачи на нетранспарентни типови во FFI, сè додека не се стабилизира `extern type`, се препорачува да користите обвивка newtype околу празна бајт низа.
///
/// Погледнете го [Nomicon] за детали.
///
/// Може да се користи `std::os::raw::c_void` ако сакаат да го поддржат стариот компајлер Rust до 1.1.0.
/// По Rust 1.30.0, тој беше реекспортиран според оваа дефиниција.
/// За повеќе информации, прочитајте [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// Забелешка, за LLVM да го препознае празниниот тип на покажувачот и според функциите за проширување како malloc(), треба да го имаме претставено како i8 * во бит-кодот LLVM.
// Енумот што се користи тука го обезбедува ова и спречува злоупотреба на типот "raw" само со приватни варијанти.
// Потребни ни се две варијанти, бидејќи компајлерот се жали на атрибутот repr инаку и ни треба барем една варијанта, бидејќи во спротивно енумот ќе биде ненаселен и барем деференцирањето на таквите покажувачи ќе биде UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Основна имплементација на `va_list`.
// Името е WIP, користејќи `VaListImpl` засега.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Непроменлив во однос на `'f`, така што секој објект `VaListImpl<'f>` е врзан за регионот на функцијата во која е дефиниран
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Имплементација на АБИ на `va_list`.
/// Погледнете го [AArch64 Procedure Call Standard] за повеќе детали.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Имплементација на АБИ на `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Имплементација на АБИ на `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Обвивка за `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Конвертирајте `VaListImpl` во `VaList` што е бинарен компатибилен со C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Конвертирајте `VaListImpl` во `VaList` што е бинарен компатибилен со C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait треба да се користи во јавни интерфејси, сепак, самиот trait не смее да се дозволи да се користи надвор од овој модул.
// Да им се дозволи на корисниците да го имплементираат trait за нов тип (со што се дозволува ва_арг да се користи за нов тип) веројатно ќе предизвика недефинирано однесување.
//
// FIXME(dlrobertson): Со цел да се користи VaArgSafe trait во јавен интерфејс, но исто така да се обезбеди дека не може да се користи на друго место, trait треба да биде јавен во приватниот модул.
// Откако ќе се спроведе RFC 2145, разгледајте го подобрувањето на ова.
//
//
//
//
mod sealed_trait {
    /// Trait што дозволува дозволените типови да се користат со [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Однапред на следниот аргумент.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Копира `va_list` на тековната локација.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // БЕЗБЕДНОСТ: му пишуваме на `MaybeUninit`, затоа тој е иницијализиран и `assume_init` е легален
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ова треба да се јави `va_end`, но нема чист начин за тоа
        // гарантира дека `drop` секогаш се вклопува во неговиот повикувач, така што `va_end` ќе се повика директно од истата функција како и соодветната `va_copy`.
        // `man va_end` наведува дека C го бара тоа, а LLVM во основа ја следи C семантиката, затоа треба да се осигураме дека `va_end` секогаш се повикува од истата функција како `va_copy`.
        //
        // За повеќе детали, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ова работи засега, бидејќи `va_end` е забранет пристап за сите тековни LLVM цели.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Уништете ја листата со аргументи `ap` по иницијализација со `va_start` или `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Ја копира моменталната локација на листата со аргументи `src` во листата на аргументи `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Вчитува аргумент од типот `T` од `va_list` `ap` и го зголемува аргументот `ap` кон кој покажува.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}