use crate::marker::Unsize;

/// Trait што означува дека ова е покажувач или обвивка за еден, каде што може да се изврши обемување на обединетиот.
///
/// Погледнете ги [DST coercion RFC][dst-coerce] и [the nomicon entry on coercion][nomicon-coerce] за повеќе детали.
///
/// За вградени типови на покажувачи, покажувачите на `T` ќе се принудат на покажувачите на `U` ако `T: Unsize<U>` со претворање од тенок покажувач во покажувач на маст.
///
/// За прилагодени типови, принудата тука работи со принудување на `Foo<T>` до `Foo<U>` доколку постои влијание на `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Таквиот поим може да се напише само ако `Foo<T>` има само едно поле нефантомодатоци со вклучено `T`.
/// Ако типот на тоа поле е `Bar<T>`, мора да постои имплементација на `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Принудата ќе работи со присилување на полето `Bar<T>` во `Bar<U>` и пополнување на останатите полиња од `Foo<T>` за да се создаде `Foo<U>`.
/// Ова ефикасно ќе вежба до полето за покажувач и ќе го присили тоа.
///
/// Општо, за паметните покажувачи ќе го имплементирате `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, со опционален `?Sized` врзан за самиот `T`.
/// За типови на обвивки кои директно вградуваат `T` како `Cell<T>` и `RefCell<T>`, можете директно да го имплементирате `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ова ќе овозможи принуди на типови како `Cell<Box<T>>` да работат.
///
/// [`Unsize`][unsize] се користи за обележување типови што можат да бидат принудени на DSTs ако стојат зад покажувачите.Се спроведува автоматски од компајлерот.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut Т-> &mut У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut Т-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut Т-> * мут У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut Т-> * состави У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * уст
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *мут Т->* мут У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ова се користи за безбедност на објектот, за да се провери дали типот на приемникот на методот може да биде испратен.
///
/// Пример за имплементација на trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut Т-> &mut У
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *мут Т->* мут У
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}