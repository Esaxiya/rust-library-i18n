/// Се користи за непроменливи операции за дереференцирање, како `*v`.
///
/// Покрај тоа што се користи за експлицитни операции за дереференцирање со операторот (unary) `*` во непроменливи контексти, `Deref` исто така се користи имплицитно од компајлерот во многу околности.
/// Овој механизам се нарекува ['`Deref` coercion'][more].
/// Во менливи контексти, се користи [`DerefMut`].
///
/// Спроведувањето на `Deref` за паметни покажувачи го прави удобен пристапот до податоците зад нив, поради што тие го имплементираат `Deref`.
/// Од друга страна, правилата во врска со `Deref` и [`DerefMut`] се дизајнирани специјално за прилагодување на паметни покажувачи.
/// Поради ова,**`Deref` треба да се спроведува само за паметни покажувачи** за да се избегне забуна.
///
/// Од слични причини,**овој trait никогаш не треба да пропадне**.Неуспехот за време на деференцирање може да биде крајно збунувачки кога имплицитно се повикува на `Deref`.
///
/// # Повеќе за присила `Deref`
///
/// Ако `T` спроведува `Deref<Target = U>`, а `x` е вредност од типот `T`, тогаш:
///
/// * Во непроменливи контексти, `*x` (каде `T` не е ниту референца ниту суров покажувач) е еквивалентен на `* Deref::deref(&x)`.
/// * Вредностите од типот `&T` се принудени на вредностите од типот `&U`
/// * `T` имплицитно ги спроведува сите методи (immutable) од типот `U`.
///
/// За повеќе детали, посетете ги [the chapter in *The Rust Programming Language*][book], како и референтните делови на [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура со единствено поле што е достапна со деференцирање на структурата.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Резултирачкиот тип по деференцирање.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Ја деференцира вредноста.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Се користи за операции за пренасочување на деференцирање, како во `*v = 1;`.
///
/// Покрај тоа што се користи за експлицитни операции за дереференцирање со операторот (unary) `*` во променливи контексти, `DerefMut` исто така се користи имплицитно од компајлерот во многу околности.
/// Овој механизам се нарекува ['`Deref` coercion'][more].
/// Во непроменливи контексти се користи [`Deref`].
///
/// Спроведувањето на `DerefMut` за паметни покажувачи го прави удобно мутирањето на податоците што стојат зад нив, поради што тие го спроведуваат `DerefMut`.
/// Од друга страна, правилата во врска со [`Deref`] и `DerefMut` се дизајнирани специјално за прилагодување на паметни покажувачи.
/// Поради ова,**`DerefMut` треба да се спроведува само за паметни покажувачи** за да се избегне забуна.
///
/// Од слични причини,**овој trait никогаш не треба да пропадне**.Неуспехот за време на деференцирање може да биде крајно збунувачки кога имплицитно се повикува на `DerefMut`.
///
/// # Повеќе за присила `Deref`
///
/// Ако `T` спроведува `DerefMut<Target = U>`, а `x` е вредност од типот `T`, тогаш:
///
/// * Во менливи контексти, `*x` (каде `T` не е ниту референца, ниту суров покажувач) е еквивалентен на `* DerefMut::deref_mut(&mut x)`.
/// * Вредностите од типот `&mut T` се принудени на вредностите од типот `&mut U`
/// * `T` имплицитно ги спроведува сите методи (mutable) од типот `U`.
///
/// За повеќе детали, посетете ги [the chapter in *The Rust Programming Language*][book], како и референтните делови на [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура со единствено поле што се менува со деференцирање на структурата.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Неспорно ја дереференцира вредноста.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Покажува дека структурата може да се користи како приемник на метод, без одликата `arbitrary_self_types`.
///
/// Ова е имплементирано од типовите на покажувачи на stdlib како `Box<T>`, `Rc<T>`, `&T` и `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}