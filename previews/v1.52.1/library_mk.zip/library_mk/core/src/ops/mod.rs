//! Преоптоварувачки оператори.
//!
//! Спроведувањето на овие traits ви овозможува да преоптоварувате одредени оператори.
//!
//! Некои од овие traits се увезени од prelude, така што тие се достапни во секоја програма Rust.Само операторите поддржани од traits можат да бидат преоптоварени.
//! На пример, операторот за додавање (`+`) може да биде преоптоварен преку [`Add`] trait, но бидејќи операторот за доделување (`=`) нема поддршка trait, не постои начин да се преоптовари неговата семантика.
//! Дополнително, овој модул не обезбедува никаков механизам за создавање нови оператори.
//! Ако се потребни преоптоварувања без својства или прилагодени оператори, треба да погледнете кон додатоците за макроа или компајлери за да ја проширите синтаксата на Rust.
//!
//! Имплементациите на операторот traits не треба да изненадуваат во нивните контексти, имајќи ги предвид нивните вообичаени значења и [operator precedence].
//! На пример, при спроведување на [`Mul`], операцијата треба да има некоја сличност со множењето (и да ги споделува очекуваните својства како асоцијативноста).
//!
//! Забележете дека краток спој на операторите `&&` и `||`, т.е. тие го проценуваат нивниот втор операнд само ако тоа придонесува за резултатот.Бидејќи ова однесување не е применливо од страна на traits, `&&` и `||` не се поддржани како преоптоварувачки оператори.
//!
//! Многу од операторите ги земаат своите операнди според вредноста.Во не-генерички контексти кои вклучуваат вградени типови, ова обично не претставува проблем.
//! Сепак, користењето на овие оператори во генерички код, бара извесно внимание, доколку вредностите треба да се користат повторно, за разлика од дозволувањето на операторите да ги трошат.Една опција е повремено да се користи [`clone`].
//! Друга опција е да се потпрете на видовите вклучени во обезбедувањето дополнителни оператори за имплементација на препораките.
//! На пример, за кориснички дефиниран тип `T` кој би требало да поддржува додавање, веројатно е добра идеја и `T` и `&T` да ги имплементираат traits [`Add<T>`][`Add`] и [`Add<&T>`][`Add`] така што генеричкиот код може да се напише без непотребно клонирање.
//!
//!
//! # Examples
//!
//! Овој пример создава структура `Point` што ги имплементира [`Add`] и [`Sub`], а потоа демонстрира собирање и одземање на две `Точки`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Погледнете ја документацијата за секој trait за примена на пример.
//!
//! [`Fn`], [`FnMut`] и [`FnOnce`] traits се имплементираат според типови што може да се повикаат како функции.Забележете дека [`Fn`] зема `&self`, [`FnMut`] зема `&mut self` и [`FnOnce`] зема `self`.
//! Овие одговараат на трите вида методи на кои може да се повикаме на пример: повик-по-референца, повик-по-менлив-повик и повик-по-вредност.
//! Најчестата употреба на овие traits е да дејствуваат како граници на функции на повисоко ниво што ги земаат функциите или затворањата како аргументи.
//!
//! Земајќи [`Fn`] како параметар:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Земајќи [`FnMut`] како параметар:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Земајќи [`FnOnce`] како параметар:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ги троши своите зафатени променливи, па затоа не може да се извршува повеќе од еднаш
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Обидот повторно да се повика `func()` ќе предизвика `use of moved value` грешка за `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` повеќе не може да се повикува во овој момент
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;