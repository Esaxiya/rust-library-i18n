/// trait за прилагодување на однесувањето на операторот `?`.
///
/// Тип кој го спроведува `Try` е оној што има канонски начин да го види во смисла на дихотомија на success/failure.
/// Овој trait овозможува и извлекување на тие вредности на успех или неуспех од постоечка инстанца и креирање на нова инстанца од вредност на успех или неуспех.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Вид на оваа вредност кога се гледа како успешна.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Вид на оваа вредност кога се гледа како неуспешен.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Го применува операторот "?".Враќањето на `Ok(t)` значи дека извршувањето треба да продолжи нормално, а резултатот на `?` е вредноста `t`.
    /// Враќањето на `Err(e)` значи дека извршувањето треба да биде branch до внатрешното затворено `catch` или да се врати од функцијата.
    ///
    /// Ако се врати резултат `Err(e)`, вредноста `e` ќе биде "wrapped" во типот на враќање на опсегот на затворање (што самиот мора да го имплементира `Try`).
    ///
    /// Поточно, се враќа вредноста `X::from_error(From::from(e))`, каде што `X` е повратен тип на функцијата за затворање.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Завиткајте вредност на грешка за да го конструирате композитниот резултат.
    /// На пример, `Result::Err(x)` и `Result::from_error(x)` се еквивалентни.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Завиткајте ОК вредност за да го конструирате композитниот резултат.
    /// На пример, `Result::Ok(x)` и `Result::from_ok(x)` се еквивалентни.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}