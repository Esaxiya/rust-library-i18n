/// Верзијата на операторот за повик што зема непроменлив приемник.
///
/// Инстанците од `Fn` може да се повикуваат постојано без состојба на мутација.
///
/// *Овој trait (`Fn`) не треба да се меша со [function pointers] (`fn`).*
///
/// `Fn` се спроведува автоматски со затворања кои земаат само непроменливи референци на зафатените променливи или не зафаќаат ништо, како и (safe) [function pointers] (со некои предупредувања, видете ја нивната документација за повеќе детали).
///
/// Дополнително, за кој било тип `F` што спроведува `Fn`, `&F` исто така спроведува `Fn`.
///
/// Бидејќи и [`FnMut`] и [`FnOnce`] се супертратити на `Fn`, секоја инстанца на `Fn` може да се користи како параметар каде што се очекува [`FnMut`] или [`FnOnce`].
///
/// Користете `Fn` како врзана кога сакате да прифатите параметар од типот на функција и треба да го повикувате постојано и без состојба на мутација (на пр., Кога го повикувате истовремено).
/// Ако не ви требаат толку строги барања, користете [`FnMut`] или [`FnOnce`] како граници.
///
/// Погледнете го [chapter on closures in *The Rust Programming Language*][book] за повеќе информации на оваа тема.
///
/// Забелешка е и специјалната синтакса за `Fn` traits (на пр
/// `Fn(usize, bool) -> употреби`).Заинтересираните за техничките детали за ова можат да се обратат на [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Повикувајќи затворање
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Користење на параметар `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така што regex може да се потпре на тој `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Врши операција за повик.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Верзијата на операторот за повик што зема применлив приемник.
///
/// Инстанци од `FnMut` може да се повикуваат постојано и може да мутираат.
///
/// `FnMut` се имплементира автоматски со затворања кои земаат непроменливи референци на зафатените променливи, како и сите типови што спроведуваат [`Fn`], на пример, (safe) [function pointers] (бидејќи `FnMut` е супер-теснец на [`Fn`]).
/// Дополнително, за кој било тип `F` што спроведува `FnMut`, `&mut F` исто така спроведува `FnMut`.
///
/// Бидејќи [`FnOnce`] е супертрет на `FnMut`, секоја инстанца на `FnMut` може да се користи онаму каде што се очекува [`FnOnce`] и бидејќи [`Fn`] е подотрес на `FnMut`, може да се користи било која инстанца на [`Fn`] каде што се очекува `FnMut`.
///
/// Користете `FnMut` како врзана кога сакате да прифатите параметар од типот на функција и треба постојано да го повикувате, дозволувајќи му да мутира.
/// Ако не сакате параметарот да мутира состојба, користете [`Fn`] како врзана;ако не треба постојано да го повикувате, користете [`FnOnce`].
///
/// Погледнете го [chapter on closures in *The Rust Programming Language*][book] за повеќе информации на оваа тема.
///
/// Забелешка е и специјалната синтакса за `Fn` traits (на пр
/// `Fn(usize, bool) -> употреби`).Заинтересираните за техничките детали за ова можат да се обратат на [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Повикување на немирно зафаќање на затворање
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Користење на параметар `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така што regex може да се потпре на тој `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Врши операција за повик.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Верзијата на операторот на повик што зема приемник на нус-вредност.
///
/// Може да се повикаат случаи на `FnOnce`, но може да не се повикуваат повеќе пати.Поради ова, ако единственото нешто што се знае за еден вид е дека тој спроведува `FnOnce`, може да се повика само еднаш.
///
/// `FnOnce` се спроведува автоматски со затворање што може да троши зафатени променливи, како и сите типови што спроведуваат [`FnMut`], на пример, (safe) [function pointers] (бидејќи `FnOnce` е супертрет на [`FnMut`]).
///
///
/// Бидејќи и [`Fn`] и [`FnMut`] се подотреси на `FnOnce`, секоја инстанца на [`Fn`] или [`FnMut`] може да се користи таму каде што се очекува `FnOnce`.
///
/// Користете `FnOnce` како врзана кога сакате да прифатите параметар од типот на функција и треба да го повикате само еднаш.
/// Ако треба постојано да го повикувате параметарот, користете [`FnMut`] како врзана;ако исто така ви треба за да не мутирате состојба, користете [`Fn`].
///
/// Погледнете го [chapter on closures in *The Rust Programming Language*][book] за повеќе информации на оваа тема.
///
/// Забелешка е и специјалната синтакса за `Fn` traits (на пр
/// `Fn(usize, bool) -> употреби`).Заинтересираните за техничките детали за ова можат да се обратат на [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Користење на параметар `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ги троши своите зафатени променливи, па затоа не може да се извршува повеќе од еднаш.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Обидот повторно да се повика `func()` ќе предизвика `use of moved value` грешка за `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` повеќе не може да се повикува во овој момент
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така што regex може да се потпре на тој `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Вратен тип откако ќе се користи операторот за повик.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Врши операција за повик.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}