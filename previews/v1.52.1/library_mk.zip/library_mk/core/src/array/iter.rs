//! Го дефинира повторувачот за низи во сопственост на `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Повреднувач [array] според вредноста.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ова е низата што ја повторуваме.
    ///
    /// Елементи со индекс `i` каде `alive.start <= i < alive.end` сè уште не се дадени и се валидни записи во низата.
    /// Елементите со индекси `i < alive.start` или `i >= alive.end` се веќе дадени и не смее да се пристапува повеќе!Тие мртви елементи може да бидат дури и во целосно уницијализирана состојба!
    ///
    ///
    /// Значи, инваријантите се:
    /// - `data[alive]` е жив (т.е. содржи валидни елементи)
    /// - `data[..alive.start]` и `data[alive.end..]` се мртви (т.е. елементите се веќе прочитани и не смеат да се допираат повеќе!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Елементите во `data` кои сè уште не се дадени.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Создава нов повторувач над дадениот `array`.
    ///
    /// *Белешка*: овој метод може да биде амортизиран во future, по [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Типот на `value` е `i32` тука, наместо `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕЗБЕДНОСТ: Прекинот тука е всушност безбеден.Документи на `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` се гарантира дека имаат иста големина и порамнување
        // > како `T`.
        //
        // Документите дури покажуваат трансмут од низа `MaybeUninit<T>` во низа `T`.
        //
        //
        // Со тоа, оваа иницијализација ги задоволува инваријантите.

        // FIXME(LukasKalbertodt): всушност користете `mem::transmute` овде, откако ќе работи со генерики на конституирање:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Дотогаш, можеме да го користиме `mem::transmute_copy` да создадеме бит-копија како различен тип, а потоа да заборавиме на `array` за да не се испушти.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Враќа непроменлива парче од сите елементи што сè уште не се дадени.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕЗБЕДНОСТ: Знаеме дека сите елементи во `alive` се правилно иницијализирани.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Враќа променлива парче од сите елементи што сè уште не се дадени.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕЗБЕДНОСТ: Знаеме дека сите елементи во `alive` се правилно иницијализирани.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Добијте го следниот индекс од напред.
        //
        // Зголемувањето на `alive.start` за 1 ја одржува непроменетата во однос на `alive`.
        // Сепак, заради оваа промена, за кратко време, живата зона повеќе не е `data[alive]`, туку `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Прочитајте го елементот од низата.
            // БЕЗБЕДНОСТ: `idx` е индекс во поранешниот регион "alive" на
            // низаЧитањето на овој елемент значи дека `data[idx]` се смета за мртов сега (т.е. не допирајте).
            // Бидејќи `idx` беше почеток на живата зона, живата зона сега е повторно `data[alive]`, враќајќи ги сите инваријанти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Добијте го следниот индекс од задната страна.
        //
        // Намалувањето на `alive.end` за 1 ја одржува непроменливата во однос на `alive`.
        // Сепак, заради оваа промена, за кратко време, живата зона повеќе не е `data[alive]`, туку `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Прочитајте го елементот од низата.
            // БЕЗБЕДНОСТ: `idx` е индекс во поранешниот регион "alive" на
            // низаЧитањето на овој елемент значи дека `data[idx]` се смета за мртов сега (т.е. не допирајте).
            // Бидејќи `idx` беше крајот на живата зона, живата зона сега е повторно `data[alive]`, враќајќи ги сите инваријанти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕЗБЕДНОСТ: Ова е безбедно: `as_mut_slice` го враќа точно под-парчето
        // на елементи што сè уште не се поместени и остануваат да се исфрлат.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Никогаш нема да прелее поради непроменливиот `жив.почеток <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итераторот навистина ја известува точната должина.
// Бројот на елементи "alive" (што сепак ќе се даде) е должината на опсегот `alive`.
// Овој опсег е намален во должина или во `next` или `next_back`.
// Секогаш се намалува за 1 во тие методи, но само ако се врати `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Забележете, ние навистина не треба да одговараме на истиот ист жив опсег, така што можеме само да клонираме во офсет 0, без оглед каде е `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонирајте ги сите живи елементи.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Напишете клон во новата низа, а потоа ажурирајте го неговиот жив опсег.
            // Ако клонираме panics, правилно ќе ги исфрлиме претходните ставки.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Само отпечатете ги елементите што сè уште не биле дадени: не можеме да пристапиме повеќе до дадените елементи.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}