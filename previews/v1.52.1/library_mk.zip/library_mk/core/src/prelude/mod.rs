//! Либкор prelude
//!
//! Овој модул е наменет за корисници на libcore кои исто така не водат до libstd.
//! Овој модул се увезува по дифолт кога се користи `#![no_std]` на ист начин како и prelude на стандардната библиотека.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Верзијата на јадрото prelude од 2015 година.
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Верзија за јадрото prelude во 2018 година.
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Верзијата на јадрото prelude од 2021 година.
///
/// Погледнете го [module-level documentation](self) за повеќе.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Додадете повеќе работи.
}