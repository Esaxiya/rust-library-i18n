//! Panic поддршка за libcore
//!
//! Основната библиотека не може да дефинира паника, но *изјавува* паника.
//! Ова значи дека функциите во внатрешноста на libcore се дозволени на panic, но за да биде корисно, возводно crate мора да дефинира паника за употреба на libcore.
//! Тековниот интерфејс за паника е:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Оваа дефиниција дозволува паника со која било општа порака, но не дозволува неуспех со вредност `Box<Any>`.
//! (`PanicInfo` само содржи `&(dyn Any + Send)`, за што ја пополнуваме атарот во " PanicInfo: : internal_constructor`.) Причината за ова е што не е дозволено да се распределува libcore.
//!
//!
//! Овој модул содржи неколку други функции за паника, но ова се само потребните елементи за компајлерот.Сите panics се насочуваат преку оваа една функција.
//! Вистинскиот симбол се декларира преку атрибутот `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Основната имплементација на макро `panic!` на libcore кога не се користи форматирање.
#[cold]
// никогаш не се вметнувај освен ако не panic_immediate_abort за да се избегне надуеност на кодот на страниците за повик што е можно повеќе
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // потребни на кодегенот за panic при прелевање и други `Assert` MIR терминатори
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Користете Arguments::new_v1 наместо format_args! ("{}", Expr) за потенцијално намалување на големината над глава.
    // Форматот_аргови!макро користи str's Display trait за да напише expr, кој повикува на Formatter::pad, што мора да приспособи скратување и полнење на низата (иако тука не се користи ниту еден).
    //
    // Користењето на Arguments::new_v1 може да дозволи компајлерот да го изостави Formatter::pad од бинарниот излез, заштедувајќи до неколку килобајти.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // потребни за конституирана panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // потребен од кодегенот за пристап до OOB array/slice за panic
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Основната имплементација на макро `panic!` на libcore кога се користи форматирање.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ЗАБЕЛЕШКА Оваа функција никогаш не ја преминува границата на FFI;тоа е повик Rust-to-Rust кој се решава на функцијата `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // БЕЗБЕДНОСТ: `panic_impl` е дефиниран во безбеден код Rust и затоа е безбедно да се повика.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Внатрешна функција за макроата `assert_eq!` и `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}