use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тип на обвивка за да се конструираат неницијализирани примери на `T`.
///
/// # Непроменлива иницијализација
///
/// Компајлерот, генерално, претпоставува дека променливата е правилно иницијализирана според барањата од типот на променливата.На пример, променлива од референтен тип мора да биде порамнета и да не е НУПЛИНА.
/// Ова е непроменлива, која мора *секогаш* да се прифати, дури и во небезбеден код.
/// Како последица на тоа, нула иницијализирање на променлива од референтен тип предизвикува моментален [undefined behavior][ub], без разлика дали таа референца некогаш се користи за пристап до меморијата:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // недефинирано однесување!⚠️
/// // Еквивалентен код со `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // недефинирано однесување!⚠️
/// ```
///
/// Компајлерот го искористува ова за разни оптимизации, како што се проверки на времетраењето и оптимизирање на изгледот на `enum`.
///
/// Слично на тоа, целосно непочетната меморија може да има каква било содржина, додека `bool` секогаш мора да биде `true` или `false`.Оттука, создавањето на неницијализирано `bool` е недефинирано однесување:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // недефинирано однесување!⚠️
/// // Еквивалентен код со `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // недефинирано однесување!⚠️
/// ```
///
/// Покрај тоа, неиницијализираната меморија е посебна по тоа што нема фиксна вредност ("fixed" значи "it won't change without being written to").Читањето на истиот неинцијализиран бајт повеќе пати може да даде различни резултати.
/// Ова го прави недефинирано однесување да има уницијализирани податоци во променлива, дури и ако таа променлива има цел број, што инаку може да собере каква било фиксна * битна шема:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // недефинирано однесување!⚠️
/// // Еквивалентен код со `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // недефинирано однесување!⚠️
/// ```
/// (Забележете дека правилата околу уницијализираните цели броеви сè уште не се финализирани, но се додека не се направат, препорачливо е да ги избегнувате.)
///
/// Згора на тоа, запомнете дека повеќето типови имаат дополнителни инваријанти, освен што се сметаат за иницијализирани на ниво на тип.
/// На пример, иницијализиран [`Vec<T>`] со `1` се смета за иницијализиран (според сегашната имплементација; ова не претставува стабилна гаранција) затоа што единственото барање што компајлерот го знае за тоа е покажувачот на податоците да не е ништовен.
/// Создавањето таков `Vec<T>` не предизвикува *непосредно* недефинирано однесување, но ќе предизвика недефинирано однесување со повеќето безбедни операции (вклучително и испуштање).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служи за овозможување на небезбеден код за справување со неницијализирани податоци.
/// Тоа е сигнал до компајлерот што покажува дека податоците овде можеби *не* се иницијализираат:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Создадете експлицитно неиницијализирана референца.
/// // Компајлерот знае дека податоците во `MaybeUninit<T>` може да бидат невалидни, и затоа ова не е UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Поставете ја на валидна вредност.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Извлечете ги иницијализираните податоци-ова е дозволено само *по* правилно иницијализирање на `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Компајлерот тогаш знае да не прави неправилни претпоставки или оптимизации на овој код.
///
/// Можете да помислите на `MaybeUninit<T>` како малку како `Option<T>`, но без никакво следење на времето и без никакви безбедносни проверки.
///
/// ## out-pointers
///
/// Можете да користите `MaybeUninit<T>` за да го имплементирате "out-pointers": наместо да враќате податоци од функција, пренесете му покажувач на некоја меморија (uninitialized) за да го ставите резултатот.
/// Ова може да биде корисно кога е важно за повикувачот да контролира како се распределува меморијата во која е зачувана резултатот и сакате да избегнете непотребни потези.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не ја испушта старата содржина, што е важно.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Сега знаеме дека `v` е иницијализиран!Ова исто така осигурува дека vector правилно паѓа.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Иницијализирање на низата елемент по елемент
///
/// `MaybeUninit<T>` може да се користи за иницијализирање на голем низа елемент-по-елемент:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Создадете уницијализирана низа `MaybeUninit`.
///     // `assume_init` е безбеден затоа што типот за кој тврдиме дека го иницијализиравме овде е еден куп `Можеби Uninit`, за кои не е потребна иницијализација.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Паѓањето на `MaybeUninit` не прави ништо.
///     // Така, користењето на необработена задача на покажувачот наместо `ptr::write` не предизвикува паѓање на старата неницијализирана вредност.
/////
///     // Исто така, ако има panic за време на оваа јамка, имаме истекување на меморија, но нема проблем со безбедноста на меморијата.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Сè е иницијализирано.
///     // Префрлете ја низата во иницијализираниот тип.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Можете исто така да работите со делумно иницијализирани низи, што може да се најдат во структури на податоци со ниско ниво.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Создадете уницијализирана низа `MaybeUninit`.
/// // `assume_init` е безбеден затоа што типот за кој тврдиме дека го иницијализиравме овде е еден куп `Можеби Uninit`, за кои не е потребна иницијализација.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Пресметајте го бројот на елементи што ги доделивме.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // За секоја ставка во низата, паѓајте ако ја распределиме.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Иницијализирање на структура поле-по-поле
///
/// Може да користите `MaybeUninit<T>` и макро [`std::ptr::addr_of_mut`] за да ги иницијализирате ударите поле по поле:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Иницијализирање на полето `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Иницијализирање на полето `list` Ако тука има panic, тогаш протекува `String` во полето `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Сите полиња се иницијализирани, затоа се јавуваме во `assume_init` за да добиеме почетен Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` се гарантира дека има иста големина, усогласеност и ABI како `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Сепак запомнете дека типот *што содржи*`MaybeUninit<T>` не е нужно истиот распоред;Rust воопшто не гарантира дека полињата на `Foo<T>` имаат ист редослед како `Foo<U>` дури и ако `T` и `U` имаат иста големина и порамнување.
///
/// Понатаму, бидејќи која било битна вредност е валидна за `MaybeUninit<T>`, компајлерот не може да примени оптимизации за non-zero/niche-filling, што потенцијално резултира со поголема големина:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ако `T` е безбеден FFI, тогаш тоа е и `MaybeUninit<T>`.
///
/// Додека `MaybeUninit` е `#[repr(transparent)]` (што покажува дека гарантира иста големина, усогласеност и ABI како `T`), ова *не* менува ниту едно од претходните предупредувања.
/// `Option<T>` и `Option<MaybeUninit<T>>` сè уште може да имаат различни големини, а типовите што содржат поле од типот `T` може да бидат поставени (и со големина) поинаку отколку ако тоа поле е `MaybeUninit<T>`.
/// `MaybeUninit` е синдикален тип, а `#[repr(transparent)]` на синдикатите е нестабилен (види [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Со текот на времето, точните гаранции на `#[repr(transparent)]` за синдикатите може да се развијат, а `MaybeUninit` може или не останува `#[repr(transparent)]`.
/// Со тоа, `MaybeUninit<T>`*секогаш* ќе гарантира дека има иста големина, порамнување и ABI како `T`;едноставно, начинот на кој `MaybeUninit` ја спроведува таа гаранција може да се развива.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Ланг ставка за да можеме да завиткаме и други видови во неа.Ова е корисно за генераторите.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не повикувајќи се на `T::clone()`, не можеме да знаеме дали сме доволно иницијализирани за тоа.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Создава нов `MaybeUninit<T>` иницијализиран со дадената вредност.
    /// Безбедно е да се јавите на [`assume_init`] на повратната вредност на оваа функција.
    ///
    /// Забележете дека паѓањето на `MaybeUninit<T>` никогаш нема да го повика кодот за паѓање на `T`.
    /// Ваша одговорност е да бидете сигурни дека `T` ќе падне ако е иницијализиран.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Создава нов `MaybeUninit<T>` во неиницијализирана состојба.
    ///
    /// Забележете дека паѓањето на `MaybeUninit<T>` никогаш нема да го повика кодот за паѓање на `T`.
    /// Ваша одговорност е да бидете сигурни дека `T` ќе падне ако е иницијализиран.
    ///
    /// Погледнете го [type-level documentation][MaybeUninit] за неколку примери.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Создадете нова низа `MaybeUninit<T>` ставки, во неницијализирана состојба.
    ///
    /// Note: во верзијата future Rust овој метод може да стане непотребен кога буква синтаксата на низата дозволува [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Примерот подолу може да користи `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Враќа (евентуално помала) парче податоци што всушност биле прочитани
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕЗБЕДНОСТ: Важечки е неинцијализиран `[MaybeUninit<_>; LEN]`.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Создава нов `MaybeUninit<T>` во неиницијализирана состојба, со тоа што меморијата се полни со `0` бајти.Од `T` зависи дали тоа веќе правилно правилно иницијализирање.
    ///
    /// На пример, `MaybeUninit<usize>::zeroed()` е иницијализиран, но `MaybeUninit<&'static i32>::zeroed()` не е затоа што референците не смеат да бидат ништовни.
    ///
    /// Забележете дека паѓањето на `MaybeUninit<T>` никогаш нема да го повика кодот за паѓање на `T`.
    /// Ваша одговорност е да бидете сигурни дека `T` ќе падне ако е иницијализиран.
    ///
    /// # Example
    ///
    /// Точна употреба на оваа функција: иницијализирање на структура со нула, каде што сите полиња на структурата можат да ја задржат бит-моделот 0 како валидна вредност.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Неточна* употреба на оваа функција: повикувањето на `x.zeroed().assume_init()` кога `0` не е валидна бит-шема за типот:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Внатре во пар, ние создаваме `NotZero` што нема валиден дискриминант.
    /// // Ова е недефинирано однесување.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕЗБЕДНОСТ: `u.as_mut_ptr()` поени на доделената меморија.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ја поставува вредноста на `MaybeUninit<T>`.
    /// Ова ја пребришува претходната вредност без да ја испушти, па затоа внимавајте да не ја користите двапати освен ако не сакате да го прескокнете активирањето на деструкторот.
    ///
    /// За ваша погодност, ова исто така враќа непроменлива референца за (сега безбедно иницијализираната) содржина на `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕЗБЕДНОСТ: Само што ја иницијализиравме оваа вредност.
        unsafe { self.assume_init_mut() }
    }

    /// Добива покажувач до содржаната вредност.
    /// Читањето од овој покажувач или претворање во референца е недефинирано однесување, освен ако не се иницијализира `MaybeUninit<T>`.
    /// Пишувањето на меморијата кон кое покажува овој покажувач (non-transitively) е недефинирано однесување (освен во `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Точна употреба на овој метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Создадете упатство за `MaybeUninit<T>`.Ова е во ред затоа што го иницијализиравме.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Неточна* употреба на овој метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Создадовме упатување на неинцијализиран vector!Ова е недефинирано однесување.⚠️
    /// ```
    ///
    /// (Забележете дека правилата околу упатувањето на неинцијализирани податоци сè уште не се финализирани, но се додека не се направат, препорачливо е да ги избегнувате.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` и `ManuallyDrop` се и `repr(transparent)` за да можеме да го фрлиме покажувачот.
        self as *const _ as *const T
    }

    /// Добива неспокоен покажувач до содржаната вредност.
    /// Читањето од овој покажувач или претворање во референца е недефинирано однесување, освен ако не се иницијализира `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Точна употреба на овој метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Создадете упатство за `MaybeUninit<Vec<u32>>`.
    /// // Ова е во ред затоа што го иницијализиравме.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Неточна* употреба на овој метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Создадовме упатување на неинцијализиран vector!Ова е недефинирано однесување.⚠️
    /// ```
    ///
    /// (Забележете дека правилата околу упатувањето на неинцијализирани податоци сè уште не се финализирани, но се додека не се направат, препорачливо е да ги избегнувате.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` и `ManuallyDrop` се и `repr(transparent)` за да можеме да го фрлиме покажувачот.
        self as *mut _ as *mut T
    }

    /// Ја вади вредноста од контејнерот `MaybeUninit<T>`.Ова е одличен начин да се осигурате дека податоците ќе паднат, бидејќи добиениот `T` е предмет на вообичаено ракување со падот.
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека `MaybeUninit<T>` навистина е во почетна состојба.Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува непосредно недефинирано однесување.
    /// [type-level documentation][inv] содржи повеќе информации за оваа непроменлива иницијализација.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Згора на тоа, запомнете дека повеќето типови имаат дополнителни инваријанти, освен што се сметаат за иницијализирани на ниво на тип.
    /// На пример, иницијализиран [`Vec<T>`] со `1` се смета за иницијализиран (според сегашната имплементација; ова не претставува стабилна гаранција) затоа што единственото барање што компајлерот го знае за тоа е покажувачот на податоците да не е ништовен.
    ///
    /// Создавањето таков `Vec<T>` не предизвикува *непосредно* недефинирано однесување, но ќе предизвика недефинирано однесување со повеќето безбедни операции (вклучително и испуштање).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Точна употреба на овој метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Неточна* употреба на овој метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` сè уште не беше иницијализирана, така што оваа последна линија предизвика недефинирано однесување.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` е иницијализиран.
        // Ова исто така значи дека `self` мора да биде варијанта `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Ја чита вредноста од контејнерот `MaybeUninit<T>`.Резултирачкиот `T` е предмет на вообичаено ракување со пад.
    ///
    /// Секогаш кога е можно, подобро е да се користи [`assume_init`] наместо тоа, што спречува дуплирање на содржината на `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека `MaybeUninit<T>` навистина е во почетна состојба.Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува недефинирано однесување.
    /// [type-level documentation][inv] содржи повеќе информации за оваа непроменлива иницијализација.
    ///
    /// Покрај тоа, ова остава копија од истите податоци зад себе во `MaybeUninit<T>`.
    /// Кога користите повеќе копии на податоците (повикувајќи `assume_init_read` повеќе пати, или прво повикувајќи `assume_init_read`, а потоа [`assume_init`]), ваша одговорност е да осигурате дека тие податоци навистина можат да бидат дуплирани.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Точна употреба на овој метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` е `Copy`, па може да читаме повеќе пати.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Удвојувањето на `None` вредност е во ред, па може да читаме повеќе пати.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Неточна* употреба на овој метод:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Сега создадовме две копии од истиот vector, што доведува до двојно бесплатно ⚠️ кога и двајцата ќе паднат!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` е иницијализиран.
        // Читањето од `self.as_ptr()` е безбедно бидејќи `self` треба да биде иницијализиран.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Ја испуштате содржаната вредност на место.
    ///
    /// Ако имате сопственост на `MaybeUninit`, наместо тоа можете да го користите [`assume_init`].
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека `MaybeUninit<T>` навистина е во почетна состојба.Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува недефинирано однесување.
    ///
    /// Згора на тоа, сите дополнителни инваријанти од типот `T` мора да бидат задоволни, бидејќи `Drop` имплементацијата на `T` (или неговите членови) може да се потпре на ова.
    /// На пример, иницијализиран [`Vec<T>`] со `1` се смета за иницијализиран (според сегашната имплементација; ова не претставува стабилна гаранција) затоа што единственото барање што компајлерот го знае за тоа е покажувачот на податоците да не е ништовен.
    ///
    /// Паѓањето на таков `Vec<T>` сепак ќе предизвика недефинирано однесување.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` е иницијализиран и
        // ги задоволува сите инваријанти на `T`.
        // Паѓањето на вредноста на место е безбедно, ако тоа е случај.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Добива споделена референца за содржаната вредност.
    ///
    /// Ова може да биде корисно кога сакаме да пристапиме до `MaybeUninit` што е иницијализиран, но немаме сопственост на `MaybeUninit` (спречувајќи употреба на `.assume_init()`)).
    ///
    /// # Safety
    ///
    /// Повикувањето на ова кога содржината сè уште не е иницијализирана целосно, предизвикува недефинирано однесување: останува на повикувачот да гарантира дека `MaybeUninit<T>` навистина е во почетна состојба.
    ///
    ///
    /// # Examples
    ///
    /// ### Точна употреба на овој метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Иницијализирајте го `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Сега кога се знае дека е иницијализиран нашиот `MaybeUninit<_>`, во ред е да креираме заедничка референца за тоа:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕЗБЕДНОСТ: `x` е иницијализиран.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Неточни* употреби на овој метод:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Создадовме упатување на неинцијализиран vector!Ова е недефинирано однесување.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Иницијализирајте го `MaybeUninit` користејќи `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Упатување на неиницијализирано `Cell<bool>`: УБ!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` е иницијализиран.
        // Ова исто така значи дека `self` мора да биде варијанта `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Добива неспокоен (unique) повик за содржаната вредност.
    ///
    /// Ова може да биде корисно кога сакаме да пристапиме до `MaybeUninit` што е иницијализиран, но немаме сопственост на `MaybeUninit` (спречувајќи употреба на `.assume_init()`)).
    ///
    /// # Safety
    ///
    /// Повикувањето на ова кога содржината сè уште не е иницијализирана целосно, предизвикува недефинирано однесување: останува на повикувачот да гарантира дека `MaybeUninit<T>` навистина е во почетна состојба.
    /// На пример, `.assume_init_mut()` не може да се користи за иницијализирање на `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Точна употреба на овој метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Иницијализира *сите* бајти од влезниот тампон.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Иницијализирајте го `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Сега знаеме дека `buf` е иницијализиран, така што можеме да го `.assume_init()` го направиме.
    /// // Сепак, користењето `.assume_init()` може да предизвика `memcpy` од 2048 бајти.
    /// // За да тврдиме дека нашиот тампон е иницијализиран без да го копираме, ние го надградуваме `&mut MaybeUninit<[u8; 2048]>` на `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕЗБЕДНОСТ: `buf` е иницијализиран.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Сега можеме да го користиме `buf` како нормално парче:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Неточни* употреби на овој метод:
    ///
    /// Не можете да користите `.assume_init_mut()` за да иницирате вредност:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Создадовме референца (mutable) на неуницијализирана `bool`!
    ///     // Ова е недефинирано однесување.⚠️
    /// }
    /// ```
    ///
    /// На пример, не можете да го [`Read`] во уницијализиран тампон:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) упатување на неинцијализирана меморија!
    ///                             // Ова е недефинирано однесување.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ниту, пак, можете да користите директен пристап до полето за да направите постепено иницијализирање поле-по-поле:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) упатување на неинцијализирана меморија!
    ///                  // Ова е недефинирано однесување.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) упатување на неинцијализирана меморија!
    ///                  // Ова е недефинирано однесување.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Во моментов се потпираме дека горенаведеното е неточно, т.е. се повикуваме на неницијализирани податоци (на пример, во `libcore/fmt/float.rs`).
    // Треба да донесеме конечна одлука за правилата пред стабилизирање.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `self` е иницијализиран.
        // Ова исто така значи дека `self` мора да биде варијанта `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Ги извлекува вредностите од низа контејнери `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека сите елементи на низата се во иницијализирана состојба.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЕЗБЕДНОСТ: Сега безбедно како што ги иницијализиравме сите елементи
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Повикувачот гарантира дека сите елементи на низата се иницијализирани
        // * `MaybeUninit<T>` и Т се гарантира дека имаат ист распоред
        // * МожебиUnint не паѓа, така што нема двојно ослободување и така, реализацијата е безбедна
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Под претпоставка дека сите елементи се иницијализирани, земете парче до нив.
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека елементите `MaybeUninit<T>` навистина се во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува недефинирано однесување.
    ///
    /// Погледнете [`assume_init_ref`] за повеќе детали и примери.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕЗБЕДНОСТ: фрлање парче на `*const [T]` е безбедно бидејќи повикувачот го гарантира тоа
        // `slice` е иницијализирана, и `МожебиUninit` е гарантирано да го има истиот распоред како `T`.
        // Добиениот покажувач е валиден бидејќи се однесува на меморија во сопственост на `slice`, што е референца и со тоа се гарантира дека е валиден за читање.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Под претпоставка дека сите елементи се иницијализирани, набавете им некакво променливо парче.
    ///
    /// # Safety
    ///
    /// Останува на повикувачот да гарантира дека елементите `MaybeUninit<T>` навистина се во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува недефинирано однесување.
    ///
    /// Погледнете [`assume_init_mut`] за повеќе детали и примери.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕЗБЕДНОСТ: слично на безбедносните белешки за `slice_get_ref`, но имаме
        // непроменлива референца, која исто така е загарантирана дека е валидна за пишување.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Добива покажувач до првиот елемент од низата.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Добива непроменлив покажувач до првиот елемент од низата.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ги копира елементите од `src` до `this`, враќајќи ја неспокојната референца на сега иницијализираната содржина на `this`.
    ///
    /// Ако `T` не спроведува `Copy`, користете [`write_slice_cloned`]
    ///
    /// Ова е слично на [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Оваа функција ќе биде panic ако двете парчиња имаат различни должини.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗБЕДНОСТ: само ги копиравме сите елементи на лени во резервниот капацитет
    /// // првите src.len() елементи на vec важат сега.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕЗБЕДНОСТ: &[T] и&[Можеби Унинит<T>] имаат ист распоред
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕЗБЕДНОСТ: Валидни елементи штотуку се копирани во `this`, така што се иницијализира
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Ги клонира елементите од `src` до `this`, враќајќи мутабилна референца на сега иницијализираната содржина на `this`.
    /// Сите веќе иницијализирани елементи нема да бидат исфрлени.
    ///
    /// Ако `T` спроведува `Copy`, користете [`write_slice`]
    ///
    /// Ова е слично на [`slice::clone_from_slice`], но не ги испушта постојните елементи.
    ///
    /// # Panics
    ///
    /// Оваа функција ќе биде panic ако двете парчиња имаат различна должина или ако е имплементирана `Clone` panics.
    ///
    /// Ако има panic, веќе клонираните елементи ќе бидат исфрлени.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗБЕДНОСТ: само што ги клониравме сите елементи на лене во резервниот капацитет
    /// // првите src.len() елементи на vec важат сега.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // за разлика од copy_from_slice ова не повикува clone_from_slice на парчето ова е затоа што `MaybeUninit<T: Clone>` не го спроведува Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕЗБЕДНОСТ: ова сурово парче ќе содржи само иницијализирани предмети
                // затоа е дозволено да се испушти.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Треба експлицитно да ги исечеме на иста должина
        // за проверка на границите да се отстрани, а оптимизаторот ќе генерира memcpy за едноставни случаи (на пример T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // потребен е чувар b/c panic може да се случи за време на клон
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕЗБЕДНОСТ: Валидни елементи штотуку се запишани во `this`, така што се иницијализира
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}