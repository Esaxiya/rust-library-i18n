use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Обвивка за инхибиција на компајлерот автоматски да го нарекува уништувачот на `T`.
/// Оваа обвивка е 0-цена.
///
/// `ManuallyDrop<T>` е предмет на истата оптимизација на изгледот како `T`.
/// Како последица на тоа, тој нема *никакво влијание* врз претпоставките што ги прави компајлерот за неговата содржина.
/// На пример, иницијализирање на `ManuallyDrop<&mut T>` со [`mem::zeroed`] е недефинирано однесување.
/// Ако треба да ракувате со неницијализирани податоци, наместо тоа, користете [`MaybeUninit<T>`].
///
/// Забележете дека пристапот до вредноста во `ManuallyDrop<T>` е безбеден.
/// Ова значи дека `ManuallyDrop<T>` чија содржина е исфрлена не смее да се изложува преку јавен безбеден API.
/// Соодветно, `ManuallyDrop::drop` е небезбеден.
///
/// # `ManuallyDrop` и да се намали редоследот.
///
/// Rust има добро дефиниран [drop order] вредности.
/// За да бидете сигурни дека полињата или локалното население се исфрлени по одреден редослед, прередете ги декларациите така што имплицитниот редослед за пад е точен.
///
/// Можно е да се користи `ManuallyDrop` за да се контролира редоследот на паѓање, но ова бара небезбеден код и тешко е да се направи правилно во присуство на одвиткување.
///
///
/// На пример, ако сакате да бидете сигурни дека одредено поле е исфрлено по другите, направете го последното поле на структурата:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ќе бидат отфрлени по `children`.
///     // Rust гарантира дека полињата ќе бидат исфрлени по редоследот на декларација.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Завиткајте вредност што треба рачно да се испушти.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Сè уште можете безбедно да работите со вредноста
    /// assert_eq!(*x, "Hello");
    /// // Но, `Drop` нема да работи тука
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ја вади вредноста од контејнерот `ManuallyDrop`.
    ///
    /// Ова овозможува повторно да се испушти вредноста.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ова паѓа на `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Ја вади вредноста од контејнерот `ManuallyDrop<T>`.
    ///
    /// Овој метод е првенствено наменет за поместување на вредностите во пад.
    /// Наместо да користите [`ManuallyDrop::drop`] за рачно да ја испуштите вредноста, можете да го користите овој метод за да ја земете вредноста и да ја користите колку што сакате.
    ///
    /// Секогаш кога е можно, подобро е да се користи [`into_inner`][`ManuallyDrop::into_inner`] наместо тоа, што спречува дуплирање на содржината на `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Оваа функција семантички ја поместува содржаната вредност без да спречи понатамошно користење, оставајќи ја состојбата на овој контејнер непроменета.
    /// Ваша одговорност е да осигурате дека овој `ManuallyDrop` не се користи повторно.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // БЕЗБЕДНОСТ: читаме од референца, која е загарантирана
        // да биде валиден за читање.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Рачно ја испушта содржаната вредност.Ова е точно еквивалентно на повик на [`ptr::drop_in_place`] со покажувач на содржаната вредност.
    /// Како такво, освен ако содржаната вредност не е спакувана структура, деструкторот ќе се повика на место без да се помести вредноста, и со тоа може да се користи за безбедно исфрлање на [pinned] податоци.
    ///
    /// Ако имате сопственост на вредноста, наместо тоа, можете да користите [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Оваа функција го извршува деструкторот на содржаната вредност.
    /// Освен промените направени од самиот уништувач, меморијата останува непроменета и, што се однесува до компајлерот, сè уште има бит-шема што важи за типот `T`.
    ///
    ///
    /// Сепак, оваа вредност "zombie" не треба да биде изложена на безбеден код и оваа функција не треба да се повикува повеќе од еднаш.
    /// Да се користи вредност откако ќе се испушти или да се испушти вредност повеќе пати, може да предизвика недефинирано однесување (во зависност од тоа што прави `drop`).
    /// Ова обично се спречува од типот систем, но корисниците на `ManuallyDrop` мора да ги почитуваат тие гаранции без помош од компајлерот.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // БЕЗБЕДНОСТ: ја испуштаме вредноста што ја посочува неспојливата референца
        // што е гарантирано дека е валидно за пишување.
        // Останува на повикувачот да провери дали `slot` не е повторно исфрлен.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}