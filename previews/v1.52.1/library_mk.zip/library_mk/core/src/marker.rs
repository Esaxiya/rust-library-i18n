//! Примитивни traits и типови што претставуваат основни својства на типовите.
//!
//! Видовите Rust можат да се класифицираат на различни корисни начини според нивните внатрешни својства.
//! Овие класификации се претставени како traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Видови што можат да се пренесат преку границите на конецот.
///
/// Овој trait автоматски се спроведува кога компајлерот утврди дека е соодветен.
///
/// Пример за тип кој не е " Испрати` е покажувачот за броење референци [`rc::Rc`][`Rc`].
/// Ако две нишки се обидат да ги клонираат [`Rc`] кои укажуваат на истата сметана референтна вредност, тие може да се обидат да го ажурираат референтниот број истовремено, што е [undefined behavior][ub] затоа што [`Rc`] не користи атомски операции.
///
/// Нејзиниот братучед [`sync::Arc`][arc] користи атомски операции (се случуваат некои надземни) и затоа е `Send`.
///
/// Погледнете [the Nomicon](../../nomicon/send-and-sync.html) за повеќе детали.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Видови со постојана големина познати во времето на компајлирање.
///
/// Сите параметри на типот имаат имплицитна врзана `Sized`.Специјалната синтакса `?Sized` може да се искористи за да се отстрани врзаното ако не е соодветно.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // структура FooUse(Foo<[i32]>);//грешка: Големината не е имплементирана за [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Единствен исклучок е имплицитниот тип `Self` на trait.
/// trait нема имплицитно врзано `Sized` бидејќи тоа е некомпатибилно со [објектот trait] каде што, по дефиниција, trait треба да работи со сите можни имплементатори, а со тоа може да има било која големина.
///
///
/// Иако Rust ќе ви овозможи да го поврзете `Sized` со trait, подоцна нема да можете да го користите за да формирате објект trait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // нека y: &dyn Бар= &Impl;//грешка: trait `Bar` не може да се направи објект
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // за Стандардно, на пример, што бара `[T]: !Default` да може да се процени
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Видови што можат да бидат "unsized" до тип на динамичка големина.
///
/// На пример, со големина на низа тип `[i8; 2]` ги спроведува `Unsize<[i8]>` и `Unsize<dyn fmt::Debug>`.
///
/// Сите имплементации на `Unsize` се обезбедени автоматски од компајлерот.
///
/// `Unsize` се спроведува за:
///
/// - `[T; N]` е `Unsize<[T]>`
/// - `T` е `Unsize<dyn Trait>` кога `T: Trait`
/// - `Foo<..., T, ...>` е `Unsize<Foo<..., U, ...>>` ако:
///   - `T: Unsize<U>`
///   - Фу е структура
///   - Само последното поле на `Foo` има тип што вклучува `T`
///   - `T` не е дел од типот на други полиња
///   - `Bar<T>: Unsize<Bar<U>>`, ако последното поле на `Foo` има тип `Bar<T>`
///
/// `Unsize` се користи заедно со [`ops::CoerceUnsized`] за да се овозможи контејнери "user-defined" како [`Rc`] да содржат типови со динамичка големина.
/// Погледнете ги [DST coercion RFC][RFC982] и [the nomicon entry on coercion][nomicon-coerce] за повеќе детали.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Задолжително trait за константите што се користат во совпаѓањата на моделите.
///
/// Било кој тип што изведува `PartialEq` автоматски го спроведува овој trait,*без оглед* дали неговите типови-параметри го имплементираат `Eq`.
///
/// Ако `const` ставка содржи некој тип што не го спроведува овој trait, тогаш тој тип или (1.) не го спроведува `PartialEq` (што значи дека постојаната нема да го обезбеди тој метод за споредба, за кој генерацијата на код претпоставува дека е достапен), или (2.) го спроведува *сопствениот* верзија на `PartialEq` (за која претпоставуваме дека не одговара на споредбата на структурната еднаквост).
///
///
/// Во кое било од двете погоре сценарија, ние ја отфрламе употребата на таква константа во совпаѓање на моделот.
///
/// Видете исто така [structural match RFC][RFC1445] и [issue 63438] кои мотивираа мигрирање од дизајн базиран на атрибути кон овој trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Задолжително trait за константите што се користат во совпаѓањата на моделите.
///
/// Било кој тип што изведува `Eq` автоматски го спроведува овој trait, * без оглед на тоа дали параметрите на неговиот тип спроведуваат `Eq`.
///
/// Ова е хакерство за да се работи околу ограничување во нашиот тип систем.
///
/// # Background
///
/// Ние сакаме да бараме типовите на конституи кои се користат во совпаѓањата на шемите да го имаат атрибутот `#[derive(PartialEq, Eq)]`.
///
/// Во поидеален свет, можеме да го провериме тоа барање само со проверка дали дадениот тип ги спроведува и `StructuralPartialEq` trait *и*`Eq` trait.
/// Сепак, може да имате АДТ што прават * `derive(PartialEq, Eq)`, и да биде случај што сакаме компајлерот да го прифати, а сепак типот на константа не успева да го имплементира `Eq`.
///
/// Имено, ваков случај:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Проблемот во горенаведениот код е што `Wrap<fn(&())>` не спроведува `PartialEq`, ниту `Eq`, бидејќи " за <` a> fn(&'a _)` does not implement those traits.)
///
/// Затоа, не можеме да се потпреме на наивна проверка за `StructuralPartialEq` и само `Eq`.
///
/// Како хакер за да работиме околу ова, ние користиме два одделни traits инјектирани од секој од двата изведени (`#[derive(PartialEq)]` и `#[derive(Eq)]`) и проверуваме дали и двајцата се присутни како дел од проверката на структурните совпаѓања.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Видови чии вредности може да се удвојат едноставно со копирање битови.
///
/// Стандардно, врзивните врски имаат " семантика за движење`.Со други зборови:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` се пресели во `y` и затоа не може да се користи
///
/// // println! ("{: ?}", x);//грешка: употреба на преместена вредност
/// ```
///
/// Меѓутоа, ако еден вид спроведува `Copy`, тој наместо тоа има " копија за семантика`:
///
/// ```
/// // Можеме да изведеме имплементација `Copy`.
/// // `Clone` исто така е потребно, бидејќи тоа е супертрет на `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` е копија на `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Важно е да се напомене дека во овие два примери, единствената разлика е во тоа дали ви е дозволен пристап до `x` по извршената задача.
/// Под хаубата, и копијата и преместувањето може да резултираат во копирање на битови во меморијата, иако ова понекогаш е оптимизирано далеку.
///
/// ## Како можам да го имплементирам `Copy`?
///
/// Постојат два начина да се имплементира `Copy` на вашиот тип.Наједноставно е да се користи `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Можете исто така да ги имплементирате `Copy` и `Clone` рачно:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Постои мала разлика помеѓу двете: стратегијата `derive` исто така ќе постави `Copy` врзан за параметрите на типот, што не е секогаш посакувано.
///
/// ## Која е разликата помеѓу `Copy` и `Clone`?
///
/// Копиите се случуваат имплицитно, на пример, како дел од задачата `y = x`.Однесувањето на `Copy` не е преоптоварено;секогаш е едноставна бит-мудра копија.
///
/// Клонирањето е експлицитно дејство, `x.clone()`.Имплементацијата на [`Clone`] може да обезбеди какво било однесување специфично за да се дуплираат вредностите безбедно.
/// На пример, имплементацијата на [`Clone`] за [`String`] треба да го копира тампонот насочен кон низа во грамадата.
/// Едноставна бит-копија на вредностите на [`String`] би го копирала само покажувачот, што доведува до двојно ослободување по линијата.
/// Од оваа причина, [`String`] е [`Clone`] но не и `Copy`.
///
/// [`Clone`] е супертрет на `Copy`, така што сè што е `Copy`, исто така, мора да го имплементира [`Clone`].
/// Ако типот е `Copy`, тогаш неговата имплементација [`Clone`] треба само да врати `*self` (видете го примерот погоре).
///
/// ## Кога мојот тип може да биде `Copy`?
///
/// Тип може да спроведе `Copy` ако сите негови компоненти спроведуваат `Copy`.На пример, оваа структура може да биде `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Структурата може да биде `Copy`, а [`i32`] е `Copy`, затоа `Point` има право да биде `Copy`.
/// Спротивно на тоа, размислете
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` не може да го имплементира `Copy`, бидејќи [`Vec<T>`] не е `Copy`.Ако се обидеме да извлечеме `Copy` имплементација, ќе добиеме грешка:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Заедничките референци (`&T`) се исто така `Copy`, така што еден вид може да биде `Copy`, дури и кога има споделени референци од типови `T` што *не се*`Copy`.
/// Размислете за следното структура, која може да го имплементира `Copy`, бидејќи држи само *споделена референца* за нашиот не-копиран тип `PointList` од горе:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Кога *не може* мојот тип да биде `Copy`?
///
/// Некои типови не можат безбедно да се копираат.На пример, копирањето на `&mut T` би создало псевдоним непроменлива референца.
/// Копирањето на [`String`] би ја дуплирало одговорноста за управување со тампонот на [String]], што доведува до двојно бесплатно.
///
/// Генерализирајќи го последниот случај, кој било тип што спроведува [`Drop`] не може да биде `Copy`, бидејќи тој управува со некои ресурси покрај сопствените бајти [`size_of::<T>`].
///
/// Ако се обидете да го имплементирате `Copy` на структура или енум што содржи податоци што не се "Копирај", ќе ја добиете грешката [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Кога *треба* мојот тип да биде `Copy`?
///
/// Општо земено, ако вашиот тип _can_ спроведува `Copy`, треба.
/// Имајте на ум, сепак, дека спроведувањето на `Copy` е дел од јавниот API од ваш тип.
/// Ако типот може да стане не-" Копирај` во future, би можело да биде разумно да се изостави имплементацијата на `Copy` сега, за да се избегне кршење на промена на API.
///
/// ## Дополнителни имплементатори
///
/// Покрај [implementors listed below][impls], следниве типови исто така го имплементираат `Copy`:
///
/// * Видови ставки на функции (т.е. посебни типови дефинирани за секоја функција)
/// * Видови на покажувачи на функции (на пр., `fn() -> i32`)
/// * Типови на низи, за сите големини, ако типот на ставка исто така спроведува `Copy` (на пример, `[i32; 123456]`)
/// * Двојни типови, ако секоја компонента исто така спроведува `Copy` (на пример, `()`, `(i32, bool)`)
/// * Видови на затворање, ако не зафаќаат никаква вредност од околината или ако сите такви зафатени вредности го спроведуваат `Copy` самите.
///   Имајте на ум дека променливите зафатени со споделена референца секогаш спроведуваат `Copy` (дури и ако референтот не го прави тоа), додека променливите зафатени со променливата референца никогаш не спроведуваат `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ова овозможува копирање на тип што не спроведува `Copy` поради незадоволни животни граници (копирање на `A<'_>` кога само `A<'static>: Copy` и `A<'_>: Clone`).
// Овој атрибут го имаме засега само затоа што постојат неколку постоечки специјализации на `Copy` кои веќе постојат во стандардната библиотека и нема начин како безбедно да се има ова однесување во моментов.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Изведете макро генерирање на импликација на trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Видови за кои е безбедно да се споделуваат референци помеѓу нишки.
///
/// Овој trait автоматски се спроведува кога компајлерот утврди дека е соодветен.
///
/// Прецизната дефиниција е: тип `T` е [`Sync`] ако и само ако `&T` е [`Send`].
/// Со други зборови, ако не постои можност за [undefined behavior][ub] (вклучително и трки со податоци) при пренесување на `&T` референци помеѓу нишките.
///
/// Како што би се очекувало, примитивните типови како [`u8`] и [`f64`] се сите [`Sync`], а исто така се и едноставните агрегатни типови што ги содржат, како што се палта, удари и енуми.
/// Повеќе примери на основни типови [`Sync`] вклучуваат типови "immutable" како `&T` и оние со едноставна наследна подвижност, како што се [`Box<T>`][box], [`Vec<T>`][vec] и повеќето други типови на колекции.
///
/// (Генеричките параметри треба да бидат [`Sync`] за нивниот контејнер да биде [" Синхронизација`].)
///
/// Нешто изненадувачка последица од дефиницијата е дека `&mut T` е `Sync` (ако `T` е `Sync`) иако се чини дека тоа може да обезбеди несинхронизирана мутација.
/// Финтата е што неспојливата референца зад споделена референца (т.е. `& &mut T`) станува само за читање, како да е `& &T`.
/// Оттука, не постои ризик од трка со податоци.
///
/// Типови што не се `Sync` се оние што имаат "interior mutability" во не-безбедна форма, како што се [`Cell`][cell] и [`RefCell`][refcell].
/// Овие типови овозможуваат мутација на нивната содржина дури и преку непроменлива, споделена референца.
/// На пример, методот `set` на [`Cell<T>`][cell] трае `&self`, затоа бара само споделена референца [`&Cell<T>`][cell].
/// Методот не извршува синхронизација, затоа [`Cell`][cell] не може да биде `Sync`.
///
/// Друг пример за тип кој не е " Синхронизиран` е референтниот-покажувач [`Rc`][rc].
/// Со оглед на која било референца [`&Rc<T>`][rc], можете да клонирате нов [`Rc<T>`][rc], менувајќи го бројот на референци на не-атомски начин.
///
/// За случаи кога е потребна внатрешна подвижност без конец, Rust обезбедува [atomic data types], како и експлицитно заклучување преку [`sync::Mutex`][mutex] и [`sync::RwLock`][rwlock].
/// Овие типови осигуруваат дека секоја мутација не може да предизвика раси на податоци, па оттука и типовите се `Sync`.
/// Исто така, [`sync::Arc`][arc] обезбедува аналог на [`Rc`][rc] без конец.
///
/// Кои било типови со внатрешна променливост, исто така, мора да користат [`cell::UnsafeCell`][unsafecell] обвивка околу value(s), што може да се мутира преку споделена референца.
/// Не успеа да го стори тоа е [undefined behavior][ub].
/// На пример, [`transmute`][transmute]-ing од `&T` до `&mut T` е неважечки.
///
/// Погледнете [the Nomicon][nomicon-send-and-sync] за повеќе детали во врска со `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): откако ќе биде поддржана за додавање белешки во `rustc_on_unimplemented` во бета фаза, и таа е продолжена за да се провери дали затворањето е некаде во ланецот со барања, проширете го како таков (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Тип со нула големина што се користи за обележување работи што "act like" ги поседуваат `T`.
///
/// Додавањето на полето `PhantomData<T>` на вашиот тип му кажува на компајлерот дека вашиот тип се однесува како да складира вредност од типот `T`, иако тоа навистина не е.
/// Оваа информација се користи при пресметување на одредени безбедносни својства.
///
/// За подетално објаснување за тоа како да го користите `PhantomData<T>`, ве молиме, видете [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Страшна нота
///
/// Иако и двајцата имаат застрашувачки имиња, `PhantomData` и " фантомски типови` се поврзани, но не се идентични.Параметар за фантомски тип е едноставно параметар за тип кој никогаш не се користи.
/// Во Rust, ова честопати предизвикува приговор на компајлерот, а решението е да додадете употреба на "dummy" по пат на `PhantomData`.
///
/// # Examples
///
/// ## Неискористени параметри за живот
///
/// Можеби најчестиот случај на употреба за `PhantomData` е структура која има неискористен параметар за живот, обично како дел од небезбеден код.
/// На пример, еве структура `Slice` која има два покажувачи од типот `*const T`, веројатно покажувајќи во низа некаде:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Намерата е основните податоци да важат само за целиот животен век `'a`, така што `Slice` не треба да го надминува животот `'a`.
/// Сепак, оваа намера не е изразена во кодот, бидејќи нема употреба на животниот век `'a` и затоа не е јасно за кои податоци се однесува.
/// Ова можеме да го исправиме со тоа што ќе му кажеме на компајлерот да се однесува *како да* структурата `Slice` содржи референца `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ова, исто така, за возврат бара коментар `T: 'a`, што покажува дека сите референци во `T` се валидни во текот на целиот животен век `'a`.
///
/// При иницијализирање на `Slice` едноставно ја давате вредноста `PhantomData` за полето `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Неискористени параметри на типот
///
/// Понекогаш се случува да имате неискористени параметри на типот што означуваат за каков тип на податоци се наоѓа структурата "tied", иако тие податоци всушност не се наоѓаат во самата структура.
/// Еве еден пример каде ова се појавува со [FFI].
/// Странскиот интерфејс користи рачки од типот `*mut ()` за да се однесува на Rust вредности од различни типови.
/// Ние го следиме типот Rust користејќи параметар на фантомски тип на структурата `ExternalResource` што обвива рачка.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Сопственост и проверка на пад
///
/// Додавањето поле од типот `PhantomData<T>` покажува дека вашиот тип поседува податоци од типот `T`.Ова, пак, имплицира дека кога типот ќе падне, може да испушти една или повеќе примери од типот `T`.
/// Ова се одразува на анализата на Rust компајлерот [drop check].
///
/// Ако вашиот структура всушност не ги поседува *податоците од типот `T`, подобро е да користите референтен тип, како `PhantomData<&'a T>` (ideally) или `PhantomData<* const T>` (ако не важи животен век), за да не се наведува сопственоста.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Внатрешен компајлер trait се користи за означување на видот на дискриминатори на енумот.
///
/// Овој trait автоматски се спроведува за секој тип и не додава никакви гаранции на [`mem::Discriminant`].
/// **е недефинирано однесување** да се трансмитира помеѓу `DiscriminantKind::Discriminant` и `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Вид на дискриминатор, кој мора да го задоволува trait bounds што го бара `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Внатрешен компајлер trait се користи за да се утврди дали еден вид содржи внатрешно `UnsafeCell`, но не преку индирекција.
///
/// Ова влијае, на пример, дали `static` од тој тип е ставен во статична меморија само за читање или статичка меморија што може да се запише.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Видови што можат безбедно да се преместат откако ќе се закачат.
///
/// Самиот Rust нема поим за недвижни типови и смета дека потезите (на пр. Преку доделување или [`mem::replace`]) секогаш се безбедни.
///
/// Наместо тоа, се користи типот [`Pin`][Pin] за да се спречат потезите низ системот за типови.Покажувачите `P<T>` завиткани во обвивката [`Pin<P<T>>`][Pin] не можат да се преместат надвор.
/// Погледнете ја документацијата [`pin` module] за повеќе информации за закачување.
///
/// Спроведувањето на `Unpin` trait за `T` ги укинува ограничувањата за закачување на типот, што потоа овозможува поместување на `T` надвор од [`Pin<P<T>>`][Pin] со функции како што е [`mem::replace`].
///
///
/// `Unpin` воопшто нема последица за податоците што не се закачени.
/// Особено, [`mem::replace`] радосно ги поместува податоците `!Unpin` (работи за секој `&mut T`, не само за `T: Unpin`).
/// Сепак, не можете да користите [`mem::replace`] на податоци завиткани во [`Pin<P<T>>`][Pin] затоа што не можете да го добиете `&mut T` што ви треба за тоа, и * тоа е она што го прави овој систем да работи.
///
/// Така, ова, на пример, може да се направи само на типови кои го спроведуваат `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Потребна ни е изменлива референца за да повикаме `mem::replace`.
/// // Таква референца можеме да добиеме со (implicitly) повикувајќи се на `Pin::deref_mut`, но тоа е можно само затоа што `String` спроведува `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Овој trait се спроведува автоматски за скоро секој тип.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Тип на маркер кој не спроведува `Unpin`.
///
/// Ако еден тип содржи `PhantomPinned`, тој нема да го спроведува `Unpin` по дифолт.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Имплементација на `Copy` за примитивни типови.
///
/// Имплементациите што не можат да се опишат во Rust се спроведуваат во `traits::SelectionContext::copy_clone_conditions()` во `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Заедничките референци можат да се копираат, но неспојливите препораки *не можат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}