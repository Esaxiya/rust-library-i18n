//! Начини да се создаде `str` од парче бајти.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Конвертира парче бајти во парче низа.
///
/// Стринг парче ([`&str`]) е направено од бајти ([`u8`]), а парче бајт ([`&[u8]`][byteslice]) е направено од бајти, така што оваа функција се претвора помеѓу двајцата.
/// Не сите бајт-парчиња се валидни низи, сепак: [`&str`] бара да е валидна UTF-8.
/// `from_utf8()` проверува дали бајтите се валидни UTF-8, а потоа ја прави и конверзијата.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ако сте сигурни дека парчето бајт е валидно UTF-8, и не сакате да направите преглед на валидноста, постои небезбедна верзија на оваа функција, [`from_utf8_unchecked`], која има исто однесување, но ја прескокнува проверката.
///
///
/// Ако ви треба `String` наместо `&str`, размислете за [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Бидејќи можете да поставите-поставите `[u8; N]` и може да земете [`&[u8]`][byteslice] од неа, оваа функција е еден од начините да имате низа доделена на стек.Има пример за ова во делот за примери подолу.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Враќа `Err` ако парчето не е UTF-8 со опис зошто даденото парче не е UTF-8.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // некои бајти, во vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Знаеме дека овие бајти се валидни, затоа само користете `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Неточни бајти:
///
/// ```
/// use std::str;
///
/// // некои невалидни бајти, во vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Погледнете ги документите за [`Utf8Error`] за повеќе детали за видовите грешки што може да се вратат.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // некои бајти, во низа распределена од магацинот
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Знаеме дека овие бајти се валидни, затоа само користете `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗБЕДНОСТ: Само трчаше валидација.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Конвертира променливо парче бајти во променливо парче жица.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" како непроменлив vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Како што знаеме овие бајти се валидни, можеме да користиме `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Неточни бајти:
///
/// ```
/// use std::str;
///
/// // Некои невалидни бајти во неспокоен vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Погледнете ги документите за [`Utf8Error`] за повеќе детали за видовите грешки што може да се вратат.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗБЕДНОСТ: Само трчаше валидација.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Конвертира парче бајти во парче низа без да провери дали низата содржи валидна UTF-8.
///
/// Погледнете ја безбедната верзија, [`from_utf8`], за повеќе информации.
///
/// # Safety
///
/// Оваа функција е небезбедна затоа што не проверува дали бајтите положени на неа се валидни UTF-8.
/// Ако ова ограничување е прекршено, недефинираното однесување резултира, бидејќи остатокот од Rust претпоставува дека ["&str"] ите се валидни UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // некои бајти, во vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека бајтите `v` се валидни UTF-8.
    // Исто така се потпира на `&str` и `&[u8]` кои имаат ист распоред.
    unsafe { mem::transmute(v) }
}

/// Конвертира парче бајти во парче низа без да провери дали низата содржи валидна UTF-8;мутабилна верзија.
///
///
/// Погледнете ја непроменливата верзија, [`from_utf8_unchecked()`] за повеќе информации.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека бајтите `v`
    // се валидни UTF-8, така што фрлањето на `*mut str` е безбедно.
    // Исто така, дереференцијата на покажувачот е безбедна затоа што тој покажувач доаѓа од референца за која се гарантира дека е валидна за запишување.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}