//! Манипулација со жици.
//!
//! За повеќе детали, видете го модулот [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. надвор од границите
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. започне <=крај
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. граница на карактерот
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // најдете го ликот
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` мора да биде помала од границата од лен и јаглен
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Ја враќа должината на `self`.
    ///
    /// Оваа должина е во бајти, а не во ``char`` или графеми.
    /// Со други зборови, можеби не е тоа што човекот ја смета за должината на низата.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // фенси ѓ!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Враќа `true` ако `self` има должина од нула бајти.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Проверува дека `индексот`-бајт е првиот бајт во низата на кодови UTF-8 или крајот на низата.
    ///
    ///
    /// Почетокот и крајот на низата (кога `индексот== self.len()`) се сметаат за граници.
    ///
    /// Враќа `false` ако `index` е поголем од `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // почеток на `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // втор бајт на `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // трет бајт од `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 и Лен се секогаш во ред.
        // Експлицитно тестирајте за 0 за да може лесно да ја оптимизира проверката и да прескокне читање на податочните низи за тој случај.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ова е малку магија еквивалентно на: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Конвертира парче стринг во парче бајт.
    /// За да го претворите парчето бајт назад во низа, користете ја функцијата [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // БЕЗБЕДНОСТ: звук затоа што трансмитираме два вида со ист распоред
        unsafe { mem::transmute(self) }
    }

    /// Конвертира парче што може да се менува во парче што може да се менува.
    ///
    /// # Safety
    ///
    /// Повикувачот мора да осигури дека содржината на парчето е валидна UTF-8 пред да заврши заемот и да се користи основната `str`.
    ///
    ///
    /// Употребата на `str` чија содржина не е валидна UTF-8 е недефинирано однесување.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // БЕЗБЕДНОСТ: гипсот од `&str` до `&[u8]` е безбеден уште од `str`
        // има ист распоред како `&[u8]` (само libstd може да ја даде оваа гаранција).
        // Дереференцијата на покажувачот е безбедна бидејќи доаѓа од изменлива референца за која се гарантира дека е валидна за пишување.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Конвертира парче жица во суров покажувач.
    ///
    /// Бидејќи парчињата жици се парче бајти, сировиот покажувач покажува на [`u8`].
    /// Овој покажувач ќе покажува на првиот бајт од низата.
    ///
    /// Повикувачот мора да осигури дека вратениот покажувач никогаш не е напишан.
    /// Ако треба да ја мутирате содржината на парчето жици, користете [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Преобразлива парче жица во суров покажувач.
    ///
    /// Бидејќи парчињата жици се парче бајти, сировиот покажувач покажува на [`u8`].
    /// Овој покажувач ќе покажува на првиот бајт од низата.
    ///
    /// Ваша одговорност е да бидете сигурни дека парчето низа ќе се измени само на начин да остане валиден UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Враќа под-парче `str`.
    ///
    /// Ова е алтернатива без паника за индексирање на `str`.
    /// Враќа [`None`] секогаш кога еквивалентно работење со индексирање би panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // индекси кои не се на границите на низата UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // надвор од границите
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Враќа менливо под-парче `str`.
    ///
    /// Ова е алтернатива без паника за индексирање на `str`.
    /// Враќа [`None`] секогаш кога еквивалентно работење со индексирање би panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // точна должина
    /// assert!(v.get_mut(0..5).is_some());
    /// // надвор од границите
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Враќа неконтролирано под-парче `str`.
    ///
    /// Ова е непроверена алтернатива за индексирање на `str`.
    ///
    /// # Safety
    ///
    /// Повикувачите на оваа функција се одговорни дека овие предуслови се исполнети:
    ///
    /// * Почетниот индекс не смее да го надминува индексот на крај;
    /// * Индексите мора да бидат во границите на оригиналното парче;
    /// * Индексите мора да лежат на границите на низата UTF-8.
    ///
    /// Доколку не се случи тоа, вратениот стринг парче може да се однесува на невалидна меморија или да ги наруши инваријантите комуницирани од типот `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked`;
        // парчето е референцирано бидејќи `self` е безбедна референца.
        // Враќаниот покажувач е безбеден затоа што импликациите на `SliceIndex` треба да гарантираат дека е.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Враќа променливо, неконтролирано под-парче `str`.
    ///
    /// Ова е непроверена алтернатива за индексирање на `str`.
    ///
    /// # Safety
    ///
    /// Повикувачите на оваа функција се одговорни дека овие предуслови се исполнети:
    ///
    /// * Почетниот индекс не смее да го надминува индексот на крај;
    /// * Индексите мора да бидат во границите на оригиналното парче;
    /// * Индексите мора да лежат на границите на низата UTF-8.
    ///
    /// Доколку не се случи тоа, вратениот стринг парче може да се однесува на невалидна меморија или да ги наруши инваријантите комуницирани од типот `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked_mut`;
        // парчето е референцирано бидејќи `self` е безбедна референца.
        // Враќаниот покажувач е безбеден затоа што импликациите на `SliceIndex` треба да гарантираат дека е.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Создава парче жица од друга низа, заобиколувајќи ги безбедносните проверки.
    ///
    /// Ова обично не се препорачува, користете со претпазливост!За безбедна алтернатива видете [`str`] и [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ова ново парче оди од `begin` до `end`, вклучително и `begin`, но со исклучок на `end`.
    ///
    /// Наместо тоа, за да добиете мутабилна жичка, видете го методот [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Повикувачите на оваа функција се одговорни дека се исполнети три предуслови:
    ///
    /// * `begin` не смее да надминува `end`.
    /// * `begin` и `end` мора да бидат бајтски позиции во рамките на стрингот.
    /// * `begin` и `end` мора да лежат на границите на низата UTF-8.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked`;
        // парчето е референцирано бидејќи `self` е безбедна референца.
        // Враќаниот покажувач е безбеден затоа што импликациите на `SliceIndex` треба да гарантираат дека е.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Создава парче жица од друга низа, заобиколувајќи ги безбедносните проверки.
    /// Ова обично не се препорачува, користете со претпазливост!За безбедна алтернатива видете [`str`] и [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ова ново парче оди од `begin` до `end`, вклучително и `begin`, но со исклучок на `end`.
    ///
    /// За да добиете непроменлива парче жица наместо тоа, видете го методот [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Повикувачите на оваа функција се одговорни дека се исполнети три предуслови:
    ///
    /// * `begin` не смее да надминува `end`.
    /// * `begin` и `end` мора да бидат бајтски позиции во рамките на стрингот.
    /// * `begin` и `end` мора да лежат на границите на низата UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked_mut`;
        // парчето е референцирано бидејќи `self` е безбедна референца.
        // Враќаниот покажувач е безбеден затоа што импликациите на `SliceIndex` треба да гарантираат дека е.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Поделете едно парче жица на две во индекс.
    ///
    /// Аргументот, `mid`, треба да биде бајт-неутрализиран од почетокот на низата.
    /// Исто така, мора да биде на границата на кодот UTF-8.
    ///
    /// Двете парчиња вратени одат од почетокот на жицата до `mid`, и од `mid` до крајот на жицата.
    ///
    /// Наместо тоа, за да добиете променливи парчиња жици, видете го методот [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ако `mid` не е на границата на точката на кодот UTF-8 или ако е над крајот на последната кодна точка на низата.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary проверува дали индексот е во [0, .len()]
        if self.is_char_boundary(mid) {
            // БЕЗБЕДНОСТ: само провери дали `mid` е на граница на јаглен.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Поделете една мутабилна жичка парче на индекс на две.
    ///
    /// Аргументот, `mid`, треба да биде бајт-неутрализиран од почетокот на низата.
    /// Исто така, мора да биде на границата на кодот UTF-8.
    ///
    /// Двете парчиња вратени одат од почетокот на жицата до `mid`, и од `mid` до крајот на жицата.
    ///
    /// За да добиете непроменливи парчиња жици наместо тоа, видете го методот [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ако `mid` не е на границата на точката на кодот UTF-8 или ако е над крајот на последната кодна точка на низата.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary проверува дали индексот е во [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // БЕЗБЕДНОСТ: само провери дали `mid` е на граница на јаглен.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Враќа повторувач преку [`char`]-ките од жицата.
    ///
    /// Бидејќи парчето жици се состои од валиден UTF-8, можеме да го повторуваме преку парче жица од [`char`].
    /// Овој метод враќа таков повторувач.
    ///
    /// Важно е да запомните дека [`char`] претставува уникатна скаларна вредност и може да не одговара на вашата идеја за тоа што е 'character'.
    ///
    /// Повторувањето над групите графеми може да биде она што навистина го сакате.
    /// Оваа функционалност не е обезбедена од стандардната библиотека на Rust, наместо тоа, проверете crates.io.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Запомнете, [`char`]-те можеби не се совпаѓаат со вашата интуиција за карактери:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // не 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Враќа повторувач преку [`char`]-от од жицата и нивните позиции.
    ///
    /// Бидејќи парчето жици се состои од валиден UTF-8, можеме да го повторуваме преку парче жица од [`char`].
    /// Овој метод враќа повторувач и на овие [`char`] и на нивните бајтски позиции.
    ///
    /// Итераторот дава тупли.Позицијата е прва, [`char`] е втора.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Запомнете, [`char`]-те можеби не се совпаѓаат со вашата интуиција за карактери:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // не (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // забележете 3 тука, последниот знак зазема два бајти
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Итератор преку бајтите на жицата.
    ///
    /// Бидејќи стрингот парче се состои од низа бајти, можеме да итератираме низ стринг парче по бајт.
    /// Овој метод враќа таков повторувач.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Поделува парче жица по празно место.
    ///
    /// Итераторот вратен ќе ги врати низите парчиња што се под-парчиња од оригиналното парче жица, одделени со која било количина на бел простор.
    ///
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    /// Ако сакате само да се поделите на белиот простор на ASCII, користете [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Се разгледуваат сите видови на бел простор:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Разделува парче од низата според ASCII белиот простор.
    ///
    /// Враќаниот повторувач ќе ги врати парчињата низа што се под-парчиња од оригиналното парче низа, одделени со која било количина на ASCII бел простор.
    ///
    ///
    /// Наместо тоа, да се подели со Unicode `Whitespace`, користете [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Се разгледуваат сите видови на бел простор на ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Итератор преку линиите на низата, како парчиња жици.
    ///
    /// Линиите завршуваат или со нова линија (`\n`) или со поврат на кочија со линија за напојување (`\r\n`).
    ///
    /// Завршувањето на последната линија е опционално.
    /// Низа што завршува со крајна завршна линија ќе ги врати истите линии како инаку идентична низа без крајна завршна линија.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Завршувањето на последната линија не е потребно:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Итератор преку линиите на низата.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Враќа повторувач на `u16` преку низата кодирани како UTF-16.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Враќа `true` ако дадената шема одговара на под-парче од овој стринг парче.
    ///
    /// Враќа `false` ако не.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Враќа `true` ако дадената шема одговара на префиксот на ова парче жица.
    ///
    /// Враќа `false` ако не.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Враќа `true` ако дадената шема се совпаѓа со наставка од овој стринг парче.
    ///
    /// Враќа `false` ако не.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Го враќа индексот на бајти од првиот знак на ова парче низа што одговара на моделот.
    ///
    /// Враќа [`None`] ако моделот не се совпаѓа.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Покомплексни обрасци кои користат стил и затворања без точка:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Не наоѓање на моделот:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Го враќа индексот на бајти за првиот знак од десното совпаѓање на моделот во ова парче низа.
    ///
    /// Враќа [`None`] ако моделот не се совпаѓа.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Покомплексни обрасци со затворачи:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Не наоѓање на моделот:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Повторувач над подничките на овој стринг парче, одделен со карактери карактеризирани со шема.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач ќе биде [`DoubleEndedIterator`] ако моделот дозволи обратно пребарување и пребарувањето forward/reverse ги дава истите елементи.
    /// Ова важи за, на пример, [`char`], но не и за `&str`.
    ///
    /// Ако моделот дозволува обратно пребарување, но неговите резултати може да се разликуваат од пребарувањето напред, може да се користи методот [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ако делот е парче од карактери, поделете се на секоја појава на кој било од ликовите:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ако низата содржи повеќе соседни сепаратори, на крајот ќе излезете со празни низи:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Сосемните сепаратори се одделени со празната низа.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Сепараторите на почетокот или на крајот од низата се соседени со празни низи.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Кога празната низа се користи како сепаратор, таа ги одделува секој карактер во низата, заедно со почетокот и крајот на низата.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Сосемните сепаратори може да доведат до евентуално изненадувачко однесување кога се користи бел простор како сепаратор.Овој код е точен:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ви дава _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Користете [`split_whitespace`] за ова однесување.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Повторувач над подничките на овој стринг парче, одделен со карактери карактеризирани со шема.
    /// Разликите од повторувачот произведени од `split` со тоа што `split_inclusive` го оставаат соодветниот дел како завршувач на подницата.
    ///
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ако се совпадне последниот елемент од стрингот, тој елемент ќе се смета за крај на претходната низа.
    /// Тој поднаслов ќе биде последната ставка вратена од повторувачот.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Повторувач над поднизите на даденото парче жица, разделени со знаци кои се совпаѓаат со шема и се даваат во обратен редослед.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач бара шемата да поддржува обратно пребарување и тоа ќе биде [`DoubleEndedIterator`] ако пребарувањето forward/reverse ги дава истите елементи.
    ///
    ///
    /// За повторување од напред, може да се користи методот [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Повторувач над поднизите на дадената парче жица, одделени со знаци кои се совпаѓаат со шема.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Еквивалентно на [`split`], освен што заостанатата поднасечка е прескокната ако е празна.
    ///
    /// [`split`]: str::split
    ///
    /// Овој метод може да се користи за низа податоци што се _terminated_, наместо _separated_ според шема.
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач ќе биде [`DoubleEndedIterator`] ако моделот дозволи обратно пребарување и пребарувањето forward/reverse ги дава истите елементи.
    /// Ова важи за, на пример, [`char`], но не и за `&str`.
    ///
    /// Ако моделот дозволува обратно пребарување, но неговите резултати може да се разликуваат од пребарувањето напред, може да се користи методот [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Повторувач над поднаиците на `self`, одделен со знаци кои се совпаѓаат со модел и даваа во обратен редослед.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Еквивалентно на [`split`], освен што заостанатата поднасечка е прескокната ако е празна.
    ///
    /// [`split`]: str::split
    ///
    /// Овој метод може да се користи за низа податоци што се _terminated_, наместо _separated_ според шема.
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач бара шемата да поддржува обратно пребарување и ќе биде двојно завршена доколку со пребарување forward/reverse се дадат истите елементи.
    ///
    ///
    /// За повторување од напред, може да се користи методот [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Повторувач над подничките на даденото стринг парче, разделено со шема, ограничено на враќање најмногу `n` ставки.
    ///
    /// Ако се вратат `n` поднапредности, последната подна низа (`n`-та поднасечка) ќе го содржи остатокот од низата.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач нема да биде двојно завршен, бидејќи не е ефикасен за поддршка.
    ///
    /// Ако моделот дозволи обратно пребарување, може да се користи методот [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Повторувач над подничките на овој стринг парче, одделен со шема, почнувајќи од крајот на низата, е ограничен на враќање најмногу `n` ставки.
    ///
    ///
    /// Ако се вратат `n` поднапредности, последната подна низа (`n`-та поднасечка) ќе го содржи остатокот од низата.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач нема да биде двојно завршен, бидејќи не е ефикасен за поддршка.
    ///
    /// За разделување од напред, може да се користи методот [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Ја дели низата на првото појавување на наведениот разграничувач и враќа префикс пред раздвојувачот и наставка по разграничувачот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ја дели низата на последната појава на наведениот разграничувач и враќа префикс пред раздвојувачот и наставка по разграничувачот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Повторувач над засебните совпаѓања на моделот во даденото парче жица.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач ќе биде [`DoubleEndedIterator`] ако моделот дозволи обратно пребарување и пребарувањето forward/reverse ги дава истите елементи.
    /// Ова важи за, на пример, [`char`], но не и за `&str`.
    ///
    /// Ако моделот дозволува обратно пребарување, но неговите резултати може да се разликуваат од пребарувањето напред, може да се користи методот [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Повторувач над одделните совпаѓања на моделот во рамките на ова парче жица, даде во обратен редослед.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач бара шемата да поддржува обратно пребарување и тоа ќе биде [`DoubleEndedIterator`] ако пребарувањето forward/reverse ги дава истите елементи.
    ///
    ///
    /// За повторување од напред, може да се користи методот [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Повторувач над одделните совпаѓања на моделот во овој дел од стрингот, како и индексот со кој започнува натпреварот.
    ///
    /// За натпревари од `pat` во рамките на `self` кои се преклопуваат, се враќаат само индексите што одговараат на првиот натпревар.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач ќе биде [`DoubleEndedIterator`] ако моделот дозволи обратно пребарување и пребарувањето forward/reverse ги дава истите елементи.
    /// Ова важи за, на пример, [`char`], но не и за `&str`.
    ///
    /// Ако моделот дозволува обратно пребарување, но неговите резултати може да се разликуваат од пребарувањето напред, може да се користи методот [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // само првиот `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Повторувач над одделните совпаѓања на моделот во `self`, даде во обратен редослед заедно со индексот на натпреварот.
    ///
    /// За натпревари од `pat` во рамките на `self` кои се преклопуваат, се враќаат само индексите што одговараат на последниот натпревар.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Однесување на повторувачот
    ///
    /// Враќаниот повторувач бара шемата да поддржува обратно пребарување и тоа ќе биде [`DoubleEndedIterator`] ако пребарувањето forward/reverse ги дава истите елементи.
    ///
    ///
    /// За повторување од напред, може да се користи методот [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // само последниот `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Враќа парче стринг со отстранети водечки и заостанувачки празни места.
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Враќа парче жица со отстрането водечко празно место.
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// `start` во овој контекст значи прва позиција на таа низа бајти;за јазик од лево кон десно како англиски или руски, ова ќе биде од левата страна, а за јазиците од десно кон лево како арапски или хебрејски, ова ќе биде од десната страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Враќа парче жица со отстрането празно место.
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// `end` во овој контекст значи последната позиција на таа низа бајти;за јазик од лево кон десно како англиски или руски, ова ќе биде од десната страна, а за јазиците од десно кон лево како арапски или хебрејски, ова ќе биде од левата страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Враќа парче жица со отстрането водечко празно место.
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// 'Left' во овој контекст значи прва позиција на таа низа бајти;за јазик како арапски или хебрејски кои се " десно од лево`отколку " лево надесно`, ова ќе биде _right_ страна, а не лево.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Враќа парче жица со отстрането празно место.
    ///
    /// 'Whitespace' се дефинира според условите на Unicode Изведен основен имот `White_Space`.
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// 'Right' во овој контекст значи последната позиција на таа низа бајти;за јазик како арапски или хебрејски кои се " десно од лево`отколку " лево надесно`, ова ќе биде _left_ страна, а не десно.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Враќа парче жица со сите префикси и наставки што одговараат на шемата што постојано се отстранува.
    ///
    /// [pattern] може да биде [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Запомнете го најраниот познат натпревар, поправете го подолу ако
            // последниот натпревар е различен
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕЗБЕДНОСТ: Познато е дека `Searcher` враќа валидни индекси.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Враќа парче жица со сите префикси што одговараат на шема која е постојано отстранета.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// `start` во овој контекст значи прва позиција на таа низа бајти;за јазик од лево кон десно како англиски или руски, ова ќе биде од левата страна, а за јазиците од десно кон лево како арапски или хебрејски, ова ќе биде од десната страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // БЕЗБЕДНОСТ: Познато е дека `Searcher` враќа валидни индекси.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Враќа парче жица со отстранет префикс.
    ///
    /// Ако стрингот започне со шемата `prefix`, се враќа поднишката по префиксот, завиткана во `Some`.
    /// За разлика од `trim_start_matches`, овој метод го отстранува префиксот точно еднаш.
    ///
    /// Ако низата не започне со `prefix`, се враќа `None`.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Враќа парче жица со извадена наставка.
    ///
    /// Ако стрингот заврши со шемата `suffix`, ја враќа подницата пред наставката, завиткана во `Some`.
    /// За разлика од `trim_end_matches`, овој метод ја отстранува наставката точно еднаш.
    ///
    /// Ако низата не заврши со `suffix`, се враќа `None`.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Враќа парче жица со сите наставки што одговараат на шемата што постојано се отстранува.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// `end` во овој контекст значи последната позиција на таа низа бајти;за јазик од лево кон десно како англиски или руски, ова ќе биде од десната страна, а за јазиците од десно кон лево како арапски или хебрејски, ова ќе биде од левата страна.
    ///
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕЗБЕДНОСТ: Познато е дека `Searcher` враќа валидни индекси.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Враќа парче жица со сите префикси што одговараат на шема која е постојано отстранета.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// 'Left' во овој контекст значи прва позиција на таа низа бајти;за јазик како арапски или хебрејски кои се " десно од лево`отколку " лево надесно`, ова ќе биде _right_ страна, а не лево.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Враќа парче жица со сите наставки што одговараат на шемата што постојано се отстранува.
    ///
    /// [pattern] може да биде `&str`, [`char`], парче [`char`] или функција или затворање што одредува дали карактерот се совпаѓа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Насоченост на текстот
    ///
    /// Низа е низа бајти.
    /// 'Right' во овој контекст значи последната позиција на таа низа бајти;за јазик како арапски или хебрејски кои се " десно од лево`отколку " лево надесно`, ова ќе биде _left_ страна, а не десно.
    ///
    ///
    /// # Examples
    ///
    /// Едноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Покомплексна шема, користејќи затворач:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Оваа парче жица се распарчува во друг вид.
    ///
    /// Бидејќи `parse` е толку општ, може да предизвика проблеми со заклучокот за типот.
    /// Како такво, `parse` е еден од ретките пати кога ќе ја видите синтаксата пријатно позната како 'turbofish': `::<>`.
    ///
    /// Ова му помага на алгоритмот за заклучок да разбере конкретно во кој тип се обидувате да анализирате.
    ///
    /// `parse` може да се анализира во било кој тип што го спроведува [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Returnе се врати [`Err`] ако не е можно да се анализира оваа низа во посакуваниот тип.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Основна употреба
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Користете 'turbofish' наместо да коментирате `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Не успеа да се анализира:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Проверува дали сите знаци во оваа низа се во опсегот ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Секој бајт можеме да го третираме како знак овде: сите мултибајтни карактери започнуваат со бајт што не е во опсегот на асии, па затоа веќе ќе застанеме тука.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Проверува дали две жици се нечувствителни на случајот ASCII.
    ///
    /// Исто како `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, но без распределување и копирање на современици.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ја преобразува оваа низа во свој еквивалент со големи букви ASCII.
    ///
    /// Буквите ASCII 'a' до 'z' се мапирани на 'A' до 'Z', но буквите што не се ASCII се непроменети.
    ///
    /// За да вратите нова голема големина без да ја измените постоечката, користете [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // БЕЗБЕДНОСТ: безбедно затоа што менуваме два вида со ист распоред.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ја преобразува оваа низа во ASCII мали букви во место.
    ///
    /// Буквите ASCII 'A' до 'Z' се мапирани на 'a' до 'z', но буквите што не се ASCII се непроменети.
    ///
    /// За да вратите нова помала вредност без да ја измените постојната, користете [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // БЕЗБЕДНОСТ: безбедно затоа што менуваме два вида со ист распоред.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Вратете повторувач што избега од секој знак во `self` со [`char::escape_debug`].
    ///
    ///
    /// Note: ќе бидат избегнати само продолжените графемски кодови кои ја започнуваат низата.
    ///
    /// # Examples
    ///
    /// Како повторувач:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Користење на `println!` директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// И двете се еквивалентни на:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Користење на `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Вратете повторувач што избега од секој знак во `self` со [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Како повторувач:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Користење на `println!` директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// И двете се еквивалентни на:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Користење на `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Вратете повторувач што избега од секој знак во `self` со [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Како повторувач:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Користење на `println!` директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// И двете се еквивалентни на:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Користење на `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Создава празна ул
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Создава празен непроменлив стр
    #[inline]
    fn default() -> Self {
        // БЕЗБЕДНОСТ: Празната низа е валидна UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Име, клониран тип fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // БЕЗБЕДНОСТ: не е безбедно
        unsafe { from_utf8_unchecked(bytes) }
    };
}