//! Дефинира тип на грешка utf8.

use crate::fmt;

/// Грешки што можат да се појават при обид да се толкува низа од [`u8`] како низа.
///
/// Како такво, семејството на функции и методи `from_utf8` ја користи оваа грешка, на пример, и за " String`и за " String`.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Методите на овој тип грешка може да се користат за да се создаде функционалност слична на `String::from_utf8_lossy` без да се распредели грамада меморија:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Го враќа индексот во дадената низа до која е потврдена валидна UTF-8.
    ///
    /// Тој е максимален индекс таков што `from_utf8(&input[..index])` би вратил `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::str;
    ///
    /// // некои невалидни бајти, во vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 враќа грешка на Utf8
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // вториот бајт не е валиден овде
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Обезбедува повеќе информации за неуспехот:
    ///
    /// * `None`: крајот на влезот беше постигнат неочекувано.
    ///   `self.valid_up_to()` е од 1 до 3 бајти од крајот на влезот.
    ///   Ако бајт-поток (како датотека или мрежен приклучок) се декодира постепено, ова може да биде валиден `char` чија секвенца бајт UTF-8 опфаќа повеќе парчиња.
    ///
    ///
    /// * `Some(len)`: се сретна неочекуван бајт.
    ///   Дадената должина е таа на невалидната бајтска низа што започнува со индексот даден од `valid_up_to()`.
    ///   Декодирањето треба да продолжи по таа низа (по вметнување на [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) во случај на декодирање со загуба.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Неуспешна грешка при парсирање на `bool` со употреба на [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}