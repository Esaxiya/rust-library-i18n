//! Имплементации на Trait за `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Спроведува нарачување на жици.
///
/// Стрингите се подредени [lexicographically](Ord#lexicographical-comparison) според нивните бајт-вредности.
/// Ова нарачува поени за кодот на Уникод врз основа на нивните позиции во табелите со кодови.
/// Ова не е нужно исто како и редоследот "alphabetical", кој варира според јазикот и локацијата.
/// Подредувањето на жиците според културно прифатените стандарди бара податоци специфични за локацијата што не се од опсегот на типот `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Спроведува операции за споредување на жици.
///
/// Стринговите се споредуваат [lexicographically](Ord#lexicographical-comparison) според нивните бајтни вредности.
/// Ова ги споредува кодовите на Уникод врз основа на нивните позиции во табелите со кодови.
/// Ова не е нужно исто како и редоследот "alphabetical", кој варира според јазикот и локацијата.
/// Споредувањето на жиците според културно прифатените стандарди бара податоци специфични за локацијата што не се во рамките на опсегот на типот `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Имплементира режење на подножје со синтакса `&self[..]` или `&mut self[..]`.
///
/// Враќа парче од целата низа, т.е. враќа `&self` или `&mut self`.Еквивалентно на `&себе [0 ..
/// len] `или`&mut сам [0 ..
/// len]`.
/// За разлика од другите операции на индексирање, ова никогаш не може да биде panic.
///
/// Оваа операција е *O*(1).
///
/// Пред 1.20.0, овие операции за индексирање сè уште беа поддржани со директна имплементација на `Index` и `IndexMut`.
///
/// Еквивалентно на `&self[0 .. len]` или `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Имплементира режење на подножје со синтакса `&self[begin .. end]` или `&mut self[begin .. end]`.
///
/// Враќа парче од дадената низа од опсегот на бајти [`почеток`, `end`).
///
/// Оваа операција е *O*(1).
///
/// Пред 1.20.0, овие операции за индексирање сè уште беа поддржани со директна имплементација на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics ако `begin` или `end` не укажува на почетниот бајт-неутрализирање на карактерот (како што е дефинирано со `is_char_boundary`), ако `begin > end` или ако `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // овие ќе panic:
/// // бајт 2 лежи во `ö`:
/// // &s [2 ..3];
///
/// // бајт 8 лежи во `老` и [1 ..
/// // 8];
///
/// // бајт 100 е надвор од низата&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: само проверете дали `start` и `end` се на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            // Исто така, ги проверивме границите на јагленот, така што ова важи UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: само проверете дали `start` и `end` се на граница на јаглен.
            // Знаеме дека покажувачот е единствен затоа што го добивме од `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗБЕДНОСТ: повикувачот гарантира дека `self` е во границите на `slice`
        // што ги исполнува сите услови за `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗБЕДНОСТ: видете ги коментарите за `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary проверува дали индексот е во [0, .len()] не може повторно да го користи `get` како погоре, поради проблеми со NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: само проверете дали `start` и `end` се на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Имплементира режење на подножје со синтакса `&self[.. end]` или `&mut self[.. end]`.
///
/// Враќа парче од дадената низа од опсегот на бајти [`0`, `end`).
/// Еквивалентно на `&self[0 .. end]` или `&mut self[0 .. end]`.
///
/// Оваа операција е *O*(1).
///
/// Пред 1.20.0, овие операции за индексирање сè уште беа поддржани со директна имплементација на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics ако `end` не укажува на почетниот бајт-неутрализирање на карактерот (како што е дефинирано од `is_char_boundary`), или ако `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: само провери дали `end` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: само провери дали `end` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: само провери дали `end` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Имплементира режење на подножје со синтакса `&self[begin ..]` или `&mut self[begin ..]`.
///
/// Враќа парче од дадената низа од опсегот на бајти [`почеток`, `len`).Еквивалентно на `&себе [започне ..
/// len] `или`&mut self [започне ..
/// len]`.
///
/// Оваа операција е *O*(1).
///
/// Пред 1.20.0, овие операции за индексирање сè уште беа поддржани со директна имплементација на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics ако `begin` не укажува на почетниот бајт-неутрализирање на карактерот (како што е дефинирано од `is_char_boundary`), или ако `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: само провери дали `start` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: само провери дали `start` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗБЕДНОСТ: повикувачот гарантира дека `self` е во границите на `slice`
        // што ги исполнува сите услови за `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗБЕДНОСТ: идентично со `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: само провери дали `start` е на граница на јаглен,
            // и ние поминуваме во безбедна референца, така што повратната вредност исто така ќе биде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Имплементира режење на подножје со синтакса `&self[begin ..= end]` или `&mut self[begin ..= end]`.
///
/// Враќа парче од дадената низа од опсегот на бајти [`begin`, `end`].Еквивалентно на `&self [begin .. end + 1]` или `&mut self[begin .. end + 1]`, освен ако `end` има максимална вредност за `usize`.
///
/// Оваа операција е *O*(1).
///
/// # Panics
///
/// Panics ако `begin` не укажува на почетниот бајт-неутрализирање на карактерот (како што е дефинирано со `is_char_boundary`), ако `end` не покажува на крајниот бајт-офсет на карактерот (`end + 1` е или почетен бајт-офсет или еднаков на `len`), ако `begin > end`, или ако `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Имплементира режење на подножје со синтакса `&self[..= end]` или `&mut self[..= end]`.
///
/// Враќа парче од дадената низа од опсегот на бајти [0, `end`].
/// Еквивалентно на `&self [0 .. end + 1]`, освен ако `end` има максимална вредност за `usize`.
///
/// Оваа операција е *O*(1).
///
/// # Panics
///
/// Panics ако `end` не укажува на крајниот бајт-офсет на карактерот (`end + 1` е или почетен бајт-неутрализиран како што е дефинирано со `is_char_boundary`, или е еднаков на `len`), или ако `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Разгради вредност од низа
///
/// Методот `FromStr` [`from_str`] често се користи имплицитно, преку методот [`parse`] на [str]].
/// Погледнете ја документацијата на ["парсирај"] за примери.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` нема параметар за цел живот и затоа можете да анализирате само типови што не содржат параметар за цел живот.
///
/// Со други зборови, можете да анализирате `i32` со `FromStr`, но не и `&i32`.
/// Може да анализирате структура што содржи `i32`, но не и таква што содржи `&i32`.
///
/// # Examples
///
/// Основна имплементација на `FromStr` на пример тип `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Поврзаната грешка што може да се врати од парсирање.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Разделува низа `s` за да врати вредност од овој тип.
    ///
    /// Ако парсирањето успее, вратете ја вредноста во [`Ok`], инаку кога низата е лошо форматирана, вратете грешка специфична за внатрешната [`Err`].
    /// Типот на грешка е специфичен за имплементација на trait.
    ///
    /// # Examples
    ///
    /// Основна употреба со [`i32`], тип што го спроведува `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Раздвојте `bool` од низа.
    ///
    /// Дава `Result<bool, ParseBoolError>`, бидејќи `s` може или не може да биде анализиран.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Забележете, во многу случаи, методот `.parse()` на `str` е посоодветен.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}