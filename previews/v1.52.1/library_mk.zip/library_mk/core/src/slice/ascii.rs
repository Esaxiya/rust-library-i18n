//! Операции на ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Проверува дали сите бајти во ова парче се во опсегот ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Проверува дали две парчиња се нечувствителни на случај ASCII.
    ///
    /// Исто како `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, но без распределување и копирање на современици.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Го преобразува ова парче во својот еквивалент со големи букви ASCII.
    ///
    /// Буквите ASCII 'a' до 'z' се мапирани на 'A' до 'Z', но буквите што не се ASCII се непроменети.
    ///
    /// За да вратите нова голема големина без да ја измените постоечката, користете [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Го преобразува ова парче во ASCII со мали букви во место.
    ///
    /// Буквите ASCII 'A' до 'Z' се мапирани на 'a' до 'z', но буквите што не се ASCII се непроменети.
    ///
    /// За да вратите нова помала вредност без да ја измените постојната, користете [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Враќа `true` ако има некој бајт во зборот `v` е ненаучен (>=128).
/// Snarfed од `../str/mod.rs`, што прави нешто слично за валидација на utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптимизиран тест ASCII што ќе користи операции за користење на време, наместо операции со бајт-на-едно време (кога е можно).
///
/// Алгоритмот што го користиме овде е прилично едноставен.Ако `s` е премногу краток, ние само го проверуваме секој бајт и завршуваме со него.Инаку:
///
/// - Прочитајте го првиот збор со ненаместен товар.
/// - Порамнете го покажувачот, прочитајте ги следните зборови до крај со порамнети оптоварувања.
/// - Прочитајте го последниот `usize` од `s` со ненаместен товар.
///
/// Ако некое од овие оптоварувања произведе нешто за што `contains_nonascii` (above) се враќа точно, тогаш знаеме дека одговорот е лажен.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ако не би добиле ништо од имплементацијата збор-на-едно време, вратете се на скаларна јамка.
    //
    // Ова го правиме и за архитектури каде `size_of::<usize>()` не е доволна усогласеност за `usize`, бидејќи тоа е чудна кутија edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ние секогаш го читаме првиот збор ненаместен, што значи дека `align_offset` е
    // 0, повторно би ја прочитале истата вредност за прочитаното подредено.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕЗБЕДНОСТ: Го потврдуваме `len < USIZE_SIZE` погоре.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ова го проверивме погоре, донекаде имплицитно.
    // Забележете дека `offset_to_aligned` е или `align_offset` или `USIZE_SIZE`, и двете се експлицитно проверени погоре.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕЗБЕДНОСТ: word_ptr е (правилно порамнет) термин за употреба што го користиме за читање на
    // средно парче парче.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` е индекс на бајти на `word_ptr`, кој се користи за проверки на крајот на јамката.
    let mut byte_pos = offset_to_aligned;

    // Параноја проверува за усогласување, бидејќи ние ќе направиме еден куп нерамнини товари.
    // Во пракса, ова би требало да биде невозможно да забрани грешка во `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Прочитајте ги следните зборови до последниот подреден збор, со исклучок на последниот подреден збор сам по себе, што треба да се направи во проверка на опашката подоцна, за да се осигурате дека опашката е секогаш најмногу `usize` до дополнителниот branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Разумност проверете дали читањето е во граници
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // И дека нашите претпоставки за `byte_pos` важат.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕЗБЕДНОСТ: Знаеме дека `word_ptr` е правилно порамнет (поради
        // `align_offset`), и знаеме дека имаме доволно бајти помеѓу `word_ptr` и крајот
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕЗБЕДНОСТ: Знаеме дека `byte_pos <= len - USIZE_SIZE`, што значи дека
        // по овој `add`, `word_ptr` ќе биде максимум од минатото.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Разумност проверете дали навистина останува само еден `usize`.
    // Ова треба да биде загарантирано од нашата состојба на јамка.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕЗБЕДНОСТ: Ова се потпира на `len >= USIZE_SIZE`, што го проверуваме на почетокот.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}