// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Го ротира опсегот `[mid-left, mid+right)` така што елементот на `mid` станува првиот елемент.Еквивалентно, ги ротира опсегот `left` елементи налево или `right` елементи надесно.
///
/// # Safety
///
/// Наведениот опсег мора да биде валиден за читање и пишување.
///
/// # Algorithm
///
/// Алгоритмот 1 се користи за мали вредности на `left + right` или за голем `T`.
/// Елементите се преместуваат во своите последни позиции едно по едно, почнувајќи од `mid - left` и напредувајќи се со модулот `right` чекори `left + right`, така што е потребен само еден привремен.
/// На крајот, пристигнуваме назад во `mid - left`.
/// Меѓутоа, ако `gcd(left + right, right)` не е 1, горенаведените чекори прескокнуваат над елементите.
/// На пример:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// За среќа, бројот на прескокнати елементи помеѓу финализираните елементи е секогаш еднаков, така што можеме само да ја надоместиме нашата почетна позиција и да направиме повеќе кругови (вкупниот број на кругови е `gcd(left + right, right)` value).
///
/// Крајниот резултат е дека сите елементи се финализираат еднаш и само еднаш.
///
/// Алгоритмот 2 се користи ако `left + right` е голем, но `min(left, right)` е доволно мал за да се смести во баферот за стек.
/// Елементите `min(left, right)` се копираат на тампон, `memmove` се нанесува на другите, а оние на тампон се преместуваат назад во дупката од спротивната страна од каде што потекнуваа.
///
/// Алгоритмите што можат да се векторизираат го надминуваат горенаведеното откако `left + right` стане доволно голем.
/// Алгоритмот 1 може да се векторизира со парчиња и изведување на многу круга одеднаш, но има премногу малку кругови во просек се додека `left + right` не биде огромен, а најлошата состојба на еден круг е секогаш таму.
/// Наместо тоа, алгоритмот 3 користи повторено разменување на `min(left, right)` елементи сè додека не се остави помал проблем со ротирање.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// кога `left < right` наместо тоа, замена се случува од лево.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. подолу алгоритмите можат да пропаднат ако овие случаи не се проверат
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Микроценки за алгоритам 1 укажуваат на тоа дека просечната изведба за случајни смени е подобра сè до околу `left + right == 32`, но најлошата изведба се распаѓа дури околу 16 години.
            // 24 беше избран за средно решение.
            // Ако големината на `T` е поголема од 4 `употреба`, овој алгоритам исто така ги надминува и другите алгоритми.
            //
            //
            let x = unsafe { mid.sub(left) };
            // почеток на првиот круг
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` може да се најде пред рака со пресметување на `gcd(left + right, right)`, но побрзо е да се направи една јамка која го пресметува gcd како несакан ефект, а потоа да го направи остатокот од парчето
            //
            //
            let mut gcd = right;
            // одредниците откриваат дека е побрзо да се разменуваат современиците до крај, наместо еднаш да се прочита една привремена, да се копира наназад, а потоа да се напише привремено на самиот крај.
            // Ова е веројатно како резултат на фактот дека заменувањето или заменувањето на современиците користи само една мемориска адреса во јамката наместо да треба да управува со две.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // наместо да го зголемуваме `i` и потоа да провериме дали е надвор од границите, проверуваме дали `i` ќе излезе надвор од границите на следното зголемување.
                // Ова спречува какво било завиткување на покажувачи или `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // крај на првиот круг
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // овој условен мора да биде тука ако `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // завршете го парчето со повеќе кругови
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` не е тип на нула големина, па затоа е во ред да се подели со нејзината големина.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритам 2 `[T; 0]` тука е да се осигура дека ова е соодветно порамнето за Т.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритам 3 Постои алтернативен начин на замена што вклучува наоѓање каде ќе биде последната размена на овој алгоритам и замена со користење на последното парче наместо замена на соседните парчиња како што прави овој алгоритам, но овој начин е сè уште побрз.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритам 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}