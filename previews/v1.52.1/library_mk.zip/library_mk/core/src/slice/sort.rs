//! Сортирање парчиња
//!
//! Овој модул содржи алгоритам за сортирање заснован на живиот поредок за пораз на Орсон Питерс, објавен на: <https://github.com/orlp/pdqsort>
//!
//!
//! Нестабилното сортирање е компатибилно со libcore затоа што не распределува меморија, за разлика од нашата стабилна имплементација на сортирање.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Кога паѓа, копирајте од `src` во `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЕЗБЕДНОСТ: Ова е класа помошници.
        //          Погледнете ја неговата употреба за исправност.
        //          Имено, мора да се биде сигурен дека `src` и `dst` не се преклопуваат како што бара `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Првиот елемент го поместува надесно сè додека не наиде на поголем или еднаков елемент.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗБЕДНОСТ: Небезбедните операции подолу вклучуваат индексирање без врзана проверка (`get_unchecked` и `get_unchecked_mut`)
    // и копирање на меморијата (`ptr::copy_nonoverlapping`).
    //
    // аИндексирање:
    //  1. Ја проверивме големината на низата до>=2.
    //  2. Сето индексирање што ќе го направиме е секогаш помеѓу {0 <= index < len} најмногу.
    //
    // бКопирање на меморијата
    //  1. Добиваме показатели за препораките за кои се гарантира дека се валидни.
    //  2. Тие не можат да се преклопуваат бидејќи добиваме показатели за индексите на разлика на парчето.
    //     Имено, `i` и `i-1`.
    //  3. Ако парчето е правилно порамнето, елементите се правилно порамнети.
    //     Одговорност на повикувачот е да се осигура дека парчето е правилно порамнето.
    //
    // Погледнете ги коментарите подолу за повеќе детали.
    unsafe {
        // Ако првите два елементи не се во функција ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Прочитајте го првиот елемент во променлива распределена на стек.
            // Ако следната операција за споредба panics, `hole` ќе падне и автоматски ќе го напише елементот повторно во парчето.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Поместете го `i`-тиот елемент едно место налево, со што ќе ја поместите дупката надесно.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` паѓа и со тоа копира `tmp` во преостанатата дупка во `v`.
        }
    }
}

/// Го поместува последниот елемент налево додека не наиде на помал или еднаков елемент.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗБЕДНОСТ: Небезбедните операции подолу вклучуваат индексирање без врзана проверка (`get_unchecked` и `get_unchecked_mut`)
    // и копирање на меморијата (`ptr::copy_nonoverlapping`).
    //
    // аИндексирање:
    //  1. Ја проверивме големината на низата до>=2.
    //  2. Сето индексирање што ќе го направиме е секогаш помеѓу `0 <= index < len-1` најмногу.
    //
    // бКопирање на меморијата
    //  1. Добиваме показатели за препораките за кои се гарантира дека се валидни.
    //  2. Тие не можат да се преклопуваат бидејќи добиваме показатели за индексите на разлика на парчето.
    //     Имено, `i` и `i+1`.
    //  3. Ако парчето е правилно порамнето, елементите се правилно порамнети.
    //     Одговорност на повикувачот е да се осигура дека парчето е правилно порамнето.
    //
    // Погледнете ги коментарите подолу за повеќе детали.
    unsafe {
        // Ако последните два елементи не се во функција ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Прочитајте го последниот елемент во променлива распределена на стек.
            // Ако следната операција за споредба panics, `hole` ќе падне и автоматски ќе го напише елементот повторно во парчето.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Поместете го " i`-ниот елемент едно место надесно, со што ќе ја поместите дупката налево.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` паѓа и со тоа копира `tmp` во преостанатата дупка во `v`.
        }
    }
}

/// Делумно сортира парче со поместување на неколку вонредни елементи наоколу.
///
/// Враќа `true` ако парчето е подредено на крајот.Оваа функција е *O*(*n*) во најлош случај.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Максимален број на соседни парови надвор од ред што ќе бидат поместени.
    const MAX_STEPS: usize = 5;
    // Ако парчето е пократко од ова, не менувајте елементи.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЕЗБЕДНОСТ: Ние веќе експлицитно извршивме проверка на врзаните со `i < len`.
        // Целокупното наше следно индексирање е само во опсегот `0 <= index < len`
        unsafe {
            // Пронајдете го следниот пар соседни елементи од ред.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Дали сме готови?
        if i == len {
            return true;
        }

        // Не менувајте елементи на кратки низи, што има цена на изведба.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Заменете го пронајдениот пар елементи.Ова ги става во правилен редослед.
        v.swap(i - 1, i);

        // Поместете го помалиот елемент налево.
        shift_tail(&mut v[..i], is_less);
        // Префрлете го поголемиот елемент надесно.
        shift_head(&mut v[i..], is_less);
    }

    // Не успеав да го сортирам парчето во ограничениот број чекори.
    false
}

/// Подредува парче користејќи вид на вметнување, што е *O*(*n*^ 2) во најлош случај.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Подредува `v` со користење на сеопфатен вид, што гарантира *O*(*n*\*log(* n*)) во најлош случај.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Оваа бинарна града го почитува непроменливиот `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Деца од `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Изберете поголемо дете.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Запрете ако непроменливата важи на `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Заменете го `node` со поголемото дете, движете се чекор погоре и продолжете со просејување.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Изградете ја грамадата во линеарно време.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Поп максимални елементи од грамада.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Партиции `v` во елементи помали од `pivot`, проследени со елементи поголеми или еднакви на `pivot`.
///
///
/// Го враќа бројот на елементи помали од `pivot`.
///
/// Поделбата се изведува блок-по-блок со цел да се минимизираат трошоците за операциите на разгранување.
/// Оваа идеја е претставена во трудот [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Број на елементи во типичен блок.
    const BLOCK: usize = 128;

    // Алгоритмот за поделба ги повторува следните чекори до завршувањето:
    //
    // 1. Проследете блок од левата страна за да идентификувате елементи поголеми или еднакви на стожерот.
    // 2. Проследете блок од десната страна за да идентификувате елементи помали од стожерот.
    // 3. Разменете ги идентификуваните елементи помеѓу левата и десната страна.
    //
    // Ги чуваме следниве варијабли за блок елементи:
    //
    // 1. `block` - Број на елементи во блокот.
    // 2. `start` - Започнете го покажувачот во низата `offsets`.
    // 3. `end` - Завршете го покажувачот во низата `offsets`.
    // 4. `неутрализирање, Индекси на вонредни елементи во блокот.

    // Тековниот блок од левата страна (од `l` до `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Тековниот блок од десната страна (од `r.sub(block_r)` to `r`).
    // БЕЗБЕДНОСТ: Во документацијата за .add() конкретно се споменува дека `vec.as_ptr().add(vec.len())` е секогаш безбеден`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Кога ќе добиеме VLA, обидете се да создадете повеќе низа со должина `min(v.len(), 2 * BLOCK) `
    // од две низи со фиксна големина со должина `BLOCK`.VLA може да бидат поефикасни во мемориската меморија.

    // Го враќа бројот на елементи помеѓу покажувачите `l` (inclusive) и `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Завршивме со поделба блок-по-блок кога `l` и `r` се приближуваат.
        // Потоа, ние правиме некоја работа за крпење со цел да ги поделиме преостанатите елементи помеѓу нив.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Број на преостанати елементи (сè уште не се споредуваат со стожерот).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Прилагодете ги големините на блокот така што левиот и десниот блок не се преклопуваат, туку совршено порамнете се за да го покриете целиот преостанат јаз.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Трагајте ги елементите `block_l` од левата страна.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЕЗБЕДНОСТ: Несигурните операции подолу вклучуваат употреба на `offset`.
                //         Според условите што ги бара функцијата, ги задоволуваме затоа што:
                //         1. `offsets_l` е распределен од магацинот, а со тоа се смета за посебен распределен објект.
                //         2. Функцијата `is_less` враќа `bool`.
                //            Лиењето `bool` никогаш нема да се прелее `isize`.
                //         3. Ние гарантиравме дека `block_l` ќе биде `<= BLOCK`.
                //            Плус, `end_l` првично беше поставен на почетниот покажувач на `offsets_`, кој беше деклариран на оџакот.
                //            Така, знаеме дека дури и во најлош случај (сите повици на `is_less` се враќаат лажни) ќе бидеме само 1 бајт на крајот.
                //        Друга операција за небезбедност овде е деференцирање на `elem`.
                //        Сепак, `elem` првично беше почетниот покажувач кон парчето кое е секогаш валидно.
                unsafe {
                    // Споредба без гранки.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Трагирајте ги елементите `block_r` од десната страна.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЕЗБЕДНОСТ: Несигурните операции подолу вклучуваат употреба на `offset`.
                //         Според условите што ги бара функцијата, ги задоволуваме затоа што:
                //         1. `offsets_r` е распределен од магацинот, а со тоа се смета за посебен распределен објект.
                //         2. Функцијата `is_less` враќа `bool`.
                //            Лиењето `bool` никогаш нема да се прелее `isize`.
                //         3. Ние гарантиравме дека `block_r` ќе биде `<= BLOCK`.
                //            Плус, `end_r` првично беше поставен на почетниот покажувач на `offsets_`, кој беше деклариран на оџакот.
                //            Така, знаеме дека дури и во најлош случај (сите повици на `is_less` се враќаат точно) ќе бидеме само 1 бајт на крајот.
                //        Друга операција за небезбедност овде е деференцирање на `elem`.
                //        Сепак, `elem` првично беше `1 *sizeof(T)` покрај крајот и го намаливме за `1* sizeof(T)` пред да пристапиме до него.
                //        Плус, се тврди дека `block_r` е помал од `BLOCK` и `elem` најмногу ќе укажува на почетокот на парчето.
                unsafe {
                    // Споредба без гранки.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Број на вон ред елементи за замена помеѓу левата и десната страна.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Наместо да менувате еден пар во тоа време, поефикасно е да се изврши циклична пермутација.
            // Ова не е строго еквивалентно на замена, но произведува сличен резултат користејќи помалку операции на меморија.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Сите вон ред елементи во левиот блок беа преместени.Преместете се на следниот блок.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Сите вон ред елементи во десниот блок беа преместени.Преместете се во претходниот блок.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Сè што останува сега е најмногу еден блок (или лево или десно) со вон ред елементи што треба да се преместат.
    // Таквите преостанати елементи може едноставно да се пренесат на крај во рамките на нивниот блок.
    //

    if start_l < end_l {
        // Левиот блок останува.
        // Поместете ги неговите преостанати вонредени елементи крајно десно.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Останува десниот блок.
        // Поместете ги неговите преостанати вонредени елементи крајно лево.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ништо друго да се направи, ние завршивме.
        width(v.as_mut_ptr(), l)
    }
}

/// Партиции `v` во елементи помали од `v[pivot]`, проследени со елементи поголеми или еднакви на `v[pivot]`.
///
///
/// Враќа парче од:
///
/// 1. Број на елементи помали од `v[pivot]`.
/// 2. Точно ако `v` веќе беше партициониран.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Ставете го стожерот на почетокот на парчето.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Прочитајте го стожерот во променлива распределена на стек за ефикасност.
        // Ако следната операција за споредување panics, стожерот автоматски ќе биде запишан во парчето.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Пронајдете го првиот пар елементи од ред.
        let mut l = 0;
        let mut r = v.len();

        // БЕЗБЕДНОСТ: Несигурноста подолу вклучува индексирање на низа.
        // За првиот: Ние веќе ги проверуваме границите тука со `l < r`.
        // За второто: Првично имаме `l == 0` и `r == v.len()` и го проверувавме тој `l < r` на секоја операција за индексирање.
        //                     Оттука знаеме дека `r` мора да биде барем `r == l`, за што се покажа дека е валидно од првиот.
        unsafe {
            // Пронајдете го првиот елемент поголем или еднаков на стожерот.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Пронајдете го последниот елемент помал од стожерот.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` излегува од опсегот и го запишува стожерот (што е променлива доделена на стек) назад во парчето каде што првично беше.
        // Овој чекор е клучен за обезбедување на безбедност!
        //
    };

    // Поставете го стожерот помеѓу двете партиции.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Партиции `v` во елементи еднакви на `v[pivot]` проследени со елементи поголеми од `v[pivot]`.
///
/// Враќа на бројот на елементи еднакви на стожерот.
/// Се претпоставува дека `v` не содржи елементи помали од стожерот.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ставете го стожерот на почетокот на парчето.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Прочитајте го стожерот во променлива распределена на стек за ефикасност.
    // Ако следната операција за споредување panics, стожерот автоматски ќе биде запишан во парчето.
    // БЕЗБЕДНОСТ: Покажувачот овде е валиден бидејќи е добиен од упатување на парче.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Сега поделете го парчето.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЕЗБЕДНОСТ: Несигурноста подолу вклучува индексирање на низа.
        // За првиот: Ние веќе ги проверуваме границите тука со `l < r`.
        // За второто: Првично имаме `l == 0` и `r == v.len()` и го проверувавме тој `l < r` на секоја операција за индексирање.
        //                     Оттука знаеме дека `r` мора да биде барем `r == l`, за што се покажа дека е валидно од првиот.
        unsafe {
            // Пронајдете го првиот елемент поголем од стожерот.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Пронајдете го последниот елемент еднаков на стожерот.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Дали сме готови?
            if l >= r {
                break;
            }

            // Заменете го пронајдениот пар елементи од ред.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Најдовме `l` елементи еднакви на стожерот.Додадете 1 на сметка за самиот стожер.
    l + 1

    // `_pivot_guard` излегува од опсегот и го запишува стожерот (што е променлива доделена на стек) назад во парчето каде што првично беше.
    // Овој чекор е клучен за обезбедување на безбедност!
}

/// Распрснува некои елементи наоколу во обид да ги разбие обрасците што можат да предизвикаат нерамнотежни партиции во quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератор на псевдорандом број од хартијата "Xorshift RNGs" од Georgeорџ Марсаagа.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Земете го модулот по случаен избор на броеви.
        // Бројот се вклопува во `usize` затоа што `len` не е поголем од `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Некои стожерни кандидати ќе бидат во близина на овој индекс.Ајде да ги рандомизираме.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Генерирајте модул со случаен број `len`.
            // Сепак, за да избегнеме скапи операции, прво го земаме модулот со моќност од два, а потоа се намалуваме за `len` додека не се вклопи во опсегот `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` се гарантира дека е помал од `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Избира стожер во `v` и ги враќа индексот и `true` ако парчето е веројатно веќе подредено.
///
/// Елементите во `v` може да бидат прередени во процесот.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Минимална должина за избор на метод на просек на просек.
    // Пократките парчиња го користат едноставниот метод средно на три.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Максимален број на размени што можат да се извршат во оваа функција.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Три индекси во близина на кои ќе избереме стожер.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Го брои вкупниот број размени што ќе ги извршиме при сортирање на индекси.
    let mut swaps = 0;

    if len >= 8 {
        // Разменува индекси така што `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Разменува индекси така што `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Ја наоѓа средната вредност на `v[a - 1], v[a], v[a + 1]` и го зачувува индексот во `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Пронајдете медијани во населбите `a`, `b` и `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Пронајдете ја средната вредност помеѓу `a`, `b` и `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Извршен е максималниот број на размени.
        // Шансите се дека парчето опаѓа или претежно опаѓа, така што свртувањето веројатно ќе помогне во побрзо подредување.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Подредува `v` рекурзивно.
///
/// Ако парчето има претходник во оригиналната низа, тоа е наведено како `pred`.
///
/// `limit` е бројот на дозволени нерамнотежни партиции пред да се префрлите на `heapsort`.
/// Ако е нула, оваа функција веднаш ќе се префрли на групно сортирање.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Парчињата до оваа должина се сортираат со помош на сортирање на вметнување.
    const MAX_INSERTION: usize = 20;

    // Точно ако последната партиција беше разумно избалансирана.
    let mut was_balanced = true;
    // Точно, ако последната партиција не ги мешаше елементите (парчето беше веќе разделено).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Многу кратки парчиња се сортираат со помош на сортирање на вметнување.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Доколку се направени премногу лоши главни избори, едноставно вратете се на горниот избор за да се гарантира `O(n * log(n))` во најлош случај.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ако последната партиција беше неурамнотежена, обидете се да ги разбиете моделите во парчето, мешајќи некои елементи наоколу.
        // Се надеваме дека ќе избереме подобар стожер овој пат.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Изберете стожер и обидете се да погодите дали парчето е веќе подредено.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ако последната партиција беше пристојно избалансирана и не ги мешаше елементите, и ако изборот на стожер предвидува дека парчето е веројатно веќе подредено ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Обидете се да идентификувате неколку вон ред елементи и да ги префрлите на исправни позиции.
            // Ако парчето заврши целосно подредено, готово е.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ако избраниот стожер е еднаков на претходникот, тогаш тоа е најмалиот елемент во парчето.
        // Поделете го парчето во елементи еднакви на и елементи поголеми од стожерот.
        // Овој случај обично се погодува кога парчето содржи многу дупликати елементи.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Продолжете со сортирање на елементи поголеми од стожерот.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Поделете го парчето.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Поделете го парчето на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Вратете се во пократката страна само со цел да го минимизирате вкупниот број на рекурзивни повици и да потрошите помалку простор за магацинот.
        // Потоа, само продолжете со подолгата страна (ова е слично на повторување на опашката).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Подредува `v` со користење на уникатен модел за пораз на шеми, што е *O*(*n*\*log(* n*)) во најлош случај.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Подредувањето нема значајно однесување кај типовите со нула големина.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ограничете го бројот на неурамнотежени партиции на `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // За парчиња до оваа должина веројатно е побрзо едноставно да ги сортирате.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Изберете стожер
        let (pivot, _) = choose_pivot(v, is_less);

        // Ако избраниот стожер е еднаков на претходникот, тогаш тоа е најмалиот елемент во парчето.
        // Поделете го парчето во елементи еднакви на и елементи поголеми од стожерот.
        // Овој случај обично се погодува кога парчето содржи многу дупликати елементи.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ако го поминавме нашиот индекс, тогаш сме добри.
                if mid > index {
                    return;
                }

                // Во спротивно, продолжете со сортирање на елементи поголеми од стожерот.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Поделете го парчето на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ако средината==индекс, тогаш завршивме, бидејќи partition() гарантираше дека сите елементи по средината се поголеми или еднакви на средината.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Подредувањето нема значајно однесување кај типовите со нула големина.Не прави ништо.
    } else if index == v.len() - 1 {
        // Пронајдете максимум елемент и ставете го на последната позиција од низата.
        // Ние сме слободни да користиме `unwrap()` тука затоа што знаеме дека v не смее да биде празно.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Пронајдете мин елемент и ставете го на првата позиција од низата.
        // Ние сме слободни да користиме `unwrap()` тука затоа што знаеме дека v не смее да биде празно.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}