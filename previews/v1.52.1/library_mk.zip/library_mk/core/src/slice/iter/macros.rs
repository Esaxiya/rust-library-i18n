//! Макроа користени од повторувачи на парчиња.

// Вметнувањето е_празно и лен прави огромна разлика во перформансите
macro_rules! is_empty {
    // Начинот на кој ја кодираме должината на повторувачот на ZST, ова работи и за ZST и за не-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// За да се ослободиме од некои проверки на границите (види `position`), ја пресметуваме должината на малку неочекуван начин.
// (Тестирано со " проверка на кодеген/парче-позиција-граници`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // понекогаш сме користени во небезбеден блок

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Овој _cannot_ користи `unchecked_sub` затоа што зависиме од завиткување за да ја претставуваме должината на долгите повторувачи на парчиња ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Ние знаеме дека `start <= end`, така може да се направи подобро од `offset_from`, кој треба да се справи потпишан.
            // Со поставување соодветни знамиња тука можеме да му го кажеме на LLVM ова, што му помага да ги отстрани проверките на границите.
            // БЕЗБЕДНОСТ: Според типот непроменлива, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Исто така, кажувајќи му на LLVM дека покажувачите се одделени со точно множество од големината на типот, тој може да го оптимизира `len() == 0` до `start == end` наместо `(end - start) < size`.
            //
            // БЕЗБЕДНОСТ: Според типот непроменлива, покажувачите се порамнети така што
            //         растојанието меѓу нив мора да биде повеќекратно од големината на обединетиот
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Заедничката дефиниција на повторувачите `Iter` и `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Го враќа првиот елемент и го поместува почетокот на повторувачот за 1 напред.
        // Во голема мера ги подобрува перформансите во споредба со вградената функција.
        // Повторувачот не смее да биде празен.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Го враќа последниот елемент и го поместува крајот на повторувачот за 1 назад.
        // Во голема мера ги подобрува перформансите во споредба со вградената функција.
        // Повторувачот не смее да биде празен.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Го намалува повторувачот кога Т е ZST, со поместување на крајот на повторувачот наназад за `n`.
        // `n` не смее да надминува `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Функција на помошник за создавање парче од повторувачот.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕЗБЕДНОСТ: повторувачот е создаден од парче со покажувач
                // `self.ptr` и должина `len!(self)`.
                // Ова гарантира дека се исполнети сите предуслови за `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Функција на помошник за поместување на почетокот на повторувачот за `offset` елементи, враќајќи го стариот почеток.
            //
            // Небезбеден затоа што поместувањето не смее да надминува `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕЗБЕДНОСТ: повикувачот гарантира дека `offset` не надминува `self.len()`,
                    // така што овој нов покажувач е во `self` и со тоа се гарантира дека не е ништовен.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Функција на помошник за поместување на крајот на повторувачот наназад за `offset` елементи, враќајќи го новиот крај.
            //
            // Небезбеден затоа што поместувањето не смее да надминува `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕЗБЕДНОСТ: повикувачот гарантира дека `offset` не надминува `self.len()`,
                    // што е загарантирано дека нема да прелее `isize`.
                    // Исто така, добиениот покажувач е во граници на `slice`, што ги исполнува другите барања за `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // може да се спроведе со парчиња, но ова избегнува проверки на границите

                // БЕЗБЕДНОСТ: Повиците `assume` се безбедни бидејќи покажувачот за стартување на парче е
                // мора да биде не-нулта, а парчињата над не-ZST-ови исто така мора да имаат не-нулта завршен покажувач.
                // Повикот кон `next_unchecked!` е безбеден бидејќи проверуваме дали повторувачот е празен.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Овој повторувач сега е празен.
                    if mem::size_of::<T>() == 0 {
                        // Ние мора да го сториме тоа на овој начин, бидејќи `ptr` можеби никогаш нема да биде 0, но `end` може да биде (поради завиткување).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕЗБЕДНОСТ: крајот не може да биде 0 ако T не е ZST затоа што ptr не е 0 и крај>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕЗБЕДНОСТ: Ние сме во граници.`post_inc_start` ја прави вистинската работа дури и за ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            // Исто така, `assume` избегнува проверка на границите.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕЗБЕДНОСТ: гарантирано е дека сме во граници од јамката непроменлива:
                        // кога `i >= n`, `self.next()` враќа `None` и јамката се распаѓа.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ние ја надминуваме стандардната имплементација, која користи `try_fold`, бидејќи оваа едноставна имплементација генерира помалку LLVM IR и побрзо се составува.
            // Исто така, `assume` избегнува проверка на границите.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕЗБЕДНОСТ: `i` мора да биде понизок од `n` бидејќи започнува од `n`
                        // и само се намалува.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕЗБЕДНОСТ: повикувачот мора да гарантира дека `i` е во граници
                // основната парче, така што `i` не може да прелее `isize`, а вратените референци се гарантира дека се однесуваат на елемент на парчето и со тоа се гарантира дека се валидни.
                //
                // Исто така, забележете дека повикувачот гарантира и дека никогаш повеќе не сме повикани со ист индекс и дека не се повикуваат други методи што ќе пристапат до ова подмножество, па затоа важи за вратената референца да биде променлива во случај на
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // може да се спроведе со парчиња, но ова избегнува проверки на границите

                // БЕЗБЕДНОСТ: Повиците `assume` се безбедни бидејќи покажувачот за почеток на парче мора да не е ништовен,
                // и парчињата над ZST не мора да имаат и нулта завршен покажувач.
                // Повикот кон `next_back_unchecked!` е безбеден бидејќи проверуваме дали повторувачот е празен.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Овој повторувач сега е празен.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕЗБЕДНОСТ: Ние сме во граници.`pre_dec_end` ја прави вистинската работа дури и за ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}