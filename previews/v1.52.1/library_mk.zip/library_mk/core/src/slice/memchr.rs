// Оригиналната имплементација е преземена од rust-memchr.
// Авторски права 2015 Ендру Галант, рубрика и Николас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Користете скратување.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Враќа `true` ако `x` содржи нула бајт.
///
/// Од *Matters Computational*, J. Arndt:
///
/// " Идејата е да се одземе по еден од секој бајт и потоа да се бараат бајти каде позајмицата се шири до најзначајните
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Го враќа првиот индекс што одговара на бајтот `x` во `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Брза патека за мали парчиња
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Скенирајте единствена бајт вредност со читање на два збора `usize` истовремено.
    //
    // Сплит `text` на три дела
    // - ненаместен почетен дел, пред адресата порачана на првиот збор во текст
    // - тело, скенирај со 2 зборови истовремено
    // - последниот преостанат дел, <2 големина на зборот

    // пребарување до усогласена граница
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // пребарување на телото на текстот
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЕЗБЕДНОСТ: предикатот на while гарантира растојание од најмалку 2 * кориснички_бајти
        // помеѓу поместувањето и крајот на парчето.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // пауза ако има бајт што одговара
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Пронајдете бајт откако точката ќе запре јамката на телото.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Го враќа последниот индекс што одговара на бајтот `x` во `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Скенирајте единствена бајт вредност со читање на два збора `usize` истовремено.
    //
    // Сплит `text` во три дела:
    // - ненагласена опашка, по пораката порачана во текстот,
    // - тело, скенирано од 2 збора истовремено,
    // - првите преостанати бајти, <2 големина на зборот.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ова го нарекуваме само за да се добие должината на префиксот и наставката.
        // Во средина секогаш обработуваме две парчиња одеднаш.
        // БЕЗБЕДНОСТ: трансмутирањето на `[u8]` на `[usize]` е безбедно, освен за разликите во големината со кои управува `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Пребарувајте во телото на текстот, проверете дали не преминуваме min_aligned_offset.
    // поместувањето е секогаш подредено, така што само тестирањето на `>` е доволно и се избегнува можно прелевање.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЕЗБЕДНОСТ: надоместувањето започнува од лен, suffix.len(), се додека е поголемо од
        // min_aligned_offset (prefix.len()) преостанатото растојание е најмалку 2 * парчиња_бајти.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Скршете ако има бајт што се совпаѓа.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Пронајдете бајт пред да престане јамката на телото.
    text[..offset].iter().rposition(|elt| *elt == x)
}