//! Атомски типови
//!
//! Атомските типови обезбедуваат примитивна комуникација со заедничка меморија помеѓу нишките и се градежни блокови на другите истовремени типови.
//!
//! Овој модул ги дефинира атомските верзии на избран број примитивни типови, вклучително и [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], итн.
//! Атомските типови претставуваат операции кои, кога се користат правилно, ги синхронизираат ажурирањата помеѓу нишките.
//!
//! Секој метод зема [`Ordering`] што претставува јачина на бариерата на меморијата за таа операција.Овие нарачки се исти како [C++20 atomic orderings][1].За повеќе информации, видете го [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Атомските променливи се безбедни за споделување помеѓу нишките (тие спроведуваат [`Sync`]), но тие самите не обезбедуваат механизам за споделување и го следат [threading model](../../../std/thread/index.html#the-threading-model) на Rust.
//!
//! Најчестиот начин за споделување на атомска променлива е да се стави во [`Arc`][arc] (споделен покажувач со броење на атомски референци).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Атомските типови може да се складираат во статички променливи, иницијализирани со употреба на постојани иницијализатори како [`AtomicBool::new`].Атомската статика често се користи за мрзлива глобална иницијализација.
//!
//! # Portability
//!
//! Сите атомски типови во овој модул се гарантираат да бидат [lock-free] доколку се достапни.Ова значи дека тие внатрешно не стекнуваат глобален мутекс.Атомските типови и операции не се гарантира дека немаат чекање.
//! Ова значи дека операциите како `fetch_or` може да се имплементираат со јамка за споредба и размена.
//!
//! Атомските операции може да се спроведат во слојот со инструкции со атомика со поголема големина.На пример, некои платформи користат 4-бајтни атомски инструкции за спроведување на `AtomicI8`.
//! Имајте на ум дека оваа емулација не треба да има влијание врз правилноста на кодот, тоа е само нешто за кое треба да бидете свесни.
//!
//! Атомските типови во овој модул можеби не се достапни на сите платформи.Атомските типови овде се широко достапни и, генерално, може да се потпрат на постојните.Некои забележителни исклучоци се:
//!
//! * PowerPC и MIPS платформите со 32-битни покажувачи немаат типови `AtomicU64` или `AtomicI64`.
//! * ARM платформите како `armv5te` кои не се за Linux обезбедуваат само операции `load` и `store` и не поддржуваат операции споредба и размена на (CAS), како што се `swap`, `fetch_add` итн.
//! Дополнително на Linux, овие операции на CAS се спроведуваат преку [operating system support], што може да се појави со казна за изведба.
//! * ARM целите со `thumbv6m` обезбедуваат само операции `load` и `store` и не поддржуваат операции Споредба и размена на (CAS), како што се `swap`, `fetch_add`, итн.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Забележете дека платформите future може да се додадат кои исто така немаат поддршка за некои атомски операции.Максимално преносливиот код ќе сака да внимава на тоа кои атомски типови се користат.
//! `AtomicUsize` и `AtomicIsize` се генерално најпреносливи, но и тогаш не се достапни насекаде.
//! За повикување, библиотеката `std` бара атомија со големина на покажувачот, иако `core` не.
//!
//! Во моментов ќе треба да користите `#[cfg(target_arch)]` првенствено за условно компајлирање во код со атомика.Исто така, постои нестабилен `#[cfg(target_has_atomic)]`, кој може да се стабилизира во future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Едноставен спин-блок:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Почекајте другата нишка да ја ослободи бравата
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Задржете глобален број на жици во живо:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Буловски тип што може безбедно да се сподели помеѓу нишките.
///
/// Овој тип ја има истата претстава во меморијата како [`bool`].
///
/// **Белешка**: Овој тип е достапен само на платформи кои поддржуваат атомски товари и продавници на `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Создава `AtomicBool` иницијализиран на `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Испраќањето е имплицитно имплементирано за AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Суров тип на покажувач кој може безбедно да се сподели помеѓу нишките.
///
/// Овој тип ја има истата претстава во меморијата како `*mut T`.
///
/// **Белешка**: Овој тип е достапен само на платформи кои поддржуваат атомски оптоварувања и зачувувања на покажувачи.
/// Неговата големина зависи од големината на целниот покажувач.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Создава нула `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Нарачки на атомска меморија
///
/// Подредувањата на меморијата го одредуваат начинот на кој атомските операции ја синхронизираат меморијата.
/// Во најслабиот [`Ordering::Relaxed`], синхронизирана е само меморијата што директно ја допира операцијата.
/// Од друга страна, пар за складирање операции [`Ordering::SeqCst`] ја синхронизираат другата меморија додека дополнително се зачувува целосниот редослед на таквите операции низ сите нишки.
///
///
/// Нарачките на меморијата на Rust се [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// За повеќе информации, видете го [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Без ограничувања на нарачки, само атомски операции.
    ///
    /// Одговара на [`memory_order_relaxed`] во C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Кога се заедно со продавница, сите претходни операции стануваат нарачани пред какво било оптоварување со оваа вредност со нарачка [`Acquire`] (или посилна).
    ///
    /// Особено, сите претходни записи стануваат видливи за сите нишки што вршат [`Acquire`] (или посилно) оптоварување со оваа вредност.
    ///
    /// Забележете дека користењето на оваа нарачка за операција што комбинира товари и зачувувања доведува до операција со оптоварување [`Relaxed`]!
    ///
    /// Оваа нарачка е применлива само за операции што можат да извршат продавница.
    ///
    /// Одговара на [`memory_order_release`] во C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Кога е во комбинација со товар, ако вчитаната вредност е напишана од продавница со нарачка [`Release`] (или посилна), тогаш сите последователни операции стануваат нарачани по таа продавница.
    /// Особено, сите последователни оптоварувања ќе видат податоци напишани пред продавницата.
    ///
    /// Забележете дека користењето на оваа нарачка за операција што комбинира товари и продавници доведува до операција на продавница [`Relaxed`]!
    ///
    /// Ова нарачување е применливо само за операции што можат да извршат оптоварување.
    ///
    /// Одговара на [`memory_order_acquire`] во C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Има ефекти и на [`Acquire`] и на [`Release`] заедно:
    /// За оптоварувања користи нарачка [`Acquire`].За продавници користи нарачка [`Release`].
    ///
    /// Забележете дека во случај на `compare_and_swap`, можно е операцијата да не изврши никаква продавница и затоа има само порачка [`Acquire`].
    ///
    /// Сепак, `AcqRel` никогаш нема да изврши пристап до [`Relaxed`].
    ///
    /// Оваа нарачка е применлива само за операции што комбинираат товари и продавници.
    ///
    /// Одговара на [`memory_order_acq_rel`] во C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Како ["Стекнување"]/["Ослободете"]/["AcqRel"](за операции за оптоварување, складирање и оптоварување со продавница, соодветно) со дополнителна гаранција дека сите теми ги гледаат сите последователни конзистентни операции во истиот редослед .
    ///
    ///
    /// Одговара на [`memory_order_seq_cst`] во C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] иницијализиран во `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Создава нов `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Враќа непроменлива референца на основната [`bool`].
    ///
    /// Ова е безбедно затоа што неспојливата референца гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // БЕЗБЕДНОСТ: непроменливата референца гарантира единствена сопственост.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Добијте атомски пристап до `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // БЕЗБЕДНОСТ: променливата референца гарантира единствена сопственост и
        // порамнувањето и на `bool` и на `Self` е 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Ја троши атомската и ја враќа содржаната вредност.
    ///
    /// Ова е безбедно затоа што поминувањето на `self` по вредност гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Вчитува вредност од bool.
    ///
    /// `load` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Можни вредности се [`SeqCst`], [`Acquire`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ако `order` е [`Release`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: сите трки со податоци се спречуваат со атомски суштини и суровини
        // внесениот покажувач е валиден затоа што го добивме од референца.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Зачувува вредност во bool.
    ///
    /// `store` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Можни вредности се [`SeqCst`], [`Release`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ако `order` е [`Acquire`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // БЕЗБЕДНОСТ: сите трки со податоци се спречуваат со атомски суштини и суровини
        // внесениот покажувач е валиден затоа што го добивме од референца.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Зачувува вредност во bool, враќајќи ја претходната вредност.
    ///
    /// `swap` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Зачувува вредност во [`bool`] ако моменталната вредност е иста со вредноста `current`.
    ///
    /// Вратината вредност е секогаш претходната вредност.Ако е еднаква на `current`, тогаш вредноста е ажурирана.
    ///
    /// `compare_and_swap` исто така, зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Забележете дека дури и кога користите [`AcqRel`], операцијата може да пропадне и затоа да изврши само оптоварување `Acquire`, но да нема семантика `Release`.
    /// Користењето на [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`] доколку се случи, а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Мигрирање кон `compare_exchange` и `compare_exchange_weak`
    ///
    /// `compare_and_swap` е еквивалентно на `compare_exchange` со следното мапирање за нарачки на меморијата:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Опуштено |Опуштено |Опуштено стекнување |Стекнете |Стекнете ослободување |Ослободување |Опуштено AcqRel |AcqRel |Стекнете SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` е дозволено лажно да пропадне дури и кога ќе успее споредбата, што му овозможува на компајлерот да генерира подобар склопен код кога споредбата и размената се користат во јамка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Зачувува вредност во [`bool`] ако моменталната вредност е иста со вредноста `current`.
    ///
    /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
    /// За успех, оваа вредност е загарантирана да биде еднаква на `current`.
    ///
    /// `compare_exchange` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
    /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
    ///
    /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Зачувува вредност во [`bool`] ако моменталната вредност е иста со вредноста `current`.
    ///
    /// За разлика од [`AtomicBool::compare_exchange`], оваа функција е дозволено лажно да пропадне дури и кога ќе успее споредбата, што може да резултира со поефикасен код на некои платформи.
    ///
    /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
    ///
    /// `compare_exchange_weak` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
    /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
    /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Логички "and" со булова вредност.
    ///
    /// Врши логичка операција "and" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
    ///
    /// Ја враќа претходната вредност.
    ///
    /// `fetch_and` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Логички "nand" со булова вредност.
    ///
    /// Врши логичка операција "nand" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
    ///
    /// Ја враќа претходната вредност.
    ///
    /// `fetch_nand` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Не можеме да користиме atomic_nand тука затоа што може да резултира со bool со невалидна вредност.
        // Ова се случува затоа што атомската операција се прави со 8-битен интеграл внатрешно, што би ги поставило горните 7 бита.
        //
        // Значи, ние наместо тоа користиме fetch_xor или swap.
        if val {
            // ! (x и точно)== !x Ние мора да го превртиме bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==точно Ние мора да го поставиме bool на true.
            //
            self.swap(true, order)
        }
    }

    /// Логички "or" со булова вредност.
    ///
    /// Врши логичка операција "or" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
    ///
    /// Ја враќа претходната вредност.
    ///
    /// `fetch_or` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Логички "xor" со булова вредност.
    ///
    /// Врши логичка операција "xor" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
    ///
    /// Ја враќа претходната вредност.
    ///
    /// `fetch_xor` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Враќа менлив покажувач на основниот [`bool`].
    ///
    /// Вршењето не-атомско читање и запишување на добиениот цел број може да биде трка со податоци.
    /// Овој метод е претежно корисен за FFI, каде што функцискиот потпис може да користи `*mut bool` наместо `&AtomicBool`.
    ///
    /// Враќањето на покажувачот `*mut` од споделена референца на овој атом е безбедно бидејќи атомските типови работат со внатрешна променливост.
    /// Сите модификации на атомската ја менуваат вредноста преку споделена референца и можат да го сторат тоа се додека користат атомски операции.
    /// За каква било употреба на вратениот суров покажувач е потребен блок `unsafe` и сè уште треба да го поддржува истото ограничување: операциите на него мора да бидат атомски.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Ја презема вредноста и применува функција на неа што враќа по изборна нова вредност.Враќа `Result` од `Ok(previous_value)` ако функцијата врати `Some(_)`, инаку `Err(previous_value)`.
    ///
    /// Note: Ова може да ја повика функцијата повеќе пати ако во меѓувреме вредноста е променета од другите нишки, сè додека функцијата ја враќа `Some(_)`, но функцијата ќе биде применета само еднаш на зачуваната вредност.
    ///
    ///
    /// `fetch_update` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// Првиот го опишува потребното нарачување за кога операцијата конечно ќе успее, додека втората ја опишува потребната нарачка за товари.
    /// Овие одговараат на нарачките за успех и неуспех на [`AtomicBool::compare_exchange`], соодветно.
    ///
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави последното успешно оптоварување [`Relaxed`].
    /// Подредувањето на товарот (failed) може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентно или послабо од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформите што поддржуваат атомско работење на `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Создава нов `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Враќа непроменлива референца на основниот покажувач.
    ///
    /// Ова е безбедно затоа што неспојливата референца гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Добијте атомски пристап до покажувачот.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - непроменливата референца гарантира единствена сопственост.
        //  - усогласувањето на `*mut T` и `Self` е исто на сите платформи поддржани од rust, како што е потврдено погоре.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Ја троши атомската и ја враќа содржаната вредност.
    ///
    /// Ова е безбедно затоа што поминувањето на `self` по вредност гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Вчитува вредност од покажувачот.
    ///
    /// `load` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Можни вредности се [`SeqCst`], [`Acquire`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ако `order` е [`Release`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Зачувува вредност во покажувачот.
    ///
    /// `store` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Можни вредности се [`SeqCst`], [`Release`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ако `order` е [`Acquire`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Зачувува вредност во покажувачот, враќајќи ја претходната вредност.
    ///
    /// `swap` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
    /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    ///
    /// **Note:** Овој метод е достапен само на платформи кои поддржуваат атомски операции на покажувачи.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Зачувува вредност во покажувачот ако моменталната вредност е иста со вредноста `current`.
    ///
    /// Вратината вредност е секогаш претходната вредност.Ако е еднаква на `current`, тогаш вредноста е ажурирана.
    ///
    /// `compare_and_swap` исто така, зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
    /// Забележете дека дури и кога користите [`AcqRel`], операцијата може да пропадне и затоа да изврши само оптоварување `Acquire`, но да нема семантика `Release`.
    /// Користењето на [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`] доколку се случи, а користењето [`Release`] го прави товарот дел [`Relaxed`].
    ///
    /// **Note:** Овој метод е достапен само на платформи кои поддржуваат атомски операции на покажувачи.
    ///
    /// # Мигрирање кон `compare_exchange` и `compare_exchange_weak`
    ///
    /// `compare_and_swap` е еквивалентно на `compare_exchange` со следното мапирање за нарачки на меморијата:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Опуштено |Опуштено |Опуштено стекнување |Стекнете |Стекнете ослободување |Ослободување |Опуштено AcqRel |AcqRel |Стекнете SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` е дозволено лажно да пропадне дури и кога ќе успее споредбата, што му овозможува на компајлерот да генерира подобар склопен код кога споредбата и размената се користат во јамка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Зачувува вредност во покажувачот ако моменталната вредност е иста со вредноста `current`.
    ///
    /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
    /// За успех, оваа вредност е загарантирана да биде еднаква на `current`.
    ///
    /// `compare_exchange` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
    /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
    ///
    /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформи кои поддржуваат атомски операции на покажувачи.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Зачувува вредност во покажувачот ако моменталната вредност е иста со вредноста `current`.
    ///
    /// За разлика од [`AtomicPtr::compare_exchange`], оваа функција е дозволено лажно да пропадне дури и кога ќе успее споредбата, што може да резултира со поефикасен код на некои платформи.
    ///
    /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
    ///
    /// `compare_exchange_weak` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
    /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
    /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформи кои поддржуваат атомски операции на покажувачи.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗБЕДНОСТ: Ова суштинско значење е небезбедно затоа што работи на суров покажувач
        // но сигурно знаеме дека покажувачот е валиден (штотуку го добивме од `UnsafeCell` што го имаме по упатување) и самата атомска операција ни овозможува безбедно да ги мутираме содржините `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Ја презема вредноста и применува функција на неа што враќа по изборна нова вредност.Враќа `Result` од `Ok(previous_value)` ако функцијата врати `Some(_)`, инаку `Err(previous_value)`.
    ///
    /// Note: Ова може да ја повика функцијата повеќе пати ако во меѓувреме вредноста е променета од другите нишки, сè додека функцијата ја враќа `Some(_)`, но функцијата ќе биде применета само еднаш на зачуваната вредност.
    ///
    ///
    /// `fetch_update` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
    /// Првиот го опишува потребното нарачување за кога операцијата конечно ќе успее, додека втората ја опишува потребната нарачка за товари.
    /// Овие одговараат на нарачките за успех и неуспех на [`AtomicPtr::compare_exchange`], соодветно.
    ///
    /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави последното успешно оптоварување [`Relaxed`].
    /// Подредувањето на товарот (failed) може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентно или послабо од нарачката за успех.
    ///
    /// **Note:** Овој метод е достапен само на платформи кои поддржуваат атомски операции на покажувачи.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Конвертира `bool` во `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Оваа макро завршува како неискористена кај некои архитектури.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Целиот тип кој може безбедно да се сподели помеѓу нишките.
        ///
        /// Овој тип има иста претстава во меморијата како и основниот тип на цел број, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// За повеќе информации во врска со разликите помеѓу атомските и не-атомските типови, како и информации за преносливоста на овој тип, видете во [module-level documentation].
        ///
        ///
        /// **Note:** Овој тип е достапен само на платформи кои поддржуваат атомски товари и продавници на [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Атомски цел број иницијализиран во `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Испраќањето е имплицитно имплементирано.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Создава нов атомски цел број.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Враќа изменлива референца на основниот цел број.
            ///
            /// Ова е безбедно затоа што неспојливата референца гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// нека мут некои_инт=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// тврди_ек! (некои_инт, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - непроменливата референца гарантира единствена сопственост.
                //  - усогласувањето на `$int_type` и `Self` е исто, како што вети $cfg_align и е потврдено погоре.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Ја троши атомската и ја враќа содржаната вредност.
            ///
            /// Ова е безбедно затоа што поминувањето на `self` по вредност гарантира дека ниедна друга нишка истовремено не пристапува до атомските податоци.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Вчитува вредност од атомскиот цел број.
            ///
            /// `load` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
            /// Можни вредности се [`SeqCst`], [`Acquire`] и [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ако `order` е [`Release`] или [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Зачувува вредност во атомскиот цел број.
            ///
            /// `store` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
            ///  Можни вредности се [`SeqCst`], [`Release`] и [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ако `order` е [`Acquire`] или [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Зачувува вредност во атомскиот цел број, враќајќи ја претходната вредност.
            ///
            /// `swap` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Зачувува вредност во атомскиот цел број ако моменталната вредност е иста со вредноста `current`.
            ///
            /// Вратината вредност е секогаш претходната вредност.Ако е еднаква на `current`, тогаш вредноста е ажурирана.
            ///
            /// `compare_and_swap` исто така, зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.
            /// Забележете дека дури и кога користите [`AcqRel`], операцијата може да пропадне и затоа да изврши само оптоварување `Acquire`, но да нема семантика `Release`.
            ///
            /// Користењето на [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`] доколку се случи, а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Мигрирање кон `compare_exchange` и `compare_exchange_weak`
            ///
            /// `compare_and_swap` е еквивалентно на `compare_exchange` со следното мапирање за нарачки на меморијата:
            ///
            /// Оригинал |Успех |Неуспех
            /// -------- | ------- | -------
            /// Опуштено |Опуштено |Опуштено стекнување |Стекнете |Стекнете ослободување |Ослободување |Опуштено AcqRel |AcqRel |Стекнете SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` е дозволено лажно да пропадне дури и кога ќе успее споредбата, што му овозможува на компајлерот да генерира подобар склопен код кога споредбата и размената се користат во јамка.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Зачувува вредност во атомскиот цел број ако моменталната вредност е иста со вредноста `current`.
            ///
            /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
            /// За успех, оваа вредност е загарантирана да биде еднаква на `current`.
            ///
            /// `compare_exchange` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
            /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
            /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
            /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
            ///
            /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Зачувува вредност во атомскиот цел број ако моменталната вредност е иста со вредноста `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// оваа функција е дозволено лажно да пропадне дури и кога ќе успее споредбата, што може да резултира со поефикасен код на некои платформи.
            /// Вратината вредност е резултат што покажува дали новата вредност е напишана и ја содржи претходната вредност.
            ///
            /// `compare_exchange_weak` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
            /// `success` го опишува потребното нарачување за операцијата за читање-модифицирање, што се одвива ако успее споредбата со `current`.
            /// `failure` ја опишува потребната нарачка за работата на товарот што се одвива кога не успее споредбата.
            /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави успешното оптоварување [`Relaxed`].
            ///
            /// Нарачката за неуспех може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентна или послаба од нарачката за успех.
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// нека мут стар= val.load(Ordering::Relaxed);
            /// јамка {нека нова=стара * 2;
            ///     натпревар val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Се додава на тековната вредност, враќајќи ја претходната вредност.
            ///
            /// Оваа операција се обвива на прелевање.
            ///
            /// `fetch_add` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Одземање од тековната вредност, враќајќи ја претходната вредност.
            ///
            /// Оваа операција се обвива на прелевање.
            ///
            /// `fetch_sub` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" со моменталната вредност.
            ///
            /// Врши бит-операција "and" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_and` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" со моменталната вредност.
            ///
            /// Врши бит-операција "nand" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_nand` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" со моменталната вредност.
            ///
            /// Врши бит-операција "or" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_or` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" со моменталната вредност.
            ///
            /// Врши бит-операција "xor" на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_xor` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Ја презема вредноста и применува функција на неа што враќа по изборна нова вредност.Враќа `Result` од `Ok(previous_value)` ако функцијата врати `Some(_)`, инаку `Err(previous_value)`.
            ///
            /// Note: Ова може да ја повика функцијата повеќе пати ако во меѓувреме вредноста е променета од другите нишки, сè додека функцијата ја враќа `Some(_)`, но функцијата ќе биде применета само еднаш на зачуваната вредност.
            ///
            ///
            /// `fetch_update` потребни се два аргументи [`Ordering`] за да се опише подредувањето на меморијата на оваа операција.
            /// Првиот го опишува потребното нарачување за кога операцијата конечно ќе успее, додека втората ја опишува потребната нарачка за товари.Овие одговараат на нарачките за успех и неуспех на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Користењето на [`Acquire`] како успешно нарачување ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави последното успешно оптоварување [`Relaxed`].
            /// Подредувањето на товарот (failed) може да биде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и мора да биде еквивалентно или послабо од нарачката за успех.
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Подредување: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Подредување: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Максимум со моменталната вредност.
            ///
            /// Ја наоѓа максимумот на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_max` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека лента=42;
            /// нека max_foo=foo.fetch_max (лента, Ordering::SeqCst).max(bar);
            /// тврди! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Минимум со моменталната вредност.
            ///
            /// Ја наоѓа минималната вредност на тековната вредност и аргументот `val` и ја поставува новата вредност на резултатот.
            ///
            /// Ја враќа претходната вредност.
            ///
            /// `fetch_min` зема аргумент [`Ordering`] кој го опишува подредувањето на меморијата на оваа операција.Можни се сите режими за нарачување.
            /// Забележете дека користењето [`Acquire`] ја прави продавницата дел од оваа операција [`Relaxed`], а користењето [`Release`] го прави товарот дел [`Relaxed`].
            ///
            ///
            /// **Белешка**: Овој метод е достапен само на платформи кои поддржуваат атомско работење на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека лента=12;
            /// нека min_foo=foo.fetch_min (лента, Ordering::SeqCst).min(bar);
            /// тврди_ек! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: трките со податоци се спречуваат со атомски суштини.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Враќа применлив покажувач во основниот цел број.
            ///
            /// Вршењето не-атомско читање и запишување на добиениот цел број може да биде трка со податоци.
            /// Овој метод е претежно корисен за FFI, каде што може да се користи потписот на функцијата
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Враќањето на покажувачот `*mut` од споделена референца на овој атом е безбедно бидејќи атомските типови работат со внатрешна променливост.
            /// Сите модификации на атомската ја менуваат вредноста преку споделена референца и можат да го сторат тоа се додека користат атомски операции.
            /// За каква било употреба на вратениот суров покажувач е потребен блок `unsafe` и сè уште треба да го поддржува истото ограничување: операциите на него мора да бидат атомски.
            ///
            ///
            /// # Examples
            ///
            /// " игнорирај го (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// надворешен "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // БЕЗБЕДНОСТ: Безбедно се додека `my_atomic_op` е атомско.
            /// небезбеден {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Ја враќа претходната вредност (како __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Ја враќа претходната вредност (како __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ја враќа максималната вредност (потпишана споредба)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ја враќа минималната вредност (потпишана споредба)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ја враќа максималната вредност (непотпишана споредба)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ја враќа минималната вредност (непотпишана споредба)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: повикувачот мора да го почитува договорот за безбедност за `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Атомска ограда.
///
/// Во зависност од наведената нарачка, оградата спречува компајлерот и процесорот да ги распоредат одредени типови на мемориски операции околу него.
/// Тоа создава синхронизирани врски помеѓу него и атомски операции или огради во други нишки.
///
/// Оградата 'A' која има (барем) [`Release`] семантика за нарачување, се синхронизира со оградата 'B' со (барем) [`Acquire`] семантика, ако и само ако постојат операции X и Y, обајцата работат на некој атомски објект 'M', така што А се секвенцира пред X, Y се синхронизира пред Б и Y ја набvesудува промената во М.
/// Ова обезбедува зависност што се случува пред А и Б.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Атомските операции со семантика [`Release`] или [`Acquire`] исто така можат да се синхронизираат со ограда.
///
/// Ограда која има подредување [`SeqCst`], покрај тоа што има и [`Acquire`] и [`Release`] семантика, учествува во глобалниот програмски редослед на другите операции [`SeqCst`] и/или огради.
///
/// Прифаќа нарачки [`Acquire`], [`Release`], [`AcqRel`] и [`SeqCst`].
///
/// # Panics
///
/// Panics ако `order` е [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Примитивно заемно исклучување засновано на спинлок.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Почекајте додека старата вредност не е `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Оваа ограда се синхронизира со продавницата во `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // БЕЗБЕДНОСТ: користењето атомска ограда е безбедно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ограда за меморија на компајлерот.
///
/// `compiler_fence` не испушта никаков код на машината, но ги ограничува видовите на меморија што е дозволено да се изврши повторно нарачување на компајлерот.Поточно, во зависност од дадената семантика [`Ordering`], на компајлерот може да не му се дозволи да преместува читање или запишување од пред или по повикот на другата страна на повикот кон `compiler_fence`.Забележете дека тоа **не го спречува* хардверот * да изврши такво прераспоредување.
///
/// Ова не е проблем во контекст за извршување со еден навој, но кога другите нишки може да ја менуваат меморијата истовремено, потребни се посилни примитиви за синхронизација како што е [`fence`].
///
/// Пре-нарачката спречена од различната семантика за нарачување е:
///
///  - со [`SeqCst`], не е дозволено повторно нарачување на читања и записи низ оваа точка.
///  - со [`Release`], претходното читање и запишување не може да се премести покрај следните пишувања.
///  - со [`Acquire`], последователното читање и запишување не може да се премести пред претходното читање.
///  - со [`AcqRel`], двете горенаведени правила се спроведуваат.
///
/// `compiler_fence` генерално е корисно само за спречување на конец да не се натпреварува *со себе*.Тоа е, ако дадена нишка извршува едно парче код, а потоа е прекината, и започне да извршува код на друго место (додека е сè уште во иста нишка, и концептуално сè уште е на истото јадро).Во традиционалните програми, ова може да се случи само кога е регистриран управувач на сигнал.
/// Во повеќе кодови на ниско ниво, такви ситуации може да се појават и при ракување со прекини, при спроведување на зелени нишки со претпоставка, итн.
/// Curубопитните читатели се охрабруваат да ја прочитаат дискусијата за јадрото Linux за [memory barriers].
///
/// # Panics
///
/// Panics ако `order` е [`Relaxed`].
///
/// # Examples
///
/// Без `compiler_fence`, `assert_eq!` во следниов код не е *загарантиран* да успее, и покрај сè што се случува во една нишка.
/// За да видите зошто, запомнете дека компајлерот може слободно да ги замени продавниците на `IMPORTANT_VARIABLE` и `IS_READ` бидејќи и двете се `Ordering::Relaxed`.Ако тоа се случи, и управувачот на сигналот се повикува веднаш по ажурирањето на `IS_READY`, тогаш управувачот на сигналот ќе види `IS_READY=1`, но `IMPORTANT_VARIABLE=0`.
/// Користејќи лекови `compiler_fence`, оваа ситуација.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // спречи претходните записи да бидат преместени над оваа точка
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // БЕЗБЕДНОСТ: користењето атомска ограда е безбедно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Сигнализира на процесорот дека е во спин-јамка со зафатен чекање (" заклучување на вртење`).
///
/// Оваа функција е застарена во корист на [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}