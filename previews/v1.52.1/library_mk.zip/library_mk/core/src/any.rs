//! Овој модул го спроведува `Any` trait, што овозможува динамично пишување од кој било тип `'static` преку рефлексија на времето.
//!
//! `Any` самиот може да се искористи за да се добие `TypeId` и има повеќе карактеристики кога се користи како trait објект.
//! Како `&dyn Any` (позајмен објект trait), тој ги има методите `is` и `downcast_ref`, да тестира дали содржината е од даден тип и да добие повикување на внатрешната вредност како тип.
//! Како `&mut dyn Any`, тука е и методот `downcast_mut`, за добивање на неспокоен повик за внатрешната вредност.
//! `Box<dyn Any>` го додава методот `downcast`, кој се обидува да се претвори во `Box<T>`.
//! Погледнете ја документацијата [`Box`] за целосните детали.
//!
//! Забележете дека `&dyn Any` е ограничен на тестирање дали вредноста е од одреден тип на бетон и не може да се користи за да се тестира дали типот спроведува trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Паметни покажувачи и `dyn Any`
//!
//! Едно од однесување што треба да го имате предвид кога користите `Any` како trait објект, особено со типови како `Box<dyn Any>` или `Arc<dyn Any>`, е дека едноставно повикувањето на `.type_id()` на вредноста ќе произведе `TypeId` на *контејнерот*, а не на основниот објект trait.
//!
//! Ова може да се избегне со претворање на паметниот покажувач во `&dyn Any` наместо тоа, што ќе го врати објектот `TypeId`.
//! На пример:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Најверојатно ќе го сакате ова:
//! let actual_id = (&*boxed).type_id();
//! // ... отколку ова:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Размислете за ситуација кога сакаме да одјавиме вредност пренесена на функција.
//! Ние ја знаеме вредноста на која работиме ја спроведува Дебаг, но не го знаеме неговиот конкретен тип.Ние сакаме да дадеме посебен третман на одредени типови: во овој случај да се испечати должината на String вредностите пред нивната вредност.
//! Ние не го знаеме конкретниот вид на нашата вредност во времето на компајлирање, па затоа треба да користиме рефлексија на траење.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Функција на дрвосечач за кој било тип што спроведува дебагирање.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Обидете се да ја претворите нашата вредност во `String`.
//!     // Ако е успешна, сакаме да ја изнесеме должината на стрингот, како и нејзината вредност.
//!     // Ако не, тоа е различен тип: само испечатете го без украси.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Оваа функција сака да го одјави својот параметар пред да заврши работа со неа.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... направи некоја друга работа
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Било кој trait
///////////////////////////////////////////////////////////////////////////////

/// trait за да се имитира динамично пишување.
///
/// Повеќето типови го имплементираат `Any`.Како и да е, кој било вид што содржи нестатичка референца не содржи.
/// Погледнете го [module-level documentation][mod] за повеќе детали.
///
/// [mod]: crate::any
// Овој trait не е небезбеден, иако се потпираме на спецификите на функцијата `type_id` на единствениот импл во небезбеден код (на пример, `downcast`).Нормално, тоа би бил проблем, но бидејќи единствениот импликација на `Any` е примена на ќебе, никој друг код не може да го имплементира `Any`.
//
// Овој trait може веројатно да го направиме небезбеден-тоа нема да предизвика кршење, бидејќи ги контролираме сите имплементации-но не избираме затоа што и тоа не е навистина потребно и може да ги збуни корисниците за разликување на небезбедни traits и небезбедни методи (т.е. `type_id` сепак би бил безбеден за повик, но најверојатно би сакале да го наведеме како таков во документацијата).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Добива `TypeId` од `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Методи за продолжување за кои било објекти на trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Осигурете се дека резултатот од пр., Приклучување на нишка може да се отпечати и затоа да се користи со `unwrap`.
// Можеби на крајот повеќе нема да биде потребно ако испраќањето работи со возбудувања.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Враќа `true` ако типот во кутија е ист како `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Добијте `TypeId` од типот со кој е инстанцирана оваа функција.
        let t = TypeId::of::<T>();

        // Добијте `TypeId` од типот во trait објектот (`self`).
        let concrete = self.type_id();

        // Споредете ги и `TypeId` за еднаквост.
        t == concrete
    }

    /// Враќа одредена референца на кутијата вредност ако е од типот `T` или `None` ако не е.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЕЗБЕДНОСТ: само провери дали укажуваме на точниот тип и можеме да се потпреме
            // тие проверуваат за безбедноста на меморијата затоа што имаме имплементирано кое било за сите видови;ниедно друго мислење не може да постои, бидејќи тие би биле во спротивност со нашето мислење.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Враќа некое менливо упатување на полето со вредност ако е од типот `T` или `None` ако не е.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЕЗБЕДНОСТ: само провери дали укажуваме на точниот тип и можеме да се потпреме
            // тие проверуваат за безбедноста на меморијата затоа што имаме имплементирано кое било за сите видови;ниедно друго мислење не може да постои, бидејќи тие би биле во спротивност со нашето мислење.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Напред кон методот дефиниран на типот `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID и неговите методи
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` претставува глобално уникатен идентификатор за еден вид.
///
/// Секој `TypeId` е нетранспарентен објект што не дозволува преглед на тоа што е внатре, но дозволува основни операции како што се клонирање, споредување, печатење и прикажување.
///
///
/// `TypeId` е моментално достапен само за типови што се припишуваат на `'static`, но ова ограничување може да се отстрани во future.
///
/// Додека `TypeId` ги спроведува `Hash`, `PartialOrd` и `Ord`, вреди да се напомене дека хашите и нарачката ќе се разликуваат помеѓу изданијата на Rust.
/// Пазете се од потпирање на нив во вашиот код!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Враќа `TypeId` од типот со кој е инстанцирана оваа генеричка функција.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Го враќа името на видот како парче низа.
///
/// # Note
///
/// Ова е наменето за дијагностичка употреба.
/// Точната содржина и формат на низата што се враќаат не се наведени, освен тоа што се опишува најдобро за типот.
/// На пример, меѓу низите што `type_name::<Option<String>>()` може да ги врати се `"Option<String>"` и `"std::option::Option<std::string::String>"`.
///
///
/// Вратената низа не смее да се смета за единствен идентификатор на еден вид бидејќи повеќе типови можат да мапираат на истото име на типот.
/// Слично на тоа, нема гаранција дека сите делови од еден тип ќе се појават во вратената низа: на пример, спецификаторите за цел живот во моментов не се вклучени.
/// Покрај тоа, излезот може да се смени помеѓу верзиите на компајлерот.
///
/// Тековната имплементација ја користи истата инфраструктура како дијагностиката на компајлерот и дебагинфо, но ова не е загарантирано.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Го враќа името на типот на насочената вредност како парче жица.
/// Ова е исто како `type_name::<T>()`, но може да се користи кога типот на променлива не е лесно достапен.
///
/// # Note
///
/// Ова е наменето за дијагностичка употреба.Точната содржина и формат на низата не се наведени, освен тоа што е опис на типот со најдобар напор.
/// На пример, `type_name_of_val::<Option<String>>(None)` може да врати `"Option<String>"` или `"std::option::Option<std::string::String>"`, но не и `"foobar"`.
///
/// Покрај тоа, излезот може да се смени помеѓу верзиите на компајлерот.
///
/// Оваа функција не ги решава објектите trait, што значи дека `type_name_of_val(&7u32 as &dyn Debug)` може да врати `"dyn Debug"`, но не и `"u32"`.
///
/// Името на типот не треба да се смета за единствен идентификатор на тип;
/// повеќе типови можат да го делат истото име на типот.
///
/// Тековната имплементација ја користи истата инфраструктура како дијагностиката на компајлерот и дебагинфо, но ова не е загарантирано.
///
/// # Examples
///
/// Ги печати стандардните типови цел број и плови.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}