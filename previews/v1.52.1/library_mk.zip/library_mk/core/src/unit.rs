use crate::iter::FromIterator;

/// Ги собира сите единици од итератор во една.
///
/// Ова е покорисно кога се комбинира со апстракции на повисоко ниво, како собирање на `Result<(), E>` каде што се грижите само за грешки:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}