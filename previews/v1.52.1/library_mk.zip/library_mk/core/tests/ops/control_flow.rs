use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ова не е стабилна површина, но помага да се задржи `?` ефтино меѓу нив, дури и ако LLVM не може секогаш да го искористи тоа во моментов.
    //
    // (За жал, резултатот и опцијата се недоследни, па ControlFlow не може да одговара на обете.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}