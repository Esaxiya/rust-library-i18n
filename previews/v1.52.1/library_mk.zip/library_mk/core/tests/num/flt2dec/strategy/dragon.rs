use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Мири е премногу бавен
fn exact_sanity_test() {
    // Овој тест завршува со работа што можам да претпоставам само дека е некој агол на функцијата библиотека `exp2`, дефиниран во кое било време на траење C што го користиме.
    // Во VS 2013 оваа функција очигледно имаше грешка бидејќи овој тест не успеа кога е поврзан, но со VS 2015 грешката се појавува бидејќи тестот тече добро.
    //
    // Се чини дека грешката е разлика во повратната вредност на `exp2(-1057)`, каде што во VS 2013 се враќа двојно со бит-моделот 0x2 и во VS 2015 се враќа 0x20000.
    //
    //
    // За сега, само игнорирајте го овој тест целосно на MSVC бидејќи тој е тестиран на друго место и онака и ние не сме супер заинтересирани за тестирање на имплементацијата на секоја платформа exp2.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}