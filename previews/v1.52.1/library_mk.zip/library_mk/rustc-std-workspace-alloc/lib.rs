#![feature(no_core)]
#![no_core]

// Погледнете ја јадрото rustc-std-простор за работа зошто е потребен овој crate.

// Преименувајте го crate за да избегнете судир со модулот за распределување во liballoc.
extern crate alloc as foo;

pub use foo::*;