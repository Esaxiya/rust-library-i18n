//! Имплементација на Rust panics преку прекинување на процесот
//!
//! Кога се споредува со имплементацијата преку одмотување, овој crate е *многу* поедноставен!Ова, рече, не е толку разноврсна, но еве!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" носивоста и треперењето до соодветниот прекин на платформата за која станува збор.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // јавете се на std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // На Windows, користете механизам специфичен за процесорот __fastfail.Во Windows 8 и подоцна, ова ќе го прекине процесот веднаш без да извршувате никакви ракувачи со исклучоци во процесот.
            // Во претходните верзии на Windows, оваа низа инструкции ќе се третира како повреда на пристапот, завршувајќи го процесот, но без нужно да се заобиколат сите управувачи на исклучоци.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ова е иста имплементација како и во `abort_internal` на libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ова ... е малку необичност.Tl; др;е дека ова е потребно за правилно поврзување, подолгото објаснување е подолу.
//
// Во моментов, бинарите на libcore/libstd што ги испраќаме, сите се компајлирани со `-C panic=unwind`.Ова е направено за да се осигура дека бинарите се максимално компатибилни со што повеќе ситуации.
// Компајлерот, сепак, бара "personality function" за сите функции собрани со `-C panic=unwind`.Оваа функција на личност е тврдо кодирана на симболот `rust_eh_personality` и е дефинирана со ставката `eh_personality`.
//
// So...
// зошто да не ја дефинирам само таа ставка тука?Добро прашање!Начинот на којшто се поврзани траењето на panic е всушност малку суптилен со тоа што тие се "sort of" во продавницата crate на компајлерот, но всушност се поврзани ако друг всушност не е поврзан.
//
// Ова завршува со значење дека и овој crate и panic_unwind crate можат да се појават во продавницата crate на компајлерот, и ако и двајцата ја дефинираат ставката за јазик `eh_personality`, тогаш ќе се појави грешка.
//
// За да се справи со ова, компајлерот бара само `eh_personality` да биде дефиниран ако времето за работа на panic што е поврзано е времетраење на одмотување, инаку не е потребно да се дефинира (со право).
// Во овој случај, сепак, оваа библиотека само го дефинира овој симбол, така што некаде има барем некоја личност.
//
// Во суштина, овој симбол е само дефиниран за да се приклучи на жица до libcore/libstd бинарни, но тој никогаш не треба да се нарекува бидејќи воопшто не поврзуваме во времетраење на одмотување.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // На x86_64-pc-windows-gnu ние ја користиме нашата сопствена функција на личност што треба да го врати `ExceptionContinueSearch` додека ги пренесуваме сите наши рамки.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Слично на погоре, ова одговара на ставката за јазици `eh_catch_typeinfo` што се користи само на Емскриптен во моментов.
    //
    // Бидејќи panics не создава исклучоци и странските исклучоци се моментално UB со -C panic=прекин (иако ова може да биде предмет на промена), сите повици на catch_unwind никогаш нема да го користат овој тип инфо.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Овие двајца се повикуваат од нашите стартни објекти на i686-pc-windows-gnu, но тие не треба да прават ништо, така што телата не се зафаќаат.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}