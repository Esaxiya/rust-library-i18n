use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Се користи за да им се каже на нашите прибелешки `#[assert_instr]` дека сите симд интринци се достапни за да го тестираат својот коден, бидејќи некои се затворени зад дополнителен `-Ctarget-feature=+unimplemented-simd128` кој сега нема никаков еквивалент на `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}