`core::arch` - Суштински специфични за архитектурата на библиотеката на Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` модулот имплементира суштински зависни од архитектурата (на пр. SIMD).

# Usage 

`core::arch` е достапен како дел од `libcore` и тој се реекспортира од `libstd`.Претпочитајте да го користите преку `core::arch` или `std::arch` отколку преку овој crate.
Нестабилните одлики често се достапни во ноќниот Rust преку `feature(stdsimd)`.

Користењето на `core::arch` преку овој crate бара ноќен Rust и тој може (и прави) често да се расипува.Единствените случаи во кои треба да размислите да го користите преку овој crate се:

* ако треба сами повторно да компајлирате `core::arch`, на пример, со овозможени посебни целни карактеристики кои не се овозможени за `libcore`/`libstd`.
Note: ако треба повторно да ја составиме за нестандардна цел, претпочитајте да користите `xargo` и повторно составување `libcore`/`libstd` како што е соодветно, наместо да го користите овој crate.
  
* користејќи некои одлики што можеби не се достапни дури и зад нестабилните одлики на Rust.Се обидуваме да ги сведеме на минимум овие.
Ако треба да користите некои од овие одлики, отворете проблем за да можеме да ги изложуваме во ноќниот Rust и да ги користите од таму.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` првенствено се дистрибуира според условите на лиценцата МИТ и лиценцата Apache (верзија 2.0), со делови опфатени со разни лиценци слични на BSD.

Погледнете ЛИЦЕНЦА-APACHE и ЛИЦЕНЦА-МИТ за детали.

# Contribution

Освен ако не наведете поинаку поинаку, секој придонес намерно поднесен за вклучување во `core_arch` од вас, како што е дефиниран во лиценцата Apache-2.0, ќе биде двојно лиценциран како погоре, без дополнителни услови и услови.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












