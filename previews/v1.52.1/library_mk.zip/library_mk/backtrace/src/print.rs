#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматер за повратни траги.
///
/// Овој тип може да се искористи за печатење на backtrace без оглед од каде потекнува самата backtrace.
/// Ако имате тип `Backtrace`, тогаш неговата имплементација `Debug` веќе го користи овој формат за печатење.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Стилови на печатење што можеме да ги отпечатиме
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Печати повратна лента за терсер што идеално содржи само релевантни информации
    Short,
    /// Печати повратна трага што ги содржи сите можни информации
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Создадете нов `BacktraceFmt` што ќе запишува излез на дадениот `fmt`.
    ///
    /// Аргументот `format` ќе го контролира стилот во кој е отпечатена заднината, а аргументот `print_path` ќе се користи за печатење на инстанците `BytesOrWideString` на имињата на датотеките.
    /// Самиот овој тип не извршува никакво печатење на имиња на датотеки, но за да се направи тоа е потребен овој повратен повик.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Печати преамбула за задниот дел што треба да се печати.
    ///
    /// Ова е потребно на некои платформи за повратните траги да бидат целосно симболизирани подоцна, инаку ова треба да биде само првиот метод што го повикате по создавањето на `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Додава рамка на излезниот заден план.
    ///
    /// Ова извршување враќа инстанца RAII на `BacktraceFrameFmt` што може да се искористи за да се испечати рамка, а при уништување тој ќе го зголеми бројачот на рамката.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Го завршува излезот за повратна трага.
    ///
    /// Ова во моментов е забрането работење, но е додадено за компатибилност на future со формати на backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Во моментов нема опции-вклучувајќи го овој hook за да дозволите додатоци за future.
        Ok(())
    }
}

/// Форматер за само една рамка на повратната трака.
///
/// Овој тип е создаден од функцијата `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Печати `BacktraceFrame` со овој формат на рамки.
    ///
    /// Ова рекурзивно ќе ги отпечати сите инстанци `BacktraceSymbol` во рамките на `BacktraceFrame`.
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Печати `BacktraceSymbol` во рамките на `BacktraceFrame`.
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ова не е одлично што на крајот не печатиме ништо
            // со имиња на датотеки што не се utf8.
            // За среќа, скоро сè е utf8, така што ова не треба да биде премногу лошо.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Печати сурови трасирани `Frame` и `Symbol`, обично од необработените поврати повици на овој crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Додава необработена рамка на излезниот заден план.
    ///
    /// Овој метод, за разлика од претходниот, ги зема необработените аргументи во случај да се извори од различни локации.
    /// Забележете дека ова може да се повика повеќе пати за една рамка.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Додава необработена рамка на излезот за повратна трага, вклучително и информации за колоната.
    ///
    /// Овој метод, како и претходниот, ги зема необработените аргументи во случај да се извори од различни локации.
    /// Забележете дека ова може да се повика повеќе пати за една рамка.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фуксија не е во можност да симболизира во рамките на процесот, така што има посебен формат што може да се користи за да се симболизира подоцна.
        // Отпечатете го тоа наместо адреси за печатење во наш сопствен формат овде.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Нема потреба да печатите "null" рамки, тоа во основа само значи дека системот за враќање назад беше малку желен да се открие супер далеку.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // За да ја намалиме големината на TCB во енклавата Sgx, не сакаме да спроведуваме функционалност за резолуција на симболот.
        // Наместо тоа, овде можеме да го отпечатиме офсетот на адресата, што подоцна може да биде мапирано за да се поправи функцијата.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Печатете го индексот на рамката, како и изборниот покажувач за инструкции на рамката.
        // Ако го надминуваме првиот симбол на оваа рамка, ние само отпечаќаме соодветен простор за бело.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Следно, напишете го името на симболот, користејќи го алтернативното форматирање за повеќе информации ако сме целосна повратна позиција.
        // Тука, ние исто така се справуваме со симболи кои немаат име,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // И последно, отпечатете го бројот filename/line ако тие се достапни.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line се отпечатени на линии под името на симболот, затоа отпечатете некој соодветен простор за да се исправиме правилно.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Делегирајте на нашиот внатрешен повратен повик за да го испечатите името на датотеката и потоа да го испечатите бројот на линијата.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Додадете број на колона, доколку е достапен.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Ние се грижиме само за првиот симбол на рамката
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}