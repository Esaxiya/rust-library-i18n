use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Претставување на сопствена и самостојна повратна врата.
///
/// Оваа структура може да се искористи за да се фати повратен тракт во различни точки од програмата и подоцна да се искористи за да се провери што претставувало заднината во тоа време.
///
///
/// `Backtrace` поддржува прилично печатење на повратни траги преку неговата имплементација `Debug`.
///
/// # Потребни карактеристики
///
/// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Рамките тука се наведени од горниот до долниот дел на оџакот
    frames: Vec<BacktraceFrame>,
    // Индексот, за кој веруваме е вистински почеток на повратната трага, изоставувајќи рамки како `Backtrace::new` и `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Фатена верзија на рамка во повратна траса.
///
/// Овој тип се враќа како список од `Backtrace::frames` и претставува една рамка на оџакот во зафатената позадина.
///
/// # Потребни карактеристики
///
/// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Фатена верзија на симбол во повратна тераса.
///
/// Овој тип се враќа како список од `BacktraceFrame::symbols` и ги претставува метаподатоците за симболот во позадината.
///
/// # Потребни карактеристики
///
/// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Зафаќа враќање назад на повикот на оваа функција, враќајќи сопственост на репрезентација.
    ///
    /// Оваа функција е корисна за претставување на backtrace како објект во Rust.Оваа вратена вредност може да се испрати преку нишки и да се отпечати на друго место, а целта на оваа вредност е да биде целосно самостојна.
    ///
    /// Имајте на ум дека на некои платформи стекнувањето целосен повратен удар и решавањето може да биде исклучително скапо.
    /// Ако цената е преголема за вашата апликација, препорачливо е да користите `Backtrace::new_unresolved()` што го избегнува чекорот на резолуција на симболот (што обично трае најдолго) и дозволува тоа да се одложи за подоцнежен датум.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // сакате да бидете сигурни дека тука има рамка за отстранување
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Слично на `new`, освен што ова не решава никакви симболи, ова едноставно ја снима заднината како список на адреси.
    ///
    /// Подоцна, функцијата `resolve` може да се повика да ги разреши симболите на оваа задна страна во читливи имиња.
    /// Оваа функција постои затоа што процесот на резолуција понекогаш може да потрае значително време, додека секое враќање може ретко да се печати.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // нема имиња на симболи
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // имиња на симболи сега присутни
    /// ```
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    ///
    #[inline(never)] // сакате да бидете сигурни дека тука има рамка за отстранување
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Ги враќа рамките од кога е зафатена оваа задна врата.
    ///
    /// Првиот запис на ова парче е најверојатно функцијата `Backtrace::new`, а последниот кадар веројатно е нешто за тоа како започна оваа нишка или главната функција.
    ///
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ако оваа повратна траса е создадена од `new_unresolved`, тогаш оваа функција ќе ги реши сите адреси во заднината на нивните симболични имиња.
    ///
    ///
    /// Ако ова враќање е претходно решено или е создадено преку `new`, оваа функција не прави ништо.
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Исто како `Frame::ip`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Исто како `Frame::symbol_address`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Исто како `Frame::module_base_address`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Го враќа списокот со симболи на кои одговара оваа рамка.
    ///
    /// Нормално, има само еден симбол по рамка, но понекогаш ако голем број на функции се вметнат во една рамка, тогаш повеќе симболи ќе бидат вратени.
    /// Првиот наведен симбол е "innermost function", додека последниот симбол е најоддалечениот (последниот повикувач).
    ///
    /// Имајте на ум дека ако оваа рамка дојде од нерешено повратно влечење, тогаш ова ќе врати празен список.
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Исто како `Symbol::name`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Исто како `Symbol::addr`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Исто како `Symbol::filename`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Исто како `Symbol::lineno`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Исто како `Symbol::colno`
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Кога печатиме патеки, се обидуваме да го соблечеме cwd ако постои, инаку само ја отпечатиме патеката каква што е.
        // Забележете дека ова го правиме само за краток формат, бидејќи ако е полн, се претпоставува дека сакаме да испечатиме сè.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}