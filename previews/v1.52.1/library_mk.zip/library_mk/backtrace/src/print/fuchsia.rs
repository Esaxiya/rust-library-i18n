use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr зема повратен повик што ќе добие dl_phdr_info покажувач за секој ДСО што е поврзан со процесот.
    // dl_iterate_phdr исто така гарантира дека динамичкиот поврзувач е заклучен од почеток до крај на повторувањето.
    // Ако повратокот врати не-нулта вредност, повторувањето се прекинува рано.
    // 'data' ќе биде предаден како трет аргумент на повратен повик на секој повик.
    // 'size' ја дава големината на dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Треба да ги анализираме ID-то за градење и некои основни податоци за заглавието на програмата што значи дека ни требаат малку работи и од спецификацијата на ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Сега треба да ја реплицираме, малку по малку, структурата од типот dl_phdr_info што ја користи тековниот динамичен поврзувач на фуксија.
// Хром, исто така, ја има оваа граница на АБИ, како и паѓачката несреќа.
// На крајот, ние би сакале да ги преместиме овие случаи да користат елф-пребарување, но треба да го обезбедиме тоа во СДК и тоа сè уште не е направено.
//
// Така, ние (и тие) сме заглавени да треба да го користиме овој метод што нанесува тесна спојка со фуксија либц.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Немаме начин да знаеме да провериме дали e_phoff и e_phnum се валидни.
    // libc треба да го обезбеди ова за нас, па затоа е безбедно да се формира парче тука.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr претставува 64-битен заглавие на програмата ELF во крајноста на целната архитектура.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr претставува валиден заглавие на програмата ELF и неговата содржина.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Немаме начин да провериме дали p_addr или p_memsz се валидни.
    // Fuchsia's libc прво ги анализира белешките, но затоа што се тука, овие заглавија мора да бидат валидни.
    //
    // NoteIter не бара основните податоци да бидат валидни, но бара границите да бидат валидни.
    // Ние веруваме дека libc обезбеди дека ова е случај за нас овде.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Вид на белешка за идентификација на градење.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr претставува заглавие на белешката ELF во крајноста на целта.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Белешката претставува ELF белешка (заглавие + содржина).
// Името е оставено како парче u8 затоа што не е секогаш ништовно завршено и rust го прави доволно лесен за да провери дали бајтите се совпаѓаат.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ви овозможува безбедно да повторувате преку сегментот за белешки.
// Завршува веднаш штом се појави грешка или нема повеќе белешки.
// Ако повторувате преку невалидни податоци, тие ќе функционираат како да не се пронајдени белешки.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Непроменлива е функцијата што покажувачот и дадената големина означуваат валиден опсег на бајти што може да се прочитаат сите.
    // Содржината на овие бајти може да биде која било, но опсегот мора да биде валиден за ова да биде безбедно.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to го усогласува 'x' со усогласувањето од 'до' бајт под претпоставка дека 'to' е моќност од 2.
// Ова следи стандардна шема во кодот за парсирање на C/C ++ ELF каде што се користат (x + до, 1)&-to.
// Rust не дозволува да ја негирате употребата затоа што користам
// Конверзија на комплементот 2 за да се пресоздаде тоа.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 троши нум бајти од парчето (доколку е присутно) и дополнително осигурува дека финалното парче е правилно порамнето.
// Ако или, бројот на барани бајти е преголем или парчето не може да се постави повторно, затоа што нема доволно бајти што постојат, Никој не се враќа и парчето не е изменето.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Оваа функција нема вистински инварианти што повикувачот мора да ги почитува, освен можеби 'bytes' да биде усогласен за перформанси (и за точноста на некои архитектури).
// Вредностите во полињата Elf_Nhdr може да бидат глупости, но оваа функција не гарантира такво нешто.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ова е безбедно сè додека има доволно простор и ние само го потврдивме тоа во изјавата if погоре, ова не треба да биде небезбедно.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Забележете дека sice_of: :<Elf_Nhdr>() е секогаш подредено со 4 бајти.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Проверете дали сме стигнале до крајот.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Ние трансмутираме nhdr, но внимателно ги разгледуваме добиените структури.
        // Ние не веруваме во namesz или descsz и не донесуваме небезбедни одлуки врз основа на видот.
        //
        // Значи, дури и ако извлечеме целосно ѓубре, сепак треба да бидеме безбедни.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Укажува дека еден сегмент е извршен.
const PERM_X: u32 = 0b00000001;
/// Укажува дека еден сегмент е запислив.
const PERM_W: u32 = 0b00000010;
/// Укажува дека еден сегмент е читлив.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Претставува сегмент ELF при траење.
struct Segment {
    /// Ја дава виртуелната адреса за време на траење на содржините на овој сегмент.
    addr: usize,
    /// Ја дава големината на меморијата на содржината на овој сегмент.
    size: usize,
    /// Ја дава модулот виртуелна адреса на овој сегмент со датотеката ELF.
    mod_rel_addr: usize,
    /// Дава дозволи пронајдени во датотеката ELF.
    /// Сепак, овие дозволи не се нужно дозволи присутни во времето на траење.
    flags: Perm,
}

/// Овозможува едно повторување преку Сегменти од ОДС.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Претставува ELF DSO (динамички споделен објект).
/// Овој тип ги упатува податоците зачувани во реалниот ОДС наместо да прави своја копија.
struct Dso<'a> {
    /// Динамичниот поврзувач секогаш ни дава име, дури и ако името е празно.
    /// Во случај на главната извршна форма, ова име ќе биде празно.
    /// Во случај на споделен предмет, тоа ќе биде сонамот (види DT_SONAME).
    name: &'a str,
    /// На Fuchsia буквално сите бинарни тела имаат ID-а за градење, но тоа не е строго барање.
    /// Нема начин да се совпаднат информациите за ДСО со вистинска ELF-датотека потоа, ако нема build_id, затоа бараме секој ОДС да има по еден овде.
    ///
    /// ОБС без build_id се игнорираат.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Враќа повторувач над Сегментите во овој ОДС.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Овие грешки кодираат проблеми што се јавуваат при анализирање на информации за секој ОДС.
///
enum Error {
    /// NameError значи дека настанала грешка при конвертирање на низа во стил C во низа rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError значи дека не најдовме проект за градба.
    /// Ова може да биде затоа што ОДС немаше проект за градење или затоа што сегментот што го содржи градежниот ID беше неправилен.
    ///
    BuildIDError,
}

/// Повикува или 'dso' или 'error' за секој ДСО поврзан со процесот со динамички поврзувач.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter кој ќе има еден од методите за јадење, наречен foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr гарантира дека info.name ќе укаже на валидна локација.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Оваа функција ја печати ознаката на симболизаторот Фуксија за сите информации содржани во ОДС.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}