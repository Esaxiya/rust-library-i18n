//! Поддршка за симболизација користејќи `gimli` crate на crates.io
//!
//! Ова е стандардната имплементација на симболизацијата за Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // " статичкиот животен век е лага за хакирање околу недостатокот на поддршка за самореферентни удари.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Претворете во " статички животен век` бидејќи симболите треба да позајмуваат само `map` и `stash` и ги зачувуваме подолу.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // За вчитување на матични библиотеки на Windows, видете одредена дискусија за rust-lang/rust#71060 за различните стратегии овде.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Библиотеките на MinGW во моментов не поддржуваат ASLR (rust-lang/rust#16514), но DLL-ите сè уште можат да се преместуваат во просторот за адреси.
            // Се чини дека адресите во информациите за дебагирање се како оваа библиотека да е натоварена на нејзиниот "image base", што е поле во нејзините заглавија на датотеките COFF.
            // Бидејќи ова е она што дебагинфо се чини дека го наведува, ние ја анализираме табелата со симболи и адресите на продавниците како да е опремена библиотеката и на "image base".
            //
            // Библиотеката можеби не е вчитана на "image base".
            // (се претпоставува дека нешто друго може да се вчита таму?) Ова е местото каде што влегува во игра полето `bias` и ние треба да ја откриеме вредноста на `bias` тука.За жал, не е јасно како да го набавите ова од натоварен модул.
            // Она што го имаме, сепак е вистинската адреса за оптоварување (`modBaseAddr`).
            //
            // Како малку полицаец за сега, ние ја мапираме датотеката, ги читаме информациите за заглавието на датотеката, па паѓаме на mmap.Ова е расипничко, бидејќи подоцна веројатно повторно ќе го отвориме ммпапот, но ова засега треба да работи доволно добро.
            //
            // Откако ќе ги имаме `image_base` (саканата локација на товарот) и `base_addr` (вистинската локација на товарот), можеме да го пополниме `bias` (разлика помеѓу вистинската и посакуваната), а потоа наведената адреса на секој сегмент е `image_base` бидејќи тоа е она што го вели датотеката.
            //
            //
            // За сега се чини дека за разлика од ELF/MachO можеме да успееме со еден сегмент по библиотека, користејќи `modBaseSize` како целата големина.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS го користи форматот на датотека Mach-O и користи API-специфични за DYLD за да вчита список на природни библиотеки што се дел од апликацијата.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Преземете го името на оваа библиотека што одговара на патеката каде да се вчита исто така.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Вчитајте го заглавието на сликата во оваа библиотека и делегирајте на `object` за да ги анализира сите команди за оптоварување за да можеме да ги откриеме сите сегменти вклучени тука.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Повторувајте ги сегментите и регистрирајте ги познатите региони за сегментите што ги наоѓаме.
            // Дополнително запишете ги сегментите за текст на информации за обработка подоцна, видете ги коментарите подолу.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Определете го "slide" за оваа библиотека што завршува како пристрасност што ја користиме за да откриеме каде се вчитани објектите во меморијата.
            // Ова е малку чудна пресметка и е резултат на обид на неколку работи во дивината и гледање што се држи.
            //
            // Општата идеја е дека `bias` плус `stated_virtual_memory_address` сегмент ќе биде таму каде што се наоѓа сегментот во реалниот простор за адреси.
            // Другата работа на која се потпираме е сепак дека вистинска адреса минус `bias` е индексот што треба да се погледне во табелата со симболи и дебагирање.
            //
            // Излегува, сепак, дека за системски опремени библиотеки овие пресметки се неточни.За мајчините извршни, сепак, се чини правилно.
            // Подигајќи одредена логика од изворот на LLDB, има посебна обвивка за првиот дел `__TEXT` натоварен од датотеката што се надоместува 0 со нулта големина.
            // Од која било причина кога ова е присутно, се чини дека значи дека табелата со симболи е релативна на само слајдот vmaddr за библиотеката.
            // Ако *не е* присутна, тогаш табелата со симболи е во однос на слајдот vmaddr плус наведената адреса на сегментот.
            //
            // Да се справиме со оваа ситуација ако * не најдеме дел за текст во нултата нуклеарна датотека, тогаш ја зголемуваме пристрасноста според наведената адреса на првите делови за текст и ги намалуваме сите наведени адреси и за таа сума.
            //
            // На тој начин, табелата со симболи секогаш се појавува во однос на износот на пристрасност на библиотеката.
            // Се чини дека ова ги има вистинските резултати за симболизирање преку табелата со симболи.
            //
            // Искрено, не сум целосно сигурен дали е тоа правилно или има нешто друго што треба да покаже како да се направи ова.
            // Засега, се чини дека ова работи доволно добро (?) и секогаш треба да можеме да го прилагодуваме ова, ако е потребно.
            //
            // За повеќе информации, видете #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Друго Unix (на пр
        // Linux) платформите користат ELF како формат на датотека на објект и обично спроведуваат API наречен `dl_iterate_phdr` за вчитување на природни библиотеки.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` треба да бидат валидни покажувачи.
        // `vec` треба да биде валиден покажувач на `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 не поддржува автоматски информации за дебагирање, но системот за градење ќе постави информации за дебагирање на патеката `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Сè друго треба да користи ELF, но не знае како да вчита домашни библиотеки.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Вчитани се сите познати споделени библиотеки.
    libraries: Vec<Library>,

    /// Меширање на мемории каде што ги задржуваме разложените информации за џуџе.
    ///
    /// Оваа листа има фиксен капацитет за целокупното време на одржување кој никогаш не се зголемува.
    /// `usize` елементот на секој пар е индекс во `libraries` горе каде што `usize::max_value()` ја претставува тековната извршна.
    ///
    /// `Mapping` е соодветна анализирана информација за џуџе.
    ///
    /// Забележете дека ова во основа е LRU-меморија и ние ќе ги смениме работите овде додека симболизираме адреси.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Сегментите од оваа библиотека се вчитани во меморијата и каде што се вчитани.
    segments: Vec<LibrarySegment>,
    /// "bias" на оваа библиотека, обично таму каде што е вчитана во меморијата.
    /// Оваа вредност се додава на наведената адреса на секој сегмент за да се добие вистинската адреса на виртуелна меморија во која е вчитан сегментот.
    /// Дополнително, оваа пристрасност се одзема од адресите на вистинската виртуелна меморија за да се индексира во дебагинфо и табелата со симболи.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Наведената адреса на овој сегмент во датотеката со објектот.
    /// Ова всушност не е местото каде што се вчитува сегментот, туку оваа адреса плус `bias` содржана во библиотеката е каде да се најде.
    ///
    stated_virtual_memory_address: usize,
    /// Големината на сегментот на THS во меморијата.
    len: usize,
}

// небезбедно затоа што ова се бара да биде синхронизирано однадвор
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // небезбедно затоа што ова се бара да биде синхронизирано однадвор
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Многу мала, многу едноставна LRU-меморија за мапирање со информации за дебагирање.
        //
        // Стапката на хит треба да биде многу висока, бидејќи типичниот оџак не се вкрстува меѓу многу споделени библиотеки.
        //
        // Структурите `addr2line::Context` се прилично скапи за креирање.
        // Неговата цена се очекува да биде амортизирана од следните пребарувања `locate`, кои ги користат структурите изградени при конструирање на `addr2line: : Context` за да добијат убави брзини.
        //
        // Ако не ја имавме оваа меморија, таа амортизација никогаш нема да се случи, а симболизирачките повратни ефекти ќе беа ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Прво, тестирајте дали овој `lib` има некој сегмент кој содржи `addr` (ракување со преместување).Ако оваа проверка помине, можеме да продолжиме подолу и всушност да ја преведеме адресата.
                //
                // Забележете дека тука користиме `wrapping_add` за да избегнеме проверки на прелевање.Во дивината се виде дека пресметката на пристрасност на SVMA + се прелева.
                // Се чини дека е малку чудно што тоа би се случило, но не можеме да сториме огромна сума, освен веројатно само да ги игнорираме тие сегменти, бидејќи тие веројатно се насочуваат кон вселената.
                //
                // Ова првично излезе во rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Сега кога знаеме дека `lib` содржи `addr`, можеме да се надоместиме со пристрасност да ја најдеме наведената адреса за вирутална меморија.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Непроменлива: откако овој условен ќе заврши без предвремено враќање
        // од грешка, записот за кеш за оваа патека е на индекс 0.

        if let Some(idx) = idx {
            // Кога мапирањето е веќе во меморијата, преместете го на предната страна.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Кога мапирањето не е во меморијата, креирајте ново пресликување, вметнете го во предниот дел на меморијата и исфрлете го најстариот запис за меморија доколку е потребно.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // не истекувајте го животниот век на `'static`, проверете дали е наменет само за нас самите
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Продолжете го животниот век на `sym` на `'static` бидејќи за жал од нас се бара тука, но тоа е единствено што излегува како референца, затоа и онака не треба да се надминува никакво повикување на него.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Конечно, добиете кеширано мапирање или креирајте ново мапирање за оваа датотека и проценете ги информациите за DWARF за да го пронајдете file/line/name за оваа адреса.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Ние бевме во можност да ги лоцираме информациите за рамката за овој симбол, а рамката на `addr2line` внатрешно ги има сите детали со ситни житни.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Не можевме да ги најдеме информациите за дебагирање, но ги најдовме во табелата со симболи на елфот што може да се изврши.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}