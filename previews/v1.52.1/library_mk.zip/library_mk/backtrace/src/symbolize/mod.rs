use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Реши адреса на симбол, поминувајќи го симболот до наведениот затворач.
///
/// Оваа функција ќе ја бара дадената адреса во области како што се табелата за локални симболи, табелата за динамички симболи или информациите за отстранување грешки на DWARF (во зависност од активираната имплементација) за да пронајдат симболи за давање.
///
///
/// Затворањето не може да се повика ако резолуцијата не може да се изврши, а исто така може да се повика повеќе од еднаш во случај на подвлечени функции.
///
/// Дадените симболи претставуваат извршување на наведениот `addr`, враќајќи ги паровите file/line за таа адреса (доколку е достапно).
///
/// Забележете дека ако имате `Frame`, тогаш се препорачува да ја користите функцијата `resolve_frame` наместо оваа.
///
/// # Потребни карактеристики
///
/// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
///
/// # Panics
///
/// Оваа функција се обидува никогаш да не биде panic, но ако `cb` обезбеди panics, тогаш некои платформи ќе принудат двојно panic да го прекине процесот.
/// Некои платформи користат библиотека C што внатрешно користи повратен повик што не може да се одмотува, па паничноста од `cb` може да предизвика прекинување на процесот.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // погледнете ја само горната рамка
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Решете ја претходната рамка за снимање на симбол, поминувајќи го симболот до наведениот затворач.
///
/// Овој функтин ја извршува истата функција како `resolve`, освен што зема `Frame` како аргумент наместо адреса.
/// Ова може да дозволи некои имплементации на платформата на повратното трасирање да обезбедат поточни информации за симболи или информации за вградени рамки на пример
///
/// Препорачливо е да го користите ова ако можете.
///
/// # Потребни карактеристики
///
/// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
///
/// # Panics
///
/// Оваа функција се обидува никогаш да не биде panic, но ако `cb` обезбеди panics, тогаш некои платформи ќе принудат двојно panic да го прекине процесот.
/// Некои платформи користат библиотека C што внатрешно користи повратен повик што не може да се одмотува, па паничноста од `cb` може да предизвика прекинување на процесот.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // погледнете ја само горната рамка
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Вредностите на IP од рамките на магацинот обично се (always?) инструкции *по* повикот што е вистинската трага на оџакот.
// Со симболизирање на ова, бројот на filename/line е еден пред и можеби во празнина ако е при крај на функцијата.
//
// Ова се чини дека во основа секогаш е случај на сите платформи, така што секогаш го одземаме еден од решениот ip за да го решиме на претходната инструкција за повик, наместо на инструкцијата да биде вратена.
//
//
// Идеално не би го сториле ова.
// Идеално, ќе бараме повикувачи на `resolve` API рачно да го направат -1 и да земат предвид дека сакаат информации за локацијата за *претходната* инструкција, а не за тековната.
// Идеално би се изложиле и на `Frame` ако навистина сме адреса на следната инструкција или струјата.
//
// Засега, ова е прилично интересна загриженост, затоа ние само интерно секогаш одземаме една.
// Потрошувачите треба да продолжат да работат и да добиваат прилично добри резултати, па затоа треба да бидеме доволно добри.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Исто како `resolve`, само небезбедно, бидејќи е несинхронизирано.
///
/// Оваа функција нема гаранти за синхронизација, но е достапна кога `std` одликата на овој crate не е компајлирана.
/// Погледнете ја функцијата `resolve` за повеќе документација и примери.
///
/// # Panics
///
/// Погледнете информации за `resolve` за забелешки на паника за `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Исто како `resolve_frame`, само небезбедно, бидејќи е несинхронизирано.
///
/// Оваа функција нема гаранти за синхронизација, но е достапна кога `std` одликата на овој crate не е компајлирана.
/// Погледнете ја функцијата `resolve_frame` за повеќе документација и примери.
///
/// # Panics
///
/// Погледнете информации за `resolve_frame` за забелешки на паника за `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait претставува резолуција на симбол во датотека.
///
/// Овој trait е даден како trait пред затворањето дадено на функцијата `backtrace::resolve`, и тој е практично испратен бидејќи не е познато која е имплементацијата зад неа.
///
///
/// Симбол може да даде контекстуални информации за некоја функција, на пример име, име на датотека, број на линија, прецизна адреса, итн.
/// Сепак, не се сите информации достапни во симбол, затоа сите методи враќаат `Option`.
///
///
pub struct Symbol {
    // TODO: овој животен век треба да се продолжи на крајот до `Symbol`,
    // но тоа во моментов е огромна промена.
    // Сега за сега ова е безбедно бидејќи `Symbol` е предаден само некогаш по препорака и не може да се клонира.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Го враќа името на оваа функција.
    ///
    /// Вратената структура може да се искористи за пребарување на разни својства за името на симболот:
    ///
    ///
    /// * Имплементацијата `Display` ќе го испечати демандлираниот симбол.
    /// * Може да се пристапи до суровата вредност `str` на симболот (ако е валидна utf-8).
    /// * Може да се пристапи до сурови бајти за името на симболот.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ја враќа почетната адреса на оваа функција.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Го враќа суровото име на датотека како парче.
    /// Ова е главно корисно за `no_std` средини.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Го враќа бројот на колоната за местото каде што моментално се извршува овој симбол.
    ///
    /// Само gimli моментално дава вредност тука, па дури и тогаш само ако `filename` врати `Some`, и затоа, следствено, е предмет на слични предупредувања.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Го враќа бројот на линијата за местото каде што моментално се извршува овој симбол.
    ///
    /// Оваа повратна вредност е типично `Some` ако `filename` врати `Some`, и како последица на тоа е предмет на слични предупредувања.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Го враќа името на датотеката каде што е дефинирана оваа функција.
    ///
    /// Ова во моментов е достапно само кога се користат libbacktrace или gimli (на пр
    /// unix платформи други) и кога бинарната програма е составена со дебагинфо.
    /// Ако ниту еден од овие услови не е исполнет, тоа најверојатно ќе го врати `None`.
    ///
    /// # Потребни карактеристики
    ///
    /// Оваа функција бара да биде овозможена одликата `std` на `backtrace` crate, а функцијата `std` е стандардно овозможена.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Можеби е парсиран симбол C++ , ако не се успее парсирањето на обележаниот симбол како Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Осигурете се да ја задржите оваа нула големина, така што одликата `cpp_demangle` нема трошоци кога е оневозможена.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Обвивка околу името на симболот за да се обезбедат ергономски додатоци на демангалираното име, суровите бајти, суровата низа итн.
///
// Дозволете мртов код кога функцијата `cpp_demangle` не е овозможена.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Создава ново име на симбол од суровите основни бајти.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Го враќа необработеното име на симболот (mangled) како `str` ако симболот е валиден utf-8.
    ///
    /// Користете ја имплементацијата `Display` ако сакате демангирана верзија.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Го враќа името на сировиот симбол како список на бајти
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ова може да се отпечати ако демандлираниот симбол всушност не е валиден, затоа справувајте се со грешката тука благодатно, не пропагирајќи ја нанадвор.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Обид да се врати таа зачувана меморија што се користеше за симболизирање на адреси.
///
/// Овој метод ќе се обиде да ги ослободи сите глобални структури на податоци што инаку биле зачувани на глобално ниво или во низата, што обично претставуваат парсирани информации за DWARF или слично.
///
///
/// # Caveats
///
/// Иако оваа функција е секогаш достапна, таа всушност не прави ништо за повеќето имплементации.
/// Библиотеките како dbghelp или libbacktrace не обезбедуваат можности за распределување на состојбата и управување со доделената меморија.
/// Засега карактеристиката `gimli-symbolize` на овој crate е единствената карактеристика каде оваа функција има каков било ефект.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}