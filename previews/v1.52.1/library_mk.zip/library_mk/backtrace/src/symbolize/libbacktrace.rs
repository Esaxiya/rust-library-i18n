//! Стратегија за симболизација со користење на кодот за парсирање DWARF во libbacktrace.
//!
//! Библиотеката libbacktrace C, типично дистрибуирана со gcc, поддржува не само генерирање на backtrace (што всушност не го користиме), туку исто така симболизира и backtrace и ракување со џуџести информации за дебагирање за работи како што се вметнатите рамки и што друго.
//!
//!
//! Ова е релативно комплицирано поради многу различни грижи тука, но основната идеја е:
//!
//! * Прво се јавуваме `backtrace_syminfo`.Ова добива информации за симболи од табелата за динамички симболи, ако можеме.
//! * Следно го нарекуваме `backtrace_pcinfo`.Ова ќе ги анализира табелите за дебагирање ако се достапни и ќе ни овозможи да ги повратиме информациите за вградените рамки, имињата на датотеките, броевите на линиите итн.
//!
//! Постојат многу трикови околу внесувањето на џуџестите маси во libbacktrace, но се надевам дека тоа не е крај на светот и е доволно јасен кога читате подолу.
//!
//! Ова е стандардната стратегија за симболизација за платформите што не се MSVC и кои не се OSX.Во libstd, ова е стандардната стратегија за OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ако е можно, претпочитајте го името `function` што доаѓа од дебагинфо и обично може да биде поточно за вградените рамки на пример.
                // Ако тоа не е присутно, вратете се на името на табелата со симболи наведени во `symname`.
                //
                // Имајте на ум дека понекогаш `function` може да се чувствува нешто помалку прецизно, на пример да се наведе како `try<i32,closure>` наместо на `std::panicking::try::do_call`.
                //
                // Не е навистина јасно зошто, но во целина името `function` изгледа поточно.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // не прават ништо за сега
}

/// Вид на покажувачот `data` пренесен во `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Откако ќе се повика овој повратен повик од `backtrace_syminfo` кога ќе започнеме да решаваме, одиме понатаму да повикаме `backtrace_pcinfo`.
    // Функцијата `backtrace_pcinfo` ќе консултира информации за дебагирање и ќе се обиде да направи работи како што се враќање на информациите file/line, како и вградени рамки.
    // Но, забележете дека `backtrace_pcinfo` може да пропадне или да не стори многу ако нема информации за дебагирање, па ако тоа се случи, сигурно ќе повикаме повратен повик со барем еден симбол од `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Вид на покажувачот `data` пренесен во `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API поддржува создавање држава, но не поддржува уништување држава.
// Јас лично сметам дека ова значи дека треба да се создаде држава, а потоа да живее вечно.
//
// Би сакал да регистрирам управувач at_exit() што ја чисти оваа состојба, но libbacktrace не дава начин за тоа.
//
// Со овие ограничувања, оваа функција има статички зачувана состојба што се пресметува првиот пат кога ќе се побара.
//
// Запомнете дека повраќањето на сè се случува сериски (една глобална брава).
//
// Забележете дека недостатокот на синхронизација тука се должи на барањето `resolve` да биде надворешно синхронизиран.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не вежбајте безбедни способности на libbacktrace бидејќи секогаш тоа го нарекуваме синхронизирано.
        //
        0,
        error_cb,
        ptr::null_mut(), // нема дополнителни податоци
    );

    return STATE;

    // Забележете дека за да работи Libbacktrace воопшто, треба да ги најде информациите за дебагирање на DWARF за тековната извршна форма.Тоа обично го прави тоа преку голем број механизми, вклучувајќи, но не ограничувајќи се на:
    //
    // * /proc/self/exe на поддржани платформи
    // * Името на датотеката е експлицитно пренесено кога се создава состојба
    //
    // Библиотеката libbacktrace е голема шифра C.Ова природно значи дека има ранливости на безбедноста во меморијата, особено кога ракувате со неправилно дебагирање.
    // Исто така, Libstd наиде на многу вакви.
    //
    // Ако се користи /proc/self/exe, тогаш можеме обично да ги игнорираме овие, бидејќи претпоставуваме дека libbacktrace е "mostly correct" и во спротивно не прави чудни работи со "attempted to be correct" информации за џуџести грешки.
    //
    //
    // Меѓутоа, ако внесеме име на датотека, тогаш тоа е можно на некои платформи (како BSD) каде што злонамерен актер може да предизвика поставување произволна датотека на таа локација.
    // Ова значи дека ако му кажеме на libbacktrace за името на датотеката, тоа може да користи произволна датотека, веројатно предизвикувајќи секфолт.
    // Ако не му кажеме на libbacktrace ништо, тогаш тоа нема да стори ништо на платформите што не поддржуваат патеки како /proc/self/exe!
    //
    // Со оглед на сето тоа, ние се обидуваме што е можно повеќе да не * поминеме во име на датотека, но мора да бидеме на платформи кои воопшто не поддржуваат /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Забележете дека идеално би користеле `std::env::current_exe`, но тука не можеме да бараме `std`.
            //
            // Користете `_NSGetExecutablePath` за да ја вчитате тековната извршна патека во статичка област (која ако е премала само откажете се).
            //
            //
            // Забележете дека овде сериозно веруваме во libbacktrace за да не умреме од корумпирани извршни, но сигурно ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows има режим на отворање датотеки каде што по нејзиното отворање не може да се избрише.
            // Во принцип, тоа е она што го сакаме овде, затоа што сакаме да осигураме дека нашата извршна функција нема да се менува под нас откако ќе ја предадеме на libbacktrace, се надеваме дека ја ублажуваме можноста да поминеме произволно податоци во libbacktrace (што може да биде лошо ракувано).
            //
            //
            // Со оглед на тоа дека ние малку танцуваме тука за да се обидеме да добиеме еден вид заклучување на сопствената слика:
            //
            // * Добијте справи со тековниот процес, вчитајте го името на датотеката.
            // * Отворете датотека на тоа име на датотека со вистинските знамиња.
            // * Повторно вчитајте го името на датотеката на тековниот процес, осигурувајќи се дека е исто
            //
            // Ако тоа помине, ние во теорија навистина ги отворивме датотеките на нашиот процес и гарантирано нема да се промени.FWIW историски е копиран од ова, па ова е моето најдобро толкување за тоа што се случуваше.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ова живее во статичка меморија за да можеме да го вратиме ..
                static mut BUF: [i8; N] = [0; N];
                // ... и ова живее на магацинот бидејќи е привремено
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // намерно истекуваме `handle` тука затоа што ако го имаме тоа отворено, треба да се зачува заклучувањето на ова име на датотека.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ние сакаме да вратиме парче што е нулта завршено, па ако сè беше пополнето и е еднакво на вкупната должина, тогаш изедначи го со неуспех.
                //
                //
                // Инаку, при враќање на успехот, проверете дали нул-бајтот е вклучен во парчето.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // грешките во задниот дел се моментално подметнати под тепихот
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Јавете се на `backtrace_syminfo` API кој (од читање на кодот) треба да се јави `syminfo_cb` точно еднаш (или да не успее со грешка веројатно).
    // Потоа се справуваме со повеќе во рамките на `syminfo_cb`.
    //
    // Забележете дека го правиме ова бидејќи `syminfo` ќе ја консултира табелата со симболи, наоѓајќи имиња на симболи дури и ако нема бинарни информации за дебагирање.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}