// се користи само на Linux токму сега, затоа дозволете мртов код на друго место
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Едноставен алокатор на арената за бајтерски бафери.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Алоцира тампон со наведената големина и враќа на него некаква промена.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕЗБЕДНОСТ: ова е единствената функција што некогаш конструира мутабилна
        // повикување на `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕЗБЕДНОСТ: ние никогаш не отстрануваме елементи од `self.buffers`, затоа е референца
        // на податоците во кој било тампон ќе живеат се додека живее `self`.
        &mut buffers[i]
    }
}