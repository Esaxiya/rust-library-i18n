//! Модул кој помага во управувањето со врзувањата на dbghelp на Windows
//!
//! Вратите на Windows (барем за MSVC) во голема мера се напојуваат преку `dbghelp.dll` и различните функции што ги содржи.
//! Овие функции се вчитуваат *динамички* наместо да се поврзуваат статички со `dbghelp.dll`.
//! Ова во моментот го прави стандардната библиотека (и теоретски се бара таму), но е обид да се помогне во намалување на статичките DLL зависности од библиотеката бидејќи повратните траги се обично прилично опционални.
//!
//! Како што се рече, `dbghelp.dll` скоро секогаш успешно се вчитува на Windows.
//!
//! Забележете дека бидејќи динамично ја вчитуваме сета оваа поддршка, не можеме да ги користиме суровите дефиниции во `winapi`, туку треба да ги дефинираме типовите на покажувачот на функциите и да го користиме тоа.
//! Ние навистина не сакаме да се занимаваме со дуплирање на winapi, затоа имаме карактеристика Cargo `verify-winapi` која тврди дека сите врски се совпаѓаат со оние во winapi и оваа одлика е овозможена на CI.
//!
//! Конечно, тука ќе забележите дека dll за `dbghelp.dll` никогаш не се растоварува, и тоа во моментов е намерно.
//! Размислувањето е дека можеме глобално да го кешираме и да го користиме помеѓу повиците кон API, избегнувајќи скап loads/unloads.
//! Ако ова е проблем за детекторите за истекување или нешто слично на тоа, можеме да го поминеме мостот кога ќе стигнеме таму.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Работете околу `SymGetOptions` и `SymSetOptions` да не бидат присутни во самата winapi.
// Инаку, ова се користи само кога двојно проверуваме типови против winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Сè уште не е дефинирано во винапи
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ова е дефинирано во winapi, но е неточно (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Сè уште не е дефинирано во винапи
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Оваа макро се користи за дефинирање на структура `Dbghelp` која внатрешно ги содржи сите покажувачи на функции што може да ги вчитаме.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Вчитаната DLL за `dbghelp.dll`
            dll: HMODULE,

            // Секој покажувач на функција за секоја функција што можеме да ја користиме
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Првично не ја вчитавме DLL
            dll: 0 as *mut _,
            // Првично, сите функции се поставени на нула за да кажат дека треба динамички да се вчитаат.
            //
            $($name: 0,)*
        };

        // Право погоден тип за секој тип на функција.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Обиди да се отвори `dbghelp.dll`.
            /// Враќа успех ако работи или грешка ако `LoadLibraryW` не успее.
            ///
            /// Panics ако библиотеката е веќе натоварена.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Функција за секој метод што би сакале да го користиме.
            // Кога ќе се повика, тој или ќе го прочита покажувачот на зачуваната функција или ќе го вчита и ќе ја врати вчитаната вредност.
            // Товарите се тврдат за да успеат.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Помош за прокси да ги користите бравите за чистење за да ги повикате функциите на помошна помош.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Иницијализирајте ја целата поддршка неопходна за пристап до функциите `dbghelp` API од овој crate.
///
///
/// Забележете дека оваа функција е **безбедна**, таа внатрешно има своја синхронизација.
/// Исто така, забележете дека е безбедно да ја повикате оваа функција повеќе пати рекурзивно.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Прво што треба да сториме е да ја синхронизираме оваа функција.Ова може да се нарече истовремено од други нишки или рекурзивно во рамките на една нишка.
        // Забележете дека е поинтригантно од тоа, затоа што она што го користиме овде, `dbghelp`,*исто така* треба да се синхронизира со сите други повикувачи на `dbghelp` во овој процес.
        //
        // Обично, нема толку многу повици кон `dbghelp` во рамките на истиот процес и веројатно можеме безбедно да претпоставиме дека само ние пристапуваме до него.
        // Меѓутоа, има уште еден примарен корисник за кој треба да се грижиме, што е иронично, но во стандардната библиотека.
        // Стандардната библиотека Rust зависи од овој crate за поддршка за повратна трага, а овој crate исто така постои и на crates.io.
        // Ова значи дека ако стандардната библиотека печати panic backtrace, тоа може да се натпреварува со овој crate што доаѓа од crates.io, предизвикувајќи секфолт.
        //
        // За да помогнеме во решавањето на овој проблем со синхронизација, тука користиме трик специфичен за Виндоус (тоа е, на крај, ограничување за синхронизација специфично за Виндоус).
        // Ние создаваме *сесија-локална* со име mutex за да го заштитиме овој повик.
        // Намерата тука е дека стандардната библиотека и овој crate не мора да споделуваат API на ниво на Rust за да ги синхронизираат тука, туку можат да работат зад сцената за да се осигурат дека се синхронизираат едни со други.
        //
        // На тој начин кога оваа функција се повикува преку стандардната библиотека или преку crates.io можеме да бидеме сигурни дека истиот мутекс се стекнува.
        //
        // Значи, сето тоа е да се каже дека првото нешто што го правиме тука е да создадеме атомски `HANDLE` кој е именуван мутекс на Windows.
        // Малку се синхронизираме со другите нишки што ја споделуваат оваа функција специфично и осигуруваме дека е создадена само една рачка на пример на оваа функција.
        // Забележете дека рачката никогаш не е затворена откако е зачувана во глобалната.
        //
        // Откако навистина ја заклучивме бравата, едноставно ја стекнавме и нашата рачка `Init` што ќе ја предадеме ќе биде одговорна за исфрлање на крајот.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Добро, венче!Сега, кога сите сме безбедно синхронизирани, да почнеме всушност да обработуваме сè.
        // Прво, треба да осигураме дека `dbghelp.dll` е вчитан во овој процес.
        // Ова го правиме динамично за да избегнеме статичка зависност.
        // Ова историски е направено за да се работи околу чудни проблеми со поврзување и има за цел да ги направи бинарните подвижни малку пофреквентни бидејќи ова е во голема мера само алатка за дебагирање.
        //
        //
        // Откако ќе го отвориме `dbghelp.dll`, треба да повикаме некои функции за иницијализација во него, а тоа е детално подолу.
        // Ова го правиме само еднаш, па затоа добивме глобален булоин што покажува дали сме завршиле или не.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Осигурете се дека е поставено знамето `SYMOPT_DEFERRED_LOADS`, бидејќи според сопствените документи на MSVC за ова: "This is the fastest, most efficient way to use the symbol handler.", па да го сториме тоа!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Всушност, иницијализирајте ги симболите со MSVC.Забележете дека ова може да не успее, но ние го игнорираме.
        // Нема само еден тон претходна уметност само по себе, но LLVM внатрешно се чини дека тука ја игнорира повратната вредност и една од библиотеките за дезинфекција во LLVM печати застрашувачко предупредување ако тоа не успее, но во основа го игнорира на долг рок.
        //
        //
        // Еден случај што се појави многу за Rust е тоа што стандардната библиотека и овој crate на crates.io сакаат да се натпреваруваат за `SymInitializeW`.
        // Стандардната библиотека историски сакаше да го иницијализира чистењето во најголем дел од времето, но сега кога го користи овој crate, тоа значи дека некој прво ќе започне со иницијализација, а другиот ќе ја земе таа иницијализација.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}