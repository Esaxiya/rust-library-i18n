# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Библиотека за стекнување повратни повратни средства за време на траење за Rust.
Оваа библиотека има за цел да ја подобри поддршката на стандардната библиотека преку обезбедување на програмски интерфејс за работа, но исто така поддржува едноставно лесно печатење на тековната заднина како што е libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Едноставно да снимите повратна трага и да одложите справување со тоа до подоцна, можете да го користите типот `Backtrace` од највисоко ниво.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ако, сепак, сакате повеќе суров пристап до вистинската функционалност за трасирање, можете директно да ги користите функциите `trace` и `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Решете го овој покажувач на инструкции во име на симбол
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // продолжете да одите на следната рамка
    });
}
```

# License

Овој проект е лиценциран под кој било од

 * Лиценца Apache, верзија 2.0, ([LICENSE-APACHE](LICENSE-APACHE) или http://www.apache.org/licenses/LICENSE-2.0)
 * Лиценца МИТ ([LICENSE-MIT](LICENSE-MIT) или http://opensource.org/licenses/MIT)

по ваша опција.

### Contribution

Освен ако не наведете поинаку поинаку, секој придонес намерно поднесен за вклучување во повратни активности од вас, како што е дефинирано во лиценцата Apache-2.0, ќе биде двојно лиценциран како погоре, без дополнителни услови и услови.







