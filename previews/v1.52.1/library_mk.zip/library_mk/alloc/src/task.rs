#![stable(feature = "wake_trait", since = "1.51.0")]
//! Видови и Traits за работа со асинхрони задачи.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Имплементација на будење задача на извршител.
///
/// Овој trait може да се користи за создавање [`Waker`].
/// Извршител може да дефинира имплементација на овој trait и да го искористи тоа за да конструира Waker за да помине на задачите што се извршуваат на тој извршител.
///
/// Овој trait е безбедна меморија и ергономска алтернатива за конструирање на [`RawWaker`].
/// Го поддржува вообичаениот дизајн на извршителот во кој се чуваат податоците користени за будење на задача во [`Arc`].
/// Некои извршители (особено оние за вградени системи) не можат да го користат овој API, затоа [`RawWaker`] постои како алтернатива за тие системи.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Основна функција `block_on` што зема future и ја извршува до крај на тековната нишка.
///
/// **Note:** Овој пример тргува со исправност за едноставност.
/// Со цел да се спречат ќор-сокаците, имплементациите во одделение за производство, исто така, ќе треба да се справат со средни повици кон `thread::unpark`, како и вгнездени повици.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Будност што ја буди тековната нишка кога ќе се повика.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Извршете future до завршување на тековната нишка.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Закапете го future за да може да се испита.
///     let mut fut = Box::pin(fut);
///
///     // Создадете нов контекст што треба да се пренесе на future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Извршете го future до крај.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Разбудете ја оваа задача.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Разбудете ја оваа задача без да го потрошите будниот.
    ///
    /// Ако извршител поддржува поевтин начин да се разбуди без да ја троши чашата, тој треба да го замени овој метод.
    /// Стандардно, тој го клонира [`Arc`] и го повикува [`wake`] на клонот.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЕЗБЕДНОСТ: Ова е безбедно бидејќи raw_waker безбедно гради
        // RawWaker од Арк<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Оваа приватна функција за конструирање на RawWaker се користи, наместо
// вметнувајќи го ова во `From<Arc<W>> for RawWaker` импл, за да се осигура дека безбедноста на `From<Arc<W>> for Waker` не зависи од правилното испраќање на trait, наместо тоа и двете имплицираат ја повикуваат оваа функција директно и експлицитно.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Зголемете го референтниот број на лакот за да го клонирате.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Разбудете се по вредност, поместувајќи го Лакот во функцијата Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Разбудете се со препорака, завиткајте го стаклото во ManualDrop за да избегнете да го испуштите
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Одлучете го референтниот број на лакот во пад
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}