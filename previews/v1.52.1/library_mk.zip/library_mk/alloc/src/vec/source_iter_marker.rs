use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Ознака за специјализација за собирање на нафтоводот повторувач во Vec при повторна употреба на распределбата на изворот, т.е.
/// извршување на гасоводот на место.
///
/// Родителот SourceIter trait е неопходен за специјализираната функција за пристап до распределбата што треба повторно да се користи.
/// Но, не е доволно специјализацијата да биде валидна.
/// Погледнете дополнителни граници на импл.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-внатрешниот SourceIter/InPlaceIterable traits се спроведува само со синџири на адаптер <Adapter<Adapter<IntoIter>>> (сите се во сопственост на core/std).
// Дополнителните граници на имплементациите на адаптерот (над `impl<I: Trait> Trait for Adapter<I>`) зависат само од другите traits веќе обележани како специјализација traits (Копирај, TrustedRandomAccess, FusedIterator).
//
// I.e. маркерот не зависи од животниот век на видовите обезбедени од корисникот.Modulo дупката за копирање, од која веќе зависат неколку други специјализации.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Дополнителни барања што не можат да се изразат преку trait bounds.Наместо тоа, се потпираме на утврдувањето:
        // а) нема ZST, бидејќи нема да има распределба за повторна употреба и аритметиката на покажувачот би panic б) совпаѓање на големината, како што барало договорот со Алок, в) усогласување, според барањата на договорот со
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // враќање на повеќе генерички имплементации
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // користете проба-пати од
        // - тоа векторизира подобро за некои адаптери за повторувачи
        // - за разлика од повеќето методи на внатрешна повторување, потребно е само &mut самостојно
        // - ни овозможува да го провлекуваме покажувачот за запишување низ внатрешноста и да го вратиме на крајот
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // повторувањето успеа, не паѓај глава
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // проверете дали договорот за SourceIter беше поддржан како предупредување: ако не беа, можеби дури и нема да стигнеме до оваа точка
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // проверете InPlaceIterable договор.Ова е можно само ако повторувачот воопшто го унапреди изворниот покажувач.
        // Ако користи неконтролиран пристап преку TrustedRandomAccess, тогаш изворниот покажувач ќе остане во својата почетна позиција и не можеме да го користиме како референца
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // испуштајте ги преостанатите вредности на опашката на изворот, но спречувајте пад на самата распределба откако IntoIter ќе излезе од опсегот, ако падот panics тогаш ги истекуваме сите елементи собрани во dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable договорот не може да се провери точно тука бидејќи try_fold има ексклузивно упатување на изворниот покажувач, сè што можеме да сториме е да провериме дали е сè уште во опсег
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}