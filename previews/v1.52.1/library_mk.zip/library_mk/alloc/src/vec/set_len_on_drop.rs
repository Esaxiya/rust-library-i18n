// Поставете ја должината на векот кога вредноста `SetLenOnDrop` излегува од опсегот.
//
// Идејата е: Полето за должина во SetLenOnDrop е локална променлива што оптимизаторот ќе ја види не е алијас со ниту една продавница преку покажувачот на податоците на Вец.
// Ова е заобиколен пат за проблемот со анализа на алијас #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}