use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Итератор кој користи затворач за да утврди дали треба да се отстрани некој елемент.
///
/// Оваа структура е создадена од [`Vec::drain_filter`].
/// Погледнете ја нејзината документација за повеќе.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Индексот на ставката што ќе биде прегледан со следниот повик до `next`.
    pub(super) idx: usize,
    /// Досега бројот на артикли што биле исцедени (removed).
    pub(super) del: usize,
    /// Оригиналната должина на `vec` пред одводот.
    pub(super) old_len: usize,
    /// Предикатот за тест на филтерот.
    pub(super) pred: F,
    /// Знаме што означува panic се појави во предикатот за тест за филтерот.
    /// Ова се користи како навестување во спроведувањето на падот за да се спречи потрошувачката на остатокот од `DrainFilter`.
    /// Било кои необработени ставки ќе бидат сменети во `vec`, но нема да се исфрлат или тестираат дополнителни ставки од предикаторот на филтерот.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Враќа упатување на основниот алокатор.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ажурирајте го индексот *откако* ќе се повика предикатот.
                // Ако индексот е ажуриран претходно и предикатот panics, елементот на овој индекс ќе протече.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ова е прилично збркана состојба и навистина не постои очигледна вистинска работа.
                        // Не сакаме да продолжуваме да се обидуваме да извршуваме `pred`, па затоа ги префрламе сите необработени елементи и му кажуваме на верзијата дека тие сè уште постојат.
                        //
                        // Потребно е повратно менување за да се спречи двојно паѓање на последната успешно исцедена ставка пред panic во предикатот.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Обид да се консумираат останатите елементи ако предикаторот на филтерот сè уште не е во паника.
        // Ние ќе ги вратиме сите преостанати елементи, без разлика дали сме веќе испаничени или ако потрошувачката тука е panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}