use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Специјализација trait што се користи за Vec::from_iter
///
/// ## Графикон на делегација:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Чест случај е пренесување vector во функција која веднаш повторно се собира во vector.
        // Ова можеме да го направиме краток спој ако IntoIter воопшто не е напреднат.
        // Кога е напредно, можеме исто така да ја користиме повторно меморијата и да ги преместиме податоците напред.
        // Но, ние тоа го правиме само кога резултирачкиот Век нема да има повеќе неискористен капацитет отколку што би го создал преку генеричката имплементација од FromIterator.
        //
        // Тоа ограничување не е строго потребно бидејќи однесувањето на распределбата на Вец е намерно неопределено.
        // Но, тоа е конзервативен избор.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // мора да делегира на spec_extend(), бидејќи самиот extend() делегира во специфицирање од празни Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ова го користи `iterator.as_slice().to_vec()` бидејќи spec_extend мора да преземе повеќе чекори за да размисли за крајниот капацитет + должина и со тоа да направи повеќе работа.
// `to_vec()` директно ја распределува точната сума и ја пополнува точно.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): со cfg(test), својствениот метод `[T]::to_vec`, потребен за оваа дефиниција на методот, не е достапен.
    // Наместо тоа, користете ја функцијата `slice::to_vec` што е достапна само со cfg(test) NB, видете го модулот slice::hack во slice.rs за повеќе информации
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}