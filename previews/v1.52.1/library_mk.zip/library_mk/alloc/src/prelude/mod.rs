//! Алокацијата Prelude
//!
//! Целта на овој модул е да се олесни увозот на најчесто користени ставки на `alloc` crate со додавање на глобутен увоз на горниот дел од модулите:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;