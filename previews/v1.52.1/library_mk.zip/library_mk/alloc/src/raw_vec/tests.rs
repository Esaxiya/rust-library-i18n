use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Пишувањето тест за интеграција помеѓу алокаторите на трети страни и `RawVec` е малку незгодно бидејќи `RawVec` API не изложува на грешни методи на распределба, затоа не можеме да провериме што ќе се случи кога ќе се исцрпи алокаторот (освен откривање на panic).
    //
    //
    // Наместо тоа, ова само проверува дали методите `RawVec` барем поминуваат низ API на Allocator кога резервира складирање.
    //
    //
    //
    //
    //

    // Нем алокатор што троши фиксна количина гориво пред да започнат да пропаѓаат обидите за распределба.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (предизвикува реалокација, со што се користат 50 + 150=200 единици гориво)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Прво, `reserve` доделува како `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 е повеќе од двојно од 7, така што `reserve` треба да работи како `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 е помалку од половина од 12, така што `reserve` мора да расте експоненцијално.
        // За време на пишувањето на овој тест, факторот за раст е 2, така што новиот капацитет е 24, сепак, факторот за раст на 1.5 е исто така во ред.
        //
        // Оттука, `>= 18` во тврдење.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}