// Ова е обид за имплементација по идеалот
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Бидејќи Rust всушност нема зависни типови и полиморфна рекурзија, се снаоѓаме со многу несигурност.
//

// Главна цел на овој модул е да се избегне комплексноста со третирање на дрвото како генерички (ако е чудно обликуван) контејнер и избегнување справување со повеќето од непроменливите B-Tree.
//
// Како таков, овој модул не се грижи дали записите се подредени, кои јазли можат да бидат недоволно, па дури и што значи недоволно.Сепак, се потпираме на неколку инваријанти:
//
// - Дрвјата мора да имаат униформа depth/height.Ова значи дека секоја патека до лист од даден јазол има точно иста должина.
// - Јазол со должина `n` има клучеви `n`, вредности `n` и рабови `n + 1`.
//   Ова подразбира дека дури и празен јазол има барем еден edge.
//   За јазол на лист, "having an edge" значи само дека можеме да идентификуваме позиција во јазолот, бидејќи рабовите на листот се празни и немаат потреба од приказ на податоци.
// Во внатрешен јазол, edge идентификува позиција и содржи покажувач кон детски јазол.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Основната репрезентација на листовите јазли и дел од репрезентацијата на внатрешните јазли.
struct LeafNode<K, V> {
    /// Ние сакаме да бидеме коваријант во `K` и `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Индексот на овој јазол е во низата `edges` на матичниот јазол.
    /// `*node.parent.edges[node.parent_idx]` треба да биде иста работа како `node`.
    /// Загарантирано е дека ова ќе биде иницијализирано само кога `parent` не е ништовен.
    parent_idx: MaybeUninit<u16>,

    /// Бројот на клучеви и вредности што ги чува овој јазол.
    len: u16,

    /// Низите ги зачувуваат вистинските податоци на јазолот.
    /// Само првите елементи на `len` од секоја низа се иницијализирани и валидни.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Иницијализира нов `LeafNode` на место.
    unsafe fn init(this: *mut Self) {
        // Како општа политика, ги оставаме полињата неиницијализирани ако можат, бидејќи ова треба да биде и малку побрзо и полесно да се следи во Валгринд.
        //
        unsafe {
            // родител_идкс, клучеви и валси се можеби УНИНИТ
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Создава нов бокс `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Основната репрезентација на внатрешните јазли.Како и кај `LeafNode`, овие треба да бидат скриени зад`BoxedNode` за да се спречи паѓање на неинцијализирани клучеви и вредности.
/// Било кој покажувач кон `InternalNode` може директно да се исфрли на покажувачот на основниот `LeafNode` дел од јазолот, дозволувајќи му на кодот генерички да делува на листот и на внатрешните јазли, без дури да провери на кој од двата покажувачот покажува.
///
/// Овој имот е овозможен со употреба на `repr(C)`.
///
#[repr(C)]
// gdb_providers.py го користи овој тип на име за интроспекција.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Укажувачите кон децата на овој јазол.
    /// `len + 1` од нив се сметаат за иницијализирани и валидни, освен што близу до крајот, додека дрвото се држи преку позајмиот тип `Dying`, некои од овие покажувачи висат.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Создава нов бокс `InternalNode`.
    ///
    /// # Safety
    /// Непроменлива на внатрешните јазли е дека тие имаат барем еден иницијализиран и валиден edge.
    /// Оваа функција не поставува таков edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Треба само да ги иницијализираме податоците;рабовите се Можеби Унинит.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Управуван, не-нулта покажувач на јазол.Ова е или сопственик на покажувачот за `LeafNode<K, V>` или сопствен покажувач за `InternalNode<K, V>`.
///
/// Сепак, `BoxedNode` не содржи никакви информации за тоа кој од двата вида јазли всушност ги содржи, и, делумно поради овој недостаток на информации, не е посебен вид и нема деструктор.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Коренскиот јазол на сопствено дрво.
///
/// Забележете дека ова нема деструктор и мора да се расчисти рачно.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Враќа ново дрво во сопственост, со свој корен јазол што првично е празен.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` не смее да биде нула.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Незаменливо го позајмува сопствениот корен јазол.
    /// За разлика од `reborrow_mut`, ова е безбедно бидејќи повратната вредност не може да се користи за уништување на коренот и не може да има други упатувања на дрвото.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Малку немирливо го позајмува сопствениот корен јазол.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Неповратно преминуваме во референца која дозволува пресекување и нуди деструктивни методи и малку повеќе.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Додава нов внатрешен јазол со еден edge насочен кон претходниот корен јазол, направете го тој нов јазол корен јазол и вратете го.
    /// Ова ја зголемува висината за 1 и е спротивно на `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, освен што само што заборавивме дека сме внатрешни сега:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Го отстранува внатрешниот корен јазол, користејќи го своето прво дете како нов корен јазол.
    /// Бидејќи е наменет само да се повика кога коренскиот јазол има само едно дете, не се прави чистење на ниту еден клуч, вредности и други деца.
    ///
    /// Ова ја намалува висината за 1 и е спротивно на `push_internal_level`.
    ///
    /// Бара ексклузивен пристап до објектот `Root`, но не и до коренскиот јазол;
    /// тоа нема да ги поништи другите рачки или упатувања на коренскиот јазол.
    ///
    /// Panics ако нема внатрешно ниво, т.е. ако коренскиот јазол е лист.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // БЕЗБЕДНОСТ: тврдевме дека сме внатрешни.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // БЕЗБЕДНОСТ: позајмивме `self` исклучиво и неговиот тип на позајмица е ексклузивен.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // БЕЗБЕДНОСТ: првиот edge е секогаш иницијализиран.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` е секогаш коваријанта во `K` и `V`, дури и кога `BorrowType` е `Mut`.
// Ова е технички погрешно, но не може да резултира во каква било несигурност поради внатрешна употреба на `NodeRef` затоа што остануваме целосно генерички над `K` и `V`.
//
// Како и да е, секогаш кога јавен тип ќе обвива `NodeRef`, проверете дали има точна варијанса.
//
/// Упатување на јазол.
///
/// Овој тип има голем број параметри кои контролираат како дејствува:
/// - `BorrowType`: Лажен тип кој опишува вид на позајмица и носи цел живот.
///    - Кога ова е `Immut<'a>`, `NodeRef` дејствува приближно како `&'a Node`.
///    - Кога ова е `ValMut<'a>`, `NodeRef` дејствува приближно како `&'a Node` во однос на клучевите и структурата на дрвото, но исто така дозволува да коегзистираат многу непроменливи референци на вредностите низ дрвото.
///    - Кога ова е `Mut<'a>`, `NodeRef` дејствува приближно како `&'a mut Node`, иако методите за вметнување овозможуваат да може да коегзистира променлив покажувач на вредност.
///    - Кога ова е `Owned`, `NodeRef` дејствува приближно како `Box<Node>`, но нема деструктор и мора да се расчисти рачно.
///    - Кога ова е `Dying`, `NodeRef` сè уште делува приближно како `Box<Node>`, но има методи за уништување на дрвото малку по малку, а обичните методи, иако не се означени како небезбедни за повикување, можат да се повикаат на UB ако се повика погрешно.
///
///   Бидејќи кој било `NodeRef` дозволува навигација низ дрвото, `BorrowType` ефективно се однесува на целото дрво, не само на самиот јазол.
/// - `K` и `V`: Ова се типови на клучеви и вредности зачувани во јазлите.
/// - `Type`: Ова може да биде `Leaf`, `Internal` или `LeafOrInternal`.
/// Кога ова е `Leaf`, `NodeRef` покажува листен јазол, кога ова е `Internal`, `NodeRef` покажува внатрешен јазол, и кога ова е `LeafOrInternal`, `NodeRef` може да покажува на кој било вид на јазол.
///   `Type` е именуван како `NodeType` кога се користи надвор од `NodeRef`.
///
/// И `BorrowType` и `NodeType` ограничуваат кои методи ги спроведуваме за да се искористи безбедноста на статички тип.Постојат ограничувања на начинот на кој можеме да ги примениме ваквите ограничувања:
/// - За секој параметар тип, можеме да дефинираме метод или генерички или за еден одреден тип.
/// На пример, не можеме да дефинираме метод како `into_kv` генерички за сите `BorrowType`, или еднаш за сите типови што носат цел живот, затоа што сакаме да ги враќа референците `&'a`.
///   Затоа, ние го дефинираме само за најмалку моќниот тип `Immut<'a>`.
/// - Не можеме да добиеме имплицитна принуда од речениците `Mut<'a>` до `Immut<'a>`.
///   Затоа, ние треба експлицитно да повикаме `reborrow` на помоќен `NodeRef` за да постигнеме метод како `into_kv`.
///
/// Сите методи на `NodeRef` кои враќаат некаква референца, или:
/// - Земете `self` по вредност и вратете го целиот животен век носен од `BorrowType`.
///   Понекогаш, за да се повикаме на ваков метод, треба да повикаме `reborrow_mut`.
/// - Земете `self` по препорака, и (implicitly) вратете го целиот животен век на референцата, наместо животот што го носи `BorrowType`.
/// На тој начин, проверувачот на позајмици гарантира дека `NodeRef` останува позајмен сè додека се користи вратената референца.
///   Методите за поддршка на вметнување го прилагодуваат ова правило со враќање на суров покажувач, односно референца без никаков животен век.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Бројот на нивоа што јазолот и нивото на лисјата се одвоени, константа на јазолот што не може целосно да се опише со `Type`, а самиот јазол не ги зачувува.
    /// Треба да ја зачуваме само висината на коренскиот јазол и да ја извлечеме висината на секој друг јазол од него.
    /// Мора да биде нула ако `Type` е `Leaf` и не-нула ако `Type` е `Internal`.
    ///
    ///
    height: usize,
    /// Покажувачот кон листот или внатрешниот јазол.
    /// Дефиницијата за `InternalNode` гарантира дека покажувачот е валиден во секој случај.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Отпакувајте референца за јазол, спакувана како `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Изложува податоци за внатрешен јазол.
    ///
    /// Враќа суров PTR за да избегне неважење на други препораки на овој јазол.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // БЕЗБЕДНОСТ: статичкиот тип на јазол е `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Бороус ексклузивен пристап до податоците на внатрешен јазол.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ја наоѓа должината на јазолот.Ова е бројот на клучеви или вредности.
    /// Бројот на рабовите е `len() + 1`.
    /// Имајте на ум дека, и покрај тоа што е безбедно, повикувањето на оваа функција може да има несакан ефект на невалидно променливо референци што ги создаде небезбеден код.
    ///
    pub fn len(&self) -> usize {
        // Клучно, ние пристапуваме само до полето `len` тука.
        // Ако BorrowType е marker::ValMut, може да има извонредни непроменливи препораки на вредности што не смееме да ги поништиме.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Го враќа бројот на нивоа што јазолот и лисјата се разделени.
    /// Нулта висина значи дека јазолот е лист самиот.
    /// Ако сликате дрвја со коренот одозгора, бројот кажува на која висина се појавува јазолот.
    /// Ако сликате дрвја со лисја на врвот, бројот кажува колку е високо дрвото се протега над јазолот.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Привремено вади друго, непроменливо повикување на истиот јазол.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Изложува дел од листот на кој било лист или внатрешен јазол.
    ///
    /// Враќа суров PTR за да избегне неважење на други препораки на овој јазол.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Јазолот мора да биде валиден барем за делот LeafNode.
        // Ова не е референца во типот NodeRef затоа што не знаеме дали треба да биде единствено или споделено.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Го наоѓа родителот на тековниот јазол.
    /// Враќа `Ok(handle)` ако тековниот јазол навистина има родител, каде `handle` покажува на edge на родителот што покажува на тековниот јазол.
    ///
    /// Враќа `Err(self)` ако тековниот јазол нема родител, враќајќи го оригиналниот `NodeRef`.
    ///
    /// Името на методот претпоставува да сликате дрвја со коренскиот јазол на врвот.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` и двајцата, по успехот, не треба да прават ништо.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Треба да користиме сурови покажувачи на јазли затоа што, ако BorrowType е marker::ValMut, може да има извонредни неспојливи препораки за вредностите што не смееме да ги поништиме.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Имајте на ум дека `self` мора да биде испразнет.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Имајте на ум дека `self` мора да биде испразнет.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Го изложува лисниот дел од кој било лист или внатрешен јазол во непроменливо дрво.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // БЕЗБЕДНОСТ: не може да има неспојливи препораки за ова дрво позајмено како `Immut`.
        unsafe { &*ptr }
    }

    /// Враќа преглед во копчињата зачувани во јазолот.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Слично на `ascend`, добива упатување на матичен јазол на јазол, но исто така го деалоцира тековниот јазол во процесот.
    /// Ова е небезбедно бидејќи тековниот јазол сепак ќе биде достапен и покрај тоа што е распределен.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Несигурно му ја тврди на компајлерот статичката информација дека овој јазол е `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Несигурно му ја тврди на компајлерот статичката информација дека овој јазол е `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Привремено извади друга, непроменлива референца на истиот јазол.Пазете се, бидејќи овој метод е многу опасен, двојно затоа што може веднаш да не изгледа опасен.
    ///
    /// Бидејќи непроменливите покажувачи можат да талкаат насекаде околу дрвото, вратениот покажувач може лесно да се искористи за да се направи оригиналниот покажувач обесен, надвор од границите или неважечки според правилата за наредени заеми.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) размислете за додавање на друг вид параметар на `NodeRef` што ја ограничува употребата на методите за навигација на реброудираните покажувачи, спречувајќи ја оваа небезбедност.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ексклузивен пристап до листовите на кој било лист или внатрешен јазол.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // БЕЗБЕДНОСТ: имаме ексклузивен пристап до целиот јазол.
        unsafe { &mut *ptr }
    }

    /// Нуди ексклузивен пристап до лист дел од кој било лист или внатрешен јазол.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // БЕЗБЕДНОСТ: имаме ексклузивен пристап до целиот јазол.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ексклузивен пристап до Лос Анџелес до елемент од областа за складирање клучеви
    ///
    /// # Safety
    /// `index` е во граници од 0..КАПАЦИТЕТ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // БЕЗБЕДНОСТ: повикувачот нема да може да повикува понатамошни методи на самостојно
        // додека не се испушти референцата за клучното парче, бидејќи имаме единствен пристап за целиот животен век на позајмицата.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Ексклузивен пристап до елементот или парче од областа за складирање на вредноста на јазолот.
    ///
    /// # Safety
    /// `index` е во граници од 0..КАПАЦИТЕТ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // БЕЗБЕДНОСТ: повикувачот нема да може да повикува понатамошни методи на самостојно
        // додека не се испушти референцата за парче вредност, бидејќи имаме единствен пристап за целиот животен век на позајмицата.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ексклузивен пристап до елементот или парче од просторот за складирање на јазолот за содржините edge.
    ///
    /// # Safety
    /// `index` е во граници од 0..КАПАЦИТЕТ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // БЕЗБЕДНОСТ: повикувачот нема да може да повикува понатамошни методи на самостојно
        // сè додека не се испушти референцата за парчиња edge, бидејќи имаме единствен пристап за целиот животен век на позајмицата.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Јазолот има повеќе од `idx` иницијализирани елементи.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ние создаваме упатување само на еден елемент за кој сме заинтересирани, за да избегнеме алиација со извонредни упатувања на други елементи, особено на оние што се враќаат кај повикувачот во претходните повторувања.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Ние мора да присилиме на индикаторите за низа големини поради Rust изданието #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Бороус ексклузивен пристап до должината на јазолот.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ја поставува врската на јазолот до нејзиниот родител edge, без да ги поништи другите препораки на јазолот.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ја брише врската на коренот до нејзиниот родител edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Додава пар со клучна вредност на крајот на јазолот.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Секоја ставка вратена од `range` е валиден индекс edge за јазолот.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Додава пар со клучна вредност и edge за да оди надесно од тој пар, до крајот на јазолот.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Проверува дали јазол е јазол `Internal` или јазол `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Упатување на одреден пар на клучна вредност или edge во рамките на еден јазол.
/// Параметарот `Node` мора да биде `NodeRef`, додека `Type` може да биде `KV` (што означува рачка на пар со клучна вредност) или `Edge` (означува рачка на edge).
///
/// Забележете дека дури и `Leaf` јазли можат да имаат рачки `Edge`.
/// Наместо да покажуваат покажувач на детски јазол, овие претставуваат простори каде што покажувачите за деца би се движеле помеѓу паровите на клучните вредности.
/// На пример, во јазол со должина 2, би имало 3 можни локации на edge, една лево од јазолот, една помеѓу двата парови и една десно од јазолот.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Не ни треба целосна општост на `#[derive(Clone)]`, бидејќи единствениот пат кога `Node` ќе може да се " Клонира` е кога тоа е непроменлива референца и затоа `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Го презема јазолот што го содржи edge или парот со клучна вредност на кој покажува оваа рачка.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Ја враќа позицијата на оваа рачка во јазолот.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Создава нова рачка за пар клуч-вредност во `node`.
    /// Небезбеден затоа што повикувачот мора да осигура дека `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Може да биде јавна имплементација на PartialEq, но се користи само во овој модул.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Привремено вади друга, непроменлива рачка на истата локација.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Не можеме да користиме Handle::new_kv или Handle::new_edge затоа што не го знаеме нашиот тип
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Несигурно му ја потврдува на компајлерот статичката информација дека јазолот на рачката е `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Привремено извади друга, непроменлива рачка на истата локација.
    /// Пазете се, бидејќи овој метод е многу опасен, двојно затоа што може веднаш да не изгледа опасен.
    ///
    ///
    /// За детали, видете `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Не можеме да користиме Handle::new_kv или Handle::new_edge затоа што не го знаеме нашиот тип
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Создава нова рачка на edge во `node`.
    /// Небезбеден затоа што повикувачот мора да осигура дека `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Со оглед на индексот edge каде што сакаме да вметнеме во јазол исполнет до капацитет, пресметува разумен индекс KV на сплит точка и каде да се изврши вметнувањето.
///
/// Целта на сплит точката е нејзиниот клуч и вредност да завршат во матичен јазол;
/// копчињата, вредностите и рабовите лево од точката на поделба стануваат лево дете;
/// копчињата, вредностите и рабовите десно од сплит точката стануваат вистинското дете.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust изданието #74834 се обидува да ги објасни овие симетрични правила.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вметнува нов пар на клучни вредности помеѓу паровите на клучните вредности надесно и лево од овој edge.
    /// Овој метод претпоставува дека има доволно простор во јазолот за да се вклопи новиот пар.
    ///
    /// Враќаниот покажувач покажува на вметнатата вредност.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вметнува нов пар на клучни вредности помеѓу паровите на клучните вредности надесно и лево од овој edge.
    /// Овој метод го дели јазолот ако нема доволно простор.
    ///
    /// Враќаниот покажувач покажува на вметнатата вредност.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ги поправа родителскиот покажувач и индексот во детскиот јазол до кој се поврзува овој edge.
    /// Ова е корисно кога редоследот на рабовите е променет,
    fn correct_parent_link(self) {
        // Создадете backpointer без да ги поништите другите препораки на јазолот.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Вметнува нов пар на клучни вредности и edge што ќе одат десно од тој нов пар помеѓу овој edge и парот со клучна вредност десно од овој edge.
    /// Овој метод претпоставува дека има доволно простор во јазолот за да се вклопи новиот пар.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Вметнува нов пар на клучни вредности и edge што ќе одат десно од тој нов пар помеѓу овој edge и парот со клучна вредност десно од овој edge.
    /// Овој метод го дели јазолот ако нема доволно простор.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вметнува нов пар на клучни вредности помеѓу паровите на клучните вредности надесно и лево од овој edge.
    /// Овој метод го дели јазолот ако нема доволно простор и се обидува да го вметне разделениот дел во матичниот јазол рекурзивно, сè додека не се достигне коренот.
    ///
    ///
    /// Ако вратениот резултат е `Fit`, јазолот на неговата рачка може да биде јазол на овој edge или предок.
    /// Ако вратениот резултат е `Split`, полето `left` ќе биде коренскиот јазол.
    /// Враќаниот покажувач покажува на вметнатата вредност.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Го наоѓа јазолот посочен од овој edge.
    ///
    /// Името на методот претпоставува да сликате дрвја со коренскиот јазол на врвот.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` и двајцата, по успехот, не треба да прават ништо.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Треба да користиме сурови покажувачи на јазли затоа што, ако BorrowType е marker::ValMut, може да има извонредни неспојливи препораки за вредностите што не смееме да ги поништиме.
        // Нема загриженост да пристапите до полето за висина затоа што таа вредност е копирана.
        // Пазете се дека, кога покажувачот на јазол ќе биде деференциран, пристапуваме до низата рабови со референца (Rust проблем #73987) и ги поништуваме сите други препораки на или во низата, доколку има.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Не можеме да повикаме одделни методи на клучеви и вредности, затоа што повикувањето на вториот не ја поништува референцата вратена од првата.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Заменете ги клучот и вредноста на кои се однесува рачката KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Помага при имплементација на `split` за одреден `NodeType`, со грижа за листните податоци.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Го дели основниот јазол на три дела:
    ///
    /// - Јазолот е скратен за да ги содржи само паровите на клучните вредности лево од оваа рачка.
    /// - Клучот и вредноста на кои укажува оваа рачка се извлекуваат.
    /// - Сите парови на клучните вредности десно од оваа рачка се ставаат во ново распределен јазол.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Го отстранува парот со клучни вредности посочен од оваа рачка и го враќа заедно со edge во кој се распадна парот со клучни вредности.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Го дели основниот јазол на три дела:
    ///
    /// - Јазолот е скратен за да ги содржи само рабовите и паровите на клучните вредности лево од оваа рачка.
    /// - Клучот и вредноста на кои укажува оваа рачка се извлекуваат.
    /// - Сите рабови и парови на клучните вредности десно од оваа рачка се ставаат во ново доделен јазол.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Претставува сесија за проценка и извршување на операција за балансирање околу внатрешен пар клуч-вредност.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Избира рамнотежен контекст со вклучување на јазолот како дете, со тоа помеѓу KV веднаш налево или надесно во родителскиот јазол.
    /// Враќа `Err` ако нема родител.
    /// Panics ако родителот е празен.
    ///
    /// Претпочита левата страна, да биде оптимален ако дадениот јазол е некако потполн, што значи тука само дека има помалку елементи од левиот брат и од десниот брат или сестра, доколку тие постојат.
    /// Во тој случај, спојувањето со левиот брат е побрзо, бидејќи треба само да ги поместиме N-те елементи на јазолот, наместо да ги поместуваме надесно и да се движиме повеќе од N-елементи пред себе.
    /// Крадењето од левиот брат е исто така обично побрзо, бидејќи треба само да ги поместиме N-те елементи на јазолот надесно, наместо да префрлиме барем N од елементите на братот или левата страна.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Враќа дали е можно спојување, т.е. дали има доволно простор во јазол за комбинирање на централното KV со двата соседни детски јазли.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Извршува спојување и дозволува затворање да одлучи што ќе врати.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // БЕЗБЕДНОСТ: висината на јазлите што се спојуваат е една под висината
                // на јазолот на овој edge, со тоа над нулата, така што тие се внатрешни.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Го спојува парот на клучна вредност на родителот и двата соседни детски јазли во левиот јазол за деца и го враќа намалениот родителски јазол.
    ///
    ///
    /// Panics освен ако ние `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Го спојува парот на клучна вредност на родителот и двата соседни детски јазли во левиот јазол за деца и го враќа тој детски јазол.
    ///
    ///
    /// Panics освен ако ние `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Го спојува парот на клучни вредности на родителот и двата соседни детски јазли во левиот јазол и ја враќа рачката edge во тој детски јазол каде што завршило следеното дете edge,
    ///
    ///
    /// Panics освен ако ние `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Отстранува пар на клучна вредност од левото дете и го става во меморијата за клучна вредност на родителот, истовремено туркајќи го стариот парен клуч-вредност на родителот во десното дете.
    ///
    /// Враќа рачка на edge кај вистинското дете што одговара на тоа каде заврши оригиналниот edge наведен од `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Отстранува пар на клучна вредност од десното дете и го става во меморијата за клучна вредност на родителот, притоа туркајќи го стариот парен клуч-вредност врз левото дете.
    ///
    /// Враќа рачка на edge кај левото дете наведено од `track_left_edge_idx`, кое не се помрдна.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ова прави кражба слично на `steal_left`, но краде повеќе елементи одеднаш.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Бидете сигурни дека можеме да украдеме безбедно.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Преместете ги податоците за лисјата.
            {
                // Направете место за украдени елементи кај вистинското дете.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Поместете ги елементите од левото дете на десно.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Преместете го лево-најкрадениот пар кај родителот.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Преместете го парот на клучни вредности на родителот на вистинското дете.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Отворете место за украдени рабови.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Украдете рабови.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Симетричен клон на `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Бидете сигурни дека можеме да украдеме безбедно.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Преместете ги податоците за лисјата.
            {
                // Преместете го десно-украдениот пар кај родителот.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Преместете го парот на клучни вредности на родителот на лево дете.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Поместете ги елементите од десното дете налево.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Пополнете ја празнината каде што биле украдените елементи.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Украдете рабови.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Пополнете ја јазот таму каде што биле украдените рабови.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ги отстранува сите статички информации кои тврдат дека овој јазол е јазол `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Отстранува какви било статични информации кои тврдат дека овој јазол е јазол `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Проверува дали основниот јазол е јазол `Internal` или јазол `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Поместете ја наставката по `self` од еден јазол во друг.`right` мора да биде празен.
    /// Првиот edge на `right` останува непроменет.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Резултат од вметнување, кога еден јазол требаше да се прошири над неговиот капацитет.
pub struct SplitResult<'a, K, V, NodeType> {
    // Изменет јазол во постојното дрво со елементи и рабови што припаѓаат лево од `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Некој клуч и вредност се поделени, за да бидат вметнати на друго место.
    pub kv: (K, V),
    // Сопствен, неповрзан, нов јазол со елементи и рабови што припаѓаат десно од `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Дали референците на јазли од овој тип на позајмица овозможуваат поминување на други јазли во дрвото.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Премин не е потребен, тоа се случува со користење на резултатот од `borrow_mut`.
        // Со оневозможување на пресек, и само создавање нови препораки за корените, знаеме дека секоја референца од типот `Owned` е на коренскиот јазол.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Вметнува вредност во парче иницијализирани елементи проследено со еден уницијализиран елемент.
///
/// # Safety
/// Парчето има повеќе од `idx` елементи.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Отстранува и враќа вредност од парче од сите иницијализирани елементи, оставајќи го зад себе еден неинцијализиран елемент.
///
///
/// # Safety
/// Парчето има повеќе од `idx` елементи.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Ги поместува елементите во положба на парче `distance` налево.
///
/// # Safety
/// Парчето има најмалку `distance` елементи.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ги поместува елементите во положба на парче `distance` надесно.
///
/// # Safety
/// Парчето има најмалку `distance` елементи.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ги преместува сите вредности од парче иницијализирани елементи во парче неуницијализирани елементи, оставајќи го зад себе `src` како сите неницијализирани.
///
/// Работи како `dst.copy_from_slice(src)`, но не бара `T` да биде `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;