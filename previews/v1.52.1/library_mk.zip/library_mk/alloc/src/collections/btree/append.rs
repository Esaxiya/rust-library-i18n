use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Ги додава сите парови на клучни вредности од соединувањето на два искачувачки повторувачи, зголемувајќи ја променливата `length` на патот.Последното му олеснува на повикувачот да избегне истекување кога управувачот со капки ќе паничи.
    ///
    /// Ако и двата повторувачи произведуваат ист клуч, овој метод го испушта парот од левиот повторувач и го додава парот од десниот повторувач.
    ///
    /// Ако сакате дрвото да заврши во строго растечки редослед, како за `BTreeMap`, двајцата повторувачи треба да произведуваат клучеви во строго растечки редослед, секој поголем од сите клучеви во дрвото, вклучувајќи ги и сите копчиња што веќе се наоѓаат на дрвото при влегувањето.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ние се подготвуваме да ги споиме `left` и `right` во подредена низа во линеарно време.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Во меѓувреме, ние градиме дрво од подредената низа во линеарно време.
        self.bulk_push(iter, length)
    }

    /// Ги турка сите парови со клучни вредности до крајот на дрвото, зголемувајќи ја променливата `length` по патот.
    /// Вториот го олеснува повикувачот да избегне протекување кога повторувачот ќе паничи.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Повторувајте низ сите парови со клучни вредности, туркајќи ги во јазли на вистинското ниво.
        for (key, value) in iter {
            // Обидете се да турнете пар на клучна вредност во тековниот јазол на листот.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Нема место, одете горе и турнете таму.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Пронајден јазол со преостанат простор, притиснете тука.
                                open_node = parent;
                                break;
                            } else {
                                // Одете пак горе.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ние сме на врвот, создаваме нов коренски јазол и туркаме таму.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Притиснете пар со клучна вредност и ново десно под-дрво.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Спуштете се повторно на десниот лист повторно.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Зголемете ја должината на секоја повторување, за да бидете сигурни дека картата ќе ги испушти приложените елементи, дури и ако напредува повторувачот.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Итератор за спојување на две подредени низи во една
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ако две копчиња се еднакви, се враќа парот со вредност на клучот од вистинскиот извор.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}