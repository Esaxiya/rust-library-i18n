//! АПИ за алокација на меморија

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ова се волшебните симболи за повикување на глобалниот алокатор.rustc ги генерира да повикуваат `__rg_alloc` итн.
    // ако има атрибут `#[global_allocator]` (шифрата што ја проширува таа атрибут макро ги генерира тие функции), или да ги повикате стандардните имплементации во libstd (`__rdl_alloc` итн.)
    //
    // во `library/std/src/alloc.rs`) инаку.
    // rustc fork на LLVM исто така ги специјализира овие имиња на функции за да може да ги оптимизира како `malloc`, `realloc` и `free`, соодветно.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Глобален алокатор на меморија.
///
/// Овој тип го спроведува [`Allocator`] trait со проследување повици до распределувачот регистриран со атрибутот `#[global_allocator]` доколку постои, или `std` crate е стандардно.
///
///
/// Note: додека овој тип е нестабилен, на функционалноста што ја обезбедува може да се пристапи преку [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Доделете ја меморијата со глобалниот алокатор.
///
/// Оваа функција ги препраќа повиците кон методот [`GlobalAlloc::alloc`] на распределувачот регистриран со атрибутот `#[global_allocator]` доколку постои, или `std` crate е стандардно.
///
///
/// Оваа функција се очекува да биде амортизирана во корист на методот `alloc` од типот [`Global`] кога таа и [`Allocator`] trait стануваат стабилни.
///
/// # Safety
///
/// Погледнете [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Делоцирајте ја меморијата со глобалниот алокатор.
///
/// Оваа функција ги препраќа повиците кон методот [`GlobalAlloc::dealloc`] на распределувачот регистриран со атрибутот `#[global_allocator]` доколку постои, или `std` crate е стандардно.
///
///
/// Оваа функција се очекува да биде амортизирана во корист на методот `dealloc` од типот [`Global`] кога таа и [`Allocator`] trait стануваат стабилни.
///
/// # Safety
///
/// Погледнете [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Пренаменете ја меморијата со глобалниот алокатор.
///
/// Оваа функција ги препраќа повиците кон методот [`GlobalAlloc::realloc`] на распределувачот регистриран со атрибутот `#[global_allocator]` доколку постои, или `std` crate е стандардно.
///
///
/// Оваа функција се очекува да биде амортизирана во корист на методот `realloc` од типот [`Global`] кога таа и [`Allocator`] trait стануваат стабилни.
///
/// # Safety
///
/// Погледнете [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Доделете нула иницијализирана меморија со глобалниот алокатор.
///
/// Оваа функција ги препраќа повиците кон методот [`GlobalAlloc::alloc_zeroed`] на распределувачот регистриран со атрибутот `#[global_allocator]` доколку постои, или `std` crate е стандардно.
///
///
/// Оваа функција се очекува да биде амортизирана во корист на методот `alloc_zeroed` од типот [`Global`] кога таа и [`Allocator`] trait стануваат стабилни.
///
/// # Safety
///
/// Погледнете [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // БЕЗБЕДНОСТ: `layout` не е нула по големина,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // БЕЗБЕДНОСТ: Исто како `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // БЕЗБЕДНОСТ: `new_size` не е нула бидејќи `old_size` е поголем или еднаков на `new_size`
            // како што налагаат безбедносните услови.Останатите услови мора да ги прифати повикувачот
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` веројатно проверува дали е `new_size >= old_layout.size()` или нешто слично.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЕЗБЕДНОСТ: бидејќи `new_layout.size()` мора да биде поголема или еднаква на `old_size`,
            // и старата и новата распределба на меморијата се валидни за читање и запишување за `old_size` бајти.
            // Исто така, бидејќи старата распределба сè уште не беше распределена, таа не може да се преклопува `new_ptr`.
            // Така, повикот кон `copy_nonoverlapping` е безбеден.
            // Безбедносниот договор за `dealloc` мора да го потврди повикувачот.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // БЕЗБЕДНОСТ: `layout` не е нула по големина,
            // други услови мора да бидат поддржани од повикувачот
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕЗБЕДНОСТ: сите услови мора да бидат поддржани од повикувачот
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕЗБЕДНОСТ: сите услови мора да бидат поддржани од повикувачот
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // БЕЗБЕДНОСТ: условите мора да бидат поддржани од повикувачот
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // БЕЗБЕДНОСТ: `new_size` не е нула.Останатите услови мора да ги прифати повикувачот
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` веројатно проверува дали е `new_size <= old_layout.size()` или нешто слично.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЕЗБЕДНОСТ: бидејќи `new_size` мора да биде помал или еднаков на `old_layout.size()`,
            // и старата и новата распределба на меморијата се валидни за читање и запишување за `new_size` бајти.
            // Исто така, бидејќи старата распределба сè уште не беше распределена, таа не може да се преклопува `new_ptr`.
            // Така, повикот кон `copy_nonoverlapping` е безбеден.
            // Безбедносниот договор за `dealloc` мора да го потврди повикувачот.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Алокатор за единствени покажувачи.
// Оваа функција не смее да се одмотува.Ако го стори тоа, кодот MIR нема да успее.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Овој потпис мора да биде ист како `Box`, во спротивно ќе се случи ICE.
// Кога ќе се додаде дополнителен параметар на `Box` (како `A: Allocator`), ова треба да се додаде и тука.
// На пример, ако `Box` се смени во `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, оваа функција треба да се смени и во `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Ракувач со грешки во распределбата

extern "Rust" {
    // Ова е волшебниот симбол за повикување на управувачот со грешки во глобалното доделување.
    // rustc го генерира за да повика `__rg_oom` ако има `#[alloc_error_handler]` или да ги повика стандардните имплементации под (`__rdl_oom`) на друг начин.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Прекинете при грешка или неуспех во доделувањето на меморијата.
///
/// Повикувачите на API за алокација на меморија кои сакаат да ја прекинат пресметката како одговор на грешка во распределбата, се охрабруваат да ја повикаат оваа функција, наместо директно да се повикуваат на `panic!` или слично.
///
///
/// Стандардно однесување на оваа функција е да отпечатите порака до стандардна грешка и да го прекинете процесот.
/// Може да се замени со [`set_alloc_error_hook`] и [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// За распределување тест `std::alloc::handle_alloc_error` може да се користи директно.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // повикана преку генерирана `__rust_alloc_error_handler`

    // ако нема `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ако има `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Специјализирајте ги клоновите во претходно алоцирана, уницијализирана меморија.
/// Користено од `Box::clone` и `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ако доделивте *прво*, може да му дозволите на оптимизаторот да ја создаде клонираната вредност на место, прескокнувајќи го локалното и преместете
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ние секогаш можеме да копираме на место, без никогаш да вклучиме локална вредност.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}