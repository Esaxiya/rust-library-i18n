//! Покажувачи за броење со еден навој.'Rc' се залага за " Референца
//! Counted'.
//!
//! Типот [`Rc<T>`][`Rc`] обезбедува заедничка сопственост на вредност од типот `T`, распределена во грамада.
//! Повикувањето на [`clone`][clone] на [`Rc`] произведува нов покажувач за истата распределба во грамадата.
//! Кога последниот [`Rc`] покажувач на дадена алокација е уништен, вредноста зачувана во таа распределба (честопати наречена "inner value") исто така се испушта.
//!
//! Заедничките референци во Rust не ја дозволуваат мутацијата по дифолт, и [`Rc`] не е исклучок: генерално не можете да добиете променлива референца за нешто што е во [`Rc`].
//! Ако ви треба подвижност, ставете [`Cell`] или [`RefCell`] во внатрешноста на [`Rc`];видете [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] користи не-атомско референтно броење.
//! Ова значи дека општите трошоци се многу ниски, но [`Rc`] не може да се испраќа помеѓу нишките и, следствено, [`Rc`] не спроведува [`Send`][send].
//! Како резултат, компајлерот Rust ќе провери *во времето на компајлирање* дека не испраќате [`Rc`] s помеѓу нишките.
//! Ако ви треба броење со повеќе навои, атомско референцирање, користете [`sync::Arc`][arc].
//!
//! Методот [`downgrade`][downgrade] може да се искористи за да се создаде [`Weak`] покажувач кој не е сопственик.
//! Покажувачот [`Weak`] може да биде [`надградба`][надградба] d на [`Rc`], но ова ќе го врати [`None`] ако вредноста зачувана во распределбата е веќе намалена.
//! Со други зборови, покажувачите `Weak` не ја одржуваат вредноста во рамките на распределбата жива;како и да е, тие * ја одржуваат живата распределба (продавницата за поддршка на внатрешната вредност).
//!
//! Циклус помеѓу покажувачите [`Rc`] никогаш нема да се распредели.
//! Поради оваа причина, [`Weak`] се користи за кршење циклуси.
//! На пример, едно дрво може да има силни покажувачи [`Rc`] од родителски јазли до деца, и [`Weak`] покажувачи од деца назад до нивните родители.
//!
//! `Rc<T>` автоматски пренасочување на `T` (преку [`Deref`] trait), така што можете да ги повикате методите на `T` на вредност од типот [`Rc<T>`][`Rc`].
//! За да се избегнат судири на името со методите на `T`, методите на самите [`Rc<T>`][`Rc`] се поврзани функции, наречени со употреба на [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Рц<T>Имплементациите на traits како `Clone` исто така може да се повикаат со користење на целосно квалификувана синтакса.
//! Некои луѓе претпочитаат да користат целосно квалификувана синтакса, додека други претпочитаат да користат метод-повик синтакса.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Синтакса на метод-повик
//! let rc2 = rc.clone();
//! // Целосно квалификувана синтакса
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] не прави автоматско пренасочување кон `T`, бидејќи внатрешната вредност можеби е веќе исфрлена.
//!
//! # Референци за клонирање
//!
//! Креирање на нова референца за истата распределба како постоечки броен покажувач за референци, се врши со употреба на `Clone` trait имплементиран за [`Rc<T>`][`Rc`] и [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Двете синтакса подолу се еквивалентни.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a и b и двете укажуваат на истата мемориска локација како и foo.
//! ```
//!
//! Синтаксата `Rc::clone(&from)` е најидиотоматска, бидејќи поизразено го пренесува значењето на кодот.
//! Во горниот пример, оваа синтакса го олеснува согледувањето дека овој код создава нова референца наместо да ја копира целата содржина на foo.
//!
//! # Examples
//!
//! Размислете за сценарио кога збир на `Gadget` се во сопственост на даден `Owner`.
//! Ние сакаме да го покажеме нашиот `Gadget` point кон нивниот `Owner`.Не можеме да го направиме ова со единствена сопственост, бидејќи повеќе од еден гаџет може да припаѓаат на истиот `Owner`.
//! [`Rc`] ни овозможува да споделуваме `Owner` помеѓу повеќе `гаџети` и да остане `Owner` да остане распределен сè додека `Gadget` поени на него.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... други полиња
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... други полиња
//! }
//!
//! fn main() {
//!     // Создадете `Owner` преброен со референци.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Создадете `Gadget` што припаѓа на `gadget_owner`.
//!     // Клонирањето на `Rc<Owner>` ни дава нов покажувач на истата распределба `Owner`, зголемувајќи го референтниот број во процесот.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Фрлете ја нашата локална променлива `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // И покрај намалувањето на `gadget_owner`, сепак можеме да го испечатиме името на `Owner` на `Gadget`.
//!     // Ова е затоа што испуштивме само еден `Rc<Owner>`, а не `Owner` на кој посочува.
//!     // Сè додека има други `Rc<Owner>` кои укажуваат на истата распределба `Owner`, тој ќе остане во живо.
//!     // Проекцијата на полето `gadget1.owner.name` работи затоа што `Rc<Owner>` автоматски се пренасочува кон `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // На крајот од функцијата, `gadget1` и `gadget2` се уништуваат, а со нив и последните броени референци на нашиот `Owner`.
//!     // Gadget Man сега се уништува исто така.
//!     //
//! }
//! ```
//!
//! Ако нашите барања се променат, а исто така треба да можеме да преминеме од `Owner` до `Gadget`, ќе наидеме на проблеми.
//! [`Rc`] покажувачот од `Owner` до `Gadget` воведува циклус.
//! Ова значи дека нивниот број на референци никогаш не може да достигне 0, а распределбата никогаш нема да биде уништена:
//! протекување на меморија.За да го заобиколиме ова, можеме да користиме [`Weak`] покажувачи.
//!
//! Rust всушност го отежнува производството на оваа јамка пред сè.За да завршиме со две вредности што се насочуваат едни на други, едната од нив треба да биде променлива.
//! Ова е тешко затоа што [`Rc`] ја спроведува безбедноста на меморијата со давање само споделени препораки за вредноста што ја обвива, и овие не дозволуваат директна мутација.
//! Треба да го завиткаме делот од вредноста што сакаме да мутираме во [`RefCell`], што обезбедува *внатрешна подвижност*: метод за да се постигне променливост преку споделена референца.
//! [`RefCell`] ги спроведува правилата за позајмување на Rust при време на траење.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... други полиња
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... други полиња
//! }
//!
//! fn main() {
//!     // Создадете `Owner` преброен со референци.
//!     // Имајте на ум дека го ставивме vector на ``Сопственикот`` `Gadget` во `RefCell` за да можеме да го мутираме преку споделена референца.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Креирајте `Gadget` што припаѓа на `gadget_owner`, како и порано.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Додадете `Gadget` на нивниот `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамичното позајмување завршува тука.
//!     }
//!
//!     // Повторувајте го нашиот `Гаџет`, печатејќи ги нивните детали.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` е `Weak<Gadget>`.
//!         // Бидејќи `Weak` покажувачите не можат да гарантираат дека распределбата сè уште постои, треба да повикаме `upgrade`, што враќа `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Во овој случај, знаеме дека распределбата сè уште постои, затоа ние едноставно го `unwrap` `Option`.
//!         // Во покомплицирана програма, можеби ќе ви треба благодатно ракување со грешки за резултат `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // На крајот од функцијата, `gadget_owner`, `gadget1` и `gadget2` се уништени.
//!     // Сега нема силни покажувачи (`Rc`) на гаџетите, па затоа се уништени.
//!     // Ова е нула за референтното сметање на Gadget Man, па тој исто така се уништува.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ова е докажано од repr(C) до future против можно реорганизирање на полето, што би се мешало во инаку безбедниот [into|from]_raw() на непроменливи внатрешни типови.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Покажувач за пребројување со еден навој.'Rc' се залага за " Референца
/// Counted'.
///
/// Погледнете го [module-level documentation](./index.html) за повеќе детали.
///
/// Вродените методи на `Rc` се сите поврзани функции, што значи дека треба да ги повикувате на пр. [`Rc::get_mut(&mut value)`][get_mut] наместо `value.get_mut()`.
/// Ова избегнува конфликти со методите од внатрешен тип `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Оваа несигурност е во ред затоа што додека овој Rc е жив, гарантирано е дека внатрешниот покажувач е валиден.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Конструира нов `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Постои имплицитен слаб покажувач во сопственост на сите силни покажувачи, што гарантира дека слабиот уништувач никогаш не ја ослободува распределбата додека работи силниот деструктор, дури и ако слабиот покажувач е зачуван во внатрешноста на силниот.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Конструира нов `Rc<T>` користејќи слаба референца кон себе.
    /// Обидот да се надополни слабата референца пред да се врати оваа функција ќе резултира со вредност `None`.
    ///
    /// Сепак, слабата референца може слободно да се клонира и да се чува за употреба подоцна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... повеќе полиња
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Конструирајте ја внатрешноста во состојба "uninitialized" со единствена слаба референца.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно е да не се откажуваме од сопственоста на слабиот покажувач, или во спротивно, меморијата може да се ослободи до времето кога се враќа `data_fn`.
        // Ако навистина сакавме да ја поминеме сопственоста, би можеле да создадеме дополнителен слаб покажувач за себе, но ова ќе резултира со дополнителни ажурирања на слабиот број на референци, што можеби инаку не е потребно.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Силните референци треба колективно да поседуваат заедничка слаба референца, затоа не управувајте со уништувачот за нашата стара слаба референца.
        //
        mem::forget(weak);
        strong
    }

    /// Конструира нов `Rc` со неиницијализирана содржина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Rc` со неиницијализирана содржина, со тоа што меморијата е исполнета со `0` бајти.
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Rc<T>`, враќајќи грешка ако алокацијата не успее
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Постои имплицитен слаб покажувач во сопственост на сите силни покажувачи, што гарантира дека слабиот уништувач никогаш не ја ослободува распределбата додека работи силниот деструктор, дури и ако слабиот покажувач е зачуван во внатрешноста на силниот.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Конструира нов `Rc` со неинцијализирана содржина, враќајќи грешка ако алокацијата не успее
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструира нов `Rc` со неницијализирана содржина, со тоа што меморијата е исполнета со `0` бајти, враќајќи грешка ако алокацијата не успее
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Конструира нов `Pin<Rc<T>>`.
    /// Ако `T` не го имплементира `Unpin`, тогаш `value` ќе биде закачен во меморијата и не може да се премести.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ја враќа внатрешната вредност, ако `Rc` има точно една силна референца.
    ///
    /// Инаку, [`Err`] се враќа со истиот `Rc` што беше донесен.
    ///
    ///
    /// Ова ќе успее дури и ако има извонредни слаби препораки.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // копирајте го содржаниот предмет

                // Наведете му на Слабите страни дека тие не можат да се промовираат со намалување на силното броење, а потоа отстранете го имплицитниот покажувач "strong weak" додека исто така ракувате со логиката на пад само со изработка на лажен Слаб.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Конструира ново парче преброено со референци со неиницијализирана содржина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Конструира ново парче преброено со референци со неиницијализирана содржина, со тоа што меморијата е исполнета со `0` бајти.
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Преобразува во `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Како и кај [`MaybeUninit::assume_init`], на повикувачот останува да гарантира дека внатрешната вредност навистина е во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува непосредно недефинирано однесување.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Преобразува во `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Како и кај [`MaybeUninit::assume_init`], на повикувачот останува да гарантира дека внатрешната вредност навистина е во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува непосредно недефинирано однесување.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Го троши `Rc`, враќајќи го завитканиот покажувач.
    ///
    /// За да избегнете истекување на меморијата, покажувачот мора да се претвори во `Rc` со употреба на [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Обезбедува суров покажувач на податоците.
    ///
    /// Броењето не влијае на кој било начин и `Rc` не се троши.
    /// Покажувачот е валиден се додека има силно броење во `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЕЗБЕДНОСТ: Ова не може да помине низ Deref::deref или Rc::inner затоа што
        // ова е потребно за да се задржи потеклото на raw/mut така што на пр
        // `get_mut` може да пишува преку покажувачот откако ќе се опорави Rc преку `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Конструира `Rc<T>` од суров покажувач.
    ///
    /// Суровиот покажувач мора претходно да биде вратен со повик до [`Rc<U>::into_raw`][into_raw] каде што `U` мора да има иста големина и порамнување како `T`.
    /// Ова е тривијално точно ако `U` е `T`.
    /// Имајте на ум дека ако `U` не е `T`, но има иста големина и порамнување, ова во основа е како трансфузија на референци од различни типови.
    /// Погледнете [`mem::transmute`][transmute] за повеќе информации за тоа кои ограничувања се применуваат во овој случај.
    ///
    /// Корисникот на `from_raw` треба да провери дали одредена вредност на `T` е исфрлена само еднаш.
    ///
    /// Оваа функција е небезбедна бидејќи неправилното користење може да доведе до несигурност во меморијата, дури и ако никогаш не се пристапи кон вратениот `Rc<T>`.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Конвертирајте назад во `Rc` за да спречите протекување.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Понатамошните повици кон `Rc::from_raw(x_ptr)` би биле несигурни во меморијата.
    /// }
    ///
    /// // Меморијата се ослободи кога `x` излезе од опсегот погоре, така што `x_ptr` сега виси!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Свртете го поместувањето за да го пронајдете оригиналниот RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Создава нов покажувач [`Weak`] на оваа распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Бидете сигурни дека не создаваме зависен Слаб
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Добива број на покажувачи [`Weak`] на оваа алокација.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Добива број на силни покажувачи (`Rc`) на оваа алокација.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Враќа `true` ако нема други покажувачи `Rc` или [`Weak`] на оваа распределба.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Враќа променлива референца во дадениот `Rc`, ако нема други покажувачи `Rc` или [`Weak`] на истата распределба.
    ///
    ///
    /// Враќа [`None`] во спротивно, бидејќи не е безбедно да мутирате споделена вредност.
    ///
    /// Видете исто така [`make_mut`][make_mut], што ќе ја означи [`clone`][clone] внатрешната вредност кога има други покажувачи.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Враќа променлива референца во дадениот `Rc`, без никаква проверка.
    ///
    /// Видете исто така [`get_mut`], кој е безбеден и прави соодветни проверки.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Било какви други покажувачи `Rc` или [`Weak`] на истата распределба не смеат да бидат пренасочени за времетраењето на вратената позајмица.
    ///
    /// Ова е тривијално, ако не постојат такви покажувачи, на пример, веднаш по `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Внимаваме * да не создадеме референца што ги покрива полињата "count", бидејќи тоа би се коси со пристапите до бројот на референци (на пр.
        // од `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Враќа `true` ако двата `Rc` укажуваат на иста распределба (во форма слична на [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Прави несигурна референца во дадениот `Rc`.
    ///
    /// Ако има и други `Rc` покажувачи за истата распределба, тогаш `make_mut` ќе ја [`clone`] внатрешната вредност на новата распределба за да обезбеди единствена сопственост.
    /// Ова се нарекува и клон-на-пишување.
    ///
    /// Ако нема други `Rc` покажувачи за оваа распределба, тогаш покажувачите [`Weak`] за оваа распределба ќе бидат одделени.
    ///
    /// Видете исто така [`get_mut`], што повеќе ќе пропадне отколку да се клонира.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Нема да клонира ништо
    /// let mut other_data = Rc::clone(&data);    // Нема да клонираме внатрешни податоци
    /// *Rc::make_mut(&mut data) += 1;        // Клонира внатрешни податоци
    /// *Rc::make_mut(&mut data) += 1;        // Нема да клонира ништо
    /// *Rc::make_mut(&mut other_data) *= 2;  // Нема да клонира ништо
    ///
    /// // Сега `data` и `other_data` упатуваат на различни алокации.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] покажувачите ќе бидат одделени:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Мора да ги клонира податоците, има и други Rcs.
            // Пред-распределете меморија за да овозможите директно запишување на клонираната вредност.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Може само да ги украде податоците, останува само Слаби страни
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Отстрани имплицитно силно слабо рефлектирање (нема потреба да изработувате лажен слаб овде-знаеме дека други слаби страни можат да исчистат за нас)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Оваа несигурност е во ред затоа што гарантирано е дека покажувачот што е вратен е *единствениот* покажувач што некогаш ќе биде вратен на Т.
        // Нашата референтна бројка е загарантирана да биде 1 во овој момент, и баравме самиот `Rc<T>` да биде `mut`, така што ја враќаме единствената можна референца за распределбата.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Обид да се спушти `Rc<dyn Any>` на тип на бетон.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Доделува `RcBox<T>` со доволен простор за евентуално големина на внатрешната вредност, каде што вредноста го има предвидениот распоред.
    ///
    /// Функцијата `mem_to_rcbox` се повикува со покажувачот на податоците и мора да врати назад (потенцијално дебел)-интер за `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Пресметајте распоред користејќи го распоредот на дадената вредност.
        // Претходно, распоредот беше пресметан на изразот `&*(ptr as* const RcBox<T>)`, но ова создаде погрешно усогласена референца (види #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Доделува `RcBox<T>` со доволен простор за евентуално големина на внатрешната вредност, каде што вредноста го има распоредот, враќајќи грешка ако распределбата не успее.
    ///
    ///
    /// Функцијата `mem_to_rcbox` се повикува со покажувачот на податоците и мора да врати назад (потенцијално дебел)-интер за `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Пресметајте распоред користејќи го распоредот на дадената вредност.
        // Претходно, распоредот беше пресметан на изразот `&*(ptr as* const RcBox<T>)`, но ова создаде погрешно усогласена референца (види #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Доделете за изгледот.
        let ptr = allocate(layout)?;

        // Иницијализирајте го RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Доделува `RcBox<T>` со доволен простор за внатрешна вредност без големина
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Доделете за `RcBox<T>` користејќи ја дадената вредност.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копирајте ја вредноста како бајти
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Ослободете ја распределбата без да ја испуштите нејзината содржина
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Доделува `RcBox<[T]>` со дадената должина.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Копирајте елементи од парче во ново доделениот Rc <\[T\]>
    ///
    /// Небезбеден затоа што повикувачот мора или да ја преземе сопственоста или да го поврзе `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Конструира `Rc<[T]>` од повторувач за кој се знае дека е со одредена големина.
    ///
    /// Однесувањето е недефинирано доколку големината е погрешна.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic штитник при клонирање на Т-елементи.
        // Во случај на panic, елементите што се запишани во новиот RcBox ќе бидат исфрлени, а потоа ќе се ослободи меморијата.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Покажувач до првиот елемент
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Се е чисто.Заборавете на чуварот за да не го ослободи новиот RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специјализација trait што се користи за `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Паѓа `Rc`.
    ///
    /// Ова ќе го намали силниот референтен број.
    /// Ако силното референтно броење достигне нула, тогаш единствените други референци (доколку ги има) се [`Weak`], затоа ние ја означуваме `drop` внатрешната вредност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Не печати ништо
    /// drop(foo2);   // Печати "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // уништи го содржаниот предмет
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // отстранете го имплицитниот покажувач "strong weak" сега кога ја уништивме содржината.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Прави клон на покажувачот `Rc`.
    ///
    /// Ова создава друг покажувач за истата распределба, зголемувајќи го силното референтно броење.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Создава нов `Rc<T>`, со вредноста `Default` за `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Хак да дозволи специјализирање за `Eq` иако `Eq` има метод.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ние ја правиме оваа специјализација овде, а не како општа оптимизација на `&T`, бидејќи во спротивно ќе додадете трошок за сите проверки на еднаквоста на рефлексиите.
/// Претпоставуваме дека `Rc` се користат за складирање на големи вредности, бавни за клонирање, но исто така тешки за проверка на еднаквоста, предизвикувајќи овој трошок полесно да се исплати.
///
/// Исто така, поверојатно е да има два клона `Rc`, кои укажуваат на иста вредност, отколку два `&Т`.
///
/// Можеме да го направиме ова само кога `T: Eq` како `PartialEq` може да биде намерно нерефлексивен.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Еднаквост за двајца `Rc` s.
    ///
    /// Два `Rc` s се еднакви ако нивните внатрешни вредности се еднакви, дури и ако се зачувани во различна распределба.
    ///
    /// Ако `T` исто така спроведува `Eq` (што подразбира рефлексивност на еднаквоста), два `Р` што укажуваат на иста распределба се секогаш еднакви.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Нееднаквост за двајца `Rc` s.
    ///
    /// Два `Rc` s се нееднакви ако нивните внатрешни вредности се нееднакви.
    ///
    /// Ако `T` исто така спроведува `Eq` (што подразбира рефлексивност на еднаквоста), два `Rc` што укажуваат на иста распределба никогаш не се нееднакви.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Делумна споредба за два `Rc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `partial_cmp()` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Помалку споредба за две `Rc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `<` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Споредба " помалку од или еднаква`за две`Rc`.
    ///
    /// Двајцата се споредуваат повикувајќи се на `<=` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Поголема од споредбата за две `Rc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `>` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Споредба за " поголема или еднаква`за две`Rc`.
    ///
    /// Двајцата се споредуваат повикувајќи се на `>=` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Споредба за два `Rc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `cmp()` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Доделете парче преброено со референци и пополнете го со клонирање на ставките `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Доделете парче од низата преброено со референци и копирајте `v` во неа.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Доделете парче од низата преброено со референци и копирајте `v` во неа.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Преместете го кутииот објект на нова распределба, сметана со референци.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Доделете парче преброено со референци и преместете ги ставките на `v` во неа.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Дозволете му на Вец да ја ослободи својата меморија, но не и да ја уништува неговата содржина
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Го зема секој елемент во `Iterator` и го собира во `Rc<[T]>`.
    ///
    /// # Карактеристики на изведбата
    ///
    /// ## Општ случај
    ///
    /// Во општ случај, собирањето во `Rc<[T]>` се врши со прво собирање во `Vec<T>`.Тоа е, кога го пишувате следново:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ова се однесува како да сме напишале:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Првиот сет на алокации се случува тука.
    ///     .into(); // Втора алокација за `Rc<[T]>` се случува овде.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ова ќе одвои онолку пати колку што е потребно за конструирање на `Vec<T>` и потоа ќе се распредели еднаш за претворање на `Vec<T>` во `Rc<[T]>`.
    ///
    ///
    /// ## Итератори со позната должина
    ///
    /// Кога вашиот `Iterator` го спроведува `TrustedLen` и е со точна големина, ќе се изврши единечна распределба за `Rc<[T]>`.На пример:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Само една алокација се случува тука.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Специјализација trait што се користи за собирање во `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ова е случај со повторувач `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗБЕДНОСТ: Треба да осигураме дека повторувачот има точна должина и ние.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Врати се на нормалното спроведување.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` е верзија на [`Rc`] која се однесува на не-сопственост на управуваната алокација.До алокацијата се пристапува со повикување на [`upgrade`] на покажувачот `Weak`, со што се враќа [«Опција»] «<« [«Rc»] »<T>> "
///
/// Бидејќи референцата `Weak` не смета за сопственост, тоа нема да спречи паѓање на вредноста зачувана во алокацијата, а самиот `Weak` не дава гаранции за вредноста што сè уште е присутна.
/// Така може да го врати [`None`] кога ["надградба"] d.
/// Сепак, забележете дека референцата `Weak` * ја спречува распределбата на самата распределба (продавницата за поддршка).
///
/// Покажувачот `Weak` е корисен за привремено повикување на распределбата управувана од [`Rc`], без да спречи паѓање на неговата внатрешна вредност.
/// Исто така се користи за да се спречат кружните препораки помеѓу покажувачите [`Rc`], бидејќи референците за меѓусебно поседување никогаш не би дозволиле да се исфрли ниту [`Rc`].
/// На пример, едно дрво може да има силни покажувачи [`Rc`] од родителски јазли до деца, и `Weak` покажувачи од деца назад до нивните родители.
///
/// Типичен начин да се добие покажувач `Weak` е да се јавите во [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ова е `NonNull` за да се овозможи оптимизирање на големината на овој тип во енуми, но не мора да е валиден покажувач.
    //
    // `Weak::new` го поставува ова на `usize::MAX` така што нема потреба да одвојува простор на купот.
    // Тоа не е вредност што вистински покажувач некогаш ќе ја има затоа што RcBox има усогласеност најмалку 2.
    // Ова е можно само кога `T: Sized`;големина `T` никогаш не висат.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Конструира нов `Weak<T>`, без да додели меморија.
    /// Повикувањето на [`upgrade`] на повратната вредност секогаш дава [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Тип на помошник за да дозволите пристап до бројот на референци без да давате никакви тврдења за полето за податоци.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Враќа суров покажувач на објектот `T` посочен од овој `Weak<T>`.
    ///
    /// Покажувачот е валиден само ако има некои силни препораки.
    /// Покажувачот може да биде обесен, ненаместен или дури [`null`] на друг начин.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // И двајцата покажуваат на истиот објект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Силниот овде го одржува во живот, така што сè уште можеме да пристапиме до објектот.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Но, не повеќе.
    /// // Можеме да направиме weak.as_ptr(), но пристапот до покажувачот ќе доведе до недефинирано однесување.
    /// // assert_eq! ("здраво", небезбеден {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ако покажувачот виси, ние го враќаме чуварот директно.
            // Ова не може да биде валидна адреса на носивост, бидејќи носивоста е барем подредена како RcBox (usize).
            ptr as *const T
        } else {
            // БЕЗБЕДНОСТ: ако is_dangling враќа неточно, тогаш покажувачот може да се референцира.
            // Товарот може да се намали во овој момент, и ние мора да ја задржиме потеклото, затоа користете сурови манипулации со покажувачот.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Го троши `Weak<T>` и го претвора во суров покажувач.
    ///
    /// Ова го претвора слабиот покажувач во суров покажувач, додека сеуште се зачувува сопственоста на една слаба референца (слабиот број не е изменет со оваа операција).
    /// Може да се претвори во `Weak<T>` со [`from_raw`].
    ///
    /// Се применуваат истите ограничувања за пристап до целта на покажувачот како и со [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Конвертира суров покажувач претходно создаден од [`into_raw`] назад во `Weak<T>`.
    ///
    /// Ова може да се користи за безбедно добивање на силна референца (повикување на [`upgrade`] подоцна) или за распределување на слабиот број со паѓање на `Weak<T>`.
    ///
    /// Потребна е сопственост на една слаба референца (со исклучок на покажувачите создадени од [`new`], бидејќи тие не поседуваат ништо; методот сè уште работи на нив).
    ///
    /// # Safety
    ///
    /// Покажувачот сигурно потекнува од [`into_raw`] и сè уште мора да ја поседува својата потенцијална слаба референца.
    ///
    /// Дозволено е силното броење да биде 0 за време на повикувањето на ова.
    /// Како и да е, ова презема сопственост на една слаба референца што во моментов е претставена како суров покажувач (слабото броење не е изменето со оваа операција) и затоа мора да биде поврзано со претходниот повик до [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Одлучи го последното слабо броење.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Погледнете Weak::as_ptr за контекст за тоа како е изведен влезниот покажувач.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ова е зависен слаб.
            ptr as *mut RcBox<T>
        } else {
            // Во спротивно, гарантирано ни е дека покажувачот потекнува од слаб слаб.
            // БЕЗБЕДНОСТ: data_offset е безбеден за повик, бидејќи ptr упатува на реално (потенцијално испуштено) Т.
            let offset = unsafe { data_offset(ptr) };
            // Така, го свртуваме надоместот за да го добиеме целиот RcBox.
            // БЕЗБЕДНОСТ: покажувачот потекнува од Слаб, така што ова поместување е безбедно.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗБЕДНОСТ: сега го вративме оригиналниот слаб покажувач, па затоа можеме да го создадеме слабиот.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Обиди за ажурирање на покажувачот `Weak` на [`Rc`], со одложување на паѓањето на внатрешната вредност ако е успешно.
    ///
    ///
    /// Враќа [`None`] ако оттогаш е исфрлена внатрешната вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Уништи ги сите силни покажувачи.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Добива број на силни покажувачи (`Rc`) што укажуваат на оваа распределба.
    ///
    /// Ако `self` е создаден со употреба на [`Weak::new`], ова ќе врати 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Добива број на покажувачи `Weak` што укажуваат на оваа распределба.
    ///
    /// Ако не останат силни покажувачи, ова ќе ја врати нулата.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // одземе имплицитно слаб ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Враќа `None` кога покажувачот виси и нема распределен `RcBox`, (т.е. кога овој `Weak` е создаден од `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Внимаваме * да не создадеме референца што го покрива полето "data", бидејќи полето може да биде мутирано истовремено (на пример, ако се исфрли последниот `Rc`, полето за податоци ќе се испушти на место).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Враќа `true` ако двата `Слаба точка укажуваат на иста распределба (слично на [`ptr::eq`]), или ако и двајцата не укажуваат на каква било распределба (бидејќи тие се создадени со `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Бидејќи ова ги споредува покажувачите, тоа значи дека `Weak::new()` ќе се изедначат едни со други, иако тие не укажуваат на каква било распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Споредување на `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Го испушта покажувачот `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Не печати ништо
    /// drop(foo);        // Печати "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // слабото сметање започнува од 1, и ќе оди на нула само ако сите силни покажувачи исчезнат.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Прави клон на покажувачот `Weak` што укажува на истата распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструира нов `Weak<T>`, распределувајќи меморија за `T` без да ја иницијализира.
    /// Повикувањето на [`upgrade`] на повратната вредност секогаш дава [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Проверивме_дадеме тука за безбедно да се справиме со mem::forget.Особено
// ако имате mem::forget Rcs (или слаби), пребројувањето може да се прелее, а потоа можете да ја ослободите распределбата додека постојат извонредни Rcs (или слаби).
//
// Абортираме затоа што ова е толку дегенерирано сценарио што не ни е гајле што се случува-ниедна вистинска програма никогаш не треба да го доживее ова.
//
// Ова треба да има занемарливи трошоци, бидејќи всушност не треба да ги клонирате овие многу во Rust благодарение на сопственоста и семантиката на движење.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Ние сакаме да прекинеме при прелевање наместо да ја испуштиме вредноста.
        // Бројот на референци никогаш нема да биде нула кога ова ќе се повика;
        // како и да е, тука вметнуваме абортус за да го навестиме LLVM за инаку пропуштената оптимизација.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Ние сакаме да прекинеме при прелевање наместо да ја испуштиме вредноста.
        // Бројот на референци никогаш нема да биде нула кога ова ќе се повика;
        // како и да е, тука вметнуваме абортус за да го навестиме LLVM за инаку пропуштената оптимизација.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Земете го офсет во рамките на `RcBox` за носивоста зад покажувачот.
///
/// # Safety
///
/// Покажувачот мора да покаже (и да има валидни метаподатоци за) претходно валидна инстанца на Т, но Т е дозволено да се испушти.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Порамнете ја големината без големина до крајот на RcBox.
    // Бидејќи RcBox е repr(C), тој секогаш ќе биде последното поле во меморијата.
    // БЕЗБЕДНОСТ: бидејќи единствените можни типови со големина се парчиња, trait објекти,
    // и надворешни типови, условот за безбедност на влезот во моментов е доволен за да ги задоволи барањата на align_of_val_raw;ова е детал за имплементација на јазикот на кој не може да се потпреме надвор од std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}