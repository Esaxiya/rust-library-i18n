/// Создава [`Vec`] што ги содржи аргументите.
///
/// `vec!` дозволува `Vec` да се дефинира со истата синтакса како изразите на низата.
/// Постојат две форми на ова макро:
///
/// - Создадете [`Vec`] што содржи дадена листа на елементи:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Создадете [`Vec`] од даден елемент и големина:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Забележете дека за разлика од изразите во низата, оваа синтакса ги поддржува сите елементи кои спроведуваат [`Clone`] и бројот на елементи не мора да биде константа.
///
/// Ова ќе го користи `clone` за удвојување израз, па затоа треба да се биде внимателен кога се користат типови кои имаат нестандардна `Clone` имплементација.
/// На пример, `vec![Rc::new(1);5] `ќе создаде vector од пет референци на истата кутија вредна цел број, а не пет референци кои укажуваат на независно кутирани цели броеви.
///
///
/// Исто така, забележете дека `vec![expr; 0]` е дозволен и произведува празен vector.
/// Ова сепак ќе го оцени `expr` и веднаш ќе ја испушти добиената вредност, затоа внимавајте на несаканите ефекти.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): со cfg(test), својствениот метод `[T]::into_vec`, потребен за оваа макро дефиниција, не е достапен.
// Наместо тоа, користете ја функцијата `slice::into_vec` што е достапна само со cfg(test) NB, видете го модулот slice::hack во slice.rs за повеќе информации
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Создава `String` користејќи интерполација на изрази за траење.
///
/// Првиот аргумент што го прима `format!` е низа формат.Ова мора да биде низа буквална.Моќта на низата за форматирање е содржана во " {}`.
///
/// Дополнителните параметри пренесени на `format!` ги заменуваат ``{}`` во низата за форматирање по дадениот редослед освен ако не се користат параметрите со име или позицијавидете [`std::fmt`] за повеќе информации.
///
///
/// Честа употреба за `format!` е спојување и интерполација на жиците.
/// Истата конвенција се користи со макроата [`print!`] и [`write!`], во зависност од наменетата дестинација на низата.
///
/// За да претворите единствена вредност во низа, користете го методот [`to_string`].Ова ќе го користи форматирањето [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ако форматирањето на trait спроведува грешка.
/// Ова укажува на неправилна имплементација бидејќи `fmt::Write for String` никогаш не враќа грешка.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Принудете го AST-јазолот на израз за да ја подобрите дијагностиката во положбата на моделот.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}