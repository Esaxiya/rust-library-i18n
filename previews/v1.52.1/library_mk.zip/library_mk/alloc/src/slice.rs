//! Динамички преглед во соседна низа, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Парчињата се поглед на блок меморија претставена како покажувач и должина.
//!
//! ```
//! // режење на Вец
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // принудувајќи низа на парче
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Парчињата се или променливи или споделени.
//! Типот на споделено парче е `&[T]`, додека типот на мутабилно парче е `&mut [T]`, каде што `T` претставува тип на елемент.
//! На пример, можете да мутирате блок меморија на кој укажува мутабилното парче:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Еве неколку работи што ги содржи овој модул:
//!
//! ## Structs
//!
//! Постојат неколку потпори кои се корисни за парчиња, како што е [`Iter`], што претставува повторување на парче.
//!
//! ## Имплементација на Trait
//!
//! Постојат неколку имплементации на заеднички traits за парчиња.Некои примери вклучуваат:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], за парчиња чиј тип на елемент е [`Eq`] или [`Ord`].
//! * [`Hash`] - за парчиња чиј тип на елемент е [`Hash`].
//!
//! ## Iteration
//!
//! Парчињата го имплементираат `IntoIterator`.Итераторот дава референци на елементите на парчиња.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Променливото парче дава непроменливи референци на елементите:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Овој повторувач дава непогодни референци на елементите на парчето, така што додека типот на елементот на парчето е `i32`, типот на елементот на повторувачот е `&mut i32`.
//!
//!
//! * [`.iter`] и [`.iter_mut`] се експлицитни методи за враќање на стандардните повторувачи.
//! * Понатамошни методи што враќаат повторувачи се [`.split`], [`.splitn`], [`.chunks`], [`.windows`] и повеќе.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Многу од употребувањата во овој модул се користат само во конфигурацијата на тестот.
// Почисто е само да го исклучите предупредувањето за неискористениот_ увоз отколку да ги поправите.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Основни методи за продолжување на парчиња
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) потребни за имплементација на макро `vec!` при тестирање на НБ, видете го модулот `hack` во оваа датотека за повеќе детали.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) потребни за имплементација на `Vec::clone` при тестирање на НБ, видете го модулот `hack` во оваа датотека за повеќе детали.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Со тоа што cfg(test) `impl [T]` не е достапен, овие три функции се всушност методи кои се наоѓаат во `impl [T]`, но не и во `core::slice::SliceExt`, ние треба да ги обезбедиме овие функции за тестот `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Не треба да додаваме вграден атрибут на ова бидејќи тоа се користи претежно во макро `vec!` и предизвикува перфектна регресија.
    // Погледнете #71204 за дискусија и резултати за перфект
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // предметите беа означени иницијализирани во јамката подолу
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) е потребно за LLVM да ги отстрани проверките на границите и има подобар кодеген од zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // векот беше распределен и иницијализиран погоре барем за оваа должина.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // распределени погоре со капацитет од `s` и иницијализирајте се на `s.len()` во ptr::copy_to_non_overlapping подолу.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Го сортира парчето.
    ///
    /// Овој вид е стабилен (т.е. не ги преуредува еднаквите елементи) и *O*(*n*\*log(* n*)) во најлош случај.
    ///
    /// Кога е применливо, се претпочита нестабилно сортирање затоа што генерално е побрзо од стабилно сортирање и не доделува помошна меморија.
    /// Погледнете [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Тековна имплементација
    ///
    /// Тековниот алгоритам е адаптивен, итеративен вид на спојување инспириран од [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Тој е дизајниран да биде многу брз во случаи кога парчето е скоро подредено или се состои од две или повеќе подредени секвенци споени една по друга.
    ///
    ///
    /// Исто така, тој доделува привремено складирање со половина од големината на `self`, но за кратки парчиња се користи не-распределувачки вид на вметнување.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Го сортира парчето со функција за споредување.
    ///
    /// Овој вид е стабилен (т.е. не ги преуредува еднаквите елементи) и *O*(*n*\*log(* n*)) во најлош случај.
    ///
    /// Функцијата за споредување мора да дефинира вкупно подредување на елементите во парчето.Ако нарачката не е тотална, редоследот на елементите е неодреден.
    /// Нарачката е целосна нарачка ако е (за сите `a`, `b` и `c`):
    ///
    /// * вкупно и антисиметрично: точно е еден од `a < b`, `a == b` или `a > b`, и
    /// * транзитивно, `a < b` и `b < c` подразбира `a < c`.Истото мора да важи и за `==` и за `>`.
    ///
    /// На пример, додека [`f64`] не спроведува [`Ord`] затоа што `NaN != NaN`, ние можеме да го користиме `partial_cmp` како функција за сортирање кога знаеме дека парчето не содржи `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Кога е применливо, се претпочита нестабилно сортирање затоа што генерално е побрзо од стабилно сортирање и не доделува помошна меморија.
    /// Погледнете [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Тековна имплементација
    ///
    /// Тековниот алгоритам е адаптивен, итеративен вид на спојување инспириран од [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Тој е дизајниран да биде многу брз во случаи кога парчето е скоро подредено или се состои од две или повеќе подредени секвенци споени една по друга.
    ///
    /// Исто така, тој доделува привремено складирање со половина од големината на `self`, но за кратки парчиња се користи не-распределувачки вид на вметнување.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обратно сортирање
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Го сортира парчето со клучна функција за извлекување.
    ///
    /// Овој вид е стабилен (т.е. не ги преуредува еднаквите елементи) и *O*(*m*\* * n *\* log(*n*)) во најлош случај, кога клучната функција е *O*(*m*).
    ///
    /// За скапи клучни функции (на пр
    /// функции кои не се едноставни пристапи до имот или основни операции), [`sort_by_cached_key`](slice::sort_by_cached_key) веројатно ќе биде значително побрз, бидејќи не ги пресметува копчињата на елементите.
    ///
    ///
    /// Кога е применливо, се претпочита нестабилно сортирање затоа што генерално е побрзо од стабилно сортирање и не доделува помошна меморија.
    /// Погледнете [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Тековна имплементација
    ///
    /// Тековниот алгоритам е адаптивен, итеративен вид на спојување инспириран од [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Тој е дизајниран да биде многу брз во случаи кога парчето е скоро подредено или се состои од две или повеќе подредени секвенци споени една по друга.
    ///
    /// Исто така, тој доделува привремено складирање со половина од големината на `self`, но за кратки парчиња се користи не-распределувачки вид на вметнување.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Го сортира парчето со клучна функција за извлекување.
    ///
    /// За време на сортирањето, функцијата на клучот се повикува само еднаш по елемент.
    ///
    /// Овој вид е стабилен (т.е. не ги преуредува еднаквите елементи) и *O*(*m*\* * n *+* n *\* log(*n*)) во најлош случај, кога клучната функција е *O*(*m*) .
    ///
    /// За едноставни клучни функции (на пр., Функции што се пристап до имот или основни операции), [`sort_by_key`](slice::sort_by_key) веројатно ќе биде побрз.
    ///
    /// # Тековна имплементација
    ///
    /// Тековниот алгоритам се заснова на [pattern-defeating quicksort][pdqsort] од Орсон Питерс, кој комбинира брз просечен случај на рандомизиран quicksort со најбрз најлош случај heapsort, додека се постигнува линеарно време на парчиња со одредени обрасци.
    /// Таа користи одредена рандомизација за да избегне дегенерирани случаи, но со фиксирано seed секогаш да обезбедува детерминистичко однесување.
    ///
    /// Во најлош случај, алгоритмот доделува привремено складирање во `Vec<(K, usize)>` должина на парчето.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Помагалка за макро за индексирање на нашиот vector според најмалиот можен тип, за да се намали алокацијата.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Елементите на `indices` се единствени, бидејќи се индексираат, така што секој вид ќе биде стабилен во однос на оригиналното парче.
                // Ние користиме `sort_unstable` тука затоа што бара помалку распределување на меморијата.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Копира `self` во нов `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Овде, `s` и `x` можат да се менуваат независно.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Копира `self` во нов `Vec` со алокатор.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Овде, `s` и `x` можат да се менуваат независно.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Забелешка, видете го модулот `hack` во оваа датотека за повеќе детали.
        hack::to_vec(self, alloc)
    }

    /// Го претвора `self` во vector без клонови или распределба.
    ///
    /// Резултирачкиот vector може да се претвори во кутија преку `Vec`<T>метод `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` не може да се користи повеќе затоа што е претворен во `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Забелешка, видете го модулот `hack` во оваа датотека за повеќе детали.
        hack::into_vec(self)
    }

    /// Создава vector со повторување на парче `n` пати.
    ///
    /// # Panics
    ///
    /// Оваа функција ќе биде panic ако капацитетот се прелее.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic при прелевање:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ако `n` е поголем од нула, може да се подели како `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` е бројот претставен со најлевиот '1' бит на `n`, а `rem` е преостанатиот дел на `n`.
        //
        //

        // Користење на `Vec` за пристап до `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` повторувањето се прави со удвојување на `buf` `expn`-пати.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ако `m > 0`, има преостанати битови до најлевиот '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` има капацитет од `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) повторувањето се врши со копирање на првите `rem` повторувања од самиот `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ова не се преклопува уште од `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` е еднаква на `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Израмнува парче `T` во единечна вредност `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Израмнува парче `T` во единечна вредност `Self::Output`, поставувајќи даден сепаратор помеѓу секој.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Израмнува парче `T` во единечна вредност `Self::Output`, поставувајќи даден сепаратор помеѓу секој.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Враќа vector што содржи копија од ова парче, каде што секој бајт е мапиран во неговиот еквивалент ASCII со големи букви.
    ///
    ///
    /// Буквите ASCII 'a' до 'z' се мапирани на 'A' до 'Z', но буквите што не се ASCII се непроменети.
    ///
    /// За да ја зголемите големината на вредноста на место, користете [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Враќа vector што содржи копија од ова парче, каде што секој бајт е мапиран во неговиот еквивалент со мали букви ASCII.
    ///
    ///
    /// Буквите ASCII 'A' до 'Z' се мапирани на 'a' до 'z', но буквите што не се ASCII се непроменети.
    ///
    /// За да ја намалите големината на вредноста на место, користете [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Продолжување traits за парчиња над специфични видови на податоци
////////////////////////////////////////////////////////////////////////////////

/// Помошник trait за [`[T]: : concat`](парче::concat).
///
/// Note: параметарот од типот `Item` не се користи во овој trait, но тој имплицира да биде поопшт.
/// Без него, ја добиваме оваа грешка:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ова е затоа што може да постојат типови `V` со повеќе `Borrow<[_]>` импликации, како што ќе се применуваат повеќе типови `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Резултирачкиот тип по спојување
    type Output;

    /// Имплементација на [`[T]: : concat`](парче::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Помошник trait за [`[T]: : приклучи се]](парче::придружи се)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Резултирачкиот тип по спојување
    type Output;

    /// Имплементација на [`[T]: : придружи се`](парче::придружи се)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Стандардни имплементации на trait за парчиња
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // фрли нешто во целта што нема да биде препишано
        target.truncate(self.len());

        // target.len <= self.len се должи на покраината погоре, така што парчињата тука се секогаш во граници.
        //
        let (init, tail) = self.split_at(target.len());

        // повторна употреба на содржаните вредности allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Вметнува `v[0]` во претходно подредена секвенца `v[1..]` така што целиот `v[..]` станува подреден.
///
/// Ова е интегрална потпрограма на вид на вметнување.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Постојат три начини да се спроведе вметнување тука:
            //
            // 1. Заменете ги соседните елементи додека првиот не стигне до крајната дестинација.
            //    Сепак, на овој начин ние копираме податоци повеќе отколку што е потребно.
            //    Ако елементите се големи структури (скапи се за копирање), овој метод ќе биде бавен.
            //
            // 2. Повторувајте се додека не се најде вистинското место за првиот елемент.
            // Потоа поместете ги елементите што го наследуваат за да ви остават простор и конечно ставете го во преостанатата дупка.
            // Ова е добар метод.
            //
            // 3. Копирајте го првиот елемент во привремена променлива.Повторувајте се додека не се најде вистинското место за тоа.
            // Како што одиме, копирајте го секој пресечен елемент во слотот што му претходи.
            // Конечно, копирајте ги податоците од привремената променлива во преостанатата дупка.
            // Овој метод е многу добар.
            // Реперите покажаа малку подобри перформанси отколку со 2-от метод.
            //
            // Сите методи беа обележани, а третиот покажа најдобри резултати.Значи, ние го одбравме оној.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Средната состојба на процесот на вметнување секогаш се следи со `hole`, што служи за две цели:
            // 1. Заштитува интегритет на `v` од panics во `is_less`.
            // 2. На крајот ја пополнува преостанатата дупка во `v`.
            //
            // Безбедност на Panic:
            //
            // Ако `is_less` panics во која било точка од процесот, `hole` ќе падне и ќе ја пополни дупката во `v` со `tmp`, со што ќе осигури дека `v` сè уште го држи секој предмет што првично го држеше точно еднаш.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` паѓа и со тоа копира `tmp` во преостанатата дупка во `v`.
        }
    }

    // Кога паѓа, копирајте од `src` во `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ги спојува намалувањето на патеките `v[..mid]` и `v[mid..]` користејќи `buf` како привремено складирање и го зачувува резултатот во `v[..]`.
///
/// # Safety
///
/// Двете парчиња мора да бидат непразни и `mid` да бидат во граници.
/// Тампонот `buf` мора да биде доволно долг за да собере копија од пократкото парче.
/// Исто така, `T` не смее да биде тип на нула големина.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Процесот на спојување прво го копира пократкиот тек во `buf`.
    // Потоа, се трага на новокопираниот рок и подолгото трчање напред (или назад), споредувајќи ги нивните следни непотрошени елементи и копирајќи го помалиот (или поголем) во `v`.
    //
    // Веднаш штом ќе се потроши целосно пократкиот рок, процесот е завршен.Ако прво се потроши подолг рок, тогаш мора да копираме што останува од пократкиот рок во преостанатата дупка во `v`.
    //
    // Средната состојба на процесот секогаш ја следи `hole`, што служи за две цели:
    // 1. Заштитува интегритет на `v` од panics во `is_less`.
    // 2. Ја пополнува преостанатата дупка во `v` ако прво се потроши подолг рок.
    //
    // Безбедност на Panic:
    //
    // Ако `is_less` panics во која било точка од процесот, `hole` ќе падне и ќе ја пополни дупката во `v` со неконзумиран опсег во `buf`, со што ќе осигури дека `v` сè уште го држи секој предмет што првично го држеше точно еднаш.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Левиот тек е пократок.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Првично, овие покажувачи укажуваат на почетоците на нивните низи.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Консумирајте ја помалата страна.
            // Доколку е еднакво, претпочитајте лево трчање за одржување на стабилноста.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Правото трчање е пократко.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Првично, овие покажувачи минуваат покрај краевите на нивните низи.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Консумирајте ја поголемата страна.
            // Ако е еднакво, претпочитајте вистинско трчање за да ја одржите стабилноста.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Конечно, `hole` паѓа.
    // Ако пократкиот рок не беше целосно потрошен, што и да остане, сега ќе се копира во дупката во `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Кога паѓа, копирајте го опсегот `start..end` во `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` не е тип на нула големина, па затоа е во ред да се подели со нејзината големина.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Овој вид на спојување позајмува некои (но не сите) идеи од TimSort, што е детално опишано [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Алгоритмот идентификува строго опаѓачки и не опаѓачки подредувања, кои се нарекуваат природни текови.Има уште еден куп на чекање што треба да се спојат.
/// Секое ново пронајдено трчање се турка врз магацинот, а потоа некои парови соседни трчања се спојуваат додека не се задоволат овие две инваријанти:
///
/// 1. за секој `i` во `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. за секој `i` во `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инваријантите осигуруваат дека вкупното време на траење е *O*(*n*\*log(* n*)) во најлош случај.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Парчињата до оваа должина се сортираат со помош на сортирање на вметнување.
    const MAX_INSERTION: usize = 20;
    // Многу кратки работи се прошируваат со помош на сортирање на вметнување за да се опфатат барем толку многу елементи.
    const MIN_RUN: usize = 10;

    // Подредувањето нема значајно однесување кај типовите со нула големина.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Кратките низи се сортираат на место преку сортирање на вметнување за да се избегнат распределбите.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Доделете тампон за да го користите како гребење на меморијата.Ја задржуваме должината 0 за да можеме да чуваме плитки копии од содржината на `v` без да ризикуваме докторите да работат на копии доколку `is_less` panics.
    //
    // При спојување на две подредени работи, овој тампон држи копија од пократкиот рок, кој секогаш ќе има должина најмногу `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Со цел да ги идентификуваме природните патеки во `v`, ние го поминуваме наназад.
    // Тоа може да изгледа како чудна одлука, но земете го предвид фактот дека спојувањето почесто оди во спротивна насока (forwards).
    // Според одредниците, спојувањето напред е нешто побрзо отколку спојувањето наназад.
    // Да заклучам, идентификувањето на трчањата со траверзирање наназад ги подобрува перформансите.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Пронајдете го следното природно возење и свртете го назад ако е строго опаѓачки.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Вметнете уште неколку елементи во патеката ако е премногу кратко.
        // Сортирањето на вметнување е побрзо од сортирањето на спојувањето на кратки низи, така што ова значително ги подобрува перформансите.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Притиснете го ова трчање на оџакот.
        runs.push(Run { start, len: end - start });
        end = start;

        // Спојте неколку парови соседни трчања за да ги задоволите инваријантите.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Конечно, точно едно трчање мора да остане во оџакот.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ја испитува магацинот на извршувања и го идентификува следниот пар на извршувања за спојување.
    // Поконкретно, ако се врати `Some(r)`, тоа значи дека следните `runs[r]` и `runs[r + 1]` мора да се спојат.
    // Ако наместо тоа, алгоритмот треба да продолжи да гради нов рок, `None` се враќа.
    //
    // TimSort е озлогласен за своите софтверски имплементации, како што е опишано овде:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Суштината на приказната е: ние мора да ги спроведеме инваријантите на првите четири трчања на магацинот.
    // Спроведувањето на нив само на првите три не е доволно за да се осигура дека инваријантите сè уште ќе ги држат *сите* работи во магацинот.
    //
    // Оваа функција правилно ги проверува инваријантите за првите четири работи.
    // Дополнително, ако горниот тек започнува со индекс 0, тој секогаш ќе бара операција за спојување сè додека оџакот не се сруши целосно, со цел да се заврши сортирањето.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}