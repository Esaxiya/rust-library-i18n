#![stable(feature = "rust1", since = "1.0.0")]

//! Покажувачи за броење референтни за конец.
//!
//! Погледнете ја документацијата [`Arc<T>`][Arc] за повеќе детали.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Меко ограничување на количината на препораки што може да се направат на `Arc`.
///
/// Пречекорувањето над оваа граница ќе ја прекине вашата програма (иако не мора) во референците за _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer не поддржува мемориски огради.
// За да избегнете лажни позитивни извештаи во Arc/Слаба имплементација, наместо тоа, користете атомски оптоварувања за синхронизација.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Покажувач за броење референтни за безбедна нишка.'Arc' се залага за " Броено атомско повикување`.
///
/// Типот `Arc<T>` обезбедува споделена сопственост на вредност од типот `T`, распределена во грамада.Повикувањето на [`clone`][clone] на `Arc` произведува нова инстанца `Arc`, што укажува на истата распределба на грамадата како и изворот `Arc`, истовремено зголемувајќи го референтниот број.
/// Кога последниот `Arc` покажувач на дадена алокација е уништен, вредноста зачувана во таа распределба (честопати наречена "inner value") исто така се испушта.
///
/// Заедничките референци во Rust не ја дозволуваат мутацијата по дифолт, а `Arc` не е исклучок: генерално не можете да добиете променлива референца за нешто што е во `Arc`.Ако треба да мутирате преку `Arc`, користете [`Mutex`][mutex], [`RwLock`][rwlock] или некој од типовите [`Atomic`][atomic].
///
/// ## Безбедност на конец
///
/// За разлика од [`Rc<T>`], `Arc<T>` користи атомски операции за референтно броење.Ова значи дека е безбеден за конец.Недостаток е што атомските операции се поскапи од обичните пристапи до меморијата.Ако не споделувате распределувања сметани на референци помеѓу нишките, размислете да користите [`Rc<T>`] за пониски трошоци.
/// [`Rc<T>`] е безбеден стандард, бидејќи компајлерот ќе фати секој обид да испрати [`Rc<T>`] помеѓу темите.
/// Сепак, библиотеката може да избере `Arc<T>` со цел да им даде на потрошувачите на библиотеката поголема флексибилност.
///
/// `Arc<T>` ќе ги имплементира [`Send`] и [`Sync`] сè додека `T` ги спроведува [`Send`] и [`Sync`].
/// Зошто не можете да ставите безбеден тип `T` во нишка во `Arc<T>` за да го направите безбеден со конец?Ова може да биде малку контра-интуитивно на почетокот: на крајот на краиштата, зарем не е поентата на `Arc<T>` конецот за безбедност?Клучот е ова: `Arc<T>` го прави безбеден конецот да има повеќекратна сопственост на истите податоци, но не додава безбедност на конецот на неговите податоци.
///
/// Размислете за `Arc <` [[RefCell<T>`]` >`.
/// [`RefCell<T>`] не е [`Sync`] и ако `Arc<T>` секогаш беше [`Send`], `Arc <` [`RefCell<T>"]"> ќе биде исто така.
/// Но, тогаш би имале проблем:
/// [`RefCell<T>`] не е безбедна за конец;води евиденција за бројот на задолжувања со употреба на не-атомски операции.
///
/// На крајот, ова значи дека можеби ќе треба да го спарите `Arc<T>` со некаков вид [`std::sync`], обично [`Mutex<T>`][mutex].
///
/// ## Циклуси на кршење со `Weak`
///
/// Методот [`downgrade`][downgrade] може да се користи за да се создаде [`Weak`] покажувач кој не е сопственик.Покажувачот [`Weak`] може да биде [`надградба`][надградба] d на `Arc`, но ова ќе го врати [`None`] ако вредноста зачувана во алокацијата е веќе намалена.
/// Со други зборови, покажувачите `Weak` не ја одржуваат вредноста во рамките на распределбата жива;како и да е, тие * ја одржуваат алокацијата (резервната продавница за вредноста) жива.
///
/// Циклус помеѓу покажувачите `Arc` никогаш нема да се распредели.
/// Поради оваа причина, [`Weak`] се користи за кршење циклуси.На пример, едно дрво може да има силни покажувачи `Arc` од родителски јазли до деца, и [`Weak`] покажувачи од деца назад до нивните родители.
///
/// # Референци за клонирање
///
/// Креирање на нова референца од постоечки покажувач преброен на референци се врши со употреба на `Clone` trait имплементиран за [`Arc<T>`][Arc] и [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Двете синтакса подолу се еквивалентни.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b и foo се сите лакови кои укажуваат на истата локација на меморијата
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматски пренасочување на `T` (преку [`Deref`][deref] trait), така што можете да ги повикате методите на `T` на вредност од типот `Arc<T>`.За да се избегнат судири на името со методите на `T`, методите на самите `Arc<T>` се поврзани функции, наречени со употреба на [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Лак<T>Имплементациите на traits како `Clone` исто така може да се повикаат со користење на целосно квалификувана синтакса.
/// Некои луѓе претпочитаат да користат целосно квалификувана синтакса, додека други претпочитаат да користат метод-повик синтакса.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Синтакса на метод-повик
/// let arc2 = arc.clone();
/// // Целосно квалификувана синтакса
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] не прави автоматско пренасочување кон `T`, бидејќи внатрешната вредност можеби е веќе исфрлена.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Споделување на некои непроменливи податоци помеѓу темите:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Забележете дека ние ** не ги извршуваме овие тестови овде.
// Градителите на windows стануваат супер незадоволни ако нишката ја надживее главната нишка, а потоа излезе во исто време (нешто ќор-сокаци), така што само ќе го избегнеме ова целосно со тоа што не ги извршуваме овие тестови.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Споделување на немирлив [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Погледнете го [`rc` documentation][rc_examples] за повеќе примери за броење на референци воопшто.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` е верзија на [`Arc`] која се однесува на не-сопственост на управуваната алокација.
/// До алокацијата се пристапува со повикување на [`upgrade`] на покажувачот `Weak`, што враќа [" Опција`] " <" [" Лак`]<T>> "
///
/// Бидејќи референцата `Weak` не смета за сопственост, тоа нема да спречи паѓање на вредноста зачувана во алокацијата, а самиот `Weak` не дава гаранции за вредноста што сè уште е присутна.
///
/// Така може да го врати [`None`] кога ["надградба"] d.
/// Сепак, забележете дека референцата `Weak` * ја спречува распределбата на самата распределба (продавницата за поддршка).
///
/// Покажувачот `Weak` е корисен за привремено повикување на распределбата управувана од [`Arc`], без да спречи паѓање на неговата внатрешна вредност.
/// Исто така се користи за да се спречат кружните препораки помеѓу покажувачите [`Arc`], бидејќи референците за меѓусебно поседување никогаш не би дозволиле да се исфрли ниту [`Arc`].
/// На пример, едно дрво може да има силни покажувачи [`Arc`] од родителски јазли до деца, и `Weak` покажувачи од деца назад до нивните родители.
///
/// Типичен начин да се добие покажувач `Weak` е да се јавите во [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ова е `NonNull` за да се овозможи оптимизирање на големината на овој тип во енуми, но не мора да е валиден покажувач.
    //
    // `Weak::new` го поставува ова на `usize::MAX` така што нема потреба да одвојува простор на купот.
    // Тоа не е вредност што вистински покажувач некогаш ќе ја има затоа што RcBox има усогласеност најмалку 2.
    // Ова е можно само кога `T: Sized`;големина `T` никогаш не висат.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ова е докажано од repr(C) до future против можно реорганизирање на полето, што би се мешало во инаку безбедниот [into|from]_raw() на непроменливи внатрешни типови.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // вредноста usize::MAX делува како чувар на привремено "locking" можноста за надградба на слаби покажувачи или декласирање на силните;ова се користи за да се избегнат трки во `make_mut` и `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Конструира нов `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Започнете го слабиот број на покажувачи како 1, што е слаб покажувач што го држат сите силни покажувачи (kinda), видете std/rc.rs за повеќе информации
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Конструира нов `Arc<T>` користејќи слаба референца кон себе.
    /// Обидот да се надополни слабата референца пред да се врати оваа функција ќе резултира со вредност `None`.
    /// Сепак, слабата референца може слободно да се клонира и да се чува за употреба подоцна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Конструирајте ја внатрешноста во состојба "uninitialized" со единствена слаба референца.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно е да не се откажуваме од сопственоста на слабиот покажувач, или во спротивно, меморијата може да се ослободи до времето кога се враќа `data_fn`.
        // Ако навистина сакавме да ја поминеме сопственоста, би можеле да создадеме дополнителен слаб покажувач за себе, но ова ќе резултира со дополнителни ажурирања на слабиот број на референци, што можеби инаку не е потребно.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Сега можеме правилно да ја иницијализираме внатрешната вредност и да ја претвориме нашата слаба референца во силна референца.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Горенаведеното запишување во полето за податоци мора да биде видливо за сите нишки што набудуваат не-нула силен број.
            // Затоа ни треба барем нарачка "Release" за да се синхронизираме со `compare_exchange_weak` во `Weak::upgrade`.
            //
            // "Acquire" нарачката не е потребна.
            // Кога ги разгледуваме можните однесувања на `data_fn`, треба да разгледаме само што може да стори со упатување на не-надградлив `Weak`:
            //
            // - Може да го *клонира*`Weak`, зголемувајќи го слабиот број на референци.
            // - Може да ги исфрли тие клонови, намалувајќи го слабиот референтен број (но никогаш на нула).
            //
            // Овие несакани ефекти не влијаат врз нас на кој било начин и не се можни други несакани ефекти само со безбеден код.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Силните референци треба колективно да поседуваат заедничка слаба референца, затоа не управувајте со уништувачот за нашата стара слаба референца.
        //
        mem::forget(weak);
        strong
    }

    /// Конструира нов `Arc` со неиницијализирана содржина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Arc` со неиницијализирана содржина, со тоа што меморијата е исполнета со `0` бајти.
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Pin<Arc<T>>`.
    /// Ако `T` не го имплементира `Unpin`, тогаш `data` ќе биде закачен во меморијата и не може да се премести.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Конструира нов `Arc<T>`, враќајќи грешка ако алокацијата не успее.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Започнете го слабиот број на покажувачи како 1, што е слаб покажувач што го држат сите силни покажувачи (kinda), видете std/rc.rs за повеќе информации
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Конструира нов `Arc` со неинцијализирана содржина, враќајќи грешка ако алокацијата не успее.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструира нов `Arc` со неинцијализирана содржина, при што меморијата е исполнета со `0` бајти, враќајќи грешка ако алокацијата не успее.
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ја враќа внатрешната вредност, ако `Arc` има точно една силна референца.
    ///
    /// Инаку, [`Err`] се враќа со истиот `Arc` што беше донесен.
    ///
    ///
    /// Ова ќе успее дури и ако има извонредни слаби препораки.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Направете слаб покажувач за да ја исчистите имплицитната силно-слаба референца
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Конструира ново парче атомички преброено со неинцијализирана содржина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Конструира ново парче сметано со атомски референци со неиницијализирана содржина, со тоа што меморијата е исполнета со `0` бајти.
    ///
    ///
    /// Погледнете [`MaybeUninit::zeroed`][zeroed] за примери за правилна и неправилна употреба на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Преобразува во `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Како и кај [`MaybeUninit::assume_init`], на повикувачот останува да гарантира дека внатрешната вредност навистина е во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува непосредно недефинирано однесување.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Преобразува во `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Како и кај [`MaybeUninit::assume_init`], на повикувачот останува да гарантира дека внатрешната вредност навистина е во почетна состојба.
    ///
    /// Повикувањето на ова кога содржината сè уште не е целосно иницијализирана, предизвикува непосредно недефинирано однесување.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Го троши `Arc`, враќајќи го завитканиот покажувач.
    ///
    /// За да избегнете истекување на меморијата, покажувачот мора да се претвори во `Arc` со употреба на [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Обезбедува суров покажувач на податоците.
    ///
    /// Броењето не влијае на кој било начин и `Arc` не се троши.
    /// Покажувачот е валиден се додека има силно броење во `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЕЗБЕДНОСТ: Ова не може да помине низ Deref::deref или RcBoxPtr::inner затоа што
        // ова е потребно за да се задржи потеклото на raw/mut така што на пр
        // `get_mut` може да пишува преку покажувачот откако ќе се опорави Rc преку `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Конструира `Arc<T>` од суров покажувач.
    ///
    /// Суровиот покажувач мора претходно да биде вратен со повик до [`Arc<U>::into_raw`][into_raw] каде што `U` мора да има иста големина и порамнување како `T`.
    /// Ова е тривијално точно ако `U` е `T`.
    /// Имајте на ум дека ако `U` не е `T`, но има иста големина и порамнување, ова во основа е како трансфузија на референци од различни типови.
    /// Погледнете [`mem::transmute`][transmute] за повеќе информации за тоа кои ограничувања се применуваат во овој случај.
    ///
    /// Корисникот на `from_raw` треба да провери дали одредена вредност на `T` е исфрлена само еднаш.
    ///
    /// Оваа функција е небезбедна бидејќи неправилното користење може да доведе до несигурност во меморијата, дури и ако никогаш не се пристапи кон вратениот `Arc<T>`.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Конвертирајте назад во `Arc` за да спречите протекување.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Понатамошните повици кон `Arc::from_raw(x_ptr)` би биле несигурни во меморијата.
    /// }
    ///
    /// // Меморијата се ослободи кога `x` излезе од опсегот погоре, така што `x_ptr` сега виси!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Свртете го поместувањето за да го пронајдете оригиналниот ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Создава нов покажувач [`Weak`] на оваа распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ова Опуштено е во ред затоа што ја проверуваме вредноста во CAS подолу.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // проверете дали слабиот бројач е моментално "locked";ако е така, врти.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: овој код во моментов ја игнорира можноста за прелевање
            // во usize::MAX;воопшто и Rc и Arc треба да се прилагодат за да се справат со прелевање.
            //

            // За разлика од Clone(), ова треба да биде читање на стекнување за да се синхронизираме со пишувањето што доаѓа од `is_unique`, така што настаните пред тоа пишување се случуваат пред ова читање.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Бидете сигурни дека не создаваме зависен Слаб
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Добива број на покажувачи [`Weak`] на оваа алокација.
    ///
    /// # Safety
    ///
    /// Овој метод сам по себе е безбеден, но правилно користење бара дополнителна грижа.
    /// Друга нишка може да го смени слабиот број во секое време, вклучително и потенцијално помеѓу повикувањето на овој метод и постапувањето според резултатот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ова тврдење е детерминистичко затоа што не сме споделиле `Arc` или `Weak` помеѓу темите.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ако слабото броење е заклучено, вредноста на броењето беше 0 непосредно пред да се земе бравата.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Добива број на силни покажувачи (`Arc`) на оваа алокација.
    ///
    /// # Safety
    ///
    /// Овој метод сам по себе е безбеден, но правилно користење бара дополнителна грижа.
    /// Друга нишка може да го смени силното пребројување во секое време, вклучително и потенцијално помеѓу повикувањето на овој метод и постапувањето според резултатот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ова тврдење е детерминистичко затоа што не сме го споделиле `Arc` помеѓу темите.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Го зголемува силното референтно сметање на `Arc<T>` поврзан со дадениот покажувач за еден.
    ///
    /// # Safety
    ///
    /// Покажувачот мора да е добиен преку `Arc::into_raw`, а поврзаната инстанца `Arc` мора да биде валидна (т.е.
    /// силното броење мора да биде најмалку 1) за времетраењето на овој метод.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ова тврдење е детерминистичко затоа што не сме го споделиле `Arc` помеѓу темите.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Задржете го лакот, но не допирајте повторно броење со завиткување во ManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Сега зголемете го пребројувањето, но не фрлајте ниту ново пресметување
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Го намалува силното референтно сметање на `Arc<T>` поврзано со дадениот покажувач по еден.
    ///
    /// # Safety
    ///
    /// Покажувачот мора да е добиен преку `Arc::into_raw`, а поврзаната инстанца `Arc` мора да биде валидна (т.е.
    /// силното броење мора да биде најмалку 1) при повикување на овој метод.
    /// Овој метод може да се искористи за ослободување на последниот `Arc` и резервната меморија, но **не треба да се повикува** откако ќе се ослободи конечниот `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Тие тврдења се детерминистички затоа што не сме го споделиле `Arc` помеѓу темите.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Оваа несигурност е во ред затоа што додека овој лак е жив, гарантирано е дека внатрешниот покажувач е валиден.
        // Понатаму, знаеме дека самата структура `ArcInner` е `Sync` бидејќи и внатрешните податоци се `Sync`, затоа сме во можност да позајмиме непроменлив покажувач за овие содржини.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Не-подвлечен дел од `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Уништете ги податоците во овој момент, иако можеби нема да ја ослободиме самата распределба на полето (сè уште може да има слаби покажувачи што лежат наоколу).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Спуштете го слабиот рефлексија колективно држено од сите силни референци
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Враќа `true` ако двата `Arc` покажуваат на иста распределба (во форма слична на [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Доделува `ArcInner<T>` со доволен простор за евентуално големина на внатрешната вредност, каде што вредноста го има предвидениот распоред.
    ///
    /// Функцијата `mem_to_arcinner` се повикува со покажувачот на податоците и мора да врати назад (потенцијално дебел)-интер за `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Пресметајте распоред користејќи го распоредот на дадената вредност.
        // Претходно, распоредот беше пресметан на изразот `&*(ptr as* const ArcInner<T>)`, но ова создаде погрешно усогласена референца (види #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Доделува `ArcInner<T>` со доволен простор за евентуално големина на внатрешната вредност, каде што вредноста го има распоредот, враќајќи грешка ако распределбата не успее.
    ///
    ///
    /// Функцијата `mem_to_arcinner` се повикува со покажувачот на податоците и мора да врати назад (потенцијално дебел)-интер за `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Пресметајте распоред користејќи го распоредот на дадената вредност.
        // Претходно, распоредот беше пресметан на изразот `&*(ptr as* const ArcInner<T>)`, но ова создаде погрешно усогласена референца (види #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Иницијализирајте го ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Доделува `ArcInner<T>` со доволен простор за внатрешна вредност без големина.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Доделете за `ArcInner<T>` користејќи ја дадената вредност.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копирајте ја вредноста како бајти
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Ослободете ја распределбата без да ја испуштите нејзината содржина
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Доделува `ArcInner<[T]>` со дадената должина.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Копирајте ги елементите од парчето во ново доделениот Arc <\[T\]>
    ///
    /// Небезбеден затоа што повикувачот мора или да ја преземе сопственоста или да го поврзе `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Конструира `Arc<[T]>` од повторувач за кој се знае дека е со одредена големина.
    ///
    /// Однесувањето е недефинирано доколку големината е погрешна.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic штитник при клонирање на Т-елементи.
        // Во случај на panic, елементите што се запишани во новиот ArcInner ќе бидат исфрлени, а потоа ќе се ослободи меморијата.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Покажувач до првиот елемент
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Се е чисто.Заборавете на чуварот за да не го ослободи новиот ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специјализација trait што се користи за `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Прави клон на покажувачот `Arc`.
    ///
    /// Ова создава друг покажувач за истата распределба, зголемувајќи го силното референтно броење.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Користењето опуштено нарачување е во ред овде, бидејќи познавањето на оригиналната референца спречува други нишки погрешно да го избришат објектот.
        //
        // Како што е објаснето во [Boost documentation][1], зголемувањето на референтниот бројач секогаш може да се направи со memory_order_relaxed: Новите препораки на објектот може да се формираат само од постоечка референца, а пренесувањето на постојната референца од една нишка на друга мора веќе да обезбеди каква било потребна синхронизација.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Сепак, треба да се чуваме од масивните пресметки во случај некој да ги заборави лаковите.
        // Ако не го сториме ова, броењето може да се прелее и корисниците ќе користат бесплатно.
        // Ние расно се заситуваме до `isize::MAX` под претпоставка дека нема ~2 милијарди нишки што го зголемуваат референтниот број одеднаш.
        //
        // Овој branch никогаш нема да биде земен во ниту една реална програма.
        //
        // Абортираме затоа што таквата програма е неверојатно дегенерирана и не се грижиме да ја поддржуваме.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Прави несигурна референца во дадениот `Arc`.
    ///
    /// Ако има и други `Arc` или [`Weak`] покажувачи за истата распределба, тогаш `make_mut` ќе создаде нова распределба и ќе се повика на [`clone`][clone] на внатрешната вредност за да обезбеди единствена сопственост.
    /// Ова се нарекува и клон-на-пишување.
    ///
    /// Забележете дека ова се разликува од однесувањето на [`Rc::make_mut`] што ги раздвојува преостанатите покажувачи `Weak`.
    ///
    /// Видете исто така [`get_mut`][get_mut], што повеќе ќе пропадне отколку да се клонира.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Нема да клонира ништо
    /// let mut other_data = Arc::clone(&data); // Нема да клонираме внатрешни податоци
    /// *Arc::make_mut(&mut data) += 1;         // Клонира внатрешни податоци
    /// *Arc::make_mut(&mut data) += 1;         // Нема да клонира ништо
    /// *Arc::make_mut(&mut other_data) *= 2;   // Нема да клонира ништо
    ///
    /// // Сега `data` и `other_data` упатуваат на различни алокации.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Имајте на ум дека имаме и силна референца и слаба референца.
        // Така, ослободувањето на нашата силна референца само по себе, нема да предизвика меморијата да се распредели.
        //
        // Користете Acquire за да се осигурате дека гледаме какви било записи на `weak` што се случуваат пред да се запишат пораките (т.е. намалувања) на `strong`.
        // Бидејќи држиме слаб број, нема шанси самиот ArcInner да биде распределен.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Постои уште еден силен покажувач, затоа мора да клонираме.
            // Пред-распределете меморија за да овозможите директно запишување на клонираната вредност.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Опуштено е доволно во горенаведеното затоа што ова е фундаментално оптимизирање: ние секогаш се натпреваруваме со слаби покажувачи.
            // Најлош случај, на крајот непотребно доделивме нов лак.
            //

            // Го отстранивме последниот силен реф, но остануваат дополнителни слаби реф.
            // Moveе ја преместиме содржината на нов лак и ќе ги поништиме другите слаби реф.
            //

            // Забележете дека не е можно читањето на `weak` да дава usize::MAX (т.е. заклучено), бидејќи слабиот број може да се заклучи само со нишка со силна референца.
            //
            //

            // Материјализирајте го нашиот сопствен имплицитен слаб покажувач, за да може да го исчисти ArcInner по потреба.
            //
            let _weak = Weak { ptr: this.ptr };

            // Може само да ги украде податоците, останува само Слаби страни
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ние бевме единствената референца од кој било вид;возвратете се на силниот број на реф.
            //
            this.inner().strong.store(1, Release);
        }

        // Како и кај `get_mut()`, небезбедноста е во ред затоа што нашата референца беше или единствена за почеток, или стана една по клонирање на содржината.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Враќа променлива референца во дадениот `Arc`, ако нема други покажувачи `Arc` или [`Weak`] на истата распределба.
    ///
    ///
    /// Враќа [`None`] во спротивно, бидејќи не е безбедно да мутирате споделена вредност.
    ///
    /// Видете исто така [`make_mut`][make_mut], што ќе ја означи [`clone`][clone] внатрешната вредност кога има други покажувачи.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Оваа несигурност е во ред затоа што гарантирано е дека покажувачот што е вратен е *единствениот* покажувач што некогаш ќе биде вратен на Т.
            // Нашата референтна бројка е загарантирана да биде 1 во овој момент, и баравме самиот лак да биде `mut`, така што ја враќаме единствената можна референца на внатрешните податоци.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Враќа променлива референца во дадениот `Arc`, без никаква проверка.
    ///
    /// Видете исто така [`get_mut`], кој е безбеден и прави соодветни проверки.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Било какви други покажувачи `Arc` или [`Weak`] на истата распределба не смеат да бидат пренасочени за времетраењето на вратената позајмица.
    ///
    /// Ова е тривијално, ако не постојат такви покажувачи, на пример, веднаш по `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Внимаваме * да не создадеме референца што ги покрива полињата "count", бидејќи ова би било алијас со истовремен пристап до бројот на референци (на пр.
        // од `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Определете дали ова е единствена референца (вклучително и слаби рефлекти) на основните податоци.
    ///
    ///
    /// Забележете дека ова бара заклучување на слабото пребројување.
    fn is_unique(&mut self) -> bool {
        // заклучете го слабиот број на покажувачи ако се чини дека сме единствениот слаб држач на покажувачот.
        //
        // Ознаката за стекнување тука осигурува врска пред сè со какво било пишување на `strong` (особено во `Weak::upgrade`) пред намалувањето на бројот на `weak` (преку `Weak::drop`, кој користи ослободување).
        // Ако ажурираниот слаб рефлекс никогаш не падне, CAS овде ќе пропадне, затоа не се грижиме да синхронизираме.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ова треба да биде `Acquire` за да се синхронизира со намалувањето на бројачот `strong` во `drop`-единствениот пристап што се случува кога се отфрла која било, но последната референца.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ослободеното пишување овде се синхронизира со читање во `downgrade`, ефикасно спречувајќи го погоре читањето на `strong` да се случи по запишувањето.
            //
            //
            self.inner().weak.store(1, Release); // ослободете ја бравата
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Паѓа `Arc`.
    ///
    /// Ова ќе го намали силниот референтен број.
    /// Ако силното референтно броење достигне нула, тогаш единствените други референци (доколку ги има) се [`Weak`], затоа ние ја означуваме `drop` внатрешната вредност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Не печати ништо
    /// drop(foo2);   // Печати "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Бидејќи `fetch_sub` е веќе атомски, не треба да синхронизираме со други нишки освен ако не го бришеме објектот.
        // Оваа иста логика се однесува на подолу `fetch_sub` до бројот на `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Оваа ограда е потребна за да се спречи прераспоредување на употребата на податоците и бришење на податоците.
        // Бидејќи е обележано `Release`, намалувањето на референтниот број се синхронизира со оваа ограда `Acquire`.
        // Ова значи дека употребата на податоците се случува пред да се намали референтниот број, што се случува пред оваа ограда, што се случува пред бришењето на податоците.
        //
        // Како што е објаснето во [Boost documentation][1],
        //
        // > Важно е да се спроведе секој можен пристап до објектот во едно
        // > нишка (преку постоечка референца) да се случи *пред* бришење
        // > објектот во друга нишка.Ова се постигнува со "release"
        // > операција по испуштање на референца (каков било пристап до објектот
        // > преку оваа референца очигледно мора да се случило претходно), и ан
        // > "acquire" операција пред бришење на објектот.
        //
        // Особено, додека содржината на лакот е обично непроменлива, можно е да имате внатрешни записи за нешто како Мутекс<T>.
        // Бидејќи Mutex не се стекнува кога ќе се избрише, не можеме да се потпреме на неговата логика за синхронизација за да направиме записи во нишката А видливи за уништувачот што работи во низата Б.
        //
        //
        // Исто така, забележете дека Оградата за стекнување овде веројатно би можела да се замени со оптоварување на стекнување, што може да ги подобри перформансите во многу спорни ситуации.Погледнете [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Обид да се симне `Arc<dyn Any + Send + Sync>` на бетонски тип.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Конструира нов `Weak<T>`, без да додели меморија.
    /// Повикувањето на [`upgrade`] на повратната вредност секогаш дава [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Тип на помошник за да дозволите пристап до бројот на референци без да давате никакви тврдења за полето за податоци.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Враќа суров покажувач на објектот `T` посочен од овој `Weak<T>`.
    ///
    /// Покажувачот е валиден само ако има некои силни препораки.
    /// Покажувачот може да биде обесен, ненаместен или дури [`null`] на друг начин.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // И двајцата покажуваат на истиот објект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Силниот овде го одржува во живот, така што сè уште можеме да пристапиме до објектот.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Но, не повеќе.
    /// // Можеме да направиме weak.as_ptr(), но пристапот до покажувачот ќе доведе до недефинирано однесување.
    /// // assert_eq! ("здраво", небезбеден {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ако покажувачот виси, ние го враќаме чуварот директно.
            // Ова не може да биде валидна адреса за носивост, бидејќи носивоста е барем порамнета како ArcInner (usize).
            ptr as *const T
        } else {
            // БЕЗБЕДНОСТ: ако is_dangling враќа неточно, тогаш покажувачот може да се референцира.
            // Товарот може да се намали во овој момент, и ние мора да ја задржиме потеклото, затоа користете сурови манипулации со покажувачот.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Го троши `Weak<T>` и го претвора во суров покажувач.
    ///
    /// Ова го претвора слабиот покажувач во суров покажувач, додека сеуште се зачувува сопственоста на една слаба референца (слабиот број не е изменет со оваа операција).
    /// Може да се претвори во `Weak<T>` со [`from_raw`].
    ///
    /// Се применуваат истите ограничувања за пристап до целта на покажувачот како и со [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Конвертира суров покажувач претходно создаден од [`into_raw`] назад во `Weak<T>`.
    ///
    /// Ова може да се користи за безбедно добивање на силна референца (повикување на [`upgrade`] подоцна) или за распределување на слабиот број со паѓање на `Weak<T>`.
    ///
    /// Потребна е сопственост на една слаба референца (со исклучок на покажувачите создадени од [`new`], бидејќи тие не поседуваат ништо; методот сè уште работи на нив).
    ///
    /// # Safety
    ///
    /// Покажувачот сигурно потекнува од [`into_raw`] и сè уште мора да ја поседува својата потенцијална слаба референца.
    ///
    /// Дозволено е силното броење да биде 0 за време на повикувањето на ова.
    /// Како и да е, ова презема сопственост на една слаба референца што во моментов е претставена како суров покажувач (слабото броење не е изменето со оваа операција) и затоа мора да биде поврзано со претходниот повик до [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Одлучи го последното слабо броење.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Погледнете Weak::as_ptr за контекст за тоа како е изведен влезниот покажувач.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ова е зависен слаб.
            ptr as *mut ArcInner<T>
        } else {
            // Во спротивно, гарантирано ни е дека покажувачот потекнува од слаб слаб.
            // БЕЗБЕДНОСТ: data_offset е безбеден за повик, бидејќи ptr упатува на реално (потенцијално испуштено) Т.
            let offset = unsafe { data_offset(ptr) };
            // Така, го свртуваме надоместот за да го добиеме целиот RcBox.
            // БЕЗБЕДНОСТ: покажувачот потекнува од Слаб, така што ова поместување е безбедно.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗБЕДНОСТ: сега го вративме оригиналниот слаб покажувач, па затоа можеме да го создадеме слабиот.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Обиди за ажурирање на покажувачот `Weak` на [`Arc`], со одложување на паѓањето на внатрешната вредност ако е успешно.
    ///
    ///
    /// Враќа [`None`] ако оттогаш е исфрлена внатрешната вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Уништи ги сите силни покажувачи.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ние користиме CAS-јамка за да го зголемиме силното пребројување наместо fetch_add бидејќи оваа функција никогаш не треба да го зема референтниот број од нула на една.
        //
        //
        let inner = self.inner()?;

        // Опуштено оптоварување затоа што секое запишување на 0 што можеме да го наб leavesудуваме го напушта полето во трајно нула состојба (така што читањето на "stale" од 0 е во ред), и секоја друга вредност е потврдена преку CAS подолу.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Погледнете ги коментарите во `Arc::clone` зошто го правиме ова (за `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Опуштено е добро за случајот со неуспехот затоа што немаме никакви очекувања за новата држава.
            // Стекнување е потребно за случајот на успех да се синхронизира со `Arc::new_cyclic`, кога внатрешната вредност може да се иницијализира откако веќе се создадени референци за `Weak`.
            // Во тој случај, очекуваме да ја набудуваме целосно почетната вредност.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // нула е проверено погоре
                Err(old) => n = old,
            }
        }
    }

    /// Добива број на силни покажувачи (`Arc`) што укажуваат на оваа распределба.
    ///
    /// Ако `self` е создаден со употреба на [`Weak::new`], ова ќе врати 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Добива апроксимација на бројот на покажувачи `Weak` што укажуваат на оваа распределба.
    ///
    /// Ако `self` е создаден со употреба на [`Weak::new`], или ако нема останати силни покажувачи, ова ќе врати 0.
    ///
    /// # Accuracy
    ///
    /// Поради деталите за имплементација, вратената вредност може да биде исклучена за 1 во која било насока кога другите нишки манипулираат со која било `Arc` или `Weak` `укажувајќи на истата распределба.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Бидејќи забележавме дека има барем еден силен покажувач откако го прочитавме слабиот број, знаеме дека имплицитната слаба референца (присутна кога и да се живи силни референци) сè уште беше околу кога го забележавме слабиот број и затоа можеме безбедно да го одземеме.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Враќа `None` кога покажувачот виси и нема распределен `ArcInner`, (т.е. кога овој `Weak` е создаден од `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Внимаваме * да не создадеме референца што го покрива полето "data", бидејќи полето може да биде мутирано истовремено (на пример, ако се исфрли последниот `Arc`, полето за податоци ќе се испушти на место).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Враќа `true` ако двата `Слаба точка укажуваат на иста распределба (слично на [`ptr::eq`]), или ако и двајцата не укажуваат на каква било распределба (бидејќи тие се создадени со `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Бидејќи ова ги споредува покажувачите, тоа значи дека `Weak::new()` ќе се изедначат едни со други, иако тие не укажуваат на каква било распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Споредување на `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Прави клон на покажувачот `Weak` што укажува на истата распределба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Погледнете ги коментарите во Arc::clone() зошто ова е опуштено.
        // Ова може да користи fetch_add (игнорирање на заклучувањето) затоа што слабиот број е заклучен само таму каде што нема *други* слаби покажувачи.
        //
        // (Значи, не можеме да го водиме овој код во тој случај).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Погледнете ги коментарите во Arc::clone() зошто го правиме ова (за mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструира нов `Weak<T>`, без да доделува меморија.
    /// Повикувањето на [`upgrade`] на повратната вредност секогаш дава [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Го испушта покажувачот `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Не печати ништо
    /// drop(foo);        // Печати "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ако дознаеме дека сме последниот слаб покажувач, тогаш е време целосно да ги деалоцираме податоците.Погледнете ја дискусијата во Arc::drop() за редоследот на меморијата
        //
        // Не е потребно да се провери заклучената состојба овде, бидејќи слабото броење може да се заклучи само ако има точно еден слаб реф., Што значи дека падот може последователно да се активира на тој преостанат слаб реф, што може да се случи само откако ќе се ослободи заклучувањето.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ние ја правиме оваа специјализација овде, а не како општа оптимизација на `&T`, бидејќи во спротивно ќе додадете трошок за сите проверки на еднаквоста на рефлексиите.
/// Претпоставуваме дека `Arc` s се користат за складирање на големи вредности, бавни за клонирање, но исто така тешки за проверка на еднаквоста, предизвикувајќи овој трошок полесно да се исплати.
///
/// Исто така, поверојатно е да има два клона `Arc`, кои укажуваат на иста вредност, отколку два `&Т`.
///
/// Можеме да го направиме ова само кога `T: Eq` како `PartialEq` може да биде намерно нерефлексивен.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Еднаквост за двајца ``Arc``.
    ///
    /// Две `лак е еднакви ако нивните внатрешни вредности се еднакви, дури и ако се зачувани во различна распределба.
    ///
    /// Ако `T` исто така го спроведува `Eq` (што подразбира рефлексивност на еднаквоста), два `Аркови кои укажуваат на иста распределба се секогаш еднакви.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Нееднаквост за двајца `Arc` s.
    ///
    /// Две `лак не се еднакви ако нивните внатрешни вредности се нееднакви.
    ///
    /// Ако `T` исто така спроведува `Eq` (имплицирајќи ја рефлексивноста на еднаквоста), два `Аркови кои укажуваат на иста вредност никогаш не се нееднакви.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Делумна споредба за две `Arc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `partial_cmp()` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Помалку споредба за две `Arc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `<` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Споредба " помалку од или еднаква на`за две`лак`.
    ///
    /// Двајцата се споредуваат повикувајќи се на `<=` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Поголема од споредбата за две `Arc` s.
    ///
    /// Двајцата се споредуваат повикувајќи се на `>` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// " Поголема од или еднаква на`споредбата за две`Arc`.
    ///
    /// Двајцата се споредуваат повикувајќи се на `>=` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Споредба за две `Арка.
    ///
    /// Двајцата се споредуваат повикувајќи се на `cmp()` за нивните внатрешни вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Создава нов `Arc<T>`, со вредноста `Default` за `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Доделете парче преброено со референци и пополнете го со клонирање на ставките `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Доделете `str` сметано со референци и копирајте `v` во него.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Доделете `str` сметано со референци и копирајте `v` во него.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Преместете го кутииот објект на нова распределба преброена со референци.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Доделете парче преброено со референци и преместете ги ставките на `v` во неа.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Дозволете му на Вец да ја ослободи својата меморија, но не и да ја уништува неговата содржина
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Го зема секој елемент во `Iterator` и го собира во `Arc<[T]>`.
    ///
    /// # Карактеристики на изведбата
    ///
    /// ## Општ случај
    ///
    /// Во општ случај, собирањето во `Arc<[T]>` се врши со прво собирање во `Vec<T>`.Тоа е, кога го пишувате следново:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ова се однесува како да сме напишале:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Првиот сет на алокации се случува тука.
    ///     .into(); // Втора алокација за `Arc<[T]>` се случува овде.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ова ќе одвои онолку пати колку што е потребно за конструирање на `Vec<T>` и потоа ќе се распредели еднаш за претворање на `Vec<T>` во `Arc<[T]>`.
    ///
    ///
    /// ## Итератори со позната должина
    ///
    /// Кога вашиот `Iterator` го спроведува `TrustedLen` и е со точна големина, ќе се изврши единечна распределба за `Arc<[T]>`.На пример:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Само една алокација се случува тука.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Специјализација trait што се користи за собирање во `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ова е случај со повторувач `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗБЕДНОСТ: Треба да осигураме дека повторувачот има точна должина и ние.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Врати се на нормалното спроведување.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Земете го офсет во рамките на `ArcInner` за носивоста зад покажувачот.
///
/// # Safety
///
/// Покажувачот мора да покаже (и да има валидни метаподатоци за) претходно валидна инстанца на Т, но Т е дозволено да се испушти.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Порамнете ја големината без големина до крајот на ArcInner.
    // Бидејќи RcBox е repr(C), тој секогаш ќе биде последното поле во меморијата.
    // БЕЗБЕДНОСТ: бидејќи единствените можни типови со големина се парчиња, trait објекти,
    // и надворешни типови, условот за безбедност на влезот во моментов е доволен за да ги задоволи барањата на align_of_val_raw;ова е детал за имплементација на јазикот на кој не може да се потпреме надвор од std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}