#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Содржината на новата меморија е неинцијализирана.
    Uninitialized,
    /// Новата меморија се гарантира дека ќе биде нула.
    Zeroed,
}

/// Алатка за ниско ниво за поергономско распределување, прераспределување и распределување на тампон на меморија на грамадата, без да се грижите за сите аголни случаи.
///
/// Овој тип е одличен за градење на сопствени структури на податоци како што се Vec и VecDeque.
/// Особено:
///
/// * Произведува `Unique::dangling()` на типови со нула големина.
/// * Произведува `Unique::dangling()` на алокации со нула должина.
/// * Избегнува ослободување на `Unique::dangling()`.
/// * Ги собира сите прелевања во пресметките на капацитетот (ги промовира во "capacity overflow" panics).
/// * Чувари против 32-битни системи кои одвојуваат повеќе од isize::MAX бајти.
/// * Чувари против преполнување на вашата должина.
/// * Повикува `handle_alloc_error` за грешни алокации.
/// * Содржи `ptr::Unique` и на тој начин му дава на корисникот сите поврзани придобивки.
/// * Го користи вишокот вратен од алокаторот за да го искористи најголемиот достапен капацитет.
///
/// Овој тип во никој случај не ја проверува меморијата со која управува.Кога ќе падне,*ќе ја ослободи нејзината меморија, но* нема * да се обиде да ја испушти нејзината содржина.
/// На корисникот на `RawVec` останува да ракува со вистинските работи *складирани* во внатрешноста на `RawVec`.
///
/// Забележете дека вишокот на типови со нула големина е секогаш бесконечен, така што `capacity()` секогаш враќа `usize::MAX`.
/// Ова значи дека треба да бидете претпазливи кога со ваков вид `Box<[T]>` се обидувате да заокружите, бидејќи `capacity()` нема да ја даде должината.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ова постои затоа што `#[unstable]` `const fn` s не треба да одговара на `min_const_fn` и затоа тие не можат да бидат повикани ниту на `min_const_fn`.
    ///
    /// Доколку промените `RawVec<T>::new` или зависности, внимавајте да не воведете ништо што навистина би го нарушило `min_const_fn`.
    ///
    /// NOTE: Можеме да ја избегнеме оваа упад и да ја провериме сообразноста со некои атрибути `#[rustc_force_min_const_fn]`, за кои е потребна усогласеност со `min_const_fn`, но не мора да дозволуваме повикување во `stable(...) const fn`/кориснички код што не овозможува `foo` кога е присутен `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Создава најголем можен `RawVec` (на системската граница) без распределување.
    /// Ако `T` има позитивна големина, тогаш ова прави `RawVec` со капацитет `0`.
    /// Ако `T` е со нула големина, тогаш се прави `RawVec` со капацитет `usize::MAX`.
    /// Корисно за спроведување на одложена распределба.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Создава `RawVec` (на системската граница) со точно капацитет и барања за усогласување за `[T; capacity]`.
    /// Ова е еквивалентно на повикување на `RawVec::new` кога `capacity` е `0` или `T` е со нула големина.
    /// Забележете дека ако `T` е со нула големина, тоа значи дека *нема* да добиете `RawVec` со бараниот капацитет.
    ///
    /// # Panics
    ///
    /// Panics ако бараниот капацитет надминува `isize::MAX` бајти.
    ///
    /// # Aborts
    ///
    /// Прекинува на ООМ.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Како `with_capacity`, но гарантира дека тампонот е нула.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Реконституира `RawVec` од покажувачот и капацитетот.
    ///
    /// # Safety
    ///
    /// `ptr` мора да се распредели (на системската граница) и со дадениот `capacity`.
    /// `capacity` не може да надминува `isize::MAX` за типови со големина.(само грижа за 32-битните системи).
    /// ZST vectors може да има капацитет до `usize::MAX`.
    /// Ако `ptr` и `capacity` доаѓаат од `RawVec`, тогаш ова е загарантирано.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Ситните Веци се неми.Прескокни на:
    // - 8 ако големината на елементот е 1, бидејќи секој алокатор на купишта веројатно ќе заокружи барање помало од 8 бајти на најмалку 8 бајти.
    //
    // - 4 ако елементите се со умерена големина (<=1 KiB).
    // - 1 во спротивно, за да се избегне губење премногу простор за многу кратки Веци.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Како `new`, но парамеризирано над изборот на распределувач за вратениот `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` значи "unallocated".типовите со нула големина се игнорираат.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Како `with_capacity`, но парамеризирано над изборот на распределувач за вратениот `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Како `with_capacity_zeroed`, но парамеризирано над изборот на распределувач за вратениот `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Конвертира `Box<[T]>` во `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Го претвора целиот тампон во `Box<[MaybeUninit<T>]>` со наведениот `len`.
    ///
    /// Забележете дека ова правилно ќе ги реконструира сите промени `cap` што може да се извршат.(Погледнете го описот на видот за детали.)
    ///
    /// # Safety
    ///
    /// * `len` мора да биде поголем или еднаков на неодамна бараниот капацитет и
    /// * `len` мора да биде помал или еднаков на `self.capacity()`.
    ///
    /// Имајте на ум дека бараниот капацитет и `self.capacity()` може да се разликуваат, бидејќи распределувачот може да распореди и да врати поголем мемориски блок отколку што е побарано.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Размислете за проверка на една половина од условите за безбедност (не можеме да ја провериме другата половина).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ние избегнуваме `unwrap_or_else` овде затоа што тој ја надувува количината на генерирана IR LLVM.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Реконструира `RawVec` од покажувачот, капацитетот и алокаторот.
    ///
    /// # Safety
    ///
    /// `ptr` мора да се распредели (преку дадениот алокатор `alloc`) и со дадениот `capacity`.
    /// `capacity` не може да надминува `isize::MAX` за типови со големина.
    /// (само грижа за 32-битните системи).
    /// ZST vectors може да има капацитет до `usize::MAX`.
    /// Ако `ptr` и `capacity` доаѓаат од `RawVec` создадени преку `alloc`, тогаш ова е загарантирано.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Добива суров покажувач до почетокот на распределбата.
    /// Забележете дека ова е `Unique::dangling()` ако `capacity == 0` или `T` е со нула големина.
    /// Во првиот случај, мора да бидете внимателни.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Го добива капацитетот на распределбата.
    ///
    /// Ова секогаш ќе биде `usize::MAX` ако `T` е со нула големина.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Враќа споделена референца на распределувачот што го поддржува овој `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Имаме доделено парче меморија, за да можеме да ги заобиколиме проверките за време на траење за да го добиеме нашиот тековен распоред.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Осигурува дека тампонот содржи барем доволно простор за да собере `len + additional` елементи.
    /// Доколку веќе нема доволно капацитет, пренаменете доволно простор плус удобен простор за опуштеност за да добиете амортизирано однесување *O*(1).
    ///
    /// Limitе го ограничи ова однесување ако непотребно би се предизвикало на panic.
    ///
    /// Ако `len` го надмине `self.capacity()`, ова може да не успее да го распредели бараниот простор.
    /// Ова не е навистина небезбедно, но небезбедниот код *што го пишувате* и се потпира на однесувањето на оваа функција може да се расипе.
    ///
    /// Ова е идеално за спроведување на операција со голем притисок како `extend`.
    ///
    /// # Panics
    ///
    /// Panics ако новиот капацитет надминува `isize::MAX` бајти.
    ///
    /// # Aborts
    ///
    /// Прекинува на ООМ.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // резервата ќе се прекинеше или испаничеше ако ленот надмине `isize::MAX`, така што ова е безбедно да се направи сега неконтролирано.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Истото како `reserve`, но враќа на грешките наместо да паничи или да абортира.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Осигурува дека тампонот содржи барем доволно простор за да собере `len + additional` елементи.
    /// Ако веќе не, ќе ја распределите минималната можна количина на меморија што е неопходна.
    /// Општо, ова ќе биде точно количината на неопходна меморија, но во принцип алокаторот може слободно да врати повеќе отколку што баравме.
    ///
    ///
    /// Ако `len` го надмине `self.capacity()`, ова може да не успее да го распредели бараниот простор.
    /// Ова не е навистина небезбедно, но небезбедниот код *што го пишувате* и се потпира на однесувањето на оваа функција може да се расипе.
    ///
    /// # Panics
    ///
    /// Panics ако новиот капацитет надминува `isize::MAX` бајти.
    ///
    /// # Aborts
    ///
    /// Прекинува на ООМ.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Истото како `reserve_exact`, но враќа на грешките наместо да паничи или да абортира.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ја намалува распределбата до одредената сума.
    /// Ако дадената сума е 0, всушност целосно деалоцира.
    ///
    /// # Panics
    ///
    /// Panics ако дадената количина е *поголема* од сегашниот капацитет.
    ///
    /// # Aborts
    ///
    /// Прекинува на ООМ.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Враќа ако треба да расте тампонот за да се исполни потребниот дополнителен капацитет.
    /// Главно се користи за да се направат можни резолуции за резерви без да се обележат `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Овој метод обично се инстанцира многу пати.Значи, сакаме да биде што е можно помало, за да ги подобриме времињата на компајлирање.
    // Но, ние исто така сакаме што е можно повеќе од нејзините содржини да бидат статички пресметливи, за да се создаде генерираниот код побрзо.
    // Затоа, овој метод е внимателно напишан така што целиот код што зависи од `T` е во него, додека што е можно повеќе од кодот што не зависи од `T` во функциите што не се генерички над `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ова е обезбедено од контекстите за повикување.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Бидејќи враќаме капацитет од `usize::MAX` кога е `elem_size`
            // 0, доаѓањето до тука значи дека `RawVec` е преполн.
            return Err(CapacityOverflow);
        }

        // За жал, ништо не можеме навистина да сториме за овие проверки.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ова гарантира експоненцијален раст.
        // Удвојувањето не може да се прелее затоа што `cap <= isize::MAX` и типот на `cap` е `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не е генерички над `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ограничувањата на овој метод се многу исти со оние на `grow_amortized`, но овој метод обично се инстанцира поретко, па затоа е помалку критичен.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Бидејќи враќаме капацитет од `usize::MAX` кога големината на типот е
            // 0, доаѓањето до тука значи дека `RawVec` е преполн.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не е генерички над `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Оваа функција е надвор од `RawVec` за да се минимизираат времињата на компајлирање.Погледнете го коментарот погоре `RawVec::grow_amortized` за детали.
// (Параметарот `A` не е значаен, бидејќи бројот на различни типови `A` што се гледа во пракса е многу помал од бројот на типови `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Проверете ја грешката тука за да ја минимизирате големината на `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Алокаторот ја проверува рамноправноста на усогласувањето
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ја ослободува меморијата во сопственост на `RawVec`*без* да се обиде да ја испушти нејзината содржина.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Централна функција за ракување со резервни грешки.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Треба да го гарантираме следново:
// * Ние никогаш не доделуваме објекти со големина на бајт `> isize::MAX`.
// * Ние не преплавуваме `usize::MAX` и всушност распределуваме премалку.
//
// На 64-битни само треба да провериме дали има прелевање, бидејќи обидот да се распределат `> isize::MAX` бајти сигурно ќе пропадне.
// На 32-битни и 16-битни треба да додадеме дополнителна заштита за ова во случај да работиме на платформа што може да ги користи сите 4 GB во кориснички простор, на пример, PAE или x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Една централна функција одговорна за известување за прелевање на капацитетот.
// Ова ќе осигури дека генерирањето кодови поврзани со овие panics е минимално бидејќи има само една локација која panics наместо еден куп низ целиот модул.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}