//! Одмотување panics за Мири.
use alloc::boxed::Box;
use core::any::Any;

// Вид на носивост што го шири моторот Мири преку одмотување за нас.
// Мора да биде со големина на покажувачот.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Функција за надворешни работи обезбедени од Мири за да започнете да се одмотувате.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Товарот што го пренесуваме на `miri_start_panic` ќе биде токму аргументот што го добиваме во `cleanup` подолу.
    // Едноставно, го собереме еднаш, за да добиеме нешто со големина на покажувачот.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Вратете го основниот `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}