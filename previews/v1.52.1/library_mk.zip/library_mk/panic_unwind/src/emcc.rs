//! Се одмотува за целта *emscripten*.
//!
//! Со оглед на тоа што вообичаената имплементација на Rust за платформите Unix директно се повикува на API-а на libunwind, на Emscripten ние ги повикуваме API-а за одмотување на C++ .
//! Ова е само целесообразност бидејќи работното време на Emscripten секогаш ги спроведува тие API и не го спроведува libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Ова одговара на изгледот на std::type_info во C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Водечкиот бајт `\x01` овде е всушност магичен сигнал до LLVM да *не* примени какво било друго манџирање, како префиксирање со карактер `_`.
    //
    //
    // Овој симбол е изборна маса што ја користат `std::type_info` на C++ .
    // Објектите од типот `std::type_info`, дескрипторите на типовите, имаат покажувач кон оваа табела.
    // Опис на типовите се повикуваат од структурите C++ EH дефинирани погоре и што ги конструираме подолу.
    //
    // Имајте на ум дека вистинската големина е поголема од 3 употребени, но потребна ни е само нашата табела да покажеме на третиот елемент.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info за класа на 'рѓа_паника
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Нормално, би користеле .as_ptr().add(2), но ова не работи во контекст на конституирање.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Ова намерно не ја користи нормалната шема за мангализирање на името затоа што не сакаме C++ да може да произведува или фаќа Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Ова е потребно затоа што кодот C++ може да ја фати нашата извршување со std::exception_ptr и повторно да го фрли повеќе пати, можеби дури и во друга нишка.
    //
    //
    caught: AtomicBool,

    // Ова треба да биде опција бидејќи животниот век на објектот ја следи C++ семантиката: кога catch_unwind го поместува полето од исклучок, тој сè уште мора да го остави објектот за исклучок во валидна состојба бидејќи неговиот уништувач сè уште ќе биде повикан од __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try всушност ни дава покажувач на оваа структура.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Бидејќи cleanup() не е дозволен за panic, ние само прекинуваме наместо тоа.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}