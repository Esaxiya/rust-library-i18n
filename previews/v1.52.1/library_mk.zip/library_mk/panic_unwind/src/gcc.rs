//! Имплементација на panics поддржана од libgcc/libunwind (во некоја форма).
//!
//! За позадина за ракување со исклучоци и одвиткување на магацинот, видете "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) и документите поврзани со него.
//! Овие се исто така добри читања:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Кратко резиме
//!
//! Ракувањето со исклучоци се случува во две фази: фаза на пребарување и фаза на расчистување.
//!
//! Во обете фази, одвиткајте ги рамките на магацинот од горе надолу со користење на информации од магацинот, одмотувајте делови од модулите на тековниот процес ("module" овде се однесува на модул за ОС, т.е. извршна или динамична библиотека).
//!
//!
//! За секоја рамка на оџакот, тој се повикува на поврзаниот "personality routine", чија адреса е исто така зачувана во делот за одмотување информации.
//!
//! Во фазата на пребарување, работата на рутината на личноста е да испита фрлен предмет на исклучок и да одлучи дали треба да се фати во таа рамка на оџакот.Откако ќе се идентификува рамката на управувачот, започнува фазата на чистење.
//!
//! Во фазата на чистење, разоткривањето повторно се повикува на секоја рутина на личноста.
//! Овој пат одлучува кој (ако го има) кодот за чистење треба да се изврши за тековната рамка на оџакот.Ако е така, контролата се пренесува на специјалниот branch во функциското тело, "landing pad", кој се повикува на деструкторите, ослободува меморија итн.
//! На крајот од подлогата за слетување, контролата се пренесува назад во продолжувањата за одмотување и одмотување.
//!
//! Откако магацинот ќе се одмота до нивото на рамката на управувачот, одвиткување застанува и последната рутина на личноста ја пренесува контролата во блокот за фаќање.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Идентификатор на класа на исклучоци на Rust.
// Ова се користи во рутините на личноста за да се утврди дали исклучокот е исфрлен од нивното сопствено траење.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // МОЗ\0 РУСТ-продавач, јазик
    0x4d4f5a_00_52555354
}

// Идеите за регистрирање беа подигнати од L0000 и TargetLowering::getExceptionSelectorRegister() на LLVM за секоја архитектура, а потоа беа мапирани до броевите на регистарот DWARF преку табели за дефинирање на регистри<arch>RegisterInfo.td, побарајте "DwarfRegNum").
//
// Видете исто така http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Следниот код е заснован на рутини на личноста на GCC и Ц ++.За повикување, видете:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Рутина на личноста ЕХАБИ.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS наместо тоа ја користи стандардната рутина бидејќи користи SjLj одмотување.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Вратите на АРМ ќе ја нарекуваат рутината на личноста со состојба==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Во тие случаи, ние сакаме да продолжиме да ја одмотуваме магацинот, инаку сите наши повратни активности ќе завршеа на __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF одмотува претпоставува дека _Unwind_Context има работи како што се функцијата и LSDA покажувачите, сепак ARM EHABI ги става во предмет на исклучок.
            // За да се зачуваат потписите на функции како _Unwind_GetLanguageSpecificData(), кои го земаат само контекстниот покажувач, рутините за личност GCC ставаат покажувач до исклучок_објект во контекстот, користејќи ја локацијата резервирана за "scratch register" (r12) на ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Попринципиелен пристап ќе биде да се обезбеди целосна дефиниција на контекстот на АРМ _Одвиткај_Во нашите врски во libunwind и да ги преземеме потребните податоци од таму директно, заобиколувајќи ги функциите за компатибилност на DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI бара рутина на личноста за ажурирање на SP вредноста во бариерата на бариерата на објектот со исклучок.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // На АРМ ЕХАБИ, рутината на личноста е одговорна за одвиткување на една рамка за оџак пред да се врати (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // дефинирани во libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Стандардна рутина за личност, која се користи директно на повеќето цели и индиректно на Windows x86_64 преку СЕХ.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // На целите x86_64 MinGW, механизмот за одмотување е SEH, сепак податоците за ракувачот за одмотување (ака LSDA) користат кодирање компатибилно со GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Рутина на личноста за повеќето од нашите цели.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Адресата за враќање укажува на 1 бајт покрај инструкциите за повик, што може да биде во следниот опсег на IP во табелата со опсег LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Рамката одмотајте ја регистрацијата на информации
//
// Сликата на секој модул содржи дел за одмотување информации за рамка (обично ".eh_frame").Кога модулот е loaded/unloaded во процесот, разоткривачот мора да биде информиран за локацијата на овој дел во меморијата.Методите за постигнување се разликуваат во зависност од платформата.
// Кај некои (на пример, Linux), развивачот може самостојно да открие оддели за одмотување информации (динамички набројувајќи ги моментално вчитаните модули преку dl_iterate_phdr() API and finding their ".eh_frame" sections); други, како Windows, бараат модули за активно да ги регистрираат своите оддели за одмотување информации преку одвиткан API.
//
//
// Овој модул дефинира два симболи на кои се повикуваат и повикуваат rsbegin.rs за да ги регистрираат нашите информации со траење на GCC.
// Спроведувањето на магацинот за одмотување (засега) е одложено на libgcc_eh, сепак Rust crates ги користат овие влезни точки специфични за Rust за да избегнат потенцијални судири со какво било траење на GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}