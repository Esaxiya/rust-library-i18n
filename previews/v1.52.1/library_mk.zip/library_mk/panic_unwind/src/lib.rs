//! Имплементација на panics преку магацинско одвиткување
//!
//! Овој crate е имплементација на panics во Rust со користење на механизам за разоткривање магацинот "most native" на платформата за која се составува.
//! Ова во суштина се категоризира во три кофи во моментов:
//!
//! 1. Целите на MSVC користат SEH во датотеката `seh.rs`.
//! 2. Emscripten користи исклучоци од C++ во датотеката `emcc.rs`.
//! 3. Сите други цели користат libunwind/libgcc во датотеката `gcc.rs`.
//!
//! Повеќе документација за секоја имплементација може да се најде во соодветниот модул.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` е неискористена со Мири, затоа предупредувања за тишина.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Стартните објекти на траење на Rust зависат од овие симболи, затоа направете ги јавно.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Цели што не поддржуваат одмотување.
        // - arch=wasm32
        // - os=никој (цели "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Користете го времето за траење на Мири.
        // Ние сè уште треба да го вчитаме и нормалното време на траење погоре, бидејќи rustc очекува да бидат дефинирани одредени ставки од таму.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Користете го вистинското време на траење.
        use real_imp as imp;
    }
}

extern "C" {
    /// Управувачот во libstd повика кога panic објект се исфрла надвор од `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Управувачот во libstd повика кога ќе се фати странски исклучок.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Влезна точка за подигање на исклучок, само делегира на имплементација специфична за платформата.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}