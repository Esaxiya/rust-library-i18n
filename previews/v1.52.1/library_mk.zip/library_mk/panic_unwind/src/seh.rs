//! Windows SEH
//!
//! На Windows (моментално само на MSVC), стандардниот механизам за ракување со исклучоци е Структуриран исклучок Ракување (SEH).
//! Ова е доста различно од управувањето со исклучоци засновано на џуџе (на пример, она што другите платформи unix го користат) во однос на внатрешните компајлери, па затоа од LLVM се бара да имаат дополнителна поддршка за SEH.
//!
//! Накратко, она што се случува тука е:
//!
//! 1. Функцијата `panic` ја повикува стандардната функција Windows `_CxxThrowException` да фрли C++ -како исклучок, предизвикувајќи процес на одвиткување.
//! 2.
//! Сите влошки за слетување генерирани од компајлерот ја користат функцијата на личност `__CxxFrameHandler3`, функција во CRT, а кодот за одвивање во Windows ќе ја користи оваа функција на личност за да го изврши целиот код за чистење на магацинот.
//!
//! 3. Сите повици генерирани од компајлерот до `invoke` имаат рамка за слетување поставена како инструкција `cleanuppad` LLVM, што укажува на почеток на рутината за чистење.
//! Личноста (во чекор 2, дефинирана во CRT) е одговорна за водење на рутините за чистење.
//! 4. На крајот, кодот "catch" во `try` својството (генериран од компајлерот) е извршен и означува дека контролата треба да се врати во Rust.
//! Ова е направено преку `catchswitch` плус `catchpad` инструкција во смисла на LLVM IR, конечно враќајќи ја нормалната контрола во програмата со инструкција `catchret`.
//!
//! Некои специфични разлики од ракувањето со исклучоци базирани на gcc се:
//!
//! * Rust нема сопствена функција на личност, таа е *секогаш*`__CxxFrameHandler3`.Дополнително, не се врши дополнително филтрирање, па на крајот ќе фатиме какви било исклучоци од С ++ што се случува да изгледаат како оние што ги фрламе.
//! Имајте на ум дека фрлањето исклучок во Rust е недефинирано однесување во секој случај, па затоа треба да биде добро.
//! * Имаме некои податоци за пренесување преку одвиткуваната граница, поточно `Box<dyn Any + Send>`.Како и со исклучоците од warуџето, овие два покажувачи се чуваат како носивост во самиот исклучок.
//! Меѓутоа, на MSVC нема потреба од дополнителна распределба на грамада затоа што магацинот на повик е зачуван додека се извршуваат функциите на филтерот.
//! Ова значи дека покажувачите се пренесуваат директно на `_CxxThrowException` кои потоа се обновуваат во функцијата на филтерот за да бидат запишани во рамката на оџакот на `try` својствениот.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ова треба да биде опција бидејќи ние го фаќаме исклучокот со упатување и неговиот деструктор се извршува со времетраењето на C++ .
    // Кога ќе го извадиме Кутието од исклучок, треба да го оставиме исклучокот во валидна состојба за неговиот деструктор да работи без двојно испуштање на Кутијата.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Прво, цел куп дефиниции за типови.Има неколку необичности специфични за платформата, и многу што само бесрамно се копираат од LLVM.Целта на сето ова е да се спроведе функцијата `panic` подолу преку повик до `_CxxThrowException`.
//
// Оваа функција трае два аргументи.Првиот е покажувач на податоците што ги пренесуваме, што во овој случај е наш објект trait.Прилично лесно да се најде!Следното, сепак, е посложено.
// Ова е покажувач кон структурата `_ThrowInfo` и обично има за цел само да го опише фрлениот исклучок.
//
// Во моментов, дефиницијата за овој тип [1] е малку влакнеста, а главната необичност (и разликата од написот на Интернет) е што на 32-битни покажувачи се покажувачи, но на 64-битни покажувачи се изразени како 32-битни преноси од Симбол `__ImageBase`.
//
// За изразување на ова се користат макроата `ptr_t` и `ptr!` во модулите подолу.
//
// Лавиринтот на дефинициите за типот, исто така, внимателно следи што емитува LLVM за ваква операција.На пример, ако го компајлирате овој код C++ на MSVC и го емитувате IRL LLVM:
//
//      #include <stdint.h>
//
//      структура на 'рѓа_паника {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      неважечки foo() { rust_panic a = {0, 1};
//          фрли а;}
//
// Во суштина тоа е она што се обидуваме да го имитираме.Повеќето од постојаните вредности подолу беа само копирани од LLVM,
//
// Во секој случај, сите овие структури се конструирани на сличен начин, и тоа е само малку гласно за нас.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Имајте на ум дека ние намерно ги игнорираме правилата за манџирање на имињата тука: не сакаме C++ да може да го фати Rust panics со едноставно прогласување `struct rust_panic`.
//
//
// Кога менувате, проверете дали низата за името на типот точно одговара на онаа што се користи во `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Водечкиот бајт `\x01` овде е всушност магичен сигнал до LLVM да *не* примени какво било друго манџирање, како префиксирање со карактер `_`.
    //
    //
    // Овој симбол е изборна маса што ја користат `std::type_info` на C++ .
    // Објектите од типот `std::type_info`, дескрипторите на типовите, имаат покажувач кон оваа табела.
    // Опис на типовите се повикуваат од структурите C++ EH дефинирани погоре и што ги конструираме подолу.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Овој тип на опишувач се користи само кога се фрла исклучок.
// Со делот за улов се ракува обид за внатрешни работи, кој генерира свој TypeDescriptor.
//
// Ова е во ред бидејќи времето за извршување на MSVC користи споредба на низи за името на типот за да одговара на TypeDescriptors наместо со еднаквоста на покажувачот.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Деструктор се користи ако кодот C++ одлучи да го фати исклучокот и да го испушти без да го пропагира.
// Делот за фаќање на суштинскиот обид ќе го постави првиот збор на објектот за исклучок на 0, така што тој ќе биде прескокнат од уништувачот.
//
// Забележете дека x86 Windows ја користи конвенцијата "thiscall" за повици за функции на член C++ наместо стандардната конвенција за повици "C".
//
// Функцијата за исклучок_копија е малку специјална тука: таа се повикува од времето на траење на MSVC под блок try/catch и panic што го генерираме тука ќе се користи како резултат на копија од исклучок.
//
// Ова се користи од времето на траење C++ за поддршка на снимање на исклучоци со std::exception_ptr, што не можеме да го поддржиме затоа што Box<dyn Any>не е клониран
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException се извршува целосно на оваа рамка на оџакот, така што нема потреба поинаку да се пренесува `data` на грамада.
    // Ние само пренесуваме покажувач на оџак до оваа функција.
    //
    // ManualDrop е потребна тука бидејќи не сакаме да се отфрли исклучокот кога се одмотуваме.
    // Наместо тоа, ќе се намали со исклучок_чист што се повикува на времето на траење на С ++.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ова ... може да изгледа изненадувачки, и оправдано така.На 32-битниот MSVC, покажувачите помеѓу овие структури се токму тоа, покажувачи.
    // Меѓутоа, на 64-битниот MSVC, покажувачите меѓу структурите се изразени како 32-битни неутрализирани вредности од `__ImageBase`.
    //
    // Следствено, на 32-битниот MSVC можеме да ги прогласиме сите овие покажувачи во статичкиот горе.
    // На 64-битниот MSVC, ќе мора да изразиме одземање на покажувачи во статиката, што Rust во моментов не го дозволува, па затоа не можеме да го направиме тоа.
    //
    // Следното најдобро нешто, тогаш е да ги пополните овие структури за време на извршувањето (паничноста веќе е "slow path").
    // Значи, тука повторно ги толкуваме сите овие полиња на покажувачот како 32-битни интеграли и потоа ја зачувуваме соодветната вредност во неа (атомски, бидејќи може да се случи истовремено panics).
    //
    // Технички, времето на траење веројатно ќе направи некое атомско читање на овие полиња, но во теорија тие никогаш не ја читаат *погрешната* вредност, така што не треба да биде премногу лошо ...
    //
    // Во секој случај, во основа треба да направиме вакво нешто додека не можеме да изразиме повеќе операции во статиката (а можеби и никогаш нема да можеме).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Товарен товар NULL овде значи дека стигнавме тука од уловот (...) на __rust_try.
    // Ова се случува кога ќе се фати исклучок од странство што не е Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Ова го бара компајлерот да постои (на пр., Тоа е ставка од јазик), но тој никогаш не е повикан од компајлерот затоа што __C_specific_handler или _except_handler3 е функцијата на личноста што секогаш се користи.
//
// Оттука, ова е само никулец што прекинува.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}