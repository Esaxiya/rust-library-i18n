//! `compiler-rt` লাইব্রেরির প্রোফাইল অংশটি সংকলন করে।
//!
//! বিশদ বিবরণের জন্য libcompiler_builtins crate এর জন্য build.rs দেখুন।

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: এক্স00 এক্স নির্দেশাবলী বর্তমানে নির্গত হয় না এবং বিল্ড স্ক্রিপ্ট
    // এই উত্স ফাইলগুলিতে বা এর মধ্যে অন্তর্ভুক্ত শিরোনামগুলির পরিবর্তনগুলি পুনরায় চালিত করবে না।
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // এই ফাইলটির নাম পরিবর্তন করা হয়েছিল এলএলভিএম 10।
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // এই ফাইলগুলি এলএলভিএম 11-এ যুক্ত করা হয়েছিল।
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // এমএসভিসিতে অতিরিক্ত পাঠাগারগুলি টানবেন না
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc এর বিভিন্ন বৈশিষ্ট্যগুলি বন্ধ করুন এবং এরকম বেশিরভাগই ইতিমধ্যে সংকলক-আরটির বিল্ড সিস্টেমটি অনুলিপি করছেন
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // ধরে নিন যে আমরা যে ইউনিক্সগুলি এটির জন্য তৈরি করছি তার জন্য fnctl() উপলব্ধ
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS কখন সেট করতে হবে এটির জন্য এটি একটি দুর্দান্ত উত্তোলনীয় হওয়া উচিত
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // মনে রাখবেন যে আমরা যদি চলতে চলেছি তবে এটি বিদ্যমান থাকতে হবে (অন্যথায় আমরা কেবল প্রোফাইলার বিল্টইনগুলি তৈরি করি না)।
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}