#![feature(no_core)]
#![no_core]

// এই crate কেন প্রয়োজন তার জন্য rustc-std-workpace-core দেখুন।

// লিবলোকের বরাদ্দ মডিউলটির সাথে বিরোধ না এড়াতে crate নামকরণ করুন।
extern crate alloc as foo;

pub use foo::*;