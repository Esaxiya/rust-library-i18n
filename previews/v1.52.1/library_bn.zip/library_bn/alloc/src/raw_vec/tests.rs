use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // তৃতীয় পক্ষের বরাদ্দকারী এবং `RawVec` এর মধ্যে সংহতকরণের পরীক্ষা লেখালেখি একটু মুশকিল কারণ `RawVec` এপিআই ফলসযোগ্য বরাদ্দ পদ্ধতি প্রকাশ করে না, সুতরাং বরাদ্দকারী শেষ হয়ে গেলে কী ঘটে তা আমরা পরীক্ষা করতে পারি না (একটি জেডপ্যানিক0 জেড সনাক্তকরণের বাইরে)।
    //
    //
    // পরিবর্তে, এটি কেবলমাত্র পরীক্ষা করে যে `RawVec` পদ্ধতিগুলি স্টোর সংরক্ষণ করে যখন কমপক্ষে Allocator API এর মাধ্যমে যায়।
    //
    //
    //
    //
    //

    // একটি বোবা বরাদ্দকারী যা বরাদ্দের চেষ্টা ব্যর্থ হওয়া শুরু হওয়ার আগে একটি নির্দিষ্ট পরিমাণ জ্বালানী গ্রহণ করে।
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (এইভাবে 50 + 150=200 ইউনিট জ্বালানী ব্যবহার করে রিলোকের কারণ হয়)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // প্রথমত,`reserve_exact` এক্স `reserve_exact` এর মতো বরাদ্দ দেয়।
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 এর দ্বিগুণের বেশি, সুতরাং `reserve` `reserve_exact` এর মতো কাজ করা উচিত।
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 এর অর্ধেকেরও কম, সুতরাং `reserve` অবশ্যই তাত্ক্ষণিকভাবে বৃদ্ধি পাবে।
        // এই পরীক্ষার লেখার সময় ফ্যাক্টর বৃদ্ধি 2, সুতরাং নতুন ক্ষমতা 24, তবে, 1.5 এর বৃদ্ধি ফ্যাক্টরও ঠিক আছে।
        //
        // অতএব দৃsert়ভাবে `>= 18`।
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}