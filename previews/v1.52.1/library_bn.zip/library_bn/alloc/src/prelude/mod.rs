//! বরাদ্দ Preide
//!
//! এই মডিউলটির উদ্দেশ্য হল `alloc` crate এর সাধারণভাবে ব্যবহৃত আইটেমগুলির মডিউলগুলির শীর্ষে একটি গ্লোব আমদানি যুক্ত করে আমদানি হ্রাস করা:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;