//! মেমরি বরাদ্দ এপিআই

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // এগুলি বিশ্বব্যাপী বরাদ্দকারীকে কল করার যাদু চিহ্ন।rustc তাদের `__rg_alloc` ইত্যাদি কল করতে জেনারেট করে
    // যদি কোনও `#[global_allocator]` অ্যাট্রিবিউট থাকে (কোডটি প্রসারিত করে যে এট্রিবিউট ম্যাক্রো সেই ফাংশনগুলি উত্পন্ন করে) বা libstd (`__rdl_alloc` ইত্যাদিতে ডিফল্ট বাস্তবায়নগুলি কল করতে) to
    //
    // অন্যথায় `library/std/src/alloc.rs` এ)।
    // LLVM এর rustc fork এছাড়াও বিশেষত ক্ষেত্রে এই ফাংশনগুলির নামগুলি যথাক্রমে `malloc`, `realloc`, এবং `free` এর মতো উপযুক্ত করতে সক্ষম হয়।
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// গ্লোবাল মেমরি বরাদ্দকারী।
///
/// এই ধরণের `#[global_allocator]` অ্যাট্রিবিউটের সাথে নিবন্ধিত বরাদ্দকারীর কাছে কলগুলি ফরওয়ার্ড করে [`Allocator`] trait বাস্তবায়ন করে যদি কোনও থাকে, বা `std` crate এর ডিফল্ট থাকে।
///
///
/// Note: এই ধরণের অস্থিরতা থাকা অবস্থায়, এটি যে কার্যকারিতা সরবরাহ করে তা [free functions in `alloc`](self#functions) এর মাধ্যমে অ্যাক্সেস করা যায়।
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// গ্লোবাল বরাদ্দকারীর সাথে মেমরি বরাদ্দ করুন।
///
/// এই ফাংশনটি `#[global_allocator]` অ্যাট্রিবিউটের সাথে নিবন্ধিত বরাদ্দকারীর [`GlobalAlloc::alloc`] পদ্ধতিতে বা `std` crate এর ডিফল্ট যদি কল করে।
///
///
/// [`Global`] প্রকারের `alloc` পদ্ধতির পক্ষে এবং [`Allocator`] trait স্থিতিশীল হয়ে গেলে এই ফাংশনটি হ্রাস করা হবে বলে আশা করা হচ্ছে।
///
/// # Safety
///
/// এক্স 100 এক্স দেখুন।
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// গ্লোবাল বরাদ্দকারীর সাথে স্মৃতি হ্রাস করুন।
///
/// এই ফাংশনটি `#[global_allocator]` অ্যাট্রিবিউটের সাথে নিবন্ধিত বরাদ্দকারীর [`GlobalAlloc::dealloc`] পদ্ধতিতে বা `std` crate এর ডিফল্ট যদি কল করে।
///
///
/// [`Global`] প্রকারের `dealloc` পদ্ধতির পক্ষে এবং [`Allocator`] trait স্থিতিশীল হয়ে গেলে এই ফাংশনটি হ্রাস করা হবে বলে আশা করা হচ্ছে।
///
/// # Safety
///
/// এক্স 100 এক্স দেখুন।
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// গ্লোবাল বরাদ্দকারীর সাথে স্মৃতি পুনরুদ্ধার করুন।
///
/// এই ফাংশনটি `#[global_allocator]` অ্যাট্রিবিউটের সাথে নিবন্ধিত বরাদ্দকারীর [`GlobalAlloc::realloc`] পদ্ধতিতে বা `std` crate এর ডিফল্ট যদি কল করে।
///
///
/// [`Global`] প্রকারের `realloc` পদ্ধতির পক্ষে এবং [`Allocator`] trait স্থিতিশীল হয়ে গেলে এই ফাংশনটি হ্রাস করা হবে বলে আশা করা হচ্ছে।
///
/// # Safety
///
/// এক্স 100 এক্স দেখুন।
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// গ্লোবাল বরাদ্দকারীর সাথে শূন্য-সূচনাযুক্ত মেমরি বরাদ্দ করুন।
///
/// এই ফাংশনটি `#[global_allocator]` অ্যাট্রিবিউটের সাথে নিবন্ধিত বরাদ্দকারীর [`GlobalAlloc::alloc_zeroed`] পদ্ধতিতে বা `std` crate এর ডিফল্ট যদি কল করে।
///
///
/// [`Global`] প্রকারের `alloc_zeroed` পদ্ধতির পক্ষে এবং [`Allocator`] trait স্থিতিশীল হয়ে গেলে এই ফাংশনটি হ্রাস করা হবে বলে আশা করা হচ্ছে।
///
/// # Safety
///
/// এক্স 100 এক্স দেখুন।
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // নিরাপদ: `layout` আকারে শূন্য নয়,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // নিরাপদ: এক্স 100 এক্স হিসাবে একই
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // নিরাপদ: `old_size` `new_size` এর চেয়ে বড় বা সমান হওয়ায় `new_size` শূন্য নয়
            // সুরক্ষা শর্ত দ্বারা প্রয়োজনীয় হিসাবে।কলারের দ্বারা অন্যান্য শর্তাবলী অবশ্যই বহাল থাকবে
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` সম্ভবত `new_size >= old_layout.size()` বা অনুরূপ কিছু পরীক্ষা করে।
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // সুরক্ষা: কারণ `new_layout.size()` অবশ্যই `old_size` এর চেয়ে বড় বা সমান হতে হবে,
            // পুরানো এবং নতুন উভয়ই মেমরির বরাদ্দ `old_size` বাইটের জন্য পড়ার জন্য এবং লেখার জন্য বৈধ।
            // এছাড়াও, যেহেতু পুরানো বরাদ্দটি এখনও অবনমিত হয়নি, এটি `new_ptr` কে ওভারল্যাপ করতে পারে না।
            // সুতরাং, `copy_nonoverlapping` এ কল নিরাপদ।
            // `dealloc` এর সুরক্ষা চুক্তি অবশ্যই কলার দ্বারা বহাল রাখা উচিত।
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // নিরাপদ: `layout` আকারে শূন্য নয়,
            // অন্যান্য শর্তগুলি অবশ্যই কলার দ্বারা বহাল থাকবে
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // নিরাপদ: সমস্ত শর্ত অবশ্যই কলারের দ্বারা বহাল থাকবে
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // নিরাপদ: সমস্ত শর্ত অবশ্যই কলারের দ্বারা বহাল থাকবে
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // নিরাপত্তা: শর্তাবলী অবশ্যই কলার দ্বারা বহাল থাকবে
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // নিরাপদ: এক্স 100 এক্স শূন্য নয়।কলারের দ্বারা অন্যান্য শর্তাবলী অবশ্যই বহাল থাকবে
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` সম্ভবত `new_size <= old_layout.size()` বা অনুরূপ কিছু পরীক্ষা করে।
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // নিরাপদ: কারণ `new_size` অবশ্যই `old_layout.size()` এর চেয়ে ছোট বা সমান হতে হবে,
            // পুরানো এবং নতুন উভয়ই মেমরির বরাদ্দ `new_size` বাইটের জন্য পড়ার জন্য এবং লেখার জন্য বৈধ।
            // এছাড়াও, যেহেতু পুরানো বরাদ্দটি এখনও অবনমিত হয়নি, এটি `new_ptr` কে ওভারল্যাপ করতে পারে না।
            // সুতরাং, `copy_nonoverlapping` এ কল নিরাপদ।
            // `dealloc` এর সুরক্ষা চুক্তি অবশ্যই কলার দ্বারা বহাল রাখা উচিত।
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// অনন্য পয়েন্টারের জন্য বরাদ্দকারী।
// এই ফাংশনটি অনাবৃত করা উচিত নয়।যদি এটি হয় তবে এমআইআর কোডজেন ব্যর্থ হবে।
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// এই স্বাক্ষরটি `Box` এর মতো হতে হবে, অন্যথায় একটি আইসিই হবে।
// যখন `Box` এ অতিরিক্ত প্যারামিটার যুক্ত করা হয় (`A: Allocator` এর মতো), এটি এখানেও যুক্ত করতে হবে।
// উদাহরণস্বরূপ, যদি `Box` কে `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` এ পরিবর্তন করা হয় তবে এই ফাংশনটিও `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` তে পরিবর্তন করতে হবে।
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # বরাদ্দ ত্রুটি হ্যান্ডলার

extern "Rust" {
    // এটি বৈশ্বিক বরাদ্দ ত্রুটি হ্যান্ডলার কল করতে যাদু প্রতীক।
    // rustc `#[alloc_error_handler]` X থাকলে `__rg_oom` কল করতে বা অন্যথায় (`__rdl_oom`) এর নীচে ডিফল্ট বাস্তবায়নগুলি কল করতে এটি তৈরি করে।
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// মেমরি বরাদ্দ ত্রুটি বা ব্যর্থতা বাতিল।
///
/// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক মেমরি বরাদ্দ API এর কলকারীরা সরাসরি `panic!` বা অনুরূপ অনুরোধ না করে এই ফাংশনটি কল করতে উত্সাহিত করা হয়।
///
///
/// এই ফাংশনটির ডিফল্ট আচরণ হ'ল মানক ত্রুটিতে একটি বার্তা মুদ্রণ করা এবং প্রক্রিয়াটি বাতিল করা।
/// এটি [`set_alloc_error_hook`] এবং [`take_alloc_error_hook`] এর সাথে প্রতিস্থাপন করা যেতে পারে।
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// বরাদ্দ পরীক্ষার জন্য এক্স00 এক্স সরাসরি ব্যবহার করা যেতে পারে।
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // উত্পাদিত `__rust_alloc_error_handler` এর মাধ্যমে ডাকা হয়

    // যদি কোনও `#[alloc_error_handler]` না থাকে
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // যদি একটি `#[alloc_error_handler]` থাকে
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// প্রাক-বরাদ্দকৃত, অবিবেচনাবিহীন মেমরিতে ক্লোন বিশেষায়িত করে।
/// `Box::clone` এবং `Rc`/`Arc::make_mut` দ্বারা ব্যবহৃত।
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *প্রথম* বরাদ্দ দেওয়া অপ্টিমাইজারটিকে স্থানটিতে ক্লোন করা মান তৈরি করতে অনুমতি দিতে পারে, স্থানীয় এড়ানো এবং সরানো যেতে পারে।
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // কোনও স্থানীয় মান জড়িত না করে আমরা সর্বদা স্থানটিতে অনুলিপি করতে পারি।
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}