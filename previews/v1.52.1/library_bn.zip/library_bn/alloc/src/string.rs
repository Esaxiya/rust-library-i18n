//! একটি ইউটিএফ-8 - এনকোডড, বর্ধনযোগ্য স্ট্রিং।
//!
//! এই মডিউলে [`String`] টাইপ, স্ট্রিংগুলিতে রূপান্তর করার জন্য [`ToString`] trait এবং [`স্ট্রিং] এর সাথে কাজ করার ফলে বিভিন্ন ত্রুটির প্রকার রয়েছে।
//!
//!
//! # Examples
//!
//! আক্ষরিক স্ট্রিং থেকে নতুন এক্স 100 এক্স তৈরির একাধিক উপায় রয়েছে:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! আপনি উপস্থিত থেকে একটি নতুন [`String`] তৈরি করতে পারেন সাথে সম্মিলন করে
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! আপনার যদি বৈধ UTF-8 বাইটের vector থাকে তবে আপনি এটি থেকে একটি [`String`] তৈরি করতে পারেন।আপনি বিপরীতটিও করতে পারেন।
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // আমরা জানি এই বাইটগুলি বৈধ, তাই আমরা `unwrap()` ব্যবহার করব।
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// একটি ইউটিএফ-8 - এনকোডড, বর্ধনযোগ্য স্ট্রিং।
///
/// `String` টাইপ সর্বাধিক সাধারণ স্ট্রিং প্রকার যা স্ট্রিংয়ের বিষয়বস্তুর উপর মালিকানা অর্জন করে।এটি এর ধার করা সমকক্ষ, আদিম [`str`] এর সাথে নিবিড় সম্পর্ক রয়েছে।
///
/// # Examples
///
/// আপনি [`String::from`] দিয়ে [a literal string][`str`] থেকে একটি `String` তৈরি করতে পারেন:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// আপনি [`push`] পদ্ধতিতে একটি [`char`] কে `String` এ যুক্ত করতে পারেন এবং [`push_str`] পদ্ধতিতে একটি [`&str`] যুক্ত করতে পারেন:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// আপনার যদি UTF-8 বাইটের vector থাকে তবে আপনি এটি থেকে [`from_utf8`] পদ্ধতিতে একটি `String` তৈরি করতে পারেন:
///
/// ```
/// // কিছু বাইট, একটি vector এ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // আমরা জানি এই বাইটগুলি বৈধ, তাই আমরা `unwrap()` ব্যবহার করব।
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `স্ট্রিংগুলি সর্বদা UTF-8 এর জন্য বৈধ।এর কয়েকটি বিভ্রান্তি রয়েছে যার মধ্যে প্রথমটি হল আপনার যদি ইউটিএফ-8 স্ট্রিং-এর প্রয়োজন হয় তবে [`OsString`] বিবেচনা করুন।এটি অনুরূপ, তবে UTF-8 বাধা ছাড়াই।দ্বিতীয় প্রভাবটি হ'ল আপনি `String` তে সূচি আনতে পারবেন না:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// সূচীকরণটি ধ্রুবক সময়ের ক্রিয়াকলাপ হিসাবে চালিত হয়, তবে UTF-8 এনকোডিং আমাদের এটি করতে দেয় না।তদুপরি, সূচকটি কী ধরণের জিনিসটি ফিরিয়ে আনবে তা পরিষ্কার নয়: একটি বাইট, কোডপয়েন্ট বা গ্রাফিম ক্লাস্টার।
/// [`bytes`] এবং [`chars`] পদ্ধতিগুলি যথাক্রমে প্রথম দুটির উপরে পুনরাবৃত্তিগুলি প্রদান করে।
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `স্ট্রিংগুলি প্রয়োগ করে [` ডেরেফ] ``<Target=str>`, এবং তাই [`str`] এর সমস্ত পদ্ধতির উত্তরাধিকারী হন।তদতিরিক্ত, এর অর্থ হ'ল আপনি একটি ফাংশনে একটি এক্স01 এক্স পাস করতে পারবেন যা একটি এম্পারস্যান্ড এক্স 100 এক্স ব্যবহার করে একটি এক্স02 এক্স নেয়:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// এটি `String` থেকে একটি [`&str`] তৈরি করবে এবং এতে প্রবেশ করবে This এই রূপান্তরটি খুব কম ব্যয়বহুল এবং তাই সাধারণত কোনও নির্দিষ্ট কারণে `String` প্রয়োজন না হলে ফাংশনগুলি [`&str`] টিকে আর্গুমেন্ট হিসাবে গ্রহণ করবে।
///
/// কিছু ক্ষেত্রে Rust এর এই রূপান্তর করতে পর্যাপ্ত তথ্য নেই যা [`Deref`] জবরদস্তি হিসাবে পরিচিত।নিম্নলিখিত উদাহরণে একটি স্ট্রিং স্লাইস [`&'a str`][`&str`] trait `TraitExample` বাস্তবায়িত করে এবং এক্স03X ফাংশনটি trait বাস্তবায়িত করে এমন কোনও কিছু নেয়।
/// এই ক্ষেত্রে Rust এর জন্য দুটি প্রকট রূপান্তর করা দরকার, যা Rust এর করার উপায় নেই।
/// যে কারণে, নিম্নলিখিত উদাহরণটি সংকলন করবে না।
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// দুটি বিকল্প আছে যা পরিবর্তে কাজ করবে।প্রথমটি হ'ল স্ট্রিংযুক্ত স্ট্রিং স্লাইস স্পষ্টভাবে এক্সট্র্যাক্ট করতে [`as_str()`] পদ্ধতিটি ব্যবহার করে `example_func(&example_string);` কে `example_func(example_string.as_str());` এ পরিবর্তন করা হবে।
/// দ্বিতীয় উপায় `example_func(&example_string);` কে `example_func(&*example_string);` এ পরিবর্তন করে।
/// এই ক্ষেত্রে আমরা `String` কে [`str`][`&str`] এর সাথে রেফারেন্স করছি, তারপরে [`str`][`&str`] কে [`&str`] এ উল্লেখ করছি।
/// দ্বিতীয় উপায়টি আরও মূর্খবাদী, তবে উভয়ই অন্তর্নিহিত রূপান্তরটির উপর নির্ভর না করে স্পষ্টতই রূপান্তরটি করার কাজ করে।
///
/// # Representation
///
/// একটি এক্স 100 এক্স তিনটি উপাদান দ্বারা গঠিত: কিছু বাইট, একটি দৈর্ঘ্য এবং একটি ক্ষমতা একটি পয়েন্টার।পয়েন্টারটি কোনও অভ্যন্তরীণ বাফারকে নির্দেশ করে `String` এর ডেটা সঞ্চয় করতে ব্যবহার করে।দৈর্ঘ্যটি বর্তমানে বাফারে সংরক্ষিত বাইটের সংখ্যা এবং ক্ষমতাটি বাইটে বাফারের আকার।
///
/// এর মতো দৈর্ঘ্য সর্বদা ক্ষমতার চেয়ে কম বা সমান হবে।
///
/// এই বাফারটি সর্বদা গাদা হয়ে থাকে।
///
/// আপনি এগুলি [`as_ptr`], [`len`], এবং [`capacity`] পদ্ধতিতে দেখতে পারেন:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // ভিক_আইএনটো_আরও_পর্বগুলি স্থিতিশীল হয়ে গেলে ফিক্সএমই এটি আপডেট করুন।
/// // স্ট্রিংয়ের ডেটা স্বয়ংক্রিয়ভাবে বাদ দেওয়া রোধ করুন
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // গল্পে উনিশ বাইট রয়েছে
/// assert_eq!(19, len);
///
/// // আমরা পিটিআর, লেন এবং ক্ষমতা থেকে বাইরে একটি স্ট্রিং পুনরায় তৈরি করতে পারি।
/// // এটি সমস্তই অনিরাপদ কারণ আমরা উপাদানগুলি বৈধ কিনা তা নিশ্চিত করার জন্য আমরা দায়বদ্ধ:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// যদি কোনও `String` এর পর্যাপ্ত ক্ষমতা থাকে তবে এতে উপাদান যুক্ত করে পুনরায় বরাদ্দ দেওয়া হবে না।উদাহরণস্বরূপ, এই প্রোগ্রামটি বিবেচনা করুন:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// এটি নিম্নলিখিত আউটপুট হবে:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// প্রথমে, আমাদের কোনও মেমরি বরাদ্দ নেই, তবে স্ট্রিংয়ের সাথে যুক্ত হয়ে এটি যথাযথভাবে তার ক্ষমতা বৃদ্ধি করে।যদি আমরা পরিবর্তে সঠিক ক্ষমতা বরাদ্দ করতে [`with_capacity`] পদ্ধতিটি ব্যবহার করি:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// আমরা একটি ভিন্ন আউটপুট দিয়ে শেষ:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// এখানে, লুপের ভিতরে আরও মেমরি বরাদ্দ করার দরকার নেই।
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 বাইট vector থেকে একটি `String` রূপান্তর করার সময় একটি সম্ভাব্য ত্রুটির মান।
///
/// এই ধরণেরটি [`String`] এ [`from_utf8`] পদ্ধতির জন্য ত্রুটি প্রকার।
/// পুনঃনির্মাণগুলি সাবধানতার সাথে এড়ানোর জন্য এটি এমনভাবে ডিজাইন করা হয়েছে: এক্স00 এক্স পদ্ধতিটি রূপান্তর প্রয়াসে ব্যবহৃত বাইট জেড0ভেেক্টর0 জেডটি ফিরিয়ে দেবে।
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] দ্বারা সরবরাহ করা [`Utf8Error`] প্রকারটি একটি ত্রুটি প্রতিনিধিত্ব করে যা [`u8`] s এর একটি স্লাইসকে [`&str`] এ রূপান্তর করার সময় ঘটতে পারে।
/// এই অর্থে, এটি `FromUtf8Error` এর একটি অ্যানালগ এবং আপনি [`utf8_error`] পদ্ধতির মাধ্যমে `FromUtf8Error` থেকে একটি পেতে পারেন।
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// // একটি vector এ কিছু অবৈধ বাইট
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 বাইট স্লাইস থেকে `String` রূপান্তর করার সময় একটি সম্ভাব্য ত্রুটির মান।
///
/// এই ধরণেরটি [`String`] এ [`from_utf16`] পদ্ধতির জন্য ত্রুটি প্রকার।
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// একটি নতুন খালি `String` তৈরি করে।
    ///
    /// প্রদত্ত যে `String` খালি, এটি কোনও প্রাথমিক বাফার বরাদ্দ করবে না।যদিও এর অর্থ এই যে এই প্রাথমিক ক্রিয়াকলাপটি খুব কম ব্যয়বহুল, এটি পরে যখন আপনি ডেটা যুক্ত করেন তখন অতিরিক্ত বরাদ্দের কারণ হতে পারে।
    ///
    /// যদি আপনার কাছে `String` কতটা ডেটা থাকবে তা সম্পর্কে ধারণা থাকলে অতিরিক্ত পুনরায় বরাদ্দ রোধ করতে [`with_capacity`] পদ্ধতিটি বিবেচনা করুন।
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// একটি নির্দিষ্ট ক্ষমতা সহ একটি নতুন খালি `String` তৈরি করে।
    ///
    /// স্ট্রিংয়ের ডেটা ধরে রাখতে অভ্যন্তরীণ বাফার রয়েছে।
    /// ক্ষমতাটি সেই বাফারের দৈর্ঘ্য এবং [`capacity`] পদ্ধতিতে অনুসন্ধান করা যেতে পারে।
    /// এই পদ্ধতিটি একটি খালি `String` তৈরি করে, তবে প্রাথমিক বাফার সহ একটি যা `capacity` বাইট ধরে রাখতে পারে।
    /// এটি কার্যকর যখন আপনি `String` এ গুচ্ছ ডেটা সংযোজন করতে পারেন, এটি করার প্রয়োজন পুনর্বিবেচনার সংখ্যা হ্রাস করে।
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// প্রদত্ত ক্ষমতাটি যদি `0` হয় তবে কোনও বরাদ্দ ঘটবে না এবং এই পদ্ধতিটি [`new`] পদ্ধতির মতো।
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // স্ট্রিংটিতে কোনও অক্ষর নেই, যদিও এটির আরও বেশি ক্ষমতা রয়েছে
    /// assert_eq!(s.len(), 0);
    ///
    /// // এগুলি সমস্ত পুনরায় প্রত্যাশা ছাড়াই সম্পন্ন হয়েছে ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... তবে এটি স্ট্রিংটিকে পুনর্বিবেচিত করতে পারে
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) সহ অন্তর্নিহিত `[T]::to_vec` পদ্ধতিটি যা এই পদ্ধতির সংজ্ঞার জন্য প্রয়োজনীয় তা উপলভ্য নয়।
    // যেহেতু পরীক্ষার উদ্দেশ্যে আমাদের এই পদ্ধতির প্রয়োজন নেই, তাই আমি কেবল এটিকে আটকে দেব NB আরও তথ্যের জন্য slice.rs এ slice::hack মডিউলটি দেখতে পাবে
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// একটি vector বাইটের একটি `String` এ রূপান্তর করে।
    ///
    /// একটি স্ট্রিং ([`String`]) বাইট ([`u8`]) দ্বারা তৈরি করা হয়, এবং একটি vector বাইট ([`Vec<u8>`]) বাইট দ্বারা তৈরি করা হয়, তাই এই ফাংশনটি দুটির মধ্যে রূপান্তরিত হয়।
    /// সমস্ত বাইট স্লাইস বৈধ `স্ট্রিংস নয়, তবে: `String` এর জন্য এটি বৈধ UTF-8 হওয়া দরকার।
    /// `from_utf8()` বাইটগুলি UTF-8 X বৈধ কিনা তা নিশ্চিত করার জন্য চেক করে এবং তারপরে রূপান্তরটি করে।
    ///
    /// আপনি যদি নিশ্চিত হন যে বাইট স্লাইসটি বৈধ UTF-8, এবং আপনি বৈধতা চেকের ওভারহেডটি ব্যয় করতে চান না, তবে এই ফাংশনটির একটি অনিরাপদ সংস্করণ রয়েছে, এক্স01 এক্স, যা একই আচরণ করে তবে চেকটি এড়িয়ে যায়।
    ///
    ///
    /// এই পদ্ধতিটি দক্ষতার জন্য vector অনুলিপি না করার বিষয়ে যত্ন নেবে।
    ///
    /// আপনার যদি `String` এর পরিবর্তে [`&str`] দরকার হয় তবে [`str::from_utf8`] বিবেচনা করুন।
    ///
    /// এই পদ্ধতির বিপরীতটি হল [`into_bytes`]।
    ///
    /// # Errors
    ///
    /// প্রদত্ত বাইটগুলি UTF-8 কেন নয় তা বর্ণনা সহ স্লাইস UTF-8 না হলে [`Err`] প্রদান করে।আপনি যে vector এ স্থানান্তরিত করেছেন তা অন্তর্ভুক্ত রয়েছে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // কিছু বাইট, একটি vector এ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // আমরা জানি এই বাইটগুলি বৈধ, তাই আমরা `unwrap()` ব্যবহার করব।
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ভুল বাইট:
    ///
    /// ```
    /// // একটি vector এ কিছু অবৈধ বাইট
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// আপনি এই ত্রুটিটি দিয়ে কী করতে পারেন সে সম্পর্কে আরও বিশদ জানতে এক্স 00 এক্স এর জন্য ডকগুলি দেখুন।
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// বাইটের স্লাইসটিকে স্ট্রিংয়ে অবৈধ অক্ষর সহ রূপান্তর করে।
    ///
    /// স্ট্রিংগুলি বাইট ([`u8`]) দিয়ে তৈরি করা হয় এবং এক্স02 এক্স বাইটের একটি স্লাইস বাইট দ্বারা তৈরি করা হয়, সুতরাং এই ফাংশনটি দুটির মধ্যে রূপান্তরিত হয়।সমস্ত বাইট স্লাইস বৈধ স্ট্রিং নয়, তবে: স্ট্রিংগুলি বৈধ UTF-8 হওয়া প্রয়োজন।
    /// এই রূপান্তরকালে, `from_utf8_lossy()` [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] এর সাথে কোনও অবৈধ UTF-8 অনুক্রমকে প্রতিস্থাপন করবে, যা দেখতে এরকম দেখাচ্ছে:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// আপনি যদি নিশ্চিত হন যে বাইট স্লাইসটি বৈধ UTF-8, এবং আপনি রূপান্তরটির ওভারহেড ব্যয় করতে চান না, তবে এই ফাংশনটির একটি অনিরাপদ সংস্করণ রয়েছে [`from_utf8_unchecked`], যা একই আচরণ করে তবে চেকগুলি এড়িয়ে যায়।
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// এই ফাংশনটি একটি [`Cow<'a, str>`] প্রদান করে।যদি আমাদের বাইট স্লাইসটি অবৈধ UTF-8 হয়, তবে আমাদের প্রতিস্থাপনের অক্ষরগুলি সন্নিবেশ করা দরকার যা স্ট্রিংয়ের আকার পরিবর্তন করবে এবং তাই এর জন্য একটি `String` প্রয়োজন।
    /// তবে এটি ইতিমধ্যে UTF-8 বৈধ হলে আমাদের নতুন বরাদ্দ লাগবে না।
    /// এই রিটার্ন টাইপ আমাদের উভয় ক্ষেত্রে পরিচালনা করতে পারবেন।
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // কিছু বাইট, একটি vector এ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ভুল বাইট:
    ///
    /// ```
    /// // কিছু অবৈধ বাইট
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// কোনও ইউটিএফ-16 - এনকোডেড জেড0ভেেক্টর0 জেড এক্স01 এক্সকে একটি `String` এ ডিকোড করুন, `v` এ যদি কোনও অবৈধ ডেটা থাকে তবে [`Err`] ফেরত।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // এটি সংগ্রহের মাধ্যমে করা হয় না: : <Result<_, _>> () কর্মক্ষমতা কারণে।
        // FIXME: এক্স00 এক্স বন্ধ হয়ে গেলে ফাংশনটি আবার সহজ করা যায়।
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// একটি ইউটিএফ-16 - এনকোডযুক্ত স্লাইস `v` কে `String` এ ডিকোড করুন, অবৈধ ডেটাটি [the replacement character (`U+FFFD`)][U+FFFD] এর সাথে প্রতিস্থাপন করুন।
    ///
    /// [`from_utf8_lossy`] এর বিপরীতে যা [`Cow<'a, str>`] প্রদান করে, `from_utf16_lossy` UTF-16 থেকে UTF-8 রূপান্তরকে একটি এক্স03 এক্স প্রদান করে একটি মেমরি বরাদ্দ প্রয়োজন।
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// একটি `String` এর কাঁচা উপাদানগুলিতে বিভক্ত করে।
    ///
    /// অন্তর্নিহিত ডেটা, স্ট্রিংয়ের দৈর্ঘ্য (বাইটে) এবং ডেটার বরাদ্দ ক্ষমতা (বাইটে) এ কাঁচা পয়েন্টার প্রদান করে।
    /// এগুলি একই ক্রমে একই যুক্তি যা [`from_raw_parts`]-তে যুক্তি হিসাবে।
    ///
    /// এই ফাংশনটি কল করার পরে, কলারটি `String` দ্বারা পরিচালিত মেমরির জন্য দায়বদ্ধ।
    /// এটি করার একমাত্র উপায় হ'ল কাঁচা পয়েন্টার, দৈর্ঘ্য এবং ক্ষমতাটিকে [`from_raw_parts`] ফাংশন দিয়ে একটি `String` এ রূপান্তর করা, যাতে ডেস্ট্রাক্টর ক্লিনআপ সম্পাদন করতে দেয়।
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// দৈর্ঘ্য, ক্ষমতা এবং পয়েন্টার থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// # Safety
    ///
    /// পরীক্ষামূলকভাবে পরীক্ষিত না হওয়া সংখ্যক আক্রমণকারী সংখ্যার কারণে এটি অত্যন্ত সুরক্ষিত is
    ///
    /// * `buf` এ থাকা মেমরিটি আগে একই বরাদ্দকারীকে স্ট্যান্ডার্ড লাইব্রেরি ব্যবহার করে ঠিক 1 এর প্রয়োজনীয় প্রান্তিককরণ সহ বরাদ্দ করা উচিত।
    /// * `length` `capacity` এর চেয়ে কম বা সমান হওয়া দরকার।
    /// * `capacity` সঠিক মান হওয়া দরকার।
    /// * `buf` এ প্রথম `length` বাইটের বৈধ UTF-8 হওয়া দরকার।
    ///
    /// এগুলি লঙ্ঘন করলে বরাদ্দকারীর অভ্যন্তরীণ ডেটা কাঠামোকে কলুষিত করার মতো সমস্যা দেখা দিতে পারে।
    ///
    /// `buf` এর মালিকানা কার্যকরভাবে `String` এ স্থানান্তরিত হয় যা ইচ্ছামত পয়েন্টার দ্বারা নির্দেশিত মেমরির বিষয়বস্তুগুলি হ্রাস করতে পারে, পুনরায় প্রকাশ করতে বা পরিবর্তন করতে পারে।
    /// নিশ্চিত করুন যে এই ফাংশনটি কল করার পরে আর কোনও কিছুই পয়েন্টার ব্যবহার করে না।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // ভিক_আইএনটো_আরও_পর্বগুলি স্থিতিশীল হয়ে গেলে ফিক্সএমই এটি আপডেট করুন।
    ///     // স্ট্রিংয়ের ডেটা স্বয়ংক্রিয়ভাবে বাদ দেওয়া রোধ করুন
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// স্ট্রিংটিতে বৈধ UTF-8 রয়েছে কিনা তা পরীক্ষা করেই একটি vector বাইটকে `String` এ রূপান্তর করে।
    ///
    /// আরও তথ্যের জন্য নিরাপদ সংস্করণ, [`from_utf8`] দেখুন।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি অনিরাপদ কারণ এটি পরীক্ষিত বাইটগুলি বৈধ UTF-8 কিনা তা পরীক্ষা করে না।
    /// যদি এই সীমাবদ্ধতা লঙ্ঘন করা হয় তবে এটি `String` এর future ব্যবহারকারীদের সাথে মেমরি অনর্থক সমস্যার কারণ হতে পারে, কারণ অন্যান্য স্ট্যান্ডার্ড লাইব্রেরি অনুমান করে যে `স্ট্রিংসটি বৈধ UTF-8।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // কিছু বাইট, একটি vector এ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// একটি `String` কে বাইট vector এ রূপান্তর করে।
    ///
    /// এটি `String` গ্রাস করে, তাই আমাদের এর সামগ্রীগুলি অনুলিপি করার দরকার নেই।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// পুরো `String` যুক্ত একটি স্ট্রিং স্লাইস বের করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// একটি এক্স00 এক্সকে পরিবর্তনীয় স্ট্রিং স্লাইসে রূপান্তরিত করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// এই `String` এর শেষে একটি প্রদত্ত স্ট্রিং স্লাইস যুক্ত করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// এই in স্ট্রিংয়ের সক্ষমতা, বাইটে দেয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// নিশ্চিত করে যে এই `স্ট্রিংয়ের সক্ষমতা তার দৈর্ঘ্যের চেয়ে কমপক্ষে `additional` বাইট।
    ///
    /// ঘন ঘন পুনর্বিবেচনা রোধ করতে, ক্ষমতাটি যদি এটি চয়ন করে তবে এটি `additional` বাইটের বেশি বাড়ানো যেতে পারে।
    ///
    ///
    /// আপনি যদি এই "at least" আচরণটি না চান তবে [`reserve_exact`] পদ্ধতিটি দেখুন।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতা [`usize`] ওভারফ্লো হয়।
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// এটি প্রকৃতপক্ষে ক্ষমতা বৃদ্ধি করতে পারে না:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s এর দৈর্ঘ্য 2 এবং সক্ষমতা 10 রয়েছে
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // যেহেতু আমাদের ইতিমধ্যে একটি অতিরিক্ত 8 ক্ষমতা রয়েছে, এটিকে কল করে ...
    /// s.reserve(8);
    ///
    /// // ... আসলে বাড়ছে না।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// নিশ্চিত করে যে এই `স্ট্রিংয়ের ক্ষমতাটি তার দৈর্ঘ্যের চেয়ে `additional` বাইট tes
    ///
    /// আপনি যদি বরাদ্দকারীর চেয়ে ভাল জানেন না তবে [`reserve`] পদ্ধতিটি বিবেচনা করুন।
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতা `usize` ওভারফ্লো হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// এটি প্রকৃতপক্ষে ক্ষমতা বৃদ্ধি করতে পারে না:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s এর দৈর্ঘ্য 2 এবং সক্ষমতা 10 রয়েছে
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // যেহেতু আমাদের ইতিমধ্যে একটি অতিরিক্ত 8 ক্ষমতা রয়েছে, এটিকে কল করে ...
    /// s.reserve_exact(8);
    ///
    /// // ... আসলে বাড়ছে না।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// প্রদত্ত `String` আরও কমপক্ষে আরও কয়েকটি উপাদান elementsোকানোর জন্য ক্ষমতা সংরক্ষণের চেষ্টা করে।
    /// ঘন ঘন পুনর্বিবেচনাগুলি এড়াতে সংগ্রহটি আরও স্থান সংরক্ষণ করতে পারে।
    /// `reserve` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে যথেষ্ট হলে কিছুই করে না।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতা ওভারফ্লো হয়, বা বরাদ্দকারী একটি ব্যর্থতার রিপোর্ট করে তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve(data.len())?;
    ///
    ///     // এখন আমরা জানি আমাদের জটিল কাজের মাঝখানে এটি OOM করতে পারে না
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// প্রদত্ত `String` আরও সঠিক উপাদানগুলিকে `additional` Xোকানোর জন্য ন্যূনতম ক্ষমতা সংরক্ষণের চেষ্টা করে।
    ///
    /// `reserve_exact` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে পর্যাপ্ত থাকলে কিছুই করে না।
    ///
    /// দ্রষ্টব্য যে বরাদ্দকারী সংগ্রহের চেয়ে তার চেয়ে বেশি জায়গা দিতে পারে।
    /// সুতরাং, সামর্থ্যটি নির্ভুলভাবে ন্যূনতম হতে নির্ভর করা যায় না।
    /// যদি জেডফিউচার0 জেড সন্নিবেশগুলি প্রত্যাশিত হয় তবে `reserve` পছন্দ করুন।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতা ওভারফ্লো হয়, বা বরাদ্দকারী একটি ব্যর্থতার রিপোর্ট করে তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve(data.len())?;
    ///
    ///     // এখন আমরা জানি আমাদের জটিল কাজের মাঝখানে এটি OOM করতে পারে না
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// দৈর্ঘ্যের সাথে মেলে এই `String` এর সক্ষমতা সঙ্কুচিত করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// নিম্ন সীমানা সহ এই `String` এর সক্ষমতা সঙ্কুচিত করে।
    ///
    /// ক্ষমতা কমপক্ষে দৈর্ঘ্য এবং সরবরাহিত মান উভয়ের হিসাবে বৃহত্তর থাকবে।
    ///
    ///
    /// যদি বর্তমান ক্ষমতা নিম্ন সীমাটির চেয়ে কম হয়, তবে এটি কোনও অপশন নয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// প্রদত্ত [`char`] এই `String` এর শেষে যুক্ত করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// এই `স্ট্রিংয়ের সামগ্রীগুলির একটি বাইট স্লাইস প্রদান করে।
    ///
    /// এই পদ্ধতির বিপরীতটি হল [`from_utf8`]।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// এই `String` নির্দিষ্ট দৈর্ঘ্য পর্যন্ত সংক্ষিপ্ত করে।
    ///
    /// যদি `new_len` স্ট্রিংয়ের বর্তমান দৈর্ঘ্যের চেয়ে বেশি হয় তবে এর কোনও প্রভাব নেই।
    ///
    ///
    /// নোট করুন যে স্ট্রিংয়ের বরাদ্দ ক্ষমতার উপর এই পদ্ধতির কোনও প্রভাব নেই
    ///
    /// # Panics
    ///
    /// Panics যদি `new_len` [`char`] সীমানায় থাকে না।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// স্ট্রিং বাফার থেকে শেষ চরিত্রটি সরিয়ে এটি প্রদান করে।
    ///
    /// এই `String` খালি থাকলে [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// বাইট অবস্থানে এই `String` থেকে একটি [`char`] সরান এবং এটি প্রদান করে।
    ///
    /// এটি একটি *ও*(*এন*) অপারেশন, কারণ এতে বাফারের প্রতিটি উপাদান অনুলিপি করা প্রয়োজন।
    ///
    /// # Panics
    ///
    /// Panics যদি `idx` `স্ট্রিংয়ের দৈর্ঘ্যের চেয়ে বড় বা সমান হয়, বা যদি এটি [`char`] সীমানায় থাকে না।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` এ প্যাটার্ন `pat` এর সমস্ত মিলগুলি সরিয়ে দিন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ম্যাচগুলি পুনরাবৃত্তভাবে সনাক্ত এবং মুছে ফেলা হবে, সুতরাং যেখানে প্যাটার্নগুলি ওভারল্যাপ হয়, কেবলমাত্র প্রথম প্যাটার্নটি সরানো হবে:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // সুরক্ষা: শুরু এবং শেষ প্রতি utf8 বাইট সীমানায় থাকবে
        // অনুসন্ধানকারী ডক্স
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// ভবিষ্যদ্বাণীকের দ্বারা বর্ণিত কেবলমাত্র অক্ষরগুলি ধরে রাখে।
    ///
    /// অন্য কথায়, `c` সমস্ত অক্ষর মুছে ফেলুন যাতে `f(c)` `false` প্রদান করে।
    /// এই পদ্ধতিটি যথাযথভাবে পরিচালনা করে প্রতিটি অক্ষরকে আসল ক্রমে ঠিক একবার দেখে এবং ধরে রাখা অক্ষরের ক্রম সংরক্ষণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// সঠিক অর্ডারটি কোনও সূচকের মতো বাহ্যিক অবস্থা অনুসরণ করার জন্য কার্যকর হতে পারে।
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // পরের চরে আইডেক্স পয়েন্ট করুন
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// বাইট অবস্থানে এই `String` এ একটি অক্ষর .োকান।
    ///
    /// এটি একটি *ও*(*এন*) অপারেশন কারণ এটি বাফারের প্রতিটি উপাদানকে অনুলিপি করা প্রয়োজন।
    ///
    /// # Panics
    ///
    /// Panics যদি `idx` `স্ট্রিংয়ের দৈর্ঘ্যের চেয়ে বড় হয় বা যদি এটি [`char`] সীমানায় না থাকে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// বাইট অবস্থানে এই `String` এ একটি স্ট্রিং স্লাইস সন্নিবেশ করান।
    ///
    /// এটি একটি *ও*(*এন*) অপারেশন কারণ এটি বাফারের প্রতিটি উপাদানকে অনুলিপি করা প্রয়োজন।
    ///
    /// # Panics
    ///
    /// Panics যদি `idx` `স্ট্রিংয়ের দৈর্ঘ্যের চেয়ে বড় হয় বা যদি এটি [`char`] সীমানায় না থাকে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// এই `String` এর সামগ্রীতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি অনিরাপদ কারণ এটি পরীক্ষিত বাইটগুলি বৈধ UTF-8 কিনা তা পরীক্ষা করে না।
    /// যদি এই সীমাবদ্ধতা লঙ্ঘন করা হয় তবে এটি `String` এর future ব্যবহারকারীদের সাথে মেমরি অনর্থক সমস্যার কারণ হতে পারে, কারণ অন্যান্য স্ট্যান্ডার্ড লাইব্রেরি অনুমান করে যে `স্ট্রিংসটি বৈধ UTF-8।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// এই `String` এর দৈর্ঘ্য, বাইটে, [`চর`] এর বা গ্রাফিক্স নয় s
    /// অন্য কথায়, কোনও মানুষ স্ট্রিংয়ের দৈর্ঘ্য বিবেচনা করে না।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// এই `String` এর দৈর্ঘ্য শূন্য এবং অন্যথায় `false` হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// প্রদত্ত বাইট সূচকে স্ট্রিংকে দুটিতে বিভক্ত করে।
    ///
    /// একটি নতুন বরাদ্দ করা `String` প্রদান করে।
    /// `self` বাইটস `[0, at)` রয়েছে এবং প্রত্যাবর্তিত এক্স0 2 এক্সে বাইটস `[at, len)` রয়েছে।
    /// `at` অবশ্যই একটি UTF-8 কোড পয়েন্টের সীমানায় থাকতে হবে।
    ///
    /// দ্রষ্টব্য যে `self` এর ক্ষমতা পরিবর্তন হয় না।
    ///
    /// # Panics
    ///
    /// Panics যদি `at` `UTF-8` কোড পয়েন্টের সীমানায় না থাকে বা এটি স্ট্রিংয়ের শেষ কোড পয়েন্টের বাইরে হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// সমস্ত লিখিত সামগ্রী সরিয়ে এই `String` কে ছাঁটাই করে।
    ///
    /// যদিও এর অর্থ `String` এর দৈর্ঘ্য শূন্য হবে, এটি এর ক্ষমতাটিকে স্পর্শ করে না।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String`-এ নির্দিষ্ট রেঞ্জটি সরিয়ে এবং সরানো `chars` উপার্জন করে এমন একটি ড্রেনিং আইট্রেটর তৈরি করে।
    ///
    ///
    /// Note: পুনরুক্তি শেষ অবধি না খাওয়া হলেও উপাদান পরিসর সরিয়ে ফেলা হয়।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভ পয়েন্ট বা শেষ পয়েন্টটি [`char`] সীমানায় থাকে না, বা যদি তারা সীমা ছাড়িয়ে যায়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // স্ট্রিং থেকে β অবধি রেঞ্জ সরিয়ে ফেলুন
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // একটি সম্পূর্ণ পরিসীমা স্ট্রিং সাফ করে
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // স্মৃতি সুরক্ষা
        //
        // Drain এর স্ট্রিং সংস্করণে vector সংস্করণটির মেমরির সুরক্ষা সমস্যা নেই।
        // ডেটা কেবল প্লেইন বাইট।
        // কারণ পরিসীমা অপসারণটি ড্রপ-এ ঘটে, যদি Drain পুনরুদ্ধারকারী ফাঁস হয় তবে অপসারণটি ঘটবে না।
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // একসাথে দুটি outণ গ্রহণ করুন।
        // ড্রপ-এ পুনরাবৃত্তি শেষ না হওয়া পর্যন্ত এক্স00 এক্স স্ট্রিং অ্যাক্সেস করা যাবে না।
        let self_ptr = self as *mut _;
        // নিরাপদ: `slice::range` এবং `is_char_boundary` উপযুক্ত বাউন্ড চেক করে।
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// স্ট্রিংয়ে নির্দিষ্ট ব্যাপ্তিটি সরিয়ে দেয় এবং প্রদত্ত স্ট্রিংয়ের সাথে এটি প্রতিস্থাপন করে।
    /// প্রদত্ত স্ট্রিংয়ের ব্যাপ্তির সমান দৈর্ঘ্য হওয়ার দরকার নেই।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভ পয়েন্ট বা শেষ পয়েন্টটি [`char`] সীমানায় থাকে না, বা যদি তারা সীমা ছাড়িয়ে যায়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // স্ট্রিং থেকে β অবধি রেঞ্জটি প্রতিস্থাপন করুন
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // স্মৃতি সুরক্ষা
        //
        // প্রতিস্থাপন_আরঞ্জারে একটি vector স্প্লাইসের মেমরির সুরক্ষা সমস্যা নেই।
        // vector সংস্করণডেটা কেবল প্লেইন বাইট।

        // সতর্কতা: এই ভেরিয়েবলটি অন্তর্ভুক্ত করা হবে আনসাউন্ড (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // সতর্কতা: এই ভেরিয়েবলটি অন্তর্ভুক্ত করা হবে আনসাউন্ড (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // এক্স X এক্স আবার ব্যবহার করা নিখরচায় (#81138) হবে আমরা ধরে নিই `range` দ্বারা বর্ণিত সীমানা একই থাকবে তবে একটি প্রতিকূল বাস্তবায়ন কলগুলির মধ্যে পরিবর্তন হতে পারে
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// এই `String` কে একটি [`Box`]`<`[`str`] `>` এ রূপান্তর করে `
    ///
    /// এটি কোনও অতিরিক্ত ক্ষমতা ছাড়বে।
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// [`U8`] এর বাইটের একটি স্লাইস দেয় যা `String` এ রূপান্তরিত করার চেষ্টা করা হয়েছিল।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // একটি vector এ কিছু অবৈধ বাইট
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` এ রূপান্তর করার চেষ্টা করা বাইটগুলি ফিরিয়ে দেয়।
    ///
    /// বরাদ্দ এড়াতে এই পদ্ধতিটি সাবধানতার সাথে তৈরি করা হয়েছে।
    /// এটি ত্রুটিটি গ্রাস করবে, বাইটগুলি সরিয়ে ফেলবে, যাতে বাইটগুলির অনুলিপি তৈরি করার প্রয়োজন হয় না।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // একটি vector এ কিছু অবৈধ বাইট
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// রূপান্তর ব্যর্থতা সম্পর্কে আরও বিশদ পেতে একটি `Utf8Error` আনুন।
    ///
    /// [`std::str`] দ্বারা সরবরাহ করা [`Utf8Error`] প্রকারটি একটি ত্রুটি প্রতিনিধিত্ব করে যা [`u8`] s এর একটি স্লাইসকে [`&str`] এ রূপান্তর করার সময় ঘটতে পারে।
    /// এই অর্থে, এটি `FromUtf8Error` এর একটি অ্যানালগ।
    /// এটি ব্যবহার সম্পর্কে আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // একটি vector এ কিছু অবৈধ বাইট
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // প্রথম বাইটটি এখানে অবৈধ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // যেহেতু আমরা `স্ট্রিংয়ের উপর পুনরাবৃত্তি করছি, আমরা আউটরেটারের কাছ থেকে প্রথম স্ট্রিং পেয়ে এবং পরবর্তী সমস্ত স্ট্রিং যুক্ত করে কমপক্ষে একটি বরাদ্দ এড়াতে পারি।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // যেহেতু আমরা CoWs এর উপর পুনরাবৃত্তি করছি, আমরা (potentially) প্রথম আইটেম পেয়ে এবং পরবর্তী সমস্ত আইটেম যুক্ত করে কমপক্ষে একটি বরাদ্দ এড়াতে পারি।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` এর প্রেরণায় প্রতিনিধিত্ব করে এমন একটি সুবিধাযুক্ত ইমপ্লিট।
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// একটি খালি `String` তৈরি করে।
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// দুটি স্ট্রিং সংমিশ্রনের জন্য এক্স 100 এক্স অপারেটরকে কার্যকর করে।
///
/// এটি বাম দিকে `String` গ্রাস করে এবং তার বাফারটি পুনরায় ব্যবহার করে (প্রয়োজনে এটি বাড়ানো)।
/// একটি নতুন এক্স00 এক্স বরাদ্দ করা এবং প্রতিটি ক্রিয়াকলাপে সম্পূর্ণ সামগ্রীর অনুলিপি এড়ানোর জন্য এটি করা হয়, যা বারবার যুক্তি দ্বারা একটি *এন*-বাইট স্ট্রিং তৈরি করার সময় *ও*(*এন*^ 2) চলমান সময় হতে পারে।
///
///
/// ডানদিকে স্ট্রিং শুধুমাত্র ধার করা হয়;এর সামগ্রীগুলি ফিরে আসা `String` এ অনুলিপি করা হয়েছে।
///
/// # Examples
///
/// দুটি স্ট্রিংয়ের প্রতিযোগিতা প্রথমটি মান দ্বারা নেয় এবং দ্বিতীয়টি ধার করে:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` সরানো হয়েছে এবং এখানে আর ব্যবহার করা যাবে না।
/// ```
///
/// আপনি যদি প্রথম `String` ব্যবহার চালিয়ে যেতে চান তবে আপনি এটি ক্লোন করতে পারেন এবং এর পরিবর্তে ক্লোনটিতে সংযোজন করতে পারেন:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` এখনও এখানে বৈধ।
/// ```
///
/// প্রথমটিকে `String` এ রূপান্তর করে `&str` স্লাইসগুলি সংঘবদ্ধ করা যায়:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` যুক্ত করার জন্য `+=` অপারেটরকে কার্যকর করে।
///
/// এটি [`push_str`][String::push_str] পদ্ধতির মতোই আচরণ করে।
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] এর জন্য একটি প্রকারের উপনাম।
///
/// পিছনের সামঞ্জস্যের জন্য এই উপন্যাসটি বিদ্যমান এবং অবশেষে হ্রাস করা হতে পারে।
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// একটি মানকে `String` এ রূপান্তর করার জন্য একটি trait।
///
/// এই trait [`Display`] trait প্রয়োগ করে এমন যে কোনও ধরণের জন্য স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয়েছে।
/// এর মতো, এক্স00 এক্স সরাসরি প্রয়োগ করা উচিত নয়:
/// [`Display`] পরিবর্তে প্রয়োগ করা উচিত এবং আপনি বিনামূল্যে জন্য `ToString` বাস্তবায়ন পান।
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// প্রদত্ত মানকে একটি `String` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// এই বাস্তবায়নে `to_string` পদ্ধতি panics যদি `Display` বাস্তবায়ন কোনও ত্রুটি ফেরায়।
/// এটি একটি ভুল `Display` বাস্তবায়ন নির্দেশ করে যেহেতু `fmt::Write for String` নিজেই কোনও ত্রুটি ফেরায় না।
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // একটি সাধারণ নির্দেশিকা হ'ল জেনেরিক ফাংশনগুলিকে ইনলাইন না করা।
    // যাইহোক, এই পদ্ধতি থেকে `#[inline]` অপসারণ অ-তুচ্ছ-অনগ্রসরগুলির কারণ হয়।
    // এটি সরিয়ে দেওয়ার চেষ্টা করার শেষ প্রচেষ্টা <https://github.com/rust-lang/rust/pull/74852> দেখুন।
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` কে `String` এ রূপান্তর করে।
    ///
    /// ফলাফল গাদা উপর বরাদ্দ করা হয়।
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: পরীক্ষা libstd এ টান দেয়, যা এখানে ত্রুটি ঘটায়
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// প্রদত্ত বাক্সযুক্ত `str` স্লাইসকে একটি `String` এ রূপান্তর করে।
    /// এটি উল্লেখযোগ্য যে `str` স্লাইসের মালিকানা রয়েছে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// প্রদত্ত `String` কে মালিকানাধীন একটি বক্সযুক্ত `str` স্লাইসে রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// একটি স্ট্রিং স্লাইসকে ধার করা ভেরিয়েন্টে রূপান্তর করে।
    /// কোনও গাদা বরাদ্দ সম্পন্ন হয় না, এবং স্ট্রিংটি অনুলিপি করা হয় না।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// একটি স্ট্রিংকে মালিকানাধীন রূপে রূপান্তরিত করে।
    /// কোনও গাদা বরাদ্দ সম্পন্ন হয় না, এবং স্ট্রিংটি অনুলিপি করা হয় না।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// একটি স্ট্রিং রেফারেন্সকে ধার ধারক রূপে রূপান্তর করে।
    /// কোনও গাদা বরাদ্দ সম্পন্ন হয় না, এবং স্ট্রিংটি অনুলিপি করা হয় না।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// প্রদত্ত `String` কে vector `Vec` তে রূপান্তর করে যা `u8` প্রকারের মান ধারণ করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` এর জন্য একটি জলস্রোতে পুনরাবৃত্তিকারী।
///
/// এই কাঠামোটি [`String`] এ [`drain`] পদ্ধতি দ্বারা তৈরি করা হয়েছে।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ডেস্ট্রাক্টরে&'মিউট স্ট্রিং' হিসাবে ব্যবহৃত হবে
    string: *mut String,
    /// অপসারণ অংশের শুরু
    start: usize,
    /// অংশ শেষ
    end: usize,
    /// অপসারণের জন্য বর্তমান অবশিষ্ট রেঞ্জ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // এক্স 100 এক্স ব্যবহার করুন।
            // "Reaffirm" panic কোডটি আবার sertedোকানো থেকে বাঁচতে সীমাগুলি পরীক্ষা করে।
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// এই পুনরাবৃত্তির অবশিষ্ট (উপ) স্ট্রিংটি একটি স্লাইস হিসাবে প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: স্থিতিশীল হওয়ার সময় অসাবধানতা এএসআরফ নীচে চাপিয়ে দেয়।
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// এক্স 100 এক্স স্থিতিশীল করার সময় অবিরাম মন্তব্য।
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ইমপ্ল <'এ> এসআরফ<str>Drain <'a> {fn as_ref(&self)-> &str for
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// জেড0ড্রেন0 জেড <'এ> n এফএন এক্স00 এক্স->&[u8] for এর জন্য ইমেল <' a> আসফেরফ <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}