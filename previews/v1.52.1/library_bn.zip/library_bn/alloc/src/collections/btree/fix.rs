use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ভাইবোনটির সাথে একত্রীকরণ বা চুরি করে একটি সম্ভাব্য নীচের নোড স্টক করে।
    /// যদি সফল হয় তবে প্যারেন্ট নোড সঙ্কুচিত করার ব্যয়ে, সেই সঙ্কীর্ণ পিতা-মাতা নোডটি ফেরত দেয়।
    /// নোডটি যদি খালি মূল হয় তবে একটি `Err` প্রদান করে।
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// একটি সম্ভাব্য আন্ডারফুল নোড স্টক করে এবং এর ফলে যদি তার পিতামাতার নোড সঙ্কুচিত হয় তবে পিতামাতাকে পুনরাবৃত্তভাবে স্টক করে।
    /// `true` এটি যদি গাছ ঠিক করে দেয়, `false` প্রদান করে যদি এটি করতে না পারে কারণ মূল নোড খালি হয়ে গেছে।
    ///
    /// এই পদ্ধতিটি পূর্বপুরুষদের শূন্য পূর্বপুরুষের মুখোমুখি হলে ইতিমধ্যে প্রবেশ এবং জেড 0 স্প্যানিকস0 জেড এর আগেও অধীনে থাকা আশা করে না।
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// উপরে খালি স্তরগুলি সরিয়ে দেয়, তবে পুরো গাছটি খালি থাকলে খালি পাতা রাখে।
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// গাছের ডান সীমানায় যেকোন আন্ডারফুল নোডগুলি স্টক আপ বা মার্জ করে।
    /// অন্যান্য নোডগুলি, যেগুলি মূল নয় বা ডানদিকের edge নয়, তাদের ইতিমধ্যে কমপক্ষে MIN_LEN উপাদান থাকা উচিত।
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` এর প্রতিসাম্য ক্লোন।
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// গাছের ডান সীমানায় যে কোনও আন্ডারফুল নোড স্টক করুন।
    /// অন্যান্য নোডগুলি, যেগুলি মূল বা ডানদিকের edge নয়, তাদের অবশ্যই MIN_LEN উপাদান চুরি করতে প্রস্তুত থাকতে হবে।
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // ডান-সর্বাধিক শিশুটি নীচে রয়েছে কিনা তা পরীক্ষা করে দেখুন।
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // আমাদের চুরি করা দরকার
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // আরও নিচে যান।
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// বাম বাচ্চাটিকে মজুত করে, ধরে নিয়েছে যে ডান শিশুটি নিম্নরূপ নয়, এবং তার বাচ্চাদের অন্তর্নিহিত না হয়ে পরিবর্তে মার্জ করার অনুমতি দেওয়ার জন্য একটি অতিরিক্ত উপাদান সরবরাহ করে।
    ///
    /// বাম সন্তানকে ফিরিয়ে দেয়।
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` পরবর্তী স্তরে একত্রিত হলে পুনরায় সমন্বয় এড়াতে।
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// বাম বাচ্চা শিশুটি নিম্নরূপ নয়, ধরে নিয়ে ডান শিশুটিকে মজুত করে এবং তার বাচ্চাদেরকে নীচে পরিণত না করে পরিবর্তে মার্জ করার অনুমতি দেওয়ার জন্য একটি অতিরিক্ত উপাদান সরবরাহ করে।
    ///
    /// ডান শিশু যেখানেই শেষ হয়েছিল সেখানে ফিরে আসে।
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` পরবর্তী স্তরে একত্রিত হলে পুনরায় সমন্বয় এড়াতে।
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}