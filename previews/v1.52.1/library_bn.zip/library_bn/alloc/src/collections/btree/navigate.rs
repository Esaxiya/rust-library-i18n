use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// অস্থায়ীভাবে একই পরিসরের আর একটি অপরিবর্তনীয় সমতুল্য বের করে।
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// একটি গাছের মধ্যে নির্দিষ্ট রেঞ্জের সীমানা নির্ধারণ করে স্বতন্ত্র পাতার প্রান্তগুলি সন্ধান করে।
    /// হয় বিভিন্ন গাছের হ্যান্ডেলগুলির একটি জোড়া একই গাছে বা খালি বিকল্পগুলির একটি জুড়ি।
    ///
    /// # Safety
    ///
    /// `BorrowType` `Immut` না হলে একই কেভিতে দু'বার দেখার জন্য সদৃশ হ্যান্ডলগুলি ব্যবহার করবেন না।
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// এক্স 100 এক্স, এক্স01 এক্স এর সমান তবে আরও কার্যকর।
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// একটি গাছের মধ্যে একটি নির্দিষ্ট পরিসীমা সীমিত করে পাতার প্রান্তগুলির জোড়া আবিষ্কার করে।
    ///
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা অর্ডার করা হয়, যেমন একটি এক্স 100 এক্সের গাছ।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // নিরাপত্তা: আমাদের orrowণ গ্রহণের প্রকারটি অপরিবর্তনীয়।
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// একটি সম্পূর্ণ গাছের সীমানা যুক্ত পাতার কিনারগুলির জুড়ি।
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// নির্দিষ্ট পরিসীমা ডিলিমেট করে পাতার প্রান্তের একজোড়াতে একটি অনন্য রেফারেন্স বিভক্ত করে।
    /// ফলাফলটি (some) রূপান্তরকে অনুমতি দেয় এমন অনন্য-অনন্য রেফারেন্স, যা অবশ্যই সাবধানে ব্যবহার করা উচিত।
    ///
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা অর্ডার করা হয়, যেমন একটি এক্স 100 এক্সের গাছ।
    ///
    ///
    /// # Safety
    /// একই কেভিতে দু'বার দেখার জন্য সদৃশ হ্যান্ডলগুলি ব্যবহার করবেন না।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// গাছের সম্পূর্ণ পরিসীমা ডিলিমেট করে পাতার প্রান্তের একজোড়াতে একটি অনন্য রেফারেন্স বিভক্ত করে।
    /// ফলাফলগুলি হ'ল রূপান্তরকরণ (কেবলমাত্র মানগুলির) মঞ্জুরি দেয় এমন অনন্য অনন্য রেফারেন্স, তাই যত্ন সহকারে অবশ্যই ব্যবহার করা উচিত।
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // আমরা এখানে নোডেরেফের মূলটি নকল করব-আমরা কখনই একই কেভিতে দু'বার পরিদর্শন করব না এবং কখনও ওভারল্যাপিং মান রেফারেন্স দিয়ে শেষ করব না।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// গাছের সম্পূর্ণ পরিসীমা ডিলিমেট করে পাতার প্রান্তের একজোড়াতে একটি অনন্য রেফারেন্স বিভক্ত করে।
    /// ফলাফলগুলি হ'ল অ-স্বতন্ত্র রেফারেন্স যা ব্যাপকভাবে ধ্বংসাত্মক পরিবর্তনের অনুমতি দেয়, তাই অবশ্যই যত্ন সহকারে ব্যবহার করা উচিত।
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // আমরা এখানে নোডেফ রুটটিকে নকল করি-আমরা কখনই এটিকে এমনভাবে অ্যাক্সেস করতে পারি না যে মূল থেকে প্রাপ্ত রেফারেন্সগুলিকে ওভারল্যাপ করে।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// একটি পাতা edge হ্যান্ডেল দেওয়া হয়েছে, ডান পাশের প্রতিবেশী কেভিতে একটি হ্যান্ডেল সহ [`Result::Ok`] প্রদান করে, যা হয় একই পাতার নোডে বা পূর্বপুরুষের নোডে।
    ///
    /// যদি পাতা edge গাছের মধ্যে সর্বশেষ হয় তবে রুট নোড দিয়ে [`Result::Err`] প্রদান করে।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// একটি পাতা edge হ্যান্ডেল দেওয়া হয়েছে, বাম দিকে প্রতিবেশী কেভিতে একটি হ্যান্ডেল সহ [`Result::Ok`] প্রদান করে, যা হয় একই পাতার নোডে বা পূর্বসূর নোডে।
    ///
    /// যদি পাতা edge গাছের মধ্যে প্রথম হয় তবে রুট নোড দিয়ে [`Result::Err`] প্রদান করে।
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// একটি অভ্যন্তরীণ edge হ্যান্ডেল দেওয়া হয়েছে, ডান পাশের প্রতিবেশী কেভিতে একটি হ্যান্ডেল সহ [`Result::Ok`] প্রদান করে, যা হয় একই অভ্যন্তরীণ নোডে বা পূর্বপুরুষের নোডে।
    ///
    /// যদি অভ্যন্তরীণ edge গাছের মধ্যে সর্বশেষ হয় তবে রুট নোড দিয়ে [`Result::Err`] প্রদান করে।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// একটি পাতা edge হ্যান্ডেলটিকে একটি মরণ গাছের মধ্যে দিয়ে দেওয়া হয়েছে, পরবর্তী পাতা edge ডানদিকে এবং মূল-মান জোড়টি, যা পূর্ববর্তী নোডে হয় একই পাতার নোডে বা অস্তিত্বহীন অবস্থায় ফিরে আসে।
    ///
    ///
    /// এই পদ্ধতিটি যে কোনও node(s) এর শেষের দিকে পৌঁছে যায় তাও deallocates।
    /// এর থেকে বোঝা যায় যে যদি আর কী-মূল্যের জুটি না থাকে তবে গাছের পুরো অংশটি নির্বিঘ্ন হয়ে গেছে এবং ফিরে আসার মতো কিছুই নেই।
    ///
    /// # Safety
    /// প্রদত্ত edge অবশ্যই পূর্বে কাউন্টার পার্ট `deallocating_next_back` দ্বারা ফিরে আসেনি।
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// একটি পাতা edge হ্যান্ডেলটি একটি মরণ গাছের মধ্যে দেওয়া হয়েছে, তার পরের পাতা edge বাম দিকে ফিরে আসে এবং এর মধ্যে কী-মান জোড়, যা হয় একই পাতার নোডে হয় পূর্বপুরুষ নোডে বা অস্তিত্বহীন।
    ///
    ///
    /// এই পদ্ধতিটি যে কোনও node(s) এর শেষের দিকে পৌঁছে যায় তাও deallocates।
    /// এর থেকে বোঝা যায় যে যদি আর কী-মূল্যের জুটি না থাকে তবে গাছের পুরো অংশটি নির্বিঘ্ন হয়ে গেছে এবং ফিরে আসার মতো কিছুই নেই।
    ///
    /// # Safety
    /// প্রদত্ত edge অবশ্যই পূর্বে কাউন্টার পার্ট `deallocating_next` দ্বারা ফিরে আসেনি।
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// পাতা থেকে মূল পর্যন্ত নোডের একটি গাদা নির্ধারণ করে।
    /// `deallocating_next` এবং `deallocating_next_back` গাছের দুপাশে নিচু হয়ে যাওয়ার পরে গাছের বাকী অংশগুলি অবনমিত করার একমাত্র উপায় এবং একই edge এ আঘাত করে।
    /// যেহেতু কেবলমাত্র যখন সমস্ত কী এবং মানগুলি ফিরে আসার কথা বলা হয়, তেমনি কোনও কী বা মানগুলিতে কোনও ক্লিনআপ করা হয় না।
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// পাতায় edge হ্যান্ডেলটি পরের পাতায় edge এ স্থানান্তরিত করে এবং এর মধ্যে কী এবং মানটির জন্য রেফারেন্স দেয়।
    ///
    ///
    /// # Safety
    /// যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// পাতায় edge হ্যান্ডেলটি পূর্ববর্তী পাতায় edge এ স্থানান্তরিত করে এবং এর মধ্যে কী এবং মানটির উল্লেখ প্রেরণ করে returns
    ///
    ///
    /// # Safety
    /// যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// পাতায় edge হ্যান্ডেলটি পরের পাতায় edge এ স্থানান্তরিত করে এবং এর মধ্যে কী এবং মানটির জন্য রেফারেন্স দেয়।
    ///
    ///
    /// # Safety
    /// যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // বেঞ্চমার্ক অনুসারে এটি শেষ করা দ্রুততর।
        kv.into_kv_valmut()
    }

    /// পূর্ববর্তী পাতায় edge হ্যান্ডেলটি পাতায় সরায় এবং এর মধ্যে কী এবং মানটির জন্য উল্লেখগুলি ফেরত দেয়।
    ///
    ///
    /// # Safety
    /// যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // বেঞ্চমার্ক অনুসারে এটি শেষ করা দ্রুততর।
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// পাতায় edge হ্যান্ডেলটি পরের পাতায় edge এ সরিয়ে দেয় এবং কী এবং মানটির মধ্যে ফিরে আসে, যেকোন নোডকে পিছনে ফেলে রেখে প্যারেন্ট নোডে ঝাঁকুনির সাথে সংশ্লিষ্ট edge রেখে যায়।
    ///
    /// # Safety
    /// - যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    /// - গাছটি পেরিয়ে যাওয়ার জন্য ব্যবহৃত হ্যান্ডলগুলির কোনও অনুলিপিটিতে কেভিটি আগে কাউন্টার পার্ট এক্স00 এক্স ফেরত দেয়নি।
    ///
    /// আপডেট হওয়া হ্যান্ডেলটি নিয়ে এগিয়ে যাওয়ার একমাত্র নিরাপদ উপায় এটির তুলনা করা, এটিকে বাদ দেওয়া, এই পদ্ধতিটিকে তার সুরক্ষা শর্ত সাপেক্ষে আবার কল করা, বা সুরক্ষার শর্ত সাপেক্ষে কাউন্টার পার্ট `next_back_unchecked` কে কল করা।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// পাতায় edge হ্যান্ডেলটি পূর্ববর্তী পাতায় edge এ সরিয়ে দেয় এবং কী এবং মানটির মধ্যে ফিরে আসে, যেকোন নোড পিছনে ফেলে রেখে তার জিন0edge0Z এর মূল নোডে ঝাঁকুনির সময় রেখে যায়।
    ///
    /// # Safety
    /// - যেদিকে ভ্রমণ হয়েছিল সেদিকে অবশ্যই আরও একটি কেভি থাকতে হবে।
    /// - গাছটি পেরোতে ব্যবহৃত হ্যান্ডলগুলির কোনও অনুলিপিটিতে এই পাতা edge এর আগে কাউন্টার পার্ট `next_unchecked` ফেরত দেয়নি।
    ///
    /// আপডেট হওয়া হ্যান্ডেলটি নিয়ে এগিয়ে যাওয়ার একমাত্র নিরাপদ উপায় এটির তুলনা করা, এটিকে বাদ দেওয়া, এই পদ্ধতিটিকে তার সুরক্ষা শর্ত সাপেক্ষে আবার কল করা, বা সুরক্ষার শর্ত সাপেক্ষে কাউন্টার পার্ট `next_unchecked` কে কল করা।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// বামতম পাতা edge কোনও নোডের নীচে বা তার নীচে ফিরে আসে, অন্য কথায়, এগিয়ে নেভিগেট করার সময় আপনার প্রথমে edge প্রয়োজন (বা পিছনে নেভিগেট করার সময় শেষ)।
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// নোডের নীচে বা নীচে ডানদিকের পাতা edge প্রদান করে, অন্য কথায়, এগিয়ে যাওয়ার সময় (বা পিছনে নেভিগেট করার সময় প্রথমে) আপনার শেষ হওয়া edge প্রয়োজন।
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// আরোহী কীগুলির ক্রমের জন্য পাতার নোড এবং অভ্যন্তরীণ কেভিগুলি পরিদর্শন করে এবং সামগ্রিকভাবে অভ্যন্তরীণ নোডগুলি গভীরতার প্রথম ক্রমে পরিদর্শন করে যার অর্থ অভ্যন্তরীণ নোডগুলি তাদের পৃথক কেভি এবং তাদের শিশু নোডের আগে pre
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// একটি (উপ) গাছের উপাদানগুলির সংখ্যা গণনা করে।
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ফরোয়ার্ড নেভিগেশনের জন্য কেভি এর নিকটতম edge পাতাটি ফেরত দেয়।
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// পিছনে নেভিগেশনের জন্য কেভি এর নিকটতম edge পাতায় ফিরিয়ে দেয়।
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}