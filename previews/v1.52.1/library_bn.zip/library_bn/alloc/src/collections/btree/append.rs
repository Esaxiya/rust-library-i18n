use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// পথে দুটি `length` ভেরিয়েবলকে বাড়িয়ে, দুটি আরোহী পুনরুক্তিগুলির সংঘ থেকে সমস্ত কী-মান জোড় যুক্ত করে।দ্বিতীয়টি যখন ড্রপ হ্যান্ডলার পিক করে তখন কলকারীকে ফাঁস এড়ানো সহজ করে তোলে।
    ///
    /// যদি উভয় পুনরাবৃত্তকারী একই কী উত্পন্ন করে, এই পদ্ধতিটি বাম পুনরুক্তি থেকে জোড়টি ড্রপ করে এবং ডান পুনরাবৃত্তকারী থেকে জোড়াটি সংযোজন করে।
    ///
    /// আপনি যদি `BTreeMap` এর মতো গাছটিকে কঠোরভাবে আরোহণের ক্রমে শেষ করতে চান তবে উভয় পুনরাবৃত্তিকে কঠোরভাবে আরোহণের ক্রমে চাবি প্রস্তুত করা উচিত, গাছের সমস্ত চাবির চেয়ে বড় বড় প্রতিটি গাছের মধ্যে প্রবেশের সময় ইতিমধ্যে কোনও চাবি রয়েছে।
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // আমরা `left` এবং `right` রৈখিক সময়ের অনুসারে বাছাই করা অনুক্রমের সাথে একীভূত করার জন্য প্রস্তুত।
        let iter = MergeIter(MergeIterInner::new(left, right));

        // এদিকে, আমরা রৈখিক সময়ে সাজানো ক্রম থেকে একটি গাছ তৈরি করি।
        self.bulk_push(iter, length)
    }

    /// গাছের শেষে সমস্ত কী-মান জোড় জোড় দেয়, পথে `length` পরিবর্তনশীল বৃদ্ধি করে।
    /// পরেরটি যখন পুনরাবৃত্তকারী প্যানিক্স করে তখন কলকারীটির কোনও ফাঁস এড়ানো সহজ করে তোলে।
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // সমস্ত কী-মান জোড়গুলির মধ্য দিয়ে আইট্রেট করুন, ডান স্তরে নোডগুলিতে ঠেলাচ্ছেন।
        for (key, value) in iter {
            // বর্তমান লিফ নোডে কী-মান জোড় জোড় করার চেষ্টা করুন।
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // কোনও স্থান বাকি নেই, উপরে উঠে সেখানে ধাক্কা দিন।
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // বাম স্থান সহ একটি নোড পেয়েছে, এখানে চাপ দিন।
                                open_node = parent;
                                break;
                            } else {
                                // আবার উপরে যান।
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // আমরা শীর্ষে আছি, একটি নতুন মূল নোড তৈরি করুন এবং সেখানে ধাক্কা দিন।
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // কী-মান জোড়া এবং নতুন ডান সাবট্রি পুশ করুন।
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // আবার ডানদিকের পাতায় নীচে যান।
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // প্রতিটি পুনরাবৃত্তির দৈর্ঘ্য বৃদ্ধি করুন, তা নিশ্চিত করতে মানচিত্রটি সংযুক্ত উপাদানগুলিকে ড্রপ করেও যদি পুনরুক্তিকারী পিক্সকে অগ্রসর করে।
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// দুটি সাজানো ক্রম একের মধ্যে মার্জ করার জন্য একটি পুনরুক্তি
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// যদি দুটি কী সমান হয় তবে সঠিক উত্স থেকে কী-মানটির জোড় দেয়।
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}