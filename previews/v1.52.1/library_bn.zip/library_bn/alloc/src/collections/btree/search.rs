use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` এর মতো সন্ধানের জন্য অন্তর্ভুক্ত থাকা অন্তর্ভুক্ত।
    Included(T),
    /// এক্স এক্স এক্স এর মতো সন্ধানের জন্য একচেটিয়া আবদ্ধ।
    Excluded(T),
    /// `Bound::Unbounded` এর মতো একটি নিঃশর্ত সমাবর্তন সীমাবদ্ধ।
    AllIncluded,
    /// একটি নিঃশর্ত একচেটিয়া আবদ্ধ।
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// পুনরাবৃত্তভাবে নোডের নেতৃত্বে একটি (উপ) গাছের মধ্যে একটি প্রদত্ত কী দেখায়।
    /// ম্যাচিং কেভি হ্যান্ডেল সহ একটি এক্স00 এক্স প্রদান করে, যদি থাকে তবে।
    /// অন্যথায়, কীটির সাথে থাকা edge পাতার হ্যান্ডেলটি দিয়ে একটি `GoDown` প্রদান করে।
    ///
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা অর্ডার করা হয়, যেমন একটি এক্স 100 এক্সের গাছ।
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// সর্বাধিক নোডে নেমে আসে যেখানে edge রেঞ্জের নীচের সীমানাটির সাথে মিলছে edge এর উপরের বাউন্ডের সাথে মিল রয়েছে, অর্থাৎ সবচেয়ে কাছের নোডে যা অন্তত একটি রেতে অন্তর্ভুক্ত রয়েছে।
    ///
    ///
    /// যদি পাওয়া যায় তবে সেই নোডের সাথে একটি `Ok` ফেরত দেয়, এতে edge সূচকগুলির জোড়াটি পরিসীমাটি সীমিত করে, এবং নোডটি অভ্যন্তরীণ হওয়ার ক্ষেত্রে, শিশু নোডগুলিতে অনুসন্ধান চালিয়ে যাওয়ার জন্য সমতুল্য জুড়ি।
    ///
    /// যদি খুঁজে পাওয়া যায় না, পুরো ব্যাপ্তির সাথে মিলে edge পাতায় একটি `Err` প্রদান করে।
    ///
    /// যদি গাছটি কী দ্বারা অর্ডার করা হয় তবেই ফলাফলটি অর্থবহ।
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // এই ভেরিয়েবলগুলি অন্তর্ভুক্ত করা এড়ানো উচিত।
        // আমরা ধরে নিচ্ছি যে `range` দ্বারা প্রতিবেদন করা সীমানা একই থাকবে তবে একটি প্রতিক্রিয়াশীল বাস্তবায়ন (#81138) কলগুলির মধ্যে পরিবর্তিত হতে পারে।
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// একটি ব্যাপ্তির নীচের সীমানা সীমানা নোডে একটি জেডজেডিজিজেড সন্ধান করে।
    /// `self` যদি অভ্যন্তরীণ নোড হয় তবে মিলে যাওয়া চাইল্ড নোডে অনুসন্ধান চালিয়ে যাওয়ার জন্য ব্যবহৃত নিম্ন সীমাটিও প্রদান করে।
    ///
    ///
    /// যদি গাছটি কী দ্বারা অর্ডার করা হয় তবেই ফলাফলটি অর্থবহ।
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// উপরের সীমার জন্য `find_lower_bound_edge` এর ক্লোন।
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// পুনরাবৃত্তি না করে নোডে একটি প্রদত্ত কী দেখায়।
    /// ম্যাচিং কেভি হ্যান্ডেল সহ একটি এক্স00 এক্স প্রদান করে, যদি থাকে তবে।
    /// অন্যথায়, edge এর হ্যান্ডেল সহ একটি `GoDown` প্রদান করে যেখানে কীটি পাওয়া যেতে পারে (যদি নোডটি অভ্যন্তরীণ হয়) বা কীটি সন্নিবেশ করা যায়।
    ///
    ///
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা অর্ডার করা হয়, যেমন একটি এক্স 100 এক্সের গাছ।
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// যে নোডে কী (বা সমতুল্য) বিদ্যমান থাকে সেখানে বা কী-এর মধ্যে থাকা edge সূচকটি ফেরত দেয় নোডে কেভি সূচক।
    ///
    ///
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা অর্ডার করা হয়, যেমন একটি এক্স 100 এক্সের গাছ।
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// একটি ব্যাপ্তির নীচের সীমানা সীমানা নোডে একটি জেডজেডজেডজেড সূচী সন্ধান করে।
    /// `self` যদি অভ্যন্তরীণ নোড হয় তবে মিলে যাওয়া চাইল্ড নোডে অনুসন্ধান চালিয়ে যাওয়ার জন্য ব্যবহৃত নিম্ন সীমাটিও প্রদান করে।
    ///
    ///
    /// যদি গাছটি কী দ্বারা অর্ডার করা হয় তবেই ফলাফলটি অর্থবহ।
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// উপরের সীমার জন্য `find_lower_bound_index` এর ক্লোন।
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}