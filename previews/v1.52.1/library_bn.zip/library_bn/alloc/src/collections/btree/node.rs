// আদর্শের অনুসরণ করে এটি বাস্তবায়নের চেষ্টা
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust যেহেতু প্রকৃতপক্ষে নির্ভরশীল প্রকারগুলি এবং বহুকোষী পুনরাবৃত্তি নেই, তাই আমরা প্রচুর অনর্থক হয়েছি।
//

// এই মডিউলটির একটি প্রধান লক্ষ্য গাছটিকে জেনেরিক (যদি অদ্ভুত আকারের হয়) ধারক হিসাবে আচরণ করে এবং বেশিরভাগ বি-ট্রি আক্রমণকারীদের সাথে আচরণ এড়িয়ে চলা জটিলতা এড়ানো।
//
// যেমন, এই মডিউলটি এন্ট্রিগুলি বাছাই করা হয়, কোন নোডগুলি আন্ডারফুল হতে পারে, বা এমনকি আন্ডারফুল মানে কী তাও গুরুত্ব দেয় না।যাইহোক, আমরা কয়েকটি আক্রমণকারী উপর নির্ভর করি:
//
// - গাছগুলিতে অভিন্ন depth/height থাকতে হবে।এর অর্থ এই যে কোনও প্রদত্ত নোড থেকে পাতায় প্রতিটি পাথের নীচে একই দৈর্ঘ্য রয়েছে has
// - `n` দৈর্ঘ্যের একটি নোডে `n` কী, `n` মান এবং `n + 1` প্রান্ত রয়েছে।
//   এটি বোঝায় যে একটি খালি নোডেরও কমপক্ষে একটি জেডডেজেডজেড থাকে।
//   পাতার নোডের জন্য, এক্স00 এক্স এর অর্থ কেবল নোডের মধ্যে আমরা একটি অবস্থান চিহ্নিত করতে পারি, যেহেতু পাতার কিনারা খালি থাকে এবং কোনও ডেটা উপস্থাপনের প্রয়োজন হয় না।
// একটি অভ্যন্তরীণ নোডে, একটি edge উভয়ই অবস্থান সনাক্ত করে এবং এতে একটি শিশু নোডের পয়েন্টার রয়েছে।
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// পাতাগুলির অন্তর্নিহিত উপস্থাপনা এবং অভ্যন্তরীণ নোডগুলির উপস্থাপনের অংশ।
struct LeafNode<K, V> {
    /// আমরা `K` এবং `V` তে সমবায় হতে চাই।
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// এই নোডের প্যারেন্ট নোডের `edges` অ্যারেতে সূচক।
    /// `*node.parent.edges[node.parent_idx]` `node` এর মতো একই জিনিস হওয়া উচিত।
    /// এটি কেবলমাত্র `parent` নন-শূন্য হলে আরম্ভ করার গ্যারান্টিযুক্ত।
    parent_idx: MaybeUninit<u16>,

    /// এই নোড স্টোরগুলিতে কী এবং মানগুলির সংখ্যা।
    len: u16,

    /// অ্যারে নোডের আসল ডেটা সংরক্ষণ করে।
    /// প্রতিটি অ্যারের কেবলমাত্র প্রথম `len` উপাদানগুলি আরম্ভ এবং বৈধ।
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// জায়গায় নতুন এক্স 100 এক্স শুরু করে।
    unsafe fn init(this: *mut Self) {
        // একটি সাধারণ নীতি হিসাবে, আমরা ক্ষেত্রগুলি যদি অবিচ্ছিন্নভাবে ছেড়ে দিতে পারি তবে তা ছেড়ে দিন, কারণ এটি ভালগ্রাইন্ডে ট্র্যাক করা কিছুটা দ্রুত এবং সহজ হওয়া উচিত।
        //
        unsafe {
            // প্যারেন্ট_আইডিএক্স, কীগুলি এবং ভ্যালসগুলি সমস্তই হতে পারে ইউএনইনিট
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// একটি নতুন বক্সেড `LeafNode` তৈরি করে।
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// অভ্যন্তরীণ নোডের অন্তর্নিহিত উপস্থাপনা।`লিফনোডের মতোই, অবিচ্ছিন্ন কী এবং মানগুলি বাদ দেওয়া রোধ করার জন্য এগুলি ed BoxedNode` এর পিছনে লুকানো উচিত।
/// এক্সএক্সএক্স-এর যে কোনও পয়েন্টারটি সরাসরি নোডের অন্তর্নিহিত `LeafNode` অংশে একটি পয়েন্টারটিতে কাস্ট করা যায়, কোডটি পাতার এবং অভ্যন্তরীণ নোডগুলিতে সাধারণভাবে কাজ করতে দেয় যার বিন্দুতে কোন দুটি পয়েন্টার নির্দেশ করছে তা পরীক্ষা না করেই।
///
/// এই বৈশিষ্ট্যটি `repr(C)` ব্যবহার করে সক্ষম করা হয়েছে।
///
#[repr(C)]
// gdb_providers.py অন্তর্নির্ধারণের জন্য এই জাতীয় নাম ব্যবহার করে।
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// এই নোডের বাচ্চাদের নির্দেশক।
    /// `len + 1` এর মধ্যে প্রারম্ভিক এবং বৈধ হিসাবে বিবেচনা করা হয়, শেষের কাছাকাছি ব্যতীত, গাছটি ধারের ধরণের `Dying` এর মাধ্যমে রাখা হয়, এর মধ্যে কিছু পয়েন্টারটি ঝুঁকছে।
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// একটি নতুন বক্সেড `InternalNode` তৈরি করে।
    ///
    /// # Safety
    /// অভ্যন্তরীণ নোডগুলির একটি আক্রমণকারী হ'ল তাদের কমপক্ষে একটি প্রাথমিক এবং বৈধ edge রয়েছে।
    /// এই ফাংশনটি এমন edge সেট আপ করে না।
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // আমাদের কেবলমাত্র ডেটা শুরু করতে হবে;প্রান্তগুলি হ'ল ইউনিনিট।
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// একটি নোডের জন্য পরিচালিত, নন-নাল পয়েন্টার।এটি হয় `LeafNode<K, V>` এর মালিকানাধীন পয়েন্টার বা `InternalNode<K, V>` এর মালিকানাধীন পয়েন্টার।
///
/// তবে `BoxedNode` এ আসলে দুটি ধরণের নোডের মধ্যে কোনটি রয়েছে তা সম্পর্কে কোনও তথ্য নেই এবং আংশিকভাবে তথ্যের এই অভাবের কারণে কোনও পৃথক প্রকার নয় এবং এর কোনও ডেস্ট্রাক্টর নেই।
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// মালিকানাধীন গাছের মূল নোড।
///
/// দ্রষ্টব্য যে এটির কোনও ডেস্ট্রাক্টর নেই এবং অবশ্যই ম্যানুয়ালি পরিষ্কার করতে হবে।
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// প্রাথমিক শূন্য থাকা নিজস্ব রুট নোড সহ একটি নতুন মালিকানাধীন গাছ ফেরত দেয়।
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` শূন্য হতে হবে না।
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// পারস্পরিকভাবে মালিকানাধীন রুট নোড ধার করে।
    /// `reborrow_mut` এর বিপরীতে, এটি নিরাপদ কারণ রিটার্ন মানটি মূলটিকে ধ্বংস করতে ব্যবহার করা যায় না এবং গাছের অন্যান্য উল্লেখ থাকতে পারে না।
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// কিছুটা পারস্পরিকভাবে মালিকানাধীন রুট নোড ধার করে।
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// অপরিবর্তনীয়ভাবে এমন একটি রেফারেন্সে স্থানান্তর যা ট্র্যাভারসালকে অনুমতি দেয় এবং ধ্বংসাত্মক পদ্ধতি এবং অন্য কিছু সরবরাহ করে।
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// পূর্ববর্তী রুট নোডের দিকে ইঙ্গিত করে একটি একক edge সহ একটি নতুন অভ্যন্তরীণ নোড যুক্ত করে, সেই নতুন নোডটিকে মূল নোড তৈরি করুন এবং এটি ফিরিয়ে দিন।
    /// এটি উচ্চতা 1 দ্বারা বৃদ্ধি করে এবং `pop_internal_level` এর বিপরীত।
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, তা বাদে আমরা ভুলে গেছি আমরা এখন অভ্যন্তরীণ:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// নতুন রুট নোড হিসাবে তার প্রথম সন্তানের ব্যবহার করে অভ্যন্তরীণ রুট নোড সরায়।
    /// যেহেতু এটি কেবলমাত্র ডাকা হবে যখন রুট নোডের কেবলমাত্র একটি শিশু থাকে তাই কোনও কী, মান এবং অন্যান্য বাচ্চাদের উপর কোনও ক্লিনআপ করা হয় না।
    ///
    /// এটি 1 দ্বারা উচ্চতা হ্রাস করে এবং `push_internal_level` এর বিপরীত।
    ///
    /// `Root` অবজেক্টে একচেটিয়া অ্যাক্সেসের প্রয়োজন তবে মূল নোডে নয়;
    /// এটি অন্য হ্যান্ডলগুলি বা মূল নোডের রেফারেন্সকে অকার্যকর করবে না।
    ///
    /// Panics যদি অভ্যন্তরীণ স্তর না থাকে, যেমন, রুট নোডটি যদি কোনও পাতা থাকে।
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // নিরাপত্তা: আমরা অভ্যন্তরীণ বলে জোর দিয়েছি।
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // নিরাপত্তা: আমরা একচেটিয়াভাবে `self` ধার নিয়েছি এবং এর ধারের ধরণটি একচেটিয়া।
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // সুরক্ষা: প্রথম edge সর্বদা শুরু হয়।
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` এক্স X01 এক্স থাকা সত্ত্বেও `NodeRef` সর্বদা `K` এবং `V` তে সমবায়ীয় হয়।
// এটি প্রযুক্তিগতভাবে ভুল, তবে `NodeRef` এর অভ্যন্তরীণ ব্যবহারের কারণে কোনওরকম অনর্থক হতে পারে না কারণ আমরা `K` এবং `V` এর চেয়ে সম্পূর্ণ জেনেরিক থাকি।
//
// যাইহোক, যখনই কোনও পাবলিক টাইপ `NodeRef` কে মোড় দেয় তখন নিশ্চিত হয়ে নিন যে এর সঠিক বৈকল্পিকতা রয়েছে।
//
/// একটি নোডের একটি রেফারেন্স।
///
/// এই ধরণের কয়েকটি পরামিতি রয়েছে যা এটি কীভাবে কাজ করে তা নিয়ন্ত্রণ করে:
/// - `BorrowType`: একটি ডামি টাইপ যা ধরণের orrowণ গ্রহণের বর্ণনা দেয় এবং আজীবন বহন করে।
///    - এটি যখন `Immut<'a>` হয়, এক্স02 এক্স মোটামুটি `&'a Node` এর মতো কাজ করে।
///    - এটি যখন `ValMut<'a>` হয়, এক্স01 এক্স কী এবং গাছের কাঠামোর সাথে মোটামুটি `&'a Node` এর মতো কাজ করে, তবে গাছের জুড়ে মানগুলির অনেকগুলি পরিবর্তনীয় রেফারেন্সকে সহাবস্থান করতে দেয়।
///    - এটি যখন `Mut<'a>` হয়, তখন `NodeRef` মোটামুটি `&'a mut Node` এর মতো কাজ করে, যদিও সন্নিবেশ পদ্ধতিগুলি একটি পরিবর্তনের জন্য পয়েন্টারকে একটি মানকে সহাবস্থান করতে দেয়।
///    - এটি যখন `Owned` হয়, এক্স02 এক্স মোটামুটি এক্স 01 এক্স এর মতো কাজ করে তবে তার কোনও ডেস্ট্রাক্টর নেই এবং ম্যানুয়ালি পরিষ্কার করতে হবে।
///    - এটি যখন `Dying` হয়, এক্স02 এক্স এখনও প্রায় `Box<Node>` এর মতো কাজ করে, তবে গাছটি কিছুটা নষ্ট করার পদ্ধতি রয়েছে এবং সাধারণ পদ্ধতিগুলি, যখন কল করা অসুরক্ষিত হিসাবে চিহ্নিত না করা হয়েছে, ভুলভাবে বলা হলে ইউবিকে ডাকতে পারে।
///
///   যেহেতু যে কোনও এক্স0 এক্স এক্স গাছের মাধ্যমে চলাচল করতে দেয়, তাই `BorrowType` কার্যকরভাবে কেবল নোডের জন্য নয়, পুরো গাছের জন্য প্রযোজ্য।
/// - `K` এবং `V`: এগুলি নোডগুলিতে সঞ্চিত কী এবং মানগুলির প্রকার।
/// - `Type`: এটি `Leaf`, `Internal`, বা `LeafOrInternal` হতে পারে।
/// এটি যখন `Leaf` হয়, তখন `NodeRef` একটি পাতার নোডের দিকে নির্দেশ করে, যখন এটি `Internal` হয় `NodeRef` কোনও অভ্যন্তরীণ নোডের দিকে নির্দেশ করে এবং যখন এটি `LeafOrInternal` হয় তখন এক্স05 এক্স উভয় প্রকার নোডের দিকে নির্দেশ করতে পারে।
///   `Type` `NodeRef` এর বাইরে ব্যবহার করার সময় নাম দেওয়া হয়েছে `NodeType`।
///
/// এক্সটেক্স এবং এক্স0 এক্স এক্স উভয়ই স্ট্যাটিক ধরণের সুরক্ষা কাজে লাগানোর জন্য আমরা কোন পদ্ধতিগুলি প্রয়োগ করি তা সীমাবদ্ধ করে।আমরা এই জাতীয় বিধিনিষেধ প্রয়োগ করতে পারি এমনভাবে সীমাবদ্ধতা রয়েছে:
/// - প্রতিটি ধরণের প্যারামিটারের জন্য, আমরা কেবল একটি পদ্ধতি সাধারণভাবে বা একটি নির্দিষ্ট ধরণের জন্য নির্ধারণ করতে পারি।
/// উদাহরণস্বরূপ, আমরা `into_kv` এর মতো কোনও পদ্ধতি সমস্ত `BorrowType` এর জন্য, বা একবারে সমস্ত জীবনযাত্রার সমস্ত ধরণের জন্য সংজ্ঞায়িত করতে পারি না, কারণ আমরা এটি `&'a` রেফারেন্স ফিরিয়ে দিতে চাই।
///   অতএব, আমরা এটি কেবল সর্বনিম্ন শক্তিশালী প্রকারের `Immut<'a>` এর জন্য সংজ্ঞায়িত করি।
/// - আমরা `Mut<'a>` থেকে `Immut<'a>` তে অন্তর্ভুক্ত জবরদস্তি পেতে পারি না।
///   অতএব, `into_kv` এর মতো কোনও পদ্ধতিতে পৌঁছাতে আমাদের আরও স্পষ্টভাবে `reborrow` কে আরও পাওয়ারফুল এক্স02 এক্সে কল করতে হবে।
///
/// `NodeRef`-এ থাকা সমস্ত পদ্ধতি যা কোনওরকম রেফারেন্স দেয়, তা হয়:
/// - `self` মান দ্বারা নিন এবং `BorrowType` দ্বারা চালিত আজীবন ফিরে আসুন।
///   কখনও কখনও, এই জাতীয় পদ্ধতি শুরু করার জন্য, আমাদের `reborrow_mut` কল করতে হবে।
/// - রেফারেন্স অনুসারে এক্স01 এক্স নিন এবং (implicitly) `BorrowType` দ্বারা চালিত আজীবন পরিবর্তে সেই রেফারেন্সটির জীবদ্দশায় ফিরে আসুন।
/// এইভাবে, orrowণ চেকার গ্যারান্টি দেয় যে `NodeRef` যতক্ষণ প্রত্যাবর্তিত রেফারেন্স ব্যবহৃত হয় ততক্ষণ orrowণ নেওয়া থাকে।
///   সন্নিবেশকে সমর্থনকারী পদ্ধতিগুলি এই নিয়মকে কোনও কাঁচা পয়েন্টার, অর্থাৎ কোনও আজীবন ছাড়াই কোনও রেফারেন্স ফিরিয়ে দিয়ে বাঁকায়।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// নোড এবং পাতাগুলির স্তর পৃথক পৃথক, নোডের একটি ধ্রুবক যা `Type` দ্বারা সম্পূর্ণরূপে বর্ণনা করা যায় না এবং নোড নিজেই সঞ্চয় করে না।
    /// আমাদের কেবল রুট নোডের উচ্চতা সংরক্ষণ করতে হবে এবং এটি থেকে প্রতিটি নোডের উচ্চতা অর্জন করতে হবে।
    /// `Type` `Leaf` হলে শূন্য এবং `Type` যদি `Internal` হয় তবে শূন্য নয় Must
    ///
    ///
    height: usize,
    /// পাতার বা অভ্যন্তরীণ নোডের পয়েন্টার।
    /// এক্স00 এক্স এর সংজ্ঞাটি নিশ্চিত করে যে পয়েন্টারটি যে কোনও উপায়েই বৈধ।
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// এক্স নং রেফারেন্সটি আনপ্যাক করুন যা `NodeRef::parent` হিসাবে প্যাক করা হয়েছিল।
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// অভ্যন্তরীণ নোডের ডেটা প্রকাশ করে।
    ///
    /// এই নোডের অন্যান্য উল্লেখগুলি অকার্যকর করতে এড়াতে একটি কাঁচা পিটিআর ফেরায় Return
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // নিরাপদ: স্ট্যাটিক নোড প্রকারটি `Internal`।
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// অভ্যন্তরীণ নোডের ডেটাতে একচেটিয়া অ্যাক্সেস ধার নেয়।
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// নোডের দৈর্ঘ্য সন্ধান করে।এটি কী বা মানগুলির সংখ্যা।
    /// প্রান্তের সংখ্যাটি `len() + 1`।
    /// মনে রাখবেন, সুরক্ষিত থাকা সত্ত্বেও, এই ফাংশনটি কল করার ফলে অনিরাপদ কোডটি তৈরি করেছে এমন পরিবর্তনীয় রেফারেন্সগুলিকে অকার্যকর করার পার্শ্ব প্রতিক্রিয়া থাকতে পারে।
    ///
    pub fn len(&self) -> usize {
        // গুরুতরভাবে, আমরা কেবলমাত্র এখানে `len` ফিল্ড অ্যাক্সেস করি।
        // যদি বোরোনটাইপটি marker::ValMut হয় তবে মানগুলির ক্ষেত্রে অসামান্য পরিবর্তনীয় উল্লেখ থাকতে পারে যা আমাদের অবশ্যই বাতিল করতে হবে না।
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// নোড এবং পাতাগুলি পৃথক পৃথক স্তরের সংখ্যা প্রদান করে।
    /// শূন্যের উচ্চতা মানে নোড নিজেই একটি পাতা।
    /// আপনি যদি উপরে শিকড় সহ গাছগুলি দেখেন তবে সংখ্যাটি বলে যে কোন উচ্চতায় নোড প্রদর্শিত হবে।
    /// আপনি যদি উপরে পাতা সহ গাছগুলি দেখেন তবে সংখ্যাটি বলে যে গাছটি নোডের ওপরে কত বেশি প্রসারিত।
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// অস্থায়ীভাবে একই নোডের অপর স্থাবর রেফারেন্স বের করে।
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// যে কোনও পাতার বা অভ্যন্তরীণ নোডের পাতার অংশটি প্রকাশ করে।
    ///
    /// এই নোডের অন্যান্য উল্লেখগুলি অকার্যকর করতে এড়াতে একটি কাঁচা পিটিআর ফেরায় Return
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // নোড অবশ্যই কমপক্ষে লিফনোড অংশের জন্য বৈধ হতে হবে।
        // এটি নোডেরফ টাইপের কোনও উল্লেখ নয় কারণ আমরা জানি না এটি অনন্য বা ভাগ করা উচিত should
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// বর্তমান নোডের পিতামাতার সন্ধান করে।
    /// যদি বর্তমান নোডের প্রকৃতপক্ষে কোনও পিতামাত থাকে তবে `Ok(handle)` প্রদান করে, যেখানে `handle` বর্তমান নোডের দিকে নির্দেশিত পিতামাতার edge এ নির্দেশ করে।
    ///
    /// মূল নোডের কোনও অভিভাবক না থাকলে `Err(self)` প্রদান করে, মূল `NodeRef` ফিরিয়ে দিবে।
    ///
    /// পদ্ধতির নামটি আপনাকে উপরে মূলের নোড দিয়ে গাছ গাছগুলি ধরে নিয়েছে।
    ///
    /// `edge.descend().ascend().unwrap()` এবং এক্স 100 এক্স উভয়েরই সাফল্যের সাথে কিছু করা উচিত নয়।
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // আমাদের নোডগুলিতে কাঁচা পয়েন্টার ব্যবহার করতে হবে কারণ, যদি বোর্নটাইপটি marker::ValMut হয় তবে মানগুলির ক্ষেত্রে অসামান্য পরিবর্তনীয় উল্লেখ থাকতে পারে যা আমাদের অবৈধ করতে হবে না।
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// নোট করুন যে `self` অবশ্যই নিরবচ্ছিন্ন হতে হবে।
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// নোট করুন যে `self` অবশ্যই নিরবচ্ছিন্ন হতে হবে।
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// যে কোনও পাতার পাতার অংশ বা অভ্যন্তরীণ নোড অপরিবর্তনীয় গাছে প্রকাশ করে oses
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // নিরাপদ: এই গাছের কোনও `Immut` হিসাবে ধার করা কোনও পরিবর্তনের উল্লেখ থাকতে পারে না।
        unsafe { &*ptr }
    }

    /// নোডে সঞ্চিত কীগুলিতে একটি ভিউ ধার করে।
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// এক্স00 এক্স এর অনুরূপ, নোডের প্যারেন্ট নোডের একটি রেফারেন্স পাওয়া যায়, তবে প্রক্রিয়াটিতে বর্তমান নোডকেও deallocates করে।
    /// এটি অনিরাপদ কারণ বর্তমান নোডটি বিচ্ছিন্ন হওয়া সত্ত্বেও এখনও অ্যাক্সেসযোগ্য হবে।
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// অনিরাপদভাবে স্থায়ী তথ্য সংকলককে জোর দেয় যে এই নোডটি একটি `Leaf`।
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// অনিরাপদভাবে স্থায়ী তথ্য সংকলককে জোর দিয়েছিল যে এই নোডটি একটি `Internal`।
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// অস্থায়ীভাবে একই নোডের জন্য আরেকটি পরিবর্তনীয় রেফারেন্স বের করে।সাবধান, এই পদ্ধতিটি যেহেতু অত্যন্ত বিপজ্জনক, দ্বিগুণ তাই যেহেতু এটি তাত্ক্ষণিকভাবে বিপজ্জনক হিসাবে দেখা যায় না।
    ///
    /// পরিবর্তনীয় পয়েন্টার গাছের চারপাশে যে কোনও জায়গায় ঘোরাঘুরি করতে পারে, প্রত্যাবর্তনকৃত পয়েন্টারটি সহজেই মূল পয়েন্টারটি ঝোলা, সীমা ছাড়িয়ে বা স্ট্যাকড orrowণ নিয়মের অধীনে অবৈধ করতে ব্যবহার করা যেতে পারে।
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef`-তে আরও একটি ধরণের পরামিতি যুক্ত করার কথা বিবেচনা করুন যা এই অসম্পূর্ণতা রোধ করে পুনর্ব্যক্ত পয়েন্টারগুলিতে নেভিগেশন পদ্ধতির ব্যবহারকে সীমাবদ্ধ করে।
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// যে কোনও পাতার বা অভ্যন্তরীণ নোডের পাতার অংশে একচেটিয়া অ্যাক্সেস ধার করে।
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // নিরাপত্তা: আমাদের সম্পূর্ণ নোডে একচেটিয়া অ্যাক্সেস রয়েছে।
        unsafe { &mut *ptr }
    }

    /// কোনও পাতার বা অভ্যন্তরীণ নোডের পাতার অংশে একচেটিয়া অ্যাক্সেস সরবরাহ করে।
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // নিরাপত্তা: আমাদের সম্পূর্ণ নোডে একচেটিয়া অ্যাক্সেস রয়েছে।
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// মূল স্টোরেজ ক্ষেত্রের কোনও উপাদানটিতে একচেটিয়া অ্যাক্সেস ধার নেয়।
    ///
    /// # Safety
    /// `index` 0. .CAPACITY এর সীমানায়
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // সুরক্ষা: কলকারী নিজে থেকে আরও পদ্ধতি কল করতে সক্ষম হবে না
        // কী স্লাইস রেফারেন্স বাদ না দেওয়া পর্যন্ত আমাদের কাছে ধারের আজীবন অনন্য অ্যাক্সেস রয়েছে।
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// নোডের মান সঞ্চয়ের ক্ষেত্রের কোনও উপাদান বা স্লাইসে একচেটিয়া অ্যাক্সেস ধার নেয়।
    ///
    /// # Safety
    /// `index` 0. .CAPACITY এর সীমানায়
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // সুরক্ষা: কলকারী নিজে থেকে আরও পদ্ধতি কল করতে সক্ষম হবে না
        // মান স্লাইস রেফারেন্স বাদ দেওয়া পর্যন্ত, যেমন weণের আজীবন আমাদের কাছে অনন্য অ্যাক্সেস থাকে।
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge সামগ্রীগুলির জন্য নোডের সঞ্চয় স্থানের কোনও উপাদান বা স্লাইসের একচেটিয়া অ্যাক্সেস ধার নেয়।
    ///
    /// # Safety
    /// `index` 0. .Capacity + 1 এর সীমানায় রয়েছে
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // সুরক্ষা: কলকারী নিজে থেকে আরও পদ্ধতি কল করতে সক্ষম হবে না
        // edge স্লাইস রেফারেন্স বাদ না দেওয়া পর্যন্ত আমাদের কাছে ধারের আজীবন অনন্য অ্যাক্সেস রয়েছে।
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - নোডে আরও বেশি `idx` প্রাথমিক উপাদান রয়েছে।
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // অন্যান্য উপাদানগুলির অসামান্য রেফারেন্সের সাথে অ্যালিজিং এড়ানোর জন্য আমরা কেবলমাত্র সেই উপাদানটির একটি রেফারেন্স তৈরি করি যা বিশেষত পূর্ববর্তী পুনরাবৃত্তিতে কলারে ফিরে আসে।
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ইস্যু #74679 এর কারণে আমাদের অবশ্যই আনসাইজড অ্যারে পয়েন্টারগুলিতে বাধ্য করতে হবে।
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// নোডের দৈর্ঘ্যে একচেটিয়া অ্যাক্সেস ধার নেয়।
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// নোডের অন্যান্য রেফারেন্সগুলিকে অবৈধ না করে নোডের লিঙ্কটিকে তার পিতামাতা edge এ সেট করে।
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// এর প্যারেন্ট edge এর মূলের লিঙ্কটি সাফ করে।
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// নোডের শেষে একটি কী-মান জুটি যুক্ত করে।
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// এক্স 100 এক্স দ্বারা প্রত্যাবর্তিত প্রতিটি আইটেম নোডের জন্য একটি বৈধ edge সূচক।
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// নোডের শেষে, এই জোড়ার ডানদিকে যেতে একটি কী-মান জুটি এবং একটি edge যুক্ত করে।
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// নোডটি একটি `Internal` নোড বা `Leaf` নোড কিনা তা পরীক্ষা করে।
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// কোনও নোডের মধ্যে একটি নির্দিষ্ট কী-মান জোড় বা edge এর একটি উল্লেখ।
/// `Node` প্যারামিটারটি অবশ্যই `NodeRef` হওয়া উচিত, অন্যদিকে `Type` `KV` (কী-মান জোড়ায় একটি হ্যান্ডেল নির্দেশকারী) বা `Edge` (জেডজেডজেডজেডে একটি হ্যান্ডেল নির্দেশকারী) হতে পারে।
///
/// মনে রাখবেন যে এমনকি `Leaf` নোডেও `Edge` হ্যান্ডেল থাকতে পারে।
/// চাইল্ড নোডে একটি পয়েন্টার উপস্থাপনের পরিবর্তে, এগুলি এমন জায়গাগুলি উপস্থাপন করে যেখানে শিশু পয়েন্টারগুলি মূল-মান জোড়াগুলির মধ্যে চলে।
/// উদাহরণস্বরূপ, দৈর্ঘ্য 2 সহ একটি নোডে, 3 টি সম্ভব edge অবস্থান থাকবে, নোডের বামে একটি, দুটি জোড়ার মধ্যে একটি এবং নোডের ডানদিকে একটি।
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// আমাদের এক্স01 এক্সের পূর্ণ সাধারণতা প্রয়োজন নেই, কারণ একমাত্র সময় `Node` হবে `ক্লোনযোগ্য যখন তখনই তা পরিবর্তনযোগ্য রেফারেন্স হয় এবং তাই `Copy`।
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// এই হ্যান্ডেলটি নির্দেশ করে যে নোডে edge বা কী-মান জুটি রয়েছে তা পুনরুদ্ধার করে।
    pub fn into_node(self) -> Node {
        self.node
    }

    /// নোডে এই হ্যান্ডেলটির অবস্থান ফেরত দেয়।
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` এ কী-মান জোড়ায় একটি নতুন হ্যান্ডেল তৈরি করে।
    /// অনিরাপদ কারণ কলারকে অবশ্যই এটি `idx < node.len()` নিশ্চিত করতে হবে।
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// আংশিকEq এর সর্বজনীন বাস্তবায়ন হতে পারে, তবে কেবল এই মডিউলটিতে ব্যবহৃত হয়।
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// অস্থায়ীভাবে একই স্থানে অন্য, অপরিবর্তনীয় হ্যান্ডেলটি বের করে।
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // আমরা Handle::new_kv বা Handle::new_edge ব্যবহার করতে পারি না কারণ আমরা আমাদের প্রকারটি জানি না
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// অনিরাপদভাবে স্থির তথ্যের সংকলককে জোর দিয়েছিল যে হ্যান্ডেলের নোডটি একটি `Leaf`।
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// অস্থায়ীভাবে একই স্থানে অন্য একটি পরিবর্তনীয় হ্যান্ডেল বের করে।
    /// সাবধান, এই পদ্ধতিটি যেহেতু অত্যন্ত বিপজ্জনক, দ্বিগুণ তাই যেহেতু এটি তাত্ক্ষণিকভাবে বিপজ্জনক হিসাবে দেখা যায় না।
    ///
    ///
    /// বিশদ জন্য, দেখুন `NodeRef::reborrow_mut`।
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // আমরা Handle::new_kv বা Handle::new_edge ব্যবহার করতে পারি না কারণ আমরা আমাদের প্রকারটি জানি না
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` এ একটি edge এ একটি নতুন হ্যান্ডেল তৈরি করে।
    /// অনিরাপদ কারণ কলারকে অবশ্যই এটি `idx <= node.len()` নিশ্চিত করতে হবে।
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// একটি edge সূচক দেওয়া হয়েছে যেখানে আমরা সক্ষমতায় ভরা নোডে সন্নিবেশ করতে চাই, একটি বিভক্ত পয়েন্টের একটি সংবেদনশীল কেভি সূচক গণনা করি এবং যেখানে সন্নিবেশ সম্পাদন করব।
///
/// বিভাজন পয়েন্টের লক্ষ্যটি তার মূল এবং মানটি প্যারেন্ট নোডে শেষ হওয়ার জন্য;
/// বিভাজন পয়েন্টের বামে কী, মান এবং প্রান্তগুলি বাম সন্তানের হয়ে ওঠে;
/// বিভাজন পয়েন্টের ডানদিকে কীগুলি, মানগুলি এবং প্রান্তগুলি সঠিক শিশু হয়ে যায়।
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ইস্যু #74834 এই প্রতিসামান্য নিয়মগুলি ব্যাখ্যা করার চেষ্টা করে।
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// এই edge এর ডান এবং বামে কী-মান জোড়াগুলির মধ্যে একটি নতুন কী-মান জুটি .োকান।
    /// এই পদ্ধতিটি ধরে নিয়েছে যে নতুন জুটির ফিট করার জন্য নোডে পর্যাপ্ত জায়গা রয়েছে।
    ///
    /// প্রত্যাবর্তিত পয়েন্টার সন্নিবেশ করা মানকে নির্দেশ করে।
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// এই edge এর ডান এবং বামে কী-মান জোড়াগুলির মধ্যে একটি নতুন কী-মান জুটি .োকান।
    /// পর্যাপ্ত জায়গা না থাকলে এই পদ্ধতিটি নোডকে বিভক্ত করে।
    ///
    /// প্রত্যাবর্তিত পয়েন্টার সন্নিবেশ করা মানকে নির্দেশ করে।
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// এই edge এর সাথে লিঙ্ক হওয়া চাইল্ড নোডে প্যারেন্ট পয়েন্টার এবং সূচি ঠিক করে।
    /// প্রান্তগুলির ক্রম পরিবর্তন করা হলে এটি কার্যকর হয়,
    fn correct_parent_link(self) {
        // নোডের অন্যান্য উল্লেখগুলি অবৈধ না করে ব্যাকপয়েন্টার তৈরি করুন।
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// একটি নতুন কী-মান জুটি এবং একটি জেডজেডজেডজেড সন্নিবেশ করান যা এই জেডজেডজেডজেডের মধ্যে এই নতুন জোড়ার ডানদিকে যাবে এবং এই জেডডেজ0 জেড এর ডানদিকে কী-মান জোড় যুক্ত করবে।
    /// এই পদ্ধতিটি ধরে নিয়েছে যে নতুন জুটির ফিট করার জন্য নোডে পর্যাপ্ত জায়গা রয়েছে।
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// একটি নতুন কী-মান জুটি এবং একটি জেডজেডজেডজেড সন্নিবেশ করান যা এই জেডজেডজেডজেডের মধ্যে এই নতুন জোড়ার ডানদিকে যাবে এবং এই জেডডেজ0 জেড এর ডানদিকে কী-মান জোড় যুক্ত করবে।
    /// পর্যাপ্ত জায়গা না থাকলে এই পদ্ধতিটি নোডকে বিভক্ত করে।
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// এই edge এর ডান এবং বামে কী-মান জোড়াগুলির মধ্যে একটি নতুন কী-মান জুটি .োকান।
    /// পর্যাপ্ত জায়গা না থাকলে এই পদ্ধতিটি নোডকে বিভক্ত করে এবং মূলটি পৌঁছানো অবধি অভিভাবক নোডে বিভক্ত অংশটি recোকানোর চেষ্টা করে until
    ///
    ///
    /// যদি ফিরে আসা ফলাফলটি একটি `Fit` হয় তবে এর হ্যান্ডেলের নোডটি এই জেডজেডজেডজেডের নোড বা পূর্বপুরুষ হতে পারে।
    /// যদি প্রত্যাশিত ফলাফলটি একটি `Split` হয় তবে এক্স01 এক্স ক্ষেত্রটি মূল নোড হবে।
    /// প্রত্যাবর্তিত পয়েন্টার সন্নিবেশ করা মানকে নির্দেশ করে।
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// এই edge দ্বারা নির্দেশিত নোডটি সন্ধান করে।
    ///
    /// পদ্ধতির নামটি আপনাকে উপরে মূলের নোড দিয়ে গাছ গাছগুলি ধরে নিয়েছে।
    ///
    /// `edge.descend().ascend().unwrap()` এবং এক্স 100 এক্স উভয়েরই সাফল্যের সাথে কিছু করা উচিত নয়।
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // আমাদের নোডগুলিতে কাঁচা পয়েন্টার ব্যবহার করতে হবে কারণ, যদি বোর্নটাইপটি marker::ValMut হয় তবে মানগুলির ক্ষেত্রে অসামান্য পরিবর্তনীয় উল্লেখ থাকতে পারে যা আমাদের অবৈধ করতে হবে না।
        // উচ্চতার ক্ষেত্রটি অ্যাক্সেস করার কোনও চিন্তা নেই কারণ সেই মানটি অনুলিপি করা হয়েছে।
        // সাবধান হন, একবার নোড পয়েন্টারটি অবজ্ঞা করা হয়ে গেলে, আমরা একটি রেফারেন্স (Rust ইস্যু #73987) দিয়ে প্রান্তগুলি অ্যারে অ্যাক্সেস করি এবং অ্যারের ভিতরে বা এর বাইরে অন্য কোনও রেফারেন্স অকার্যকর করি, এর আশেপাশে থাকা উচিত।
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // আমরা পৃথক কী এবং মান পদ্ধতিগুলি কল করতে পারি না, কারণ দ্বিতীয়টিকে কল করা প্রথমে ফিরে আসা রেফারেন্সকে অকার্যকর করে দেয়।
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// কে এবং হ্যান্ডেলটি যে কী এবং মানটি উল্লেখ করে তার প্রতিস্থাপন করুন।
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// লিফের ডেটা যত্ন নিয়ে নির্দিষ্ট `NodeType` এর জন্য এক্স01 এক্স বাস্তবায়নে সহায়তা করে।
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// অন্তর্নিহিত নোডকে তিন ভাগে বিভক্ত করুন:
    ///
    /// - নোডটি কেবলমাত্র এই হ্যান্ডেলের বাম দিকের মূল-মান জোড়া রাখার জন্য কাটা হয়েছে।
    /// - এই হ্যান্ডেলটি দ্বারা নির্দেশিত কী এবং মানটি বের করা হয়েছে।
    /// - এই হ্যান্ডেলের ডানদিকে সমস্ত কী-মান জোড় একটি নতুন বরাদ্দ নোডে রাখা হয়েছে।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// এই হ্যান্ডেলের দ্বারা নির্দেশিত মূল-মান যুগলটি সরান এবং কী-মান জুটিটি ভেঙে পড়েছে এমন edge এর সাথে এটি ফিরিয়ে দেয়।
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// অন্তর্নিহিত নোডকে তিন ভাগে বিভক্ত করুন:
    ///
    /// - নোডটি কেবলমাত্র এই হ্যান্ডেলের বামে প্রান্ত এবং কী-মান জোড়া যুক্ত করতে কাটা হয়েছে।
    /// - এই হ্যান্ডেলটি দ্বারা নির্দেশিত কী এবং মানটি বের করা হয়েছে।
    /// - এই হ্যান্ডেলের ডানদিকে সমস্ত প্রান্ত এবং কী-মান জোড়া একটি নতুন বরাদ্দ নোডে রাখা হয়।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// একটি অভ্যন্তরীণ কী-মান জুটির চারপাশে ভারসাম্য ক্রিয়াকলাপটি মূল্যায়ন এবং সম্পাদনের জন্য একটি সেশন প্রতিনিধিত্ব করে।
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// একটি সন্তানের হিসাবে নোডের সাথে জড়িত একটি ভারসাম্যপূর্ণ প্রেক্ষাপট বেছে নেয়, এইভাবে কেভিটির মধ্যে অবিলম্বে বাম বা পিতামাতার নোডের ডানদিকে।
    /// কোনও পিতামাতা না থাকলে একটি `Err` প্রদান করে।
    /// Panics পিতা বা মাতা খালি থাকলে।
    ///
    /// বাম দিকটি অগ্রাধিকার দেয়, প্রদত্ত নোডটি যদি কোনওভাবে নীচের দিকে থাকে তবে সর্বোত্তম হতে পারে, যার অর্থ এখানে কেবলমাত্র তার বাম ভাইবালীর চেয়ে কম উপাদান রয়েছে এবং ডান ভাইবিনের চেয়ে যদি সেগুলি বিদ্যমান থাকে।
    /// সেক্ষেত্রে বাম ভাইবোনের সাথে মিশে যাওয়া আরও দ্রুততর হয়, যেহেতু আমাদের কেবল নোডের এন উপাদানগুলিকে ডান দিকে সরিয়ে পরিবর্তে এন এর উপাদানগুলির সামনে নিয়ে যাওয়ার পরিবর্তে কেবল স্থানান্তরিত করতে হবে।
    /// বাম ভাইবোন থেকে চুরি করাও সাধারণত দ্রুত হয়, যেহেতু আমাদের কেবল নোডের এন উপাদানগুলি ডান দিকে স্থানান্তরিত করতে হবে, পরিবর্তে ভাইবোনদের উপাদানগুলির মধ্যে কমপক্ষে এন বামে স্থানান্তরিত করা।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// একত্রিত হওয়া সম্ভব কিনা, অর্থাত্, উভয় সংলগ্ন শিশু নোডের সাথে কেন্দ্রীয় কেভি সংযুক্ত করার জন্য নোডে পর্যাপ্ত জায়গা রয়েছে কিনা তা প্রত্যাবর্তন করে।
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// একত্রীকরণ সম্পাদন করে এবং কী বন্ধ করতে হবে তা স্থগিত করতে দেয়।
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // সুরক্ষা: সংযুক্ত নোডগুলির উচ্চতা উচ্চতার নীচে
                // এই edge এর নোডের, এভাবে শূন্যের উপরে, সুতরাং এগুলি অভ্যন্তরীণ।
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// পিতামাতার কী-মান জুটি এবং সংলগ্ন শিশু নোড উভয়কে বাম চাইল্ড নোডে মার্জ করে এবং সঙ্কুচিত প্যারেন্ট নোডকে ফিরিয়ে দেয়।
    ///
    ///
    /// Panics যদি না আমরা `.can_merge()` না করি।
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// পিতামাতার কী-মান জুটি এবং সংলগ্ন শিশু নোড উভয়কে বাম চাইল্ড নোডে মার্জ করে এবং সেই শিশু নোডকে ফিরিয়ে দেয়।
    ///
    ///
    /// Panics যদি না আমরা `.can_merge()` না করি।
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// পিতা-মাতার কী-মান জুটি এবং সংলগ্ন শিশু নোড উভয়কে বাম চাইল্ড নোডে মার্জ করে এবং ট্র্যাকড চাইল্ড edge শেষ হয়ে যাওয়া সেই শিশু নোডে edge হ্যান্ডেলটি ফেরত দেয়,
    ///
    ///
    /// Panics যদি না আমরা `.can_merge()` না করি।
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// পুরানো পিতা-মাতার কী-মান জোড়টিকে ডান সন্তানের দিকে ঠেলে দিয়ে বাম সন্তানের কাছ থেকে একটি মূল-মান জুটি সরিয়ে দেয় এবং এটি পিতামাতার কী-মান স্টোরেজে রাখে।
    ///
    /// ডান সন্তানের সাথে edge এ একটি হ্যান্ডেল ফিরিয়ে দেয় যেখানে `track_right_edge_idx` দ্বারা নির্দিষ্ট মূল edge শেষ হয়েছিল ended
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// পুরানো পিতা-মাতার কী-মান জোড়াকে বাম সন্তানের দিকে ঠেলা দেওয়ার সময় ডান শিশু থেকে একটি মূল-মান জুটি সরিয়ে দেয় এবং এটিকে পিতামাতার কী-মান স্টোরেজে রাখে।
    ///
    /// `track_left_edge_idx` দ্বারা উল্লিখিত বাম সন্তানের edge এ একটি হ্যান্ডেল ফিরিয়ে দেয়, যা সরেনি।
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// এটি `steal_left` এর মতো চুরি করে তবে একসাথে একাধিক উপাদান চুরি করে।
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // নিশ্চিত হয়ে নিন যে আমরা নিরাপদে চুরি করতে পারি।
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // পাতার ডেটা সরান।
            {
                // সঠিক সন্তানের মধ্যে চুরি হওয়া উপাদানগুলির জন্য জায়গা তৈরি করুন।
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // বাম শিশু থেকে উপাদানগুলি ডানদিকে সরান।
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // বাম-চুরি হওয়া জুটিকে পিতামাতার কাছে নিয়ে যান।
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // পিতামাতার কী-মান জুটি ডান সন্তানের দিকে সরান।
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // প্রান্তের চুরির জন্য জায়গা তৈরি করুন।
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // প্রান্ত চুরি করুন।
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` এর প্রতিসাম্য ক্লোন।
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // নিশ্চিত হয়ে নিন যে আমরা নিরাপদে চুরি করতে পারি।
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // পাতার ডেটা সরান।
            {
                // ডান-সর্বাধিক চুরি হওয়া জুটিকে পিতামাতার কাছে নিয়ে যান।
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // বাম সন্তানের জন্য পিতামাতার কী-মান জুটিটি সরান।
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ডান শিশু থেকে বাম দিকে উপাদানগুলি সরান।
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // ফাঁক পূরণ করুন যেখানে চুরির উপাদান ছিল।
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // প্রান্ত চুরি করুন।
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // ফাঁকগুলি পূরণ করুন যেখানে চুরি করা প্রান্তগুলি ব্যবহৃত হত।
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// এই নোডটি একটি `Leaf` নোড বলে জোর দিয়ে যে কোনও স্থিতিশীল তথ্য সরিয়ে দেয়।
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// এই নোডটি একটি `Internal` নোড বলে জোর দিয়ে যে কোনও স্থিতিশীল তথ্য সরিয়ে দেয়।
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// অন্তর্নিহিত নোডটি একটি `Internal` নোড বা `Leaf` নোড কিনা তা পরীক্ষা করে।
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` এর পরে প্রত্যয়টি একটি নোড থেকে অন্য একটিতে নিয়ে যান।`right` অবশ্যই খালি থাকতে হবে।
    /// `right` এর প্রথম edge অপরিবর্তিত রয়েছে।
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// সন্নিবেশের ফলাফল, যখন কোনও নোডের তার ক্ষমতা ছাড়িয়ে প্রসারিত করার প্রয়োজন হয়।
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` এর বামে থাকা উপাদান এবং প্রান্তগুলি সহ বিদ্যমান গাছে নোড পরিবর্তিত হয়েছে।
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // কিছু কী এবং মান বিভক্ত হয়ে গেছে, অন্য কোথাও beোকানোর জন্য।
    pub kv: (K, V),
    // `kv` এর ডান অন্তর্ভুক্ত উপাদান এবং প্রান্তগুলি সহ মালিকানাযুক্ত, আনটচড, নতুন নোড।
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // এই ধারের ধরণের নোডের উল্লেখগুলি গাছের অন্য নোডগুলিতে যাওয়ার অনুমতি দেয় কিনা।
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ট্র্যাভারসাল প্রয়োজন হয় না, এটি `borrow_mut` এর ফলাফল ব্যবহার করে ঘটে।
        // ট্র্যাভারসাল অক্ষম করে এবং কেবল শিকড়গুলিতে নতুন রেফারেন্স তৈরি করে আমরা জানি যে `Owned` টাইপের প্রতিটি রেফারেন্স একটি রুট নোডের সাথে to
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// এক অবিশ্বাস্য উপাদান দ্বারা অনুসরণ করা প্রাথমিক উপাদানগুলির একটি টুকরোতে একটি মান সন্নিবেশ করায়।
///
/// # Safety
/// স্লাইসে `idx` এরও বেশি উপাদান রয়েছে।
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// সমস্ত প্রাথমিককরণ উপাদানগুলির একটি স্লাইস থেকে একটি মানটিকে প্রত্যাহার করে এবং প্রত্যাহার করে অবিচ্ছিন্ন একটি উপাদানকে পিছনে ফেলে।
///
///
/// # Safety
/// স্লাইসে `idx` এরও বেশি উপাদান রয়েছে।
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// এক স্লাইস `distance` অবস্থানে বাম দিকে উপাদানগুলি স্থানান্তর করুন।
///
/// # Safety
/// স্লাইসে কমপক্ষে `distance` উপাদান রয়েছে।
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// এক স্লাইস `distance` পজিশনে উপাদানগুলি ডানদিকে স্থানান্তর করুন।
///
/// # Safety
/// স্লাইসে কমপক্ষে `distance` উপাদান রয়েছে।
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// `src` কে সমস্ত অবিশ্বাস্যরূপে রেখে, প্রাথমিক মানের উপাদানগুলির একটি স্লাইস থেকে অবিচ্ছিন্ন উপাদানগুলির এক টুকরোতে সমস্ত মান সরিয়ে দেয়।
///
/// `dst.copy_from_slice(src)` এর মতো কাজ করে তবে `Copy` হতে `T` প্রয়োজন হয় না।
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;