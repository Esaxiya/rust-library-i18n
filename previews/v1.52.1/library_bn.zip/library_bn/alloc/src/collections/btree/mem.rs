use core::intrinsics;
use core::mem;
use core::ptr;

/// এটি প্রাসঙ্গিক ফাংশনটি কল করে `v` অনন্য রেফারেন্সের পিছনে মান প্রতিস্থাপন করে।
///
///
/// `change` বন্ধের মধ্যে যদি কোনও panic হয় তবে পুরো প্রক্রিয়াটি বাতিল হয়ে যাবে।
#[allow(dead_code)] // চিত্র হিসাবে এবং জেডফিউচার0 জেড ব্যবহারের জন্য রাখুন
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// এটি প্রাসঙ্গিক ফাংশনটি কল করে `v` অনন্য রেফারেন্সের পিছনে থাকা মানকে প্রতিস্থাপন করে এবং সেই পথে প্রাপ্ত ফলাফলকে ফিরিয়ে দেয়।
///
///
/// `change` বন্ধের মধ্যে যদি কোনও panic হয় তবে পুরো প্রক্রিয়াটি বাতিল হয়ে যাবে।
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}