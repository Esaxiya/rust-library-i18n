use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// একটি পুনরাবৃত্তির মূল যা দুটি কঠোরভাবে আরোহণের পুনরুত্থানের আউটপুটকে একত্রিত করে, উদাহরণস্বরূপ কোনও ইউনিয়ন বা প্রতিসম পার্থক্য।
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// উভয় পুনরাবৃত্তিকে পিকেটে মোড়ানোের চেয়ে বেঞ্চমার্কগুলি দ্রুততর, সম্ভবত আমরা একটি ফিউসডেটিরেটর সীমাবদ্ধ করার পক্ষে সামর্থ রাখি।
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// উত্সের জুড়ি একত্রিত করে একটি পুনরাবৃত্তির জন্য একটি নতুন কোর তৈরি করে।
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// একত্রিত হওয়া উত্সের জোড় থেকে স্টেমিংয়ের পরবর্তী জুড়ি আইটেমগুলি দেয়।
    /// যদি উভয় প্রত্যাশিত বিকল্পের একটি মান থাকে তবে সেই মানটি সমান এবং উভয় উত্সে ঘটে।
    /// প্রত্যাশিত বিকল্পগুলির মধ্যে একটিতে যদি একটি মান থাকে তবে সেই মানটি অন্য উত্সে ঘটে না (বা উত্সগুলি কঠোরভাবে আরোহণ নয়)।
    ///
    /// যদি না ফেরত বিকল্পের একটি মান থাকে তবে পুনরাবৃত্তি শেষ হয়ে গেছে এবং পরবর্তী কলগুলি একই খালি জুটি ফিরে আসবে।
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// চূড়ান্ত পুনরাবৃত্তির `size_hint` এর জন্য একজোড়া উপরের সীমানা ফেরত দেয়।
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}