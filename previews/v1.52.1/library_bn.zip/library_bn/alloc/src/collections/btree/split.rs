use super::node::{ForceResult::*, Root};
use super::search::SearchResult::*;
use core::borrow::Borrow;

impl<K, V> Root<K, V> {
    /// উভয় গাছের দৈর্ঘ্য গণনা করে যা প্রদত্ত সংখ্যক পৃথক কী-মান জোড়ায় বিভক্ত হওয়ার ফলে আসে।
    ///
    pub fn calc_split_length(
        total_num: usize,
        root_a: &Root<K, V>,
        root_b: &Root<K, V>,
    ) -> (usize, usize) {
        let (length_a, length_b);
        if root_a.height() < root_b.height() {
            length_a = root_a.reborrow().calc_length();
            length_b = total_num - length_a;
            debug_assert_eq!(length_b, root_b.reborrow().calc_length());
        } else {
            length_b = root_b.reborrow().calc_length();
            length_a = total_num - length_b;
            debug_assert_eq!(length_a, root_a.reborrow().calc_length());
        }
        (length_a, length_b)
    }

    /// প্রদত্ত কীটি এবং এর পরে কী-মান জোড়া দিয়ে একটি গাছ বিভক্ত করুন।
    /// ফলটি কেবল তখনই অর্থবহ হয় যখন গাছটি কী দ্বারা আদেশ করা হয় এবং যদি `Q` এর ক্রমটি `K` এর সাথে মিলে যায়।
    /// যদি `self` সমস্ত `BTreeMap` ট্রি আক্রমণকারীকে সম্মান করে, তবে এক্স02 এক্স এবং প্রত্যাবর্তিত ট্রি উভয়ই সেই আক্রমণকারীদের সম্মান করবে।
    ///
    ///
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q>,
    {
        let left_root = self;
        let mut right_root = Root::new_pillar(left_root.height());
        let mut left_node = left_root.borrow_mut();
        let mut right_node = right_root.borrow_mut();

        loop {
            let mut split_edge = match left_node.search_node(key) {
                // কী ডান গাছের দিকে যাচ্ছে
                Found(kv) => kv.left_edge(),
                GoDown(edge) => edge,
            };

            split_edge.move_suffix(&mut right_node);

            match (split_edge.force(), right_node.force()) {
                (Internal(edge), Internal(node)) => {
                    left_node = edge.descend();
                    right_node = node.first_edge().descend();
                }
                (Leaf(_), Leaf(_)) => break,
                _ => unreachable!(),
            }
        }

        left_root.fix_right_border();
        right_root.fix_left_border();
        right_root
    }

    /// খালি নোড সমন্বিত একটি গাছ তৈরি করে।
    fn new_pillar(height: usize) -> Self {
        let mut root = Root::new();
        for _ in 0..height {
            root.push_internal_level();
        }
        root
    }
}