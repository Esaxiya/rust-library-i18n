//! একটি বর্ধনযোগ্য রিং বাফার সহ একটি ডাবল-এন্ড সারি প্রয়োগ করা হয়েছে।
//!
//! এই সারিটিতে ধারকটির উভয় প্রান্ত থেকে *ও*(1) মোড়ক সংযোজন এবং অপসারণ রয়েছে।
//! এটিতেও *O*(1) vector এর মতো সূচি রয়েছে।
//! ধারণকৃত উপাদানগুলি অনুলিপিযোগ্য হওয়ার প্রয়োজন নেই, এবং সজ্জিত প্রকারটি প্রেরণযোগ্য হলে সারিটি প্রেরণযোগ্য হবে।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // সবচেয়ে বড় সম্ভাবনা দুটি

/// একটি বর্ধনযোগ্য রিং বাফার সহ একটি ডাবল-এন্ড সারি প্রয়োগ করা হয়েছে।
///
/// এই ধরণের "default" ব্যবহারটি একটি সারি হিসাবে কাতারে যোগ করার জন্য [`push_back`] এবং সারি থেকে সরাতে [`pop_front`] ব্যবহার করতে হবে।
///
/// [`extend`] এবং এই পদ্ধতিতে [`append`] পিছনের দিকে ধাক্কা দেয় এবং এক্স0১ এক্স এর মাধ্যমে পুনরাবৃত্তি করা সামনে থেকে পিছনে যায়।
///
/// যেহেতু `VecDeque` একটি রিং বাফার, এর উপাদানগুলি মেমরির ক্ষেত্রে অবিচ্ছিন্নভাবে আবশ্যক নয়।
/// যদি আপনি দক্ষ বাছাইয়ের মতো উপাদানগুলিকে একক টুকরো হিসাবে অ্যাক্সেস করতে চান তবে আপনি এক্স00 এক্স ব্যবহার করতে পারেন।
/// এটি `VecDeque` কে ঘোরায় যাতে এর উপাদানগুলি মোড়ানো না যায় এবং এখন-সংলগ্ন উপাদান ক্রমটিতে একটি পরিবর্তনীয় টুকরোটি ফেরত দেয়।
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // লেজ এবং মাথা বাফার মধ্যে পয়েন্টার হয়।
    // লেজ সর্বদা পঠনযোগ্য প্রথম উপাদানটির দিকে নির্দেশ করে, হেড সর্বদা নির্দেশ করে যেখানে কোথায় লেখা উচিত written
    //
    // যদি লেজ==মাথা বাফারটি খালি থাকে।রিংবফারের দৈর্ঘ্য উভয়ের মধ্যে দূরত্ব হিসাবে সংজ্ঞায়িত করা হয়।
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// স্লাইসে সমস্ত আইটেমের জন্য ডেস্ট্রাক্টর চালিত হয় যখন এটি নামানো হয় (সাধারণত বা আনওয়ানডিংয়ের সময়)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] এর জন্য ড্রপ ব্যবহার করুন
            ptr::drop_in_place(front);
        }
        // RawVec হ্রাস পরিচালনা করে
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// একটি খালি `VecDeque<T>` তৈরি করে।
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// প্রান্তিকভাবে আরও সুবিধাজনক
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// প্রান্তিকভাবে আরও সুবিধাজনক
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // শূন্য আকারের ধরণের জন্য, আমরা সর্বদা সর্বাধিক ক্ষমতাতে থাকি
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// পিটিআরটি একটি স্লাইসে পরিণত করুন
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// পিটিআরটি একটি মিউট স্লাইসে পরিণত করুন
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// বাফার থেকে একটি উপাদান সরানো
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// বাফারে একটি উপাদান লিখে, এটিকে সরানো।
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// বাফার সম্পূর্ণ ক্ষমতা সম্পন্ন হলে `true` প্রদান করে।
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// প্রদত্ত যৌক্তিক উপাদান সূচকের জন্য অন্তর্নিহিত বাফারে সূচকটি প্রদান করে।
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// প্রদত্ত যৌক্তিক উপাদান সূচক + সংযোজনের জন্য অন্তর্নিহিত বাফারে সূচকটি ফেরত দেয় Return
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// প্রদত্ত যৌক্তিক উপাদান সূচক, সাবট্রেন্ডের জন্য অন্তর্নিহিত বাফারে সূচকটি প্রদান করে।
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src থেকে dst অবধি লম্বা মেমরির একটি অবরুদ্ধ ব্লক অনুলিপি করে
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src থেকে dst অবধি লম্বা মেমরির একটি অবরুদ্ধ ব্লক অনুলিপি করে
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src থেকে গন্তব্য পর্যন্ত লম্বা মেমরির একটি সম্ভাব্য মোড়কের ব্লক অনুলিপি করে।
    /// (abs(dst - src) + লেন) অবশ্যই cap() এর চেয়ে বড় হবে না (src এবং গন্তব্যস্থানের মধ্যে সর্বাধিক এক ক্রমাগত ওভারল্যাপিং অঞ্চল থাকতে হবে)।
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src মোড়ানো হয় না, dst মোড়ানো হয় না
                //
                //        এস।।।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স ডি।
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // z0src0Z এর আগে dst, src মোড়বে না, dst মোড়কে
                //
                //
                //    এস।।।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স .. ডি।
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // জেড0src0Z dst এর আগে, src মোড়ানো হয় না, dst মোড়কে
                //
                //
                //              এস।।।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স .. ডি।
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // z0src0Z এর আগে dst, src মোড়ানো, ডিএসটি মোড়ানো হয় না
                //
                //
                //    .. এস।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স ডি।।।
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // জেড0src0Z dst এর আগে, src মোড়ানো, ডিএসটি মোড়ানো হয় না
                //
                //
                //    .. এস।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স ডি।।।
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // z0src0Z এর আগে dst, src মোড়ানো, ডিএসটি মোড়ক
                //
                //
                //    ।.. এস।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স
                // 4 এক্স 100 এক্স .. ডি।।
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // জেড0src0Z dst এর আগে, src মোড়ানো, ডিএসটি মোড়ক
                //
                //
                //    .. এস।।
                // 1 এক্স 100 এক্স
                // 2 এক্স 100 এক্স
                // 3 এক্স 100 এক্স
                // 4 এক্স 100 এক্স.. ডি।
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// আমাদের সবেমাত্র পুনরায় স্থানান্তরিত হয়েছে তা হ্যান্ডেল করতে চারপাশে মাথা এবং লেজের অংশগুলি ফ্রব করে।
    /// অনিরাপদ কারণ এটি পুরানো_রক্ষমতা বিশ্বাস করে।
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // রিং বাফার TH এর সংক্ষিপ্ততম সংলগ্ন অংশটি সরান
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] এইচটি
        //   [o o . o o o o o ]
        //          টিএইচবি [।।।ooooooo।।।।।।
        //          ] এইচটি
        //   [o o o o o . o o ]
        //              এইচটিসি এক্স 100 এক্স
        //
        //
        //
        //

        if self.tail <= self.head {
            // একটি না
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// একটি খালি `VecDeque` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// কমপক্ষে `capacity` উপাদানগুলির জন্য ফাঁকা `VecDeque` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 যেহেতু রিংবফার সর্বদা একটি স্থান খালি রাখে
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// প্রদত্ত সূচকে উপাদানটির জন্য একটি রেফারেন্স সরবরাহ করে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// প্রদত্ত সূচকে উপাদানটির একটি পরিবর্তনীয় রেফারেন্স সরবরাহ করে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i` এবং `j` সূচকগুলিতে উপাদানগুলি অদলবদল করে।
    ///
    /// `i` এবং `j` সমান হতে পারে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Panics
    ///
    /// Panics যদি কোনও সূচক সীমা ছাড়িয়ে যায়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// পুনরায় গণনা ছাড়াই `VecDeque` ধারণ করতে থাকা উপাদানগুলির সংখ্যা প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// প্রদত্ত `VecDeque`-তে সঠিকভাবে আরও `additional` আরও উপাদান forোকানোর জন্য ন্যূনতম ক্ষমতা সঞ্চয় করে capacity
    /// ক্ষমতা ইতিমধ্যে পর্যাপ্ত থাকলে কিছুই করে না।
    ///
    /// দ্রষ্টব্য যে বরাদ্দকারী সংগ্রহের চেয়ে তার চেয়ে বেশি জায়গা দিতে পারে।
    /// সুতরাং সক্ষমতা সঠিকভাবে ন্যূনতম হতে নির্ভর করা যায় না।
    /// যদি জেডফিউচার0 জেড সন্নিবেশগুলি প্রত্যাশিত হয় তবে [`reserve`] পছন্দ করুন।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতা `usize` ওভারফ্লো হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// প্রদত্ত `VecDeque`-এ অন্ততপক্ষে কমপক্ষে `additional` আরও উপাদান সন্নিবেশ করার ক্ষমতা সংরক্ষণ করে।
    /// ঘন ঘন পুনর্বিবেচনাগুলি এড়াতে সংগ্রহটি আরও স্থান সংরক্ষণ করতে পারে।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতা `usize` ওভারফ্লো হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// প্রদত্ত `VecDeque<T>` আরও সঠিক উপাদানগুলিকে `additional` Xোকানোর জন্য ন্যূনতম ক্ষমতা সংরক্ষণের চেষ্টা করে।
    ///
    /// `try_reserve_exact` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে পর্যাপ্ত থাকলে কিছুই করে না।
    ///
    /// দ্রষ্টব্য যে বরাদ্দকারী সংগ্রহের চেয়ে তার চেয়ে বেশি জায়গা দিতে পারে।
    /// সুতরাং, সামর্থ্যটি নির্ভুলভাবে ন্যূনতম হতে নির্ভর করা যায় না।
    /// যদি জেডফিউচার0 জেড সন্নিবেশগুলি প্রত্যাশিত হয় তবে `reserve` পছন্দ করুন।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতাটি `usize` ওভারফ্লো হয় বা বরাদ্দকারী একটি ব্যর্থতার কথা জানায়, তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // এখন আমরা জানি যে আমাদের জটিল কাজের মাঝখানে এটি OOM(Out-Of-Memory) করতে পারে না
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // খুবই জটিল
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// প্রদত্ত `VecDeque<T>` আরও কমপক্ষে আরও কয়েকটি উপাদান elementsোকানোর জন্য ক্ষমতা সংরক্ষণের চেষ্টা করে।
    /// ঘন ঘন পুনর্বিবেচনাগুলি এড়াতে সংগ্রহটি আরও স্থান সংরক্ষণ করতে পারে।
    /// `try_reserve` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে যথেষ্ট হলে কিছুই করে না।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতাটি `usize` ওভারফ্লো হয় বা বরাদ্দকারী একটি ব্যর্থতার কথা জানায়, তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve(data.len())?;
    ///
    ///     // এখন আমরা জানি আমাদের জটিল কাজের মাঝখানে এটি OOM করতে পারে না
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // খুবই জটিল
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` এর সক্ষমতা যতটা সম্ভব সঙ্কুচিত করে।
    ///
    /// এটি দৈর্ঘ্যের যতটা সম্ভব নিচে নেমে যাবে তবে বরাদ্দকারীটি আরও কয়েকটি উপাদানগুলির জন্য জায়গা রয়েছে তা এখনও `VecDeque` কে অবহিত করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// নিম্ন সীমা সহ `VecDeque` এর সক্ষমতা সঙ্কুচিত করে।
    ///
    /// ক্ষমতা কমপক্ষে দৈর্ঘ্য এবং সরবরাহিত মান উভয়ের হিসাবে বৃহত্তর থাকবে।
    ///
    ///
    /// যদি বর্তমান ক্ষমতা নিম্ন সীমাটির চেয়ে কম হয়, তবে এটি কোনও অপশন নয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // আমাদের কোনও ওভারফ্লো সম্পর্কে উদ্বিগ্ন হওয়ার দরকার নেই কারণ `self.len()` বা `self.capacity()` কখনই `usize::MAX` হতে পারে না।
        // রিংবফার হিসাবে +1 সর্বদা একটি স্থান খালি ছেড়ে দেয়।
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // আগ্রহের তিনটি মামলা রয়েছে:
            //   সমস্ত উপাদানগুলি কাঙ্ক্ষিত সীমার বাইরে থাকে উপাদানগুলি সুস্পষ্ট এবং মাথাটি কাঙ্ক্ষিত সীমার বাইরে থাকে উপাদানগুলি দ্বন্দ্বহীন এবং লেজটি কাঙ্ক্ষিত সীমার বাইরে থাকে is
            //
            //
            // অন্য সমস্ত সময়ে, উপাদান অবস্থানগুলি প্রভাবিত হয় না।
            //
            // ইঙ্গিত দেয় যে মাথার উপাদানগুলি সরানো উচিত।
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // উপাদানগুলি কাঙ্ক্ষিত সীমা থেকে বাইরে নিয়ে যান (টার্গেট_ক্যাপের পরে অবস্থান)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // এইচটি
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// প্রথম `len` উপাদান রেখে এবং বাকিগুলি বাদ দিয়ে `VecDeque` কে ছোট করে।
    ///
    ///
    /// যদি `len` `ভেকডেকের বর্তমান দৈর্ঘ্যের চেয়ে বেশি হয় তবে এর কোনও প্রভাব নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// স্লাইসে সমস্ত আইটেমের জন্য ডেস্ট্রাক্টর চালিত হয় যখন এটি নামানো হয় (সাধারণত বা আনওয়ানডিংয়ের সময়)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // নিরাপদ কারণ:
        //
        // * `drop_in_place` এ দেওয়া যে কোনও স্লাইস বৈধ;দ্বিতীয় ক্ষেত্রে `len <= front.len()` রয়েছে এবং `len > self.len()` এ ফিরে আসা প্রথম ক্ষেত্রে `begin <= back.len()` নিশ্চিত করে
        //
        // * ভ্যাকডেকের মাথাটি `drop_in_place` কল করার আগে সরানো হয়েছে, তাই `drop_in_place` panics যদি কোনও মান দুবার বাদ যায় না
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // প্রথম এক panics-এ কোনও ডেস্ট্রাস্টার থাকা সত্ত্বেও দ্বিতীয়ার্ধটি বাদ পড়েছে তা নিশ্চিত করুন।
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// একটি সামনের থেকে পিছনে পুনরাবৃত্তির ফিরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// একটি সামনের থেকে পিছনে পুনরাবৃত্তি ফেরত দেয় যা পরিবর্তনীয় রেফারেন্স দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // সুরক্ষা: অভ্যন্তরীণ `IterMut` সুরক্ষা আক্রমণকারী প্রতিষ্ঠিত কারণ
        // `ring` আমরা তৈরি করি আজীবন '_।
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` এর বিষয়বস্তুগুলিকে ক্রমযুক্ত একজোড়া টুকরো দেয়।
    ///
    /// যদি [`make_contiguous`] আগে বলা হয়েছিল, এক্স01 এক্স এর সমস্ত উপাদান প্রথম স্লাইসে এবং দ্বিতীয় স্লাইসটি খালি থাকবে।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` এর বিষয়বস্তুগুলিকে ক্রমযুক্ত একজোড়া টুকরো দেয়।
    ///
    /// যদি [`make_contiguous`] আগে বলা হয়েছিল, এক্স01 এক্স এর সমস্ত উপাদান প্রথম স্লাইসে এবং দ্বিতীয় স্লাইসটি খালি থাকবে।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` এ উপাদানগুলির সংখ্যা প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` খালি থাকলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// একটি পুনরুক্তি তৈরি করে যা `VecDeque` এ নির্দিষ্ট রেঞ্জটি coversেকে দেয়।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভিক পয়েন্টটি শেষ পয়েন্টের চেয়ে বেশি হয় বা শেষ বিন্দু vector দৈর্ঘ্যের চেয়ে বেশি হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // একটি সম্পূর্ণ পরিসীমা সমস্ত বিষয়বস্তু জুড়ে
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self এ আমাদের থাকা ভাগ করা রেফারেন্সটি ইটারের '_ _ এ বজায় রাখা হয়।
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// একটি পুনরুক্তি তৈরি করে যা `VecDeque` এ নির্দিষ্ট মিউটেবল রেঞ্জকে coversেকে দেয়।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভিক পয়েন্টটি শেষ পয়েন্টের চেয়ে বেশি হয় বা শেষ বিন্দু vector দৈর্ঘ্যের চেয়ে বেশি হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // একটি সম্পূর্ণ পরিসীমা সমস্ত বিষয়বস্তু জুড়ে
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // সুরক্ষা: অভ্যন্তরীণ `IterMut` সুরক্ষা আক্রমণকারী প্রতিষ্ঠিত কারণ
        // `ring` আমরা তৈরি করি আজীবন '_।
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` এ নির্দিষ্ট রেঞ্জটি সরিয়ে দেয় এবং মুছে ফেলা আইটেমগুলি দেয় এমন একটি নিকাশী আয়রেটর তৈরি করে।
    ///
    /// দ্রষ্টব্য 1: পুনরুক্তি শেষ অবধি না খাওয়া হলেও উপাদান পরিসরটি সরানো হবে।
    ///
    /// দ্রষ্টব্য 2: `Drain` মান বাদ না দেওয়া থাকলে, ডিক থেকে কতগুলি উপাদান সরানো হবে তা অনির্ধারিত। তবে এটি ধার করা expণের মেয়াদ শেষ হয়ে যায় (যেমন, `mem::forget` এর কারণে) to
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভিক পয়েন্টটি শেষ পয়েন্টের চেয়ে বেশি হয় বা শেষ বিন্দু vector দৈর্ঘ্যের চেয়ে বেশি হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // একটি সম্পূর্ণ পরিসীমা সমস্ত বিষয়বস্তু সাফ করে
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // স্মৃতি সুরক্ষা
        //
        // Drain প্রথমবার তৈরি হওয়ার পরে, Drain এর ডেস্ট্রাক্টর কখনই চালনা করতে না পারে তা নিশ্চিত করার জন্য উত্সটি দ্বৈতকে সংক্ষিপ্ত করে দেওয়া হবে যে কোনও অবিশ্রুত বা সরানো উপাদানগুলি অ্যাক্সেসযোগ্য নয়।
        //
        //
        // Drain মানগুলি অপসারণের জন্য ptr::read কে বের করে দেবে।
        // শেষ হয়ে গেলে, অবশিষ্ট তথ্যগুলি গর্তটি coverাকতে আবার অনুলিপি করা হবে এবং head/tail মানগুলি সঠিকভাবে পুনরুদ্ধার করা হবে।
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ডেকির উপাদানগুলি তিনটি ভাগে বিভক্ত:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // টি=এক্স 100 এক্স;এইচ=এক্স01 এক্স;t=drain_tail;h=drain_head
        //
        // আমরা drain_tail কে self.head হিসাবে এবং drain_head এবং self.head যথাক্রমে Drain এ পরের টেইল এবং after_head হিসাবে সঞ্চয় করি।
        // এটি কার্যকর অ্যারেগুলিও ছাঁটাই করে তোলে যে যদি Drain ফাঁস হয়ে যায় তবে আমরা drain শুরুর পরে সম্ভাব্য স্থানান্তরিত মানগুলি ভুলে গিয়েছি।
        //
        //
        //        টি ম এইচ
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain শুরু হওয়ার পরে drain সম্পূর্ণ না হওয়া এবং Drain ডেস্ট্রাক্টর চালিত হওয়া অবধি মান সম্পর্কে about
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // গুরুতরভাবে, আমরা কেবলমাত্র `self` থেকে এখানে ভাগ করা রেফারেন্স তৈরি করি এবং এটি থেকে পড়ি।
                // আমরা `self`-এ লিখি না বা কোনও পরিবর্তনীয় রেফারেন্সে পুনরায় যোগ করি না।
                // সুতরাং `deque` এর জন্য আমরা উপরে তৈরি কাঁচা পয়েন্টারটি বৈধ থাকবে remains
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// সমস্ত মান সরিয়ে `VecDeque` সাফ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// যদি `VecDeque` প্রদত্ত মানের সমান একটি উপাদান থাকে তবে `true` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// সামনের উপাদানটির জন্য একটি রেফারেন্স সরবরাহ করে বা `None` এক্স ফাঁকা থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// সামনের উপাদানটির জন্য একটি পরিবর্তনীয় রেফারেন্স সরবরাহ করে বা `None` এক্স ফাঁকা থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// `VecDeque` খালি থাকলে ব্যাক এলিমেন্টের জন্য একটি রেফারেন্স বা `None` সরবরাহ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// `VecDeque` খালি থাকলে পিছনের উপাদানটির জন্য একটি পরিবর্তনীয় রেফারেন্স বা `None` সরবরাহ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// প্রথম উপাদানটি সরিয়ে ফেরত দেয়, বা `None` `VecDeque` খালি থাকলে X
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` থেকে শেষ উপাদানটি সরিয়ে দেয় এবং এটি খালি থাকলে `None` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` এ একটি উপাদান প্রস্তুত করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` এর পিছনে একটি উপাদান যুক্ত করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: আমাদের কি `head == 0` বোঝার উচিত?
        // যে এক্স 100 এক্স সংলগ্ন?
        self.tail <= self.head
    }

    /// `VecDeque` এর যে কোনও জায়গা থেকে কোনও উপাদান সরিয়ে দেয় এবং এটিকে প্রথম উপাদান দিয়ে প্রতিস্থাপন করে returns
    ///
    ///
    /// এটি অর্ডারিং সংরক্ষণ করে না, তবে এটি *ও*(1)।
    ///
    /// `index` সীমার বাইরে থাকলে `None` প্রদান করে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` এর যে কোনও জায়গা থেকে একটি উপাদান সরিয়ে ফেলা এবং এটি শেষ উপাদান দিয়ে প্রতিস্থাপন করে returns
    ///
    ///
    /// এটি অর্ডারিং সংরক্ষণ করে না, তবে এটি *ও*(1)।
    ///
    /// `index` সীমার বাইরে থাকলে `None` প্রদান করে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` এর মধ্যে `index` এ একটি উপাদান সন্নিবেশ করে, সূচকগুলি সহ সমস্ত উপাদানকে `index` এর চেয়ে বড় বা সমান পিছনের দিকে সরিয়ে দেয়।
    ///
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Panics
    ///
    /// Panics যদি `index` `ভেকডেকের দৈর্ঘ্যের চেয়ে বেশি হয়
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // রিং বাফারে উপাদানগুলির সর্বনিম্ন সংখ্যা সরান এবং প্রদত্ত বস্তুটি সন্নিবেশ করান
        //
        // সর্বাধিক len/2 এ, 1 টি উপাদান সরানো হবে। O(min(n, n-i))
        //
        // তিনটি প্রধান মামলা রয়েছে:
        //  উপাদানসমূহ সুসংগত
        //      - বিশেষ ক্ষেত্রে যখন লেজ 0 টি হয় তবে উপাদানগুলি বিচ্ছিন্ন হয় এবং সন্নিবেশটি লেজ বিভাগে থাকে উপাদানগুলি বিচ্ছিন্ন হয় এবং সন্নিবেশটি মাথা বিভাগে থাকে
        //
        //
        // তাদের প্রত্যেকের জন্য আরও দুটি মামলা রয়েছে:
        //  সন্নিবেশ লেজের কাছাকাছি সন্নিবেশ মাথার কাছাকাছি
        //
        // কী: এইচ, এক্স00 এক্স
        //      T, self.tail o, বৈধ উপাদান I, সন্নিবেশ উপাদান A, যে উপাদানটি সন্নিবেশ বিন্দু M এর পরে হওয়া উচিত, নির্দেশিত উপাদানকে স্থানান্তরিত করা হয়েছিল
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       টিআইএইচ
                //      [একটি oooooo।।।।।।
                //      .
                //      .]
                //
                //                       এইচটি
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // সামঞ্জস্যপূর্ণ, লেজের নিকটে সন্নিবেশ করান:
                    //
                    //             টিআইএইচ
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // সামঞ্জস্যপূর্ণ, লেজ এবং লেজের নিকটে সন্নিবেশ 0:
                    //
                    //
                    //       টিআইএইচ
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       এইচটি
                    //      [o I A o o o o o . . . . . . . o]
                    //       এমএম

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // ইতিমধ্যে লেজ সরিয়ে নিয়েছে, সুতরাং আমরা কেবলমাত্র `index - 1` উপাদানগুলি অনুলিপি করি।
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // সামঞ্জস্যপূর্ণ, মাথার কাছাকাছি প্রবেশ করান:
                    //
                    //             টিআইএইচ
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       এমএমএম

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // বিচ্ছিন্ন, লেজ, লেজ বিভাগের কাছাকাছি sertোকান:
                    //
                    //                   এইচটিআই
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   এইচটি
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // বিচ্ছিন্ন, মাথার কাছাকাছি tailোকান, লেজ বিভাগ:
                    //
                    //           এইচটিআই
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             এইচটি
                    //      [o o o . . . . . . o o o o o I A]
                    //       এমএমএমএম

                    // নতুন মাথা পর্যন্ত উপাদানগুলি অনুলিপি করুন
                    self.copy(1, 0, self.head);

                    // বাফারের নীচে ফাঁকা জায়গায় সর্বশেষ উপাদানটি অনুলিপি করুন
                    self.copy(0, self.cap() - 1, 1);

                    // আইডিএক্স থেকে উপাদানগুলিকে ^ উপাদানটি অন্তর্ভুক্ত না করে এগিয়ে যেতে শেষ করুন
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // বিচ্ছিন্ন, সন্নিবেশ লেজ, মাথা বিভাগের কাছাকাছি এবং অভ্যন্তরীণ বাফারের সূচক শূন্যে রয়েছে:
                    //
                    //
                    //       আইএইচটি
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           এইচটি
                    //      [A o o o o o o o o o . . o o o I]
                    //                               এমএমএম

                    // নতুন পুচ্ছ পর্যন্ত উপাদানগুলি অনুলিপি করুন
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // বাফারের নীচে ফাঁকা জায়গায় সর্বশেষ উপাদানটি অনুলিপি করুন
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // বিচ্ছিন্ন, লেজের নিকটে সন্নিবেশ করান, মাথা বিভাগ:
                    //
                    //             আইএইচটি
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           এইচটি
                    //      [o o I A o o o o o o . . o o o o]
                    //       এমএমএমএমএমএম

                    // নতুন পুচ্ছ পর্যন্ত উপাদানগুলি অনুলিপি করুন
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // বাফারের নীচে ফাঁকা জায়গায় সর্বশেষ উপাদানটি অনুলিপি করুন
                    self.copy(self.cap() - 1, 0, 1);

                    // idx-1 থেকে উপাদানগুলিকে ^ উপাদানটি অন্তর্ভুক্ত না করে এগিয়ে যেতে শেষ করুন
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // বিচ্ছিন্ন, মাথার কাছাকাছি headোকান, মাথা বিভাগ:
                    //
                    //               আইএইচটি
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     এইচটি
                    //      [o o o o I A o o . . . . . o o o]
                    //                 এমএমএম

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // লেজ পরিবর্তন করা হয়েছে তাই আমাদের পুনরায় গণনা করা দরকার
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` থেকে উপাদানটি `index` এ সরিয়ে দেয় এবং প্রদান করে।
    /// যার অপসারণের স্থানটির নিকটতম অংশটি স্থান তৈরিতে সরানো হবে এবং সমস্ত আক্রান্ত উপাদান নতুন অবস্থানে চলে যাবে।
    ///
    /// `index` সীমার বাইরে থাকলে `None` প্রদান করে।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // তিনটি প্রধান মামলা রয়েছে:
        //  উপাদানগুলি সুস্পষ্ট হয় উপাদানগুলি সংক্রামক হয় এবং অপসারণ লেজ বিভাগে হয় উপাদানগুলি বিতর্কিত হয় এবং অপসারণটি মাথা বিভাগে থাকে
        //
        //      - বিশেষ ক্ষেত্রে যখন উপাদানগুলি প্রযুক্তিগতভাবে সুসংগত হয় তবে self.head =0 হয়
        //
        // তাদের প্রত্যেকের জন্য আরও দুটি মামলা রয়েছে:
        //  সন্নিবেশ লেজের কাছাকাছি সন্নিবেশ মাথার কাছাকাছি
        //
        // কী: এইচ, এক্স00 এক্স
        //      টি, এক্স00 এক্স ও, বৈধ উপাদান x, এলিমেন্টটি অপসারণের জন্য চিহ্নিত করা হয়েছে, সরানো হচ্ছে এমন উপাদান নির্দেশ করে এম, এলিমেন্টটি সরানো হয়েছে নির্দেশ করে
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // সামঞ্জস্যপূর্ণ, লেজ কাছাকাছি সরান:
                    //
                    //             টিআরএইচ
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // সামঞ্জস্যপূর্ণ, মাথার কাছাকাছি সরান:
                    //
                    //             টিআরএইচ
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // বিতর্কিত, লেজ, লেজ বিভাগের কাছাকাছি সরান:
                    //
                    //                   এইচটিআর
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   এইচটি
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // বিতর্কিত, মাথার কাছাকাছি সরান, মাথা বিভাগ:
                    //
                    //               আরএইচটি
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   এইচটি
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // বিতর্কিত, মাথার কাছাকাছি সরান, লেজ বিভাগ:
                    //
                    //             এইচটিআর
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           এইচটি
                    //      [o o . . . . . . . o o o o o o o]
                    //       এমএমএমএম
                    //
                    // বা আধা-অসন্তুষ্ট, মাথার পাশে, লেজ বিভাগটি সরিয়ে ফেলুন:
                    //
                    //       এইচটিআর
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // লেজ বিভাগে উপাদান আঁকুন
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // আন্ডারফ্লো প্রতিরোধ করে।
                    if self.head != 0 {
                        // প্রথম উপাদানটি খালি জায়গায় অনুলিপি করুন
                        self.copy(self.cap() - 1, 0, 1);

                        // মাথা বিভাগে উপাদানগুলি পিছনে সরিয়ে নিন
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // বিতর্কিত, লেজ, মাথা বিভাগের কাছাকাছি সরান:
                    //
                    //           আরএইচটি
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           এইচটি
                    //      [o o o o o o o o o o . . . . o o]
                    //       এমএমএমএমএম

                    // আইডিএক্স পর্যন্ত উপাদানগুলি আঁকুন
                    self.copy(1, 0, idx);

                    // শেষ উপাদানটি খালি জায়গায় অনুলিপি করুন
                    self.copy(0, self.cap() - 1, 1);

                    // শেষটি বাদ দিয়ে পুচ্ছ থেকে উপাদানগুলি এগিয়ে যেতে সরিয়ে দিন
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// প্রদত্ত সূচকে `VecDeque` কে দুটিতে বিভক্ত করে।
    ///
    /// একটি নতুন বরাদ্দ করা `VecDeque` প্রদান করে।
    /// `self` `[0, at)` উপাদান রয়েছে এবং ফিরে আসা `VecDeque` এ `[at, len)` উপাদান রয়েছে।
    ///
    /// দ্রষ্টব্য যে `self` এর ক্ষমতা পরিবর্তন হয় না।
    ///
    /// সূচক 0-এ এলিমেন্টটি সারির সামনের অংশ।
    ///
    /// # Panics
    ///
    /// `at > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` প্রথমার্ধে মিথ্যা।
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // দ্বিতীয়ার্ধের সবকটিই নিন।
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` দ্বিতীয়ার্ধে থাকা, প্রথম অর্ধে আমরা যে উপাদানগুলিকে এড়িয়ে গেছি তা ফ্যাক্টর করা দরকার।
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // ক্লিয়ারআপ যেখানে বাফারগুলির শেষ রয়েছে
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` এর সমস্ত উপাদানকে `self` এ সরান, `other` খালি রেখে।
    ///
    /// # Panics
    ///
    /// Panics যদি নিজের মধ্যে নতুন সংখ্যক উপাদানগুলির একটি এক্স 100 এক্স প্রবাহিত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // নিষ্পাপ impl
        self.extend(other.drain(..));
    }

    /// কেবলমাত্র প্রাকটিকের দ্বারা নির্দিষ্ট উপাদানগুলিকে ধরে রাখে।
    ///
    /// অন্য কথায়, সমস্ত উপাদান `e` মুছে ফেলুন যেমন `f(&e)` মিথ্যা প্রত্যাবর্তন করে।
    /// এই পদ্ধতিটি যথাযথভাবে পরিচালনা করে প্রতিটি উপাদানকে আসল ক্রমে একবারে পরিদর্শন করে এবং ধরে রাখা উপাদানগুলির ক্রম সংরক্ষণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// সঠিক অর্ডারটি কোনও সূচকের মতো বাহ্যিক অবস্থা অনুসরণ করার জন্য কার্যকর হতে পারে।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // এটি panic বা বাতিল করতে পারে
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // বাফারের আকার দ্বিগুণ করুন।
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` এর জায়গায় স্থান পরিবর্তন করে যাতে `len()` `new_len` এর সমান হয়, হয় পিছন থেকে অতিরিক্ত উপাদানগুলি সরিয়ে দিয়ে বা `generator` কল করে উত্পন্ন উপাদানগুলি সংযোজন করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// এই ডীকটির অভ্যন্তরীণ স্টোরেজটিকে পুনরায় সাজানো হয়েছে সুতরাং এটি একটি স্বতন্ত্র টুকরো, যা পরে ফিরে আসে।
    ///
    /// এই পদ্ধতিটি বরাদ্দ দেয় না এবং elementsোকানো উপাদানগুলির ক্রম পরিবর্তন করে না।এটি কোনও পরিবর্তনীয় স্লাইসটি ফেরত দেওয়ার সাথে সাথে এটি একটি ডীককে বাছাই করতে ব্যবহার করা যেতে পারে।
    ///
    /// একবার অভ্যন্তরীণ স্টোরেজটি সুস্পষ্ট হয়ে গেলে, [`as_slices`] এবং [`as_mut_slices`] পদ্ধতিগুলি `VecDeque` এর সম্পূর্ণ সামগ্রী একক টুকরোতে ফিরিয়ে দেবে।
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// একটি deque এর বিষয়বস্তু বাছাই করা।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // deque বাছাই
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // বিপরীত ক্রমে এটি বাছাই
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// সংলগ্ন টুকরোতে অপরিবর্তনীয় অ্যাক্সেস পাওয়া।
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // আমরা এখন নিশ্চিত হতে পারি যে `slice` এর মধ্যে ডেকের সমস্ত উপাদান রয়েছে, যদিও এখনও `buf` এ অবিচ্ছিন্ন অ্যাক্সেস রয়েছে।
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // এক সাথে লেজের অনুলিপি করার জন্য পর্যাপ্ত ফাঁকা জায়গা রয়েছে, এর অর্থ আমরা প্রথমে মাথাটি পিছনের দিকে সরিয়ে, এবং তারপরে পুচ্ছটিকে সঠিক অবস্থানে অনুলিপি করি।
            //
            //
            // থেকে: ডিএফজিএইচ .... এবিসি
            // প্রতি: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: আমরা বর্তমানে বিবেচনা করি না .... ABCDEFGH
            // সংগত হতে হবে কারণ `head` এই ক্ষেত্রে `0` হবে।
            // যদিও আমরা সম্ভবত এটি পরিবর্তন করতে চাইছি এটি তুচ্ছ নয় কারণ কয়েকটি জায়গা `is_contiguous` এর অর্থ প্রত্যাশা করে যে আমরা কেবল `buf[tail..head]` ব্যবহার করে টুকরো টুকরো করতে পারি।
            //
            //

            // এক সাথে মাথা কপি করার জন্য পর্যাপ্ত ফাঁকা জায়গা রয়েছে, এর অর্থ হ'ল আমরা প্রথমে পুচ্ছকে সামনে এগিয়ে নিয়ে যাব, এবং তারপরে মাথাটি সঠিক অবস্থানে অনুলিপি করব।
            //
            //
            // থেকে: এফজিএইচ .... এবিসিডিই
            // থেকে: ... ABCDEFGH।
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ফ্রি হ'ল মাথা এবং লেজ উভয়ের চেয়ে ছোট, এর অর্থ আমাদের ধীরে ধীরে লেজ এবং মাথা "swap" করতে হবে।
            //
            //
            // থেকে: EFGHI ... এবিসিডি বা এক্স 100 এক্স X
            // প্রতি: এবিসিডিডিএফজিআই ... বা এবিসিডিডিএফজিআইজিএকে।
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // সাধারণ সমস্যাটি দেখতে এই জিআইজিএইচএলএম ... এবিসিডিএফ, যেকোন অদলবদলের আগে ... জিবিজিএল, বামে জেডজেডজেডজেড টেম্প স্টোর না পৌঁছানো পর্যন্ত অবিসিডিএফজিআইজিএম ... কেএল, অদলবদল
                //                  - তারপরে একটি নতুন এক্স 100 এক্স স্টোরের সাথে অ্যালগরিদমটি পুনরায় আরম্ভ করুন কখনও কখনও ডান জেডেডজেডজেড জেড বাফারের শেষে পৌঁছলে টেম্প স্টোরটি পৌঁছে যায়, এর অর্থ আমরা কম অদলবদল দিয়ে সঠিক ক্রমে আঘাত করেছি!
                //
                // E.g
                // EF..ABCD ABCDEF .., কেবলমাত্র চারটি অদলবদলের পরে আমরা শেষ করেছি
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ডাবল-এন্ড সারিতে `mid` বাম দিকে ঘোরান।
    ///
    /// Equivalently,
    /// - আইটেম এক্স 100 এক্সকে প্রথম অবস্থানে নিয়ে আসে।
    /// - প্রথম `mid` আইটেমগুলি পোপ করে এবং এগুলি শেষের দিকে ঠেলা দেয়।
    /// - `len() - mid` জায়গা ডানদিকে ঘোরান।
    ///
    /// # Panics
    ///
    /// `mid` যদি `len()` এর চেয়ে বেশি হয়।
    /// দ্রষ্টব্য যে `mid == len()` _not_ panic করে এবং এটি কোনও অপ-রোটেশন ঘূর্ণন।
    ///
    /// # Complexity
    ///
    /// এক্স01 এক্স সময় নেয় এবং কোনও অতিরিক্ত স্থান নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ডাবল-এন্ড সারিতে `k` জায়গা ডানদিকে ঘোরান।
    ///
    /// Equivalently,
    /// - প্রথম আইটেমটি `k` এ স্থান ঘোরান।
    /// - সর্বশেষ `k` আইটেমগুলি পোপ করে এবং তাদের সামনে ধাক্কা দেয়।
    /// - বাম দিকে `len() - k` স্থান ঘোরান।
    ///
    /// # Panics
    ///
    /// `k` যদি `len()` এর চেয়ে বেশি হয়।
    /// দ্রষ্টব্য যে `k == len()` _not_ panic করে এবং এটি কোনও অপ-রোটেশন ঘূর্ণন।
    ///
    /// # Complexity
    ///
    /// এক্স01 এক্স সময় নেয় এবং কোনও অতিরিক্ত স্থান নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // নিরাপদ: নিম্নলিখিত দুটি পদ্ধতির জন্য ঘূর্ণনের পরিমাণ প্রয়োজন
    // দ্বীপের দৈর্ঘ্যের অর্ধেকের কম হবে।
    //
    // `wrap_copy` এটি `min(x, cap() - x) + copy_len <= cap()` প্রয়োজন, তবে `min` এর তুলনায় x নির্বিশেষে কখনই অর্ধেকের বেশি নয়, সুতরাং এখানে কল করা ঠিক আছে কারণ আমরা অর্ধেকের চেয়ে কম দৈর্ঘ্যের সাথে কল করছি যা কখনই অর্ধেকের চেয়ে বেশি নয়।
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// বাইনারি একটি নির্দিষ্ট উপাদানের জন্য এই বাছাই করা `VecDeque` অনুসন্ধান করে।
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।
    /// যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// চারটি উপাদানের একটি সিরিজ দেখায়।
    /// প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// আপনি যদি সাজানো ক্রম বজায় রেখে একটি সাজানো `VecDeque` এ কোনও আইটেম সন্নিবেশ করতে চান:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// বাইনারি একটি তুলনামূলক ফাংশন সহ এই সাজানো `VecDeque` অনুসন্ধান করে।
    ///
    /// তুলনাকারী ফাংশনটি অন্তর্নিহিত `VecDeque` এর সাজানোর ক্রমের সাথে সামঞ্জস্যপূর্ণ একটি আদেশ বাস্তবায়ন করা উচিত, একটি অর্ডার কোড প্রদান করে যা তার যুক্তিটি পছন্দসই লক্ষ্যমাত্রার চেয়ে `Less`, `Equal` বা `Greater` কিনা তা নির্দেশ করে।
    ///
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// চারটি উপাদানের একটি সিরিজ দেখায়।প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// বাইনারি একটি চাবি নিষ্কাশন ফাংশন সহ এই বাছাই করা `VecDeque` অনুসন্ধান করে।
    ///
    /// ধরে নেওয়া যায় যে `VecDeque` কী দ্বারা বাছাই করা হয়েছে, উদাহরণস্বরূপ একই কী এক্সট্রাকশন ফাংশনটি ব্যবহার করে [`make_contiguous().sort_by_key()`](#method.make_contiguous) দিয়ে।
    ///
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।
    /// যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// তাদের দ্বিতীয় উপাদানগুলির দ্বারা বাছাই করা জোড়াগুলির টুকরোতে চারটি উপাদানের একটি সিরিজ দেখায়।
    /// প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` এর জায়গায় স্থান পরিবর্তন করে যাতে `len()` নতুন_লেনের সমান হয়, হয় পিছন থেকে অতিরিক্ত উপাদানগুলি সরিয়ে দিয়ে বা `value` এর ক্লোনগুলি পিছনে যুক্ত করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// প্রদত্ত যৌক্তিক উপাদান সূচকের জন্য অন্তর্নিহিত বাফারে সূচকটি প্রদান করে।
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // আকার সর্বদা 2 এর শক্তি
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// বাফারে পড়তে থাকা উপাদানগুলির সংখ্যা গণনা করুন
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // আকার সর্বদা 2 এর শক্তি
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // সর্বদা তিনটি বিভাগে বিভাজ্য, উদাহরণস্বরূপ: স্ব: [a b c|d e f] অন্যান্য: এক্স01 এক্স সম্মুখ=3, মাঝারি=1, এক্স02 এক্স==এক্স04 এক্স&&এক্স05 এক্স==এক্স06 এক্স এবং&এক্স07 এক্স==এক্স00 এক্স
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // এস_স্লাইস পদ্ধতিতে ফেরত ফালিগুলিতে Hash::hash_slice ব্যবহার করা সম্ভব নয় কারণ তাদের দৈর্ঘ্য অন্যথায় অভিন্ন মাপে পৃথক হতে পারে।
        //
        //
        // হ্যাশার কেবল তার পদ্ধতিগুলিতে ঠিক একই সেট কলগুলির সমতার গ্যারান্টি দেয়।
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` সম্মুখে একটি সামনের থেকে পিছনে পুনরাবৃত্তকারী হিসাবে মান অনুসারে উপাদান দেয় umes
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // এই ফাংশনটির নৈতিক সমতুল্য হওয়া উচিত:
        //
        //      iter.into_iter() item আইটেমের জন্য
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] কে [`VecDeque<T>`] এ পরিণত করুন।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// এটি যেখানে সম্ভব পুনর্বিবেচনা এড়াতে পারে না, তবে এর শর্তগুলি কঠোর এবং পরিবর্তনের সাপেক্ষে এবং `Vec<T>` `From<VecDeque<T>>` থেকে না এসে পুনরায় স্থানান্তর না করা পর্যন্ত নির্ভর করা উচিত নয়।
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // জেডএসটিগুলিকে সক্ষমতা নিয়ে চিন্তিত হওয়ার জন্য কোনও আসল বরাদ্দ নেই, তবে `VecDeque` `Vec` এর চেয়ে বেশি দৈর্ঘ্য পরিচালনা করতে পারে না।
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // আমাদের যদি ক্ষমতা দুটি, খুব কম ক্ষুদ্রের না হয় বা কমপক্ষে একটি মুক্ত স্থান না থাকে তবে আমাদের আকার পরিবর্তন করতে হবে।
            // এটি এটি `Vec` এ থাকা অবস্থায় আমরা এটি করি যাতে আইটেমগুলি panic এ নেমে যায়।
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] কে [`Vec<T>`] এ পরিণত করুন।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// এটি কখনই পুনরায় বরাদ্দ করার প্রয়োজন হয় না, তবে যদি বৃত্তাকার বাফার বরাদ্দের শুরুতে না ঘটে তবে *ও*(*এন*) ডেটা মুভমেন্টটি করা দরকার।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // এটি একটি *ও*(1)।
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // এটির জন্য ডেটা পুনরায় সাজানো দরকার।
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}