//! মালিকানাযুক্ত নোডগুলির সাথে দ্বিগুণ-লিঙ্কযুক্ত তালিকা।
//!
//! এক্স 100 এক্স স্থির সময়ে উভয় প্রান্তে পুশিং এবং পপিংয়ের উপাদানগুলিকে অনুমতি দেয়।
//!
//! NOTE: [`Vec`] বা [`VecDeque`] ব্যবহার করা প্রায় সর্বদা আরও ভাল কারণ অ্যারে-ভিত্তিক ধারকগুলি সাধারণত দ্রুত, আরও মেমরির দক্ষ এবং সিপিইউ ক্যাশে আরও ভাল ব্যবহার করে।
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// মালিকানাযুক্ত নোডগুলির সাথে দ্বিগুণ-লিঙ্কযুক্ত তালিকা।
///
/// এক্স 100 এক্স স্থির সময়ে উভয় প্রান্তে পুশিং এবং পপিংয়ের উপাদানগুলিকে অনুমতি দেয়।
///
/// NOTE: `Vec` বা `VecDeque` ব্যবহার করা প্রায় সর্বদা আরও ভাল কারণ অ্যারে-ভিত্তিক ধারকগুলি সাধারণত দ্রুত, আরও মেমরির দক্ষ এবং সিপিইউ ক্যাশে আরও ভাল ব্যবহার করে।
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` এর উপাদানগুলির উপর একটি পুনরাবৃত্তকারী।
///
/// এই `struct` এক্স00 এক্স দ্বারা নির্মিত।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` এর পক্ষে সরান
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// একটি `LinkedList` এর উপাদানগুলির উপর একটি পরিবর্তনীয় পুনরাবৃত্তকারী।
///
/// এই `struct` এক্স00 এক্স দ্বারা নির্মিত।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // আমরা এখানে * সম্পূর্ণরূপে সম্পূর্ণ তালিকাটির মালিকানা পাই না, নোডের এক্স01 এক্স এর উল্লেখগুলি পুনরাবৃত্তকারী দ্বারা হস্তান্তরিত হয়েছে!সুতরাং এটি ব্যবহার করার সময় সতর্কতা অবলম্বন করুন;যে পদ্ধতিগুলি বলা হয় সেগুলি অবশ্যই সচেতন হতে হবে যে `element` এর এলিয়াসিং পয়েন্টার থাকতে পারে।
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// একটি `LinkedList` এর উপাদানগুলির উপর একটি মালিকানাধীন পুনরাবৃত্তকারী।
///
/// এই `struct` [`LinkedList`] পদ্ধতিতে [`LinkedList`] (`IntoIterator` trait সরবরাহ করেছেন) দ্বারা তৈরি করা হয়েছে।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// ব্যক্তিগত পদ্ধতি
impl<T> LinkedList<T> {
    /// তালিকার সামনের দিকে প্রদত্ত নোড যুক্ত করে।
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // এই পদ্ধতিটি `element`-এ পয়েন্টার আলিয়াসিংয়ের বৈধতা বজায় রাখার জন্য পুরো নোডগুলিতে পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` ওভারল্যাপিং করে নতুন মিউটযোগ্য (unique!) রেফারেন্স তৈরি করছে না।
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// তালিকার সামনের নোডটি সরিয়ে দেয় এবং ফেরত দেয়।
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // এই পদ্ধতিটি `element`-এ পয়েন্টার আলিয়াসিংয়ের বৈধতা বজায় রাখার জন্য পুরো নোডগুলিতে পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` ওভারল্যাপিং করে নতুন মিউটযোগ্য (unique!) রেফারেন্স তৈরি করছে না।
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// তালিকার পিছনে প্রদত্ত নোড যুক্ত করে।
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // এই পদ্ধতিটি `element`-এ পয়েন্টার আলিয়াসিংয়ের বৈধতা বজায় রাখার জন্য পুরো নোডগুলিতে পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` ওভারল্যাপিং করে নতুন মিউটযোগ্য (unique!) রেফারেন্স তৈরি করছে না।
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// তালিকার পিছনে নোড সরিয়ে এবং ফেরত দেয়।
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // এই পদ্ধতিটি `element`-এ পয়েন্টার আলিয়াসিংয়ের বৈধতা বজায় রাখার জন্য পুরো নোডগুলিতে পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` ওভারল্যাপিং করে নতুন মিউটযোগ্য (unique!) রেফারেন্স তৈরি করছে না।
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// বর্তমান তালিকা থেকে নির্দিষ্ট নোডটি লিঙ্কমুক্ত করে।
    ///
    /// সতর্কতা: এটি সরবরাহিত নোডটি বর্তমান তালিকার সাথে সম্পর্কিত কিনা তা পরীক্ষা করবে না।
    ///
    /// এই পদ্ধতিটি এলিয়াসিং পয়েন্টারগুলির বৈধতা বজায় রাখতে `element`-তে পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // এটি এখন আমাদের, আমরা একটি এক্স00 এক্স তৈরি করতে পারি।

        // `element` ওভারল্যাপিং করে নতুন মিউটযোগ্য (unique!) রেফারেন্স তৈরি করছে না।
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // এই নোডটি প্রধান নোড
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // এই নোডটি পুচ্ছ নোড
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// দুটি বিদ্যমান নোডের মধ্যে নোডের একটি সিরিজ বিভক্ত করে।
    ///
    /// সতর্কতা: এটি সরবরাহ করা নোড দুটি বিদ্যমান তালিকার সাথে সম্পর্কিত কিনা তা পরীক্ষা করবে না।
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // এই পদ্ধতিটি `element`-এ পয়েন্টার আলিয়াসিংয়ের বৈধতা বজায় রাখার জন্য একই সময়ে পুরো নোডের একাধিক পরিবর্তনীয় রেফারেন্স তৈরি না করার জন্য যত্ন নেয়।
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// নোডের একটি সিরিজ হিসাবে লিঙ্কযুক্ত তালিকা থেকে সমস্ত নোডকে আলাদা করে।
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // বিভক্ত নোড হ'ল দ্বিতীয় অংশের নতুন মাথা নোড
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // দ্বিতীয় অংশের প্রধান পিটিআরটি ঠিক করুন
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // বিভক্ত নোড হ'ল প্রথম অংশের নতুন পুচ্ছ নোড এবং দ্বিতীয় অংশের মাথার মালিক।
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // প্রথম অংশের লেজ পিটিআর ঠিক করুন
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// একটি খালি `LinkedList<T>` তৈরি করে।
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// একটি খালি `LinkedList` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// সমস্ত উপাদানকে `other` থেকে তালিকার শেষের দিকে নিয়ে যায়।
    ///
    /// এটি `other` থেকে সমস্ত নোডকে পুনরায় ব্যবহার করে এবং এগুলি `self` এ স্থানান্তরিত করে।
    /// এই ক্রিয়াকলাপের পরে, `other` খালি হয়ে যায়।
    ///
    /// এই ক্রিয়াকলাপটি *ও*(1) সময় এবং *ও*(1) মেমরিতে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` এখানে ঠিক আছে কারণ উভয় তালিকার সম্পূর্ণটিতে আমাদের একচেটিয়া অ্যাক্সেস রয়েছে।
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// সমস্ত উপাদানকে `other` থেকে তালিকার শুরুতে সরানো হয়।
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` এখানে ঠিক আছে কারণ উভয় তালিকার সম্পূর্ণটিতে আমাদের একচেটিয়া অ্যাক্সেস রয়েছে।
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// একটি ফরোয়ার্ড ইটারেটর সরবরাহ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// পরিবর্তনীয় রেফারেন্স সহ একটি ফরোয়ার্ড ইটারেটর সরবরাহ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// সামনের উপাদানটিতে একটি কার্সার সরবরাহ করে।
    ///
    /// তালিকাটি খালি থাকলে কার্সারটি "ghost" অ-উপাদানটির দিকে নির্দেশ করছে।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// সামনের উপাদানটিতে সম্পাদনা কার্যক্রমের সাথে একটি কার্সার সরবরাহ করে।
    ///
    /// তালিকাটি খালি থাকলে কার্সারটি "ghost" অ-উপাদানটির দিকে নির্দেশ করছে।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// পিছনের উপাদানটিতে একটি কার্সার সরবরাহ করে।
    ///
    /// তালিকাটি খালি থাকলে কার্সারটি "ghost" অ-উপাদানটির দিকে নির্দেশ করছে।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// পিছনের উপাদানটিতে সম্পাদনা কার্যক্রমের সাথে একটি কার্সার সরবরাহ করে।
    ///
    /// তালিকাটি খালি থাকলে কার্সারটি "ghost" অ-উপাদানটির দিকে নির্দেশ করছে।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` খালি থাকলে `true` প্রদান করে।
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` এর দৈর্ঘ্য প্রদান করে।
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` থেকে সমস্ত উপাদান সরিয়ে দেয়।
    ///
    /// এই অপারেশনটি *ও*(*এন*) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// যদি `LinkedList` প্রদত্ত মানের সমান একটি উপাদান থাকে তবে `true` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// সামনের উপাদানটির জন্য রেফারেন্স সরবরাহ করে বা তালিকাটি খালি থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// সামনের উপাদানটির জন্য একটি পরিবর্তনীয় রেফারেন্স সরবরাহ করে বা তালিকাটি খালি থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// পিছনের উপাদানটির জন্য রেফারেন্স সরবরাহ করে বা তালিকাটি খালি থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// পিছনের উপাদানটির জন্য একটি পরিবর্তনীয় রেফারেন্স সরবরাহ করে বা তালিকাটি খালি থাকলে `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// তালিকায় প্রথমে একটি উপাদান যুক্ত করে।
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// প্রথম উপাদানটি সরিয়ে ফেরত দেয়, অথবা তালিকাটি খালি থাকলে `None`।
    ///
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// তালিকার পিছনে একটি উপাদান যুক্ত করে।
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// একটি তালিকা থেকে শেষ উপাদানটি সরিয়ে দেয় এবং এটি খালি থাকলে `None` প্রদান করে।
    ///
    ///
    /// এই অপারেশনটি *ও*(1) সময়ে গণনা করা উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// প্রদত্ত সূচকে তালিকাটিকে দুটিতে বিভক্ত করে।
    /// সূচী সহ প্রদত্ত সূচকের পরে সমস্ত কিছু প্রদান করে।
    ///
    /// এই অপারেশনটি *ও*(*এন*) সময়ে গণনা করা উচিত।
    ///
    /// # Panics
    ///
    /// `at > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // নীচে, আমরা প্রথম বা শেষ থেকে which i-1`th নোডের দিকে পুনরাবৃত্তি করি, যার উপর নির্ভর করে দ্রুততর হবে।
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (যা একটি নতুন কাঠামো তৈরি করে) ব্যবহার না করে স্কিপিংয়ের পরিবর্তে আমরা ম্যানুয়ালি এড়িয়ে চলি যাতে স্কিপ প্রয়োগের বিশদগুলির উপর নির্ভর না করে আমরা মাঠের ক্ষেত্রটি অ্যাক্সেস করতে পারি
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // শেষ থেকে শুরু ভাল
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// প্রদত্ত সূচকে উপাদানটি সরিয়ে ফেরত দেয়।
    ///
    /// এই অপারেশনটি *ও*(*এন*) সময়ে গণনা করা উচিত।
    ///
    /// # Panics
    /// জেড 0 প্যানিক্স0 জেড যদি>> লেন হয়
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // নীচে, আমরা প্রদত্ত সূচকে নোডের দিকে পুনরাবৃত্তি করি, শুরু বা শেষ থেকে, কোনটি আরও দ্রুত হবে তার উপর নির্ভর করে।
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// এমন একটি পুনরুক্তি তৈরি করে যা কোনও উপাদান অপসারণ করা উচিত কিনা তা নির্ধারণের জন্য ক্লোজার ব্যবহার করে।
    ///
    /// যদি বন্ধটি সত্যটি ফিরে আসে, তবে উপাদানটি সরানো হবে এবং ফলন হবে।
    /// যদি ক্লোজারটি মিথ্যা প্রত্যাবর্তন করে তবে উপাদানটি তালিকায় থাকবে এবং পুনরাবৃত্তিকারী দ্বারা উত্পাদিত হবে না।
    ///
    /// দ্রষ্টব্য যে `drain_filter` আপনাকে ফিল্টার বন্ধের প্রতিটি উপাদানকে পরিবর্তিত করতে দেয়, আপনি তা রাখার বা অপসারণের বিষয়ে বিবেচনা না করেই করুন।
    ///
    ///
    /// # Examples
    ///
    /// মূল তালিকাটিকে পুনরায় ব্যবহার করে সন্ধ্যা ও প্রতিকূলতার মধ্যে একটি তালিকা বিভক্ত করা:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // orrowণ ইস্যু এড়ানো।
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // আমরা নীচে একই লুপটি চালিয়ে যান।এটি কেবল তখনই চালিত হয় যখন কোনও ধ্বংসকারী আতঙ্কিত হয়।
                // আর এক যদি panics হয় তবে এটি বাতিল হয়ে যাবে।
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ক' পেতে আনবাউন্ড আজীবন প্রয়োজন
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ক' পেতে আনবাউন্ড আজীবন প্রয়োজন
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ক' পেতে আনবাউন্ড আজীবন প্রয়োজন
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ক' পেতে আনবাউন্ড আজীবন প্রয়োজন
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// একটি `LinkedList` এর উপরে একটি কার্সার।
///
/// একটি এক্স00 এক্স একটি পুনরাবৃত্তির মতো, এটি ব্যতীত পিছনে এবং পিছনে সন্ধান করতে পারে।
///
/// কার্সার সর্বদা তালিকার দুটি উপাদান এবং যৌক্তিকভাবে বৃত্তাকার উপায়ে সূচকের মধ্যে বিশ্রাম দেয়।
/// এটি সামঞ্জস্য করার জন্য, একটি "ghost" অ-উপাদান রয়েছে যা তালিকার মাথা এবং লেজের মধ্যে `None` দেয়।
///
///
/// তৈরি করা হলে তালিকার সামনের দিকে কার্সারগুলি শুরু হয়, বা তালিকাটি খালি থাকলে "ghost" অ-উপাদান element
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// সম্পাদনা ক্রিয়াকলাপ সহ একটি `LinkedList` এর উপরে একটি কার্সার।
///
/// একটি এক্স 100 এক্স একটি পুনরাবৃত্তির মতো, এটি ব্যতীত পিছনে এবং পিছনে সন্ধান করতে পারে এবং পুনরাবৃত্তির সময় তালিকায় নিরাপদে পরিবর্তন করতে পারে except
/// কারণ এর উত্সযুক্ত উল্লেখগুলির আজীবন কেবলমাত্র অন্তর্নিহিত তালিকার পরিবর্তে তার নিজের জীবনকালের সাথে আবদ্ধ tied
/// এর অর্থ কার্সারগুলি একসাথে একাধিক উপাদান সরবরাহ করতে পারে না।
///
/// কার্সার সর্বদা তালিকার দুটি উপাদান এবং যৌক্তিকভাবে বৃত্তাকার উপায়ে সূচকের মধ্যে বিশ্রাম দেয়।
/// এটি সামঞ্জস্য করার জন্য, একটি "ghost" অ-উপাদান রয়েছে যা তালিকার মাথা এবং লেজের মধ্যে `None` দেয়।
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` এর মধ্যে কার্সার অবস্থান সূচক ফেরত দেয়।
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` এর পরবর্তী উপাদানটিতে কার্সারটি সরানো হয়।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে এটি এটিকে `LinkedList` এর প্রথম উপাদানটিতে নিয়ে যাবে।
    /// যদি এটি `LinkedList` এর শেষ উপাদানটির দিকে ইশারা করে তবে এটি এটি "ghost" অ-উপাদানগুলিতে স্থানান্তরিত করবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // আমাদের কোনও বর্তমান উপাদান ছিল না;কার্সারটি শুরু অবস্থানে বসে ছিল পরবর্তী উপাদান তালিকার প্রধান হওয়া উচিত
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // আমরা একটি পূর্ববর্তী উপাদান ছিল, সুতরাং এর এর পরবর্তী যান
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` এর পূর্ববর্তী উপাদানটিতে কার্সারটি সরানো হয়।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে এটি এটিকে `LinkedList` এর শেষ উপাদানটিতে নিয়ে যাবে।
    /// যদি এটি `LinkedList` এর প্রথম উপাদানটির দিকে ইশারা করে তবে এটি এটি "ghost" অ-উপাদানগুলিতে স্থানান্তরিত করবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // কারেন্ট নেইআমরা তালিকার শুরুতে আছি।ফলন না কিছুই এবং শেষ পর্যন্ত লাফান।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // একটি প্রাক আছেএটি উত্পাদন এবং পূর্ববর্তী উপাদান যান।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// কার্সারটি বর্তমানে নির্দেশ করে এমন উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে এটি `None` প্রদান করে।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// পরবর্তী উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি "ghost" অ-উপাদানটির দিকে ইশারা করে তবে এটি `LinkedList` এর প্রথম উপাদানটি প্রদান করে।
    /// যদি এটি `LinkedList` এর শেষ উপাদানটির দিকে ইশারা করে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// পূর্ববর্তী উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি "ghost" অ-উপাদানটির দিকে ইশারা করে তবে এটি `LinkedList` এর শেষ উপাদানটি প্রদান করে।
    /// যদি এটি `LinkedList` এর প্রথম উপাদানটির দিকে নির্দেশ করে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` এর মধ্যে কার্সার অবস্থান সূচক ফেরত দেয়।
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` এর পরবর্তী উপাদানটিতে কার্সারটি সরানো হয়।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে এটি এটিকে `LinkedList` এর প্রথম উপাদানটিতে নিয়ে যাবে।
    /// যদি এটি `LinkedList` এর শেষ উপাদানটির দিকে ইশারা করে তবে এটি এটি "ghost" অ-উপাদানগুলিতে স্থানান্তরিত করবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // আমাদের কোনও বর্তমান উপাদান ছিল না;কার্সারটি শুরু অবস্থানে বসে ছিল পরবর্তী উপাদান তালিকার প্রধান হওয়া উচিত
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // আমরা একটি পূর্ববর্তী উপাদান ছিল, সুতরাং এর এর পরবর্তী যান
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` এর পূর্ববর্তী উপাদানটিতে কার্সারটি সরানো হয়।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে এটি এটিকে `LinkedList` এর শেষ উপাদানটিতে নিয়ে যাবে।
    /// যদি এটি `LinkedList` এর প্রথম উপাদানটির দিকে ইশারা করে তবে এটি এটি "ghost" অ-উপাদানগুলিতে স্থানান্তরিত করবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // কারেন্ট নেইআমরা তালিকার শুরুতে আছি।ফলন না কিছুই এবং শেষ পর্যন্ত লাফান।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // একটি প্রাক আছেএটি উত্পাদন এবং পূর্ববর্তী উপাদান যান।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// কার্সারটি বর্তমানে নির্দেশ করে এমন উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে এটি `None` প্রদান করে।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// পরবর্তী উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি "ghost" অ-উপাদানটির দিকে ইশারা করে তবে এটি `LinkedList` এর প্রথম উপাদানটি প্রদান করে।
    /// যদি এটি `LinkedList` এর শেষ উপাদানটির দিকে ইশারা করে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// পূর্ববর্তী উপাদানটির একটি রেফারেন্স প্রদান করে।
    ///
    /// যদি কার্সারটি "ghost" অ-উপাদানটির দিকে ইশারা করে তবে এটি `LinkedList` এর শেষ উপাদানটি প্রদান করে।
    /// যদি এটি `LinkedList` এর প্রথম উপাদানটির দিকে নির্দেশ করে তবে এটি `None` প্রদান করে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// বর্তমান উপাদানটির দিকে ইঙ্গিত করে কেবল পঠনযোগ্য কার্সারটি দেয়।
    ///
    /// ফিরে আসা `Cursor` এর জীবনকালটি `CursorMut` এর সাথে আবদ্ধ, যার অর্থ এটি `CursorMut` কে ছাড়িয়ে যেতে পারে না এবং `Cursor` এক্স এর জীবদ্দশায় হিমায়িত হয়ে গেছে।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// এখন তালিকা সম্পাদনা অপারেশন

impl<'a, T> CursorMut<'a, T> {
    /// এক্সটেক্সে বর্তমানের পরে একটি নতুন উপাদান সন্নিবেশ করান।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে নতুন উপাদানটি `LinkedList` এর সামনের অংশে .োকানো হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // এক্স 100 এক্স অ-উপাদানগুলির সূচক পরিবর্তন হয়েছে।
                self.index = self.list.len;
            }
        }
    }

    /// বর্তমানের আগে `LinkedList` এ একটি নতুন উপাদান সন্নিবেশ করান।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে নতুন উপাদানটি `LinkedList` এর শেষে inোকানো হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` থেকে বর্তমান উপাদানটি সরিয়ে দেয়।
    ///
    /// যে উপাদানটি সরানো হয়েছিল তা ফিরিয়ে দেওয়া হয়েছে এবং কার্সারটি `LinkedList` এর পরবর্তী উপাদানগুলিতে নির্দেশ করতে সরানো হয়েছে।
    ///
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে কোনও উপাদান সরানো হবে না এবং `None` ফিরে আসবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// তালিকার নোডকে বিলোপ না করেই `LinkedList` থেকে বর্তমান উপাদানটি সরিয়ে দেয়।
    ///
    /// যে নোডটি সরানো হয়েছিল তা কেবলমাত্র এই নোডযুক্ত একটি নতুন `LinkedList` হিসাবে ফিরে আসবে।
    /// কার্সারটি বর্তমান `LinkedList` এর পরবর্তী উপাদানগুলিতে নির্দেশ করতে সরানো হয়েছে।
    ///
    /// যদি কার্সারটি বর্তমানে "ghost" অ-উপাদানটির দিকে নির্দেশ করছে তবে কোনও উপাদান সরানো হবে না এবং `None` ফিরে আসবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// বর্তমানের পরে প্রদত্ত `LinkedList` থেকে উপাদানগুলি সন্নিবেশ করান।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে এক্স 100 এক্স এর শুরুতে নতুন উপাদানগুলি সন্নিবেশ করা হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // এক্স 100 এক্স অ-উপাদানগুলির সূচক পরিবর্তন হয়েছে।
                self.index = self.list.len;
            }
        }
    }

    /// প্রদত্ত `LinkedList` থেকে বর্তমানের আগে উপাদানগুলি সন্নিবেশ করান।
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে নির্দেশ করছে তবে নতুন উপাদানগুলি `LinkedList` এর শেষে sertedোকানো হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// বর্তমান উপাদানটির পরে তালিকাটিকে দুটিতে বিভক্ত করে।
    /// এটি কার্সারের পরে সমস্ত কিছু নিয়ে একটি নতুন তালিকা ফিরে আসবে, মূল তালিকাটি আগে সমস্ত কিছু ধরে রাখবে।
    ///
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে ইশারা করে তবে `LinkedList` এর সম্পূর্ণ সামগ্রী সরানো হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // এক্স 100 এক্স অ-উপাদানগুলির সূচকটি 0 এ পরিবর্তিত হয়েছে।
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// বর্তমান উপাদানটির আগে তালিকায় দুটি বিভক্ত হয়।
    /// এটি কার্সারের আগে সমস্ত কিছু নিয়ে একটি নতুন তালিকা ফিরে আসবে, মূল তালিকাটি পরে সমস্ত কিছু ধরে রাখবে।
    ///
    ///
    /// যদি কার্সারটি "ghost" নন-এলিমেন্টের দিকে ইশারা করে তবে `LinkedList` এর সম্পূর্ণ সামগ্রী সরানো হবে।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// লিঙ্কলিস্টে `drain_filter` কল করে একটি পুনরাবৃত্তি উত্পাদিত।
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` রেফারেন্স aliasing সঙ্গে ঠিক আছে।
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// মান অনুসারে উপাদানগুলি ফলনকারীকে পুনরুক্তি হিসাবে তালিকা গ্রহণ করে।
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// নিশ্চিত করুন যে `LinkedList` এবং এর কেবল পঠনযোগ্য পুনরাবৃত্তি তাদের ধরণের পরামিতিগুলিতে সমবায় রয়েছে।
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}