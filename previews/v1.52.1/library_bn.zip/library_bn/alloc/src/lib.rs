//! # Rust মূল বরাদ্দ এবং সংগ্রহ লাইব্রেরি
//!
//! এই লাইব্রেরিটি হ্যাপ-বরাদ্দকৃত মানগুলি পরিচালনা করার জন্য স্মার্ট পয়েন্টার এবং সংগ্রহ সরবরাহ করে।
//!
//! এই লাইব্রেরিটি লাইবকোরের মতো সাধারণত [`std` crate](../std/index.html)-এ এর সামগ্রীগুলি পুনরায় রফতানি করা হয় বলে সরাসরি ব্যবহার করার প্রয়োজন হয় না।
//! `#![no_std]` গুণাবলী ব্যবহার করে এমন Crates তবে সাধারণত `std` এর উপর নির্ভর করে না, তাই তারা পরিবর্তে এই crate ব্যবহার করবে।
//!
//! ## বক্স করা মান
//!
//! এক্স01 এক্স টাইপটি একটি স্মার্ট পয়েন্টার টাইপ।কেবলমাত্র একটি [`Box`] এর এক জন মালিক থাকতে পারে, এবং মালিক সেই বিষয়বস্তুগুলিকে পরিবর্তিত করতে সিদ্ধান্ত নিতে পারেন, যা স্তূপে থাকে।
//!
//! এই প্রকারটি দক্ষতার সাথে থ্রেডগুলির মধ্যে প্রেরণ করা যেতে পারে কারণ একটি এক্স 100 এক্স মানের আকার পয়েন্টারের সমান।
//! গাছের মতো ডেটা স্ট্রাকচারগুলি প্রায়শই বাক্সগুলির সাহায্যে নির্মিত হয় কারণ প্রতিটি নোডে প্রায়শই একজন পিতা বা মাতা থাকে।
//!
//! ## রেফারেন্স গণনা পয়েন্টার
//!
//! [`Rc`] প্রকারটি থ্রেডের মধ্যে মেমরি ভাগ করে নেওয়ার উদ্দেশ্যে তৈরি একটি নন-থ্রেডসেসে রেফারেন্স-গণনা করা পয়েন্টার টাইপ।
//! একটি [`Rc`] পয়েন্টার এক প্রকার, `T` মোড় করে এবং কেবলমাত্র একটি ভাগ করা রেফারেন্স `&T` অ্যাক্সেসের অনুমতি দেয়।
//!
//! উত্তরাধিকারসূত্রে পরিবর্তিত রূপান্তর (যেমন [`Box`] ব্যবহার করা) কোনও অ্যাপ্লিকেশনের জন্য খুব সীমাবদ্ধ থাকে এবং এই রূপটি XTX বা [`RefCell`] টাইপগুলির সাথে মিউটেশনটি অনুমোদনের জন্য যুক্ত হয় যখন এই ধরণেরটি কার্যকর।
//!
//!
//! ## পারমাণবিকভাবে রেফারেন্স গণনা পয়েন্টার
//!
//! এক্স01 এক্স টাইপটি থ্রেডসেফের সমতুল্য [`Rc`] টাইপ।এটি [`Rc`] এর সমস্ত একই কার্যকারিতা সরবরাহ করে, কেবলমাত্র প্রকারের `T` ভাগ করার যোগ্য এটি ব্যতীত।
//! অতিরিক্ত হিসাবে,[`Arc<T>`][`Arc`] এক্স না থাকা অবস্থায় [`Arc<T>`][`Arc`] নিজেই প্রেরণযোগ্য।
//!
//! এই ধরণের অন্তর্ভুক্ত থাকা ডেটাতে ভাগ করে নেওয়া অ্যাক্সেসের অনুমতি দেয় এবং প্রায়শই মিটেক্সেসের মতো সিঙ্ক্রোনাইজেশন আদিমগুলির সাথে জুড়ে দেওয়া হয় যাতে ভাগ করা সংস্থার পরিবর্তনের অনুমতি দেওয়া হয়।
//!
//! ## Collections
//!
//! সর্বাধিক সাধারণ সাধারণ উদ্দেশ্যে ডেটা স্ট্রাকচারের প্রয়োগগুলি এই লাইব্রেরিতে সংজ্ঞায়িত করা হয়েছে।[standard collections library](../std/collections/index.html) এর মাধ্যমে সেগুলি পুনরায় রফতানি করা হয়।
//!
//! ## গাদা ইন্টারফেস
//!
//! [`alloc`](alloc/index.html) মডিউলটি নিম্ন-স্তরের ইন্টারফেসকে ডিফল্ট গ্লোবাল বরাদ্দকারীকে সংজ্ঞায়িত করে।এটি libc বরাদ্দকারী API এর সাথে সামঞ্জস্যপূর্ণ নয়।
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// প্রযুক্তিগতভাবে, এটি রুটডকের একটি বাগ: এক্সস্ট 2 এক্স ব্লকের ডাস্টাবেশনগুলি `&[T]` এর জন্য rustdoc দেখতে পেয়েছে, যার মধ্যে এই বৈশিষ্ট্যটি X01 এক্স-তে ব্যবহার করে ডকুমেন্টেশন রয়েছে এবং পাগল হয়ে যায় যে বৈশিষ্ট্য-গেটটি সক্ষম নয়।
// আদর্শভাবে, এটি অন্যান্য জেড 0 ক্রেটস0 জেড থেকে ডক্সের জন্য বৈশিষ্ট্য গেটের জন্য যাচাই করবে না, তবে যেহেতু এটি কেবল ল্যাং আইটেমের জন্যই উপস্থিত হতে পারে, তাই এটি ঠিক করার মতো মনে হয় না।
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// এই গ্রন্থাগারটি পরীক্ষা করার অনুমতি দিন

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// অন্যান্য মডিউল দ্বারা ব্যবহৃত অভ্যন্তরীণ ম্যাক্রোগুলি সহ মডিউল (অন্যান্য মডিউলগুলির আগে অন্তর্ভুক্ত করা দরকার)।
#[macro_use]
mod macros;

// নিম্ন স্তরের বরাদ্দ কৌশলগুলির জন্য গাদা সরবরাহ করা হয়েছে

pub mod alloc;

// উপরের গাদা ব্যবহার করে আদিম ধরণের

// পরীক্ষার সিএফজিতে বিল্ডিং করার সময় ল্যাং-আইটেমগুলির নকল করা এড়াতে `boxed.rs` থেকে শর্তাধীন মোডের সংজ্ঞা দেওয়া দরকার;তবে কোডটির `use boxed::Box;` ঘোষণা থাকতেও দরকার।
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}