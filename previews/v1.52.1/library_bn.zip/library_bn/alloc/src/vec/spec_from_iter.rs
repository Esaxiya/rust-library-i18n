use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter এর জন্য বিশেষায়িতকরণ trait ব্যবহৃত
///
/// ## প্রতিনিধি গ্রাফ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // একটি সাধারণ কেস একটি vector একটি ক্রিয়ায় উত্তীর্ণ হয় যা তাত্ক্ষণিকভাবে একটি vector তে পুনরায় সংগ্রহ করে।
        // ইনটোআইটারটি যদি একেবারেই উন্নত না হয় তবে আমরা এটি শর্ট সার্কিট করতে পারি।
        // এটি উন্নত হয়ে গেলে আমরা মেমরিটি পুনরায় ব্যবহার করতে এবং ডেটাটিকে সামনে নিয়ে যেতে পারি।
        // তবে আমরা কেবল তখনই করি যখন ফলিত ভাইকটির জেনেরিক ফ্রিআইট্রেটর প্রয়োগের মাধ্যমে এটি তৈরি করার চেয়ে বেশি অব্যবহৃত ক্ষমতা না থাকে।
        //
        // ভেকের বরাদ্দের আচরণটি ইচ্ছাকৃতভাবে অনির্ধারিত হওয়ায় এই সীমাবদ্ধতা কঠোরভাবে প্রয়োজনীয় নয়।
        // তবে এটি একটি রক্ষণশীল পছন্দ।
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // খালি ভিজের জন্য এক্স_০ এক্স নিজেই স্পেক_ফর্মের প্রতিনিধি হিসাবে spec_extend() ডেলিগেট করতে হবে
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// এটি `iterator.as_slice().to_vec()` ব্যবহার করে যেহেতু spec_extend অবশ্যই চূড়ান্ত ক্ষমতা + দৈর্ঘ্য সম্পর্কে যুক্তিযুক্ত আরও পদক্ষেপ নিতে হবে এবং এভাবে আরও কাজ করা উচিত।
// `to_vec()` সরাসরি সঠিক পরিমাণ বরাদ্দ করে এবং এটি ঠিক পূরণ করে।
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) সহ অন্তর্নিহিত `[T]::to_vec` পদ্ধতিটি যা এই পদ্ধতির সংজ্ঞার জন্য প্রয়োজনীয় তা উপলভ্য নয়।
    // পরিবর্তে `slice::to_vec` ফাংশনটি ব্যবহার করুন যা কেবলমাত্র cfg(test) NB এর সাথে উপলভ্য রয়েছে আরও তথ্যের জন্য slice.rs-এ slice::hack মডিউলটি দেখুন
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}