// `SetLenOnDrop` মান সুযোগের বাইরে চলে গেলে ভ্যাকের দৈর্ঘ্য সেট করুন।
//
// ধারণাটি হ'ল সেটলেনঅনড্রপের দৈর্ঘ্য ক্ষেত্রটি একটি স্থানীয় ভেরিয়েবল যা অপ্টিমাইজারটি দেখতে পাবে ভেকের ডেটা পয়েন্টারটির মাধ্যমে কোনও স্টোরের সাথে উপকরণ নেই।
// এটি ওরফে বিশ্লেষণ ইস্যু #32155 এর জন্য কার্যকর ar
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}