use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// উত্স বরাদ্দ পুনঃব্যবহারের সময় কোনও ভিসিতে পুনরাবৃত্ত পাইপলাইন সংগ্রহের জন্য বিশেষীকরণের চিহ্নিতকারী ie
/// জায়গায় পাইপলাইন চালাচ্ছে।
///
/// সোর্সইটার প্যারেন্ট trait বিশেষায়িত ক্রিয়াকলাপের জন্য বরাদ্দ অ্যাক্সেস করার প্রয়োজন যা পুনরায় ব্যবহার করতে হবে।
/// তবে বিশেষজ্ঞের বৈধ হওয়ার পক্ষে এটি যথেষ্ট নয়।
/// প্ররোচিত উপর অতিরিক্ত সীমা দেখুন।
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-অভ্যন্তরীণ SourceIter/InPlaceIterable traits কেবল অ্যাডাপ্টারের চেইন দ্বারা প্রয়োগ করা হয় <Adapter<Adapter<IntoIter>>> (সমস্ত core/std এর মালিকানাধীন)।
// অ্যাডাপ্টার বাস্তবায়নের অতিরিক্ত সীমাগুলি (`impl<I: Trait> Trait for Adapter<I>` এর বাইরে) কেবলমাত্র traits হিসাবে চিহ্নিত অন্যান্য traits এর উপর নির্ভর করে (অনুলিপি, বিশ্বাসযোগ্য র্যান্ডমএ্যাক্সেস, ফিউজডিজিটর)।
//
// I.e. চিহ্নিতকারী ব্যবহারকারীর সরবরাহিত প্রকারের লাইফটাইমের উপর নির্ভর করে না।অনুলিপিটির অনুলিপি, যা ইতিমধ্যে অন্যান্য বেশ কয়েকটি বিশেষায়নের উপর নির্ভর করে।
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds এর মাধ্যমে প্রকাশ করা যায় না এমন অতিরিক্ত প্রয়োজনীয়তা।পরিবর্তে আমরা কনস্টের উপর নির্ভর করি:
        // ক) কোন জেডএসটি নেই যেহেতু পুনরায় ব্যবহারের জন্য কোনও বরাদ্দ থাকবে না এবং পয়েন্টার গাণিতিক জেড 0 প্যানিক0 জেড হবে না খ) অলোক চুক্তি অনুসারে প্রয়োজনীয় আকারের ম্যাচ গ) অ্যালোক চুক্তির প্রয়োজন অনুসারে প্রান্তিককরণের ম্যাচ
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // আরও জেনেরিক প্রয়োগে ফলব্যাক
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // তারপর থেকে চেষ্টা ভাঁজ ব্যবহার করুন
        // - এটি কিছু পুনরাবৃত্তকারী অ্যাডাপ্টারগুলির জন্য ভাল ভেক্টরাইজ করে
        // - বেশিরভাগ অভ্যন্তরীণ পুনরাবৃত্তি পদ্ধতির বিপরীতে, এটি কেবলমাত্র একটি &mut স্ব নেয়
        // - এটি আমাদের লেখার পয়েন্টারটিকে তার অভ্যন্তরের মধ্য দিয়ে থ্রেড করতে দেয় এবং শেষ পর্যন্ত এটি ফিরে পেতে দেয়
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // পুনরাবৃত্তি সফল হয়েছে, মাথা ছাড়বেন না
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // সোর্সইটার চুক্তিটি সাবধান ছিল কিনা তা পরীক্ষা করুন: তারা না থাকলে আমরা এমনকি এটি এ পর্যন্ত তৈরি করতে পারি না
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ইনপ্লেসআইটেবল চুক্তি পরীক্ষা করুন।এটি কেবল তখনই সম্ভব যখন পুনরুক্তিকারীর উত্স পয়েন্টারটি মোটেই উন্নত advanced
        // এটি যদি বিশ্বাসযোগ্য র্যান্ডোম অ্যাক্সেসের মাধ্যমে চেক করা অ্যাক্সেস ব্যবহার করে তবে উত্স পয়েন্টারটি তার প্রাথমিক অবস্থানে থাকবে এবং আমরা এটিকে রেফারেন্স হিসাবে ব্যবহার করতে পারি না
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // উত্সের লেজুতে অবশিষ্ট থাকা মানগুলি ফেলে দিন তবে একবার আন্টোইটার সুযোগের বাইরে চলে গেলে বরাদ্দকে নিজেই ড্রপ প্রতিরোধ করে যদি panics ড্রপ করে তবে আমরা ডিএসটি_বুফে সংগৃহীত যে কোনও উপাদানও ফাঁস করে দেই
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ইনপ্লেসিটেটেবল চুক্তিটি এখানে যথাযথভাবে যাচাই করা যায় না, যেহেতু ট্রাই_ফোল্ডের উত্স পয়েন্টারটির একচেটিয়া রেফারেন্স রয়েছে আমরা যা করতে পারি তা পরীক্ষা করে দেখুন এটি এখনও সীমার মধ্যে রয়েছে কিনা?
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}