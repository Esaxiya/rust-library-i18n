use core::ptr::{self};
use core::slice::{self};

// স্থানের পুনরাবৃত্তির জন্য একটি সহায়ক কাঠামো যা পুনরাবৃত্তির গন্তব্য স্লাইস ফেলে দেয়।
// উত্স স্লাইস (লেজ) ইন্টিওটার দ্বারা বাদ দেওয়া হয়।
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}