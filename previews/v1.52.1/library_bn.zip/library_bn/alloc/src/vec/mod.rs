//! হিপ-বরাদ্দ সামগ্রীগুলির সাথে লিখিত `Vec<T>` সহ একটি সংযোগযুক্ত বর্ধনযোগ্য অ্যারে প্রকার।
//!
//! জেড ভিেক্টর00 জেডে এক্স 100 এক্স ইনডেক্সিং, এক্সোরাইজড এক্স01 এক্স পুশ (শেষ পর্যন্ত) এবং এক্স02 এক্স পপ (শেষ থেকে) রয়েছে।
//!
//!
//! Vectors নিশ্চিত করে যে তারা কখনই `isize::MAX` বাইটের বেশি বরাদ্দ করে না।
//!
//! # Examples
//!
//! আপনি স্পষ্টভাবে [`Vec::new`] দিয়ে একটি [`Vec`] তৈরি করতে পারেন:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... বা [`vec!`] ম্যাক্রো ব্যবহার করে:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // দশ জিরো
//! ```
//!
//! আপনি vector এর শেষে [`push`] মানগুলি করতে পারেন (যা vector প্রয়োজন হিসাবে বাড়বে):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! পপিং মানগুলি একইভাবে কাজ করে:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors এছাড়াও ইনডেক্সিং সমর্থন করে ([`Index`] এবং [`IndexMut`] traits মাধ্যমে):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` এবং উচ্চারিত 'vector' হিসাবে লিখিত একটি সংলগ্ন বর্ধনযোগ্য অ্যারে প্রকার।
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] ম্যাক্রো সূচনাটি আরও সুবিধাজনক করার জন্য সরবরাহ করা হয়েছে:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// এটি একটি প্রদত্ত মান দিয়ে একটি `Vec<T>` এর প্রতিটি উপাদানকে আরম্ভ করতে পারে।
/// এটি পৃথক পদক্ষেপে বরাদ্দকরণ এবং ইনিশিয়ালাইজেশন সম্পাদন করার চেয়ে আরও দক্ষ হতে পারে, বিশেষত জিরোসের জেডোভেেক্টর0 জেড শুরু করার সময়:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // নিম্নলিখিতটি সমতুল্য, তবে সম্ভাব্য ধীর:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// আরও তথ্যের জন্য, [Capacity and Reallocation](#capacity-and-reallocation) দেখুন।
///
/// একটি দক্ষ স্ট্যাক হিসাবে একটি `Vec<T>` ব্যবহার করুন:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // প্রিন্ট 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` প্রকারটি সূচক অনুসারে মানগুলিতে অ্যাক্সেস করতে দেয়, কারণ এটি [`Index`] trait প্রয়োগ করে।একটি উদাহরণ আরও স্পষ্ট হবে:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // এটি এক্স 100 এক্স প্রদর্শন করবে
/// ```
///
/// তবে সাবধান হন: আপনি যদি এমন একটি সূচকটি অ্যাক্সেস করার চেষ্টা করেন যা `Vec`-এ নেই তবে আপনার সফ্টওয়্যারটি panic করবে!আপনি এই কাজ করতে পারবেন না:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// [`get`] এবং [`get_mut`] ব্যবহার করুন যদি আপনি সূচকটি `Vec`-এ রয়েছে কিনা তা পরীক্ষা করতে চান।
///
/// # Slicing
///
/// একটি এক্স 100 এক্স পরিবর্তনীয় হতে পারে।অন্যদিকে, স্লাইসগুলি কেবল পঠনযোগ্য অবজেক্ট।
/// একটি [slice][prim@slice] পেতে, [`&`] ব্যবহার করুন।উদাহরণ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... এবং যে সব!
/// // আপনি এটি এটির মতোও করতে পারেন:
/// let u: &[usize] = &v;
/// // বা এই মত:
/// let u: &[_] = &v;
/// ```
///
/// Rust এ, আপনি কেবল পঠনের অ্যাক্সেস সরবরাহ করতে চাইলে vectors এর চেয়ে আর্গুমেন্ট হিসাবে স্লাইসগুলি পাস করা আরও সাধারণ।[`String`] এবং [`&str`] এর ক্ষেত্রেও একই রকম।
///
/// # ক্ষমতা এবং পুনঃনির্ধারণ
///
/// একটি vector এর সক্ষমতা হ'ল জেডভেস্টর0 জেড-এ যোগ করা হবে এমন কোনও জেড0 ফিউচার0 জেড উপাদানগুলির জন্য বরাদ্দ করা জায়গার পরিমাণ।এটি vector এর *দৈর্ঘ্য* এর সাথে বিভ্রান্ত হওয়ার দরকার নেই, যা vector এর মধ্যে প্রকৃত উপাদানগুলির সংখ্যা নির্দিষ্ট করে।
/// যদি একটি vector এর দৈর্ঘ্য তার ক্ষমতা ছাড়িয়ে যায় তবে এর ক্ষমতা স্বয়ংক্রিয়ভাবে বৃদ্ধি পাবে, তবে এর উপাদানগুলি পুনরায় স্থান দিতে হবে।
///
/// উদাহরণস্বরূপ, ক্ষমতা 10 এবং দৈর্ঘ্য 0 সহ একটি জেড 0ভেেক্টর0 জেড 10 টি আরও উপাদানগুলির জন্য ফাঁকা vector হবে।vector এ 10 বা তারও কম উপাদানগুলিকে ঠেলে দেওয়ার ফলে তার ক্ষমতা পরিবর্তন হবে না বা পুনরায় স্থান ঘটবে না।
/// তবে, যদি vector এর দৈর্ঘ্য 11 এ বাড়ানো হয় তবে এটি পুনর্বিবেচনা করতে হবে যা ধীর হতে পারে।এই কারণে, vector কতটা প্রত্যাশিত আশা করা যায় তা নির্দিষ্ট করার জন্য [`Vec::with_capacity`] ব্যবহার করার পরামর্শ দেওয়া হয়।
///
/// # Guarantees
///
/// অবিশ্বাস্যভাবে মৌলিক প্রকৃতির কারণে, এক্স 01 এক্স এর নকশা সম্পর্কে প্রচুর গ্যারান্টি দেয়।এটি নিশ্চিত করে যে এটি সাধারণ ক্ষেত্রে যতটা সম্ভব কম-ওভারহেড এবং অনিরাপদ কোড দ্বারা আদিম উপায়ে সঠিকভাবে ম্যানিপুলেট করা যায়।নোট করুন যে এই গ্যারান্টিগুলি একটি অযোগ্য `Vec<T>`-কে বোঝায়।
/// যদি অতিরিক্ত ধরণের পরামিতি যুক্ত করা হয় (যেমন, কাস্টম বরাদ্দকারীদের সমর্থন করার জন্য), তাদের ডিফল্টকে ওভাররাইড করা আচরণ পরিবর্তন করতে পারে।
///
/// মূলত, `Vec` হ'ল এবং সর্বদা একটি (পয়েন্টার, ক্ষমতা, দৈর্ঘ্য) ট্রিপলেট হবে।বেশিও না, কমও না.এই ক্ষেত্রগুলির ক্রম সম্পূর্ণরূপে অনির্ধারিত এবং আপনার এগুলি সংশোধন করার জন্য উপযুক্ত পদ্ধতিগুলি ব্যবহার করা উচিত।
/// পয়েন্টারটি কখনই শূন্য হবে না, সুতরাং এই ধরণটি নাল-পয়েন্টার-অনুকূলিত।
///
/// যাইহোক, পয়েন্টারটি আসলে বরাদ্দ মেমরিটির দিকে নির্দেশ করতে পারে না।
/// বিশেষত, আপনি যদি [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] এর মাধ্যমে 0 ক্ষমতা সহ একটি `Vec` নির্মাণ করেন বা খালি ভেকটিতে [`shrink_to_fit`] কল করে এটি মেমরি বরাদ্দ করবে না।একইভাবে, আপনি যদি `Vec` এর মধ্যে শূন্য আকারের প্রকারগুলি সংরক্ষণ করেন তবে এটি তাদের জন্য স্থান বরাদ্দ করবে না।
/// *মনে রাখবেন যে এই ক্ষেত্রে `Vec` 0* এর [`capacity`] প্রতিবেদন করতে পারে না।
/// `Vec` যদি এবং কেবলমাত্র [`মেম্বার: : আকার_::<T>`]`() * capacity()> 0` `
/// সাধারণভাবে, `ভেকের বরাদ্দের বিশদটি খুব সূক্ষ্ম-যদি আপনি কোনও `Vec` ব্যবহার করে মেমরি বরাদ্দ করতে চান এবং এটি অন্য কোনও কিছুর জন্য ব্যবহার করেন (হয় অনিরাপদ কোডটি পাস করার জন্য, বা আপনার নিজের মেমরি-ব্যাকড সংগ্রহ তৈরি করতে), নিশ্চিত হন `Vec` পুনরুদ্ধার করতে `from_raw_parts` ব্যবহার করে এবং পরে এটিকে ফেলে রেখে এই স্মৃতিটিকে ডিলেক্ট করতে।
///
/// যদি কোনও `Vec`* * বরাদ্দ মেমরির থাকে, তবে এটি যে মেমরিটিকে নির্দেশ করে তা হিপগুলিতে থাকে (বরাদ্দকারী Rust দ্বারা নির্ধারিত হিসাবে ডিফল্টরূপে ব্যবহারের জন্য কনফিগার করা হয়), এবং এর পয়েন্টারটি [`len`] সূচনা করে, সংলগ্ন উপাদানগুলিকে নির্দেশ করে (আপনি কী করবেন দেখুন যদি আপনি এটি কোনও টুকরোকে জোর করে রেখেছেন), এর পরে [`ক্ষমতা`]`,`[`লেন`] যুক্তিযুক্তভাবে অবিচ্ছিন্ন, সংগত উপাদানগুলি।
///
///
/// `'a'` এবং `'b'` উপাদান 4 সহ ক্ষমতাযুক্ত একটি জেড 0 সেভেটর0 জেড নীচে হিসাবে ভিজ্যুয়ালাইজ করা যায়।উপরের অংশটি `Vec` স্ট্রাক্ট, এটি গাদা, দৈর্ঘ্য এবং সক্ষমতাতে বরাদ্দের প্রধানের একটি পয়েন্টার ধারণ করে।
/// নীচের অংশটি হ'ল বরাদ্দ, একটি স্বচ্ছ মেমরি ব্লক।
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **আনইনিট** এমন স্মৃতি উপস্থাপন করে যা আরম্ভ হয় না, দেখুন [`MaybeUninit`]।
/// - Note: এবিআই স্থিতিশীল নয় এবং এক্স 100 এক্স এর মেমরি লেআউট (ক্ষেত্রগুলির ক্রম সহ) সম্পর্কে কোনও গ্যারান্টি দেয় না।
///
/// `Vec` কখনই কোনও "small optimization" সঞ্চালন করতে পারবেন না যেখানে উপাদানগুলি দুটি কারণে স্ট্যাকে আসলে সংরক্ষণ করা হয়:
///
/// * এটি অনিরাপদ কোডের জন্য একটি `Vec` সঠিকভাবে ম্যানিপুলেট করা আরও কঠিন করে তুলবে।যদি কেবল সরিয়ে নেওয়া হয় তবে কোনও এক্স0 এক্স এর সামগ্রীগুলির স্থিতিশীল ঠিকানা থাকবে না এবং কোনও এক্স 02 এক্স আসলে মেমরি বরাদ্দ করেছে কিনা তা নির্ধারণ করা আরও কঠিন হবে।
///
/// * এটি প্রতিটি ক্ষেত্রে অ্যাক্সেসের অতিরিক্ত জেড0 ফ্রেঞ্চ0 জেড ব্যতীত সাধারণ ক্ষেত্রে শাস্তি দেয়।
///
/// `Vec` সম্পূর্ণ খালি হলেও স্বয়ংক্রিয়ভাবে নিজেকে সঙ্কুচিত করবে না।এটি নিশ্চিত করে যে কোনও অপ্রয়োজনীয় বরাদ্দ বা বিলোপ ঘটবে না।একটি `Vec` খালি করা এবং তারপরে আবার একই [`len`] পর্যন্ত পূরণ করা বরাদ্দকারীকে কোনও কল করতে হবে না।আপনি যদি অব্যবহৃত স্মৃতি মুক্ত করতে চান তবে [`shrink_to_fit`] বা [`shrink_to`] ব্যবহার করুন।
///
/// [`push`] এবং রিপোর্ট করা ক্ষমতা পর্যাপ্ত থাকলে [`insert`] কখনই বরাদ্দ দেয় না (পুনরায়)।[`push`] এবং [`insert`]* *[পুনরায়) বরাদ্দ করবে [`লেনা]`==`[` ক্ষমতা`] থাকলে।অর্থাৎ, রিপোর্ট করা ক্ষমতা সম্পূর্ণ নির্ভুল, এবং নির্ভর করা যেতে পারে।এমনকি এটি যদি `Vec` দ্বারা বরাদ্দ করা মেমোরিটি ম্যানুয়ালি মুক্ত করতে ব্যবহৃত হয় তবে যদি প্রয়োজন হয়।
/// বাল্ক সন্নিবেশ পদ্ধতিগুলি *যখন প্রয়োজনীয় না হয় তখনও* পুনঃব্যবহার করতে পারে।
///
/// `Vec` পূর্ণ হওয়ার সময় পুনরায় স্থান নির্ধারণের সময় বা এক্স 011 এক্স কল করার সময় কোনও বিশেষ বিকাশের কৌশল গ্যারান্টি দেয় না।বর্তমান কৌশলটি মৌলিক এবং এটি অ-ধ্রুবক বৃদ্ধির ফ্যাক্টরটি ব্যবহার করার পক্ষে আকাঙ্খিত প্রমাণিত হতে পারে।যে কৌশলই ব্যবহৃত হয় অবশ্যই গ্যারান্টি দেয় *ও*(1) মোড়িত এক্স 100 এক্স।
///
/// `vec![x; n]`, `vec![a, b, c, d]` এবং [`Vec::with_capacity(n)`][`Vec::with_capacity`], সকলেই অনুরোধ ক্ষমতা সহ একটি এক্স02 এক্স উত্পাদন করবে।
/// যদি [`len`]`==`[`ক্ষমতা`], (যেমন [`vec!`] ম্যাক্রোর ক্ষেত্রে), তবে কোনও এক্স01 এক্সকে উপাদানগুলি পুনরায় স্থান না দিয়ে বা না সরানো দিয়ে কোনও এক্স0 2 এক্স থেকে রূপান্তর করা যায়।
///
/// `Vec` এটি থেকে সরানো কোনও ডেটা নির্দিষ্টভাবে ওভাররাইট করবে না, তবে এটি নির্দিষ্টভাবে সংরক্ষণ করবে না।এটির অবিচ্ছিন্ন মেমরিটি স্ক্র্যাচ স্পেস যা এটি চাইলে ব্যবহার করতে পারে।এটি সাধারণত সর্বাধিক দক্ষ বা কার্যকরভাবে প্রয়োগ করা সহজ যা কিছু করতে পারে।সুরক্ষার উদ্দেশ্যে মুছে ফেলার জন্য মুছে ফেলা ডেটা নির্ভর করবেন না।
/// এমনকি যদি আপনি একটি `Vec` ড্রপ করেন তবে এর বাফারটি অন্য কোনও `Vec` দ্বারা কেবল পুনরায় ব্যবহার করা যেতে পারে।
/// এমনকি যদি আপনি প্রথমে `ভেকের স্মৃতি শূন্য করেন তবে আসলে এটি ঘটতে পারে না কারণ অপ্টিমাইজার এটিকে কোনও পার্শ্ব-প্রতিক্রিয়া বিবেচনা করে না যা অবশ্যই সংরক্ষণ করা উচিত।
/// এর মধ্যে একটি কেস রয়েছে যা আমরা ভেঙে ফেলব না: তবে অতিরিক্ত সক্ষমতা লিখতে `unsafe` কোড ব্যবহার করা, এবং তারপরে দৈর্ঘ্যের সাথে মিল রেখে, সর্বদা বৈধ।
///
/// বর্তমানে, `Vec` যে উপাদানগুলিতে বাদ পড়েছে তার গ্যারান্টি দেয় না।
/// আদেশটি অতীতে পরিবর্তিত হয়েছে এবং আবার পরিবর্তন হতে পারে।
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// সহজাত পদ্ধতি
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// একটি নতুন, খালি `Vec<T>` তৈরি করে।
    ///
    /// vector যতক্ষণ পর্যন্ত উপাদানগুলিকে এতে চাপানো না হয় ততক্ষণ বরাদ্দ দেওয়া হবে না।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// নির্দিষ্ট ক্ষমতা সহ একটি নতুন, খালি `Vec<T>` তৈরি করে।
    ///
    /// vector পুনরায় স্থান ছাড়াই ঠিক `capacity` উপাদান রাখতে সক্ষম হবে will
    /// যদি `capacity` 0 হয় তবে vector বরাদ্দ হবে না।
    ///
    /// এটি লক্ষণীয় গুরুত্বপূর্ণ যে প্রতীয়মান vector এর *ক্ষমতা* নির্দিষ্ট করা থাকলেও vector এর শূন্য *দৈর্ঘ্য* থাকবে।
    ///
    /// দৈর্ঘ্য এবং ক্ষমতার মধ্যে পার্থক্যের ব্যাখ্যার জন্য,*[সক্ষমতা এবং পুনঃনির্ধারণ]* দেখুন।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector তে কোনও আইটেম নেই, যদিও এটির আরও বেশি ক্ষমতা রয়েছে
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // এগুলি সমস্ত পুনরায় প্রত্যাশা ছাড়াই সম্পন্ন হয়েছে ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... তবে এটি vector পুনর্বিবেচনা করতে পারে
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// অন্য vector এর কাঁচা উপাদান থেকে সরাসরি একটি `Vec<T>` তৈরি করে।
    ///
    /// # Safety
    ///
    /// পরীক্ষামূলকভাবে পরীক্ষিত না হওয়া সংখ্যক আক্রমণকারী সংখ্যার কারণে এটি অত্যন্ত সুরক্ষিত is
    ///
    /// * `ptr` আগে [`স্ট্রিং`]/` ভিসি মাধ্যমে বরাদ্দ করা দরকার<T>। (কমপক্ষে, এটি না থাকলে এটি খুব সম্ভবত ভুল হওয়ার সম্ভাবনা রয়েছে)।
    /// * `T` `ptr` যা বরাদ্দ করা হয়েছিল তার সমান আকার এবং প্রান্তিককরণ থাকা দরকার।
    ///   (`T` এর চেয়ে কম কঠোর প্রান্তিককরণ যথেষ্ট নয়, প্রান্তিককরণটি [`dealloc`] এর প্রয়োজনীয়তা পূরণের জন্য সত্যই সমান হওয়া দরকার যে মেমরিটি একই বরাদ্দ করতে হবে এবং একই বিন্যাসের সাথে বিযুক্ত করা হবে))
    ///
    /// * `length` `capacity` এর চেয়ে কম বা সমান হওয়া দরকার।
    /// * `capacity` পয়েন্টারটি বরাদ্দ করা হয়েছিল এমন ক্ষমতা হওয়া দরকার।
    ///
    /// এগুলি লঙ্ঘন করলে বরাদ্দকারীর অভ্যন্তরীণ ডেটা কাঠামোকে কলুষিত করার মতো সমস্যা দেখা দিতে পারে।উদাহরণস্বরূপ এটি **নয়** দৈর্ঘ্যের `size_t` দৈর্ঘ্যের সি পয়েন্টার থেকে এক্স এক্স 1 এক্স এক্স এক্স 011 এক্স তৈরি করা নিরাপদ।
    /// এটি `Vec<u16>` এবং এর দৈর্ঘ্য থেকে কোনওটি তৈরি করাও নিরাপদ নয়, কারণ বরাদ্দকারী প্রান্তিককরণের যত্ন করে এবং এই দুটি ধরণের পৃথক প্রান্তিককরণ রয়েছে।
    /// বাফারটি প্রান্তিককরণ 2 (`u16` এর জন্য) দিয়ে বরাদ্দ করা হয়েছিল, তবে এটিকে `Vec<u8>` এ পরিণত করার পরে এটি প্রান্তিককরণ 1 এর সাথে বিচ্ছিন্ন হয়ে যাবে।
    ///
    /// `ptr` এর মালিকানা কার্যকরভাবে `Vec<T>` এ স্থানান্তরিত হয় যা ইচ্ছামত পয়েন্টার দ্বারা নির্দেশিত মেমরির বিষয়বস্তুগুলি হ্রাস করতে পারে, পুনরায় প্রকাশ করতে বা পরিবর্তন করতে পারে।
    /// নিশ্চিত করুন যে এই ফাংশনটি কল করার পরে আর কোনও কিছুই পয়েন্টার ব্যবহার করে না।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // ভিক_আইএনটো_আরও_পর্বগুলি স্থিতিশীল হয়ে গেলে ফিক্সএমই এটি আপডেট করুন।
    ///     // Running v` এর ডেস্ট্রাক্টর চালানো রোধ করুন যাতে আমরা বরাদ্দের সম্পূর্ণ নিয়ন্ত্রণে থাকি।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // এক্স00 এক্স সম্পর্কিত বিভিন্ন গুরুত্বপূর্ণ টুকরো টানুন
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6 দিয়ে মেমরি ওভাররাইট করুন
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // সবকিছু আবার এক ভিসিতে রেখে দিন
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// একটি নতুন, খালি `Vec<T, A>` তৈরি করে।
    ///
    /// vector যতক্ষণ পর্যন্ত উপাদানগুলিকে এতে চাপানো না হয় ততক্ষণ বরাদ্দ দেওয়া হবে না।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// সরবরাহকারীর বরাদ্দকারী সহ নির্দিষ্ট ক্ষমতা সহ একটি নতুন, খালি `Vec<T, A>` তৈরি করে।
    ///
    /// vector পুনরায় স্থান ছাড়াই ঠিক `capacity` উপাদান রাখতে সক্ষম হবে will
    /// যদি `capacity` 0 হয় তবে vector বরাদ্দ হবে না।
    ///
    /// এটি লক্ষণীয় গুরুত্বপূর্ণ যে প্রতীয়মান vector এর *ক্ষমতা* নির্দিষ্ট করা থাকলেও vector এর শূন্য *দৈর্ঘ্য* থাকবে।
    ///
    /// দৈর্ঘ্য এবং ক্ষমতার মধ্যে পার্থক্যের ব্যাখ্যার জন্য,*[সক্ষমতা এবং পুনঃনির্ধারণ]* দেখুন।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector তে কোনও আইটেম নেই, যদিও এটির আরও বেশি ক্ষমতা রয়েছে
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // এগুলি সমস্ত পুনরায় প্রত্যাশা ছাড়াই সম্পন্ন হয়েছে ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... তবে এটি vector পুনর্বিবেচনা করতে পারে
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// অন্য vector এর কাঁচা উপাদান থেকে সরাসরি একটি `Vec<T, A>` তৈরি করে।
    ///
    /// # Safety
    ///
    /// পরীক্ষামূলকভাবে পরীক্ষিত না হওয়া সংখ্যক আক্রমণকারী সংখ্যার কারণে এটি অত্যন্ত সুরক্ষিত is
    ///
    /// * `ptr` আগে [`স্ট্রিং`]/` ভিসি মাধ্যমে বরাদ্দ করা দরকার<T>। (কমপক্ষে, এটি না থাকলে এটি খুব সম্ভবত ভুল হওয়ার সম্ভাবনা রয়েছে)।
    /// * `T` `ptr` যা বরাদ্দ করা হয়েছিল তার সমান আকার এবং প্রান্তিককরণ থাকা দরকার।
    ///   (`T` এর চেয়ে কম কঠোর প্রান্তিককরণ যথেষ্ট নয়, প্রান্তিককরণটি [`dealloc`] এর প্রয়োজনীয়তা পূরণের জন্য সত্যই সমান হওয়া দরকার যে মেমরিটি একই বরাদ্দ করতে হবে এবং একই বিন্যাসের সাথে বিযুক্ত করা হবে))
    ///
    /// * `length` `capacity` এর চেয়ে কম বা সমান হওয়া দরকার।
    /// * `capacity` পয়েন্টারটি বরাদ্দ করা হয়েছিল এমন ক্ষমতা হওয়া দরকার।
    ///
    /// এগুলি লঙ্ঘন করলে বরাদ্দকারীর অভ্যন্তরীণ ডেটা কাঠামোকে কলুষিত করার মতো সমস্যা দেখা দিতে পারে।উদাহরণস্বরূপ এটি **নয়** দৈর্ঘ্যের `size_t` দৈর্ঘ্যের সি পয়েন্টার থেকে এক্স এক্স 1 এক্স এক্স এক্স 011 এক্স তৈরি করা নিরাপদ।
    /// এটি `Vec<u16>` এবং এর দৈর্ঘ্য থেকে কোনওটি তৈরি করাও নিরাপদ নয়, কারণ বরাদ্দকারী প্রান্তিককরণের যত্ন করে এবং এই দুটি ধরণের পৃথক প্রান্তিককরণ রয়েছে।
    /// বাফারটি প্রান্তিককরণ 2 (`u16` এর জন্য) দিয়ে বরাদ্দ করা হয়েছিল, তবে এটিকে `Vec<u8>` এ পরিণত করার পরে এটি প্রান্তিককরণ 1 এর সাথে বিচ্ছিন্ন হয়ে যাবে।
    ///
    /// `ptr` এর মালিকানা কার্যকরভাবে `Vec<T>` এ স্থানান্তরিত হয় যা ইচ্ছামত পয়েন্টার দ্বারা নির্দেশিত মেমরির বিষয়বস্তুগুলি হ্রাস করতে পারে, পুনরায় প্রকাশ করতে বা পরিবর্তন করতে পারে।
    /// নিশ্চিত করুন যে এই ফাংশনটি কল করার পরে আর কোনও কিছুই পয়েন্টার ব্যবহার করে না।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // ভিক_আইএনটো_আরও_পর্বগুলি স্থিতিশীল হয়ে গেলে ফিক্সএমই এটি আপডেট করুন।
    ///     // Running v` এর ডেস্ট্রাক্টর চালানো রোধ করুন যাতে আমরা বরাদ্দের সম্পূর্ণ নিয়ন্ত্রণে থাকি।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // এক্স00 এক্স সম্পর্কিত বিভিন্ন গুরুত্বপূর্ণ টুকরো টানুন
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6 দিয়ে মেমরি ওভাররাইট করুন
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // সবকিছু আবার এক ভিসিতে রেখে দিন
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// একটি `Vec<T>` এর কাঁচা উপাদানগুলিতে বিভক্ত করে।
    ///
    /// অন্তর্নিহিত ডেটা, vector দৈর্ঘ্য (উপাদানগুলিতে) এবং উপাত্তের বরাদ্দ ক্ষমতা (উপাদানগুলিতে) এর কাঁচা পয়েন্টার প্রদান করে।
    /// এগুলি একই ক্রমে একই যুক্তি যা [`from_raw_parts`]-তে যুক্তি হিসাবে।
    ///
    /// এই ফাংশনটি কল করার পরে, কলার `Vec` দ্বারা পরিচালিত মেমরির জন্য দায়বদ্ধ।
    /// এটি করার একমাত্র উপায় হ'ল কাঁচা পয়েন্টার, দৈর্ঘ্য এবং ক্ষমতাটিকে [`from_raw_parts`] ফাংশন দিয়ে একটি `Vec` এ রূপান্তর করা, যাতে ডেস্ট্রাক্টর ক্লিনআপ সম্পাদন করতে দেয়।
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // আমরা এখন উপাদানগুলিতে পরিবর্তন আনতে পারি, যেমন কাঁচা পয়েন্টারটি একটি সামঞ্জস্যপূর্ণ প্রকারে ট্রান্সমিট করা।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// একটি `Vec<T>` এর কাঁচা উপাদানগুলিতে বিভক্ত করে।
    ///
    /// অন্তর্নিহিত ডেটা, vector দৈর্ঘ্য (উপাদানগুলিতে), ডেটার বরাদ্দ ক্ষমতা (উপাদানগুলিতে) এবং বরাদ্দকারীকে কাঁচা পয়েন্টার প্রদান করে।
    /// এগুলি একই ক্রমে একই যুক্তি যা [`from_raw_parts_in`]-তে যুক্তি।
    ///
    /// এই ফাংশনটি কল করার পরে, কলার `Vec` দ্বারা পরিচালিত মেমরির জন্য দায়বদ্ধ।
    /// এটি করার একমাত্র উপায় হ'ল কাঁচা পয়েন্টার, দৈর্ঘ্য এবং ক্ষমতাটিকে [`from_raw_parts_in`] ফাংশন দিয়ে একটি `Vec` এ রূপান্তর করা, যাতে ডেস্ট্রাক্টর ক্লিনআপ সম্পাদন করতে দেয়।
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // আমরা এখন উপাদানগুলিতে পরিবর্তন আনতে পারি, যেমন কাঁচা পয়েন্টারটি একটি সামঞ্জস্যপূর্ণ প্রকারে ট্রান্সমিট করা।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector পুনরায় প্রত্যাশা ছাড়াই ধারণ করতে পারে এমন সংখ্যার উপাদান প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// প্রদত্ত `Vec<T>`-এ অন্ততপক্ষে কমপক্ষে `additional` আরও উপাদান সন্নিবেশ করার ক্ষমতা সংরক্ষণ করে।
    /// ঘন ঘন পুনর্বিবেচনাগুলি এড়াতে সংগ্রহটি আরও স্থান সংরক্ষণ করতে পারে।
    /// `reserve` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে যথেষ্ট হলে কিছুই করে না।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতাটি `isize::MAX` বাইটের বেশি হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// প্রদত্ত `Vec<T>`-তে সঠিকভাবে আরও `additional` আরও উপাদান forোকানোর জন্য ন্যূনতম ক্ষমতা সঞ্চয় করে capacity
    ///
    /// `reserve_exact` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে পর্যাপ্ত থাকলে কিছুই করে না।
    ///
    /// দ্রষ্টব্য যে বরাদ্দকারী সংগ্রহের চেয়ে তার চেয়ে বেশি জায়গা দিতে পারে।
    /// সুতরাং, সামর্থ্যটি নির্ভুলভাবে ন্যূনতম হতে নির্ভর করা যায় না।
    /// যদি জেডফিউচার0 জেড সন্নিবেশগুলি প্রত্যাশিত হয় তবে `reserve` পছন্দ করুন।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতা `usize` ওভারফ্লো হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// প্রদত্ত `Vec<T>` আরও কমপক্ষে আরও কয়েকটি উপাদান elementsোকানোর জন্য ক্ষমতা সংরক্ষণের চেষ্টা করে।
    /// ঘন ঘন পুনর্বিবেচনাগুলি এড়াতে সংগ্রহটি আরও স্থান সংরক্ষণ করতে পারে।
    /// `try_reserve` কল করার পরে, ক্ষমতাটি `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    /// ক্ষমতা ইতিমধ্যে যথেষ্ট হলে কিছুই করে না।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতা ওভারফ্লো হয়, বা বরাদ্দকারী একটি ব্যর্থতার রিপোর্ট করে তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve(data.len())?;
    ///
    ///     // এখন আমরা জানি আমাদের জটিল কাজের মাঝখানে এটি OOM করতে পারে না
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // খুবই জটিল
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// প্রদত্ত `Vec<T>`-এ সঠিকভাবে `additional` উপাদান beোকানোর জন্য ন্যূনতম ক্ষমতা সংরক্ষণের চেষ্টা করে।
    /// `try_reserve_exact` কল করার পরে, ক্ষমতাটি যদি `Ok(())` ফেরত দেয় তবে `self.len() + additional` এর চেয়ে বড় বা সমান হবে।
    ///
    /// ক্ষমতা ইতিমধ্যে পর্যাপ্ত থাকলে কিছুই করে না।
    ///
    /// দ্রষ্টব্য যে বরাদ্দকারী সংগ্রহের চেয়ে তার চেয়ে বেশি জায়গা দিতে পারে।
    /// সুতরাং, সামর্থ্যটি নির্ভুলভাবে ন্যূনতম হতে নির্ভর করা যায় না।
    /// যদি জেডফিউচার0 জেড সন্নিবেশগুলি প্রত্যাশিত হয় তবে `reserve` পছন্দ করুন।
    ///
    /// # Errors
    ///
    /// যদি ক্ষমতা ওভারফ্লো হয়, বা বরাদ্দকারী একটি ব্যর্থতার রিপোর্ট করে তবে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // স্মৃতিটি প্রাক-সংরক্ষণ করুন, যদি আমরা না পারি তবে প্রস্থান করা হচ্ছে
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // এখন আমরা জানি আমাদের জটিল কাজের মাঝখানে এটি OOM করতে পারে না
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // খুবই জটিল
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector এর সক্ষমতা যতটা সম্ভব সঙ্কুচিত করে।
    ///
    /// এটি দৈর্ঘ্যের যতটা সম্ভব নিচে নেমে যাবে তবে বরাদ্দকারীটি এখনও vector কে অবহিত করতে পারে যে আরও কয়েকটি উপাদানের জন্য জায়গা রয়েছে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ক্ষমতাটি দৈর্ঘ্যের চেয়ে কখনই কম নয় এবং সেগুলি সমান হলে কিছুই করার থাকে না, তাই আমরা কেবলমাত্র একটি বৃহত্তর ক্ষমতা সহ কল করে `RawVec::shrink_to_fit`-এ panic কেস এড়াতে পারি।
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// নিম্ন সীমা দ্বারা vector এর ক্ষমতা সঙ্কুচিত করে।
    ///
    /// ক্ষমতা কমপক্ষে দৈর্ঘ্য এবং সরবরাহিত মান উভয়ের হিসাবে বৃহত্তর থাকবে।
    ///
    ///
    /// যদি বর্তমান ক্ষমতা নিম্ন সীমাটির চেয়ে কম হয়, তবে এটি কোনও অপশন নয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector কে [`Box<[T]>`][owned slice] এ রূপান্তর করে।
    ///
    /// নোট করুন যে এটি কোনও অতিরিক্ত ক্ষমতা ছাড়বে।
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// যে কোনও অতিরিক্ত ক্ষমতা সরিয়ে দেওয়া হয়েছে:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// প্রথম `len` উপাদান রেখে এবং বাকিগুলি বাদ দিয়ে vector ছোট করে।
    ///
    /// যদি `len` vector এর বর্তমান দৈর্ঘ্যের চেয়ে বেশি হয় তবে এর কোনও প্রভাব নেই।
    ///
    /// [`drain`] পদ্ধতিটি `truncate` অনুকরণ করতে পারে তবে অতিরিক্ত উপাদানগুলি বাদ দেওয়ার পরিবর্তে ফিরিয়ে আনতে পারে।
    ///
    ///
    /// নোট করুন যে vector এর বরাদ্দ ক্ষমতার উপর এই পদ্ধতির কোনও প্রভাব নেই।
    ///
    /// # Examples
    ///
    /// একটি পাঁচটি উপাদান vector দুটি উপাদানকে কাটা:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` vector এর বর্তমান দৈর্ঘ্যের চেয়ে বেশি হলে কোনও ছাঁটাই ঘটে না:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` [`clear`] পদ্ধতি কল করার সমান হলে সংক্ষিপ্তকরণ।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // এটি নিরাপদ কারণ:
        //
        // * `drop_in_place` এ দেওয়া স্লাইসটি বৈধ;এক্স01 এক্স কেসটি একটি অবৈধ স্লাইস তৈরি করা এড়িয়ে যায়, এবং
        // * X0Xctor0Z এর `len` `drop_in_place` কল করার আগে সঙ্কুচিত হয়ে গেছে, এর ফলে `drop_in_place` একবার panic এ যাওয়ার ক্ষেত্রে কোনও মান দুইবার বাদ দেওয়া হবে না (যদি এটি panics দু'বার হয় তবে প্রোগ্রামটি বাতিল হয়ে যায়)।
        //
        //
        //
        unsafe {
            // Note: এটি উদ্দেশ্যমূলক যে এটি `>` এবং `>=` নয়।
            //       এটি `>=` এ পরিবর্তন করার কিছু ক্ষেত্রে নেতিবাচক কর্মক্ষমতা জড়িত।
            //       আরও জন্য #78884 দেখুন।
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// পুরো vector সমন্বিত একটি স্লাইস বের করে।
    ///
    /// `&s[..]` এর সমান।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// পুরো vector এর একটি পরিবর্তনীয় স্লাইস বের করে।
    ///
    /// `&mut s[..]` এর সমান।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector এর বাফারে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে vector পয়েন্টারটি এই ফাংশনটি দিয়ে দেয়াকে আউটলাইভ করে, অন্যথায় এটি আবর্জনার দিকে নির্দেশ করে শেষ হবে।
    /// vector পরিবর্তন করে এর বাফারটিকে পুনরায় স্থান দিতে পারে, যার ফলে এটিতে কোনও পয়েন্টারও অবৈধ হয়ে যায়।
    ///
    /// ফোনকারীকে অবশ্যই নিশ্চিত করতে হবে যে পয়েন্টার (non-transitively) নির্দেশিত মেমরিটি এই পয়েন্টার বা এর থেকে প্রাপ্ত কোনও পয়েন্টার ব্যবহার করে কখনই (কোনও `UnsafeCell` এর অভ্যন্তরের বাইরে) লিখিত হয় না।
    /// আপনার যদি স্লাইসের বিষয়বস্তুগুলিকে পরিবর্তিত করতে হয় তবে [`as_mut_ptr`] ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // আমরা `deref` এর মধ্য দিয়ে যাওয়া এড়াতে একই নামের স্লাইস পদ্ধতির ছায়া দিই, যা মধ্যবর্তী রেফারেন্স তৈরি করে।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector এর বাফারে একটি অনিরাপদ পরিবর্তনযোগ্য পয়েন্টারটি ফিরিয়ে দেয়।
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে vector পয়েন্টারটি এই ফাংশনটি দিয়ে দেয়াকে আউটলাইভ করে, অন্যথায় এটি আবর্জনার দিকে নির্দেশ করে শেষ হবে।
    ///
    /// vector পরিবর্তন করে এর বাফারটিকে পুনরায় স্থান দিতে পারে, যার ফলে এটিতে কোনও পয়েন্টারও অবৈধ হয়ে যায়।
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 টি উপাদানের জন্য যথেষ্ট বড় vector বরাদ্দ করুন।
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // কাঁচা পয়েন্টার লেখার মাধ্যমে উপাদানগুলির সূচনা করুন, তারপরে দৈর্ঘ্য নির্ধারণ করুন।
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // `deref_mut` এর মধ্য দিয়ে যাওয়া এড়াতে আমরা একই নামের স্লাইস পদ্ধতির ছায়া দিয়ে থাকি, যা মধ্যবর্তী রেফারেন্স তৈরি করে।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// অন্তর্নিহিত বরাদ্দকারীর একটি রেফারেন্স প্রদান করে।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector এর দৈর্ঘ্যকে `new_len` এ জোর করে।
    ///
    /// এটি একটি নিম্ন-স্তরের অপারেশন যা এই ধরণের সাধারণ আক্রমণকারীদের কোনওোটাই রক্ষণ করে না।
    /// সাধারণত একটি vector এর দৈর্ঘ্য পরিবর্তনের পরিবর্তে [`truncate`], [`resize`], [`extend`] বা [`clear`] এর মতো একটি নিরাপদ অপারেশন ব্যবহার করে করা হয়।
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] এর চেয়ে কম বা সমান হতে হবে।
    /// - `old_len..new_len` এ থাকা উপাদানগুলি অবশ্যই শুরু করতে হবে।
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// এই পদ্ধতিটি এমন পরিস্থিতিতে কার্যকর হতে পারে যেখানে vector অন্যান্য কোডের বাফার হিসাবে পরিবেশন করছে, বিশেষত এফএফআইয়ের মাধ্যমে:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // এটি ডক উদাহরণের জন্য একটি সর্বনিম্ন কঙ্কাল;
    /// # // এটি একটি বাস্তব গ্রন্থাগারের জন্য একটি সূচনা পয়েন্ট হিসাবে ব্যবহার করবেন না।
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // এফএফআই পদ্ধতির ডক্স অনুসারে, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // নিরাপদ: যখন `deflateGetDictionary` `Z_OK` ফেরত দেয়, তখন তা ধরে রাখে:
    ///     // 1. `dict_length` উপাদানগুলির সূচনা করা হয়েছিল।
    ///     // 2.
    ///     // `dict_length` <=ক্ষমতা (32_768) যা `set_len` কল করা নিরাপদ করে।
    ///     unsafe {
    ///         // এফএফআই কল করুন ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... এবং প্রারম্ভিক কি ছিল দৈর্ঘ্য আপডেট করুন।
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// নিম্নোক্ত উদাহরণটি শব্দদায়ক হলেও, `set_len` কল করার আগে অভ্যন্তরীণ vectors মুক্ত করা হয়নি বলে একটি মেমরি ফাঁস রয়েছে:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` খালি তাই কোনও উপাদানকে আরম্ভ করার দরকার নেই।
    /// // 2. `0 <= capacity` সর্বদা `capacity` যা থাকে তা ধরে রাখে।
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// সাধারণত, এখানে, কেউ সঠিকভাবে কন্টেন্টগুলি ফেলে দেওয়ার জন্য [`clear`] ব্যবহার করবে এবং মেমরি ফাঁস করবে না।
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector থেকে একটি উপাদান সরান এবং এটি প্রদান করে।
    ///
    /// সরানো উপাদান vector এর শেষ উপাদান দ্বারা প্রতিস্থাপিত হয়।
    ///
    /// এটি অর্ডারিং সংরক্ষণ করে না, তবে এটি O(1)।
    ///
    /// # Panics
    ///
    /// `index` সীমার বাইরে থাকলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // আমরা স্ব উপাদান [সূচক] শেষ উপাদান সঙ্গে প্রতিস্থাপন।
            // নোট করুন যে উপরের সীমানা যদি সফল হয় তবে অবশ্যই একটি শেষ উপাদান থাকতে হবে (যা নিজেই হতে পারে [সূচী] নিজেই হতে পারে)।
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector এর মধ্যে `index` পজিশনে একটি উপাদান সন্নিবেশ করান, সমস্ত উপাদানকে এর পরে ডানে সরিয়ে দেয়।
    ///
    ///
    /// # Panics
    ///
    /// `index > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // নতুন উপাদান জন্য স্থান
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // অপরিবর্তনীয় স্থান নতুন মান রাখার জন্য
            //
            {
                let p = self.as_mut_ptr().add(index);
                // স্থান তৈরি করতে সবকিছুকে শিফট করুন।
                // (ধারাবাহিকভাবে দুটি স্থানে সূচকের উপাদানটির সদৃশ করা।)
                ptr::copy(p, p.offset(1), len - index);
                // `সূচি` উপাদানটির প্রথম অনুলিপি ওভাররাইট করে এটিতে লিখুন।
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector এর মধ্যে `index` অবস্থানের এলিমেন্টটি সরিয়ে দেয় এবং প্রদান করে, সমস্ত উপাদান বামে স্থানান্তরিত করার পরে।
    ///
    ///
    /// # Panics
    ///
    /// `index` সীমার বাইরে থাকলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // আমরা যে জায়গাটি থেকে নিচ্ছি।
                let ptr = self.as_mut_ptr().add(index);
                // এটি অনুলিপি করুন, অনিরাপদ স্ট্যাকের এবং একই সময়ে vector এ মানটির একটি অনুলিপি রাখুন।
                //
                ret = ptr::read(ptr);

                // সেই জায়গাটি পূরণ করতে সবকিছুকে নীচে নামিয়ে দিন।
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// কেবলমাত্র প্রাকটিকের দ্বারা নির্দিষ্ট উপাদানগুলিকে ধরে রাখে।
    ///
    /// অন্য কথায়, `e` সমস্ত উপাদানগুলি মুছুন যেমন `f(&e)` `false` প্রদান করে।
    /// এই পদ্ধতিটি যথাযথভাবে পরিচালনা করে প্রতিটি উপাদানকে আসল ক্রমে একবারে পরিদর্শন করে এবং ধরে রাখা উপাদানগুলির ক্রম সংরক্ষণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// যেহেতু উপাদানগুলি মূল ক্রমে ঠিক একবার পরিদর্শন করা হয়েছে, কোন উপাদান রাখতে হবে তা সিদ্ধান্ত নিতে বাহ্যিক অবস্থা ব্যবহার করা যেতে পারে।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // ড্রপ গার্ড কার্যকর না করা হলে ডাবল ড্রপ এড়ান, যেহেতু আমরা প্রক্রিয়া চলাকালীন কিছু ছিদ্র করতে পারি।
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-প্রক্রিয়াজাত লেন-> |^-পরের চেক
        //                  | <-মুছে ফেলা সিএনটি-> |
        //      | <-আসল_লেন-> | |রাখা হয়েছে: যে উপাদানগুলি পূর্বাভাস দেয় তা সত্য হয়।
        //
        // হোল: সরানো বা বাদ দেওয়া উপাদান স্লট।
        // চেক করা হয়নি: চেক করা বৈধ উপাদানসমূহ।
        //
        // এই ড্রপ প্রহরীকে ডেকে আনা হবে যখন প্রিডিকেট বা `drop` এলিমেন্টের আতঙ্কিত হয়।
        // এটি গর্ত এবং `set_len` কভার করতে চেক করা উপাদানগুলিকে সঠিক দৈর্ঘ্যে স্থানান্তরিত করে।
        // প্রিকিটিক এবং এক্স 100 এক্স কখনই প্যাঙ্ক করে না এমন ক্ষেত্রে এটি অপ্টিমাইজ হবে।
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // সুরক্ষা: চেক করা চেক করা আইটেমগুলি অবশ্যই বৈধ হওয়া উচিত যেহেতু আমরা সেগুলি কখনই স্পর্শ করি না।
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // নিরাপত্তা: গর্তগুলি পূরণ করার পরে, সমস্ত আইটেম সংলগ্ন স্মৃতিতে রয়েছে।
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // নিরাপদ: চেক না করা উপাদান অবশ্যই বৈধ হতে হবে।
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` আতঙ্কিত হলে ডাবল ড্রপ এড়ানোর জন্য তাড়াতাড়ি অগ্রসর হন।
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // সুরক্ষা: বাদ দেওয়ার পরে আমরা আর কখনও এই উপাদানটিকে স্পর্শ করি না।
                unsafe { ptr::drop_in_place(cur) };
                // আমরা ইতিমধ্যে কাউন্টার উন্নত।
                continue;
            }
            if g.deleted_cnt > 0 {
                // নিরাপদ: `deleted_cnt`> 0, সুতরাং গর্ত স্লট অবশ্যই বর্তমান উপাদানের সাথে ওভারল্যাপ করা উচিত নয়।
                // আমরা সরানোর জন্য অনুলিপি ব্যবহার করি এবং এই উপাদানটিকে আর কখনও স্পর্শ করি না।
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // সমস্ত আইটেম প্রক্রিয়া করা হয়।এটি এলএলভিএম দ্বারা `set_len` এ অনুকূলিত হতে পারে।
        drop(g);
    }

    /// vector এ টানা প্রথমগুলির ব্যতীত সমস্তগুলি সরিয়ে দেয় যা একই কীটিতে সমাধান হয়।
    ///
    ///
    /// vector বাছাই করা থাকলে, এটি সমস্ত সদৃশ সরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// প্রদত্ত সাম্যতার সম্পর্কটিকে সন্তুষ্ট করে vector এ টানা উপাদানগুলির প্রথমটি ব্যতীত সমস্তগুলি সরিয়ে দেয়।
    ///
    /// `same_bucket` ফাংশনটি vector থেকে দুটি উপাদানের রেফারেন্স পাস হয়েছে এবং উপাদানগুলি সমান তুলনা করে কিনা তা নির্ধারণ করতে হবে।
    /// উপাদানগুলি স্লাইসে তাদের ক্রম থেকে বিপরীত ক্রমে উত্তীর্ণ হয়, সুতরাং `same_bucket(a, b)` যদি `true` ফেরত দেয়, `a` সরানো হয়।
    ///
    ///
    /// vector বাছাই করা থাকলে, এটি সমস্ত সদৃশ সরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// সংগ্রহের পিছনে একটি উপাদান যুক্ত করে।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতাটি `isize::MAX` বাইটের বেশি হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // এটি panic বা বাতিল করে দিবে যদি আমরা> isize::MAX বাইট বরাদ্দ করি বা দৈর্ঘ্যের বর্ধন শূন্য-আকারের প্রকারের জন্য উপচে পড়ে যায়।
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector থেকে শেষ উপাদানটি সরিয়ে দেয় এবং এটি খালি থাকলে [`None`] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` এর সমস্ত উপাদানকে `Self` এ সরান, `other` খালি রেখে।
    ///
    /// # Panics
    ///
    /// Panics যদি vector তে উপাদানগুলির সংখ্যা একটি `usize` ওভারফ্লো করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// অন্যান্য বাফার থেকে `Self` এ উপাদান যুক্ত করে।
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// একটি ড্রেনিং আইট্রেটর তৈরি করে যা vector এ নির্দিষ্ট রেঞ্জটি সরিয়ে দেয় এবং সরানো আইটেমগুলি দেয়।
    ///
    /// যখন ইটারেটর ** ** বাদ দেওয়া হয় তখন পরিবাহীর সমস্ত উপাদান vector থেকে সরিয়ে ফেলা হয়, এমনকি যদি পুনরুক্তি সম্পূর্ণরূপে গ্রাস না করা হয়।
    /// যদি পুনরুক্তি ** ** বাদ না দেওয়া হয় (উদাহরণস্বরূপ [`mem::forget`] সহ), কতগুলি উপাদান সরানো হয়েছে তা অনির্ধারিত।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভিক পয়েন্টটি শেষ পয়েন্টের চেয়ে বেশি হয় বা শেষ বিন্দু vector দৈর্ঘ্যের চেয়ে বেশি হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // একটি পূর্ণ পরিসীমা vector সাফ করে
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // স্মৃতি সুরক্ষা
        //
        // Drain প্রথমবার তৈরি হওয়ার পরে, Drain এর ডেস্ট্রাক্টর কখনই চালাবেন না তা নিশ্চিত করার জন্য এটি উত্স vector এর দৈর্ঘ্য কমিয়ে দেয় যাতে কোনও অবিচ্ছিন্ন বা সরানো-থেকে উপাদানগুলি অ্যাক্সেসযোগ্য না হয়।
        //
        //
        // Drain মানগুলি অপসারণের জন্য ptr::read কে বের করে দেবে।
        // শেষ হয়ে গেলে, ভেস্কের অবশিষ্ট লেজটি গর্তটি coverাকতে পিছনে অনুলিপি করা হয় এবং vector দৈর্ঘ্যটি নতুন দৈর্ঘ্যে পুনরুদ্ধার করা হয়।
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain ফাঁস হওয়া অবস্থায় নিরাপদ থাকতে self.vec দৈর্ঘ্যের সেট শুরু করুন
            self.set_len(start);
            // পুরো Drain পুনরুক্তিকারী (যেমন &mut টি) এর orrowণ গ্রহণের আচরণ নির্দেশ করতে IterMut এ orrowণ ব্যবহার করুন।
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector সাফ করে সমস্ত মান মুছে ফেলে।
    ///
    /// নোট করুন যে vector এর বরাদ্দ ক্ষমতার উপর এই পদ্ধতির কোনও প্রভাব নেই।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector এ থাকা উপাদানগুলির সংখ্যা প্রদান করে, এটির 'length' হিসাবেও উল্লেখ করা হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector তে কোনও উপাদান না থাকলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// প্রদত্ত সূচকে দুটি সংগ্রহকে বিভক্ত করে।
    ///
    /// `[at, len)` রেঞ্জের এলিমেন্টগুলি সহ একটি নতুন বরাদ্দ হওয়া vector প্রদান করে।
    /// কল করার পরে, আসল vector এর পূর্বের ক্ষমতাটি অপরিবর্তিত রেখে `[0, at)` উপাদানগুলি রেখে যাবে।
    ///
    ///
    /// # Panics
    ///
    /// `at > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // নতুন vector আসল বাফারটি নিতে এবং অনুলিপিটি এড়াতে পারে
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // অনিরাপদভাবে `set_len` এবং আইটেমগুলি `other` এ অনুলিপি করুন।
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec`-কে স্থানান্তরিত করে যাতে `len` `new_len` এর সমান হয়।
    ///
    /// যদি `new_len` এক্স01 এক্স এর চেয়ে বেশি হয় তবে এক্স03 এক্স পার্থক্য দ্বারা প্রসারিত হবে, প্রতিটি অতিরিক্ত স্লট ক্লোজার এক্স 100 এক্স কল করার ফলে ভরাট হবে।
    ///
    /// `f` থেকে ফেরতের মানগুলি `Vec` এ শেষ হবে যাতে তারা উত্পন্ন হয়েছে।
    ///
    /// `new_len` যদি `len` এর চেয়ে কম হয়, তবে `Vec` কেটে নেওয়া হয়।
    ///
    /// এই পদ্ধতিটি প্রতিটি ধাক্কায় নতুন মান তৈরি করতে ক্লোজার ব্যবহার করে।আপনি যদি একটি প্রদত্ত মান [`Clone`] এর চেয়ে পছন্দ করেন তবে [`Vec::resize`] ব্যবহার করুন।
    /// যদি মানগুলি উত্পন্ন করতে আপনি [`Default`] trait ব্যবহার করতে চান তবে আপনি দ্বিতীয় যুক্তি হিসাবে [`Default::default`] পাস করতে পারেন।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// এক্স 00 এক্স গ্রহণ করে এবং ফাঁস করে, বিষয়বস্তুগুলির একটি পরিবর্তনীয় রেফারেন্স প্রদান করে, `&'a mut [T]`.
    /// নোট করুন যে `T` টাইপটি অবশ্যই নির্বাচিত আজীবন এক্স00 এক্সকে বহন করবে।
    /// এই ধরণের যদি কেবল স্থিতিশীল রেফারেন্স থাকে তবে বা কোনওটিই না, তবে এটি `'static` হিসাবে বেছে নেওয়া যেতে পারে।
    ///
    /// এই ফাংশনটি [`Box`] এর [`leak`][Box::leak] ফাংশনের সমান, লিক করা স্মৃতি পুনরুদ্ধারের কোনও উপায় নেই except
    ///
    ///
    /// এই ফাংশনটি মূলত সেই ডেটার জন্য দরকারী যা প্রোগ্রামটির বাকি অংশের জন্য বেঁচে থাকে।
    /// প্রত্যাবর্তিত রেফারেন্সটি বাদ দেওয়া মেমরির ফাঁসির কারণ হবে।
    ///
    /// # Examples
    ///
    /// সাধারণ ব্যবহার:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector এর অবশিষ্ট অতিরিক্ত ক্ষমতাটি `MaybeUninit<T>` এর স্লাইস হিসাবে প্রদান করে।
    ///
    /// ফিরে আসা স্লাইসটি ডেটা (উদাহরণস্বরূপ) vector পূরণ করার জন্য ব্যবহার করা যেতে পারে
    /// [`set_len`] পদ্ধতিটি ব্যবহার করে আরম্ভিত হিসাবে ডেটা চিহ্নিত করার আগে কোনও ফাইল থেকে পড়ে)
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 টি উপাদানের জন্য যথেষ্ট বড় vector বরাদ্দ করুন।
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // প্রথম 3 টি উপাদান পূরণ করুন।
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector এর প্রথম 3 উপাদান প্রাথমিক হিসাবে চিহ্নিত করুন।
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // বাফারে পয়েন্টারের অবৈধতা রোধ করতে এই পদ্ধতিটি `split_at_spare_mut` এর শর্তে কার্যকর করা হয় না।
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector সামগ্রীটি `T` এর স্লাইস হিসাবে, vector এর অবশিষ্ট অতিরিক্ত ক্ষমতা `MaybeUninit<T>` এর টুকরো হিসাবে প্রদান করে।
    ///
    /// [`set_len`] পদ্ধতিটি ব্যবহার করে আরম্ভিকৃত হিসাবে ডেটা চিহ্নিত করার আগে ফিরিয়ে নেওয়া অতিরিক্ত ক্ষমতার টুকরোটি vector পূরণ করতে ব্যবহার করা যেতে পারে (উদাহরণস্বরূপ কোনও ফাইল থেকে পড়ে)।
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// নোট করুন যে এটি একটি নিম্ন-স্তরের এপিআই, যা অপ্টিমাইজেশনের উদ্দেশ্যে যত্ন সহ ব্যবহার করা উচিত।
    /// যদি আপনার কোনও `Vec` এ ডেটা যুক্ত করতে হয় তবে আপনার সঠিক প্রয়োজনের উপর নির্ভর করে আপনি [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] বা [`resize_with`] ব্যবহার করতে পারেন।
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 টি উপাদানের জন্য অতিরিক্ত বড় স্থান সংরক্ষণ করুন।
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // পরবর্তী 4 টি উপাদান পূরণ করুন।
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector এর 4 টি উপাদানকে প্রাথমিক হিসাবে চিহ্নিত করুন।
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - লেন উপেক্ষা করা হয় এবং তাই কখনও পরিবর্তন করা হয়
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// সুরক্ষা: পরিবর্তিত .2 (&mut ইউজাইজ) কে `.set_len(_)` কল করার সমান মনে করা হয়।
    ///
    /// এই পদ্ধতিটি `extend_from_within` এ একবারে সমস্ত ভ্যাক্ট অংশগুলিতে অনন্য অ্যাক্সেস ব্যবহার করতে ব্যবহৃত হয়।
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` উপাদানগুলির জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত
        // - `spare_ptr` বাফারের অতীততে একটি উপাদান নির্দেশ করছে, তাই এটি `initialized` এর সাথে ওভারল্যাপ হয় না
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec`-কে স্থানান্তরিত করে যাতে `len` `new_len` এর সমান হয়।
    ///
    /// যদি `new_len` এক্স01 এক্স এর চেয়ে বড় হয়, প্রতিটি অতিরিক্ত স্লট এক্স 100 এক্স দিয়ে পূর্ণ করে `Vec` পার্থক্য দ্বারা প্রসারিত করা হয়।
    ///
    /// `new_len` যদি `len` এর চেয়ে কম হয়, তবে `Vec` কেটে নেওয়া হয়।
    ///
    /// পাস হওয়া মানটিকে ক্লোন করতে সক্ষম হওয়ার জন্য এই পদ্ধতিতে [`Clone`] বাস্তবায়নের জন্য `T` প্রয়োজন।
    /// আপনার যদি আরও নমনীয়তার প্রয়োজন হয় (বা [`Clone`] এর পরিবর্তে [`Vec::resize_with`] উপর নির্ভর করতে চান), এক্স00 এক্স ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// ক্লোনস এবং `Vec` এ স্লাইসে সমস্ত উপাদান যুক্ত করে।
    ///
    /// স্লাইস `other` এর উপর দিয়ে আইট্রেট করে, প্রতিটি উপাদানকে ক্লোন করে এবং তারপরে এটিকে `Vec` এ যুক্ত করে।
    /// `other` vector ক্রমানুসারে বিপরীত হয়েছে।
    ///
    /// মনে রাখবেন যে এই ফাংশনটি [`extend`] এর সমান, এটি বাদে স্লাইসগুলির সাথে কাজ করার জন্য বিশেষজ্ঞ করা হয়েছে।
    ///
    /// যদি এবং জেড0 আরস্ট0 জেড স্পেশালাইজেশন পেয়ে থাকে তবে এই ফাংশনটি হ্রাস পাবে (তবে এখনও উপলব্ধ)।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` থেকে vector এর শেষ পর্যন্ত উপাদানগুলি অনুলিপি করে।
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` গ্যারান্টি দেয় যে প্রদত্ত পরিসরটি স্ব সূচিকরণের জন্য বৈধ
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// এই কোডটি `extend_with_{element,default}` কে সাধারণীকরণ করে।
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// প্রদত্ত জেনারেটরটি ব্যবহার করে `n` মান দ্বারা vector প্রসারিত করুন।
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // বাগের আশেপাশে কাজ করার জন্য সেটলেনঅনড্রপ ব্যবহার করুন যেখানে সংকলক `ptr` এর মাধ্যমে self.set_len() এর মাধ্যমে উপনামটি না করে স্টোরটি উপলব্ধি করতে পারে না।
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // শেষটি বাদে সমস্ত উপাদান লিখুন
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics ক্ষেত্রে প্রতিটি পদক্ষেপে দৈর্ঘ্য বৃদ্ধি করুন
                local_len.increment_len(1);
            }

            if n > 0 {
                // আমরা অযথা ক্লোনিং না করে সরাসরি শেষ উপাদানটি লিখতে পারি
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // স্কোপ গার্ড দ্বারা লেন সেট
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait বাস্তবায়ন অনুযায়ী vector এ পরপর পুনরাবৃত্তি উপাদানগুলি সরিয়ে দেয়।
    ///
    ///
    /// vector বাছাই করা থাকলে, এটি সমস্ত সদৃশ সরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// অভ্যন্তরীণ পদ্ধতি এবং ফাংশন
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` বৈধ সূচক হওয়া দরকার
    /// - `self.capacity() - self.len()` অবশ্যই `>= src.len()` হওয়া উচিত
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - উপাদানগুলি আরম্ভ করার পরে লেন বৃদ্ধি করা হয়
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - কলার গ্যারান্টি দেয় যে src একটি বৈধ সূচক
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - এলিমেন্টটি সবেমাত্র `MaybeUninit::write` দিয়ে শুরু করা হয়েছিল, সুতরাং লেন বাড়ানো ঠিক
            // - লিক প্রতিরোধের জন্য প্রতিটি উপাদান পরে লেন বৃদ্ধি করা হয় (দেখুন #82533 ইস্যু)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - কলার গ্যারান্টি দেয় যে `src` একটি বৈধ সূচক
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - উভয় পয়েন্টারই অনন্য স্লাইস রেফারেন্স (`&mut [_]।) থেকে তৈরি করা হয়েছে যাতে তারা বৈধ হয় এবং ওভারল্যাপ হয় না।
            //
            // - উপাদানগুলি হ'ল: অনুলিপি করুন তাই মূল মানগুলির সাথে কিছু না করে এগুলি অনুলিপি করা ঠিক
            // - `count` `source` এর লেনের সমান, তাই `count` পঠনের জন্য উত্সটি বৈধ
            // - `.reserve(count)` গ্যারান্টি দেয় যে `spare.len() >= count` তাই অতিরিক্ত `count` লেখার জন্য বৈধ
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - উপাদানগুলি সবেমাত্র `copy_nonoverlapping` দ্বারা সূচনা করা হয়েছিল
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// ভেকের জন্য সাধারণ trait বাস্তবায়ন
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) সহ অন্তর্নিহিত `[T]::to_vec` পদ্ধতিটি যা এই পদ্ধতির সংজ্ঞার জন্য প্রয়োজনীয় তা উপলভ্য নয়।
    // পরিবর্তে `slice::to_vec` ফাংশনটি ব্যবহার করুন যা কেবলমাত্র cfg(test) NB এর সাথে উপলভ্য রয়েছে আরও তথ্যের জন্য slice.rs-এ slice::hack মডিউলটি দেখুন
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ওভাররাইট করা হবে না এমন কিছু ফেলে দিন
        self.truncate(other.len());

        // self.len <= other.len উপরের কাটা কাটা কারণে, সুতরাং এখানে টুকরো সবসময় অন্তঃসীমা।
        //
        let (init, tail) = other.split_at(self.len());

        // এক্সট্রেসযুক্ত মানগুলিকে পুনরায় ব্যবহার করুন।
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// একটি গ্রাসকারী আয়রেটর তৈরি করে, এটি এমন একটি যা প্রতিটি মান vector এর বাইরে (শুরু থেকে শেষের দিকে) সরিয়ে দেয়।
    /// vector এ কল করার পরে ব্যবহার করা যাবে না।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s এর স্ট্রিং রয়েছে &String নয়
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // লিফ পদ্ধতিতে যার জন্য বিভিন্ন এক্স00 এক্স বাস্তবায়ন যখন তাদের কাছে প্রয়োগ করার জন্য আরও কোনও অপ্টিমাইজেশন নেই তখন তারা তাদের প্রতিনিধিত্ব করে
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // এটি একটি সাধারণ পুনরাবৃত্তির ক্ষেত্রে।
        //
        // এই ফাংশনটির নৈতিক সমতুল্য হওয়া উচিত:
        //
        //      পুনরুক্তিকারী আইটেম জন্য {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // আমাদের ঠিকানার জায়গা বরাদ্দ করতে হবে বলে এনবি ওভারফ্লো করতে পারে না
                self.set_len(len + 1);
            }
        }
    }

    /// একটি বিভক্ত পুনরুক্তি তৈরি করে যা প্রদত্ত `replace_with` পুনরুক্তি দিয়ে vector এ নির্দিষ্ট রেঞ্জটি প্রতিস্থাপন করে এবং সরানো আইটেমগুলি দেয়।
    ///
    /// `replace_with` `range` এর সমান দৈর্ঘ্য হওয়ার দরকার নেই।
    ///
    /// `range` এমনকি যদি শেষ না হওয়া পর্যন্ত পুনরুক্তি গ্রহণ করা না হয় তবে সরানো হয়।
    ///
    /// `Splice` মান ফাঁস হয়ে গেলে কতগুলি উপাদান vector থেকে সরানো হবে তা অনির্ধারিত।
    ///
    /// এক্সপুট পুনরুক্তিকারী `replace_with` কেবলমাত্র এক্স01 এক্স এর মান বাদ দিলে গ্রাস করা হয়।
    ///
    /// এটি সর্বোত্তম যদি:
    ///
    /// * লেজ (`range` এর পরে vector এর উপাদানগুলি) খালি রয়েছে,
    /// * বা `replace_with` `রেঞ্জের দৈর্ঘ্যের চেয়ে কম বা সমমানের উপাদান দেয়
    /// * বা এর `size_hint()` এর নীচের সীমানাটি হুবহু।
    ///
    /// অন্যথায়, একটি অস্থায়ী vector বরাদ্দ করা হয় এবং পুচ্ছ দু'বার সরানো হয়।
    ///
    /// # Panics
    ///
    /// Panics যদি প্রারম্ভিক পয়েন্টটি শেষ পয়েন্টের চেয়ে বেশি হয় বা শেষ বিন্দু vector দৈর্ঘ্যের চেয়ে বেশি হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// এমন একটি পুনরুক্তি তৈরি করে যা কোনও উপাদান অপসারণ করা উচিত কিনা তা নির্ধারণের জন্য ক্লোজার ব্যবহার করে।
    ///
    /// যদি বন্ধটি সত্যটি ফিরে আসে, তবে উপাদানটি সরানো হবে এবং ফলন হবে।
    /// যদি ক্লোজারটি মিথ্যা প্রত্যাবর্তন করে তবে উপাদানটি vector এ থাকবে এবং পুনরুক্তি দ্বারা উত্পাদিত হবে না।
    ///
    /// এই পদ্ধতিটি ব্যবহার করা নিম্নলিখিত কোডের সমতুল্য:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // আপনার কোড এখানে
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// তবে এক্স00 এক্স ব্যবহার করা সহজ।
    /// `drain_filter` এটি আরও দক্ষ, কারণ এটি অ্যারের উপাদানগুলিকে প্রচুর পরিমাণে ব্যাকশিফ্ট করতে পারে।
    ///
    /// দ্রষ্টব্য যে `drain_filter` আপনাকে ফিল্টার বন্ধের প্রতিটি উপাদানকে পরিবর্তিত করতে দেয়, আপনি তা রাখার বা অপসারণ নির্বাচন না করেই নির্বিশেষে।
    ///
    ///
    /// # Examples
    ///
    /// আসল বরাদ্দ পুনঃব্যবহার করে সন্ধ্যা ও প্রতিকূলতার মধ্যে একটি অ্যারের বিভাজন:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // ফাঁস হওয়ার বিরুদ্ধে আমাদের প্রতিরোধ করুন (ফাঁস প্রশস্তকরণ)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// প্রয়োগকে প্রসারিত করুন যা উপাদানগুলিকে ভিস্কে চাপ দেওয়ার আগে রেফারেন্সগুলির বাইরে অনুলিপি করে।
///
/// এই প্রয়োগটি স্লাইস পুনরাবৃত্তির জন্য বিশেষীকরণ করা হয়েছে, যেখানে এটি একবারে পুরো স্লাইস যুক্ত করার জন্য [`copy_from_slice`] ব্যবহার করে।
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors এর তুলনা কার্যকর করে [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors এর অর্ডারিং কার্যকর করে [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // এক্স 00 এক্স এর জন্য ড্রপ ব্যবহার করুন জেডভেেক্টর0 জেড এর উপাদানগুলিকে দুর্বল প্রয়োজনীয় প্রকার হিসাবে উল্লেখ করতে একটি কাঁচা টুকরো ব্যবহার করুন;
            //
            // নির্দিষ্ট ক্ষেত্রে বৈধতার প্রশ্ন এড়াতে পারে
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec হ্রাস পরিচালনা করে
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// একটি খালি `Vec<T>` তৈরি করে।
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: পরীক্ষা libstd এ টান দেয়, যা এখানে ত্রুটি ঘটায়
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: পরীক্ষা libstd এ টান দেয়, যা এখানে ত্রুটি ঘটায়
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` এর সম্পূর্ণ সামগ্রীটিকে অ্যারে হিসাবে পাওয়া যায়, যদি এর আকার অনুরোধ করা অ্যারের সাথে ঠিক মেলে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// দৈর্ঘ্যটি যদি মেলে না, তবে ইনপুটটি `Err` এ ফিরে আসবে:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// আপনি যদি `Vec<T>` এর কেবল একটি উপসর্গ পেয়ে থাকেন তবে আপনি প্রথমে [`.truncate(N)`](Vec::truncate) কল করতে পারেন।
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // নিরাপদ: এক্স 100 এক্স সর্বদা স্বাচ্ছন্দ্যযুক্ত।
        unsafe { vec.set_len(0) };

        // নিরাপত্তা: একটি `ভেকের পয়েন্টারটি সর্বদা সঠিকভাবে সাজানো থাকে এবং
        // অ্যারের প্রয়োজনীয় প্রান্তিককরণটি আইটেমগুলির সমান।
        // আমরা আগে পরীক্ষা করেছিলাম যে আমাদের পর্যাপ্ত আইটেম রয়েছে।
        // `set_len` এক্স01 এক্সগুলিকে এগুলি ফেলে নাও বলে আইটেমগুলি ডাবল-ড্রপ হবে না।
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}