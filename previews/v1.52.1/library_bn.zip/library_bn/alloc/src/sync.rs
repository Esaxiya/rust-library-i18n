#![stable(feature = "rust1", since = "1.0.0")]

//! থ্রেড-নিরাপদ রেফারেন্স-কাউন্টিং পয়েন্টার।
//!
//! আরও তথ্যের জন্য [`Arc<T>`][Arc] ডকুমেন্টেশন দেখুন।

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// কোনও `Arc` এ করা যেতে পারে এমন পরিমাণের রেফারেন্সের উপর একটি নরম সীমা।
///
/// এই সীমা ছাড়িয়ে গেলে আপনার প্রোগ্রামটি বাতিল করতে হবে (যদিও প্রয়োজনীয় নয়) _exactly_ `MAX_REFCOUNT + 1` রেফারেন্সে।
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// থ্রেডস্যানিটাইজার মেমরি বেড়া সমর্থন করে না।
// আর্ক/দুর্বল প্রয়োগের ক্ষেত্রে মিথ্যা ইতিবাচক প্রতিবেদনগুলি এড়াতে পরিবর্তে সিঙ্ক্রোনাইজেশনের জন্য পারমাণবিক লোড ব্যবহার করুন।
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// একটি থ্রেড-নিরাপদ রেফারেন্স-কাউন্টিং পয়েন্টার।এক্স00 এক্স এর অর্থ 'অ্যাটমিক্যাল রেফারেন্স কাউন্টার'।
///
/// `Arc<T>` টাইপটি গাদাতে বরাদ্দকৃত `T` প্রকারের একটির মালিকানার মালিকানা সরবরাহ করে।`Arc`-এ এক্স03 এক্স চালু করা একটি নতুন এক্স05 এক্স উদাহরণ তৈরি করে, যা উত্স `Arc` হিসাবে গাদাতে একই বরাদ্দকে নির্দেশ করে, যখন একটি রেফারেন্স গণনা বাড়িয়ে তোলে।
/// প্রদত্ত বরাদ্দের সর্বশেষ `Arc` পয়েন্টারটি ধ্বংস হয়ে গেলে সেই বরাদ্দকৃত সঞ্চিত মান (প্রায়শই "inner value" হিসাবে উল্লেখ করা হয়) বাদ দেওয়া হয়।
///
/// Rust-এ ভাগ করা রেফারেন্সগুলি ডিফল্টরূপে মিউটেশনটিকে অস্বীকার করে এবং এক্স04 এক্স এর ব্যতিক্রম নয়: আপনি সাধারণত কোনও `Arc` এর অভ্যন্তরের কোনও কিছুর পরিবর্তনে রেফারেন্স পেতে পারেন না।আপনার যদি কোনও `Arc` এর মাধ্যমে পরিবর্তন করতে হয় তবে [`Mutex`][mutex], [`RwLock`][rwlock] বা এক্স05 এক্স প্রকারের একটি ব্যবহার করুন।
///
/// ## থ্রেড সুরক্ষা
///
/// [`Rc<T>`] এর বিপরীতে, `Arc<T>` তার রেফারেন্স গণনার জন্য পারমাণবিক ক্রিয়াকলাপ ব্যবহার করে।এর অর্থ এটি থ্রেড-নিরাপদ।অসুবিধাটি হ'ল সাধারণ স্মৃতি অ্যাক্সেসের চেয়ে পারমাণবিক ক্রিয়াকলাপগুলি আরও ব্যয়বহুল।আপনি যদি থ্রেডগুলির মধ্যে রেফারেন্স-গণনা করা বরাদ্দ ভাগ করে না নিচ্ছেন তবে লোকে ওভারহেডের জন্য [`Rc<T>`] ব্যবহার বিবেচনা করুন।
/// [`Rc<T>`] একটি নিরাপদ ডিফল্ট, কারণ সংকলক থ্রেডগুলির মধ্যে একটি [`Rc<T>`] প্রেরণের যে কোনও প্রয়াস ধরবে।
/// তবে গ্রন্থাগার গ্রাহকদের আরও নমনীয়তা দেওয়ার জন্য একটি লাইব্রেরি `Arc<T>` বেছে নিতে পারে।
///
/// `Arc<T>` `T` যতক্ষণ [`Send`] এবং [`Sync`] প্রয়োগ করে [`Send`] এবং [`Sync`] প্রয়োগ করবে।
/// থ্রেড-নিরাপদ করতে আপনি কেন একটি এক্স-থার্ড-নিরাপদ প্রকার `T` একটি `Arc<T>` রাখতে পারবেন না?এটি প্রথমে কিছুটা পাল্টা স্বজ্ঞাত হতে পারে: সর্বোপরি, `Arc<T>` থ্রেড সুরক্ষার বিন্দু নয়?মূলটি হ'ল: `Arc<T>` একই ডেটার একাধিক মালিকানা পেতে থ্রেডটিকে নিরাপদ করে তোলে, তবে এটি তার ডেটাতে থ্রেড সুরক্ষা যোগ করে না।
///
/// `আর্ক <` [`রেফসেল বিবেচনা করুন<T>`]`>``
/// [`RefCell<T>`] [`Sync`] নয়, এবং যদি X02 এক্স সর্বদা [`Send`] থাকে, `আর্ক <` [`রেফসেল<T>`]`> পাশাপাশি হবে।
/// তবে তারপরে আমাদের একটি সমস্যা হবে:
/// [`RefCell<T>`] থ্রেড নিরাপদ নয়;এটি অ-পারমাণবিক ক্রিয়াকলাপ ব্যবহার করে orrowণ গ্রহণের গণনা ট্র্যাক করে।
///
/// শেষ পর্যন্ত এর অর্থ হ'ল আপনার `Arc<T>` কে কোনও ধরণের [`std::sync`] টাইপের সাথে সাধারণত [`Mutex<T>`][mutex] জোড়া লাগতে পারে।
///
/// ## `Weak` এর সাথে চক্র ভাঙ্গা
///
/// [`downgrade`][downgrade] পদ্ধতিটি কোনও নন-মালিকানাধীন [`Weak`] পয়েন্টার তৈরি করতে ব্যবহার করা যেতে পারে।একটি এক্স03 এক্স পয়েন্টারটি [`আপগ্রেড][আপগ্রেড] ডি থেকে এক্স এক্স এক্স এ হতে পারে তবে বরাদ্দকৃত সঞ্চিত মানটি ইতিমধ্যে বাদ দেওয়া থাকলে এটি এক্স04 এক্স ফিরে আসবে।
/// অন্য কথায়, এক্স 100 এক্স পয়েন্টারগুলি বরাদ্দের ভিতরে মানটি বাঁচিয়ে রাখে না;তবে, তারা বরাদ্দ (মূল্যের জন্য ব্যাকিং স্টোর) রাখে।
///
/// `Arc` পয়েন্টারগুলির মধ্যে একটি চক্র কখনই বিলোপযুক্ত হবে না।
/// এই কারণে, [`Weak`] চক্র ভাঙ্গতে ব্যবহৃত হয়।উদাহরণস্বরূপ, একটি গাছে পিতামাতৃ নোড থেকে বাচ্চাদের কাছে শক্তিশালী `Arc` পয়েন্টার এবং বাচ্চাদের কাছ থেকে তাদের পিতামাতার কাছে ফিরে আসা [`Weak`] পয়েন্টার থাকতে পারে।
///
/// # ক্লোনিং রেফারেন্স
///
/// বিদ্যমান রেফারেন্স-কাউন্ট পয়েন্টার থেকে একটি নতুন রেফারেন্স তৈরি করা [`Arc<T>`][Arc] এবং [`Weak<T>`][Weak] এর জন্য বাস্তবায়িত `Clone` trait ব্যবহার করে করা হয়।
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // নীচের দুটি বাক্য গঠন সমান।
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b এবং foo হ'ল সমস্ত আরক যা একই মেমরির অবস্থানকে নির্দেশ করে
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` স্বয়ংক্রিয়ভাবে `T`-এর ([`Deref`][deref] trait মাধ্যমে) উল্লেখ করা হয়, যাতে আপনি `Arc<T>` টাইপের মানতে `T` এর পদ্ধতিগুলি কল করতে পারেন।`T` এর পদ্ধতির সাথে নামের সংঘর্ষ এড়াতে, `Arc<T>` এর পদ্ধতিগুলি নিজেই যুক্ত ফাংশন যা [fully qualified syntax] ব্যবহার করে বলা হয়:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `আর্ক<T>`Clone` এর মতো traits এর বাস্তবায়নগুলিও পুরোপুরি যোগ্যতাসম্পন্ন সিনট্যাক্স ব্যবহার করে ডাকা যেতে পারে।
/// কিছু লোক পুরোপুরি যোগ্যতাসম্পন্ন সিনট্যাক্স ব্যবহার করতে পছন্দ করেন, আবার কেউ কেউ মেথড-কল সিনট্যাক্স ব্যবহার করতে পছন্দ করেন।
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // পদ্ধতি-কল সিনট্যাক্স
/// let arc2 = arc.clone();
/// // সম্পূর্ণরূপে যোগ্যতাসম্পন্ন বাক্য গঠন
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T`-এ স্বয়ংক্রিয়-অবলম্বন করে না, কারণ অভ্যন্তরীণ মানটি ইতিমধ্যে বাদ পড়েছে।
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// থ্রেডগুলির মধ্যে কিছু অপরিবর্তনীয় ডেটা ভাগ করা:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// নোট করুন যে আমরা এখানে **এই পরীক্ষাগুলি চালাই না**।
// এক্স থ্রেডস নির্মাতারা অত্যন্ত অসন্তুষ্ট হন যদি কোনও থ্রেড মূল থ্রেডকে আউটলাইভ করে এবং একই সাথে বাইরে বেরিয়ে আসে (কোনও কিছু ডেডলকস) যাতে আমরা কেবল এই পরীক্ষাগুলি না চালিয়ে এটিকে পুরোপুরি এড়িয়ে চলে।
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// একটি পরিবর্তনীয় [`AtomicUsize`] ভাগ করা:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// সাধারণভাবে রেফারেন্স গণনার আরও উদাহরণের জন্য [`rc` documentation][rc_examples] দেখুন।
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] এর একটি সংস্করণ যা পরিচালিত বরাদ্দের কোনও অ-মালিকানা সংক্রান্ত রেফারেন্স ধারণ করে।
/// `Weak` পয়েন্টারে [`upgrade`] কল করে এই বরাদ্দটি অ্যাক্সেস করা হয়েছে, যা একটি [`বিকল্প`] returns <`[`আর্কি]`দেয়<T>>`।
///
/// যেহেতু একটি `Weak` রেফারেন্স মালিকানার দিকে গণনা করে না, এটি বরাদ্দকৃত সঞ্চিত মূল্য বাদ দেওয়া থেকে বিরত রাখবে না এবং এক্স01 এক্স নিজেই এখনও মান উপস্থিত থাকার বিষয়ে কোনও গ্যারান্টি দেয় না।
///
/// [`আপগ্রেড]] d হলে এটি [`None`] ফিরতে পারে।
/// তবে খেয়াল করুন যে একটি `Weak` রেফারেন্স * নিজেই বরাদ্দকে (ব্যাকিং স্টোর) আটকানো থেকে আটকাচ্ছে।
///
/// একটি `Weak` পয়েন্টার [`Arc`] দ্বারা পরিচালিত বরাদ্দটির অস্থায়ী রেফারেন্স রাখার জন্য এর অভ্যন্তরীণ মান বাদ পড়ার ছাড়াই দরকারী।
/// এটি [`Arc`] পয়েন্টারগুলির মধ্যে বিজ্ঞপ্তি সংক্রান্ত রেফারেন্স প্রতিরোধ করতেও ব্যবহৃত হয়, কারণ পারস্পরিক মালিকানার রেফারেন্সগুলি কখনই [`Arc`] কে বাদ দিতে দেয় না।
/// উদাহরণস্বরূপ, একটি গাছে পিতামাতৃ নোড থেকে বাচ্চাদের কাছে শক্তিশালী [`Arc`] পয়েন্টার এবং বাচ্চাদের কাছ থেকে তাদের পিতামাতার কাছে ফিরে আসা `Weak` পয়েন্টার থাকতে পারে।
///
/// `Weak` পয়েন্টারটি পাওয়ার সাধারণ উপায়টি হল [`Arc::downgrade`] কল করা।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // এনামগুলিতে এই ধরণের আকারের অনুকূলকরণের অনুমতি দেওয়ার জন্য এটি একটি এক্স 100 এক্স, তবে এটি অবশ্যই একটি বৈধ পয়েন্টার নয়।
    //
    // `Weak::new` এটি `usize::MAX` এ সেট করে যাতে এটির গাদাতে স্থান বরাদ্দের প্রয়োজন হয় না।
    // এটির আসল পয়েন্টারটির কোনও মূল্য নেই কারণ আরসিবক্সের কমপক্ষে 2 প্রান্তিককরণ রয়েছে।
    // এটি কেবল তখনই সম্ভব যখন এক্স 100 এক্স;আনসাইজড এক্স01 এক্স কখনই বিড়ম্বনা করে না।
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// সম্ভাব্য ফিল্ড-অর্ডারিংয়ের বিপরীতে এটি repr(C) থেকে জেডফিউচার0 জেড-প্রুফ, এটি ট্রান্সম্যাটেবল অভ্যন্তরীণ প্রকারের অন্যথায় নিরাপদ [into|from]_raw() হস্তক্ষেপ করবে।
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX মানটি অস্থায়ীভাবে "locking" এর জন্য প্রেরণেল হিসাবে দুর্বল পয়েন্টারগুলিকে আপগ্রেড করার ক্ষমতা বা শক্তিশালীকে ডাউনগ্রেড করার ক্ষমতা হিসাবে কাজ করে;এটি `make_mut` এবং `get_mut` এর দৌড়গুলি এড়ানোর জন্য ব্যবহৃত হয়।
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// একটি নতুন `Arc<T>` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // X হিসাবে দুর্বল পয়েন্টার গণনাটি 1 হিসাবে শুরু করুন যা সমস্ত শক্তিশালী পয়েন্টার (kinda) এর অধীনে রয়েছে, আরও তথ্যের জন্য std/rc.rs দেখুন
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// নিজের প্রতি দুর্বল রেফারেন্স ব্যবহার করে একটি নতুন এক্স00 এক্স তৈরি করে।
    /// এই ফাংশনটি ফেরত দেওয়ার আগে দুর্বল রেফারেন্সকে আপগ্রেড করার চেষ্টা করার ফলে একটি `None` মান হবে।
    /// তবে, দুর্বল রেফারেন্সটি নির্দ্বিধায় ক্লোন করা এবং পরে ব্যবহারের জন্য সংরক্ষণ করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // একক দুর্বল রেফারেন্স সহ "uninitialized" রাজ্যের অভ্যন্তরটি তৈরি করুন।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // এটি গুরুত্বপূর্ণ যে আমরা দুর্বল পয়েন্টারের মালিকানা ছেড়ে দেব না, নাহলে `data_fn` রিটার্নের সময় দিয়ে মেমরিটি মুক্ত হয়ে যেতে পারে।
        // আমরা যদি সত্যই মালিকানাটি পাস করতে চাইতাম, আমরা নিজের জন্য একটি অতিরিক্ত দুর্বল পয়েন্টার তৈরি করতে পারতাম, তবে এর ফলে দুর্বল রেফারেন্স গণনায় অতিরিক্ত আপডেট হতে পারে যা অন্যথায় প্রয়োজনীয় হতে পারে না।
        //
        //
        //
        //
        let data = data_fn(&weak);

        // এখন আমরা সঠিকভাবে অভ্যন্তরীণ মানটি আরম্ভ করতে পারি এবং আমাদের দুর্বল রেফারেন্সটিকে শক্তিশালী রেফারেন্সে পরিণত করতে পারি।
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // উপাত্ত ক্ষেত্রের উপরের লেখার অবশ্যই কোনও থ্রেডের কাছে দৃশ্যমান হতে হবে যা একটি অ-শূন্য শক্তিশালী গণনা পালন করে।
            // সুতরাং `Weak::upgrade` এ `compare_exchange_weak` এর সাথে সিঙ্ক্রোনাইজ করার জন্য আমাদের কমপক্ষে "Release" ক্রম প্রয়োজন।
            //
            // "Acquire" অর্ডার প্রয়োজন হয় না।
            // `data_fn` এর সম্ভাব্য আচরণগুলি বিবেচনা করার সময় আমাদের কেবল এটি অপরিবর্তনীয় `Weak` এর রেফারেন্স সহ কী করতে পারে তা খতিয়ে দেখা দরকার:
            //
            // - এটি দুর্বল রেফারেন্স গণনা বাড়িয়ে `Weak`* * ক্লোন করতে পারে।
            // - এটি সেই ক্লোনগুলি ফেলে দিতে পারে, দুর্বল রেফারেন্স গণনা হ্রাস করে (তবে কখনই শূন্য হয় না)।
            //
            // এই পার্শ্ব প্রতিক্রিয়াগুলি কোনওভাবেই আমাদের প্রভাবিত করে না এবং নিরাপদ কোডের সাহায্যে অন্য কোনও পার্শ্ব প্রতিক্রিয়া সম্ভব নয়।
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // শক্তিশালী রেফারেন্সগুলি সম্মিলিতভাবে ভাগ করা দুর্বল রেফারেন্সের মালিক হওয়া উচিত, সুতরাং আমাদের পুরানো দুর্বল রেফারেন্সের জন্য ডেস্ট্রাক্টর চালাবেন না।
        //
        mem::forget(weak);
        strong
    }

    /// অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন এক্স00 এক্স গঠন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// এক্স01 এক্স বাইট দিয়ে মেমরিটি ভরাট হওয়ার সাথে সাথে অবিচ্ছিন্ন সামগ্রীগুলির সাথে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// একটি নতুন `Pin<Arc<T>>` তৈরি করে।
    /// যদি `T` `Unpin` বাস্তবায়িত না করে, তবে এক্স0 2 এক্স মেমরিতে পিন হয়ে যাবে এবং সরানো যায় না।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফিরিয়ে নতুন `Arc<T>` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // X হিসাবে দুর্বল পয়েন্টার গণনাটি 1 হিসাবে শুরু করুন যা সমস্ত শক্তিশালী পয়েন্টার (kinda) এর অধীনে রয়েছে, আরও তথ্যের জন্য std/rc.rs দেখুন
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন এক্স00 এক্স তৈরি করে, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফেরায়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// এক্সটায়ালাইজড সামগ্রী সহ নতুন `Arc` তৈরি করে, মেমরিটি `0` বাইট দিয়ে ভরাট করা হয়, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফিরিয়ে দেয়।
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` এর ঠিক একটি দৃ strong় রেফারেন্স থাকলে অভ্যন্তরীণ মানটি প্রদান করে।
    ///
    /// অন্যথায়, একটি [`Err`] একই `Arc` এর সাথে পাস করা হয়েছিল।
    ///
    ///
    /// অসামান্য দুর্বল উল্লেখ থাকলেও এটি সফল হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // অন্তর্নিহিত দৃ strong়-দুর্বল রেফারেন্সটি পরিষ্কার করতে একটি দুর্বল পয়েন্টার করুন
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন পারমাণবিকভাবে রেফারেন্স-গণনা করা স্লাইস তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// এক্সটিএক্সএক্স বাইটে মেমরিটি ভরাট হওয়ার সাথে সাথে অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন পারমাণবিকভাবে রেফারেন্স-গণনা করা স্লাইস তৈরি করে।
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` এ রূপান্তর করে।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] এর মতো, অভ্যন্তরীণ মানটি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।
    ///
    /// সামগ্রীটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এটিকে কল করা তাত্ক্ষণিক সংজ্ঞায়িত আচরণের কারণ হয়।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` এ রূপান্তর করে।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] এর মতো, অভ্যন্তরীণ মানটি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।
    ///
    /// সামগ্রীটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এটিকে কল করা তাত্ক্ষণিক সংজ্ঞায়িত আচরণের কারণ হয়।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// মোড়ানো পয়েন্টারটি ফিরে, `Arc` গ্রহণ করে।
    ///
    /// মেমরি ফাঁস এড়াতে পয়েন্টারটি অবশ্যই [`Arc::from_raw`] ব্যবহার করে একটি `Arc` এ রূপান্তর করতে হবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ডেটাতে একটি কাঁচা পয়েন্টার সরবরাহ করে।
    ///
    /// গণনাগুলি কোনওভাবেই প্রভাবিত হয় না এবং `Arc` সেবন হয় না।
    /// এক্স 100 এক্সে শক্তিশালী গণনা রয়েছে ততক্ষণ পয়েন্টারটি বৈধ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // সুরক্ষা: এটি Deref::deref বা RcBoxPtr::inner এর মাধ্যমে যেতে পারে না কারণ এটি
        // এটি যেমন raw/mut প্রবণতা ধরে রাখা প্রয়োজন eg
        // `get_mut` `from_raw` এর মাধ্যমে আরসিটি পুনরুদ্ধারের পরে পয়েন্টারটির মাধ্যমে লিখতে পারে।
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// কাঁচা পয়েন্টার থেকে একটি `Arc<T>` তৈরি করে।
    ///
    /// কাঁচা পয়েন্টারটি অবশ্যই [`Arc<U>::into_raw`][into_raw] এ কল দিয়ে ফিরে এসেছে যেখানে `U` এর অবশ্যই `T` এর মতো আকার এবং প্রান্তিককরণ থাকতে হবে।
    /// `U` যদি `T` হয় তবে এটি তুচ্ছভাবে সত্য।
    /// মনে রাখবেন যে `U` যদি X01 এক্স না হয় তবে একই আকার এবং প্রান্তিককরণ থাকে তবে এটি মূলত বিভিন্ন ধরণের রেফারেন্স ট্রান্সমুটিংয়ের মতো।
    /// এই ক্ষেত্রে কী সীমাবদ্ধতা প্রযোজ্য সে সম্পর্কে আরও তথ্যের জন্য [`mem::transmute`][transmute] দেখুন।
    ///
    /// `from_raw`-এর ব্যবহারকারীকে `T` এর নির্দিষ্ট মানটি একবারে বাদ দেওয়া হয়েছে তা নিশ্চিত করতে হবে।
    ///
    /// এই ফাংশনটি অনিরাপদ কারণ অনুচিত ব্যবহারের কারণে স্মৃতিশক্তি অসম্পূর্ণ হতে পারে, এমনকি যদি ফিরে আসা `Arc<T>` কখনও অ্যাক্সেস না করা হয়।
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ফুটো রোধ করতে একটি `Arc` এ ফিরে রূপান্তর করুন।
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` এ আরও কলগুলি মেমরি-অনিরাপদ হবে।
    /// }
    ///
    /// // `x` উপরের সুযোগের বাইরে চলে যাওয়ার পরে মেমরিটি মুক্ত হয়েছিল, তাই এক্স01 এক্স এখন ঝুঁকছে!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // আসল আর্কইনার খুঁজে পেতে অফসেটটি বিপরীত করুন।
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// এই বরাদ্দে একটি নতুন এক্স00 এক্স পয়েন্টার তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // এই রিলাক্সড ঠিক আছে কারণ আমরা নীচের সিএএসে মানটি যাচাই করছি।
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // দুর্বল কাউন্টারটি বর্তমানে "locked" কিনা তা পরীক্ষা করুন;যদি তাই হয়, স্পিন।
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: এই কোডটি বর্তমানে অতিরিক্ত প্রবাহের সম্ভাবনা উপেক্ষা করে
            // usize::MAX মধ্যে;সাধারণভাবে আরসি এবং আর্ক উভয়ই ওভারফ্লো নিয়ে কাজ করার জন্য সামঞ্জস্য করা দরকার।
            //

            // Clone() এর বিপরীতে, `is_unique` থেকে আসা লেখার সাথে সুসংগত করার জন্য আমাদের এ্যাকুইয়ার রিড হওয়া দরকার, যাতে লেখার আগের ঘটনাগুলি এই পঠনের আগে ঘটে।
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // নিশ্চিত করুন যে আমরা কোনও ঝোলা দুর্বল তৈরি করি না
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// এই বরাদ্দে [`Weak`] পয়েন্টার সংখ্যা পায়।
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি নিজেই নিরাপদ তবে এটি সঠিকভাবে ব্যবহার করার জন্য অতিরিক্ত যত্ন প্রয়োজন।
    /// এই পদ্ধতিতে কল করা এবং ফলাফলটিতে অভিনয় করার মধ্যে সম্ভাব্য সহ আরও একটি থ্রেড যে কোনও সময় দুর্বল গণনা পরিবর্তন করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // এই দাবিটি নির্বিচারক কারণ কারণ আমরা থ্রেডগুলির মধ্যে `Arc` বা `Weak` ভাগ করি নি।
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // যদি দুর্বল গণনাটি বর্তমানে লক করা থাকে তবে লকটি নেওয়ার ঠিক আগে গণনার মান 0 ছিল।
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// এই বরাদ্দটিতে শক্তিশালী (`Arc`) পয়েন্টার সংখ্যা পায়।
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি নিজেই নিরাপদ তবে এটি সঠিকভাবে ব্যবহার করার জন্য অতিরিক্ত যত্ন প্রয়োজন।
    /// এই পদ্ধতিতে কল করা এবং ফলাফলটিতে অভিনয় করার মধ্যে সম্ভাব্য সহ আরও একটি থ্রেড যে কোনও সময় শক্তিশালী গণনা পরিবর্তন করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // এই দাবিটি নির্বিচারক কারণ আমরা থ্রেডগুলির মধ্যে `Arc` ভাগ করি নি।
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// একের পর এক প্রদত্ত পয়েন্টারের সাথে যুক্ত `Arc<T>` এর শক্তিশালী রেফারেন্স গণনা বৃদ্ধি করে।
    ///
    /// # Safety
    ///
    /// পয়েন্টারটি অবশ্যই `Arc::into_raw` এর মাধ্যমে প্রাপ্ত হওয়া উচিত এবং সম্পর্কিত `Arc` উদাহরণটি অবশ্যই বৈধ হতে হবে (যেমন
    /// এই পদ্ধতির সময়কালের জন্য শক্তিশালী গণনা কমপক্ষে 1 হতে হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // এই দাবিটি নির্বিচারক কারণ আমরা থ্রেডগুলির মধ্যে `Arc` ভাগ করি নি।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // আর্ক ধরে রাখুন, তবে ম্যানুয়ালিড্রপ মোড়ক করে পুনরায় গণনা স্পর্শ করবেন না
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // এখন পুনঃকাউন্ট বাড়ান, তবে নতুন রি-কাউন্টও বাদ দেবেন না
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// সরবরাহ করা পয়েন্টারের সাথে এক দ্বারা যুক্ত `Arc<T>` এর শক্তিশালী রেফারেন্স গণনা হ্রাস করে।
    ///
    /// # Safety
    ///
    /// পয়েন্টারটি অবশ্যই `Arc::into_raw` এর মাধ্যমে প্রাপ্ত হওয়া উচিত এবং সম্পর্কিত `Arc` উদাহরণটি অবশ্যই বৈধ হতে হবে (যেমন
    /// শক্তিশালী গণনা কমপক্ষে 1 হওয়া উচিত) এই পদ্ধতিটি চালু করার সময়।
    /// এই পদ্ধতিটি চূড়ান্ত এক্স 100 এক্স এবং ব্যাকিং স্টোরেজ প্রকাশ করতে ব্যবহৃত হতে পারে তবে চূড়ান্ত এক্স01 এক্স প্রকাশের পরে ** বলা উচিত নয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // এই বক্তব্যগুলি নির্বিচারবাদী কারণ আমরা থ্রেডগুলির মধ্যে `Arc` ভাগ করি নি।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // এটি অনর্থক ঠিক আছে কারণ এই চাপটি জীবিত থাকাকালীন আমাদের গ্যারান্টিযুক্ত যে অভ্যন্তরীণ পয়েন্টারটি বৈধ।
        // তদুপরি, আমরা জানি যে `ArcInner` কাঠামো নিজেই `Sync` কারণ অভ্যন্তরীণ তথ্যগুলিও `Sync`, তাই আমরা ঠিক এই বিষয়বস্তুগুলিতে একটি অপরিবর্তনীয় পয়েন্টার loanণ নিচ্ছি।
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // এক্স00 এক্স এর অন্তর্নিহিত অংশ।
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // এই মুহুর্তে ডেটাটি ধ্বংস করুন, যদিও আমরা বাক্স বরাদ্দটি নিজেই মুক্ত না করতে পারি (এরপরে এখনও দুর্বল পয়েন্টার থাকতে পারে)।
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // সমস্ত শক্তিশালী রেফারেন্সের দ্বারা সম্মিলিতভাবে দুর্বল রেফারেল ড্রপ করুন
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// যদি দুটি `আর্ক alloc একই বরাদ্দে নির্দেশ করে তবে `true` প্রদান করে ([`ptr::eq`] এর মতো শিরাতে)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// সম্ভাব্য-অচলিত অভ্যন্তরীণ মানের যেখানে মানটির বিন্যাসটি সরবরাহ করা হয়েছে তার জন্য পর্যাপ্ত জায়গা সহ একটি এক্স 100 এক্স বরাদ্দ করে।
    ///
    /// এক্স01 এক্স ফাংশনটি ডেটা পয়েন্টার সহ কল করা হয় এবং অবশ্যই `ArcInner<T>` এর জন্য একটি (সম্ভাব্য ফ্যাট)-পয়েন্টারটি ফিরে আসতে হবে।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // প্রদত্ত মান বিন্যাস ব্যবহার করে বিন্যাস গণনা করুন।
        // পূর্বে, `&*(ptr as* const ArcInner<T>)` এক্সপ্রেশনটিতে বিন্যাস গণনা করা হত, তবে এটি একটি ভুল স্বাক্ষরিত রেফারেন্স তৈরি করেছে (দেখুন #54908)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// একটি এক্স-00 এক্সকে সম্ভাব্য-অচলিত অভ্যন্তরীণ মানের জন্য পর্যাপ্ত জায়গা সহ বরাদ্দ দেয় যেখানে মানটি লেআউটটি সরবরাহ করে, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফেরায়।
    ///
    ///
    /// এক্স01 এক্স ফাংশনটি ডেটা পয়েন্টার সহ কল করা হয় এবং অবশ্যই `ArcInner<T>` এর জন্য একটি (সম্ভাব্য ফ্যাট)-পয়েন্টারটি ফিরে আসতে হবে।
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // প্রদত্ত মান বিন্যাস ব্যবহার করে বিন্যাস গণনা করুন।
        // পূর্বে, `&*(ptr as* const ArcInner<T>)` এক্সপ্রেশনটিতে বিন্যাস গণনা করা হত, তবে এটি একটি ভুল স্বাক্ষরিত রেফারেন্স তৈরি করেছে (দেখুন #54908)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // আরকিআইনার শুরু করুন
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// একটি আনসাইজড অভ্যন্তরীণ মানের জন্য পর্যাপ্ত জায়গা সহ একটি `ArcInner<T>` বরাদ্দ করে।
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // প্রদত্ত মানটি ব্যবহার করে `ArcInner<T>` এর জন্য বরাদ্দ করুন।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // বাইট হিসাবে মান কপি করুন
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // বরাদ্দকরণের বিষয়বস্তু না ফেলেই বিনামূল্যে করুন
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// প্রদত্ত দৈর্ঘ্য সহ একটি `ArcInner<[T]>` বরাদ্দ করে।
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// স্লাইস থেকে উপাদানগুলিকে সদ্য বরাদ্দ করা আর্ক <T [টি\]> এ অনুলিপি করুন
    ///
    /// অনিরাপদ কারণ কলারকে অবশ্যই মালিকানা নিতে হবে বা `T: Copy` বাঁধতে হবে।
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// নির্দিষ্ট আকারের হিসাবে পরিচিত একটি পুনরাবৃত্তকারী থেকে একটি `Arc<[T]>` তৈরি করে।
    ///
    /// আকারটি ভুল হওয়া উচিত আচরণটি অপরিজ্ঞাত।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // টি উপাদানগুলির ক্লোনিং করার সময় Panic প্রহরী।
        // panic এর ইভেন্টে, নতুন আর্কআইনারে লিখিত থাকা উপাদানগুলি বাদ দেওয়া হবে, তারপরে স্মৃতি মুক্ত হবে।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // পয়েন্টার প্রথম উপাদান
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // সব পরিষ্কার.গার্ডকে ভুলে যান যাতে এটি নতুন আর্কইনারকে মুক্ত না করে।
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` এর জন্য বিশেষায়িতকরণ trait ব্যবহৃত।
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` পয়েন্টারের একটি ক্লোন তৈরি করে।
    ///
    /// শক্তিশালী রেফারেন্স গণনা বৃদ্ধি করে এটি একই বরাদ্দে আরেকটি পয়েন্টার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // একটি শিথিল অর্ডার ব্যবহার করা এখানে ঠিক আছে, কারণ মূল রেফারেন্সের জ্ঞানটি অন্য থ্রেডকে ভুলভাবে অবজেক্টটি মুছতে বাধা দেয়।
        //
        // [Boost documentation][1] তে বর্ণিত হিসাবে, রেফারেন্স কাউন্টারটি বাড়ানো সর্বদা স্মৃতি_র্ডার_ রিলাক্সড দিয়ে করা যায়: কোনও অবজেক্টের নতুন রেফারেন্স কেবল একটি বিদ্যমান রেফারেন্স থেকে তৈরি করা যেতে পারে এবং একটি থ্রেড থেকে অন্য থ্রেডে বিদ্যমান রেফারেন্সটি পাস করার জন্য ইতিমধ্যে প্রয়োজনীয় সিঙ্ক্রোনাইজেশন সরবরাহ করতে হবে।
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // তবে কেউ যদি `মেম: :::আর্কেসকে ভুলে যায় তবে আমাদের প্রচুর রিফ্যাক্টস থেকে রক্ষা করতে হবে।
        // আমরা যদি এটি না করি তবে গণনা উপচে পড়তে পারে এবং ব্যবহারকারীরা বিনামূল্যে ব্যবহার করতে পারবেন।
        // `isize::MAX` এক্স বিলিয়ন থ্রেডগুলি একবারে রেফারেন্স গণনা বৃদ্ধি করার অনুমিতিতে আমরা `isize::MAX` এর সাথে ধীরে ধীরে পরিপূর্ণ হয়েছি।
        //
        // এই branch কখনই কোনও বাস্তববাদী প্রোগ্রামে নেওয়া হবে না।
        //
        // আমরা গর্ভপাত করি কারণ এই জাতীয় প্রোগ্রাম অবিশ্বাস্যভাবে হ্রাসযুক্ত, এবং আমরা এটি সমর্থন করার কোন যত্ন নেই।
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// প্রদত্ত `Arc` এ একটি পরিবর্তনীয় রেফারেন্স তৈরি করে।
    ///
    /// যদি একই বরাদ্দে অন্য `Arc` বা [`Weak`] পয়েন্টার থাকে তবে এক্স02 এক্স একটি নতুন বরাদ্দ তৈরি করবে এবং অনন্য মালিকানা নিশ্চিত করার জন্য অভ্যন্তরীণ মানটিতে এক্স03 এক্সকে অনুরোধ করবে।
    /// এটিকে ক্লোন-অন-রাইটিং হিসাবেও উল্লেখ করা হয়।
    ///
    /// দ্রষ্টব্য যে এটি [`Rc::make_mut`] এর আচরণের থেকে পৃথক যা অন্য কোনও `Weak` পয়েন্টারকে বিচ্ছিন্ন করে।
    ///
    /// এছাড়াও [`get_mut`][get_mut] দেখুন, যা ক্লোনিংয়ের চেয়ে ব্যর্থ হবে।
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // কিছুই ক্লোন করবেন না
    /// let mut other_data = Arc::clone(&data); // অভ্যন্তরীণ ডেটা ক্লোন করবে না
    /// *Arc::make_mut(&mut data) += 1;         // ক্লোনসের অভ্যন্তরীণ ডেটা
    /// *Arc::make_mut(&mut data) += 1;         // কিছুই ক্লোন করবেন না
    /// *Arc::make_mut(&mut other_data) *= 2;   // কিছুই ক্লোন করবেন না
    ///
    /// // এখন `data` এবং `other_data` বিভিন্ন বরাদ্দে নির্দেশ করে।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // নোট করুন যে আমরা একটি শক্তিশালী রেফারেন্স এবং দুর্বল রেফারেন্স উভয়ই ধরে রেখেছি।
        // সুতরাং, কেবলমাত্র আমাদের দৃ reference় রেফারেন্স প্রকাশ করলে তা স্বতঃস্ফূর্তভাবে স্মৃতিটিকে হ্রাস পাবে না।
        //
        // এক্স-এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স এক্স প্রকাশিত হওয়ার আগে যে কোনও লিখন আমরা দেখতে পাই তা নিশ্চিত করার জন্য অ্যাকুইয়ার ব্যবহার করুন।
        // যেহেতু আমরা একটি দুর্বল গণনা রেখেছি, আর্কইনার নিজেই বিলোপ হওয়ার কোনও সম্ভাবনা নেই।
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // আর একটি শক্তিশালী পয়েন্টার বিদ্যমান, সুতরাং আমাদের অবশ্যই ক্লোন করতে হবে।
            // ক্লোন করা মানটি সরাসরি লেখার জন্য মেমরি প্রাক-বরাদ্দ।
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // উপরের অংশে শিথিল স্বাচ্ছন্দ্য কারণ এটি মূলত একটি অপ্টিমাইজেশন: আমরা সবসময় দুর্বল পয়েন্টারগুলি বাদ দিয়ে দৌড় করি।
            // সবচেয়ে খারাপ ক্ষেত্রে, আমরা অযথা একটি নতুন আরক বরাদ্দ করেছি।
            //

            // আমরা শেষ শক্তিশালী রেফটি সরিয়েছি, তবে অতিরিক্ত দুর্বল রেফ বাকী রয়েছে।
            // আমরা বিষয়বস্তুগুলিকে একটি নতুন আর্কে স্থানান্তর করব, এবং অন্যান্য দুর্বল রেফারগুলি অবৈধ করব।
            //

            // দ্রষ্টব্য যে `weak` পড়ার পক্ষে usize::MAX (অর্থাত লকড) পাওয়া সম্ভব নয়, কারণ দুর্বল গণনাটি কেবল শক্তিশালী রেফারেন্স সহ একটি থ্রেড দ্বারা লক করা যায়।
            //
            //

            // আমাদের নিজস্ব অন্তর্নিহিত দুর্বল পয়েন্টারকে বস্তুগতকরণ করুন, যাতে এটি প্রয়োজন মতো আর্কইনার পরিষ্কার করতে পারে।
            //
            let _weak = Weak { ptr: this.ptr };

            // কেবল ডেটা চুরি করতে পারে, যা বাকী রয়েছে তা হ'ল উইাকস
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // আমরা উভয় ধরনের একমাত্র রেফারেন্স ছিল;শক্তিশালী রেফ কাউন্ট ব্যাক আপ।
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` এর মতো, অনর্থক ঠিক আছে কারণ আমাদের উল্লেখটি শুরু করার সাথেই অনন্য ছিল, বা বিষয়বস্তু ক্লোনিংয়ের পরে এক হয়ে গেছে।
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// একই বরাদ্দে অন্য কোনও `Arc` বা [`Weak`] পয়েন্টার না থাকলে প্রদত্ত `Arc`-তে পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    ///
    /// অন্যথায় [`None`] প্রদান করে, কারণ ভাগ করা মানকে পরিবর্তন করা নিরাপদ নয়।
    ///
    /// এছাড়াও [`make_mut`][make_mut] দেখুন, যা অন্য পয়েন্টারগুলি উপস্থিত থাকলে অভ্যন্তরীণ মানটি [`clone`][clone] করবে।
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // এই অনর্থকটি ঠিক আছে কারণ আমাদের গ্যারান্টিযুক্ত যে পয়েন্টারটি ফিরে এসেছে কেবলমাত্র * পয়েন্টার যা টি-তে ফিরে আসবে is
            // আমাদের রেফারেন্স গণনাটি এই মুহুর্তে 1 হওয়ার গ্যারান্টিযুক্ত এবং আমরা খোদ খোদাই `mut` হওয়া দরকার, তাই আমরা অভ্যন্তরীণ তথ্যের একমাত্র সম্ভাব্য রেফারেন্সটি ফিরিয়ে দিচ্ছি।
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// কোনও চেক ছাড়াই প্রদত্ত `Arc` এর পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    /// এছাড়াও [`get_mut`] দেখুন, যা নিরাপদ এবং যথাযথ চেক করে।
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// একই বরাদ্দের জন্য অন্য কোনও `Arc` বা [`Weak`] পয়েন্টারগুলি অবশ্যই ফেরত bণের সময়কালের জন্য উপযুক্ত নয়।
    ///
    /// এটি তুচ্ছভাবে যদি কেস পয়েন্টার উপস্থিত না থাকে তবে উদাহরণস্বরূপ `Arc::new` এর পরে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // আমরা "count" ক্ষেত্রগুলি coveringেকে রেফারেন্স তৈরি করতে *না* দিতে সাবধান, কারণ এটি রেফারেন্স গণনায় একযোগে অ্যাক্সেস সহ উপনাম হবে (যেমন,
        // `Weak` দ্বারা)।
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// অন্তর্নিহিত ডেটাতে এটি অনন্য রেফারেন্স (দুর্বল রেফ সহ) কিনা তা নির্ধারণ করুন।
    ///
    ///
    /// নোট করুন যে এর জন্য দুর্বল রেফ গণনাটি লক করা দরকার।
    fn is_unique(&mut self) -> bool {
        // যদি আমরা একমাত্র দুর্বল পয়েন্টার ধারক হিসাবে উপস্থিত হই তবে দুর্বল পয়েন্টার গণনাটিকে লক করুন।
        //
        // এক্সকিউএক্স গণনা হ্রাসের আগে `strong` (বিশেষত `Weak::upgrade`-এ) কোনও লেখার সাথে সম্পর্কের আগে-এর সম্পর্কের বিষয়টি এখানে অর্জনের লেবেলটি নিশ্চিত করে (এক্স 100 এক্স, যা প্রকাশ ব্যবহার করে)।
        // যদি আপগ্রেড করা দুর্বল রেফটি কখনও বাদ না দেওয়া হয় তবে এখানকার সিএএস ব্যর্থ হবে তাই আমরা সিঙ্ক্রোনাইজ করার কোনও যত্ন নেই।
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop`-এ `strong` কাউন্টারটির হ্রাসের সাথে সিঙ্ক্রোনাইজ হওয়ার জন্য এটি একটি `Acquire` হওয়া দরকার-একমাত্র অ্যাক্সেস তখনই ঘটে যখন শেষ রেফারেন্সটি বাদ দেওয়া হয়।
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // এখানে প্রকাশের লিখনটি `downgrade` এ একটি রিডের সাথে সিঙ্ক্রোনাইজ করে, `strong` এর উপরের পড়াকে কার্যকরভাবে লেখার পরে ঘটতে বাধা দেয়।
            //
            //
            self.inner().weak.store(1, Release); // লকটি ছেড়ে দিন
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// এক্স 100 এক্স ড্রপ করে।
    ///
    /// এটি শক্তিশালী রেফারেন্স গণনা হ্রাস করবে।
    /// যদি শক্তিশালী রেফারেন্স গণনাটি শূন্যে পৌঁছে যায় তবে কেবলমাত্র অন্যান্য উল্লেখগুলি (যদি থাকে তবে) [`Weak`] হয়, সুতরাং আমরা অভ্যন্তরের মানটি `drop` করি।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // কিছু মুদ্রণ করে না
    /// drop(foo2);   // প্রিন্ট "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` ইতিমধ্যে পারমাণবিক, তাই আমরা অন্য থ্রেডের সাথে সিঙ্ক্রোনাইজ করার প্রয়োজন নেই যতক্ষণ না আমরা অবজেক্টটি মুছতে না চলে।
        // এই একই যুক্তিটি `weak` গণনায় নীচে `fetch_sub` এ প্রযোজ্য।
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // এই বেড়াটি ডেটা ব্যবহার এবং ডেটা মুছতে পুনরায় রোধ করতে প্রয়োজন।
        // এটি `Release` চিহ্নিত করা হয়েছে বলে, রেফারেন্স গণনাটি হ্রাস হওয়া এই `Acquire` বেড়ার সাথে সুসংগত করে।
        // এর অর্থ হ'ল তথ্য ব্যবহার রেফারেন্স গণনা হ্রাস করার আগে ঘটে যা এই বেড়ার আগে ঘটে যা তথ্য মোছার আগে ঘটে।
        //
        // [Boost documentation][1] এ বর্ণিত হিসাবে,
        //
        // > একটিতে অবজেক্টটিতে যে কোনও সম্ভাব্য অ্যাক্সেস প্রয়োগ করা জরুরী
        // > মুছে ফেলার আগে * ঘটতে থ্রেড (বিদ্যমান রেফারেন্সের মাধ্যমে)
        // > ভিন্ন থ্রেডে বস্তুএটি একটি এক্স 100 এক্স দ্বারা অর্জন করা হয়েছে
        // > একটি রেফারেন্স (বস্তুর কোনও অ্যাক্সেস) ফেলে দেওয়ার পরে ক্রিয়াকলাপ
        // > এই রেফারেন্সের মাধ্যমে অবশ্যই স্পষ্টত আগে ঘটেছিল) এবং এ
        // > "acquire" অবজেক্ট মুছে ফেলার আগে অপারেশন।
        //
        // বিশেষত, যখন একটি আর্কের বিষয়বস্তুগুলি সাধারণত অপরিবর্তনীয় হয় তবে কোনও অভ্যন্তরের কোনও শিরোনামের মতো লিখতে পারা যায়<T>।
        // যেহেতু মুটেক্স মুছে ফেলা হবে তা অর্জিত না হওয়ায় আমরা থ্রেড এ লেখার জন্য এর সুসংগত যুক্তির উপর নির্ভর করতে পারি না থ্রেড বিতে চলমান কোনও ধ্বংসকারীকে দৃশ্যমান A
        //
        //
        // আরও মনে রাখবেন যে এ্যাকায়ার বেড়াটি এখানে অ্যাকুইয়ার লোডের সাথে প্রতিস্থাপিত হতে পারে যা উচ্চ-বিতর্কিত পরিস্থিতিতে কর্মক্ষমতা উন্নত করতে পারে।এক্স 100 এক্স দেখুন।
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` কে কংক্রিটের ধরণে ডাউনকাস্ট করার চেষ্টা করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// কোনও মেমরি বরাদ্দ না করে একটি নতুন এক্স00 এক্স তৈরি করে।
    /// রিটার্ন ভ্যালুতে [`upgrade`] কল করা সর্বদা [`None`] দেয়।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ডেটা ক্ষেত্র সম্পর্কে কোনও মন্তব্য না করে রেফারেন্স গণনাগুলিতে অ্যাক্সেসের অনুমতি দেওয়ার জন্য সহায়ক প্রকার।
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// এই `Weak<T>` দ্বারা নির্দেশিত `T` অবজেক্টে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// কিছু শক্তিশালী উল্লেখ থাকলে কেবলমাত্র পয়েন্টারটি বৈধ।
    /// পয়েন্টারটি ঝোলা, স্বাক্ষরবিহীন বা অন্যথায় [`null`] হতে পারে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // উভয়ই একই বস্তুর দিকে ইঙ্গিত করে
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // শক্তিশালী এখানে এটিকে জীবিত রাখে, তাই আমরা এখনও অবজেক্টটি অ্যাক্সেস করতে পারি।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // কিন্তু আর না.
    /// // আমরা এক্স00 এক্স করতে পারি, তবে পয়েন্টারে অ্যাক্সেস করলে অপরিজ্ঞাত আচরণ হতে পারে।
    /// // assert_eq! ("হ্যালো", অনিরাপদ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // যদি পয়েন্টারটি ঝুঁকছে তবে আমরা সরাসরি সেন্ডিনেলটি ফিরিয়ে দেব।
            // এটি কোনও বৈধ পে-লোড ঠিকানা হতে পারে না, কারণ পে-লোড কমপক্ষে আর্কইনার এক্স00 এক্স হিসাবে সংযুক্ত থাকে।
            ptr as *const T
        } else {
            // নিরাপদ: যদি is_dangling মিথ্যা প্রত্যাবর্তন করে, তবে পয়েন্টারটি হ্রাসযোগ্য।
            // পেডলোডটি এই মুহুর্তে বাদ পড়তে পারে এবং আমাদের প্রবর্তন বজায় রাখতে হবে, তাই কাঁচা পয়েন্টার ম্যানিপুলেশন ব্যবহার করুন।
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// এক্স 100 এক্স গ্রহণ করে এবং এটি একটি কাঁচা পয়েন্টারে পরিণত করে।
    ///
    /// এটি দুর্বল পয়েন্টারটিকে একটি কাঁচা পয়েন্টারে রূপান্তরিত করে, যখন এখনও একটি দুর্বল রেফারেন্সের মালিকানা সংরক্ষণ করে (দুর্বল গণনাটি এই অপারেশন দ্বারা সংশোধিত হয় না)।
    /// এটি [`from_raw`] এর সাহায্যে `Weak<T>` এ ফিরে যেতে পারে।
    ///
    /// [`as_ptr`] এর মতো পয়েন্টারের লক্ষ্য অ্যাক্সেসের একই নিষেধাজ্ঞাগুলি প্রযোজ্য।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] দ্বারা পূর্বে তৈরি করা একটি কাঁচা পয়েন্টারকে `Weak<T>` এ আবার রূপান্তর করে।
    ///
    /// এটি নিরাপদে একটি শক্তিশালী রেফারেন্স পেতে (পরে [`upgrade`] কল করে) বা `Weak<T>` ফেলে দিয়ে দুর্বল গণনাটি ডিলেক্ট করতে ব্যবহার করা যেতে পারে।
    ///
    /// এটি একটি দুর্বল রেফারেন্সের মালিকানা নেয় ([`new`] দ্বারা নির্মিত পয়েন্টারগুলি ব্যতীত, কারণ এগুলির কোনও মালিকানা নেই; পদ্ধতিটি এখনও তাদের উপর কাজ করে)।
    ///
    /// # Safety
    ///
    /// পয়েন্টারটি অবশ্যই [`into_raw`] থেকে উদ্ভূত হয়েছে এবং এখনও এর সম্ভাব্য দুর্বল রেফারেন্সের মালিক হওয়া উচিত।
    ///
    /// এটি কল করার সময় শক্তিশালী গণনা 0 এর জন্য অনুমোদিত।
    /// তবুও, এটি বর্তমানে কাঁচা পয়েন্টার হিসাবে উপস্থাপিত একটি দুর্বল রেফারেন্সের মালিকানা গ্রহণ করে (দুর্বল গণনাটি এই ক্রিয়াকলাপের মাধ্যমে সংশোধিত হয় না) এবং তাই এটি অবশ্যই [`into_raw`] এ পূর্ববর্তী কল দিয়ে যুক্ত করা উচিত।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // শেষ দুর্বল গণনা হ্রাস।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ইনপুট পয়েন্টার কীভাবে উত্পন্ন হয় তা প্রসঙ্গে Weak::as_ptr দেখুন।

        let ptr = if is_dangling(ptr as *mut T) {
            // এটি একটি জটলা দুর্বল।
            ptr as *mut ArcInner<T>
        } else {
            // অন্যথায়, আমরা নিশ্চিত যে পয়েন্টারটি কোনও দুর্বল দুর্বল থেকে এসেছে।
            // নিরাপদ: ডেটা_অফসেট কল করা নিরাপদ, কারণ পিটিআরটি একটি আসল (সম্ভাব্য বাদ দেওয়া) টির উল্লেখ করে।
            let offset = unsafe { data_offset(ptr) };
            // সুতরাং, আমরা পুরো আরসিবক্স পেতে অফসেটটি বিপরীত করি।
            // সুরক্ষা: পয়েন্টারটি দুর্বল থেকে উদ্ভূত, তাই এই অফসেটটি নিরাপদ।
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // সুরক্ষা: আমরা এখন আসল দুর্বল পয়েন্টারটি পুনরুদ্ধার করেছি, সুতরাং দুর্বল তৈরি করতে পারি।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` পয়েন্টারটিকে একটি [`Arc`] এ আপগ্রেড করার চেষ্টা, যদি সফল হয় তবে অভ্যন্তরীণ মান হ্রাস পেতে বিলম্ব হয়।
    ///
    ///
    /// যদি অভ্যন্তরীণ মানটি তখন থেকে বাদ দেওয়া হয় তবে [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // সমস্ত শক্তিশালী পয়েন্টার ধ্বংস করুন।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // আমরা একটি fetch_add এর পরিবর্তে শক্তিশালী কাউন্ট বাড়ানোর জন্য একটি সিএএস লুপ ব্যবহার করি কারণ এই ফাংশনটি কখনই শূন্য থেকে একের মধ্যে রেফারেন্স গণনা করা উচিত নয়।
        //
        //
        let inner = self.inner()?;

        // স্বাচ্ছন্দ্য লোড কারণ 0 এর যে কোনও লিখন যা আমরা পর্যবেক্ষণ করতে পারি স্থায়ীভাবে শূন্য অবস্থায় মাঠ ছেড়ে যায় (সুতরাং 0 এর একটি এক্স 100 এক্স ভাল আছে), এবং অন্য কোনও মান নীচের সিএএসের মাধ্যমে নিশ্চিত করা হয়েছে।
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // কেন আমরা এটি করি (এক্স01 এক্স এর জন্য) এক্স 100 এক্স-এ মন্তব্য দেখুন।
            if n > MAX_REFCOUNT {
                abort();
            }

            // স্বাচ্ছন্দ্য ব্যর্থতার ক্ষেত্রে ঠিক আছে কারণ নতুন রাষ্ট্র সম্পর্কে আমাদের কোনও প্রত্যাশা নেই।
            // সাফল্যের ক্ষেত্রে `Arc::new_cyclic` এর সাথে সিঙ্ক্রোনাইজ করার জন্য অধিগ্রহণ প্রয়োজনীয়, যখন `Weak` রেফারেন্সগুলি ইতিমধ্যে তৈরি হওয়ার পরে অভ্যন্তরীণ মানটি আরম্ভ করা যেতে পারে।
            // সেক্ষেত্রে আমরা সম্পূর্ণরূপে আরম্ভকৃত মানটি পর্যবেক্ষণ করতে আশা করি।
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // নাল উপরে চেক
                Err(old) => n = old,
            }
        }
    }

    /// এই বরাদ্দকে নির্দেশ করে শক্তিশালী (`Arc`) পয়েন্টার সংখ্যা পায়।
    ///
    /// যদি [`Weak::new`] এক্সটি [`Weak::new`] ব্যবহার করে তৈরি করা হয়েছিল, তবে এটি 0 এ ফিরে আসবে।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// এই বরাদ্দকে নির্দেশ করে `Weak` পয়েন্টার সংখ্যার একটি প্রায় অনুমান করে।
    ///
    /// যদি [`Weak::new`] এক্সটি [`Weak::new`] ব্যবহার করে তৈরি করা হয়েছিল, বা যদি কোনও শক্তিশালী পয়েন্টার না থাকে তবে এটি 0 ফিরে আসবে।
    ///
    /// # Accuracy
    ///
    /// বাস্তবায়নের বিশদগুলির কারণে, অন্য থ্রেডগুলি একই বরাদ্দকে নির্দেশ করে যে কোনও `আর্কিস বা` দুর্বলগুলি পরিচালনা করছে তখন প্রত্যাশিত মান উভয় দিকেই 1 দিয়ে বন্ধ হয়ে যেতে পারে।
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // যেহেতু আমরা লক্ষ্য করেছি যে দুর্বল গণনাটি পড়ার পরে কমপক্ষে একটি শক্ত পয়েন্টার ছিল, তাই আমরা জানি যে দুর্বল গণনাটি পর্যবেক্ষণ করার সময় অন্তর্নিহিত দুর্বল রেফারেন্স (উপস্থিত যখনই কোনও শক্তিশালী রেফারেন্স জীবিত থাকে) তখনও ছিল এবং তাই নিরাপদে এটি বিয়োগ করতে পারে।
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// পয়েন্টারটি যখন ঝুঁকছে তখন `None` প্রদান করে এবং কোনও বরাদ্দকৃত `ArcInner` নেই (যেমন, যখন এই `Weak` এক্স03 এক্স দ্বারা নির্মিত হয়েছিল)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // আমরা "data" ফিল্ডটি কভার করে * কোনও রেফারেন্স তৈরি না করার বিষয়ে সতর্ক রয়েছি, কারণ ক্ষেত্রটি একই সাথে পরিবর্তিত হতে পারে (উদাহরণস্বরূপ, শেষ `Arc` বাদ দিলে ডেটা ক্ষেত্রটি জায়গায় রেখে দেওয়া হবে)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// যদি দু'টি দুর্বল একই বরাদ্দ ([`ptr::eq`] এর সমান) দিকে নির্দেশ করে, বা উভয় কোনও বরাদ্দকে নির্দেশ না করে তবে `true` প্রদান করে (কারণ এগুলি `Weak::new()`) দিয়ে তৈরি হয়েছিল।
    ///
    ///
    /// # Notes
    ///
    /// যেহেতু এটি পয়েন্টারগুলির সাথে তুলনা করে তার অর্থ এটি যে `Weak::new()` একে অপরের সাথে সমান হবে, যদিও তারা কোনও বরাদ্দকে নির্দেশ করে না।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// এক্স00 এক্স এর তুলনা করা হচ্ছে।
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` পয়েন্টারের একটি ক্লোন তৈরি করে যা একই বরাদ্দকে নির্দেশ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // কেন এই রিল্যাক্স হয় তার জন্য এক্স00 এক্স-এ মন্তব্য দেখুন।
        // এটি একটি fetch_add (লক উপেক্ষা করে) ব্যবহার করতে পারে কারণ দুর্বল গণনাটি কেবল সেখানে লক থাকে যেখানে *অন্য কোনও* দুর্বল পয়েন্টার থাকে না।
        //
        // (সুতরাং আমরা এই ক্ষেত্রে এই কোডটি চলতে পারি না)।
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // আমরা কেন এটি করি (এক্স01 এক্স এর জন্য) এক্স 100 এক্স-এ মন্তব্য দেখুন।
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// মেমরি বরাদ্দ না করে একটি নতুন এক্স00 এক্স গঠন করে।
    /// রিটার্ন ভ্যালুতে [`upgrade`] কল করা সর্বদা [`None`] দেয়।
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// এক্স 100 এক্স পয়েন্টার বাদ দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // কিছু মুদ্রণ করে না
    /// drop(foo);        // প্রিন্ট "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // যদি আমরা জানতে পারি যে আমরা সর্বশেষ দুর্বল পয়েন্টার ছিলাম, তবে ডেটা পুরোপুরি হ্রাস করার সময়।মেমরি ক্রমগুলি সম্পর্কে Arc::drop() এ আলোচনা দেখুন
        //
        // এখানে তালাবদ্ধ অবস্থার জন্য যাচাই করা দরকার নেই, কারণ দুর্বল গণনাটি কেবল তখনই তালাবদ্ধ হতে পারে যদি সেখানে কোনও দুর্বল রেফ থাকে, যার অর্থ হ'ল ড্রপটি পরবর্তীকালে অবশিষ্ট অবশিষ্ট দুর্বল রেফের উপর চালানো যেতে পারে, যা কেবল লকটি প্রকাশের পরে ঘটতে পারে।
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// আমরা এই বিশেষীকরণটি এখানে করছি, এবং `&T` এ আরও সাধারণ অপ্টিমাইজেশন হিসাবে নয়, কারণ এটি অন্যথায় রেফগুলিতে সমস্ত সমতা চেকগুলিতে ব্যয় যোগ করবে।
/// আমরা ধরে নিই যে `আর্কসগুলি বড় মানগুলি সঞ্চয় করতে ব্যবহৃত হয়, এটি ক্লোন করতে ধীর হয় তবে সমতা পরীক্ষা করতেও ভারী হয়, যার ফলে এই ব্যয়টি আরও সহজেই পরিশোধ করা যায়।
///
/// এটিতে দুটি 00&T`s এর চেয়েও দুটি এক্স00 এক্স ক্লোন হওয়ার সম্ভাবনা বেশি that
///
/// আমরা কেবল তখনই এটি করতে পারি যখন `T: Eq` `PartialEq` হিসাবে ইচ্ছাকৃত অপ্রয়োজনীয় হতে পারে।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// দুটি `আরাকের জন্য সমতা।
    ///
    /// তাদের অভ্যন্তরীণ মান সমান হলে দুটি `আর্কস সমান, এমনকি যদি তারা বিভিন্ন বরাদ্দে সঞ্চিত থাকে।
    ///
    /// যদি `T` এছাড়াও `Eq` (সমতার আবদ্ধ প্রতিচ্ছবি) প্রয়োগ করে তবে দুটি বরকটি একই বরাদ্দকে নির্দেশ করে সর্বদা সমান।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// দুটি `আর্কেসের জন্য বৈষম্য।
    ///
    /// দুটি `আর্কে অসম হয় যদি তাদের অভ্যন্তরীণ মানগুলি অসম হয়।
    ///
    /// যদি `T` এছাড়াও `Eq` (সমতার আবদ্ধ প্রতিচ্ছবি) প্রয়োগ করে, একই মানের দিকে নির্দেশিত দুটি `আর্কস কখনও অসম নয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// দুটি `আর্কের জন্য আংশিক তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `partial_cmp()` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// দুটি `আর্কের তুলনায় কম।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `<` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// দুটি `আর্কের জন্য তুলনা 'এর চেয়ে কম বা সমান'।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `<=` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// বৃহত্তর-তুলনায় দুটি `আর্কের জন্য।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `>` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'বৃহত্তর চেয়ে সমান বা সমান' দুটি `আর্কের জন্য তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `>=` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// দুটি `আরাকের জন্য তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `cmp()` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` এর জন্য `Default` মান সহ একটি নতুন এক্স01 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// একটি রেফারেন্স-গণনা করা স্লাইস বরাদ্দ করুন এবং `v` এর আইটেমগুলি ক্লোন করে এটি পূরণ করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// একটি রেফারেন্স-গণনা করা `str` বরাদ্দ করুন এবং এতে `v` অনুলিপি করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// একটি রেফারেন্স-গণনা করা `str` বরাদ্দ করুন এবং এতে `v` অনুলিপি করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// একটি বাক্সযুক্ত বস্তুকে নতুন, রেফারেন্স-গণনা বরাদ্দে সরান।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// একটি রেফারেন্স-গণনা করা স্লাইস বরাদ্দ করুন এবং এর মধ্যে আইটেমগুলি সরান move
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // ভিসিকে এর স্মৃতি মুক্ত করার অনুমতি দিন, তবে এর সামগ্রীগুলি ধ্বংস করবেন না
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` এ প্রতিটি উপাদান নেয় এবং এটি একটি `Arc<[T]>` এ সংগ্রহ করে।
    ///
    /// # কর্মক্ষমতা বৈশিষ্ট্য
    ///
    /// ## সাধারণ ক্ষেত্রে
    ///
    /// সাধারণ ক্ষেত্রে, `Arc<[T]>` এ সংগ্রহ করা প্রথমে একটি `Vec<T>` এ সংগ্রহের মাধ্যমে করা হয়।এটি হ'ল নিম্নলিখিতটি লেখার সময়:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// এটি এমনভাবে আচরণ করে যেন আমরা লিখেছি:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // বরাদ্দের প্রথম সেটটি এখানে ঘটে।
    ///     .into(); // `Arc<[T]>` এর জন্য একটি দ্বিতীয় বরাদ্দ এখানে ঘটে।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// এটি `Vec<T>` নির্মানের জন্য যতবার প্রয়োজন ততবার বরাদ্দ করবে এবং তারপরে এটি `Vec<T>` কে `Arc<[T]>` এ রূপান্তর করার জন্য একবার বরাদ্দ করবে।
    ///
    ///
    /// ## পরিচিত দৈর্ঘ্যের Iteilers
    ///
    /// যখন আপনার `Iterator` `TrustedLen` প্রয়োগ করে এবং সঠিক আকারের হয়, তখন `Arc<[T]>` এর জন্য একটি একক বরাদ্দ দেওয়া হবে।উদাহরণ স্বরূপ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // এখানে একটি মাত্র বরাদ্দ ঘটে।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` এ সংগ্রহের জন্য বিশেষায়িতকরণ trait ব্যবহৃত।
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // এটি একটি `TrustedLen` পুনরাবৃত্তির ক্ষেত্রে।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // নিরাপত্তা: আমাদের নিশ্চিত করতে হবে যে পুনরাবৃত্তির সঠিক দৈর্ঘ্য রয়েছে এবং আমাদের রয়েছে।
                Arc::from_iter_exact(self, low)
            }
        } else {
            // স্বাভাবিক প্রয়োগে ফিরে যান।
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// পয়েন্টারের পিছনে পেওডের জন্য একটি এক্স00 এক্স এর মধ্যে অফসেট পান।
///
/// # Safety
///
/// পয়েন্টারটি অবশ্যই টি এর পূর্বের বৈধ উদাহরণের সাথে (এবং এর জন্য বৈধ মেটাডেটা থাকতে হবে) নির্দেশ করতে হবে, তবে টি বাদ দেওয়ার অনুমতি দেওয়া হয়েছে।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // অর্কআইনারের শেষে অব্যবহৃত মানটিকে সারিবদ্ধ করুন।
    // আরসিবক্স repr(C) হওয়ায় এটি সর্বদা স্মৃতিতে সর্বশেষ ক্ষেত্র হবে।
    // নিরাপত্তা: যেহেতু কেবলমাত্র অচলিত ধরণের প্রকারগুলি হ'ল স্লাইস, জেড 0 ট্রাইট0 জেড অবজেক্ট,
    // এবং বাহ্যিক ধরণের, ইনপুট সুরক্ষা প্রয়োজনীয়তা বর্তমানে align_of_val_raw এর প্রয়োজনীয়তাগুলি পূরণ করার জন্য যথেষ্ট;এটি ভাষাটির একটি বাস্তবায়নের বিশদ যা std এর বাইরে নির্ভর করা যায় না।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}