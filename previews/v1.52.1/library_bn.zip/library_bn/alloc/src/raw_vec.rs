#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// নতুন মেমরির বিষয়বস্তু অবিচ্ছিন্ন করা হয়েছে।
    Uninitialized,
    /// নতুন মেমরিটি শূন্যের গ্যারান্টিযুক্ত।
    Zeroed,
}

/// জড়িত সমস্ত কোণার কেস সম্পর্কে উদ্বিগ্ন না হয়ে আরও বেশি আর্গোনিকভাবে বরাদ্দকরণ, পুনর্নির্মাণ এবং মেমরির একটি বাফারকে কমিয়ে দেওয়ার জন্য একটি নিম্ন-স্তরের ইউটিলিটি।
///
/// ভেক এবং ভেকডেকের মতো আপনার নিজস্ব ডেটা স্ট্রাকচার তৈরি করার জন্য এই ধরণেরটি দুর্দান্ত।
/// নির্দিষ্টভাবে:
///
/// * শূন্য আকারের ধরণের ক্ষেত্রে `Unique::dangling()` উত্পাদন করে।
/// * শূন্য দৈর্ঘ্যের বরাদ্দে `Unique::dangling()` উত্পাদন করে।
/// * এক্স00 এক্স মুক্ত করা এড়ানো হয়।
/// * ক্ষমতা গণনাগুলিতে সমস্ত ওভারফ্লোগুলি ক্যাচ করে (এগুলিকে "capacity overflow" panics এ প্রচার করে)।
/// * এক্স-00 এক্স বাইটের বেশি বরাদ্দ 32-বিট সিস্টেমের বিরুদ্ধে রক্ষীরা।
/// * আপনার দৈর্ঘ্য উপচে পড়া বিরুদ্ধে গার্ডস।
/// * পতনযোগ্য বরাদ্দের জন্য কল করুন `handle_alloc_error`।
/// * একটি এক্স 100 এক্স রয়েছে এবং এভাবে ব্যবহারকারীকে সম্পর্কিত সমস্ত সুবিধা দিয়ে থাকে।
/// * বৃহত্তম উপলব্ধ সক্ষমতা ব্যবহার করতে বরাদ্দকারীর কাছ থেকে ফিরে আসা অতিরিক্ত ব্যবহার করে।
///
/// এই ধরণটি যেভাবে মেমরি পরিচালনা করে তা পরীক্ষা করে না।যখন এটি ফেলে দেওয়া হবে *এটির মেমরি মুক্ত করবে* তবে এটি এর সামগ্রীগুলি ফেলে দেওয়ার চেষ্টা করবে না *।
/// এটি `RawVec` এক্স এর ব্যবহারকারীর উপর নির্ভর করে যে কোনও `RawVec` এর ভিতরে *সঞ্চিত* প্রকৃত জিনিসগুলি পরিচালনা করে।
///
/// মনে রাখবেন যে শূন্য আকারের ধরণের অতিরিক্ত পরিমাণ সর্বদা অসীম, তাই X01 এক্স সর্বদা `usize::MAX` প্রদান করে।
/// এর অর্থ হ'ল `Box<[T]>` এক্স এর দৈর্ঘ্য দেয় না বলে আপনার `capacity()` X এর সাথে বৃত্তাকারে ট্রিপ করার সময় সতর্ক হওয়া দরকার।
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): এটি বিদ্যমান কারণ `#[unstable]` `Const fn`s এর `min_const_fn` এর সাথে সামঞ্জস্য করা দরকার না এবং তাই সেগুলিকে`min_const_fn`s এও বলা যায় না।
    ///
    /// আপনি যদি `RawVec<T>::new` বা নির্ভরতা পরিবর্তন করেন তবে দয়া করে `min_const_fn` কে সত্যই লঙ্ঘন করবে এমন কোনও কিছু না করার জন্য দয়া করে যত্ন নিন।
    ///
    /// NOTE: আমরা এই হ্যাকটি এড়াতে এবং `min_const_fn` এর সাথে কিছু সংশ্লেষের প্রয়োজন এমন কিছু `#[rustc_force_min_const_fn]` অ্যাট্রিবিউটের সাথে সংযোগ পরীক্ষা করতে পারি তবে `#[rustc_const_unstable(feature = "foo", issue = "01234")]` উপস্থিত থাকলে `stable(...) const fn`/ব্যবহারকারী কোডটিতে `foo` সক্ষম না করে অগত্যা এটি কল করার অনুমতি দেয় না।
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// বরাদ্দ ছাড়াই সবচেয়ে বড় সম্ভাব্য `RawVec` (সিস্টেমের হিপে) তৈরি করে।
    /// যদি `T` এর ইতিবাচক আকার থাকে, তবে এটি `0` ক্ষমতা সহ একটি `RawVec` করে।
    /// যদি `T` শূন্য আকারের হয়, তবে এটি `usize::MAX` ক্ষমতা সহ একটি `RawVec` করে।
    /// বিলম্ব বরাদ্দ বাস্তবায়নের জন্য দরকারী।
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` এর জন্য ঠিক ক্ষমতা এবং প্রান্তিককরণের প্রয়োজনীয়তা সহ একটি এক্স01 এক্স (সিস্টেমের হিপে) তৈরি করে।
    /// এটি `RawVec::new` কল করার সমতুল্য যখন `capacity` হয় `0` বা `T` শূন্য আকারের হয়।
    /// মনে রাখবেন যে `T` যদি শূন্য আকারের হয় তবে এর অর্থ আপনি অনুরোধ ক্ষমতা সহ একটি এক্স01 এক্স পাবেন না *।
    ///
    /// # Panics
    ///
    /// Panics যদি অনুরোধ করা ক্ষমতাটি `isize::MAX` বাইটের বেশি হয়।
    ///
    /// # Aborts
    ///
    /// ওম-এ অবসান।
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// এক্স00 এক্স এর মতো তবে গ্যারান্টি দেয় বাফারটি শূন্য হয়েছে।
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// একটি পয়েন্টার এবং ক্ষমতা থেকে একটি `RawVec` পুনর্গঠন করে।
    ///
    /// # Safety
    ///
    /// `ptr` অবশ্যই বরাদ্দ করা উচিত (সিস্টেমের গাদা) এবং প্রদত্ত `capacity` এর সাথে।
    /// `capacity` আকারের ধরণের জন্য `isize::MAX` ছাড়িয়ে যেতে পারে না।(শুধুমাত্র 32-বিট সিস্টেমে উদ্বেগ)।
    /// ZST vectors এর ক্ষমতা `usize::MAX` অবধি হতে পারে।
    /// যদি `ptr` এবং `capacity` যদি কোনও `RawVec` থেকে আসে তবে এটির গ্যারান্টিযুক্ত।
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ক্ষুদ্র ভেকগুলি বোবা।এড়িয়ে যান:
    // - 8 যদি উপাদানটির আকার 1 হয়, কারণ যে কোনও হিপ বরাদ্দকারীরা 8 বাইটের চেয়ে কম কমপক্ষে 8 বাইটের অনুরোধটি সংগ্রহ করতে পারেন।
    //
    // - 4 যদি উপাদানগুলি মাঝারি আকারের হয় (<=1 কিবি)।
    // - 1 অন্যথায় খুব সংক্ষিপ্ত ভিজের জন্য খুব বেশি জায়গা নষ্ট করা এড়াতে।
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` এর মতো, তবে ফিরে আসা `RawVec` এর জন্য বরাদ্দকারীর পছন্দকে কেন্দ্র করে প্যারামিটারাইজড।
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" X এর অর্থ।শূন্য আকারের প্রকারগুলি উপেক্ষা করা হয়।
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` এর মতো, তবে ফিরে আসা `RawVec` এর জন্য বরাদ্দকারীর পছন্দকে কেন্দ্র করে প্যারামিটারাইজড।
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` এর মতো, তবে ফিরে আসা `RawVec` এর জন্য বরাদ্দকারীর পছন্দকে কেন্দ্র করে প্যারামিটারাইজড।
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` কে `RawVec<T>` এ রূপান্তর করে।
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// পুরো বাফারকে নির্দিষ্ট করা `len` দিয়ে `Box<[MaybeUninit<T>]>` এ রূপান্তর করে।
    ///
    /// দ্রষ্টব্য যে এটি সম্পাদিত হয়েছে এমন কোনও `cap` পরিবর্তনগুলি সঠিকভাবে পুনঃস্থাপন করবে।(বিশদ জন্য প্রকারের বিবরণ দেখুন।)
    ///
    /// # Safety
    ///
    /// * `len` অতি সম্প্রতি অনুরোধ করা সক্ষমতার চেয়ে বড় বা সমান হতে হবে এবং equal
    /// * `len` `self.capacity()` এর চেয়ে কম বা সমান হতে হবে।
    ///
    /// দ্রষ্টব্য, যে অনুরোধকৃত ক্ষমতা এবং `self.capacity()` আলাদা হতে পারে, কারণ একজন বরাদ্দকারী সামগ্রিকভাবে আবেদন করতে পারে এবং অনুরোধের চেয়ে আরও বড় মেমরি ব্লকটি ফিরিয়ে দিতে পারে।
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // নিরাপত্তার প্রয়োজনীয়তার অর্ধেক পরিমাণ পরীক্ষা করুন (আমরা অন্য অর্ধেকটি পরীক্ষা করতে পারি না)।
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // আমরা এখানে `unwrap_or_else` এড়াতে পারি কারণ এটি উত্পাদিত এলএলভিএম আইআরের পরিমাণকে স্ফীত করে।
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// পয়েন্টার, ক্ষমতা এবং বরাদ্দকারী থেকে একটি `RawVec` পুনর্গঠন করে।
    ///
    /// # Safety
    ///
    /// `ptr` অবশ্যই বরাদ্দ করা উচিত (প্রদত্ত বরাদ্দকারী এক্স02 এক্সের মাধ্যমে) এবং প্রদত্ত `capacity` এর সাথে।
    /// `capacity` আকারের ধরণের জন্য `isize::MAX` ছাড়িয়ে যেতে পারে না।
    /// (শুধুমাত্র 32-বিট সিস্টেমে উদ্বেগ)।
    /// ZST vectors এর ক্ষমতা `usize::MAX` অবধি হতে পারে।
    /// যদি `ptr` এবং `capacity` `alloc` এর মাধ্যমে তৈরি করা একটি `RawVec` থেকে আসে তবে এটির গ্যারান্টিযুক্ত।
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// বরাদ্দ শুরুর একটি কাঁচা পয়েন্টার পায়।
    /// দ্রষ্টব্য যে এটি `Unique::dangling()` যদি `capacity == 0` বা `T` শূন্য আকারের হয়।
    /// পূর্ববর্তী ক্ষেত্রে, আপনাকে অবশ্যই যত্নবান হতে হবে।
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// বরাদ্দ সক্ষমতা পায়।
    ///
    /// `T` শূন্য আকারের হলে এটি সর্বদা `usize::MAX` হবে।
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// এই `RawVec` সমর্থন করে বরাদ্দকারীকে একটি ভাগ করা রেফারেন্স প্রদান করে।
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // আমাদের মেমরির একটি বরাদ্দ অংশ রয়েছে, তাই আমরা আমাদের বর্তমান লেআউটটি পেতে রানটাইম চেকগুলি বাইপাস করতে পারি।
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// নিশ্চিত করে যে বাফারটিতে কমপক্ষে `len + additional` উপাদান রাখতে পর্যাপ্ত জায়গা রয়েছে।
    /// যদি এর মধ্যে ইতিমধ্যে পর্যাপ্ত ক্ষমতা না থাকে তবে এমওরাইটাইজড *ও*(1) আচরণ পেতে পর্যাপ্ত জায়গা এবং আরামদায়ক স্ল্যাক স্পেস পুনরায় স্থাপন করবে।
    ///
    /// যদি অযথা নিজেরাই panic এর কারণ হয়ে থাকে তবে এই আচরণটি সীমাবদ্ধ করবে।
    ///
    /// যদি `len` `self.capacity()` ছাড়িয়ে যায় তবে এটি অনুরোধ করা স্থানটি বরাদ্দ করতে ব্যর্থ হতে পারে।
    /// এটি সত্যই অনিরাপদ নয়, তবে আপনি লিখেছেন এমন অনিরাপদ কোডটি যা এই ফাংশনের আচরণের উপর নির্ভর করে তা ভঙ্গ হতে পারে।
    ///
    /// এটি `extend` এর মতো একটি বাল্ক-পুশ অপারেশন বাস্তবায়নের জন্য আদর্শ।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতাটি `isize::MAX` বাইটের বেশি হয়।
    ///
    /// # Aborts
    ///
    /// ওম-এ অবসান।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // লেনটি `isize::MAX` ছাড়িয়ে গেলে রিজার্ভটি বাতিল বা আতঙ্কিত হয়ে থাকতে পারে তাই এখনই এটি পরীক্ষা না করা নিরাপদ।
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` এর সমান, তবে আতঙ্কিত বা বিসর্জন দেওয়ার পরিবর্তে ত্রুটিগুলিতে ফিরে আসে।
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// নিশ্চিত করে যে বাফারটিতে কমপক্ষে `len + additional` উপাদান রাখতে পর্যাপ্ত জায়গা রয়েছে।
    /// যদি এটি ইতিমধ্যে না হয় তবে প্রয়োজনীয় ন্যূনতম পরিমাণে প্রয়োজনীয় মেমোরিটি পুনরায় স্থাপন করবে।
    /// সাধারণত এটি হ'ল প্রয়োজনীয় মেমরির পরিমাণ, তবে নীতিগতভাবে বরাদ্দকারী আমাদের চেয়ে যে পরিমাণ বেশি চেয়েছিলেন তা দিতে মুক্ত।
    ///
    ///
    /// যদি `len` `self.capacity()` ছাড়িয়ে যায় তবে এটি অনুরোধ করা স্থানটি বরাদ্দ করতে ব্যর্থ হতে পারে।
    /// এটি সত্যই অনিরাপদ নয়, তবে আপনি লিখেছেন এমন অনিরাপদ কোডটি যা এই ফাংশনের আচরণের উপর নির্ভর করে তা ভঙ্গ হতে পারে।
    ///
    /// # Panics
    ///
    /// Panics যদি নতুন ক্ষমতাটি `isize::MAX` বাইটের বেশি হয়।
    ///
    /// # Aborts
    ///
    /// ওম-এ অবসান।
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` এর সমান, তবে আতঙ্কিত বা বিসর্জন দেওয়ার পরিবর্তে ত্রুটিগুলিতে ফিরে আসে।
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// নির্দিষ্ট পরিমাণে বরাদ্দকে সঙ্কুচিত করে।
    /// প্রদত্ত পরিমাণটি যদি 0 হয় তবে প্রকৃতপক্ষে সম্পূর্ণরূপে deallocates।
    ///
    /// # Panics
    ///
    /// প্রদত্ত পরিমাণটি বর্তমান ক্ষমতার চেয়ে *বড়* হলে Panics।
    ///
    /// # Aborts
    ///
    /// ওম-এ অবসান।
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// প্রয়োজনীয় অতিরিক্ত ক্ষমতা পূরণের জন্য বাফার বাড়ার প্রয়োজন হলে ফিরে আসে।
    /// `grow` ইনলাইন না করে মূলত ইনলাইনিং রিজার্ভ-কলগুলি করতে প্রধানত ব্যবহৃত হয়।
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // এই পদ্ধতিটি সাধারণত বহুবার তাত্পর্যপূর্ণ হয়।তাই আমরা কমাইলগুলি সংশোধন করার জন্য এটি যতটা সম্ভব ছোট হতে চাই।
    // তবে আমরা তৈরির কোডটি দ্রুত চালিত করার জন্য এর সামগ্রীর অনেকগুলি স্ট্যাটিক্যালি গণনাযোগ্য হওয়াও চাই।
    // সুতরাং, এই পদ্ধতিটি সাবধানতার সাথে লেখা হয়েছে যাতে `T` এর উপর নির্ভরশীল সমস্ত কোডই এর মধ্যে থাকে, তবে `T` এর উপর নির্ভর করে না এমন কোডের বেশিরভাগই `T` এর চেয়ে বেশি জেনেরিক ফাংশনে রয়েছে।
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // এটি কলিং প্রসঙ্গে নিশ্চিত করা হয়েছে।
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // যেহেতু আমরা `elem_size` থাকে তখন আমরা `usize::MAX` এর সক্ষমতা ফিরিয়ে আনি
            // 0, এখানে পৌঁছানো অগত্যা `RawVec` ওভারফুল হয়েছে এর অর্থ।
            return Err(CapacityOverflow);
        }

        // দুঃখের বিষয় এই চেকগুলি সম্পর্কে আমরা আসলে কিছুই করতে পারি না।
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // এটি তাত্পর্যপূর্ণ বৃদ্ধির গ্যারান্টি দেয়।
        // ডাবলিং ওভারফ্লো করতে পারে না কারণ `cap <= isize::MAX` এবং `cap` এর ধরণটি `usize`।
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` এর চেয়ে বেশি জেনেরিক।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // এই পদ্ধতির সীমাবদ্ধতাগুলি `grow_amortized` এর মতো অনেকগুলি একই, তবে এই পদ্ধতিটি প্রায়শই প্রায়শই ইনস্ট্যান্ট করা হয় তাই এটি কম সমালোচনামূলক।
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // যেহেতু আমরা প্রকারের আকারের হয় তখন আমরা `usize::MAX` এর সক্ষমতা ফিরে পাই
            // 0, এখানে পৌঁছানো অগত্যা `RawVec` ওভারফুল হয়েছে এর অর্থ।
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` এর চেয়ে বেশি জেনেরিক।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// সংকলনের সময়গুলি হ্রাস করতে এই ফাংশনটি `RawVec` এর বাইরে।বিস্তারিত জানার জন্য এক্স01 এক্সের উপরে মন্তব্যটি দেখুন।
// (এক্স 100 এক্স প্যারামিটারটি তাত্পর্যপূর্ণ নয়, কারণ অনুশীলনে দেখা বিভিন্ন `A` ধরণের সংখ্যা `T` ধরণের সংখ্যার চেয়ে অনেক ছোট smaller)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` এর আকার হ্রাস করতে এখানে ত্রুটিটি পরীক্ষা করুন।
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // বরাদ্দকারী প্রান্তিককরণের সমতার জন্য পরীক্ষা করে
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` এর মালিকানাধীন মেমরিটিকে * এর বিষয়বস্তু বাদ দেওয়ার চেষ্টা না করেই সজ্জিত করে।
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// রিজার্ভ ত্রুটি পরিচালনার জন্য কেন্দ্রীয় ফাংশন।
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// আমাদের নিম্নলিখিত গ্যারান্টি দেওয়া প্রয়োজন:
// * আমরা কখনই `> isize::MAX` বাইট-সাইজ অবজেক্টগুলি বরাদ্দ করি না।
// * আমরা `usize::MAX` ওভারফ্লো করি না এবং আসলে খুব কম বরাদ্দ করি।
//
// - ৪-বিটে আমাদের কেবল ওভারফ্লো পরীক্ষা করা দরকার যেহেতু `> isize::MAX` বাইট বরাদ্দ দেওয়ার চেষ্টা অবশ্যই ব্যর্থ হবে।
// ৩২-বিট এবং ১--বিট-তে আমরা এর জন্য অতিরিক্ত গার্ড যুক্ত করতে হবে যদি আমরা এমন প্ল্যাটফর্মে চলছি যা ব্যবহারকারী-স্পেসে সমস্ত 4 জিবি ব্যবহার করতে পারে, যেমন, পিএই বা এক্স 100 এক্স।
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ক্ষমতার ওভারফ্লোগুলি রিপোর্ট করার জন্য দায়ী একটি কেন্দ্রীয় ফাংশন।
// এটি নিশ্চিত করবে যে এই জেড 0 প্যানিক্স0 জেড সম্পর্কিত কোড জেনারেশনটি ন্যূনতম কারণ মডিউল জুড়ে গুচ্ছের চেয়ে panics কেবলমাত্র একটি অবস্থান রয়েছে।
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}