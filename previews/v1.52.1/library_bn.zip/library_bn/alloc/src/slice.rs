//! একটি গতিযুক্ত আকারের একটি দৃশ্যকে একটি যথাযথ অনুক্রমে, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! স্লাইসগুলি পয়েন্টার এবং দৈর্ঘ্যের হিসাবে উপস্থাপিত মেমরির ব্লকের মধ্যে একটি ভিউ।
//!
//! ```
//! // একটি ভিসি কাটা
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // একটি টুকরা যাও একটি অ্যারে জোর
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! স্লাইস হয় পরিবর্তনীয় বা ভাগ করা হয়।
//! ভাগ করা স্লাইস টাইপটি `&[T]`, অন্যদিকে পরিবর্তিত স্লাইসের ধরণটি `&mut [T]`, যেখানে `T` উপাদান প্রকারের প্রতিনিধিত্ব করে।
//! উদাহরণস্বরূপ, আপনি মেমোরির ব্লকটিকে পরিবর্তন করতে পারেন যা একটি পরিবর্তনীয় টুকরাটি নির্দেশ করে:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! এই মডিউলটিতে রয়েছে এমন কিছু বিষয় এখানে:
//!
//! ## Structs
//!
//! স্লাইসগুলির জন্য দরকারী এমন বেশ কয়েকটি স্ট্রাক্ট রয়েছে যেমন [`Iter`], যা একটি স্লাইসের উপরে পুনরাবৃত্তি উপস্থাপন করে।
//!
//! ## Trait বাস্তবায়ন
//!
//! স্লাইসগুলির জন্য সাধারণ জেড 0 ট্রাইট0 জেডের বেশ কয়েকটি বাস্তবায়ন রয়েছে।কিছু উদাহরণ অন্তর্ভুক্ত:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], স্লাইসগুলির জন্য যার উপাদান ধরণের [`Eq`] বা [`Ord`]।
//! * [`Hash`] - স্লাইসগুলির জন্য যাদের উপাদানের প্রকারটি [`Hash`]।
//!
//! ## Iteration
//!
//! স্লাইসগুলি `IntoIterator` বাস্তবায়ন করে।পুনরুক্তি করা স্লাইস উপাদানগুলির জন্য রেফারেন্স দেয়।
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! পরিবর্তনীয় স্লাইস উপাদানগুলিতে পরিবর্তনীয় রেফারেন্স দেয়:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! এই পুনরাবৃত্তকারী স্লাইসের উপাদানগুলিতে পরিবর্তনীয় রেফারেন্স দেয়, সুতরাং স্লাইসের উপাদান টাইপটি `i32` থাকে তবে পুনরাবৃত্তির উপাদান টাইপটি `&mut i32` হয়।
//!
//!
//! * [`.iter`] ডিফল্ট পুনরাবৃত্তির ফিরিয়ে দেওয়ার জন্য এক্স এক্স এক্স স্পষ্ট পদ্ধতি।
//! * পুনরাবৃত্তির প্রত্যাবর্তনকারী আরও পদ্ধতি হ'ল [`.split`], [`.splitn`], [`.chunks`], [`.windows`] এবং আরও অনেক কিছু।
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// এই মডিউলে থাকা অনেকগুলি ওয়েস্ট কেবল পরীক্ষার কনফিগারেশনে ব্যবহৃত হয়।
// অব্যবহৃত_পোর্টস সতর্কতাগুলি ঠিক করার চেয়ে কেবল এটি বন্ধ করা আরও পরিষ্কার।
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// বেসিক স্লাইস এক্সটেনশন পদ্ধতি
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) এনবি পরীক্ষার সময় `vec!` ম্যাক্রো বাস্তবায়নের জন্য প্রয়োজনীয়, আরও তথ্যের জন্য এই ফাইলের `hack` মডিউলটি দেখুন।
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) এনবি পরীক্ষার সময় `Vec::clone` বাস্তবায়নের জন্য প্রয়োজনীয়, আরও তথ্যের জন্য এই ফাইলে `hack` মডিউলটি দেখুন।
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` উপলভ্য নয়, এই তিনটি ফাংশনটি আসলে এমন পদ্ধতি যা `impl [T]` তে থাকে তবে `core::slice::SliceExt` তে নয়, আমাদের এক্স04 এক্স পরীক্ষার জন্য এই ফাংশনগুলি সরবরাহ করতে হবে
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // আমাদের এটিতে ইনলাইন অ্যাট্রিবিউট যুক্ত করা উচিত নয় যেহেতু এটি বেশিরভাগ `vec!` ম্যাক্রোতে ব্যবহৃত হয় এবং পারফেক্ট রিগ্রেশন সৃষ্টি করে।
    // আলোচনা এবং পারফেক্ট ফলাফলের জন্য #71204 দেখুন।
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // আইটেমগুলি নীচের লুপে প্রাথমিকভাবে চিহ্নিত করা হয়েছিল
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) সীমাবদ্ধতা পরীক্ষাগুলি অপসারণ করতে এলএলভিএমের জন্য প্রয়োজনীয় এবং জিপের চেয়ে ভাল কোডজেন রয়েছে।
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // কমপক্ষে এই দৈর্ঘ্যের জন্য ভিসিকে বরাদ্দ করা হয়েছিল এবং উপরে আরম্ভ করা হয়েছিল।
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` এর ক্ষমতা সহ উপরে বরাদ্দ করা হয়েছে, এবং নীচে ptr::copy_to_non_overlapping এ `s.len()` এ সূচনা করুন।
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// স্লাইস সাজান।
    ///
    /// এই বাছাই স্থিতিশীল (যেমন, সমান উপাদানগুলির পুনঃক্রম না করে) এবং *ও*(*এন*\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে)।
    ///
    /// প্রযোজ্য ক্ষেত্রে অস্থির বাছাই পছন্দ করা হয় কারণ এটি সাধারণত স্থিতিশীল বাছাইয়ের চেয়ে দ্রুত এবং এটি সহায়ক মেমরি বরাদ্দ করে না।
    /// এক্স 100 এক্স দেখুন।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম হ'ল [timsort](https://en.wikipedia.org/wiki/Timsort) দ্বারা অনুপ্রাণিত একটি অভিযোজিত, পুনরাবৃত্ত মার্জ সাজান।
    /// স্লাইস প্রায় বাছাই করা হয়েছে এমন ক্ষেত্রে বা এটি একের পর এক দুটি বা আরও বাছাইযুক্ত ক্রমযুক্ত করে খুব দ্রুত তৈরি করার জন্য এটি ডিজাইন করা হয়েছে।
    ///
    ///
    /// এছাড়াও, এটি `self` এর অর্ধেক আকারের অস্থায়ী স্টোরেজ বরাদ্দ করে, তবে সংক্ষিপ্ত টুকরোগুলির জন্য একটি বরাদ্দ না করা সন্নিবেশ সাজানোর পরিবর্তে ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// একটি তুলনামূলক ফাংশন দিয়ে স্লাইস সাজান।
    ///
    /// এই বাছাই স্থিতিশীল (যেমন, সমান উপাদানগুলির পুনঃক্রম না করে) এবং *ও*(*এন*\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে)।
    ///
    /// তুলক ফাংশন অবশ্যই স্লাইসের উপাদানগুলির জন্য মোট ক্রম সংজ্ঞায়িত করতে হবে।যদি অর্ডারিং মোটটি না হয় তবে উপাদানগুলির ক্রমটি অনির্দিষ্ট।
    /// একটি অর্ডার মোট অর্ডার হয় যদি তা হয় (সমস্ত `a`, `b` এবং `c` এর জন্য):
    ///
    /// * মোট এবং অ্যান্টিসিমমেট্রিক: `a < b`, `a == b` বা `a > b` এর মধ্যে একটি সত্য, এবং
    /// * ট্রানজিটিভ, `a < b` এবং `b < c` এক্স01 এক্সকে বোঝায়।এটি অবশ্যই `==` এবং `>` উভয়ের জন্যই রাখা উচিত।
    ///
    /// উদাহরণস্বরূপ, [`f64`] [`Ord`] বাস্তবায়িত করে না কারণ `NaN != NaN`, আমরা যখন স্লাইসটিতে একটি এক্স 100 এক্স না থাকে তখন আমরা `partial_cmp` টিকে আমাদের বাছাই ফাংশন হিসাবে ব্যবহার করতে পারি।
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// প্রযোজ্য ক্ষেত্রে অস্থির বাছাই পছন্দ করা হয় কারণ এটি সাধারণত স্থিতিশীল বাছাইয়ের চেয়ে দ্রুত এবং এটি সহায়ক মেমরি বরাদ্দ করে না।
    /// এক্স 100 এক্স দেখুন।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম হ'ল [timsort](https://en.wikipedia.org/wiki/Timsort) দ্বারা অনুপ্রাণিত একটি অভিযোজিত, পুনরাবৃত্ত মার্জ সাজান।
    /// স্লাইস প্রায় বাছাই করা হয়েছে এমন ক্ষেত্রে বা এটি একের পর এক দুটি বা আরও বাছাইযুক্ত ক্রমযুক্ত করে খুব দ্রুত তৈরি করার জন্য এটি ডিজাইন করা হয়েছে।
    ///
    /// এছাড়াও, এটি `self` এর অর্ধেক আকারের অস্থায়ী স্টোরেজ বরাদ্দ করে, তবে সংক্ষিপ্ত টুকরোগুলির জন্য একটি বরাদ্দ না করা সন্নিবেশ সাজানোর পরিবর্তে ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // বিপরীত বাছাই
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// কী নিষ্কাশন ফাংশন দিয়ে স্লাইসটি সাজান।
    ///
    /// এই বাছাইটি স্থিতিশীল (অর্থাত্, সমান উপাদানগুলির পুনঃক্রম করতে পারে না) এবং *ও*(*এম* n * * এন *\* এক্স00 এক্স সবচেয়ে খারাপ পরিস্থিতি, যেখানে মূল ফাংশনটি *ও*(*মি*)।
    ///
    /// ব্যয়বহুল মূল কার্যগুলির জন্য (যেমন
    /// সাধারণ সম্পত্তি অ্যাক্সেস বা বেসিক ক্রিয়াকলাপ নয় এমন ফাংশন), [`sort_by_cached_key`](slice::sort_by_cached_key) সম্ভবত উল্লেখযোগ্যভাবে দ্রুত হতে পারে, কারণ এটি উপাদান কীগুলি পুনরায় সংশোধন করে না।
    ///
    ///
    /// প্রযোজ্য ক্ষেত্রে অস্থির বাছাই পছন্দ করা হয় কারণ এটি সাধারণত স্থিতিশীল বাছাইয়ের চেয়ে দ্রুত এবং এটি সহায়ক মেমরি বরাদ্দ করে না।
    /// এক্স 100 এক্স দেখুন।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম হ'ল [timsort](https://en.wikipedia.org/wiki/Timsort) দ্বারা অনুপ্রাণিত একটি অভিযোজিত, পুনরাবৃত্ত মার্জ সাজান।
    /// স্লাইস প্রায় বাছাই করা হয়েছে এমন ক্ষেত্রে বা এটি একের পর এক দুটি বা আরও বাছাইযুক্ত ক্রমযুক্ত করে খুব দ্রুত তৈরি করার জন্য এটি ডিজাইন করা হয়েছে।
    ///
    /// এছাড়াও, এটি `self` এর অর্ধেক আকারের অস্থায়ী স্টোরেজ বরাদ্দ করে, তবে সংক্ষিপ্ত টুকরোগুলির জন্য একটি বরাদ্দ না করা সন্নিবেশ সাজানোর পরিবর্তে ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// কী নিষ্কাশন ফাংশন দিয়ে স্লাইসটি সাজান।
    ///
    /// বাছাইয়ের সময়, মূল ফাংশনটি প্রতি উপাদান হিসাবে একবার কল করা হয়।
    ///
    /// এই ধরণের স্থিতিশীল (যেমন, সমান উপাদানগুলিকে পুনরায় অর্ডার করে না) এবং *ও*(*এম*\* * এন *+* এন *\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে, যেখানে মূল ফাংশনটি *ও*(*মি*) ।
    ///
    /// সাধারণ কী ফাংশনগুলির জন্য (যেমন, ফাংশন যা সম্পত্তি অ্যাক্সেস বা বেসিক ক্রিয়াকলাপ), এক্স00 এক্স দ্রুততর হওয়ার সম্ভাবনা রয়েছে।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম ওসন পিটার্স দ্বারা [pattern-defeating quicksort][pdqsort] এর উপর ভিত্তি করে তৈরি করা হয়েছে, যা র্যান্ডমাইজড কুইকোর্টের দ্রুত গড় কেসকে হিপসোর্টের দ্রুততম খারাপের সাথে একত্রিত করে, যখন নির্দিষ্ট নিদর্শনগুলির সাথে স্লাইসগুলিতে রৈখিক সময় অর্জন করে।
    /// এটি অবক্ষয়জনিত কেসগুলি এড়ানোর জন্য কিছুটা র‌্যান্ডমাইজেশন ব্যবহার করে তবে সর্বদা নির্দ্বিধামূলক আচরণ প্রদানের জন্য একটি স্থির seed ব্যবহার করে।
    ///
    /// সবচেয়ে খারাপ ক্ষেত্রে, অ্যালগরিদম স্লাইসের দৈর্ঘ্যে একটি `Vec<(K, usize)>` এ অস্থায়ী স্টোরেজ বরাদ্দ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // বরাদ্দ হ্রাস করার জন্য, আমাদের vector ক্ষুদ্রতম সম্ভাব্য প্রকারের দ্বারা সূচক করার জন্য সহায়ক ম্যাক্রো।
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` এর উপাদানগুলি অনন্য, যেমন তারা সূচকযুক্ত হয়, তাই মূল স্লাইসের সাথে কোনও ধরণের স্থিতিশীল থাকবে।
                // আমরা এখানে `sort_unstable` ব্যবহার করি কারণ এর জন্য কম স্মৃতি বরাদ্দ প্রয়োজন।
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// এক্স 011 এক্সকে একটি নতুন এক্স 100 এক্সে অনুলিপি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // এখানে, `s` এবং `x` স্বাধীনভাবে পরিবর্তন করা যেতে পারে।
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` কে একটি বরাদ্দকারী সহ একটি নতুন এক্স01 এক্সে অনুলিপি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // এখানে, `s` এবং `x` স্বাধীনভাবে পরিবর্তন করা যেতে পারে।
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // এনবি, আরও তথ্যের জন্য এই ফাইলে `hack` মডিউলটি দেখুন।
        hack::to_vec(self, alloc)
    }

    /// ক্লোন বা বরাদ্দ ছাড়াই `self` কে vector এ রূপান্তর করে।
    ///
    /// ফলাফল প্রাপ্ত vector `Vec এর মাধ্যমে আবার একটি বাক্সে রূপান্তরিত হতে পারে<T>এর এক্স 100 এক্স পদ্ধতি।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` এটি আর ব্যবহার করা যাবে না কারণ এটি `x` এ রূপান্তরিত হয়েছে।
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // এনবি, আরও তথ্যের জন্য এই ফাইলে `hack` মডিউলটি দেখুন।
        hack::into_vec(self)
    }

    /// একটি স্লাইস `n` বার পুনরাবৃত্তি করে একটি vector তৈরি করে।
    ///
    /// # Panics
    ///
    /// ক্ষমতাটি ওভারফ্লো হয়ে গেলে এই ফাংশনটি panic করবে will
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ওভারফ্লো উপর একটি panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // যদি `n` শূন্যের চেয়ে বড় হয় তবে এটি `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` হিসাবে বিভক্ত হতে পারে।
        // `2^expn` `n` এর বামতম '1' বিট দ্বারা প্রতিনিধিত্ব করা সংখ্যা এবং `rem` হল `n` এর অবশিষ্ট অংশ।
        //
        //

        // `set_len()` অ্যাক্সেস করতে `Vec` ব্যবহার করা।
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` পুনরাবৃত্তি `buf`-এক্সপেন-বার দ্বিগুণ করে করা হয়।
        buf.extend(self);
        {
            let mut m = n >> 1;
            // যদি `m > 0` হয় তবে বামতম '1' পর্যন্ত অবশিষ্ট বিট রয়েছে।
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` এর ক্ষমতা রয়েছে।
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ Expn`) পুনরাবৃত্তিটি `buf` থেকে নিজেই প্রথম `rem` পুনরাবৃত্তি অনুলিপি দ্বারা সম্পন্ন হয়।
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // এটি `2^expn > rem`-এর পরে অ-ওভারল্যাপিং।
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` এর সমান (`= self.len() * n`))।
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` এর এক স্লাইসকে একক মান `Self::Output` এ ফ্ল্যাট করে।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// প্রতিটি মধ্যে একটি পৃথক পৃথক পৃথক স্থাপন করে, একক মান `Self::Output` এ `T` এর একটি স্লাইস ফ্ল্যাট করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// প্রতিটি মধ্যে একটি পৃথক পৃথক পৃথক স্থাপন করে, একক মান `Self::Output` এ `T` এর একটি স্লাইস ফ্ল্যাট করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// এই স্লাইসের একটি অনুলিপিযুক্ত একটি জেড0ভেেক্টর0 জেড প্রদান করে যেখানে প্রতিটি বাইটকে তার ASCII আপার কেস সমতুল্যে ম্যাপ করা হয়।
    ///
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি বড়হাতে, [`make_ascii_uppercase`] ব্যবহার করুন।
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// এই স্লাইসের একটি অনুলিপিযুক্ত একটি জেড0ভেেক্টর0 জেড প্রদান করে যেখানে প্রতিটি বাইটকে তার ASCII নিম্নের সমতুল্য ম্যাপ করা হয়।
    ///
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি ছোট করতে, [`make_ascii_lowercase`] ব্যবহার করুন।
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// নির্দিষ্ট ধরণের ডেটাতে স্লাইসের জন্য traits প্রসারিত করুন
////////////////////////////////////////////////////////////////////////////////

/// [`[টি]: : কনক্যাট`](স্লাইস::কনক্যাট) এর জন্য সহায়ক জিডট্রেট0 জেড।
///
/// Note: এই trait এ `Item` টাইপ প্যারামিটার ব্যবহার করা হয়নি তবে এটি ইমপ্লগুলিকে আরও জেনেরিক হতে দেয়।
/// এটি ছাড়া, আমরা এই ত্রুটিটি পাই:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// এটি একাধিক `Borrow<[_]>` ইমপ্লের সাথে `V` প্রকারের উপস্থিতি থাকতে পারে কারণ একাধিক `T` প্রকারগুলি প্রয়োগ করতে পারে:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// সংক্ষিপ্তকরণের পরে ফলাফল প্রকার
    type Output;

    /// [`[টি]: : কনক্যাট`](স্লাইস::কনক্যাট) এর বাস্তবায়ন
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[টি]: : জোয়ান`](স্লাইস::যোগ) এর জন্য সহায়ক জেড0ট্রাইট0 জেড
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// সংক্ষিপ্তকরণের পরে ফলাফল প্রকার
    type Output;

    /// [`[টি]: : জয়েন`](স্লাইস::যোগ) এর বাস্তবায়ন
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// স্লাইসগুলির জন্য মানক trait বাস্তবায়ন
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // লক্ষ্যবস্তুতে এমন কোনও কিছু ফেলে দিন যা ওভাররাইট করা হবে না
        target.truncate(self.len());

        // target.len <= self.len উপরের কাটা কাটা কারণে, সুতরাং এখানে টুকরো সবসময় অন্তঃসীমা।
        //
        let (init, tail) = self.split_at(target.len());

        // এক্সট্রেসযুক্ত মানগুলিকে পুনরায় ব্যবহার করুন।
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` প্রাক-সাজানো ক্রম `v[1..]` সন্নিবেশ করান যাতে পুরো `v[..]` বাছাই হয়ে যায়।
///
/// এটি সন্নিবেশ সাজানোর অবিচ্ছেদ্য সাবরুটাইন।
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // সন্নিবেশ প্রয়োগের জন্য এখানে তিনটি উপায় রয়েছে:
            //
            // 1. প্রথমটি তার চূড়ান্ত গন্তব্যে না আসা পর্যন্ত সংলগ্ন উপাদানগুলি অদলবদল করুন।
            //    যাইহোক, এইভাবে আমরা প্রয়োজনের চেয়ে বেশি প্রায় ডেটা অনুলিপি করি।
            //    যদি উপাদানগুলি বড় কাঠামো হয় (অনুলিপি করা ব্যয়বহুল), এই পদ্ধতিটি ধীর হবে।
            //
            // 2. প্রথম উপাদানটির জন্য সঠিক স্থান না পাওয়া পর্যন্ত Iterate করুন।
            // তারপরে এটির জন্য জায়গা তৈরি করতে সফল হওয়া উপাদানগুলি স্থানান্তর করুন এবং অবশেষে এটিকে অবশিষ্ট গর্তে রাখুন।
            // এটি একটি ভাল পদ্ধতি।
            //
            // 3. অস্থায়ী ভেরিয়েবলে প্রথম উপাদানটি অনুলিপি করুন।এটির জন্য সঠিক স্থানটি না পাওয়া পর্যন্ত Iterate করুন।
            // আমরা পাশাপাশি চলার সাথে সাথে প্রতিটি ট্র্যাভার্ড করা উপাদান এর পূর্ববর্তী স্লটে অনুলিপি করুন।
            // অবশেষে, অস্থায়ী পরিবর্তনশীল থেকে ডেটা অনুলিপি করে অবশিষ্ট গর্তে।
            // এই পদ্ধতিটি খুব ভাল।
            // বেঞ্চমার্ক ২ য় পদ্ধতির তুলনায় কিছুটা ভাল পারফরম্যান্স দেখিয়েছে।
            //
            // সমস্ত পদ্ধতি বেঞ্চমার্কযুক্ত ছিল এবং তৃতীয়টি সেরা ফলাফল দেখিয়েছে।সুতরাং আমরা যে এক চয়ন।
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // সন্নিবেশ প্রক্রিয়াটির মধ্যবর্তী অবস্থা সর্বদা `hole` দ্বারা অনুসরণ করা হয়, যা দুটি উদ্দেশ্যে পরিবেশন করে:
            // 1. X0 `is_less` এর panics থেকে `v` এর অখণ্ডতা রক্ষা করে।
            // 2. শেষে `v` এ অবশিষ্ট গর্তটি পূরণ করে।
            //
            // Panic সুরক্ষা:
            //
            // প্রক্রিয়া চলাকালীন যে কোনও সময়ে যদি `is_less` panics হয়, `hole` নামবে এবং `tmp` এক্স এর গর্তটি `tmp` দিয়ে পূর্ণ করবে, সুতরাং এটি নিশ্চিত করে যে `v` এখনও প্রথমে ঠিক একবারে অনুষ্ঠিত প্রতিটি বস্তু ধরে রেখেছে।
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ফেলে দেওয়া হয় এবং এইভাবে এক্স0 এক্স এক্সকে `v` এর অবশিষ্ট গর্তে অনুলিপি করে।
        }
    }

    // নামানো হলে `src` থেকে `dest` এ অনুলিপিগুলি।
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// অ-হ্রাস-না হওয়া রানগুলি `v[..mid]` এবং `v[mid..]` কে অস্থায়ী স্টোরেজ হিসাবে `buf` ব্যবহার করে এবং ফলাফলটিকে `v[..]` এ সঞ্চয় করে।
///
/// # Safety
///
/// দুটি স্লাইস অবশ্যই খালি নয় এবং `mid` অবশ্যই সীমানায় থাকতে হবে।
/// খাটো স্লাইসের একটি অনুলিপি ধরে রাখার জন্য বাফার `buf` অবশ্যই যথেষ্ট দীর্ঘ হতে হবে।
/// এছাড়াও, `T` অবশ্যই শূন্য আকারের ধরণের হওয়া উচিত নয়।
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // মার্জ প্রক্রিয়াটি প্রথমে `buf` এ সংক্ষিপ্ত রানটিকে অনুলিপি করে।
    // তারপরে এটি সদ্য অনুলিপি করা রান এবং লম্বা দৌড়ে এগিয়ে (বা পিছনের দিকে) সন্ধান করে, তাদের পরবর্তী অসমর্থিত উপাদানগুলির তুলনা করে এবং কম (বা আরও বেশি) একটিকে `v` এ অনুলিপি করে।
    //
    // সংক্ষিপ্ত রানটি পুরোপুরি গ্রাস হওয়ার সাথে সাথে প্রক্রিয়াটি সম্পন্ন হয়।যদি লম্বা রানটি প্রথমে গ্রাস হয়ে যায়, তবে সংক্ষিপ্ত রানের বাকি যা কিছু আছে তা আমাদের অবশ্যই `v` এর অবশিষ্ট গর্তে অনুলিপি করতে হবে।
    //
    // প্রক্রিয়াটির মধ্যবর্তী অবস্থা সর্বদা `hole` দ্বারা অনুসরণ করা হয়, যা দুটি উদ্দেশ্যে পরিবেশন করে:
    // 1. X0 `is_less` এর panics থেকে `v` এর অখণ্ডতা রক্ষা করে।
    // 2. লম্বা রানটি প্রথম গ্রাস হয়ে গেলে `v` এ অবশিষ্ট গর্ত পূরণ করে।
    //
    // Panic সুরক্ষা:
    //
    // প্রক্রিয়া চলাকালীন যে কোনও মুহুর্তে যদি `is_less` panics হয়, `hole` ছাড়বে এবং `buf` এর অনির্ধারিত পরিসীমাটি দিয়ে `v` এর গর্তটি পূরণ করবে, সুতরাং এটি নিশ্চিত করে যে `v` এখনও শুরুতে একবারে অনুষ্ঠিত প্রতিটি বস্তু ধরে রেখেছে।
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // বাম রান ছোট হয়।
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // প্রাথমিকভাবে, এই পয়েন্টারগুলি তাদের অ্যারের শুরুতে নির্দেশ করে।
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // কম দিক গ্রহণ করুন।
            // সমান হলে, স্থিতিশীলতা বজায় রাখতে বাম রানটি পছন্দ করুন।
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ডান রান ছোট হয়।
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // প্রাথমিকভাবে, এই পয়েন্টারগুলি তাদের অ্যারের শেষের দিকে নির্দেশ করে।
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // বৃহত্তর দিক গ্রহণ করুন।
            // সমান হলে, স্থিতিশীলতা বজায় রাখার জন্য ডান রানটিকে পছন্দ করুন।
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // অবশেষে, `hole` বাদ পড়ে।
    // যদি সংক্ষিপ্ত রানটি পুরোপুরি গ্রাস না করা হত তবে এর যা কিছু অবশিষ্ট রয়েছে তা এখন `v` এর গর্তে অনুলিপি করা হবে।

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // নামানো হলে `start..end` রেঞ্জটি `dest..` এ অনুলিপি করে।
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` একটি শূন্য আকারের প্রকার নয়, সুতরাং এটির আকার দিয়ে ভাগ করা ঠিক।
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// এই মার্জ সাজানোর টিমসোর্ট থেকে কিছু (তবে সমস্ত নয়) ধারনা নিয়েছে, যা বিশদ [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) বর্ণিত।
///
///
/// অ্যালগরিদম কঠোরভাবে অবতরণ এবং অবতীর্ণ অনুচ্ছেদগুলি সনাক্ত করে, যা প্রাকৃতিক রান বলে।এখনও একত্রীকরণের বাকি মুলতুবি রয়েছে।
/// প্রতিটি নতুন পাওয়া রান স্ট্যাকের দিকে ঠেলাঠেলি করা হয় এবং তারপরে এই দুটি আক্রমণকারী সন্তুষ্ট না হওয়া অবধি কিছু সংলগ্ন রানগুলি একত্রীকরণ করা হয়:
///
/// 1. `1..runs.len()` এ প্রতিটি এক্স 0 এক্স এর জন্য: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` এ প্রতিটি এক্স 0 এক্স এর জন্য: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// আক্রমণকারীরা নিশ্চিত করে যে মোট চলমান সময় *ও*(*এন*\* এক্স00 এক্স সবচেয়ে খারাপ অবস্থা)।
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // এই দৈর্ঘ্য পর্যন্ত স্লাইস সন্নিবেশ সাজানোর মাধ্যমে বাছাই করা হয়।
    const MAX_INSERTION: usize = 20;
    // কমপক্ষে এই অনেক উপাদান বিস্তৃত করতে সন্নিবেশ সাজানোর সাহায্যে খুব ছোট রানগুলি বাড়ানো হয়।
    const MIN_RUN: usize = 10;

    // শূন্য আকারের ধরণের ক্ষেত্রে বাছাইয়ের কোনও অর্থবহ আচরণ নেই।
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // বরাদ্দ এড়াতে সংক্ষিপ্ত অ্যারে সন্নিবেশ সাজানোর মাধ্যমে স্থানে সাজানো হয়।
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // স্ক্র্যাচ মেমরি হিসাবে ব্যবহার করতে একটি বাফার বরাদ্দ করুন।আমরা দৈর্ঘ্য 0 রাখি যাতে `is_less` panics যদি অনুলিপিগুলিতে চলমান ডেক্টরগুলিকে ঝুঁকি না দিয়ে আমরা এতে `v` এর সামগ্রীগুলির অগভীর রাখতে পারি।
    //
    // দুটি বাছাই করা রানের মার্জ করার সময়, এই বাফারটি সংক্ষিপ্ত রানের একটি অনুলিপি রাখে, যার দৈর্ঘ্য সর্বদা সর্বোচ্চ `len / 2` হবে will
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` এ প্রাকৃতিক রানগুলি সনাক্ত করতে, আমরা এটিকে পিছনের দিকে পিছনে ফেলেছি।
    // এটি একটি অদ্ভুত সিদ্ধান্তের মতো বলে মনে হতে পারে তবে একত্রিত হওয়াটি প্রায়শই বিপরীত দিকের (forwards) এ চলে যায় তা বিবেচনা করুন।
    // মানদণ্ড অনুসারে, সামনের দিকে মার্জ করার চেয়ে সামনের দিকে মার্জ করা কিছুটা দ্রুত।
    // উপসংহারে, পিছনে পিছনে গিয়ে রান শনাক্তকরণ কার্যকারিতা উন্নত করে।
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // পরবর্তী প্রাকৃতিক রানটি সন্ধান করুন এবং যদি এটি কঠোরভাবে অবতরণ হয় তবে এটিকে বিপরীত করুন।
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // এটি খুব সংক্ষিপ্ত হলে রানটিতে আরও কিছু উপাদান Inোকান।
        // সংক্ষিপ্ত সিকোয়েন্সগুলিতে সংযোজনকরণের চেয়ে সন্নিবেশ সাজানো দ্রুততর হয়, সুতরাং এটি কার্যকারিতাটি উল্লেখযোগ্যভাবে উন্নত করে।
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // এই রান স্ট্যাকের উপর ধাক্কা।
        runs.push(Run { start, len: end - start });
        end = start;

        // আক্রমণকারীদের সন্তুষ্ট করতে সংলগ্ন রানগুলির কয়েক জোড়া মার্জ করুন।
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // শেষ অবধি, এক রান অবশ্যই স্ট্যাকের মধ্যে থাকতে হবে।
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // রানের স্ট্যাক পরীক্ষা করে এবং একত্রীকরণের জন্য পরবর্তী জোড়া রান সনাক্ত করে।
    // আরও সুনির্দিষ্টভাবে, যদি `Some(r)` ফেরত আসে তবে এর অর্থ `runs[r]` এবং `runs[r + 1]` অবশ্যই একত্রিত করা উচিত।
    // যদি এর পরিবর্তে অ্যালগরিদম একটি নতুন রান তৈরি করা চালিয়ে যায় তবে `None` ফিরে আসবে।
    //
    // টিমসোর্টটি বগি বাস্তবায়নের জন্য কুখ্যাত, যেমন এখানে বর্ণিত:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // গল্পটির মূল বক্তব্যটি হ'ল: আমাদের অবশ্যই আক্রমণকারীদের স্ট্যাকের উপরের চারটি রানে প্রয়োগ করতে হবে।
    // কেবলমাত্র শীর্ষ তিনে তাদের প্রয়োগ করা নিশ্চিত করা যথেষ্ট নয় যে আক্রমণকারীরা এখনও স্ট্যাকের *সমস্ত* রান রাখতে পারে।
    //
    // এই ফাংশনটি শীর্ষ চারটি রানের জন্য সঠিকভাবে আক্রমণকারীদের পরীক্ষা করে।
    // তদ্ব্যতীত, শীর্ষস্থানীয় সূচক যদি 0 থেকে শুরু হয়, বাছাই সম্পূর্ণ করার জন্য, স্ট্যাক সম্পূর্ণরূপে ভেঙে না ফেলা পর্যন্ত এটি সর্বদা মার্জ অপারেশনটির দাবি করবে।
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}