//! ইউনিকোড স্ট্রিং টুকরা।
//!
//! *[See also the `str` primitive type](str).*
//!
//! এক্স01 এক্স টাইপ দুটি প্রধান স্ট্রিং প্রকারগুলির মধ্যে একটি, অন্যটি `String`।
//! এটির এক্স 100 এক্স সমতুল্য নয়, এর সামগ্রীগুলি ধার করা হয়েছে।
//!
//! # বেসিক ব্যবহার
//!
//! `&str` প্রকারের একটি প্রাথমিক স্ট্রিং ঘোষণা:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! এখানে আমরা একটি স্ট্রিং আক্ষরিক ঘোষণা করেছি, এটি স্ট্রিং স্লাইস হিসাবেও পরিচিত।
//! স্ট্রিং লিটারালগুলির একটি স্থির জীবনকাল থাকে যার অর্থ `hello_world` স্ট্রিংটি পুরো প্রোগ্রামের সময়কালের জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
//!
//! আমরা `হ্যালো_ওয়ার্ল্ডwor এর জীবনকালও স্পষ্টভাবে নির্দিষ্ট করতে পারি:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// এই মডিউলে থাকা অনেকগুলি ওয়েস্ট কেবল পরীক্ষার কনফিগারেশনে ব্যবহৃত হয়।
// অব্যবহৃত_পোর্টস সতর্কতাগুলি ঠিক করার চেয়ে কেবল এটি বন্ধ করা আরও পরিষ্কার।
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` এ `str` এখানে অর্থবহ নয়।
/// trait এর এই ধরণের প্যারামিটারটি কেবল অন্য ইমপ্লিট সক্ষম করতে বিদ্যমান।
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // হার্ডকোডযুক্ত মাপের লুপগুলি খুব দ্রুত সঞ্চালিত হয় ছোট ছোট বিভাজক দৈর্ঘ্যের ক্ষেত্রে কেস বিশেষ করে
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // নির্বিচারে অ-শূন্য আকারের ফ্যালব্যাক
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// অপ্টিমাইজড জয়েন বাস্তবায়ন যা ভিসি উভয়ের পক্ষে কাজ করে<T>(টি: অনুলিপি করুন) এবং স্ট্রিংয়ের অভ্যন্তরীণ ভিসি বর্তমানে (2018-05-13) তে টাইপ অনুমান এবং বিশেষীকরণ সহ একটি বাগ রয়েছে (#36262 সংখ্যাটি দেখুন) এই কারণে স্লাইসকনক্যাট<T>টির জন্য বিশেষীকরণ করা হয় না: অনুলিপি এবং স্লাইসকনকাট<str>এই ফাংশনটির একমাত্র ব্যবহারকারী।
// এটি স্থির করার জন্য এটি জায়গায় রেখে দেওয়া হয়।
//
// স্ট্রিং-যোগ দেওয়ার সীমানা হ'ল এস: ধার<str>এবং ভিস-জয়েন Bণ নেওয়ার জন্য <[টি]> এক্স00 এক্স এবং স্ট্র উভয়ই কিছু টি-এর জন্য এসআরএফ <[টি]>
// => s.borrow().as_ref() এবং আমাদের সবসময় টুকরা থাকে
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // প্রথম টুকরাটি কেবলমাত্র এটির পূর্ববর্তী বিভাজক ছাড়া
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // যোগদান করা ভিসির সঠিক মোট দৈর্ঘ্যটি গণনা করুন যদি `len` গণনা ওভারফ্লো হয় তবে আমরা panic করব যেভাবেই আমাদের মেমরিটি শেষ হয়ে যাবে এবং বাকী ফাংশনটির পুরো ভিসিকে প্রাক-বরাদ্দ করা দরকার সুরক্ষার জন্য
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // অবিচ্ছিন্ন বাফার প্রস্তুত করুন
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // সীমা ছাড়াই কপির বিভাজক এবং স্লাইসগুলি ছোট বিভাজকগুলির জন্য বৃহত উন্নতিগুলি (~ x2) এর জন্য হার্ডকডযুক্ত অফসেটগুলি সহ লুপ উত্পন্ন করে
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // একটি অদ্ভুত orrowণ বাস্তবায়ন দৈর্ঘ্য গণনা এবং আসল অনুলিপি জন্য বিভিন্ন স্লাইস ফিরে আসতে পারে।
        //
        // নিশ্চিত করুন যে আমরা কলারের কাছে অবিচ্ছিন্ন বাইটগুলি প্রকাশ করি না।
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// স্ট্রিং টুকরা জন্য পদ্ধতি।
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// অনুলিপি বা বরাদ্দ ছাড়াই একটি `Box<str>` কে `Box<[u8]>` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// কোনও প্যাটার্নের সমস্ত মিলকে অন্য স্ট্রিংয়ের সাথে প্রতিস্থাপন করে।
    ///
    /// `replace` একটি নতুন এক্স 100 এক্স তৈরি করে এবং এই স্ট্রিংয়ের তথ্যটি এতে টুকরো করে।
    /// এটি করার সময় এটি কোনও প্যাটার্নের মিল খুঁজে পাওয়ার চেষ্টা করে।
    /// যদি এটি কোনও খুঁজে পায় তবে এটি তাদের প্রতিস্থাপনের স্ট্রিং স্লাইস দ্বারা প্রতিস্থাপন করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// যখন প্যাটার্নটি মেলে না:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// কোনও প্যাটার্নের প্রথম এন ম্যাচগুলিকে অন্য স্ট্রিংয়ের সাথে প্রতিস্থাপন করে।
    ///
    /// `replacen` একটি নতুন এক্স 100 এক্স তৈরি করে এবং এই স্ট্রিংয়ের তথ্যটি এতে টুকরো করে।
    /// এটি করার সময় এটি কোনও প্যাটার্নের মিল খুঁজে পাওয়ার চেষ্টা করে।
    /// এটি যদি কোনওটি খুঁজে পায়, তবে এটি বেশিরভাগ `count` বারে প্রতিস্থাপনের স্ট্রিং স্লাইস দ্বারা তাদের প্রতিস্থাপন করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// যখন প্যাটার্নটি মেলে না:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // পুনরায় বরাদ্দের সময় কমাতে আশা করি
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// একটি নতুন [`String`] হিসাবে, এই স্ট্রিং স্লাইসের ছোট হাতের সমান Return
    ///
    /// 'Lowercase' ইউনিকোড ডেরিভড কোর সম্পত্তি `Lowercase` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// যেহেতু কেস পরিবর্তন করার সাথে কিছু অক্ষর একাধিক অক্ষরে বিস্তৃত হতে পারে, তাই এই ফাংশনটি স্থানটিতে পরামিতি পরিবর্তনের পরিবর্তে একটি [`String`] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// সিগমা সহ একটি কৃপণ উদাহরণ:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // তবে একটি শব্দের শেষে এটি ς, নয় σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// কেস ছাড়া ভাষা পরিবর্তন করা হয় না:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word মানচিত্রগুলি σ, কোনও শব্দের শেষে যেখানে এটি maps তে ম্যাপ করে ς
                // এটি একমাত্র শর্তাধীন (contextual) তবে `SpecialCasing.txt` এ ভাষা-স্বতন্ত্র ম্যাপিং, সুতরাং জেনেরিক "condition" প্রক্রিয়া না করে হার্ড-কোড করুন।
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` সংজ্ঞা জন্য।
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// একটি নতুন [`String`] হিসাবে, এই স্ট্রিং স্লাইসের বড় হাতের সমান ফেরত দেয়।
    ///
    /// 'Uppercase' ইউনিকোড ডেরিভড কোর সম্পত্তি `Uppercase` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// যেহেতু কেস পরিবর্তন করার সাথে কিছু অক্ষর একাধিক অক্ষরে বিস্তৃত হতে পারে, তাই এই ফাংশনটি স্থানটিতে পরামিতি পরিবর্তনের পরিবর্তে একটি [`String`] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// মামলা ছাড়া স্ক্রিপ্ট পরিবর্তন করা হয় না:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// একটি চরিত্র একাধিক হয়ে উঠতে পারে:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// অনুলিপি বা বরাদ্দ ছাড়াই একটি [`Box<str>`] কে [`String`] এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// একটি স্ট্রিং `n` বার পুনরাবৃত্তি করে একটি নতুন এক্স 100 এক্স তৈরি করে।
    ///
    /// # Panics
    ///
    /// ক্ষমতাটি ওভারফ্লো হয়ে গেলে এই ফাংশনটি panic করবে will
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// ওভারফ্লো উপর একটি panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// এই স্ট্রিংয়ের একটি অনুলিপি প্রদান করে যেখানে প্রতিটি অক্ষরকে তার ASCII আপার কেস সমতুল্য করে ম্যাপ করা হয়।
    ///
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি বড়হাতে, [`make_ascii_uppercase`] ব্যবহার করুন।
    ///
    /// অ-এসসিআইআই অক্ষর ছাড়াও ASCII অক্ষরগুলি বড় করতে, [`to_uppercase`] ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 আক্রমণকারী সংরক্ষণ করে।
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// এই স্ট্রিংয়ের একটি অনুলিপি প্রদান করে যেখানে প্রতিটি অক্ষরকে তার ASCII লোয়ার কেস সমতুল্যে ম্যাপ করা হয়।
    ///
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি ছোট করতে, [`make_ascii_lowercase`] ব্যবহার করুন।
    ///
    /// অ-এসসিআইআই অক্ষর ছাড়াও ASCII অক্ষরগুলি ছোট করতে, [`to_lowercase`] ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 আক্রমণকারী সংরক্ষণ করে।
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// স্ট্রিংটিতে বৈধ UTF-8 রয়েছে কিনা তা পরীক্ষা না করেই বাইটের একটি বক্সযুক্ত স্লাইসকে একটি বক্সযুক্ত স্ট্রিং স্লাইসে রূপান্তরিত করে।
///
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}