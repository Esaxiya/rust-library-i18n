//! একক থ্রেডযুক্ত রেফারেন্স-কাউন্টিং পয়েন্টার।'Rc' এর অর্থ 'রেফারেন্স'
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] টাইপটি গাদাতে বরাদ্দকৃত `T` প্রকারের একটির ভাগের মালিকানা সরবরাহ করে।
//! [`Rc`] এ [`clone`][clone] আমন্ত্রণ করা হিপগুলিতে একই বরাদ্দে একটি নতুন পয়েন্টার তৈরি করে।
//! প্রদত্ত বরাদ্দের সর্বশেষ [`Rc`] পয়েন্টারটি ধ্বংস হয়ে গেলে সেই বরাদ্দকৃত সঞ্চিত মান (প্রায়শই "inner value" হিসাবে উল্লেখ করা হয়) বাদ দেওয়া হয়।
//!
//! Rust-এ ভাগ করা রেফারেন্সগুলি ডিফল্টরূপে মিউটেশনটিকে অস্বীকার করে এবং এক্স01 এক্স এর ব্যতিক্রম নয়: আপনি সাধারণত কোনও [`Rc`] এর অভ্যন্তরের কোনও কিছুর পরিবর্তনে রেফারেন্স পেতে পারেন না।
//! যদি আপনার পরিবর্তনের প্রয়োজন হয় তবে [`Rc`] এর ভিতরে একটি এক্স 2 এক্স বা এক্স03 এক্স রাখুন;এক্স 100 এক্স দেখুন।
//!
//! [`Rc`] অ-পারমাণবিক রেফারেন্স গণনা ব্যবহার করে।
//! এর অর্থ হ'ল ওভারহেড খুব কম, তবে থ্রেডগুলির মধ্যে একটি [`Rc`] প্রেরণ করা যাবে না এবং ফলস্বরূপ [`Rc`] [`Send`][send] প্রয়োগ করে না।
//! ফলস্বরূপ, Rust সংকলক *সংকলনের সময়* যাচাই করবে যে আপনি [`Rc s] গুলি থ্রেডের মধ্যে প্রেরণ করছেন না।
//! আপনার যদি একাধিক-থ্রেডযুক্ত, পারমাণবিক রেফারেন্স গণনা প্রয়োজন হয় তবে [`sync::Arc`][arc] ব্যবহার করুন।
//!
//! [`downgrade`][downgrade] পদ্ধতিটি কোনও নন-মালিকানাধীন [`Weak`] পয়েন্টার তৈরি করতে ব্যবহার করা যেতে পারে।
//! একটি এক্স01 এক্স পয়েন্টারটি [`আপগ্রেড][আপগ্রেড] ডি থেকে এক্স এক্স এক্স এক্স হতে পারে তবে বরাদ্দকৃত সঞ্চিত মানটি ইতিমধ্যে বাদ দেওয়া থাকলে এটি এক্স02 এক্স ফিরে আসবে।
//! অন্য কথায়, এক্স 100 এক্স পয়েন্টারগুলি বরাদ্দের ভিতরে মানটি বাঁচিয়ে রাখে না;তবে, তারা বরাদ্দ (অভ্যন্তরীণ মানের জন্য ব্যাক স্টোর) রাখে *।
//!
//! [`Rc`] পয়েন্টারগুলির মধ্যে একটি চক্র কখনই বিলোপযুক্ত হবে না।
//! এই কারণে, [`Weak`] চক্র ভাঙ্গতে ব্যবহৃত হয়।
//! উদাহরণস্বরূপ, একটি গাছে পিতামাতৃ নোড থেকে বাচ্চাদের কাছে শক্তিশালী [`Rc`] পয়েন্টার এবং বাচ্চাদের কাছ থেকে তাদের পিতামাতার কাছে ফিরে আসা [`Weak`] পয়েন্টার থাকতে পারে।
//!
//! `Rc<T>` স্বয়ংক্রিয়ভাবে `T`-এর ([`Deref`] trait মাধ্যমে) উল্লেখ করা হয়, যাতে আপনি [`Rc<T>`][`Rc`] টাইপের মানতে `T` এর পদ্ধতিগুলিকে কল করতে পারেন।
//! `T` এর পদ্ধতির সাথে নামের সংঘর্ষ এড়াতে, [`Rc<T>`][`Rc`] এর পদ্ধতিগুলি নিজেই যুক্ত ফাংশন যা [fully qualified syntax] ব্যবহার করে ডাকা হয়:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `আরসি<T>`Clone` এর মতো traits এর বাস্তবায়নগুলিও পুরোপুরি যোগ্যতাসম্পন্ন সিনট্যাক্স ব্যবহার করে ডাকা যেতে পারে।
//! কিছু লোক পুরোপুরি যোগ্যতাসম্পন্ন সিনট্যাক্স ব্যবহার করতে পছন্দ করেন, আবার কেউ কেউ মেথড-কল সিনট্যাক্স ব্যবহার করতে পছন্দ করেন।
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // পদ্ধতি-কল সিনট্যাক্স
//! let rc2 = rc.clone();
//! // সম্পূর্ণরূপে যোগ্যতাসম্পন্ন বাক্য গঠন
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T`-এ স্বয়ংক্রিয়-অবলম্বন করে না, কারণ অভ্যন্তরীণ মানটি ইতিমধ্যে বাদ পড়েছে।
//!
//! # ক্লোনিং রেফারেন্স
//!
//! বিদ্যমান রেফারেন্স গণনা পয়েন্টার হিসাবে একই বরাদ্দে একটি নতুন রেফারেন্স তৈরি করা [`Rc<T>`][`Rc`] এবং [`Weak<T>`][`Weak`] এর জন্য বাস্তবায়িত `Clone` trait ব্যবহার করে করা হয়।
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // নীচের দুটি বাক্য গঠন সমান।
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a এবং b উভয়ই ফু হিসাবে একই মেমরি অবস্থানের দিকে নির্দেশ করে।
//! ```
//!
//! `Rc::clone(&from)` সিনট্যাক্সটি সর্বাধিক প্রতিযোগিতামূলক কারণ এটি কোডটির অর্থ আরও স্পষ্টভাবে জানায়।
//! উপরের উদাহরণে, এই বাক্য গঠনটি দেখতে আরও সহজ করে তোলে যে এই কোডটি ফু এর সম্পূর্ণ সামগ্রী অনুলিপি না করে একটি নতুন রেফারেন্স তৈরি করছে।
//!
//! # Examples
//!
//! এমন একটি দৃশ্য বিবেচনা করুন যেখানে `গ্যাজেটগুলির একটি সেট প্রদত্ত `Owner` এর মালিকানাধীন।
//! আমরা আমাদের `গ্যাজেটের পয়েন্টগুলি তাদের এক্স01 এক্সে রাখতে চাই।আমরা এটি অনন্য মালিকানা দিয়ে করতে পারি না, কারণ একাধিক গ্যাজেট একই `Owner` এর সাথে সম্পর্কিত হতে পারে।
//! [`Rc`] আমাদের একাধিক `গ্যাজেটের মধ্যে একটি `Owner` ভাগ করার অনুমতি দেয় এবং `Owner` এর যতগুলি এক্স এক্স 2 এক্স পয়েন্ট থাকে ততক্ষণ বরাদ্দ রাখতে দেয়।
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... অন্যান্য ক্ষেত্র
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... অন্যান্য ক্ষেত্র
//! }
//!
//! fn main() {
//!     // একটি রেফারেন্স-গণনা করা `Owner` তৈরি করুন।
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` এর অন্তর্ভুক্ত `গ্যাজেটগুলি তৈরি করুন।
//!     // `Rc<Owner>` ক্লোনিং আমাদের একই `Owner` বরাদ্দে একটি নতুন পয়েন্টার দেয়, প্রক্রিয়ায় রেফারেন্স গণনা বাড়িয়ে তোলে।
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // আমাদের স্থানীয় পরিবর্তনশীল `gadget_owner` এর নিষ্পত্তি করুন।
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ছাড়ার পরেও আমরা এখনও `গ্যাজেটগুলির `Owner` এর নাম মুদ্রণ করতে সক্ষম।
//!     // এটি হ'ল কারণ আমরা কেবলমাত্র একটিমাত্র `Rc<Owner>` ফেলেছি, এটি `Owner` নির্দেশ করে না।
//!     // যতক্ষণ না অন্য `Rc<Owner>` একই `Owner` বরাদ্দে নির্দেশ করছে ততক্ষণ এটি লাইভ থাকবে।
//!     // ক্ষেত্রের প্রজেকশন `gadget1.owner.name` কাজ করে কারণ `Rc<Owner>` স্বয়ংক্রিয়ভাবে `Owner`-এর জন্য dereferences।
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ফাংশন শেষে, `gadget1` এবং `gadget2` ধ্বংস হয়ে যায় এবং তাদের সাথে আমাদের `Owner` এর সর্বশেষ গণনা করা রেফারেন্স।
//!     // গ্যাজেট ম্যান এখন পাশাপাশি ধ্বংস হয়ে যায়।
//!     //
//! }
//! ```
//!
//! যদি আমাদের প্রয়োজনীয়তাগুলি পরিবর্তন হয় এবং `Owner` থেকে `Gadget` এও যেতে সক্ষম হওয়া দরকার, আমরা সমস্যার মধ্যে পড়ব।
//! `Owner` থেকে `Gadget` পর্যন্ত একটি [`Rc`] পয়েন্টার একটি চক্রের পরিচয় দেয়।
//! এর অর্থ হ'ল তাদের রেফারেন্স গণনাগুলি কখনই 0 এ পৌঁছাতে পারে না এবং বরাদ্দ কখনই ধ্বংস হয় না:
//! একটি স্মৃতি ফুটোএটি ঘুরে দেখার জন্য, আমরা এক্স00 এক্স পয়েন্টার ব্যবহার করতে পারি।
//!
//! Rust আসলে প্রথমদিকে এই লুপটি উত্পাদন করা কিছুটা কঠিন করে তোলে।একে অপরের সাথে নির্দেশিত দুটি মান দিয়ে শেষ করতে, তাদের মধ্যে একটির পরিবর্তনশীল হওয়া দরকার।
//! এটি কঠিন কারণ [`Rc`] কেবল মোড়কের মানটির অংশীদারি রেফারেন্স দিয়ে মেমরির সুরক্ষা কার্যকর করে এবং এগুলি সরাসরি রূপান্তর করতে দেয় না।
//! আমাদেরকে একটি [`RefCell`] তে রূপান্তর করতে ইচ্ছুক মানের অংশটি আমাদের আবৃত করতে হবে, যা * অভ্যন্তরীণ মিউটিবিলিটি সরবরাহ করে: একটি ভাগ করে দেওয়া রেফারেন্সের মাধ্যমে মিউটিয়েটি অর্জনের একটি পদ্ধতি।
//! [`RefCell`] রানটাইম সময়ে জেড 0 রুস্ট0 জেডের ingণ নিয়ম কার্যকর করে।
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... অন্যান্য ক্ষেত্র
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... অন্যান্য ক্ষেত্র
//! }
//!
//! fn main() {
//!     // একটি রেফারেন্স-গণনা করা `Owner` তৈরি করুন।
//!     // নোট করুন যে আমরা একটি `RefCell` এর মধ্যে `মালিকের vector এর` গ্যাজেটগুলি রেখেছি যাতে আমরা এটি একটি ভাগ করা রেফারেন্সের মাধ্যমে রূপান্তর করতে পারি।
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // পূর্বের মতো `gadget_owner` এর সাথে সম্পর্কিত `গ্যাজেটগুলি তৈরি করুন।
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // তাদের `Owner` এ। গ্যাজেটগুলি যুক্ত করুন।
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` গতিশীল orrowণ এখানে শেষ হয়।
//!     }
//!
//!     // আমাদের `গ্যাজেটগুলির উপর নজর রাখুন, তাদের বিশদটি মুদ্রণ করুন।
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` এটি একটি এক্স 100 এক্স।
//!         // যেহেতু `Weak` পয়েন্টারগুলি এই বরাদ্দটি এখনও উপস্থিত রয়েছে তার গ্যারান্টি দিতে পারে না, তাই আমাদের `upgrade` কল করতে হবে, যা একটি `Option<Rc<Gadget>>` প্রদান করে।
//!         //
//!         //
//!         // এই ক্ষেত্রে আমরা জানি যে বরাদ্দটি এখনও বিদ্যমান, তাই আমরা কেবল `unwrap` এক্স 100 এক্স।
//!         // আরও জটিল প্রোগ্রামে আপনার `None` ফলাফলের জন্য গ্রেফিউর ত্রুটি পরিচালনা করতে হবে।
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ফাংশন শেষে, `gadget_owner`, `gadget1`, এবং `gadget2` ধ্বংস হয়।
//!     // গ্যাজেটগুলিতে এখন কোনও শক্তিশালী (`Rc`) পয়েন্টার নেই, তাই সেগুলি নষ্ট হয়ে গেছে।
//!     // এটি গ্যাজেট ম্যানের রেফারেন্স গণনাটিকে শূন্য করে, তাই সেও ধ্বংস হয়ে যায়।
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// সম্ভাব্য ফিল্ড-অর্ডারিংয়ের বিপরীতে এটি repr(C) থেকে জেডফিউচার0 জেড-প্রুফ, এটি ট্রান্সম্যাটেবল অভ্যন্তরীণ প্রকারের অন্যথায় নিরাপদ [into|from]_raw() হস্তক্ষেপ করবে।
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// একটি একক থ্রেডযুক্ত রেফারেন্স-কাউন্টিং পয়েন্টার।'Rc' এর অর্থ 'রেফারেন্স'
/// Counted'.
///
/// আরও তথ্যের জন্য [module-level documentation](./index.html) দেখুন।
///
/// `Rc` এর অন্তর্নিহিত পদ্ধতিগুলি সমস্ত সম্পর্কিত ফাংশন, যার অর্থ হল যে আপনি তাদেরকে যেমন `value.get_mut()` এর পরিবর্তে [`Rc::get_mut(&mut value)`][get_mut] হিসাবে কল করতে হবে।
/// এটি অভ্যন্তর প্রকারের `T` এর পদ্ধতিগুলির সাথে দ্বন্দ্ব এড়ায়।
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // এটি অনর্থক ঠিক আছে কারণ এই আরসি জীবিত থাকাকালীন আমাদের গ্যারান্টিযুক্ত যে অভ্যন্তরীণ পয়েন্টারটি বৈধ।
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// একটি নতুন `Rc<T>` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // সমস্ত শক্তিশালী পয়েন্টারগুলির মালিকানাধীন একটি অন্তর্নিহিত দুর্বল পয়েন্টার রয়েছে, যা নিশ্চিত করে যে শক্তিশালী ডেস্ট্রাক্টর চলাকালীন দুর্বল বিনষ্টকারী কখনও বরাদ্দকে ছাড় দেয় না এমনকি দুর্বল পয়েন্টারটি শক্তিশালীটির ভিতরে সঞ্চিত থাকলেও।
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// নিজের প্রতি দুর্বল রেফারেন্স ব্যবহার করে একটি নতুন এক্স00 এক্স তৈরি করে।
    /// এই ফাংশনটি ফেরত দেওয়ার আগে দুর্বল রেফারেন্সকে আপগ্রেড করার চেষ্টা করার ফলে একটি `None` মান হবে।
    ///
    /// তবে, দুর্বল রেফারেন্সটি নির্দ্বিধায় ক্লোন করা এবং পরে ব্যবহারের জন্য সংরক্ষণ করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... আরও ক্ষেত্র
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // একক দুর্বল রেফারেন্স সহ "uninitialized" রাজ্যের অভ্যন্তরটি তৈরি করুন।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // এটি গুরুত্বপূর্ণ যে আমরা দুর্বল পয়েন্টারের মালিকানা ছেড়ে দেব না, নাহলে `data_fn` রিটার্নের সময় দিয়ে মেমরিটি মুক্ত হয়ে যেতে পারে।
        // আমরা যদি সত্যই মালিকানাটি পাস করতে চাইতাম, আমরা নিজের জন্য একটি অতিরিক্ত দুর্বল পয়েন্টার তৈরি করতে পারতাম, তবে এর ফলে দুর্বল রেফারেন্স গণনায় অতিরিক্ত আপডেট হতে পারে যা অন্যথায় প্রয়োজনীয় হতে পারে না।
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // শক্তিশালী রেফারেন্সগুলি সম্মিলিতভাবে ভাগ করা দুর্বল রেফারেন্সের মালিক হওয়া উচিত, সুতরাং আমাদের পুরানো দুর্বল রেফারেন্সের জন্য ডেস্ট্রাক্টর চালাবেন না।
        //
        mem::forget(weak);
        strong
    }

    /// অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন এক্স00 এক্স গঠন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// এক্স01 এক্স বাইট দিয়ে মেমরিটি ভরাট হওয়ার সাথে সাথে অবিচ্ছিন্ন সামগ্রীগুলির সাথে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফিরিয়ে নতুন `Rc<T>` তৈরি করে
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // সমস্ত শক্তিশালী পয়েন্টারগুলির মালিকানাধীন একটি অন্তর্নিহিত দুর্বল পয়েন্টার রয়েছে, যা নিশ্চিত করে যে শক্তিশালী ডেস্ট্রাক্টর চলাকালীন দুর্বল বিনষ্টকারী কখনও বরাদ্দকে ছাড় দেয় না এমনকি দুর্বল পয়েন্টারটি শক্তিশালীটির ভিতরে সঞ্চিত থাকলেও।
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// অবিচ্ছিন্ন বিষয়বস্তু সহ একটি নতুন এক্স00 এক্স তৈরি করে, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফিরিয়ে দেয়
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// এক্সটায়ালাইজড সামগ্রী সহ নতুন এক্স 100 এক্স তৈরি করে, মেমরিটি `0` বাইটে ভরাট করে, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফিরিয়ে দেয়
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// একটি নতুন `Pin<Rc<T>>` তৈরি করে।
    /// যদি `T` `Unpin` বাস্তবায়িত না করে, তবে এক্স0 2 এক্স মেমরিতে পিন হয়ে যাবে এবং সরানো যায় না।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` এর ঠিক একটি দৃ strong় রেফারেন্স থাকলে অভ্যন্তরীণ মানটি প্রদান করে।
    ///
    /// অন্যথায়, একটি [`Err`] একই `Rc` এর সাথে পাস করা হয়েছিল।
    ///
    ///
    /// অসামান্য দুর্বল উল্লেখ থাকলেও এটি সফল হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // অন্তর্ভুক্ত বস্তুটি কপি করুন

                // দুর্বলদের প্রতি ইঙ্গিত করুন যে শক্তিশালী গণনা হ্রাস করে তাদের প্রচার করা যাবে না এবং তারপরে কেবল একটি জাল দুর্বল তৈরি করে ড্রপ লজিক পরিচালনা করার সময় অন্তর্নিহিত "strong weak" পয়েন্টারটি সরিয়ে দিন।
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// অবিশ্রুত বিষয়বস্তু সহ একটি নতুন রেফারেন্স-গণনা করা স্লাইস তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` বাইটে মেমরিটি ভরাট হওয়ার সাথে সাথে অবিচ্ছিন্ন সামগ্রীগুলির সাথে একটি নতুন রেফারেন্স-গণনা করা স্লাইস তৈরি করে।
    ///
    ///
    /// এই পদ্ধতির সঠিক এবং ভুল ব্যবহারের উদাহরণগুলির জন্য [`MaybeUninit::zeroed`][zeroed] দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` এ রূপান্তর করে।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] এর মতো, অভ্যন্তরীণ মানটি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।
    ///
    /// সামগ্রীটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এটিকে কল করা তাত্ক্ষণিক সংজ্ঞায়িত আচরণের কারণ হয়।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` এ রূপান্তর করে।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] এর মতো, অভ্যন্তরীণ মানটি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।
    ///
    /// সামগ্রীটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এটিকে কল করা তাত্ক্ষণিক সংজ্ঞায়িত আচরণের কারণ হয়।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // স্থগিত সূচনা:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// মোড়ানো পয়েন্টারটি ফিরে, `Rc` গ্রহণ করে।
    ///
    /// মেমরি ফাঁস এড়াতে পয়েন্টারটি অবশ্যই [`Rc::from_raw`][from_raw] ব্যবহার করে একটি `Rc` এ রূপান্তর করতে হবে।
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ডেটাতে একটি কাঁচা পয়েন্টার সরবরাহ করে।
    ///
    /// গণনাগুলি কোনওভাবেই প্রভাবিত হয় না এবং `Rc` সেবন হয় না।
    /// এক্স 100 এক্সে শক্তিশালী গণনা রয়েছে ততক্ষণ পয়েন্টারটি বৈধ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // নিরাপত্তা: এটি Deref::deref বা Rc::inner এর মাধ্যমে যেতে পারে না কারণ এটি
        // এটি যেমন raw/mut প্রবণতা ধরে রাখা প্রয়োজন eg
        // `get_mut` `from_raw` এর মাধ্যমে আরসিটি পুনরুদ্ধারের পরে পয়েন্টারটির মাধ্যমে লিখতে পারে।
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// কাঁচা পয়েন্টার থেকে একটি `Rc<T>` তৈরি করে।
    ///
    /// কাঁচা পয়েন্টারটি অবশ্যই [`Rc<U>::into_raw`][into_raw] এ কল দিয়ে ফিরে এসেছে যেখানে `U` এর অবশ্যই `T` এর মতো আকার এবং প্রান্তিককরণ থাকতে হবে।
    /// `U` যদি `T` হয় তবে এটি তুচ্ছভাবে সত্য।
    /// মনে রাখবেন যে `U` যদি X01 এক্স না হয় তবে একই আকার এবং প্রান্তিককরণ থাকে তবে এটি মূলত বিভিন্ন ধরণের রেফারেন্স ট্রান্সমুটিংয়ের মতো।
    /// এই ক্ষেত্রে কী সীমাবদ্ধতা প্রযোজ্য সে সম্পর্কে আরও তথ্যের জন্য [`mem::transmute`][transmute] দেখুন।
    ///
    /// `from_raw`-এর ব্যবহারকারীকে `T` এর নির্দিষ্ট মানটি একবারে বাদ দেওয়া হয়েছে তা নিশ্চিত করতে হবে।
    ///
    /// এই ফাংশনটি অনিরাপদ কারণ অনুচিত ব্যবহারের কারণে স্মৃতিশক্তি অসম্পূর্ণ হতে পারে, এমনকি যদি ফিরে আসা `Rc<T>` কখনও অ্যাক্সেস না করা হয়।
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // ফুটো রোধ করতে একটি `Rc` এ ফিরে রূপান্তর করুন।
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` এ আরও কলগুলি মেমরি-অনিরাপদ হবে।
    /// }
    ///
    /// // `x` উপরের সুযোগের বাইরে চলে যাওয়ার পরে মেমরিটি মুক্ত হয়েছিল, তাই এক্স01 এক্স এখন ঝুঁকছে!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // আসল আরসিবক্স খুঁজতে অফসেটটি বিপরীত করুন।
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// এই বরাদ্দে একটি নতুন এক্স00 এক্স পয়েন্টার তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // নিশ্চিত করুন যে আমরা কোনও ঝোলা দুর্বল তৈরি করি না
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// এই বরাদ্দে [`Weak`] পয়েন্টার সংখ্যা পায়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// এই বরাদ্দটিতে শক্তিশালী (`Rc`) পয়েন্টার সংখ্যা পায়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// এই বরাদ্দে অন্য কোনও `Rc` বা [`Weak`] পয়েন্টার না থাকলে `true` প্রদান করে।
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// একই বরাদ্দে অন্য কোনও `Rc` বা [`Weak`] পয়েন্টার না থাকলে প্রদত্ত `Rc`-তে পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    ///
    /// অন্যথায় [`None`] প্রদান করে, কারণ ভাগ করা মানকে পরিবর্তন করা নিরাপদ নয়।
    ///
    /// এছাড়াও [`make_mut`][make_mut] দেখুন, যা অন্য পয়েন্টারগুলি উপস্থিত থাকলে অভ্যন্তরীণ মানটি [`clone`][clone] করবে।
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// কোনও চেক ছাড়াই প্রদত্ত `Rc` এর পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    /// এছাড়াও [`get_mut`] দেখুন, যা নিরাপদ এবং যথাযথ চেক করে।
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// একই বরাদ্দের জন্য অন্য কোনও `Rc` বা [`Weak`] পয়েন্টারগুলি অবশ্যই ফেরত bণের সময়কালের জন্য উপযুক্ত নয়।
    ///
    /// এটি তুচ্ছভাবে যদি কেস পয়েন্টার উপস্থিত না থাকে তবে উদাহরণস্বরূপ `Rc::new` এর পরে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // আমরা "count" ক্ষেত্রগুলি আবরণ করে * একটি রেফারেন্স তৈরি না করার বিষয়ে সতর্ক রয়েছি, কারণ এটি রেফারেন্স গণনায় অ্যাক্সেসের সাথে দ্বন্দ্ব করবে (যেমন
        // `Weak` দ্বারা)।
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// যদি দুটি `Rc thes একই বরাদ্দে ([`ptr::eq`] এর মতো শিরাতে) থাকে তবে `true` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// প্রদত্ত `Rc` এ একটি পরিবর্তনীয় রেফারেন্স তৈরি করে।
    ///
    /// যদি একই বরাদ্দে অন্য `Rc` পয়েন্টার থাকে তবে অনন্য মালিকানা নিশ্চিত করতে `make_mut` একটি নতুন বরাদ্দের অভ্যন্তরীণ মানকে [`clone`] করবে।
    /// এটিকে ক্লোন-অন-রাইটিং হিসাবেও উল্লেখ করা হয়।
    ///
    /// যদি এই বরাদ্দে অন্য কোনও `Rc` পয়েন্টার না থাকে তবে এই বরাদ্দের এক্স01 এক্স পয়েন্টারগুলি আলাদা করা হবে।
    ///
    /// এছাড়াও [`get_mut`] দেখুন, যা ক্লোনিংয়ের চেয়ে ব্যর্থ হবে।
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // কিছুই ক্লোন করবেন না
    /// let mut other_data = Rc::clone(&data);    // অভ্যন্তরীণ ডেটা ক্লোন করবে না
    /// *Rc::make_mut(&mut data) += 1;        // ক্লোনসের অভ্যন্তরীণ ডেটা
    /// *Rc::make_mut(&mut data) += 1;        // কিছুই ক্লোন করবেন না
    /// *Rc::make_mut(&mut other_data) *= 2;  // কিছুই ক্লোন করবেন না
    ///
    /// // এখন `data` এবং `other_data` বিভিন্ন বরাদ্দে নির্দেশ করে।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] পয়েন্টারগুলি আলাদা করা হবে:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ডেটা ক্লোন করতে হবে, অন্য আরসিএস রয়েছে।
            // ক্লোন করা মানটি সরাসরি লেখার জন্য মেমরি প্রাক-বরাদ্দ।
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // কেবল ডেটা চুরি করতে পারে, যা বাকী রয়েছে তা হ'ল উইাকস
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // অন্তর্নিহিত শক্তিশালী-দুর্বল রেফ সরান (এখানে কোনও জাল দুর্বল কারুকাজ করার দরকার নেই-আমরা জানি অন্য দুর্বলরা আমাদের জন্য পরিষ্কার করতে পারে)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // এই অনর্থকটি ঠিক আছে কারণ আমাদের গ্যারান্টিযুক্ত যে পয়েন্টারটি ফিরে এসেছে কেবলমাত্র * পয়েন্টার যা টি-তে ফিরে আসবে is
        // আমাদের রেফারেন্স গণনাটি এই মুহুর্তে 1 হওয়ার গ্যারান্টিযুক্ত এবং আমাদের `Rc<T>` নিজেই `mut` হওয়া দরকার, সুতরাং আমরা বরাদ্দের একমাত্র সম্ভাব্য রেফারেন্সটি ফিরিয়ে দিচ্ছি।
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` কে কংক্রিটের ধরণে ডাউনকাস্ট করার চেষ্টা করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// সম্ভাব্য-অচলিত অভ্যন্তরীণ মানের যেখানে মানটির বিন্যাসটি সরবরাহ করা হয়েছে তার জন্য পর্যাপ্ত জায়গা সহ একটি এক্স 100 এক্স বরাদ্দ করে।
    ///
    /// এক্স01 এক্স ফাংশনটি ডেটা পয়েন্টার সহ কল করা হয় এবং অবশ্যই `RcBox<T>` এর জন্য একটি (সম্ভাব্য ফ্যাট)-পয়েন্টারটি ফিরে আসতে হবে।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // প্রদত্ত মান বিন্যাস ব্যবহার করে বিন্যাস গণনা করুন।
        // পূর্বে, `&*(ptr as* const RcBox<T>)` এক্সপ্রেশনটিতে বিন্যাস গণনা করা হত, তবে এটি একটি ভুল স্বাক্ষরিত রেফারেন্স তৈরি করেছে (দেখুন #54908)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// একটি এক্স-00 এক্সকে সম্ভাব্য-অচলিত অভ্যন্তরীণ মানের জন্য পর্যাপ্ত জায়গা সহ বরাদ্দ দেয় যেখানে মানটি লেআউটটি সরবরাহ করে, বরাদ্দ ব্যর্থ হলে একটি ত্রুটি ফেরায়।
    ///
    ///
    /// এক্স01 এক্স ফাংশনটি ডেটা পয়েন্টার সহ কল করা হয় এবং অবশ্যই `RcBox<T>` এর জন্য একটি (সম্ভাব্য ফ্যাট)-পয়েন্টারটি ফিরে আসতে হবে।
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // প্রদত্ত মান বিন্যাস ব্যবহার করে বিন্যাস গণনা করুন।
        // পূর্বে, `&*(ptr as* const RcBox<T>)` এক্সপ্রেশনটিতে বিন্যাস গণনা করা হত, তবে এটি একটি ভুল স্বাক্ষরিত রেফারেন্স তৈরি করেছে (দেখুন #54908)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // বিন্যাসের জন্য বরাদ্দ করুন।
        let ptr = allocate(layout)?;

        // আরসিবক্স শুরু করুন
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// একটি আনসাইজড অভ্যন্তরীণ মানের জন্য পর্যাপ্ত জায়গা সহ একটি `RcBox<T>` বরাদ্দ করে
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // প্রদত্ত মানটি ব্যবহার করে `RcBox<T>` এর জন্য বরাদ্দ করুন।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // বাইট হিসাবে মান কপি করুন
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // বরাদ্দকরণের বিষয়বস্তু না ফেলেই বিনামূল্যে করুন
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// প্রদত্ত দৈর্ঘ্য সহ একটি `RcBox<[T]>` বরাদ্দ করে।
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// স্লাইস থেকে উপাদানগুলি সদ্য বরাদ্দ হওয়া আরসি <\[টি\]> এ অনুলিপি করুন
    ///
    /// অনিরাপদ কারণ কলারের অবশ্যই মালিকানা নিতে হবে বা `T: Copy` কে আবদ্ধ করতে হবে
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// নির্দিষ্ট আকারের হিসাবে পরিচিত একটি পুনরাবৃত্তকারী থেকে একটি `Rc<[T]>` তৈরি করে।
    ///
    /// আকারটি ভুল হওয়া উচিত আচরণটি অপরিজ্ঞাত।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // টি উপাদানগুলির ক্লোনিং করার সময় Panic প্রহরী।
        // panic এর ইভেন্টে, নতুন আরসিবক্সে লিখিত থাকা উপাদানগুলি বাদ দেওয়া হবে, তারপরে স্মৃতি মুক্ত হবে।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // পয়েন্টার প্রথম উপাদান
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // সব পরিষ্কার.গার্ডকে ভুলে যান যাতে এটি নতুন আরসিবক্সকে মুক্ত করে না।
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` এর জন্য বিশেষায়িতকরণ trait ব্যবহৃত।
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// এক্স 100 এক্স ড্রপ করে।
    ///
    /// এটি শক্তিশালী রেফারেন্স গণনা হ্রাস করবে।
    /// যদি শক্তিশালী রেফারেন্স গণনাটি শূন্যে পৌঁছে যায় তবে কেবলমাত্র অন্যান্য উল্লেখগুলি (যদি থাকে তবে) [`Weak`] হয়, সুতরাং আমরা অভ্যন্তরের মানটি `drop` করি।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // কিছু মুদ্রণ করে না
    /// drop(foo2);   // প্রিন্ট "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // অন্তর্ভুক্ত বস্তু ধ্বংস
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // এখনই অন্তর্নিহিত "strong weak" পয়েন্টারটি সরান যে আমরা সামগ্রীগুলি ধ্বংস করেছি।
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` পয়েন্টারের একটি ক্লোন তৈরি করে।
    ///
    /// শক্তিশালী রেফারেন্স গণনা বৃদ্ধি করে এটি একই বরাদ্দে আরেকটি পয়েন্টার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` এর জন্য `Default` মান সহ একটি নতুন এক্স01 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` এর একটি পদ্ধতি থাকলেও `Eq` এ বিশেষজ্ঞের অনুমতি দেওয়ার জন্য হ্যাক।
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// আমরা এই বিশেষীকরণটি এখানে করছি, এবং `&T` এ আরও সাধারণ অপ্টিমাইজেশন হিসাবে নয়, কারণ এটি অন্যথায় রেফগুলিতে সমস্ত সমতা চেকগুলিতে ব্যয় যোগ করবে।
/// আমরা ধরে নিই যে values Rc`s বৃহত্তর মান সংরক্ষণ করতে ব্যবহৃত হয়, এটি ক্লোন করতে ধীর হয় তবে সাম্যতা পরীক্ষা করতেও ভারী হয়, যার ফলে এই ব্যয়টি আরও সহজেই পরিশোধ করা যায়।
///
/// এটিতে দুটি 00&T`s এর চেয়েও দুটি এক্স00 এক্স ক্লোন হওয়ার সম্ভাবনা বেশি that
///
/// আমরা কেবল তখনই এটি করতে পারি যখন `T: Eq` `PartialEq` হিসাবে ইচ্ছাকৃত অপ্রয়োজনীয় হতে পারে।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// দুই `Rc`s এর জন্য সমতা।
    ///
    /// দুটি `Rc`s সমান যদি তাদের অভ্যন্তরীণ মান সমান হয়, এমনকি যদি তারা বিভিন্ন বরাদ্দে সঞ্চিত থাকে।
    ///
    /// যদি `T` এছাড়াও `Eq` (সমতার আবদ্ধ প্রতিচ্ছবি) প্রয়োগ করে, একই বরাদ্দকে নির্দেশ করে এমন দুটি `আরসি` সর্বদা সমান।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// দুই `Rc`s এর জন্য বৈষম্য।
    ///
    /// যদি তাদের অভ্যন্তরীণ মান অসম হয় তবে দুটি `আরসি অসম।
    ///
    /// যদি `T` এছাড়াও `Eq` (সমতার আবদ্ধ প্রতিচ্ছবি) প্রয়োগ করে, একই বরাদ্দকে নির্দেশ করে এমন দুটি `আরসি` কখনই অসম হয় না।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// দুই `Rc`s এর জন্য আংশিক তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `partial_cmp()` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// দুই `আরসি এর তুলনায় কম Less
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `<` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// দুটি `আরসি'র জন্য তুলনা 'এর চেয়ে কম বা সমান'।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `<=` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// বৃহত্তর-তুলনায় দুটি `আরসি এর জন্য।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `>` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'বৃহত্তর চেয়ে সমান বা সমান' দুটি `আরসি'র জন্য তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `>=` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// দুটি `আরসি এর জন্য তুলনা।
    ///
    /// দুটির সাথে তাদের অভ্যন্তরীণ মানগুলিতে `cmp()` কল করে তুলনা করা হচ্ছে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// একটি রেফারেন্স-গণনা করা স্লাইস বরাদ্দ করুন এবং `v` এর আইটেমগুলি ক্লোন করে এটি পূরণ করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// একটি রেফারেন্স-গণনা করা স্ট্রিং স্লাইস বরাদ্দ করুন এবং এতে `v` অনুলিপি করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// একটি রেফারেন্স-গণনা করা স্ট্রিং স্লাইস বরাদ্দ করুন এবং এতে `v` অনুলিপি করুন।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// একটি বাক্সযুক্ত বস্তুকে নতুন, রেফারেন্স গণনা, বরাদ্দে সরান।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// একটি রেফারেন্স-গণনা করা স্লাইস বরাদ্দ করুন এবং এর মধ্যে আইটেমগুলি সরান move
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // ভিসিকে এর স্মৃতি মুক্ত করার অনুমতি দিন, তবে এর সামগ্রীগুলি ধ্বংস করবেন না
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` এ প্রতিটি উপাদান নেয় এবং এটি একটি `Rc<[T]>` এ সংগ্রহ করে।
    ///
    /// # কর্মক্ষমতা বৈশিষ্ট্য
    ///
    /// ## সাধারণ ক্ষেত্রে
    ///
    /// সাধারণ ক্ষেত্রে, `Rc<[T]>` এ সংগ্রহ করা প্রথমে একটি `Vec<T>` এ সংগ্রহের মাধ্যমে করা হয়।এটি হ'ল নিম্নলিখিতটি লেখার সময়:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// এটি এমনভাবে আচরণ করে যেন আমরা লিখেছি:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // বরাদ্দের প্রথম সেটটি এখানে ঘটে।
    ///     .into(); // `Rc<[T]>` এর জন্য একটি দ্বিতীয় বরাদ্দ এখানে ঘটে।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// এটি `Vec<T>` নির্মানের জন্য যতবার প্রয়োজন ততবার বরাদ্দ করবে এবং তারপরে এটি `Vec<T>` কে `Rc<[T]>` এ রূপান্তর করার জন্য একবার বরাদ্দ করবে।
    ///
    ///
    /// ## পরিচিত দৈর্ঘ্যের Iteilers
    ///
    /// যখন আপনার `Iterator` `TrustedLen` প্রয়োগ করে এবং সঠিক আকারের হয়, তখন `Rc<[T]>` এর জন্য একটি একক বরাদ্দ দেওয়া হবে।উদাহরণ স্বরূপ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // এখানে একটি মাত্র বরাদ্দ ঘটে।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` এ সংগ্রহের জন্য বিশেষায়িতকরণ trait ব্যবহৃত।
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // এটি একটি `TrustedLen` পুনরাবৃত্তির ক্ষেত্রে।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // নিরাপত্তা: আমাদের নিশ্চিত করতে হবে যে পুনরাবৃত্তির সঠিক দৈর্ঘ্য রয়েছে এবং আমাদের রয়েছে।
                Rc::from_iter_exact(self, low)
            }
        } else {
            // স্বাভাবিক প্রয়োগে ফিরে যান।
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] এর একটি সংস্করণ যা পরিচালিত বরাদ্দের কোনও অ-মালিকানা সংক্রান্ত রেফারেন্স ধারণ করে।`Weak` পয়েন্টারে [`upgrade`] কল করে এই বরাদ্দটি অ্যাক্সেস করা হয়েছে, যা একটি [`বিকল্প`] returns <`[`আরসি`] returns প্রদান করে<T>>`।
///
/// যেহেতু একটি `Weak` রেফারেন্স মালিকানার দিকে গণনা করে না, এটি বরাদ্দকৃত সঞ্চিত মূল্য বাদ দেওয়া থেকে বিরত রাখবে না এবং এক্স01 এক্স নিজেই এখনও মান উপস্থিত থাকার বিষয়ে কোনও গ্যারান্টি দেয় না।
/// [`আপগ্রেড]] d হলে এটি [`None`] ফিরতে পারে।
/// তবে খেয়াল করুন যে একটি `Weak` রেফারেন্স * নিজেই বরাদ্দকে (ব্যাকিং স্টোর) আটকানো থেকে আটকাচ্ছে।
///
/// একটি `Weak` পয়েন্টার [`Rc`] দ্বারা পরিচালিত বরাদ্দটির অস্থায়ী রেফারেন্স রাখার জন্য এর অভ্যন্তরীণ মান বাদ পড়ার ছাড়াই দরকারী।
/// এটি [`Rc`] পয়েন্টারগুলির মধ্যে বিজ্ঞপ্তি সংক্রান্ত রেফারেন্স প্রতিরোধ করতেও ব্যবহৃত হয়, কারণ পারস্পরিক মালিকানার রেফারেন্সগুলি কখনই [`Rc`] কে বাদ দিতে দেয় না।
/// উদাহরণস্বরূপ, একটি গাছে পিতামাতৃ নোড থেকে বাচ্চাদের কাছে শক্তিশালী [`Rc`] পয়েন্টার এবং বাচ্চাদের কাছ থেকে তাদের পিতামাতার কাছে ফিরে আসা `Weak` পয়েন্টার থাকতে পারে।
///
/// `Weak` পয়েন্টারটি পাওয়ার সাধারণ উপায়টি হল [`Rc::downgrade`] কল করা।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // এনামগুলিতে এই ধরণের আকারের অনুকূলকরণের অনুমতি দেওয়ার জন্য এটি একটি এক্স 100 এক্স, তবে এটি অবশ্যই একটি বৈধ পয়েন্টার নয়।
    //
    // `Weak::new` এটি `usize::MAX` এ সেট করে যাতে এটির গাদাতে স্থান বরাদ্দের প্রয়োজন হয় না।
    // এটির আসল পয়েন্টারটির কোনও মূল্য নেই কারণ আরসিবক্সের কমপক্ষে 2 প্রান্তিককরণ রয়েছে।
    // এটি কেবল তখনই সম্ভব যখন এক্স 100 এক্স;আনসাইজড এক্স01 এক্স কখনই বিড়ম্বনা করে না।
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// কোনও মেমরি বরাদ্দ না করে একটি নতুন এক্স00 এক্স তৈরি করে।
    /// রিটার্ন ভ্যালুতে [`upgrade`] কল করা সর্বদা [`None`] দেয়।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ডেটা ক্ষেত্র সম্পর্কে কোনও মন্তব্য না করে রেফারেন্স গণনাগুলিতে অ্যাক্সেসের অনুমতি দেওয়ার জন্য সহায়ক প্রকার।
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// এই `Weak<T>` দ্বারা নির্দেশিত `T` অবজেক্টে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// কিছু শক্তিশালী উল্লেখ থাকলে কেবলমাত্র পয়েন্টারটি বৈধ।
    /// পয়েন্টারটি ঝোলা, স্বাক্ষরবিহীন বা অন্যথায় [`null`] হতে পারে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // উভয়ই একই বস্তুর দিকে ইঙ্গিত করে
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // শক্তিশালী এখানে এটিকে জীবিত রাখে, তাই আমরা এখনও অবজেক্টটি অ্যাক্সেস করতে পারি।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // কিন্তু আর না.
    /// // আমরা এক্স00 এক্স করতে পারি, তবে পয়েন্টারে অ্যাক্সেস করলে অপরিজ্ঞাত আচরণ হতে পারে।
    /// // assert_eq! ("হ্যালো", অনিরাপদ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // যদি পয়েন্টারটি ঝুঁকছে তবে আমরা সরাসরি সেন্ডিনেলটি ফিরিয়ে দেব।
            // এটি কোনও বৈধ পে-লোড ঠিকানা হতে পারে না, কারণ পে-লোড অন্তত RcBox (usize) হিসাবে সংযুক্ত থাকে।
            ptr as *const T
        } else {
            // নিরাপদ: যদি is_dangling মিথ্যা প্রত্যাবর্তন করে, তবে পয়েন্টারটি হ্রাসযোগ্য।
            // পেডলোডটি এই মুহুর্তে বাদ পড়তে পারে এবং আমাদের প্রবর্তন বজায় রাখতে হবে, তাই কাঁচা পয়েন্টার ম্যানিপুলেশন ব্যবহার করুন।
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// এক্স 100 এক্স গ্রহণ করে এবং এটি একটি কাঁচা পয়েন্টারে পরিণত করে।
    ///
    /// এটি দুর্বল পয়েন্টারটিকে একটি কাঁচা পয়েন্টারে রূপান্তরিত করে, যখন এখনও একটি দুর্বল রেফারেন্সের মালিকানা সংরক্ষণ করে (দুর্বল গণনাটি এই অপারেশন দ্বারা সংশোধিত হয় না)।
    /// এটি [`from_raw`] এর সাহায্যে `Weak<T>` এ ফিরে যেতে পারে।
    ///
    /// [`as_ptr`] এর মতো পয়েন্টারের লক্ষ্য অ্যাক্সেসের একই নিষেধাজ্ঞাগুলি প্রযোজ্য।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] দ্বারা পূর্বে তৈরি করা একটি কাঁচা পয়েন্টারকে `Weak<T>` এ আবার রূপান্তর করে।
    ///
    /// এটি নিরাপদে একটি শক্তিশালী রেফারেন্স পেতে (পরে [`upgrade`] কল করে) বা `Weak<T>` ফেলে দিয়ে দুর্বল গণনাটি ডিলেক্ট করতে ব্যবহার করা যেতে পারে।
    ///
    /// এটি একটি দুর্বল রেফারেন্সের মালিকানা নেয় ([`new`] দ্বারা নির্মিত পয়েন্টারগুলি ব্যতীত, কারণ এগুলির কোনও মালিকানা নেই; পদ্ধতিটি এখনও তাদের উপর কাজ করে)।
    ///
    /// # Safety
    ///
    /// পয়েন্টারটি অবশ্যই [`into_raw`] থেকে উদ্ভূত হয়েছে এবং এখনও এর সম্ভাব্য দুর্বল রেফারেন্সের মালিক হওয়া উচিত।
    ///
    /// এটি কল করার সময় শক্তিশালী গণনা 0 এর জন্য অনুমোদিত।
    /// তবুও, এটি বর্তমানে কাঁচা পয়েন্টার হিসাবে উপস্থাপিত একটি দুর্বল রেফারেন্সের মালিকানা গ্রহণ করে (দুর্বল গণনাটি এই ক্রিয়াকলাপের মাধ্যমে সংশোধিত হয় না) এবং তাই এটি অবশ্যই [`into_raw`] এ পূর্ববর্তী কল দিয়ে যুক্ত করা উচিত।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // শেষ দুর্বল গণনা হ্রাস।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ইনপুট পয়েন্টার কীভাবে উত্পন্ন হয় তা প্রসঙ্গে Weak::as_ptr দেখুন।

        let ptr = if is_dangling(ptr as *mut T) {
            // এটি একটি জটলা দুর্বল।
            ptr as *mut RcBox<T>
        } else {
            // অন্যথায়, আমরা নিশ্চিত যে পয়েন্টারটি কোনও দুর্বল দুর্বল থেকে এসেছে।
            // নিরাপদ: ডেটা_অফসেট কল করা নিরাপদ, কারণ পিটিআরটি একটি আসল (সম্ভাব্য বাদ দেওয়া) টির উল্লেখ করে।
            let offset = unsafe { data_offset(ptr) };
            // সুতরাং, আমরা পুরো আরসিবক্স পেতে অফসেটটি বিপরীত করি।
            // সুরক্ষা: পয়েন্টারটি দুর্বল থেকে উদ্ভূত, তাই এই অফসেটটি নিরাপদ।
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // সুরক্ষা: আমরা এখন আসল দুর্বল পয়েন্টারটি পুনরুদ্ধার করেছি, সুতরাং দুর্বল তৈরি করতে পারি।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` পয়েন্টারটিকে একটি [`Rc`] এ আপগ্রেড করার চেষ্টা, যদি সফল হয় তবে অভ্যন্তরীণ মান হ্রাস পেতে বিলম্ব হয়।
    ///
    ///
    /// যদি অভ্যন্তরীণ মানটি তখন থেকে বাদ দেওয়া হয় তবে [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // সমস্ত শক্তিশালী পয়েন্টার ধ্বংস করুন।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// এই বরাদ্দকে নির্দেশ করে শক্তিশালী (`Rc`) পয়েন্টার সংখ্যা পায়।
    ///
    /// যদি [`Weak::new`] এক্সটি [`Weak::new`] ব্যবহার করে তৈরি করা হয়েছিল, তবে এটি 0 এ ফিরে আসবে।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// এই বরাদ্দকে নির্দেশ করে `Weak` পয়েন্টার সংখ্যা পান।
    ///
    /// যদি কোনও শক্ত পয়েন্টার না থাকে তবে এটি শূন্যে ফিরে আসবে।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // অন্তর্নিহিত দুর্বল পিটিআর বিয়োগ করুন
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// পয়েন্টারটি যখন ঝুঁকছে তখন `None` প্রদান করে এবং কোনও বরাদ্দকৃত `RcBox` নেই (যেমন, যখন এই `Weak` এক্স03 এক্স দ্বারা নির্মিত হয়েছিল)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // আমরা "data" ফিল্ডটি কভার করে * কোনও রেফারেন্স তৈরি না করার বিষয়ে সতর্ক রয়েছি, কারণ ক্ষেত্রটি একই সাথে পরিবর্তিত হতে পারে (উদাহরণস্বরূপ, শেষ `Rc` বাদ দিলে ডেটা ক্ষেত্রটি জায়গায় রেখে দেওয়া হবে)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// যদি দু'টি দুর্বল একই বরাদ্দ ([`ptr::eq`] এর সমান) দিকে নির্দেশ করে, বা উভয় কোনও বরাদ্দকে নির্দেশ না করে তবে `true` প্রদান করে (কারণ এগুলি `Weak::new()`) দিয়ে তৈরি হয়েছিল।
    ///
    ///
    /// # Notes
    ///
    /// যেহেতু এটি পয়েন্টারগুলির সাথে তুলনা করে তার অর্থ এটি যে `Weak::new()` একে অপরের সাথে সমান হবে, যদিও তারা কোনও বরাদ্দকে নির্দেশ করে না।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// এক্স00 এক্স এর তুলনা করা হচ্ছে।
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// এক্স 100 এক্স পয়েন্টার বাদ দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // কিছু মুদ্রণ করে না
    /// drop(foo);        // প্রিন্ট "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // দুর্বল গণনাটি 1 থেকে শুরু হয় এবং সমস্ত শক্তিশালী পয়েন্টার অদৃশ্য হয়ে গেলে কেবল শূন্যে চলে যাবে।
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` পয়েন্টারের একটি ক্লোন তৈরি করে যা একই বরাদ্দকে নির্দেশ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `T` এর সূচনা না করে মেমরি বরাদ্দ করে একটি নতুন `Weak<T>` তৈরি করে।
    /// রিটার্ন ভ্যালুতে [`upgrade`] কল করা সর্বদা [`None`] দেয়।
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: আমরা নিরাপদে mem::forget ডিল করার জন্য এখানে চেক_আড্ড করেছি।নির্দিষ্টভাবে
// আপনি যদি mem::forget আরসিএস (বা দুর্বল) হয়ে থাকেন তবে রেফ-কাউন্টটি উপচে পড়তে পারে, এবং তারপরে আপনি অসামান্য আরসিএস (বা দুর্বল) উপস্থিত থাকা অবস্থায় বরাদ্দটি মুক্ত করতে পারেন।
//
// আমরা গর্ভপাত করি কারণ এটি এমন একটি হ্রাসপ্রাপ্ত পরিস্থিতি যা ঘটেছিল তা নিয়ে আমরা মাথা ঘামাই না-কোনও সত্যিকারের প্রোগ্রামটি কখনই এটি অনুভব করা উচিত নয়।
//
// মালিকানা এবং সরানো-শব্দার্থবিজ্ঞানের জন্য জেড রাস্ট0 জেডে আপনাকে এগুলি আসলে ক্লোন করার দরকার নেই বলে এটির উপেক্ষিত ওভারহেড থাকা উচিত।
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // আমরা মান বাদ দেওয়ার পরিবর্তে ওভারফ্লোতে বাতিল করতে চাই।
        // যখন এটিকে বলা হয় তখন রেফারেন্স গণনা কখনই শূন্য হবে না;
        // তবুও, আমরা অন্যথায় মিস হওয়া অপ্টিমাইজেশনে এলএলভিএমকে ইঙ্গিত করতে এখানে একটি বিসর্জন sertোকান।
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // আমরা মান বাদ দেওয়ার পরিবর্তে ওভারফ্লোতে বাতিল করতে চাই।
        // যখন এটিকে বলা হয় তখন রেফারেন্স গণনা কখনই শূন্য হবে না;
        // তবুও, আমরা অন্যথায় মিস হওয়া অপ্টিমাইজেশনে এলএলভিএমকে ইঙ্গিত করতে এখানে একটি বিসর্জন sertোকান।
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// পয়েন্টারের পিছনে পেওডের জন্য একটি এক্স00 এক্স এর মধ্যে অফসেট পান।
///
/// # Safety
///
/// পয়েন্টারটি অবশ্যই টি এর পূর্বের বৈধ উদাহরণের সাথে (এবং এর জন্য বৈধ মেটাডেটা থাকতে হবে) নির্দেশ করতে হবে, তবে টি বাদ দেওয়ার অনুমতি দেওয়া হয়েছে।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // আরসিবক্সের শেষে অব্যবহৃত মানটিকে সারিবদ্ধ করুন।
    // আরসিবক্স repr(C) হওয়ায় এটি সর্বদা স্মৃতিতে সর্বশেষ ক্ষেত্র হবে।
    // নিরাপত্তা: যেহেতু কেবলমাত্র অচলিত ধরণের প্রকারগুলি হ'ল স্লাইস, জেড 0 ট্রাইট0 জেড অবজেক্ট,
    // এবং বাহ্যিক ধরণের, ইনপুট সুরক্ষা প্রয়োজনীয়তা বর্তমানে align_of_val_raw এর প্রয়োজনীয়তাগুলি পূরণ করার জন্য যথেষ্ট;এটি ভাষাটির একটি বাস্তবায়নের বিশদ যা std এর বাইরে নির্ভর করা যায় না।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}