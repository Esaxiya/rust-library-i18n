#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ব্যাকট্রেসগুলির জন্য একটি ফর্ম্যাটর।
///
/// এই প্রকারটি ব্যাকট্রেস যেখানেই এসেছে সেটিকে নির্বিশেষে একটি ব্যাকট্রেস মুদ্রণ করতে ব্যবহার করা যেতে পারে।
/// আপনার যদি `Backtrace` প্রকার থাকে তবে এর `Debug` বাস্তবায়ন ইতিমধ্যে এই মুদ্রণ ফর্ম্যাটটি ব্যবহার করে।
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// মুদ্রণের শৈলী যা আমরা মুদ্রণ করতে পারি
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// একটি টিয়ার্স ব্যাকট্রেস মুদ্রণ করে যা আদর্শভাবে কেবল প্রাসঙ্গিক তথ্য ধারণ করে
    Short,
    /// একটি ব্যাকট্রেস মুদ্রণ করে যাতে সমস্ত সম্ভাব্য তথ্য থাকে
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// একটি নতুন `BacktraceFmt` তৈরি করুন যা প্রদত্ত `fmt` এ আউটপুট লিখবে।
    ///
    /// `format` টি আর্গুমেন্টটি স্টাইলটি নিয়ন্ত্রণ করবে যেখানে ব্যাকট্র্যাসটি মুদ্রিত হবে এবং `print_path` টি যুক্তি ফাইলের `BytesOrWideString` উদাহরণগুলি মুদ্রণ করতে ব্যবহৃত হবে।
    /// এই ধরণের নিজেই ফাইল নামগুলির কোনও মুদ্রণ করে না, তবে এই কলব্যাকটি করার জন্য এটি প্রয়োজন।
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ব্যাকট্রেসটি মুদ্রিত হওয়ার জন্য একটি উপস্থাপক মুদ্রণ করে।
    ///
    /// ব্যাকট্রেসগুলি পরে পুরোপুরি প্রতীকী হওয়ার জন্য এটি কয়েকটি প্ল্যাটফর্মে প্রয়োজন এবং অন্যথায় এটি `BacktraceFmt` তৈরির পরে আপনি যে প্রথম পদ্ধতিটি কল করবেন এটি হওয়া উচিত।
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ব্যাকট্রেস আউটপুটটিতে একটি ফ্রেম যুক্ত করে।
    ///
    /// এই প্রতিশ্রুতিটি `BacktraceFrameFmt` এর একটি RAII উদাহরণ দেয় যা প্রকৃতপক্ষে কোনও ফ্রেম মুদ্রণের জন্য ব্যবহার করা যেতে পারে এবং ধ্বংসের সময় এটি ফ্রেমের কাউন্টারকে বাড়িয়ে তুলবে।
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// ব্যাকট্রেস আউটপুট সম্পূর্ণ করে।
    ///
    /// এটি বর্তমানে একটি অপ-অপশন নয় তবে ব্যাকট্র্যাস ফর্ম্যাটগুলির সাথে জেড0 ফিউচার0 জেড সামঞ্জস্যের জন্য যুক্ত করা হয়েছে।
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // জেডফিউচার0 জেড সংযোজনগুলির জন্য মঞ্জুরি দেওয়ার জন্য বর্তমানে এই জেড0 হুক0 জেড সহ একটি অন-আপ-।
        Ok(())
    }
}

/// ব্যাকট্রিসের মাত্র একটি ফ্রেমের জন্য একটি ফর্ম্যাটর।
///
/// এই ধরণেরটি `BacktraceFmt::frame` ফাংশন দ্বারা তৈরি করা হয়েছে।
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// এই ফ্রেম ফর্ম্যাটারের সাহায্যে একটি `BacktraceFrame` মুদ্রণ করে।
    ///
    /// এটি পুনরাবৃত্তভাবে `BacktraceFrame` এর মধ্যে সমস্ত `BacktraceSymbol` দস্তাবেজ মুদ্রণ করবে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// একটি `BacktraceFrame` এর মধ্যে একটি `BacktraceSymbol` মুদ্রণ করে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: এটি দুর্দান্ত কিছু নয় যে আমরা কিছু মুদ্রণ শেষ করি না
            // নন-utf8 ফাইলের নাম সহ।
            // ধন্যবাদ, প্রায় সবই utf8 তাই এটি খুব খারাপ হওয়া উচিত নয়।
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// সাধারণত এই crate এর কাঁচা কলব্যাকের মধ্যে থেকে কোনও কাঁচা ট্রেড `Frame` এবং `Symbol` মুদ্রণ করে।
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ব্যাকট্রেস আউটপুটে একটি কাঁচা ফ্রেম যুক্ত করে।
    ///
    /// এই পদ্ধতিটি পূর্বের মত নয়, বিভিন্ন স্থান থেকে উত্স হওয়ার কারণে কাঁচা যুক্তিগুলি গ্রহণ করে।
    /// নোট করুন যে এটি এক ফ্রেমের জন্য একাধিকবার বলা যেতে পারে।
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// কলামের তথ্য সহ ব্যাকট্রেস আউটপুটটিতে একটি কাঁচা ফ্রেম যুক্ত করে।
    ///
    /// এই পদ্ধতিটি, পূর্বের মতো, বিভিন্ন স্থান থেকে উত্স হওয়ার কারণে কাঁচা যুক্তি গ্রহণ করে।
    /// নোট করুন যে এটি এক ফ্রেমের জন্য একাধিকবার বলা যেতে পারে।
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ফুচিয়া কোনও প্রক্রিয়ার মধ্যে প্রতীক দিতে অক্ষম তাই এর একটি বিশেষ ফর্ম্যাট রয়েছে যা পরে প্রতীক হিসাবে ব্যবহার করা যেতে পারে।
        // এখানে আমাদের নিজস্ব ফর্ম্যাটে ঠিকানা মুদ্রণের পরিবর্তে মুদ্রণ করুন।
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // এক্স 100 এক্স ফ্রেমগুলি প্রিন্ট করার দরকার নেই, এটির মূলত এটির অর্থ হ'ল সিস্টেম ব্যাকট্রেস খুব পিছনে সুপার ব্যাক টریس করতে আগ্রহী ছিল।
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // এসজিএক্স এনক্ল্যাভে টিসিবি আকার হ্রাস করতে আমরা প্রতীক রেজোলিউশন কার্যকারিতা বাস্তবায়ন করতে চাই না।
        // বরং আমরা এখানে ঠিকানার অফসেটটি মুদ্রণ করতে পারি, যা পরে ফাংশনটি সংশোধন করতে ম্যাপ করা যায়।
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ফ্রেমের সূচী পাশাপাশি ফ্রেমের ofচ্ছিক নির্দেশিকা পয়েন্টার মুদ্রণ করুন।
        // আমরা যদি এই ফ্রেমের প্রথম চিহ্নের বাইরে থাকি তবে আমরা কেবল উপযুক্ত হোয়াইটস্পেস মুদ্রণ করি।
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // এরপরে প্রতীক নামটি লিখুন, বিকল্পের ফর্ম্যাটিং ব্যবহার করে আরও তথ্যের জন্য আমরা যদি পুরো ব্যাকট্রেস পাই।
        // এখানে আমরা এমন চিহ্নগুলিও পরিচালনা করি যার নাম নেই,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // এবং শেষ পর্যন্ত, filename/line নম্বর উপলব্ধ থাকলে প্রিন্ট আউট করুন।
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line প্রতীক নামের অধীনে লাইনে মুদ্রিত হয়, তাই সঠিকভাবে সাজানোর জন্য কিছু উপযুক্ত হোয়াইটস্পেস প্রিন্ট করুন ourselves
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ফাইলের নামটি মুদ্রণের জন্য আমাদের অভ্যন্তরীণ কলবাকে প্রেরণ করুন এবং তারপরে লাইন নম্বরটি মুদ্রণ করুন।
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // উপলব্ধ থাকলে কলাম নম্বর যুক্ত করুন।
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // আমরা কেবল কোনও ফ্রেমের প্রথম প্রতীক সম্পর্কে যত্নশীল
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}