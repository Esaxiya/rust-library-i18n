//! রানটাইমে ব্যাকট্রিজ অর্জনের জন্য একটি গ্রন্থাগার
//!
//! এই লাইব্রেরির অর্থ রানটাইম প্রোগ্রামযুক্তভাবে ব্যাকট্র্যাস অর্জনের অনুমতি দিয়ে স্ট্যান্ডার্ড লাইব্রেরির `RUST_BACKTRACE=1` সমর্থন পরিপূরক করা।
//! এই লাইব্রেরির দ্বারা উত্পাদিত ব্যাকট্রেসগুলি বিশ্লেষণ করার প্রয়োজন নেই, উদাহরণস্বরূপ, এবং একাধিক ব্যাকএন্ড বাস্তবায়নের কার্যকারিতা প্রকাশ করে।
//!
//! # Usage
//!
//! প্রথমে এটি আপনার Cargo.toml এ যুক্ত করুন
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // এখানে অনিরাপদ তাই পরীক্ষা no_std এ পাস করে।
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // প্রতীক নামের এই নির্দেশিকাটির পয়েন্টারটি সমাধান করুন
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // পরের ফ্রেমে যেতে থাকুন
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// যখন আমরা ইচ্ছামত অংশ হিসাবে বিল্ডিং করছি, সমস্ত সতর্কতা নিঃশব্দ করুন যেহেতু তারা এই জেড 0 ক্রেট0 জেড গাছের বাইরে তৈরি হওয়ায় তারা অপ্রাসঙ্গিক।
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// এটি এখনই কেবল জিমলির জন্য ব্যবহৃত হয়, যা কেবলমাত্র কয়েকটি প্ল্যাটফর্মে ব্যবহৃত হয়, তাই এটি অন্য কনফিগারেশনে অব্যবহৃত হলে চিন্তা করবেন না।
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;