use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// একটি মালিকানাধীন এবং স্ব-অন্তর্ভুক্ত ব্যাকট্রেসের প্রতিনিধিত্ব।
///
/// এই কাঠামোটি কোনও প্রোগ্রামের বিভিন্ন পয়েন্টে ব্যাকট্রিজ ক্যাপচার করতে ব্যবহার করা যেতে পারে এবং পরে ব্যাকট্রেস কী ছিল তা পরিদর্শন করতে ব্যবহার করা যেতে পারে।
///
///
/// `Backtrace` এর এক্স 100 এক্স বাস্তবায়নের মাধ্যমে ব্যাকট্রেসগুলির সুন্দর-মুদ্রণ সমর্থন করে।
///
/// # প্রয়োজনীয় বৈশিষ্ট্য
///
/// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // এখানে ফ্রেমগুলি স্ট্যাকের উপর থেকে নীচে তালিকাভুক্ত করা হয়
    frames: Vec<BacktraceFrame>,
    // আমরা যে সূচকটি বিশ্বাস করি তা হ'ল এক্সটেক্স এক্স এবং এক্স00 এক্সের মতো ফ্রেম বাদ দিয়ে ব্যাকট্রেশের আসল শুরু।
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// ব্যাকট্র্যাসে ফ্রেমের ক্যাপচার করা সংস্করণ।
///
/// এই ধরণেরটি `Backtrace::frames` থেকে তালিকা হিসাবে ফিরে আসে এবং ক্যাপচারিত ব্যাকট্র্যাসে একটি স্ট্যাক ফ্রেম উপস্থাপন করে।
///
/// # প্রয়োজনীয় বৈশিষ্ট্য
///
/// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// ব্যাকট্র্যাসে প্রতীকের সংস্করণ ক্যাপচার করা হয়েছে।
///
/// এই ধরণেরটি `BacktraceFrame::symbols` থেকে তালিকা হিসাবে ফিরে আসে এবং ব্যাকট্র্যাসে প্রতীকের জন্য মেটাডেটা উপস্থাপন করে।
///
/// # প্রয়োজনীয় বৈশিষ্ট্য
///
/// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// মালিকানাধীন প্রতিনিধিত্ব ফিরিয়ে এই ফাংশনের কলসাইটে একটি ব্যাকট্রেস ক্যাপচার করে।
    ///
    /// এই ফাংশনটি Rust এ অবজেক্ট হিসাবে ব্যাকট্রেস উপস্থাপনের জন্য দরকারী।এই প্রত্যাবর্তিত মানটি থ্রেডগুলি জুড়ে পাঠানো যেতে পারে এবং অন্য কোথাও মুদ্রিত হতে পারে এবং এই মানটির উদ্দেশ্য সম্পূর্ণরূপে স্বনির্ভর থাকা।
    ///
    /// মনে রাখবেন যে কয়েকটি প্ল্যাটফর্মে একটি সম্পূর্ণ ব্যাকট্রিজ অর্জন এবং এটি সমাধান করা অত্যন্ত ব্যয়বহুল।
    /// যদি আপনার অ্যাপ্লিকেশনটির জন্য ব্যয়টি খুব বেশি হয় তবে এটি পরিবর্তে `Backtrace::new_unresolved()` ব্যবহার করার পরামর্শ দেওয়া হয় যা প্রতীক রেজোলিউশন পদক্ষেপটি এড়িয়ে যায় (যা সাধারণত সবচেয়ে দীর্ঘ সময় নেয়) এবং পরবর্তী তারিখের জন্য পিছিয়ে দেওয়ার অনুমতি দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // মুছে ফেলার জন্য এখানে একটি ফ্রেম রয়েছে তা নিশ্চিত করতে চান
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` এর অনুরূপ এটি ছাড়াও এটি কোনও চিহ্নগুলিকে সমাধান করে না, এটি কেবল ঠিকানাগুলির তালিকা হিসাবে ব্যাকট্রেসকে ক্যাপচার করে।
    ///
    /// পরবর্তী সময়ে `resolve` ফাংশনটি এই ব্যাকট্রেসের প্রতীকগুলি পাঠযোগ্য নামগুলিতে সমাধান করার জন্য ডেকে আনা যেতে পারে।
    /// এই ফাংশনটি বিদ্যমান কারণ রেজোলিউশন প্রক্রিয়াটি মাঝে মাঝে একটি উল্লেখযোগ্য পরিমাণে সময় নিতে পারে তবে যে কোনও একটি ব্যাকট্রেস কেবল খুব কমই মুদ্রিত হতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // কোন চিহ্নের নাম
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // প্রতীক নাম এখন উপস্থিত
    /// ```
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    ///
    #[inline(never)] // মুছে ফেলার জন্য এখানে একটি ফ্রেম রয়েছে তা নিশ্চিত করতে চান
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// এই ব্যাকট্রিজটি ক্যাপচার করা থেকে ফ্রেমগুলি ফেরত দেয়।
    ///
    /// এই স্লাইজের প্রথম এন্ট্রিটি সম্ভবত `Backtrace::new` ফাংশন এবং শেষ ফ্রেমটি সম্ভবত এই থ্রেড বা মূল ফাংশনটি কীভাবে শুরু হয়েছিল সে সম্পর্কে কিছু একটা।
    ///
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// যদি এই ব্যাকট্রিজটি `new_unresolved` থেকে তৈরি করা হয় তবে এই ফাংশনটি ব্যাকট্রেসের সমস্ত ঠিকানা তাদের প্রতীকী নামগুলিতে সমাধান করবে।
    ///
    ///
    /// যদি এই ব্যাকট্রিজটি আগে সমাধান করা হয়েছিল বা `new` এর মাধ্যমে তৈরি করা হয়েছিল, তবে এই ফাংশনটি কিছুই করে না।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// এই ফ্রেমটির সাথে সম্পর্কিত প্রতীকগুলির তালিকা ফিরে আসে।
    ///
    /// সাধারণত ফ্রেম প্রতি শুধুমাত্র একটি প্রতীক থাকে, তবে কখনও কখনও যদি অনেকগুলি ফাংশন একটি ফ্রেমে linedোকানো থাকে তবে একাধিক চিহ্ন প্রত্যাবর্তিত হবে।
    /// তালিকাভুক্ত প্রথম প্রতীকটি "innermost function", যেখানে সর্বশেষ প্রতীকটি বহিরাগত (শেষ কলার)।
    ///
    /// মনে রাখবেন যে যদি এই ফ্রেমটি অমীমাংসিত ব্যাকট্র্যাস থেকে আসে তবে এটি একটি খালি তালিকা ফিরে আসবে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// এক্স 100 এক্স হিসাবে একই
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // পাথগুলি মুদ্রণের সময় আমরা সিডাব্লুডির উপস্থিতি উপস্থিত থাকলে তা স্ট্রিপ করার চেষ্টা করি, অন্যথায় আমরা কেবল সেই পথটি প্রিন্ট করি।
        // মনে রাখবেন যে আমরা এটি কেবল সংক্ষিপ্ত বিন্যাসের জন্যই করি, কারণ এটি পূর্ণ হলে আমরা সম্ভবত সমস্ত কিছু মুদ্রণ করতে চাই।
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}