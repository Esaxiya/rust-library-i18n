//! Windows এ dbghelp বাইন্ডিং পরিচালনা করতে সহায়তা করার জন্য একটি মডিউল
//!
//! এক্স 100 এক্সের ব্যাকট্রেসগুলি (কমপক্ষে এমএসভিসির জন্য) `dbghelp.dll` এবং এতে থাকা বিভিন্ন ফাংশনগুলির মাধ্যমে মূলত চালিত হয়।
//! এই ফাংশনগুলি বর্তমানে `dbghelp.dll` এর সাথে স্থিতিশীলভাবে লিঙ্ক করার পরিবর্তে *গতিশীল* লোড করা হয়েছে।
//! এটি বর্তমানে স্ট্যান্ডার্ড লাইব্রেরি দ্বারা সম্পন্ন হয়েছে (এবং তাত্ত্বিকভাবে সেখানে প্রয়োজনীয় প্রয়োজন), তবে ব্যাকট্রেসগুলি সাধারণত বেশ optionচ্ছিক হওয়ায় একটি লাইব্রেরির স্থির dll নির্ভরতা হ্রাস করতে সহায়তা করার একটি প্রচেষ্টা এটি।
//!
//! বলা হচ্ছে, `dbghelp.dll` প্রায় সর্বদা সাফল্যের সাথে Windows এ লোড হয়।
//!
//! তবে লক্ষ করুন যেহেতু আমরা এই সমস্ত সমর্থনটি গতিশীলভাবে লোড করছি আমরা আসলে `winapi` এ কাঁচা সংজ্ঞাটি ব্যবহার করতে পারি না, বরং আমাদের নিজের ফাংশন পয়েন্টার প্রকারগুলি সংজ্ঞায়িত করতে হবে এবং এটি ব্যবহার করতে হবে।
//! আমরা সত্যই উইনাপিকে নকল করার ব্যবসায়ের সাথে থাকতে চাই না, সুতরাং আমাদের কাছে একটি জেড 0 কার্গো0 জেড বৈশিষ্ট্য `verify-winapi` রয়েছে যা দাবি করে যে সমস্ত বাইন্ডিংগুলি উইনাপির সাথে মেলে এবং এই বৈশিষ্ট্যটি সিআই-তে সক্ষম করা হয়েছে।
//!
//! শেষ অবধি, আপনি এখানে লক্ষ করবেন যে `dbghelp.dll` এর জন্য dll কখনই লোড হয় না এবং এটি বর্তমানে ইচ্ছাকৃত।
//! চিন্তাভাবনাটি হ'ল আমরা বিশ্বব্যাপী এটিকে ক্যাশে করতে পারি এবং ব্যয়বহুল loads/unloads এড়িয়ে এপিআই-এর কলগুলির মধ্যে এটি ব্যবহার করতে পারি।
//! এটি যদি ফাঁস সনাক্তকারীগুলির জন্য সমস্যা বা এর মতো কিছু হয় তবে আমরা যখন সেখানে পৌঁছব তখন সেতুটি পেরিয়ে যেতে পারি।
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// এক্সপিএক্স এবং এক্স0 এক্স এর চারপাশে উইনপিতে উপস্থিত না হয়ে কাজ করুন।
// অন্যথায় এটি তখনই ব্যবহৃত হয় যখন আমরা উইনাপির বিপরীতে ডাবল-চেক করব।
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // উইনাপিতে এখনও সংজ্ঞায়িত হয়নি
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // এটি উইনাপিতে সংজ্ঞায়িত করা হয়েছে তবে এটি ভুল (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // উইনাপিতে এখনও সংজ্ঞায়িত হয়নি
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// এই ম্যাক্রোটি একটি `Dbghelp` কাঠামো সংজ্ঞায়িত করতে ব্যবহৃত হয় যা অভ্যন্তরীণভাবে সমস্ত ফাংশন পয়েন্টার রয়েছে যা আমরা লোড করতে পারি।
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// এক্স00 এক্স এর জন্য লোডড ডিএলএল
            dll: HMODULE,

            // আমরা ব্যবহার করতে পারি প্রতিটি ফাংশন জন্য প্রতিটি ফাংশন পয়েন্টার
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // প্রাথমিকভাবে আমরা ডিএলএল লোড করি নি
            dll: 0 as *mut _,
            // প্রাথমিকভাবে সমস্ত ক্রিয়াকলাপ শূন্যতে সেট করা আছে তা বলার জন্য তাদের ডায়নামিকভাবে লোড করা দরকার।
            //
            $($name: 0,)*
        };

        // প্রতিটি ফাংশনের ধরণের জন্য সুবিধার্থে টাইপডেফ।
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` খোলার চেষ্টা।
            /// `LoadLibraryW` ব্যর্থ হলে এটি কাজ করলে সাফল্য বা ত্রুটি ফিরে আসে।
            ///
            /// Panics যদি লাইব্রেরি ইতিমধ্যে লোড হয়।
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // আমরা ব্যবহার করতে চাই প্রতিটি পদ্ধতির জন্য ফাংশন।
            // যখন এটি বলা হয় তা হয় ক্যাশেড ফাংশন পয়েন্টারটি পড়বে বা এটিকে লোড করবে এবং লোড হওয়া মানটি ফিরিয়ে দেবে।
            // সাফল্য বোঝা ভার।
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp ফাংশনগুলি উল্লেখ করতে ক্লিনআপ লকগুলি ব্যবহার করার সুবিধার্থে প্রক্সি।
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// এই crate থেকে `dbghelp` এপিআই ফাংশন অ্যাক্সেসের জন্য প্রয়োজনীয় সমস্ত সহায়তা শুরু করুন।
///
///
/// মনে রাখবেন যে এই ফাংশনটি **নিরাপদ**, অভ্যন্তরীণভাবে এর নিজস্ব সিঙ্ক্রোনাইজেশন রয়েছে।
/// এছাড়াও মনে রাখবেন যে এই ফাংশনটি পুনরাবৃত্তভাবে একাধিকবার কল করা নিরাপদ।
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // আমাদের প্রথমে যা করতে হবে তা হ'ল এই ফাংশনটি সিঙ্ক্রোনাইজ করা।এটিকে অন্য থ্রেড থেকে একযোগে বা এক থ্রেডের মধ্যে পুনরাবৃত্তভাবে বলা যেতে পারে।
        // মনে রাখবেন যে এটি এর চেয়েও জটিল, কারণ আমরা এখানে যা ব্যবহার করছি, এক্স 100 এক্স,*এছাড়াও* এই প্রক্রিয়াতে অন্য সমস্ত কলারদের সাথে সিঙ্ক্রোনাইজ করা দরকার।
        //
        // সাধারণত একই প্রক্রিয়াটির মধ্যে `dbghelp` এ অনেক কল আসে না এবং আমরা সম্ভবত নিরাপদে ধরে নিতে পারি যে আমরা কেবল এটির অ্যাক্সেস করছি।
        // তবে, প্রাথমিক প্রাথমিক ব্যবহারকারীর একজনকে আমাদের উদ্বেগ করতে হবে যা উদ্বেগজনকভাবে আমরা নিজেরাই, কিন্তু স্ট্যান্ডার্ড লাইব্রেরিতে।
        // Rust স্ট্যান্ডার্ড লাইব্রেরি ব্যাকট্রেস সহায়তার জন্য এই crate এর উপর নির্ভর করে এবং এই crate এছাড়াও crates.io এ বিদ্যমান।
        // এর অর্থ হ'ল যদি স্ট্যান্ডার্ড লাইব্রেরি একটি panic ব্যাকট্রেস মুদ্রণ করে থাকে তবে এটি এই crate crates.io থেকে আগত হয়ে দৌড়াদৌড়ি করতে পারে, যার ফলে সেগফাল্ট হয়।
        //
        // এই সিঙ্ক্রোনাইজেশন সমস্যা সমাধানে সহায়তা করতে আমরা এখানে একটি উইন্ডোজ-নির্দিষ্ট ট্রিক নিয়োগ করি (এটি সর্বোপরি সিঙ্ক্রোনাইজেশন সম্পর্কিত একটি উইন্ডোজ-নির্দিষ্ট বিধিনিষেধ)।
        // আমরা এই কলটি সুরক্ষিত করতে একটি সেশন-লোকাল * নামে একটি মুটেক্স তৈরি করি।
        // এখানে উদ্দেশ্যটি হ'ল স্ট্যান্ডার্ড লাইব্রেরি এবং এই জেড 0 ক্রেট 0 জেডকে এখানে সিঙ্ক্রোনাইজ করার জন্য জেড 0 রিস্ট0 জেড-লেভেল এপিআইগুলি ভাগ করতে হবে না তবে তারা একে অপরের সাথে সিঙ্ক্রোনাইজ করছে তা নিশ্চিত করার জন্য পর্দার পিছনে কাজ করতে পারে can
        //
        // যখন এই ফাংশনটি স্ট্যান্ডার্ড লাইব্রেরি বা crates.io এর মাধ্যমে কল করা হয় তখন আমরা নিশ্চিত হতে পারি যে একই মিটেক্সটি অর্জিত হয়েছে।
        //
        // সুতরাং এর সব বলতে হবে যে আমরা এখানে প্রথম কাজটি করি তা হল আমরা পরমাণুগতভাবে একটি `HANDLE` তৈরি করি যা Windows এ একটি নামক মুটেক্স।
        // আমরা অন্যান্য থ্রেডগুলি বিশেষত এই ফাংশনটি ভাগ করে নেওয়ার সাথে কিছুটা সিঙ্ক্রোনাইজ করেছি এবং নিশ্চিত করে নিই যে এই ফাংশনের উদাহরণ অনুযায়ী কেবলমাত্র একটি হ্যান্ডেল তৈরি হয়েছে।
        // মনে রাখবেন যে হ্যান্ডেলটি বিশ্বব্যাপী একবারে সংরক্ষণ করা হয় না closed
        //
        // আমরা আসলে লকটি সরিয়ে ফেলার পরে আমরা কেবল এটি অর্জন করি এবং আমাদের `Init` হ্যান্ডেলটি হস্তান্তরিত করে শেষ পর্যন্ত এটিকে নামানোর জন্য দায়বদ্ধ হবে।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ঠিক আছে, ভাই!এখন যেহেতু আমরা সবাই নিরাপদে সিঙ্ক্রোনাইজ করেছি, আসুন আমরা আসলে সমস্ত কিছু প্রক্রিয়াজাতকরণ শুরু করি।
        // প্রথমে আমাদের নিশ্চিত করতে হবে যে `dbghelp.dll` আসলে এই প্রক্রিয়াতে লোড হয়েছে।
        // স্থিতিশীল নির্ভরতা এড়াতে আমরা গতিশীলভাবে এটি করি।
        // এটি historতিহাসিকভাবে অদ্ভুত সংযোগ সম্পর্কিত সমস্যাগুলির জন্য কাজ করা হয়েছে এবং বাইনারিগুলিকে কিছুটা আরও বহনযোগ্য করে তোলা হয়েছে কারণ এটি মূলত একটি ডিবাগিং ইউটিলিটি।
        //
        //
        // আমরা একবার `dbghelp.dll` ওপেন করার পরে আমাদের এতে কিছু সূচনা ফাংশন কল করতে হবে এবং এটি নীচে আরও বিশদভাবে জানানো হয়েছে।
        // যদিও আমরা এটি কেবল একবারই করি, তাই আমরা একটি বৈশ্বিক বুলিয়ান পেয়েছি যা ইঙ্গিত করে যে আমরা এখনও শেষ করেছি কি না।
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` পতাকাটি সেট করা আছে কিনা তা নিশ্চিত করুন, কারণ এমএসভিসির নিজস্ব ডক্স অনুযায়ী: "This is the fastest, most efficient way to use the symbol handler.", সুতরাং আসুন এটি করা যাক!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // আসলে এমএসভিসির সাহায্যে প্রতীকগুলি সূচনা করুন।নোট করুন যে এটি ব্যর্থ হতে পারে, তবে আমরা এটিকে এড়িয়ে চলেছি।
        // এই প্রতি সেটির জন্য এক টন পূর্বের শিল্প নেই, তবে এলএলভিএম অভ্যন্তরীণভাবে এখানে রিটার্নের মানটিকে অগ্রাহ্য করবে বলে মনে হচ্ছে এবং এলএলভিএমের স্যানিটাইজার লাইব্রেরিগুলির মধ্যে একটি ভীতিজনক সতর্কতা প্রিন্ট করে যদি এটি ব্যর্থ হয় তবে মূলত এটি দীর্ঘকালীন উপেক্ষা করে।
        //
        //
        // এই ক্ষেত্রে Rust এর ক্ষেত্রে এটি অনেকটাই সামনে আসে এটি হ'ল স্ট্যান্ডার্ড লাইব্রেরি এবং crates.io-এ এই জেড 0 ক্রেট 0 জেড উভয়ই `SymInitializeW` এর জন্য প্রতিযোগিতা করতে চায়।
        // Libraryতিহাসিকভাবে স্ট্যান্ডার্ড লাইব্রেরি বেশিরভাগ সময় ক্লিনআপ শুরু করতে চেয়েছিল, তবে এখন যেহেতু এটি এই crate ব্যবহার করছে এর অর্থ হ'ল যে কেউ প্রথমে আরম্ভ হবে এবং অন্যটি সেই সূচনাটি গ্রহণ করবে।
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}