use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr একটি কলব্যাক নেয় যা প্রতিটি ডিএসওর জন্য dl_phdr_info পয়েন্টার গ্রহণ করবে যা প্রক্রিয়াটির সাথে যুক্ত হয়েছে।
    // dl_iterate_phdr এছাড়াও গতিশীল লিঙ্কার পুনরাবৃত্তি শেষে শেষ থেকে লক করা আছে তা নিশ্চিত করে।
    // যদি কলব্যাক একটি শূন্য-না মান দেয় তবে পুনরাবৃত্তিটি তাড়াতাড়ি বন্ধ হয়ে যায়।
    // 'data' প্রতিটি কলে কলব্যাকের তৃতীয় যুক্তি হিসাবে পাস করা হবে।
    // 'size' dl_phdr_info এর আকার দেয়।
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// আমাদের বিল্ড আইডি এবং কিছু বেসিক প্রোগ্রামের শিরোনামের ডেটা পার্স করা দরকার যার অর্থ ELF স্পেক থেকে আমাদের কিছুটা জিনিসও প্রয়োজন।
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// এখন আমাদের flsia এর বর্তমান গতিশীল লিঙ্কার দ্বারা ব্যবহৃত dl_phdr_info ধরণের কাঠামোর বিট বিট প্রতিলিপি করতে হবে।
// ক্রোমিয়ামের এই এবিআই সীমানার পাশাপাশি ক্র্যাশপ্যাডও রয়েছে।
// অবশেষে আমরা এই কেসগুলি এলফ-অনুসন্ধান ব্যবহার করতে সরিয়ে নিতে চাই তবে আমাদের এসডিকে এটি সরবরাহ করা দরকার এবং এটি এখনও হয়নি।
//
// সুতরাং আমরা (এবং তারা) এই পদ্ধতিটি ব্যবহার করতে আটকে রয়েছি যা ফুচিয়া লিবিসির সাথে একটি সংকীর্ণ সংযোগ দেয়।
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff এবং e_phnum বৈধ কিনা তা পরীক্ষা করার আমাদের কোন উপায় নেই।
    // libc আমাদের জন্য এটি নিশ্চিত করা উচিত তাই এটি এখানে একটি টুকরা গঠন নিরাপদ।
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr লক্ষ্য আর্কিটেকচারের শেষের দিকে একটি 64-বিট ELF প্রোগ্রামের শিরোনামকে উপস্থাপন করে।
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// পিএইচডিআর একটি বৈধ ইএলএফ প্রোগ্রামের শিরোনাম এবং এর সামগ্রীগুলি উপস্থাপন করে।
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // আমাদের কাছে p_addr বা p_memsz বৈধ কিনা তা পরীক্ষা করার কোনও উপায় নেই।
    // ফুচিয়ার লিবিসি নোটগুলি প্রথমে পার্স করে তবে এখানে থাকার কারণে এই শিরোনামগুলি অবশ্যই বৈধ হতে পারে।
    //
    // নোটআইটারের অন্তর্নিহিত ডেটা বৈধ হওয়ার প্রয়োজন হয় না তবে এটির সীমাটি বৈধ হওয়ার প্রয়োজন হয় না।
    // আমরা বিশ্বাস করি যে libc নিশ্চিত করেছে যে এখানে আমাদের ক্ষেত্রে এটিই।
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// বিল্ড আইডিগুলির জন্য নোটের ধরণ।
const NT_GNU_BUILD_ID: u32 = 3;

// এলফ_এনএইচডিআর লক্ষ্যটির শেষের দিকে একটি ELF নোট শিরোনামের প্রতিনিধিত্ব করে।
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// নোট একটি ELF নোট প্রতিনিধিত্ব করে (শিরোনাম + বিষয়বস্তু)।
// নামটি একটি u8 স্লাইস হিসাবে রেখে দেওয়া হয়েছে কারণ এটি সর্বদা বাতিল হয় না এবং rust এটি এত সহজেই সহজ করে তোলে যা বাইটগুলি যে কোনওভাবে মিলে।
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// নোটআইটার আপনাকে নোট বিভাগে নিরাপদে পুনরাবৃত্তি করতে দেয়।
// কোনও ত্রুটি হওয়ার সাথে সাথে এটি বন্ধ হয়ে যায় বা আরও কোনও নোট নেই।
// আপনি যদি অবৈধ ডেটা নিয়ে পুনরাবৃত্তি করেন তবে এটি কোনও নোটের সন্ধান না পেয়ে যেমন কাজ করবে।
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // এটি ফাংশনটির একটি আক্রমণকারী যা প্রদত্ত পয়েন্টার এবং আকারের দ্বারা বাইটগুলির একটি বৈধ পরিসীমা বোঝানো হয় যা সমস্ত পড়তে পারে।
    // এই বাইটগুলির বিষয়বস্তু যে কোনও কিছু হতে পারে তবে এটি নিরাপদ থাকার জন্য পরিসরটি বৈধ হতে হবে।
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' কে 'থেকে' বাইট প্রান্তিককরণ ধরে ধরে 'to' 2 এর শক্তি বলে ধরেছে।
// এটি সি/সি ++ ইএলএফ পার্সিং কোডের একটি মানক প্যাটার্ন অনুসরণ করে যেখানে (x + থেকে, 1) এবং -to ব্যবহৃত হয়।
// Rust আপনাকে ব্যবহার করতে অস্বীকার করতে দেয় না যাতে আমি ব্যবহার করি
// এটি পুনরায় তৈরি করতে 2 এর পরিপূরক রূপান্তর।
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 স্লাইস (উপস্থিত থাকলে) থেকে সংখ্যা বাইট গ্রহণ করে এবং অতিরিক্তভাবে নিশ্চিত করে যে চূড়ান্ত স্লাইস যথাযথভাবে প্রান্তিক করা আছে।
// যদি কোনও একটির জন্য অনুরোধ করা বাইটের সংখ্যা খুব বেশি হয় বা পর্যাপ্ত অবশিষ্ট বাইট না থাকার কারণে পরে স্লাইসটি সত্যায়িত করা যায় না, কোনওটিই ফিরে আসে না এবং স্লাইসটি সংশোধিত হয় না।
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// এই ফাংশনটির কোনও আসল আক্রমণকারী নেই কলারের পক্ষে পারফরম্যান্সের জন্য প্রান্তিককরণ করা উচিত (এবং কিছু আর্কিটেকচারের নির্ভুলতার জন্য) অন্যটি অবশ্যই ধরে রাখতে হবে।
// Elf_Nhdr ক্ষেত্রের মানগুলি বোকামি হতে পারে তবে এই ফাংশনটি এমন কোনও বিষয় নিশ্চিত করে না।
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // যতক্ষণ পর্যাপ্ত জায়গা থাকে এটি ততক্ষণ নিরাপদ এবং আমরা কেবল নিশ্চিত করেছি যে উপরের যদি বিবৃতিতে এটি অনিরাপদ না হয়।
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // নোট করুন যে sice_of: :<Elf_Nhdr>() সর্বদা 4-বাইট সারিবদ্ধ থাকে।
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // আমরা শেষ পর্যন্ত পৌঁছেছি কিনা তা পরীক্ষা করে দেখুন।
        if self.base.len() == 0 || self.error {
            return None;
        }
        // আমরা একটি এনএইচডিআর ট্রান্সমিট করি তবে আমরা ফলস্বরূপ কাঠামোটি যত্ন সহকারে বিবেচনা করি।
        // আমরা নেমস বা ডেস্কজকে বিশ্বাস করি না এবং প্রকারের ভিত্তিতে আমরা কোনও অনিরাপদ সিদ্ধান্ত গ্রহণ করি না।
        //
        // সুতরাং আমরা সম্পূর্ণ আবর্জনা বেরিয়ে গেলেও আমাদের এখনও নিরাপদ থাকা উচিত।
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ইঙ্গিত করে যে একটি বিভাগ কার্যকর হয়।
const PERM_X: u32 = 0b00000001;
/// ইঙ্গিত করে যে একটি বিভাগ লেখার যোগ্য।
const PERM_W: u32 = 0b00000010;
/// ইঙ্গিত করে যে কোনও বিভাগটি পাঠযোগ্য।
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// রানটাইমে একটি ইএলএফ বিভাগের প্রতিনিধিত্ব করে।
struct Segment {
    /// এই বিভাগের সামগ্রীগুলির রানটাইম ভার্চুয়াল ঠিকানা দেয়।
    addr: usize,
    /// এই বিভাগের বিষয়বস্তুর মেমরি আকার দেয়।
    size: usize,
    /// ELF ফাইলের সাথে এই বিভাগটির মডিউল ভার্চুয়াল ঠিকানা দেয়।
    mod_rel_addr: usize,
    /// ELF ফাইলে পাওয়া অনুমতি দেয়।
    /// এই অনুমতিগুলি অবশ্য রানটাইমে উপস্থিত অনুমতিগুলি অগত্যা নয়।
    flags: Perm,
}

/// ডিএসও থেকে সেগমেন্টগুলিতে এক পুনরাবৃত্তি করতে দেয়।
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// একটি ELF DSO (ডায়নামিক শেয়ার্ড অবজেক্ট) উপস্থাপন করে।
/// এই ধরণেরটি তার নিজস্ব অনুলিপি তৈরির চেয়ে প্রকৃত ডিএসওতে সঞ্চিত ডেটা উল্লেখ করে।
struct Dso<'a> {
    /// গতিশীল লিঙ্কার নামটি খালি থাকলেও সর্বদা আমাদের একটি নাম দেয়।
    /// মূল এক্সিকিউটেবলের ক্ষেত্রে এই নামটি খালি থাকবে।
    /// কোনও ভাগ করা বস্তুর ক্ষেত্রে এটি সোনাম হবে (দেখুন DT_SONAME)।
    name: &'a str,
    /// ফুচিয়াতে কার্যত সমস্ত বাইনারিগুলির আইডি রয়েছে তবে এটি কোনও কঠোর প্রয়োজনীয়তা নয়।
    /// পরে কোনও বিল্ড_আইড না থাকলে ডিএসও তথ্যের সাথে আসল ইএলএফ ফাইলের সাথে মিলে যাওয়ার কোনও উপায় নেই তাই আমাদের প্রয়োজন প্রতিটি ডিএসও এখানে থাকা উচিত।
    ///
    /// বিল্ডআইড ছাড়াই ডিএসও এড়ানো হবে।
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// এই ডিএসওতে বিভাগগুলির উপর একটি পুনরাবৃত্তিকে ফেরত দেয়।
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// এই ত্রুটিগুলি প্রতিটি ডিএসও সম্পর্কিত তথ্য বিশ্লেষণের সময় উত্থাপিত সমস্যাগুলি এনকোড করে।
///
enum Error {
    /// নেমআরারের অর্থ হ'ল সি স্টাইলের স্ট্রিংটিকে rust স্ট্রিংয়ে রূপান্তর করার সময় একটি ত্রুটি ঘটেছে।
    ///
    NameError(core::str::Utf8Error),
    /// বিল্ডআইডার এর অর্থ আমরা একটি বিল্ড আইডি পাইনি।
    /// এটি হয় কারণ ডিএসওর কোনও বিল্ড আইডি না থাকায় বা বিল্ড আইডি সহ সেগমেন্টটি ত্রুটিযুক্ত ছিল।
    ///
    BuildIDError,
}

/// গতিশীল লিঙ্কার দ্বারা প্রক্রিয়াটিতে সংযুক্ত প্রতিটি ডিএসওর জন্য এক্স00 এক্স বা এক্স01 এক্স হয়।
///
///
/// # Arguments
///
/// * `visitor` - একটি ডসোপ্রিন্টারে এমন একটি খাওয়ার পদ্ধতি থাকবে যা ফরচ ডিএসও বলে।
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr info.name একটি বৈধ অবস্থান নির্দেশ করবে তা নিশ্চিত করে।
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// এই ফাংশনটি ডিএসওতে থাকা সমস্ত তথ্যের জন্য ফুচিয়া প্রতীকী চিহ্নকে মুদ্রণ করে।
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}