//! প্রতীক কৌশলটি libbacktrace-এ DWARF-পার্সিং কোড ব্যবহার করে।
//!
//! সাধারণত gcc দিয়ে বিতরণ করা libbacktrace সি লাইব্রেরি কেবল ব্যাকট্রিজ তৈরি করে না (যা আমরা আসলে ব্যবহার করি না) বরং ব্যাকট্র্যাসকে প্রতীকী করে এবং ইনালিড ফ্রেম এবং হোয়াট নোটের মতো জিনিসগুলি সম্পর্কে বামন ডিবাগ তথ্য পরিচালনা করে।
//!
//!
//! এখানে বিভিন্ন উদ্বেগের কারণে এটি তুলনামূলকভাবে জটিল, তবে মূল ধারণাটি হ'ল:
//!
//! * প্রথমে আমরা `backtrace_syminfo` কল করি।এটি পারলে ডায়নামিক সিম্বল টেবিল থেকে প্রতীক তথ্য পাওয়া যায়।
//! * এরপরে আমরা `backtrace_pcinfo` কল করি।এটি ডিবাগইনফো সারণীগুলি উপলভ্য থাকলে পার্স করবে এবং আমাদের ইনলাইন ফ্রেম, ফাইলের নাম, লাইন নম্বর ইত্যাদি সম্পর্কিত তথ্য পুনরুদ্ধার করতে দিবে will
//!
//! বামন টেবিলগুলি লাইবব্র্যাক্ট্রেসে নিয়ে আসার বিষয়ে প্রচুর কৌশল রয়েছে তবে আশা করি এটি পৃথিবীর শেষ নয় এবং নীচে পড়ার সময় যথেষ্ট পরিষ্কার।
//!
//! এটি নন-এমএসভিসি এবং নন-ওএসএক্স প্ল্যাটফর্মগুলির জন্য ডিফল্ট প্রতীক কৌশল।যদিও এটি ওএসএক্সের জন্য ডিফল্ট কৌশল li
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // যদি সম্ভব হয় তবে `function` নামটি পছন্দ করুন যা ডিবাগিনফো থেকে আসে এবং সাধারণত ইনলাইন ফ্রেমের জন্য আরও সঠিক হতে পারে উদাহরণস্বরূপ।
                // এটি যদি উপস্থিত না থাকে তবে `symname` এ উল্লিখিত প্রতীক টেবিলের নামটিতে ফিরে যান।
                //
                // মনে রাখবেন যে কখনও কখনও `function` কিছুটা কম নির্ভুল অনুভব করতে পারে, উদাহরণস্বরূপ `std::panicking::try::do_call` এর `try<i32,closure>` বিস্তৃত তালিকাভুক্ত।
                //
                // এটি কেন প্রকৃতপক্ষে পরিষ্কার নয় তবে সামগ্রিকভাবে `function` নামটি আরও নির্ভুল বলে মনে হয়।
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // আপাতত কিছুই করো না
}

/// `data` পয়েন্টারের প্রকারটি `syminfo_cb` এ গেছে
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // এই কলব্যাকটি `backtrace_syminfo` থেকে শুরু হয়ে গেলে আমরা যখন সমাধান করা শুরু করি আমরা এক্স 100 এক্সকে কল করতে আরও এগিয়ে যাই।
    // `backtrace_pcinfo` ফাংশনটি ডিবাগ তথ্য এবং file/line তথ্য পুনরুদ্ধারের পাশাপাশি ইনলাইনড ফ্রেমগুলির মতো কাজগুলি করার চেষ্টা করবে।
    // নোট করুন যদিও ডিবাগ তথ্য না থাকলে `backtrace_pcinfo` ব্যর্থ হতে পারে বা অনেক কিছু করতে পারে না, সুতরাং যদি তা ঘটে থাকে তবে আমরা অবশ্যই `syminfo_cb` থেকে কমপক্ষে একটি প্রতীক নিয়ে কলব্যাক কল করব।
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` পয়েন্টারের প্রকারটি `pcinfo_cb` এ গেছে
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API একটি রাষ্ট্র তৈরি করতে সমর্থন করে তবে এটি কোনও রাষ্ট্রকে ধ্বংস করতে সমর্থন করে না।
// আমি ব্যক্তিগতভাবে এটি বোঝাতে চাইছি যে একটি রাষ্ট্র তৈরি করা এবং তারপরে চিরকাল বেঁচে থাকার অর্থ।
//
// আমি একটি এক্স00 এক্স হ্যান্ডলার নিবন্ধন করতে চাই যা এই রাজ্যটি পরিষ্কার করে দেয়, তবে লিবব্যাক্ট্রেস এটি করার কোনও উপায় সরবরাহ করে না।
//
// এই প্রতিবন্ধকতাগুলির সাথে, এই ফাংশনটির একটি স্থিতিযুক্ত ক্যাশেড স্টেট রয়েছে যা প্রথমবারের জন্য অনুরোধ করা হলে তা গণনা করা হয়।
//
// মনে রাখবেন যে ব্যাকট্র্যাকিং সমস্ত ক্রমিকভাবে ঘটে (এক গ্লোবাল লক)।
//
// নোট করুন যে এখানে সিঙ্ক্রোনাইজেশনের অভাবটি `resolve` বাহ্যিকভাবে সিঙ্ক্রোনাইজ করা প্রয়োজনের কারণে।
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // লিবব্যাকট্রেসের থ্রেডসফ ক্ষমতাগুলি ব্যবহার করবেন না যেহেতু আমরা সর্বদা এটি একটি সিঙ্ক্রোনাইজড ফ্যাশনে কল করি।
        //
        0,
        error_cb,
        ptr::null_mut(), // কোনও অতিরিক্ত ডেটা নেই
    );

    return STATE;

    // নোট করুন যে libbacktrace এ কাজ করার জন্য এটি বর্তমান এক্সিকিউটেবলের জন্য DWARF ডিবাগ তথ্য সন্ধান করা প্রয়োজন।এটি সাধারণত এমন কয়েকটি প্রক্রিয়া সহ করে যা অন্তর্ভুক্ত করে তবে সীমাবদ্ধ নয়:
    //
    // * /proc/self/exe সমর্থিত প্ল্যাটফর্মগুলিতে
    // * অবস্থা তৈরির সময় ফাইলের নামটি স্পষ্টভাবে পাস করেছিল
    //
    // Libbacktrace গ্রন্থাগারটি সি কোডের একটি বড় ওয়াড।এর স্বাভাবিক অর্থ এটি মেমরির সুরক্ষা দুর্বলতা পেয়েছে, বিশেষত যখন ত্রুটিযুক্ত ডিবাগিনফো পরিচালনা করে।
    // Stতিহাসিকভাবে লিবিস্টডি প্রচুর পরিমাণে চলে গেছে।
    //
    // যদি /proc/self/exe ব্যবহার করা হয় তবে আমরা সাধারণত এগুলি উপেক্ষা করতে পারি কারণ আমরা ধরে নিই যে libbacktrace "mostly correct" এবং অন্যথায় "attempted to be correct" বামন ডিবাগ তথ্যের সাথে অদ্ভুত জিনিস না করে।
    //
    //
    // তবে আমরা যদি কোনও ফাইলনামে পাস করি তবে এটি এমন কিছু প্ল্যাটফর্মে (বিএসডি এর মতো) সম্ভব যেখানে কোনও দূষিত অভিনেতা সেই স্থানে একটি স্বেচ্ছাসেবক ফাইল স্থাপন করতে পারে।
    // এর অর্থ হ'ল আমরা যদি কোনও ফাইল নাম সম্পর্কে লাইবব্র্যাক্ট্রেসকে বলি তবে এটি একটি স্বেচ্ছাসেবী ফাইল ব্যবহার করতে পারে, সম্ভবত সেগফাল্টগুলি ঘটায়।
    // যদি আমরা যদিও লাইবব্র্যাকট্রেস কিছু না বলি তবে এটি প্ল্যাটফর্মগুলিতে এমন কিছু করবে না যা /proc/self/exe এর মতো পথগুলিকে সমর্থন করে না!
    //
    // কোনও ফাইলনেম * পাস না করার জন্য যথাসাধ্য চেষ্টা করার পরেও আমাদের অবশ্যই এমন প্ল্যাটফর্মগুলিতে আবশ্যক যা /proc/self/exe মোটেও সমর্থন করে না।
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // মনে রাখবেন যে আদর্শভাবে আমরা `std::env::current_exe` ব্যবহার করব তবে আমাদের এখানে `std` লাগবে না।
            //
            // স্থিতিশীল অঞ্চলে বর্তমান এক্সিকিউটেবল পাথ লোড করতে `_NSGetExecutablePath` ব্যবহার করুন (এটি যদি খুব ছোট হয় তবে হাল ছেড়ে দেয়)।
            //
            //
            // নোট করুন যে আমরা দুর্ভাগ্যজনক এক্সিকিউটেবলের উপর মারা না যাওয়ার জন্য লাইবব্র্যাক্ট্রেসের উপর গুরুত্ব সহকারে বিশ্বাস করছি, তবে তা অবশ্যই ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ফাইলগুলি খোলার একটি মোড রয়েছে যেখানে এটি খোলার পরে এটি মোছা যায় না।
            // এটি আমরা এখানে যা চাই তা সাধারণ কারণ আমরা এটি নিশ্চিত করতে চাই যে আমাদের নির্বাহযোগ্যটি আমাদের অধীনে থেকে লাইবব্যাকট্র্যাসের হাতে তুলে দেবার পরে, আশাবাদী যথেচ্ছ ডেটাগুলিকে লাইবব্যাকট্রেসে (যা ভুল পথে চালিত হতে পারে) এর মধ্যে সরিয়ে দেওয়ার ক্ষমতা হ্রাস করবে।
            //
            //
            // আমাদের নিজস্ব ইমেজে এক ধরণের লক পাওয়ার চেষ্টা করার জন্য আমরা এখানে কিছুটা নাচ করি:
            //
            // * বর্তমান প্রক্রিয়াটিতে একটি হ্যান্ডেল পান, এর ফাইল নামটি লোড করুন।
            // * ডান পতাকা সহ সেই ফাইল নামটিতে একটি ফাইল খুলুন।
            // * বর্তমান প্রক্রিয়াটির ফাইল নাম পুনরায় লোড করুন, এটি একইরূপ তা নিশ্চিত করে
            //
            // যদি তাত্ত্বিকভাবে সমস্ত পাস হয় তবে আমরা প্রকৃতপক্ষে আমাদের প্রক্রিয়াটির ফাইলটি খুলেছি এবং আমরা গ্যারান্টিযুক্ত এটি পরিবর্তন হবে না।FWIW এর একটি গুচ্ছটি bতিহাসিকভাবে libstd থেকে অনুলিপি করা হয়েছে, তাই যা হচ্ছিল তার এটি আমার সেরা ব্যাখ্যা।
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // এটি স্থির স্মৃতিতে বাস করে যাতে আমরা এটি ফিরিয়ে দিতে পারি ..
                static mut BUF: [i8; N] = [0; N];
                // ... এবং এটি স্ট্যাকের উপর থেকে এটি অস্থায়ী থেকে জীবনযাপন করে
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ইচ্ছাকৃতভাবে এখানে `handle` ফাঁস করুন কারণ এই খোলা থাকলে এই ফাইলটির নামের উপর আমাদের লক সংরক্ষণ করা উচিত।
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // আমরা এমন একটি স্লাইস ফিরিয়ে দিতে চাই যা নুল-টার্মিনেটেড, তাই যদি সমস্ত কিছু পূরণ করা হয় এবং এটি মোট দৈর্ঘ্যের সমান হয় তবে ব্যর্থতার সাথে এটি সমান হয়।
                //
                //
                // অন্যথায় সাফল্য ফিরিয়ে দেওয়ার সময় নুল বাইট স্লাইসে অন্তর্ভুক্ত রয়েছে তা নিশ্চিত করুন।
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ব্যাকট্রেস ত্রুটিগুলি বর্তমানে রাগের নীচে ছড়িয়ে পড়েছে
    let state = init_state();
    if state.is_null() {
        return;
    }

    // এক্স কোডএক্স এপিআই কল করুন (কোডটি পড়ার সময় থেকে) একবারে `syminfo_cb` কল করা উচিত (অথবা সম্ভবত কোনও ত্রুটির সাথে ব্যর্থ হবে)।
    // এরপরে আমরা `syminfo_cb` এর মধ্যে আরও পরিচালনা করি।
    //
    // নোট করুন যে আমরা `syminfo` প্রতীক টেবিলের সাথে পরামর্শ করব, বাইনারিটিতে কোনও ডিবাগের তথ্য না থাকলেও প্রতীক নামগুলি সন্ধান করবে we
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}