// কেবলমাত্র এখনই Linux এ ব্যবহৃত হয়েছে, তাই অন্য কোথাও ডেড কোডের অনুমতি দিন
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// বাইট বাফারগুলির জন্য একটি সাধারণ ক্ষেত্র বরাদ্দকারী।
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// নির্দিষ্ট আকারের একটি বাফার বরাদ্দ করে এবং এতে পরিবর্তনীয় রেফারেন্স দেয়।
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // নিরাপত্তা: এটিই কেবলমাত্র একটি ফাংশন যা কখনও পরিবর্তনীয় করে তোলে
        // `self.buffers` রেফারেন্স।
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // নিরাপদ: আমরা কখনই `self.buffers` থেকে উপাদানগুলি সরিয়ে নেই, তাই একটি রেফারেন্স
        // যে কোনও বাফারের অভ্যন্তরে থাকা ডেটাতে `self` যতক্ষণ না বেঁচে থাকবে।
        &mut buffers[i]
    }
}