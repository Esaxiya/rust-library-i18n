use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::elf::{ELFCOMPRESS_ZLIB, SHF_COMPRESSED};
use object::read::elf::{CompressionHeader, FileHeader, SectionHeader, SectionTable, Sym};
use object::read::StringTable;
use object::{BigEndian, Bytes, NativeEndian};

#[cfg(target_pointer_width = "32")]
type Elf = object::elf::FileHeader32<NativeEndian>;
#[cfg(target_pointer_width = "64")]
type Elf = object::elf::FileHeader64<NativeEndian>;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

struct ParsedSym {
    address: u64,
    size: u64,
    name: u32,
}

pub struct Object<'a> {
    /// স্থানীয় শূন্যতার প্রতিনিধিত্ব করে শূন্য-আকারের প্রকার।
    ///
    /// পরিবর্তে আমরা আক্ষরিক ব্যবহার করতে পারি, তবে এটি নির্ভুলতা নিশ্চিত করতে সহায়তা করে।
    endian: NativeEndian,
    /// পুরো ফাইল ডেটা।
    data: Bytes<'a>,
    sections: SectionTable<'a, Elf>,
    strings: StringTable<'a>,
    /// বেস ঠিকানায় প্রাক-পার্সড এবং সাজানো প্রতীকগুলির তালিকা।
    syms: Vec<ParsedSym>,
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = object::Bytes(data);
        let elf = Elf::parse(data).ok()?;
        let endian = elf.endian().ok()?;
        let sections = elf.sections(endian, data).ok()?;
        let mut syms = sections
            .symbols(endian, data, object::elf::SHT_SYMTAB)
            .ok()?;
        if syms.is_empty() {
            syms = sections
                .symbols(endian, data, object::elf::SHT_DYNSYM)
                .ok()?;
        }
        let strings = syms.strings();

        let mut syms = syms
            .iter()
            // কেবলমাত্র function/object চিহ্নগুলি দেখুন।
            // এটি মিরর করে যা libbacktrace করে এবং সাধারণভাবে আমরা কেবল তত্ত্বের মধ্যে ফাংশন ঠিকানাগুলি প্রতীকী করছি।
            // অবজেক্ট সিম্বলগুলি ডেটার সাথে মিলে যায় এবং কারও পক্ষে কোনও ফাংশন থাকতে যথেষ্ট পাগল স্ট্যাটিক ডেটাতে যেতে পারে?
            //
            //
            .filter(|sym| {
                let st_type = sym.st_type();
                st_type == object::elf::STT_FUNC || st_type == object::elf::STT_OBJECT
            })
            // অপরিজ্ঞাত বিভাগের শিরোনামে থাকা কোনও কিছু এড়িয়ে যান, কারণ এর অর্থ এটি একটি আমদানি করা ফাংশন এবং আমরা কেবল স্থানীয়ভাবে সংজ্ঞায়িত ফাংশনগুলির সাথে প্রতীকী ating
            //
            //
            .filter(|sym| sym.st_shndx(endian) != object::elf::SHN_UNDEF)
            .map(|sym| {
                let address = sym.st_value(endian).into();
                let size = sym.st_size(endian).into();
                let name = sym.st_name(endian);
                ParsedSym {
                    address,
                    size,
                    name,
                }
            })
            .collect::<Vec<_>>();
        syms.sort_unstable_by_key(|s| s.address);
        Some(Object {
            endian,
            data,
            sections,
            strings,
            syms,
        })
    }

    pub fn section(&self, stash: &'a Stash, name: &str) -> Option<&'a [u8]> {
        if let Some(section) = self.section_header(name) {
            let mut data = section.data(self.endian, self.data).ok()?;

            // ডিআরএফ-স্ট্যান্ডার্ড এক্স 100 এক্স সংক্ষেপণের জন্য পরীক্ষা করুন, যেমন এলডির এক্স01 এক্স পতাকা দ্বারা উত্পাদিত।
            //
            let flags: u64 = section.sh_flags(self.endian).into();
            if (flags & u64::from(SHF_COMPRESSED)) == 0 {
                // সংকুচিত নয়।
                return Some(data.0);
            }

            let header = data.read::<<Elf as FileHeader>::CompressionHeader>().ok()?;
            if header.ch_type(self.endian) != ELFCOMPRESS_ZLIB {
                // Zlib সংকোচনের একমাত্র পরিচিত প্রকার।
                return None;
            }
            let size = usize::try_from(header.ch_size(self.endian)).ok()?;
            let buf = stash.allocate(size);
            decompress_zlib(data.0, buf)?;
            return Some(buf);
        }

        // নন স্ট্যান্ডার্ড GNU সংক্ষেপণ বিন্যাসের জন্য পরীক্ষা করুন, যেমন এলডির এক্স00 এক্স পতাকা দ্বারা উত্পন্ন।
        // এর অর্থ হ'ল আমরা যদি আসলে `.debug_info` এর জন্য জিজ্ঞাসা করি তবে আমাদের `.zdebug_info` নামের একটি অংশটি সন্ধান করা উচিত।
        //
        //
        if !name.starts_with(".debug_") {
            return None;
        }
        let debug_name = name[7..].as_bytes();
        let compressed_section = self
            .sections
            .iter()
            .filter_map(|header| {
                let name = self.sections.section_name(self.endian, header).ok()?;
                if name.starts_with(b".zdebug_") && &name[8..] == debug_name {
                    Some(header)
                } else {
                    None
                }
            })
            .next()?;
        let mut data = compressed_section.data(self.endian, self.data).ok()?;
        if data.read_bytes(8).ok()?.0 != b"ZLIB\0\0\0\0" {
            return None;
        }
        let size = usize::try_from(data.read::<object::U32Bytes<_>>().ok()?.get(BigEndian)).ok()?;
        let buf = stash.allocate(size);
        decompress_zlib(data.0, buf)?;
        Some(buf)
    }

    fn section_header(&self, name: &str) -> Option<&<Elf as FileHeader>::SectionHeader> {
        self.sections
            .section_by_name(self.endian, name.as_bytes())
            .map(|(_index, section)| section)
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // উপরে Windows হিসাবে বাইনারি অনুসন্ধান একই ধরণের
        let i = match self.syms.binary_search_by_key(&addr, |sym| sym.address) {
            Ok(i) => i,
            Err(i) => i.checked_sub(1)?,
        };
        let sym = self.syms.get(i)?;
        if sym.address <= addr && addr <= sym.address + sym.size {
            self.strings.get(sym.name).ok()
        } else {
            None
        }
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}

fn decompress_zlib(input: &[u8], output: &mut [u8]) -> Option<()> {
    use miniz_oxide::inflate::core::inflate_flags::{
        TINFL_FLAG_PARSE_ZLIB_HEADER, TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF,
    };
    use miniz_oxide::inflate::core::{decompress, DecompressorOxide};
    use miniz_oxide::inflate::TINFLStatus;

    let (status, in_read, out_read) = decompress(
        &mut DecompressorOxide::new(),
        input,
        output,
        0,
        TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF | TINFL_FLAG_PARSE_ZLIB_HEADER,
    );
    if status == TINFLStatus::Done && in_read == input.len() && out_read == output.len() {
        Some(())
    } else {
        None
    }
}