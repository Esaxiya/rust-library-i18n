use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// প্রতীকটিকে নির্দিষ্ট ক্লোজারে পাস করে কোনও চিহ্নের কোনও ঠিকানা সমাধান করুন।
///
/// এই ফাংশনটি প্রদত্ত ঠিকানাগুলি যেমন স্থানীয় প্রতীক টেবিল, গতিশীল প্রতীক টেবিল, বা DWARF ডিবাগ তথ্য (সক্রিয়করণের উপর নির্ভর করে) ফলনের জন্য চিহ্নগুলি সন্ধান করবে।
///
///
/// সমাধানটি সম্পাদন করা না গেলে ক্লোজার বলা হবে না, এবং ইনলাইনড ফাংশনগুলির ক্ষেত্রে এটি একাধিকবার ডাকা যেতে পারে।
///
/// প্রাপ্ত প্রতীকগুলি নির্দিষ্ট `addr` এ কার্য সম্পাদনকে প্রতিনিধিত্ব করে, সেই ঠিকানার (যদি উপলভ্য থাকে) জন্য file/line জোড়া ফেরত দেয়।
///
/// মনে রাখবেন যে আপনার যদি `Frame` থাকে তবে এইটির পরিবর্তে `resolve_frame` ফাংশনটি ব্যবহার করার পরামর্শ দেওয়া হচ্ছে।
///
/// # প্রয়োজনীয় বৈশিষ্ট্য
///
/// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
///
/// # Panics
///
/// এই ফাংশনটি panic কখনই করতে চেষ্টা করে না, তবে `cb` যদি panics সরবরাহ করে তবে কিছু প্ল্যাটফর্মগুলি ডাবল জেডপ্যানিক0 জেডটিকে প্রক্রিয়াটি বাতিল করতে বাধ্য করবে।
/// কিছু প্ল্যাটফর্ম একটি সি লাইব্রেরি ব্যবহার করে যা অভ্যন্তরীণভাবে কলব্যাকগুলি ব্যবহার করে যা অযথা চালানো যায় না, তাই `cb` থেকে আতঙ্কিত হওয়া কোনও প্রক্রিয়া বাতিল করতে পারে।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // শুধুমাত্র উপরের ফ্রেমটি দেখুন
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// পূর্ববর্তী ক্যাপচার ফ্রেমটিকে একটি প্রতীক হিসাবে সমাধান করুন, প্রতীকটি নির্দিষ্ট বন্ধে পাস করুন।
///
/// এই ফান্টটিনটি `resolve` এর মতো একই কার্য সম্পাদন করে তা ছাড়া এটি কোনও ঠিকানার পরিবর্তে একটি `Frame` কে যুক্তি হিসাবে গ্রহণ করে।
/// এটি ব্যাকট্রাক্সিংয়ের কিছু প্ল্যাটফর্ম বাস্তবায়নের জন্য আরও সঠিক চিহ্নের তথ্য বা উদাহরণস্বরূপ ইনলাইন ফ্রেম সম্পর্কিত তথ্য সরবরাহ করতে পারে।
///
/// আপনি যদি পারেন তবে এটি ব্যবহার করার পরামর্শ দেওয়া হচ্ছে।
///
/// # প্রয়োজনীয় বৈশিষ্ট্য
///
/// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
///
/// # Panics
///
/// এই ফাংশনটি panic কখনই করতে চেষ্টা করে না, তবে `cb` যদি panics সরবরাহ করে তবে কিছু প্ল্যাটফর্মগুলি ডাবল জেডপ্যানিক0 জেডটিকে প্রক্রিয়াটি বাতিল করতে বাধ্য করবে।
/// কিছু প্ল্যাটফর্ম একটি সি লাইব্রেরি ব্যবহার করে যা অভ্যন্তরীণভাবে কলব্যাকগুলি ব্যবহার করে যা অযথা চালানো যায় না, তাই `cb` থেকে আতঙ্কিত হওয়া কোনও প্রক্রিয়া বাতিল করতে পারে।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // শুধুমাত্র উপরের ফ্রেমটি দেখুন
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// স্ট্যাক ফ্রেমগুলির আইপি মানগুলি হ'ল * কল করার পরে নির্দেশটি হ'ল প্রকৃত স্ট্যাক ট্রেস X
// এটির প্রতীকীকরণের ফলে filename/line সংখ্যাটি একের সামনে এবং সম্ভবত যদি এটি ফাংশনের সমাপ্তির কাছাকাছি হয় তবে শূন্যতার মধ্যে চলে যায়।
//
// এটি সমস্ত প্ল্যাটফর্মের ক্ষেত্রে মূলত সর্বদা ক্ষেত্রে দেখা যায়, তাই আমরা নির্দেশটি ফিরে না আসার পরিবর্তে পূর্ববর্তী কল নির্দেশে সমাধান করার জন্য সমাধানের আইপি থেকে সর্বদা একটি বিয়োগ করি।
//
//
// আদর্শভাবে আমরা এটি করব না।
// আদর্শভাবে আমাদের X0 `resolve` এপিএলের কলারদের ম্যানুয়ালি -1 করতে হবে এবং অ্যাকাউন্ট যে তারা পূর্ববর্তী * নির্দেশের জন্য অবস্থানের তথ্য চায়, বর্তমানের জন্য নয় would
// আদর্শভাবে আমরা `Frame`-তে প্রকাশ করতে চাই যদি আমরা প্রকৃতপক্ষে পরবর্তী নির্দেশের ঠিকানা বা বর্তমান হয়।
//
// আপাতত যদিও এটি একটি সুন্দর কুলুঙ্গি বিষয় তাই আমরা কেবল অভ্যন্তরীণভাবে সবসময় একটি বিয়োগ করি।
// ভোক্তাদের কাজ করা এবং বেশ ভাল ফলাফল পাওয়া উচিত, তাই আমাদের যথেষ্ট ভাল হওয়া উচিত।
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` হিসাবে একই, এটি অনির্দিষ্টকৃত হিসাবে কেবল অনিরাপদ।
///
/// এই ফাংশনটিতে সিঙ্ক্রোনাইজেশন গ্যারেন্টি নেই তবে যখন এই জেড 0 ক্রেট0 জেড এর `std` বৈশিষ্ট্যটি সংকলিত না হয় তখন উপলব্ধ।
/// আরও ডকুমেন্টেশন এবং উদাহরণগুলির জন্য `resolve` ফাংশনটি দেখুন।
///
/// # Panics
///
/// আতঙ্কিত হয়ে `cb` তে ক্যাভ্যাটগুলির জন্য `resolve` এর তথ্য দেখুন।
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` হিসাবে একই, এটি অনির্দিষ্টকৃত হিসাবে কেবল অনিরাপদ।
///
/// এই ফাংশনটিতে সিঙ্ক্রোনাইজেশন গ্যারেন্টি নেই তবে যখন এই জেড 0 ক্রেট0 জেড এর `std` বৈশিষ্ট্যটি সংকলিত না হয় তখন উপলব্ধ।
/// আরও ডকুমেন্টেশন এবং উদাহরণগুলির জন্য `resolve_frame` ফাংশনটি দেখুন।
///
/// # Panics
///
/// আতঙ্কিত হয়ে `cb` তে ক্যাভ্যাটগুলির জন্য `resolve_frame` এর তথ্য দেখুন।
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// একটি trait একটি ফাইলের মধ্যে একটি চিহ্নের রেজোলিউশন উপস্থাপন করে।
///
/// এই trait `backtrace::resolve` ফাংশনটি প্রদত্ত বন্ধের কাছে trait অবজেক্ট হিসাবে উত্পাদিত হয়েছে এবং এটি কার্যত প্রেরণ করা হয়েছে এটি অজানা হিসাবে এটি বাস্তবায়নের পিছনে রয়েছে।
///
///
/// একটি চিহ্ন একটি ফাংশন সম্পর্কে প্রাসঙ্গিক তথ্য দিতে পারে, উদাহরণস্বরূপ নাম, ফাইলের নাম, লাইন নম্বর, সুনির্দিষ্ট ঠিকানা ইত্যাদি can
/// সমস্ত তথ্য সর্বদা একটি প্রতীক হিসাবে উপলব্ধ হয় না, তবে, সমস্ত পদ্ধতি একটি `Option` ফেরত দেয়।
///
///
pub struct Symbol {
    // TODO: এই আজীবন আবদ্ধ হওয়া অবশেষে `Symbol` পর্যন্ত বজায় রাখা দরকার,
    // তবে বর্তমানে এটি একটি ব্রেকিং পরিবর্তন।
    // আপাতত এটি নিরাপদ যেহেতু `Symbol` কেবলমাত্র রেফারেন্সের মাধ্যমে হস্তান্তর করা হয়েছে এবং ক্লোন করা যায় না।
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// এই ফাংশনটির নাম ফিরিয়ে দেয়।
    ///
    /// প্রতীক নামটি সম্পর্কে বিভিন্ন বৈশিষ্ট্য জিজ্ঞাসা করতে ফিরে আসা কাঠামোটি ব্যবহার করা যেতে পারে:
    ///
    ///
    /// * `Display` বাস্তবায়ন বিভক্ত প্রতীকটি মুদ্রণ করবে।
    /// * প্রতীকটির কাঁচা `str` মানটি অ্যাক্সেস করা যেতে পারে (এটি বৈধ utf-8 হলে)।
    /// * প্রতীক নামের কাঁচা বাইটগুলি অ্যাক্সেস করা যায়।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// এই ফাংশনটির প্রারম্ভিক ঠিকানা প্রদান করে।
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// কাঁচা ফাইলের নামটি স্লাইস হিসাবে ফিরিয়ে দেয়।
    /// এটি `no_std` পরিবেশের জন্য মূলত কার্যকর।
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// বর্তমানে এই প্রতীকটি কার্যকর করছে তার জন্য কলাম নম্বরটি দেয়।
    ///
    /// কেবলমাত্র জিমলি এখানে এখানে একটি মান সরবরাহ করে এবং তারপরেও যদি `filename` `Some` ফেরত দেয় এবং তাই ফলস্বরূপ এটি অনুরূপ ক্যাভেটস সাপেক্ষে।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// বর্তমানে এই প্রতীকটি কার্যকর করছে এমন লাইন নম্বর প্রদান করে।
    ///
    /// এই রিটার্ন মানটি `Some` হয় যদি `filename` এক্স 100 এক্স প্রদান করে এবং ফলস্বরূপ অনুরূপ সতর্কীকরণের সাপেক্ষে।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// এই ফাংশনটি সংজ্ঞায়িত করা হয়েছিল এমন ফাইলের নাম ফেরত দেয়।
    ///
    /// এটি বর্তমানে কেবল তখনই উপলভ্য যখন লিবব্যাকট্র্যাস বা জিমলি ব্যবহার করা হয় (উদাঃ)
    /// unix অন্য প্ল্যাটফর্মগুলি) এবং যখন কোনও বাইনারি ডিবাগিনফোর সাথে সংকলিত হয়।
    /// যদি এই শর্তগুলির একটিও পূরণ না হয় তবে এটি সম্ভবত `None` এ ফিরে আসবে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // জ্যাডরস্ট0 জেড হিসাবে ম্যাংলেড প্রতীকটি পার্সিং করা ব্যর্থ হলে সম্ভবত একটি পার্সড সি ++ প্রতীক।
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // এই শূন্য আকারের রাখতে নিশ্চিত করুন, যাতে অক্ষম হওয়ার সময় `cpp_demangle` বৈশিষ্ট্যটির কোনও মূল্য না থাকে has
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ডিমেলযুক্ত নাম, কাঁচা বাইটস, কাঁচা স্ট্রিং ইত্যাদিতে অর্গনোমিক অ্যাক্সেসর সরবরাহ করতে প্রতীক নামের চারপাশে একটি মোড়ক
///
// `cpp_demangle` বৈশিষ্ট্যটি সক্ষম না হওয়ার জন্য ডেড কোডের অনুমতি দিন।
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// কাঁচা অন্তর্নিহিত বাইট থেকে একটি নতুন প্রতীক নাম তৈরি করে।
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// প্রতীকটি বৈধ utf-8 হলে কাঁচা (mangled) প্রতীক নামটিকে `str` হিসাবে ফিরিয়ে দেয়।
    ///
    /// আপনি যদি ডিমেংল্ড সংস্করণ চান তবে `Display` বাস্তবায়নটি ব্যবহার করুন।
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// বাইটের তালিকা হিসাবে কাঁচা প্রতীক নামটি দেয়
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // এটি মুদ্রণ করতে পারে যদি ডিমেংলড প্রতীকটি বাস্তবে বৈধ না হয়, সুতরাং ত্রুটিটিকে এখানে বাহ্যিকভাবে প্রচার না করে নিখুঁতভাবে পরিচালনা করুন।
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// অ্যাড্রেস প্রতীক হিসাবে ব্যবহৃত ক্যাশেড মেমরির দাবি করার চেষ্টা করুন।
///
/// এই পদ্ধতিটি এমন কোনও বিশ্বব্যাপী ডেটা স্ট্রাকচার প্রকাশ করার চেষ্টা করবে যা অন্যথায় বিশ্বব্যাপী বা থ্রেডে ক্যাশে করা হয়েছে যা সাধারণত পার্সড ডিয়ারএফ তথ্য বা অনুরূপ উপস্থাপন করে।
///
///
/// # Caveats
///
/// যদিও এই ফাংশনটি সর্বদা উপলব্ধ থাকে এটি বেশিরভাগ বাস্তবায়নে আসলে কিছুই করে না।
/// Dbghelp বা libbacktrace এর মতো গ্রন্থাগারগুলি স্থিতিস্থাপক রাষ্ট্র এবং বরাদ্দ মেমরি পরিচালনা করার জন্য কোনও সুবিধা সরবরাহ করে না।
/// আপাতত এই crate এর `gimli-symbolize` বৈশিষ্ট্যটি হ'ল একমাত্র বৈশিষ্ট্য যেখানে এই ফাংশনটির কোনও প্রভাব রয়েছে।
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}