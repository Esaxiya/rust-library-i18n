//! crates.io এ `gimli` crate ব্যবহার করে প্রতীক হিসাবে সমর্থন
//!
//! এটি Rust এর জন্য ডিফল্ট প্রতীকীকরণ বাস্তবায়ন।

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'স্থির জীবনকাল স্ব-রেফারেন্সিয়াল স্ট্রাইকগুলির পক্ষে সমর্থন না পাওয়ার আশ্রয় নেওয়া মিথ্যা।
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // স্ট্যাটিক লাইফটাইমগুলিতে রূপান্তর করুন যেহেতু প্রতীকগুলির কেবলমাত্র `map` এবং `stash` নেওয়া উচিত এবং আমরা সেগুলি নীচে সংরক্ষণ করছি।
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows এ নেটিভ লাইব্রেরি লোড করার জন্য, এখানে বিভিন্ন কৌশলের জন্য এক্স01 এক্স সম্পর্কে কিছু আলোচনা দেখুন।
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW গ্রন্থাগারগুলি বর্তমানে ASLR (rust-lang/rust#16514) সমর্থন করে না, তবে ডিএলএলগুলি এখনও ঠিকানার জায়গাতেই স্থানান্তরিত হতে পারে।
            // এটি প্রদর্শিত হয় যে ডিবাগ তথ্যের ঠিকানাগুলি সমস্ত যেমন-এই লাইব্রেরিটি এর "image base" এ লোড করা হয়েছিল, যা এটির সিওএফএফ ফাইল শিরোনামের ক্ষেত্র।
            // যেহেতু এটিই ডিবাগিনফো তালিকাবদ্ধ করে মনে হচ্ছে আমরা প্রতীক টেবিল এবং স্টোরের ঠিকানাগুলি পার্স করে দিচ্ছি যেন লাইব্রেরিটিও "image base" এ লোড হয়েছে।
            //
            // তবে গ্রন্থাগারটি "image base" এ লোড করা যাবে না।
            // (সম্ভবত সেখানে অন্য কোনও কিছু লোড হতে পারে?) এখানেই `bias` ক্ষেত্রটি খেলতে আসে এবং আমাদের এখানে `bias` এর মান খুঁজে বের করতে হবে।দুর্ভাগ্যক্রমে যদিও বোঝা যাচ্ছে যে এটি বোঝা মডিউল থেকে কীভাবে অর্জন করবেন।
            // আমাদের কাছে যা আছে তা হ'ল আসল লোড ঠিকানা (`modBaseAddr`)।
            //
            // আপাতত একটি কপ-আউট হিসাবে আমরা ফাইলটি এমএম্যাপ করি, ফাইলের শিরোনামের তথ্য পড়ি, তারপরে এমএমএপ ড্রপ করি।এটি অপব্যয় কারণ আমরা সম্ভবত এমএমএপটি পরে আবার খুলব, তবে এটি আপাতত ভালভাবে কাজ করা উচিত।
            //
            // একবার আমাদের কাছে `image_base` (কাঙ্ক্ষিত লোডের অবস্থান) এবং `base_addr` (প্রকৃত লোডের অবস্থান) আমরা `bias` (প্রকৃত এবং কাঙ্ক্ষিতের মধ্যে পার্থক্য) পূরণ করতে পারি এবং তারপরে প্রতিটি বিভাগের বর্ণিত ঠিকানাটি `image_base` হয় যেহেতু ফাইলটি বলে says
            //
            //
            // আপাতত এটি উপস্থিত হয় যে ELF/MachO এর বিপরীতে আমরা পুরো আকার হিসাবে `modBaseSize` ব্যবহার করে লাইব্রেরি প্রতি এক বিভাগে করতে পারি।
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ম্যাচ-ও ফাইল ফর্ম্যাট ব্যবহার করে এবং অ্যাপ্লিকেশনের অংশ যা দেশীয় পাঠাগারগুলির তালিকা লোড করতে ডিওয়াইএলডি-নির্দিষ্ট এপিআই ব্যবহার করে।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // এই লাইব্রেরির নামটি আনুন যা এটি লোড করার পথের সাথে সামঞ্জস্য করে।
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // এই লাইব্রেরির ইমেজ শিরোনাম লোড করুন এবং সমস্ত লোড কমান্ড বিশ্লেষণের জন্য `object` তে প্রতিনিধি করুন যাতে আমরা এখানে জড়িত সমস্ত বিভাগগুলি খুঁজে বের করতে পারি।
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // সেগমেন্টগুলির উপরে পরিলক্ষিত করুন এবং আমরা যে বিভাগগুলি খুঁজে পাই সেগুলির জন্য পরিচিত অঞ্চলগুলি নিবন্ধ করুন।
            // পরে প্রক্রিয়াজাতকরণের জন্য পাঠ্য বিভাগগুলিতে তথ্য রেকর্ড করুন, নীচের মন্তব্যগুলি দেখুন।
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // এই লাইব্রেরির জন্য "slide" নির্ধারণ করুন যা মেমরির বস্তুগুলি কোথায় লোড হয় তা নির্ধারণের জন্য আমরা ব্যবহার করি এমন পক্ষপাতিত্ব শেষ হয়।
            // এটি যদিও কিছুটা অদ্ভুত গণনা এবং এটি বন্যের মধ্যে কয়েকটি জিনিস চেষ্টা করার এবং কোনটি লাঠি দেখছে ফলাফল।
            //
            // সাধারণ ধারণাটি হ'ল এক্স00 এক্স প্লাস একটি সেগমেন্টের এক্স01 এক্স এমন জায়গায় চলেছে যেখানে আসল ঠিকানা স্পেসে সেগমেন্টটি থাকে।
            // যদিও আমরা নির্ভর করি অন্যটি হ'ল একটি আসল ঠিকানা বিয়োগ `bias` প্রতীক টেবিল এবং ডিবাগিনফোতে সন্ধান করার সূচক index
            //
            // দেখা যাচ্ছে যে সিস্টেম লোড লাইব্রেরির জন্য এই গণনাগুলি ভুল।নেটিভ এক্সিকিউটেবলের জন্য তবে এটি সঠিক দেখাচ্ছে।
            // এলএলডিবি'র উত্স থেকে কিছু যুক্তি তুলে ধরতে এতে ননজারো আকারের ফাইল অফসেট 0 থেকে লোড হওয়া প্রথম এক্স00 এক্স বিভাগের জন্য কিছু বিশেষ-আবরণ রয়েছে।
            // যে কোনও কারণেই এটি উপস্থিত থাকার পরে এটি বোঝায় যে প্রতীক টেবিলটি লাইব্রেরির জন্য কেবল vmaddr স্লাইডের সাথে সম্পর্কিত।
            // যদি এটি *উপস্থিত না* থাকে তবে প্রতীক টেবিলটি vmaddr স্লাইড প্লাস বিভাগের বর্ণিত ঠিকানার সাথে সম্পর্কিত।
            //
            // এই পরিস্থিতিটি পরিচালনা করতে যদি আমরা ফাইল অফসেট শূন্যে একটি পাঠ্য বিভাগ না পাই * তবে আমরা প্রথম পাঠ্য বিভাগের বর্ণিত ঠিকানার মাধ্যমে পক্ষপাত বাড়িয়ে দেব এবং সেই পরিমাণ দ্বারা সমস্ত বর্ণিত ঠিকানা হ্রাস করব।
            //
            // এইভাবে প্রতীক টেবিলটি লাইব্রেরির পক্ষপাতের পরিমাণের সাথে সর্বদা উপস্থিত থাকে।
            // প্রতীক টেবিলের মাধ্যমে প্রতীকীকরণের জন্য এটির সঠিক ফলাফল রয়েছে বলে মনে হয়।
            //
            // সত্যিই আমি পুরোপুরি নিশ্চিত নই যে এটি সঠিক কিনা বা অন্য কোনও কিছু আছে যা এটি কীভাবে করতে হয় তা নির্দেশ করতে হবে।
            // আপাতত যদিও এটি যথেষ্ট পরিমাণে (?) কার্যকরভাবে কাজ করছে বলে মনে হচ্ছে এবং প্রয়োজনে আমাদের প্রয়োজন সময় বরাবরই এটি টুইট করতে সক্ষম।
            //
            // আরও কিছু তথ্যের জন্য দেখুন #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // অন্যান্য এক্স 100 এক্স (উদাঃ)
        // লিনাক্স) প্ল্যাটফর্মগুলি একটি বস্তুর ফাইল ফর্ম্যাট হিসাবে ELF ব্যবহার করে এবং সাধারণত নেটিভ লাইব্রেরি লোড করতে `dl_iterate_phdr` নামক একটি API প্রয়োগ করে।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` একটি বৈধ পয়েন্টার হওয়া উচিত।
        // `vec` একটি `std::Vec` এর একটি বৈধ পয়েন্টার হওয়া উচিত।
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 স্থানীয়ভাবে ডিবাগ তথ্য সমর্থন করে না, তবে বিল্ড সিস্টেমটি ডিবাগ তথ্যটি `romfs:/debug_info.elf` পাথে রাখবে।
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // অন্য সমস্ত কিছুতে ইএলএফ ব্যবহার করা উচিত, তবে নেটিভ লাইব্রেরিগুলি কীভাবে লোড করতে হয় তা জানে না।
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// লোড করা হয়েছে এমন সমস্ত জ্ঞাত শেয়ার্ড লাইব্রেরি।
    libraries: Vec<Library>,

    /// ম্যাপিংস ক্যাশে যেখানে আমরা পার্সড বামন সম্পর্কিত তথ্য ধরে রাখি।
    ///
    /// এই তালিকাটির পুরো আজীবনের জন্য একটি স্থির ক্ষমতা রয়েছে যা কখনই বৃদ্ধি পায় না।
    /// প্রতিটি জুটির `usize` উপাদানটি `libraries` এর উপরে একটি সূচক যেখানে `usize::max_value()` বর্তমান নির্বাহযোগ্যকে উপস্থাপন করে।
    ///
    /// এক্স 100 এক্স পার্সড বামন সম্পর্কিত তথ্য সম্পর্কিত।
    ///
    /// মনে রাখবেন যে এটি মূলত একটি এলআরইউ ক্যাশে এবং আমরা ঠিকানাগুলির প্রতীক হিসাবে এখানে জিনিসগুলিকে প্রায় স্থানান্তর করব।
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// এই লাইব্রেরির অংশগুলি মেমরিতে লোড হয়েছে এবং সেগুলি লোড করা হয়েছে।
    segments: Vec<LibrarySegment>,
    /// এই লাইব্রেরির "bias", সাধারণত যেখানে এটি মেমরিতে লোড হয়।
    /// এই মানটি প্রতিটি বিভাগের বর্ণিত ঠিকানায় যুক্ত করা হয়েছে যাতে খণ্ডটি লোড হয়েছে এমন আসল ভার্চুয়াল মেমরি ঠিকানা।
    /// অতিরিক্তভাবে এই পক্ষপাতটি বাস্তব ভার্চুয়াল মেমরি ঠিকানাগুলি থেকে সূচককে ডিবাগিনফোর এবং প্রতীক সারণিতে বিয়োগ করা হয়।
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// অবজেক্ট ফাইলে এই বিভাগটির বর্ণিত ঠিকানা।
    /// এটি যেখানে খণ্ডটি লোড করা হয় তা নয়, বরং এই ঠিকানাটি সহ গ্রন্থাগারের `bias` রয়েছে যেখানে এটি সন্ধান করতে হবে।
    ///
    stated_virtual_memory_address: usize,
    /// স্মৃতিতে ths বিভাগের আকার।
    len: usize,
}

// অনিরাপদ কারণ এটি বাহ্যিকভাবে সিঙ্ক্রোনাইজ করা প্রয়োজন
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // অনিরাপদ কারণ এটি বাহ্যিকভাবে সিঙ্ক্রোনাইজ করা প্রয়োজন
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ডিবাগ তথ্য ম্যাপিংয়ের জন্য খুব ছোট, খুব সাধারণ এলআরইউ ক্যাশে।
        //
        // হিট রেটটি খুব বেশি হওয়া উচিত, যেহেতু সাধারণ স্ট্যাকটি অনেকগুলি ভাগ করা লাইব্রেরির মধ্যে অতিক্রম করে না।
        //
        // এক্স 100 এক্স স্ট্রাকচারগুলি তৈরি করা বেশ ব্যয়বহুল।
        // এর ব্যয়টি পরবর্তী `locate` ক্যোরিয়াস দ্বারা সূক্ষ্মভাবে প্রত্যাশিত হবে, যা ভাল স্পিডআপগুলি পেতে `addr2line: : Context`s নির্মাণের সময় নির্মিত কাঠামোগুলি লাভ করে।
        //
        // যদি আমাদের কাছে এই ক্যাশেটি না থাকে, তবে amশ্বরিকরণটি কখনই ঘটবে না, এবং ব্যাকট্র্যাসের প্রতীকীকরণ ssssllllooooowwww হবে।
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // প্রথমত, পরীক্ষা করুন যে এই `lib`-এ `addr` (হ্যান্ডলিং রিলোকেশন) সমন্বিত কোনও বিভাগ রয়েছে কিনা testযদি এই চেকটি পাস হয়ে যায় তবে আমরা নীচে চালিয়ে যেতে পারি এবং ঠিকানাটি অনুবাদ করতে পারি।
                //
                // নোট করুন যে ওভারফ্লো চেকগুলি এড়াতে আমরা এখানে `wrapping_add` ব্যবহার করছি।এটি বন্যের মধ্যে দেখা গেছে যে SVMA + পক্ষপাত গণনা উপচে পড়ে।
                // এটি কিছুটা অদ্ভুত বলে মনে হচ্ছে যা ঘটবে তবে এগুলি সম্পর্কে আমরা আরও কিছু করতে পারি না কেবল সম্ভবত সেগুলিগুলিকে উপেক্ষা করার কারণে তারা সম্ভবত মহাশূন্যের দিকে ইঙ্গিত করছে।
                //
                // এটি মূলত rust-lang/backtrace-rs#329 এ উঠে এসেছিল।
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // এখন যেহেতু আমরা জানি যে `lib` এ `addr` রয়েছে, তাই আমরা উল্লিখিত ভাইরাল মেমরি ঠিকানাটি পক্ষপাত দিয়ে অফসেট করতে পারি।
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ছদ্মবেশী: শর্তসাপেক্ষে তাড়াতাড়ি প্রত্যাবর্তন ছাড়াই সম্পূর্ণ হয়
        // একটি ত্রুটি থেকে, এই পাথের জন্য ক্যাশে প্রবেশ সূচী 0 এ রয়েছে।

        if let Some(idx) = idx {
            // যখন ম্যাপিংটি ইতিমধ্যে ক্যাশে রয়েছে তখন এটিকে সামনে নিয়ে যান।
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // যখন ম্যাপিং ক্যাশে নেই, তখন একটি নতুন ম্যাপিং তৈরি করুন, এটি ক্যাশের সামনের অংশে sertোকান এবং প্রয়োজনে সবচেয়ে পুরানো ক্যাশে প্রবেশিকাটি সরিয়ে দিন।
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` জীবদ্দশায় ফাঁস করবেন না, এটি কেবল আমাদের কাছেই রয়েছে তা নিশ্চিত করুন
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // দুর্ভাগ্যক্রমে আমাদের এখানে প্রয়োজনীয় হওয়ার কারণে `sym` এর জীবনকালকে `'static` পর্যন্ত প্রসারিত করুন, তবে এটি কোনও ক্ষেত্রেই রেফারেন্স হিসাবে বাইরে চলেছে তাই যাইহোক এই ফ্রেমের বাইরে এর কোনও রেফারেন্স বজায় রাখা উচিত নয়।
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // অবশেষে, একটি ক্যাশেড ম্যাপিং পান বা এই ফাইলটির জন্য একটি নতুন ম্যাপিং তৈরি করুন এবং এই ঠিকানার জন্য file/line/name সন্ধানের জন্য DWARF তথ্যটি মূল্যায়ন করুন।
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// আমরা এই প্রতীকটির জন্য ফ্রেম তথ্য সনাক্ত করতে সক্ষম হয়েছি এবং `addr2line` এর ফ্রেমে অভ্যন্তরীণভাবে সমস্ত কৌতুকপূর্ণ বিবরণ রয়েছে।
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ডিবাগের তথ্য খুঁজে পাওয়া যায়নি, তবে আমরা এটি সম্পাদনযোগ্য এলফের প্রতীক টেবিলের মধ্যে পেয়েছি।
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}