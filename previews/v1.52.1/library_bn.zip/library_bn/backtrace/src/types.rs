//! প্ল্যাটফর্ম নির্ভর ধরণের।

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// একটি স্ট্রিমের একটি প্ল্যাটফর্মের স্বতন্ত্র উপস্থাপনা।
/// `std` সক্ষম থাকা সাথে কাজ করার সময় এটি `std` ধরণের রূপান্তর সরবরাহের সুবিধার পদ্ধতিগুলিতে সুপারিশ করা হয়।
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// একটি স্লাইস, সাধারণত Unix প্ল্যাটফর্মগুলিতে সরবরাহ করা হয়।
    Bytes(&'a [u8]),
    /// Windows থেকে সাধারণত প্রশস্ত স্ট্রিং।
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// লসী `Cow<str>` এ রূপান্তর করে, `Bytes` বৈধ UTF-8 না হলে বা `BytesOrWideString` `Wide` হলে বরাদ্দ হবে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` এর একটি `Path` উপস্থাপনা সরবরাহ করে।
    ///
    /// # প্রয়োজনীয় বৈশিষ্ট্য
    ///
    /// এই ফাংশনটির জন্য `backtrace` crate সক্রিয় করা `std` বৈশিষ্ট্য প্রয়োজন এবং এক্স02 এক্স বৈশিষ্ট্যটি ডিফল্টরূপে সক্ষম করা হয়েছে।
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}