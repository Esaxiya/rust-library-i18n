//! libunwind/gcc_s/etc এপিআই ব্যবহার করে ব্যাকট্র্যাস সমর্থন support
//!
//! এই মডিউলে লাইবউবাইন্ড স্টাইলের API গুলি ব্যবহার করে স্ট্যাকটি আনওয়াইন্ড করার ক্ষমতা রয়েছে।
//! নোট করুন যে লাইবুনবাইন্ড-এর মতো এপিআই এর বাস্তবায়ন পুরো গুচ্ছ আছে এবং এটি কেবল পিকে হওয়ার পরিবর্তে একবারে বেশিরভাগের সাথে সামঞ্জস্য হওয়ার চেষ্টা করছে।
//!
//!
//! লাইবুনউইন্ড এপিআই `_Unwind_Backtrace` দ্বারা চালিত এবং অনুশীলনে ব্যাকট্র্যাস উত্পন্ন করতে খুব নির্ভরযোগ্য।
//! এটি সম্পূর্ণরূপে পরিষ্কার নয় যে এটি কীভাবে হয় (ফ্রেম পয়েন্টার? এহ_ফ্রেম তথ্য? উভয়?) তবে এটি কার্যকর বলে মনে হচ্ছে!
//!
//! এই মডিউলটির বেশিরভাগ জটিলতা লাইবুনউইন্ড বাস্তবায়ন জুড়ে বিভিন্ন প্ল্যাটফর্মের পার্থক্যগুলি পরিচালনা করছে।
//! অন্যথায় এটি লাইবুনউইন্ড এপিআই-র কাছে খুব সোজা Rust আবদ্ধ।
//!
//! এটি বর্তমানে সমস্ত নন-উইন্ডোজ প্ল্যাটফর্মের জন্য ডিফল্ট আনওয়ানডিং এপিআই।
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// একটি কাঁচা লাইবুনউইন্ড পয়েন্টার সহ এটি কেবলমাত্র পঠনযোগ্য থ্রেডস্যাফ ফ্যাশনে অ্যাক্সেস হওয়া উচিত, সুতরাং এটি `Sync`।
// `Clone` এর মাধ্যমে অন্য থ্রেডগুলিতে প্রেরণ করার সময় আমরা সর্বদা এমন সংস্করণে স্যুইচ করি যা অভ্যন্তর পয়েন্টার ধরে রাখে না, তাই আমাদেরও `Send` হওয়া উচিত।
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // দেখে মনে হচ্ছে ওএসএক্স U _উইন্ডওয়াইন্ড_ফাইন্ডএক্লোজিং ফাংশন `এ একটি পয়েন্টার ফিরিয়ে দিয়েছে ... এমন কিছু যা অস্পষ্ট।
        // এটি অবশ্যই যে কোনও কারণে বদ্ধ ক্রিয়াকলাপ নয়।
        // এখানে কী চলছে তা আমার কাছে সম্পূর্ণ পরিষ্কার নয়, তাই আপাতত এটিকে হতাশ করুন এবং সর্বদা আইপিটি ফিরিয়ে দিন।
        //
        // নোট করুন `skip_inner_frames.rs` X পরীক্ষাটি এই ক্লজের কারণে ওএসএক্সে ছেড়ে দেওয়া হয়েছে এবং যদি এটি স্থির হয় তবে তত্ত্বের পরীক্ষাটি ওএসএক্সে চালানো যেতে পারে!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ব্যাকট্রেসগুলির জন্য ব্যবহৃত লাইব্রেরি ইন্টারফেসটি উন্মুক্ত করুন
///
/// নোট করুন যে মৃত কোডটি এখানে কেবলমাত্র বাইন্ডিংয়ের মতো অনুমোদিত রয়েছে আইওএস এগুলি সমস্ত ব্যবহার করে না তবে আরও প্ল্যাটফর্ম-নির্দিষ্ট কনফিগারেশন কোডকে খুব বেশি দূষিত করে
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // শুধুমাত্র এআরএম ইএবিআই দ্বারা ব্যবহৃত
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // আইওএস এ কোনও নেটিভ _উইন্ডওয়াইন্ড_ব্যাকট্রেস নেই
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 সাল থেকে উপলভ্য, আমাদের উদ্দেশ্যটির জন্য ঠিক থাকতে হবে
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // এই ফাংশনটি একটি মিসনোমার: এই ফ্রেমের ক্যানোনিকাল ফ্রেম ঠিকানা (ওরফে কলার ফ্রেমের এসপি) পাওয়ার চেয়ে এটি এই ফ্রেমের এসপি ফিরিয়ে দেয়।
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x একটি পক্ষপাতদুষ্ট সিএফএ মান ব্যবহার করে, তাই আমাদের _উন্ডওয়াইন্ড_গেটসিএফএর উপর নির্ভর করার পরিবর্তে স্ট্যাক পয়েন্টার রেজিস্টার এক্স00 এক্স পেতে আমাদের _উন্ডউইন্ড_গেটজিআর ব্যবহার করতে হবে।
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android এবং বাহুতে, এক্স01 এক্স এবং অন্যদের একগুচ্ছ ফাংশনটি ম্যাক্রোস, তাই আমরা ম্যাক্রোগুলির বিস্তৃতি যুক্ত ফাংশনগুলি সংজ্ঞায়িত করি।
    //
    //
    // TODO: আপনি যদি এটি খুঁজে পেতে পারেন তবে এই ম্যাক্রোগুলি সংজ্ঞায়িত করে এমন শিরোলেখ ফাইলটিতে লিঙ্ক করুন।
    // (আমি, ফিটজেন, এই ম্যাক্রোর সম্প্রসারণের কয়েকটি মূলত ধার নিয়েছিল এমন শিরোনামের ফাইলটি খুঁজে পাই না))
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 বাহুতে স্ট্যাক পয়েন্টার।
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // এই ফাংশনটি Android বা ARM/Linux এও বিদ্যমান নেই, সুতরাং এটি একটি অন-আপ করুন।
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}