use backtrace::Backtrace;

// 50-অক্ষরের মডিউল নাম
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-অক্ষরের কাঠামোর নাম
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// দীর্ঘ ক্রিয়াকলাপের নামগুলি অবশ্যই (MAX_SYM_NAME, 1) টি অক্ষরে কাটা উচিত।
// gnu সমস্ত ফ্রেমের জন্য "<no info>" প্রিন্ট করে কেবল এমএসভিসি-র জন্য এই পরীক্ষাটি চালান।
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // কাঠামোর নামের 10 টি পুনরাবৃত্তি, সুতরাং সম্পূর্ণরূপে যোগ্য ফাংশনের নাম কমপক্ষে 10 *(50 + 50)* 2=2000 অক্ষর দীর্ঘ।
    //
    // এটি আসলে আরও দীর্ঘতর কারণ এটিতে `::`, `<>` এবং বর্তমান মডিউলটির নাম অন্তর্ভুক্ত রয়েছে
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}