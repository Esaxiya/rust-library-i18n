use backtrace::Backtrace;

// এই পরীক্ষাটি কেবল এমন প্ল্যাটফর্মগুলিতে কাজ করে যা ফ্রেমের জন্য একটি ওয়ার্কিং `symbol_address` ফাংশন রয়েছে যা প্রতীকের শুরুর ঠিকানাটির প্রতিবেদন করে।
// ফলস্বরূপ এটি কেবল কয়েকটি প্ল্যাটফর্মে সক্ষম রয়েছে।
//
const ENABLED: bool = cfg!(all(
    // Windows সত্যই পরীক্ষা করা হয়নি, এবং ওএসএক্স আসলে একটি ঘেরযুক্ত ফ্রেম সন্ধান করা সমর্থন করে না, তাই এটি অক্ষম করুন
    //
    target_os = "linux",
    // এআরএম-এ এনক্লোজিং ফাংশনটি সন্ধান করে কেবল আইপি নিজেই ফিরে আসবে।
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}