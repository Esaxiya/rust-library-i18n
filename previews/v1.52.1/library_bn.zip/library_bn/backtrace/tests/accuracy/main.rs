mod auxiliary;

macro_rules! pos {
    () => {
        (file!(), line!())
    };
}

macro_rules! check {
    ($($pos:expr),*) => ({
        verify(&[$($pos,)* pos!()]);
    })
}

type Pos = (&'static str, u32);

#[test]
fn doit() {
    if
    // ডিফল্টরূপে স্থিতিকভাবে লিঙ্কযুক্ত এবং ডায়নামিক লাইব্রেরি সমর্থন করে না এমন ম্যাসেল এড়িয়ে যান
    //
    !cfg!(target_env = "musl")
    // ডিবিএলএসের সমর্থন নেই এমন লিবব্যাকট্রেসে মিনিজিডাব্লু এড়িয়ে যান।
    && !(cfg!(windows) && cfg!(target_env = "gnu") && cfg!(feature = "libbacktrace"))
    // মিরি ছেড়ে যান, যেহেতু এটি গতিশীল লাইব্রেরি সমর্থন করে না।
    && !cfg!(miri)
    {
        // TODO(#238) এই ফাংশনটিতে এটি প্রথম হওয়া উচিত নয়, তবে বর্তমানে এটি ঘটে।
        //
        let mut dir = std::env::current_exe().unwrap();
        dir.pop();
        if cfg!(windows) {
            dir.push("dylib_dep.dll");
        } else if cfg!(target_os = "macos") {
            dir.push("libdylib_dep.dylib");
        } else {
            dir.push("libdylib_dep.so");
        }
        let lib = libloading::Library::new(&dir).unwrap();
        let api = unsafe { lib.get::<extern "C" fn(Pos, fn(Pos, Pos))>(b"foo").unwrap() };
        api(pos!(), |a, b| {
            check!(a, b);
        });
    }

    outer(pos!());
}

#[inline(never)]
fn outer(main_pos: Pos) {
    inner(main_pos, pos!());
    inner_inlined(main_pos, pos!());
}

#[inline(never)]
#[rustfmt::skip]
fn inner(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);
    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
}

#[inline(always)]
#[rustfmt::skip]
fn inner_inlined(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);

    #[inline(always)]
    fn inner_further_inlined(main_pos: Pos, outer_pos: Pos, inner_pos: Pos) {
        check!(main_pos, outer_pos, inner_pos);
    }
    inner_further_inlined(main_pos, outer_pos, pos!());

    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });

    // এটি অন্তর্ভুক্ত ফাংশনটিতে দুটি স্বতন্ত্র কলগুলির মধ্যে একটি পার্থক্য পরীক্ষা করে।
    // (আন) ভাগ্যক্রমে, এলএলভিএম কোনওভাবে পরপর দুটি ধরণের কলকে একটি নোডে মার্জ করে।
    inner_further_inlined(main_pos, outer_pos, pos!());
}

fn verify(filelines: &[Pos]) {
    let trace = backtrace::Backtrace::new();
    println!("-----------------------------------");
    println!("looking for:");
    for (file, line) in filelines.iter().rev() {
        println!("\t{}:{}", file, line);
    }
    println!("found:\n{:?}", trace);
    let mut symbols = trace.frames().iter().flat_map(|frame| frame.symbols());
    let mut iter = filelines.iter().rev();
    while let Some((file, line)) = iter.next() {
        loop {
            let sym = match symbols.next() {
                Some(sym) => sym,
                None => panic!("failed to find {}:{}", file, line),
            };
            if let Some(filename) = sym.filename() {
                if let Some(lineno) = sym.lineno() {
                    if filename.ends_with(file) && lineno == *line {
                        break;
                    }
                }
            }
        }
    }
}