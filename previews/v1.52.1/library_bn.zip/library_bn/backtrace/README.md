# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust এর জন্য রানটাইম ব্যাকট্রেসগুলি অর্জন করার জন্য একটি লাইব্রেরি।
এই লাইব্রেরির সাথে কাজ করার জন্য একটি প্রোগ্রাম্যাটিক ইন্টারফেস সরবরাহ করে স্ট্যান্ডার্ড লাইব্রেরিটির সমর্থন বাড়ানোর লক্ষ্য রয়েছে, তবে এটি কেবল সহজেই লাইবস্টের জেড 0 স্প্যানিকস0 জেডের মতো বর্তমান ব্যাকট্রেস মুদ্রণ করতে সহায়তা করে।

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

কেবল কোনও ব্যাকট্রিজ ক্যাপচার করতে এবং পরবর্তী সময় পর্যন্ত এটির সাথে লেনদেন স্থগিত করার জন্য, আপনি শীর্ষ স্তরের `Backtrace` প্রকারটি ব্যবহার করতে পারেন।

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

তবে, যদি আপনি প্রকৃত ট্রেসিং কার্যকারিতাটিতে আরও কাঁচা অ্যাক্সেস চান তবে আপনি সরাসরি `trace` এবং `resolve` ফাংশন ব্যবহার করতে পারেন।

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // প্রতীক নামের এই নির্দেশিকাটির পয়েন্টারটি সমাধান করুন
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // পরের ফ্রেমে যেতে থাকুন
    });
}
```

# License

এই প্রকল্পের যে কোনও একটিতে লাইসেন্স করা হয়

 * Apache লাইসেন্স, সংস্করণ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) বা http://www.apache.org/licenses/LICENSE-2.0)
 * এমআইটি লাইসেন্স ([LICENSE-MIT](LICENSE-MIT) বা http://opensource.org/licenses/MIT)

আপনার বিকল্পে

### Contribution

আপনি অন্যথায় স্পষ্টভাবে বিবরণ না দিলে Apache-2.0 লাইসেন্সে সংজ্ঞায়িত হিসাবে আপনার দ্বারা ব্যাকট্রেস-আরএসে অন্তর্ভুক্তির জন্য ইচ্ছাকৃতভাবে জমা দেওয়া কোনও অবদান, কোনও অতিরিক্ত শর্ত বা শর্ত ছাড়াই উপরোক্ত হিসাবে দ্বৈত লাইসেন্সপ্রাপ্ত হবে।







