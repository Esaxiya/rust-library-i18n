//! একটি `proc_macro` ক্লায়েন্ট (একটি প্রো ম্যাক্রো জেড0crate0Z) এবং একটি এক্স0 এক্স এক্স সার্ভারের (একটি সংকলক ফ্রন্ট-এন্ড) মধ্যে যোগাযোগের জন্য অভ্যন্তরীণ ইন্টারফেস।
//!
//! সিরিয়ালাইজেশন (সি এবিআই বাফার সহ) এবং অনন্য পূর্ণসংখ্যার হ্যান্ডলগুলি নিযুক্ত `proc_macro` এর দুটি অনুলিপি (একই উত্স থেকে) এর মধ্যে সম্ভাব্যভাবে জড়িত Rust ABIs (যেমন, বুটস্ট্র্যাপের সময় stage0/bin/rustc বনাম stage1/bin/rustc) এর দুটি কপির মধ্যে নিরাপদে হস্তক্ষেপের অনুমতি দেওয়া হয়েছে।
//!
//!
//!
//!

#![deny(unsafe_code)]

use crate::{Delimiter, Level, LineColumn, Spacing};
use std::fmt;
use std::hash::Hash;
use std::marker;
use std::mem;
use std::ops::Bound;
use std::panic;
use std::sync::atomic::AtomicUsize;
use std::sync::Once;
use std::thread;

/// সার্ভার আরপিসি এপিআই বর্ণনা করে উচ্চ-অর্ডার ম্যাক্রো, ক্লায়েন্ট-সাইড এবং সার্ভার-সাইড উভয় প্রকারের নিরাপদ Rust এপিআইয়ের স্বয়ংক্রিয় প্রজন্মকে মঞ্জুরি দেয়।
///
/// `with_api!(MySelf, my_self, my_macro)` এতে প্রসারিত:
///
/// ```rust,ignore (pseudo-code)
/// my_macro! {
///     // ...
///     Literal {
///         // ...
///         fn character(ch: char) -> MySelf::Literal;
///         // ...
///         fn span(my_self: &MySelf::Literal) -> MySelf::Span;
///         fn set_span(my_self: &mut MySelf::Literal, span: MySelf::Span);
///     },
///     // ...
/// }
/// ```
///
/// প্রথম দুটি আর্গুমেন্ট বিভিন্ন বিভিন্ন ব্যবহারের কেস সক্ষম করতে আর্গুমেন্টের নাম এবং argument/return প্রকারগুলি কাস্টমাইজ করতে দেয়:
///
/// যদি `my_self` কেবলমাত্র `self` হয়, তবে প্রতিটি এক্স02 এক্স স্বাক্ষর কোনও পদ্ধতির জন্য যেমন ব্যবহার করতে পারেন।
/// যদি এটি অন্য কিছু হয় (অনুশীলনে `self_`), তবে স্বাক্ষরগুলির একটি বিশেষ `self` যুক্তি নেই এবং তাই, আলাদা আলাদা পরিচয় করানো যেতে পারে।
///
///
/// যদি `MySelf` কেবলমাত্র `Self` হয় তবে প্রকারগুলি কেবলমাত্র trait বা trait ইমপ্লির অভ্যন্তরে বৈধ, যেখানে trait প্রতিটি API ধরণের জন্য সম্পর্কিত প্রকারের রয়েছে।
/// যদি অ-সম্পর্কিত প্রকারগুলি পছন্দসই হয় তবে `Self` এর পরিবর্তে একটি মডিউল নাম (অনুশীলনে `self`) ব্যবহার করা যেতে পারে।
///
///
///
///
macro_rules! with_api {
    ($S:ident, $self:ident, $m:ident) => {
        $m! {
            FreeFunctions {
                fn drop($self: $S::FreeFunctions);
                fn track_env_var(var: &str, value: Option<&str>);
            },
            TokenStream {
                fn drop($self: $S::TokenStream);
                fn clone($self: &$S::TokenStream) -> $S::TokenStream;
                fn new() -> $S::TokenStream;
                fn is_empty($self: &$S::TokenStream) -> bool;
                fn from_str(src: &str) -> $S::TokenStream;
                fn to_string($self: &$S::TokenStream) -> String;
                fn from_token_tree(
                    tree: TokenTree<$S::Group, $S::Punct, $S::Ident, $S::Literal>,
                ) -> $S::TokenStream;
                fn into_iter($self: $S::TokenStream) -> $S::TokenStreamIter;
            },
            TokenStreamBuilder {
                fn drop($self: $S::TokenStreamBuilder);
                fn new() -> $S::TokenStreamBuilder;
                fn push($self: &mut $S::TokenStreamBuilder, stream: $S::TokenStream);
                fn build($self: $S::TokenStreamBuilder) -> $S::TokenStream;
            },
            TokenStreamIter {
                fn drop($self: $S::TokenStreamIter);
                fn clone($self: &$S::TokenStreamIter) -> $S::TokenStreamIter;
                fn next(
                    $self: &mut $S::TokenStreamIter,
                ) -> Option<TokenTree<$S::Group, $S::Punct, $S::Ident, $S::Literal>>;
            },
            Group {
                fn drop($self: $S::Group);
                fn clone($self: &$S::Group) -> $S::Group;
                fn new(delimiter: Delimiter, stream: $S::TokenStream) -> $S::Group;
                fn delimiter($self: &$S::Group) -> Delimiter;
                fn stream($self: &$S::Group) -> $S::TokenStream;
                fn span($self: &$S::Group) -> $S::Span;
                fn span_open($self: &$S::Group) -> $S::Span;
                fn span_close($self: &$S::Group) -> $S::Span;
                fn set_span($self: &mut $S::Group, span: $S::Span);
            },
            Punct {
                fn new(ch: char, spacing: Spacing) -> $S::Punct;
                fn as_char($self: $S::Punct) -> char;
                fn spacing($self: $S::Punct) -> Spacing;
                fn span($self: $S::Punct) -> $S::Span;
                fn with_span($self: $S::Punct, span: $S::Span) -> $S::Punct;
            },
            Ident {
                fn new(string: &str, span: $S::Span, is_raw: bool) -> $S::Ident;
                fn span($self: $S::Ident) -> $S::Span;
                fn with_span($self: $S::Ident, span: $S::Span) -> $S::Ident;
            },
            Literal {
                fn drop($self: $S::Literal);
                fn clone($self: &$S::Literal) -> $S::Literal;
                fn debug_kind($self: &$S::Literal) -> String;
                fn symbol($self: &$S::Literal) -> String;
                fn suffix($self: &$S::Literal) -> Option<String>;
                fn integer(n: &str) -> $S::Literal;
                fn typed_integer(n: &str, kind: &str) -> $S::Literal;
                fn float(n: &str) -> $S::Literal;
                fn f32(n: &str) -> $S::Literal;
                fn f64(n: &str) -> $S::Literal;
                fn string(string: &str) -> $S::Literal;
                fn character(ch: char) -> $S::Literal;
                fn byte_string(bytes: &[u8]) -> $S::Literal;
                fn span($self: &$S::Literal) -> $S::Span;
                fn set_span($self: &mut $S::Literal, span: $S::Span);
                fn subspan(
                    $self: &$S::Literal,
                    start: Bound<usize>,
                    end: Bound<usize>,
                ) -> Option<$S::Span>;
            },
            SourceFile {
                fn drop($self: $S::SourceFile);
                fn clone($self: &$S::SourceFile) -> $S::SourceFile;
                fn eq($self: &$S::SourceFile, other: &$S::SourceFile) -> bool;
                fn path($self: &$S::SourceFile) -> String;
                fn is_real($self: &$S::SourceFile) -> bool;
            },
            MultiSpan {
                fn drop($self: $S::MultiSpan);
                fn new() -> $S::MultiSpan;
                fn push($self: &mut $S::MultiSpan, span: $S::Span);
            },
            Diagnostic {
                fn drop($self: $S::Diagnostic);
                fn new(level: Level, msg: &str, span: $S::MultiSpan) -> $S::Diagnostic;
                fn sub(
                    $self: &mut $S::Diagnostic,
                    level: Level,
                    msg: &str,
                    span: $S::MultiSpan,
                );
                fn emit($self: $S::Diagnostic);
            },
            Span {
                fn debug($self: $S::Span) -> String;
                fn def_site() -> $S::Span;
                fn call_site() -> $S::Span;
                fn mixed_site() -> $S::Span;
                fn source_file($self: $S::Span) -> $S::SourceFile;
                fn parent($self: $S::Span) -> Option<$S::Span>;
                fn source($self: $S::Span) -> $S::Span;
                fn start($self: $S::Span) -> LineColumn;
                fn end($self: $S::Span) -> LineColumn;
                fn join($self: $S::Span, other: $S::Span) -> Option<$S::Span>;
                fn resolved_at($self: $S::Span, at: $S::Span) -> $S::Span;
                fn source_text($self: $S::Span) -> Option<String>;
            },
        }
    };
}

// FIXME(eddyb) এটি `encode` কে প্রতিটি যুক্তির জন্য কল করে, তবে বিপরীতে, `&mut` আর্গুমেন্ট দ্বারা শুরু হওয়া fromণ থেকে 00ণ সংক্রান্ত বিরোধগুলি এড়াতে।
//
macro_rules! reverse_encode {
    ($writer:ident;) => {};
    ($writer:ident; $first:ident $(, $rest:ident)*) => {
        reverse_encode!($writer; $($rest),*);
        $first.encode(&mut $writer, &mut ());
    }
}

// FIXME(eddyb) এটি `decode` কে প্রতিটি যুক্তির জন্য কল করে, তবে বিপরীতে, `&mut` আর্গুমেন্ট দ্বারা শুরু হওয়া fromণ থেকে 00ণ সংক্রান্ত বিরোধগুলি এড়াতে।
//
macro_rules! reverse_decode {
    ($reader:ident, $s:ident;) => {};
    ($reader:ident, $s:ident; $first:ident: $first_ty:ty $(, $rest:ident: $rest_ty:ty)*) => {
        reverse_decode!($reader, $s; $($rest: $rest_ty),*);
        let $first = <$first_ty>::decode(&mut $reader, $s);
    }
}

#[allow(unsafe_code)]
mod buffer;
#[forbid(unsafe_code)]
pub mod client;
#[allow(unsafe_code)]
mod closure;
#[forbid(unsafe_code)]
mod handle;
#[macro_use]
#[forbid(unsafe_code)]
mod rpc;
#[allow(unsafe_code)]
mod scoped_cell;
#[forbid(unsafe_code)]
pub mod server;

use buffer::Buffer;
pub use rpc::PanicMessage;
use rpc::{Decode, DecodeMut, Encode, Reader, Writer};

/// একটি সার্ভার এবং ক্লায়েন্টের মধ্যে একটি সক্রিয় সংযোগ।
/// সার্ভারটি সেতুটি তৈরি করে (`server.rs` এ `Bridge::run_server`), তারপরে এটি `client::Client` এর `run` ক্ষেত্রে ফাংশন পয়েন্টারের মাধ্যমে ক্লায়েন্টকে দেয়।
/// ক্লায়েন্টটি এক্সিকিউশন চলাকালীন টিএলএসে `Bridge` এর অনুলিপিটি ধরে রাখে (`client.rs`-এ `Bridge::{enter, with}`)।
///
///
#[repr(C)]
pub struct Bridge<'a> {
    /// পুনরায় ব্যবহারযোগ্য বাফার (কেবলমাত্র ক্লিয়ার-এড, কখনও সঙ্কুচিত হবে না), প্রাথমিকভাবে অনুরোধ করার জন্য ব্যবহৃত হয়, তবে ক্লায়েন্টের কাছে ইনপুট পাস করার জন্যও।
    ///
    cached_buffer: Buffer<u8>,

    /// অনুরোধ করতে ক্লায়েন্টটি ব্যবহার করে এমন সার্ভার-সাইড ফাংশন।
    dispatch: closure::Closure<'a, Buffer<u8>, Buffer<u8>>,

    /// যদি 'true' থাকে তবে সর্বদা ডিফল্ট panic hook তে প্রার্থনা করুন
    force_show_panics: bool,
}

impl<'a> !Sync for Bridge<'a> {}
impl<'a> !Send for Bridge<'a> {}

#[forbid(unsafe_code)]
#[allow(non_camel_case_types)]
mod api_tags {
    use super::rpc::{DecodeMut, Encode, Reader, Writer};

    macro_rules! declare_tags {
        ($($name:ident {
            $(fn $method:ident($($arg:ident: $arg_ty:ty),* $(,)?) $(-> $ret_ty:ty)*;)*
        }),* $(,)?) => {
            $(
                pub(super) enum $name {
                    $($method),*
                }
                rpc_encode_decode!(enum $name { $($method),* });
            )*


            pub(super) enum Method {
                $($name($name)),*
            }
            rpc_encode_decode!(enum Method { $($name(m)),* });
        }
    }
    with_api!(self, self, declare_tags);
}

/// trait ইমপ্লিট প্রেরণের অনুমতি দেওয়ার জন্য সম্পর্কিত প্রকারগুলি মোড়ানোর জন্য সহায়তাকারী Help
/// এটি হ'ল সাধারণত `T::Foo` এবং `T::Bar` এর জন্য একটি জুড়ি ওভারল্যাপ করতে পারে তবে XL3X এবং `Marked<T::Bar, Bar>` এর মতো প্রচ্ছদের পরিবর্তে যদি প্রলিপিগুলি থাকে তবে তারা তা করতে পারে না।
///
///
trait Mark {
    type Unmarked;
    fn mark(unmarked: Self::Unmarked) -> Self;
}

/// এক্স 800 এক্স দ্বারা মোড়ানো প্রকারগুলি মোড়ানো করুন (বিশদগুলির জন্য এক্স01 এক্স দেখুন)।
trait Unmark {
    type Unmarked;
    fn unmark(self) -> Self::Unmarked;
}

#[derive(Copy, Clone, PartialEq, Eq, Hash)]
struct Marked<T, M> {
    value: T,
    _marker: marker::PhantomData<M>,
}

impl<T, M> Mark for Marked<T, M> {
    type Unmarked = T;
    fn mark(unmarked: Self::Unmarked) -> Self {
        Marked { value: unmarked, _marker: marker::PhantomData }
    }
}
impl<T, M> Unmark for Marked<T, M> {
    type Unmarked = T;
    fn unmark(self) -> Self::Unmarked {
        self.value
    }
}
impl<T, M> Unmark for &'a Marked<T, M> {
    type Unmarked = &'a T;
    fn unmark(self) -> Self::Unmarked {
        &self.value
    }
}
impl<T, M> Unmark for &'a mut Marked<T, M> {
    type Unmarked = &'a mut T;
    fn unmark(self) -> Self::Unmarked {
        &mut self.value
    }
}

impl<T: Mark> Mark for Option<T> {
    type Unmarked = Option<T::Unmarked>;
    fn mark(unmarked: Self::Unmarked) -> Self {
        unmarked.map(T::mark)
    }
}
impl<T: Unmark> Unmark for Option<T> {
    type Unmarked = Option<T::Unmarked>;
    fn unmark(self) -> Self::Unmarked {
        self.map(T::unmark)
    }
}

macro_rules! mark_noop {
    ($($ty:ty),* $(,)?) => {
        $(
            impl Mark for $ty {
                type Unmarked = Self;
                fn mark(unmarked: Self::Unmarked) -> Self {
                    unmarked
                }
            }
            impl Unmark for $ty {
                type Unmarked = Self;
                fn unmark(self) -> Self::Unmarked {
                    self
                }
            }
        )*
    }
}
mark_noop! {
    (),
    bool,
    char,
    &'a [u8],
    &'a str,
    String,
    Delimiter,
    Level,
    LineColumn,
    Spacing,
    Bound<usize>,
}

rpc_encode_decode!(
    enum Delimiter {
        Parenthesis,
        Brace,
        Bracket,
        None,
    }
);
rpc_encode_decode!(
    enum Level {
        Error,
        Warning,
        Note,
        Help,
    }
);
rpc_encode_decode!(struct LineColumn { line, column });
rpc_encode_decode!(
    enum Spacing {
        Alone,
        Joint,
    }
);

#[derive(Clone)]
pub enum TokenTree<G, P, I, L> {
    Group(G),
    Punct(P),
    Ident(I),
    Literal(L),
}

impl<G: Mark, P: Mark, I: Mark, L: Mark> Mark for TokenTree<G, P, I, L> {
    type Unmarked = TokenTree<G::Unmarked, P::Unmarked, I::Unmarked, L::Unmarked>;
    fn mark(unmarked: Self::Unmarked) -> Self {
        match unmarked {
            TokenTree::Group(tt) => TokenTree::Group(G::mark(tt)),
            TokenTree::Punct(tt) => TokenTree::Punct(P::mark(tt)),
            TokenTree::Ident(tt) => TokenTree::Ident(I::mark(tt)),
            TokenTree::Literal(tt) => TokenTree::Literal(L::mark(tt)),
        }
    }
}
impl<G: Unmark, P: Unmark, I: Unmark, L: Unmark> Unmark for TokenTree<G, P, I, L> {
    type Unmarked = TokenTree<G::Unmarked, P::Unmarked, I::Unmarked, L::Unmarked>;
    fn unmark(self) -> Self::Unmarked {
        match self {
            TokenTree::Group(tt) => TokenTree::Group(tt.unmark()),
            TokenTree::Punct(tt) => TokenTree::Punct(tt.unmark()),
            TokenTree::Ident(tt) => TokenTree::Ident(tt.unmark()),
            TokenTree::Literal(tt) => TokenTree::Literal(tt.unmark()),
        }
    }
}

rpc_encode_decode!(
    enum TokenTree<G, P, I, L> {
        Group(tt),
        Punct(tt),
        Ident(tt),
        Literal(tt),
    }
);