//! `Cell` এক্স 100 এক্স অস্তিত্বের জীবনকাল জন্য বৈকল্পিক।

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// জীবনকাল সহ ল্যাম্বডা অ্যাপ্লিকেশনটি টাইপ করুন।
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// লাইফড লাইবড্ডা টাইপ করুন, যেমন, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) X0Nwtype0Z FIXME(#52812) দ্বারা `&'a mut <T as ApplyL<'b>>::Out` এর সাথে প্রতিস্থাপন সীমাবদ্ধতার আশপাশে কাজ করুন
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` চলাকালীন `self` এর মান সেট করে `replacement`, যা পুরানো মানটি পারস্পরিকভাবে পায়।
    /// `f` প্রস্থান করার পরেও পুরাতন মানটি পুনরুদ্ধার করা হবে, এমনকি জেড 0 স্প্যানিক0 জেড দ্বারাও, এক্স০০ এক্স এর দ্বারা করা পরিবর্তনগুলি।
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// মোড়কের সাহায্যে `f` আতঙ্কিত হয়ে থাকলেও ঘরটি সর্বদা ভরাট হয়ে যায় তা নিশ্চিত করে (XP1X দ্বারা বিকল্প অবস্থায় পরিবর্তিত হয়ে থাকে) always
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` চলাকালীন `self` এর মান সেট করে `value`।
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}