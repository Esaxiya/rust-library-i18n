//! নতুন ম্যাক্রো সংজ্ঞায়িত করার সময় ম্যাক্রো লেখকদের জন্য একটি সমর্থন লাইব্রেরি।
//!
//! এই লাইব্রেরিটি স্ট্যান্ডার্ড ডিস্ট্রিবিউশন দ্বারা সরবরাহিত, পদ্ধতিগতভাবে সংজ্ঞায়িত ম্যাক্রো সংজ্ঞা যেমন ফাংশন-জাতীয় ম্যাক্রো এক্স00 এক্স, ম্যাক্রো বৈশিষ্ট্য এক্স01 এক্স এবং কাস্টম ডেরিভ বৈশিষ্ট্য attrib##[প্রো_ম্যাক্রো_ডেরিভ] the এর ইন্টারফেসে গ্রাস করা প্রকারগুলি সরবরাহ করে `
//!
//!
//! আরও জন্য [the book] দেখুন।
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// বর্তমানে চলমান প্রোগ্রামটিতে প্র্যাক_ম্যাক্রো অ্যাক্সেসযোগ্য করা হয়েছে কিনা তা নির্ধারণ করে।
///
/// Proc_macro crate কেবলমাত্র পদ্ধতিগত ম্যাক্রোগুলির প্রয়োগের জন্য ব্যবহারের উদ্দেশ্যে forকোনও প্রসেসুয়াল ম্যাক্রোর বাইরে যেমন বিল্ড স্ক্রিপ্ট বা ইউনিট পরীক্ষা বা সাধারণ জেড 0 রিস্ট0 জেড বাইনারি থেকে আহ্বান করা হলে এই জেড 0 ক্রেট 0 জেড জেড 0 প্যানিক0 জেড এর সমস্ত ফাংশন।
///
/// জেড 0 রিস্ট0 জেড লাইব্রেরিগুলির জন্য বিবেচনা করে যা ম্যাক্রো এবং নন-ম্যাক্রো উভয় ক্ষেত্রেই সমর্থন করার জন্য ডিজাইন করা হয়েছে, প্র্যাক_ম্যাক্রোর API ব্যবহারের জন্য প্রয়োজনীয় অবকাঠামোগুলি বর্তমানে উপলব্ধ কিনা তা সনাক্ত করার জন্য `proc_macro::is_available()` একটি অ-আতঙ্কিত উপায় সরবরাহ করে।
/// পদ্ধতিগত ম্যাক্রোর অভ্যন্তর থেকে আহ্বান করা হলে সত্যটি প্রত্যাবর্তন করে, অন্য কোনও বাইনারি থেকে আহ্বান করা হলে মিথ্যা।
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// এই crate দ্বারা প্রদত্ত প্রধান প্রকার, tokens এর বিমূর্ত স্ট্রিম উপস্থাপন করে বা আরও সুনির্দিষ্টভাবে token গাছের ক্রম।
/// এই ধরণের token গাছগুলিকে পুনরাবৃত্তি করার জন্য ইন্টারফেস সরবরাহ করে এবং বিপরীতে একটি সংখ্যাতে token গাছ সংগ্রহ করে।
///
///
/// এটি `#[proc_macro]`, `#[proc_macro_attribute]` এবং `#[proc_macro_derive]` সংজ্ঞাগুলির ইনপুট এবং আউটপুট উভয়ই।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` থেকে ত্রুটি ফিরে এসেছে।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token গাছ নেই এমন একটি খালি `TokenStream` প্রদান করে।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// এই `TokenStream` খালি কিনা তা পরীক্ষা করে।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// স্ট্রিংটি tokens এ ভাঙ্গার চেষ্টা করে এবং সেই tokens কে token স্ট্রিমে পার্স করার চেষ্টা করুন।
/// বিভিন্ন কারণে ব্যর্থ হতে পারে, উদাহরণস্বরূপ, যদি স্ট্রিংয়ে ভারসাম্যহীন সীমানা বা অক্ষরগুলি ভাষাতে বিদ্যমান থাকে।
///
/// পার্সড স্ট্রিমের সমস্ত tokens `Span::call_site()` স্প্যান পান।
///
/// NOTE: কিছু ত্রুটি `LexError` ফিরিয়ে দেওয়ার পরিবর্তে panics হতে পারে।আমরা এই ত্রুটিগুলি পরে `LexError into এ পরিবর্তনের অধিকার সংরক্ষণ করি।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token স্ট্রিমটিকে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা সম্ভবত Z টোকেনট্রি: : গ্রুপ X এর `Delimiter::None` সীমানার এবং নেতিবাচক সংখ্যাসূচক ব্যতীত একই token স্ট্রিমে (মডুলো স্প্যান) রূপান্তরবিহীন বলে মনে করা হয়।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ডিবাগিংয়ের জন্য সুবিধাজনক আকারে token মুদ্রণ করে।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// একটি একক token গাছ সমন্বিত একটি token স্ট্রিম তৈরি করে।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// একটি একক প্রবাহে প্রচুর token গাছ সংগ্রহ করে।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token স্ট্রিমের একটি "flattening" অপারেশন, একাধিক token স্ট্রিম থেকে token গাছ সংগ্রহ করে একটি একক প্রবাহে।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) সম্ভব একটি অপ্টিমাইজড বাস্তবায়ন if/when ব্যবহার করুন।
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// এক্সটারএক্স প্রকারের জন্য সর্বজনীন প্রয়োগের বিশদ যেমন পুনরাবৃত্তিকারী।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `টোকেনস্ট্রিম` এর` টোকেনট্রি over
    /// পুনরাবৃত্তিটি "shallow", উদাহরণস্বরূপ, পুনরাবৃত্তিটি সীমিত দলগুলিতে পুনরাবৃত্তি করে না এবং পুরো গ্রুপগুলি token গাছ হিসাবে প্রত্যাবর্তন করে।
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` নির্বিচারে tokens গ্রহণ করে এবং ইনপুট বর্ণনা করে একটি `TokenStream` এ প্রসারিত।
/// উদাহরণস্বরূপ, `quote!(a + b)` একটি এক্সপ্রেশন তৈরি করবে, যা যখন মূল্যায়ন করা হয়, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// এক্সকোটিং `$` এর সাথে সম্পন্ন হয় এবং একক পরবর্তী পরিচয়টিকে অব্যক্ত শব্দ হিসাবে গ্রহণ করে কাজ করে।
/// `$` নিজেই উদ্ধৃত করতে, `$$` ব্যবহার করুন।
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// ম্যাক্রো সম্প্রসারণ তথ্যের পাশাপাশি উত্স কোডের একটি অঞ্চল।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// স্প্যান `self` এ প্রদত্ত `message` সহ একটি নতুন এক্স01 এক্স তৈরি করে।
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// একটি স্প্যান যা ম্যাক্রো সংজ্ঞা সাইটে সমাধান করে।
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// বর্তমান পদ্ধতিগত ম্যাক্রোর অনুরোধের স্প্যান।
    /// এই স্প্যানটির সাথে তৈরি শনাক্তকারীগুলিকে সমাধান করা হবে যেন তারা সরাসরি ম্যাক্রো কল লোকেশন (কল-সাইট স্বাস্থ্যবিধি) এবং ম্যাক্রো কল সাইটে অন্য কোডগুলি তাদের উল্লেখ করতে সক্ষম হবে।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// একটি স্প্যান যা `macro_rules` স্বাস্থ্যবিধি উপস্থাপন করে এবং কখনও কখনও ম্যাক্রো সংজ্ঞা সাইটের (স্থানীয় ভেরিয়েবল, লেবেল, এক্স01 এক্স) এবং কখনও কখনও ম্যাক্রো কল সাইটে (অন্য সব কিছু) সমাধান করে।
    ///
    /// স্প্যানের অবস্থান কল-সাইট থেকে নেওয়া হয়েছে।
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// মূল উত্স ফাইল যা এই স্প্যানটিকে নির্দেশ করে।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// পূর্ববর্তী ম্যাক্রো প্রসারণে tokens এর জন্য `Span` যেখান থেকে `self` উত্পাদিত হয়েছিল, যদি তা থাকে।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` যে উত্স উত্স কোড থেকে উত্পন্ন হয়েছিল তার স্প্যান।
    /// এই `Span` যদি অন্য ম্যাক্রো বিস্তৃতি থেকে উত্পন্ন না হয় তবে ফেরতের মান `*self` এর সমান।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// এই স্প্যানটির জন্য উত্স ফাইলে শুরু line/column পান।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// এই স্প্যানটির জন্য উত্স ফাইলে শেষ হওয়া line/column পান।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` এবং `other` সমাহার করে একটি নতুন স্প্যান তৈরি করে।
    ///
    /// `self` এবং `other` বিভিন্ন ফাইল থেকে থাকলে `None` প্রদান করে।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` হিসাবে একই line/column তথ্য দিয়ে একটি নতুন স্প্যান তৈরি করে তবে এটি প্রতীকগুলি সমাধান করে যেমন এটি `other` এ ছিল।
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` হিসাবে একই নাম রেজোলিউশন আচরণের সাথে তবে `other` এর line/column তথ্য সহ একটি নতুন স্প্যান তৈরি করে।
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// স্প্যানগুলির সাথে তারা সমান কিনা তা তুলনা করে।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// স্প্যানের পিছনে উত্স পাঠ্য ফেরত দেয়।
    /// এটি স্পেস এবং মন্তব্য সহ আসল উত্স কোডটি সংরক্ষণ করে।
    /// স্প্যানটি যদি আসল উত্স কোডের সাথে মিলে যায় তবে এটি কেবল ফলাফল দেয়।
    ///
    /// Note: ম্যাক্রোর পর্যবেক্ষণযোগ্য ফলাফলটি কেবলমাত্র tokens এর উপর নির্ভর করা উচিত এবং এই উত্স পাঠ্যে নয়।
    ///
    /// এই ফাংশনটির ফলাফলটি শুধুমাত্র ডায়াগনস্টিক্সের জন্য ব্যবহারের জন্য সর্বোত্তম প্রচেষ্টা।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ডিবাগ করার জন্য সুবিধাজনক ফর্মটিতে একটি স্প্যান মুদ্রণ করে।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// একটি লাইন-কলামের জুটি একটি `Span` এর শুরু বা শেষ উপস্থাপন করে।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// উত্স ফাইলে 1-ইনডেক্সেড লাইন, যার উপর স্প্যান শুরু হয় বা (inclusive) শেষ হয়।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// উত্স ফাইলে 0-সূচিযুক্ত কলাম (UTF-8 অক্ষরগুলিতে) যার স্প্যানটি (inclusive) শুরু হয় বা শেষ হয়।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// প্রদত্ত `Span` এর উত্স ফাইল।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// এই উত্স ফাইলটিতে পথ পায়।
    ///
    /// ### Note
    /// যদি এই `SourceFile` এর সাথে যুক্ত কোড স্প্যানটি কোনও বাহ্যিক ম্যাক্রো, এই ম্যাক্রোর দ্বারা উত্পাদিত হয় তবে এটি ফাইল সিস্টেমে প্রকৃত পথ নাও হতে পারে।
    /// [`is_real`] ব্যবহার করে পরীক্ষা করুন।
    ///
    /// এছাড়াও লক্ষ করুন যে `is_real` `true` প্রদান করে, যদি `--remap-path-prefix` কমান্ড লাইনে পাস করা হয় তবে প্রদত্ত পথটি বৈধ নয়।
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// যদি এই উত্স ফাইলটি একটি আসল উত্স ফাইল হয় এবং কোনও বাহ্যিক ম্যাক্রোর সম্প্রসারণ দ্বারা উত্পন্ন না হয় তবে `true` প্রদান করে।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ইন্টার্যাক্রেট স্প্যানগুলি প্রয়োগ না করা পর্যন্ত এটি একটি হ্যাক এবং বাহ্যিক ম্যাক্রোগুলিতে উত্পন্ন স্প্যানগুলির জন্য আমাদের কাছে আসল উত্স ফাইল থাকতে পারে।
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// একটি একক token বা token গাছগুলির একটি সীমিত সিকোয়েন্স (উদাঃ, X01 এক্স)।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// বন্ধনী ডিলিমিটর দ্বারা বেষ্টিত একটি token স্ট্রিম।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// একটি সনাক্তকারী।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// একটি একক বিরামচিহ্ন অক্ষর (`+`, `,`, `$`, ইত্যাদি)।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// একটি আক্ষরিক অক্ষর (`'a'`), স্ট্রিং (`"hello"`), সংখ্যা (`2.3`), ইত্যাদি
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// এতে থাকা token বা একটি সীমিত প্রবাহের `span` পদ্ধতিতে প্রেরণ করে এই গাছের স্প্যানটি দেয়।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *কেবল এই token* এর জন্য স্প্যানটি কনফিগার করে।
    ///
    /// মনে রাখবেন যে এই জেড0 টোকেন0 জেডটি যদি `Group` হয় তবে এই পদ্ধতিটি অভ্যন্তরীণ tokens এর প্রতিটি স্প্যানটি কনফিগার করবে না, এটি কেবল প্রতিটি বৈকল্পিকের `set_span` পদ্ধতিতে প্রতিনিধিত্ব করবে।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ডিবাগিংয়ের জন্য সুবিধাজনক আকারে token গাছ মুদ্রণ করে।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // এগুলির প্রত্যেকেরই উদ্ভূত ডিবাগের স্ট্রাক্ট টাইপের নাম রয়েছে, সুতরাং অতিরিক্ত অতিরিক্ত স্তর নিয়ে বিরক্ত করবেন না
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token গাছটিকে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা সম্ভবত Z টোকেনট্রি: : গ্রুপ X এর `Delimiter::None` ডিলিমিটার এবং নেতিবাচক সংখ্যাসূচক অক্ষর ব্যতীত একই token গাছ (মডুলো স্প্যানস) এ ক্ষতিহীনভাবে রূপান্তরিত হওয়ার কথা।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// একটি সীমাবদ্ধ token স্ট্রিম।
///
/// একটি `Group` অভ্যন্তরীণভাবে একটি `TokenStream` রয়েছে যা surrounded ডেলিমিটার দ্বারা বেষ্টিত।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token গাছগুলির ক্রম কীভাবে সীমিত করা হয় তা বর্ণনা করে।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// একটি অন্তর্নিহিত ডিলিমিটার, উদাহরণস্বরূপ, "macro variable" `$var` থেকে আসা tokens এর আশেপাশে উপস্থিত হতে পারে।
    /// `$var * 3` এর মতো ক্ষেত্রে যেখানে `$var` হয় `1 + 2`, সেখানে অপারেটর অগ্রাধিকারগুলি সংরক্ষণ করা গুরুত্বপূর্ণ।
    /// অন্তর্নিহিত ডিলিমিটারগুলি কোনও স্ট্রিংয়ের মাধ্যমে token স্ট্রিমের রাউন্ডট্রিপ থেকে বাঁচতে পারে না।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// প্রদত্ত ডিলিমিটার এবং token স্ট্রিম সহ একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// এই নির্মাতা এই গ্রুপটির স্প্যানটি `Span::call_site()` এ সেট করবে।
    /// স্প্যানটি পরিবর্তন করতে আপনি নীচের `set_span` পদ্ধতিটি ব্যবহার করতে পারেন।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// এই `Group` এর ডিলিমিটারটি ফিরিয়ে দেয়
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// এই `Group` এ সীমাবদ্ধ tokens এর `TokenStream` প্রদান করে।
    ///
    /// নোট করুন যে প্রত্যাবর্তিত token প্রবাহটি উপরে বর্ণিত ডিলিমিটারটি অন্তর্ভুক্ত করে না।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// পুরো `Group` বিস্তৃত এই token স্ট্রিমের ডিলিমিটারদের জন্য স্প্যানটি ফেরত দেয়।
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// এই গোষ্ঠীর উদ্বোধনী ডিলিমিটারের দিকে ইঙ্গিত করে স্প্যানটি ফেরত দেয়।
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// এই গোষ্ঠীর সমাপনী ডিলিমিটারের দিকে ইঙ্গিত করে স্প্যানটি দেয়।
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// এই `গ্রুপের ডিলিমিটরের জন্য স্প্যানটি কনফিগার করে তবে এর অভ্যন্তরীণ tokens নয়।
    ///
    /// এই পদ্ধতিটি **নয়** এই গ্রুপ দ্বারা বিভক্ত সমস্ত অভ্যন্তরীণ tokens স্প্যান সেট করবে, তবে এটি কেবল `Group` এর স্তরে সীমাবদ্ধ tokens স্প্যান সেট করবে।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// গোষ্ঠীটিকে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা সম্ভবত 00 টোকেনট্রি: : এক্স ২০০ এক্স ডেলিফিটর সহ গ্রুপ `ব্যতীত নিখরচায় একই গোষ্ঠীতে (মডুলো স্প্যান) রূপান্তরিত হওয়া উচিত।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// একটি এক্স0৩ এক্স এক্স01 এক্স, এক্স02 এক্স বা এক্স 100 এক্স এর মতো একক বিরামচিহ্ন অক্ষর।
///
/// এক্স-00 এক্স এর মতো মাল্টি-ক্যারেক্টারেটর অপারেটরগুলি `Spacing` এর দুটি ফর্ম হিসাবে ফিরে আসা `Punct` এর দুটি উদাহরণ হিসাবে উপস্থাপিত হয়।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// একটি `Punct` অন্য `Punct` অবিলম্বে অনুসরণ করা হয় বা অন্য token বা হোয়াইটস্পেস অনুসরণ করবে কিনা।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// উদাহরণস্বরূপ, `+` এক্স01 এক্স, এক্স01 এক্স, এক্স03 এক্স বা এক্স 100 এক্স।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// উদাহরণস্বরূপ, `+` `+=` বা `'#` এ `Joint`।
    /// অতিরিক্তভাবে, একক উদ্ধৃতি `'` শনাক্তকারীদের সাথে লাইফটাইম এক্স00 এক্স গঠন করতে পারে।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// প্রদত্ত চরিত্র এবং ব্যবধান থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    /// `ch` টি আর্গুমেন্ট অবশ্যই ভাষা দ্বারা অনুমোদিত বৈধ বিরামচিহ্ন অক্ষর হতে হবে, অন্যথায় ফাংশনটি panic করবে।
    ///
    /// ফিরে আসা `Punct` এ `Span::call_site()` এর ডিফল্ট স্প্যান থাকবে যা নীচে `set_span` পদ্ধতিতে আরও কনফিগার করা যেতে পারে।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// এই বিরামচিহ্নের অক্ষরের মান `char` হিসাবে ফিরিয়ে দেয়।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// এই বিরামচিহ্নের অক্ষরের ব্যবধানটি প্রতীয়মান করে যে এটি token প্রবাহে অন্য `Punct` অবিলম্বে অনুসরণ করেছে কিনা তা নির্দেশ করে, যাতে তারা সম্ভবত একটি বহু-চরিত্রের অপারেটর (`Joint`) এর সাথে সংযুক্ত হতে পারে, বা এটি অনুসরণ করে অন্য কোনও জেড টোকেন0 জেড বা হোয়াইটস্পেস এক্স02 এক্স যাতে অপারেটর অবশ্যই আছে শেষ
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// এই বিরামচিহ্নের চরিত্রটির জন্য স্প্যানটি দেয়।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// এই বিরামচিহ্ন চরিত্রের জন্য স্প্যানটি কনফিগার করুন।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// বিরামচিহ্ন অক্ষরটিকে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা ক্ষতিহীনভাবে একই অক্ষরে রূপান্তরিত হওয়া উচিত।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// একটি সনাক্তকারী (`ident`)।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// প্রদত্ত `string` পাশাপাশি নির্দিষ্ট `span` দিয়ে একটি নতুন এক্স01 এক্স তৈরি করে।
    /// `string` টি আর্গুমেন্টটি অবশ্যই ভাষা দ্বারা অনুমোদিত বৈধ শনাক্তকারী হতে হবে (কীওয়ার্ড সহ, উদাহরণস্বরূপ `self` বা `fn`)।অন্যথায়, ফাংশনটি panic করবে।
    ///
    /// নোট করুন যে বর্তমানে জেড0rustc0Z এ থাকা `span` এই সনাক্তকারীটির জন্য স্বাস্থ্যকর তথ্য কনফিগার করে।
    ///
    /// এই সময় পর্যন্ত `Span::call_site()` স্পষ্টভাবে "call-site" হাইজিনের বিকল্পটি বেছে নেবে অর্থাত এই স্প্যানটি দিয়ে তৈরি করা শনাক্তকারীগুলি ম্যাক্রো কলের স্থানে সরাসরি লেখা হয়েছিল এমন সমাধান করা হবে এবং ম্যাক্রো কল সাইটে থাকা অন্য কোডগুলি উল্লেখ করতে সক্ষম হবে তাদের পাশাপাশি।
    ///
    ///
    /// পরে `Span::def_site()` এর মতো স্প্যানস এক্স01 এক্স হাইজিন নির্বাচন করতে অনুমতি দেবে যার অর্থ এই স্প্যানটি দিয়ে তৈরি করা শনাক্তকারীরা ম্যাক্রো সংজ্ঞা এবং ম্যাক্রো কল সাইটে থাকা অন্য কোডের অবস্থানের স্থানে সমাধান করা হবে to
    ///
    /// হাইজিনের বর্তমান গুরুত্বের কারণে এই নির্মাতা অন্যান্য tokens এর বিপরীতে নির্মাণে একটি `Span` নির্দিষ্ট করার প্রয়োজন।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` হিসাবে একই, তবে একটি কাঁচা শনাক্তকারী (`r#ident`) তৈরি করে।
    /// `string` টি আর্গুমেন্টটি ভাষা দ্বারা অনুমোদিত বৈধ শনাক্তকারী হতে (কীওয়ার্ডগুলি সহ, যেমন `fn`)।
    /// পাথ বিভাগগুলিতে ব্যবহারযোগ্য এমন কীওয়ার্ডগুলি (উদাঃ)
    /// `self`, `সুপার`) সমর্থিত নয় এবং এটি panic এর কারণ ঘটবে।
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) দ্বারা ফিরে আসা পুরো স্ট্রিংকে ঘিরে এই `Ident` এর স্প্যানটি দেয়।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// এই `Ident` এর স্প্যানটি কনফিগার করে, সম্ভবত এর হাইজিন প্রসঙ্গে পরিবর্তন করে।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// শনাক্তকারীকে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা ক্ষতিহীনভাবে একই শনাক্তকারীতে রূপান্তরিত হওয়া উচিত।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// একটি আক্ষরিক স্ট্রিং (`"hello"`), বাইট স্ট্রিং (`b"hello"`), অক্ষর (`'a'`), বাইট অক্ষর (`b'a'`), একটি প্রত্যয় সহ বা তার ছাড়াই একটি পূর্ণসংখ্যা বা ভাসমান পয়েন্ট সংখ্যা (`1`, `1u8`, `2.3`, `2.3f32`)।
///
/// `true` এবং `false` এর মতো বুলিয়ান লিটারেলগুলি এখানে অন্তর্ভুক্ত নয়, তারা হ'ল `পরিচয়।
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// নির্দিষ্ট মান সহ একটি নতুন প্রত্যয়িত পূর্ণসংখ্যার আক্ষরিক তৈরি করে।
        ///
        /// এই ফাংশনটি `1u32` এর মতো একটি পূর্ণসংখ্যা তৈরি করবে যেখানে নির্ধারিত পূর্ণসংখ্যার মানটি token এর প্রথম অংশ এবং ইন্টিগ্রালটি শেষেও প্রত্যয়যুক্ত হয়।
        /// নেতিবাচক সংখ্যা থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে রাউন্ড-ট্রিপগুলি টিকে থাকতে পারে না এবং দুটি জেড টোকেন0 জেড (এক্স01 এক্স এবং পজিটিভ আক্ষরিক) বিভক্ত হতে পারে।
        ///
        ///
        /// এই পদ্ধতির মাধ্যমে তৈরি লিটারালগুলিতে ডিফল্টরূপে `Span::call_site()` স্প্যান থাকে, যা নীচে `set_span` পদ্ধতিতে কনফিগার করা যায়।
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// নির্দিষ্ট মান সহ একটি নতুন অসমাপ্ত পূর্ণসংখ্যার আক্ষরিক তৈরি করে।
        ///
        /// এই ফাংশনটি `1` এর মতো একটি পূর্ণসংখ্যা তৈরি করবে যেখানে নির্ধারিত পূর্ণসংখ্যার মানটি token এর প্রথম অংশ।
        /// এই token এ কোন প্রত্যয় নির্দিষ্ট করা হয়নি, যার অর্থ `Literal::i8_unsuffixed(1)` এর মতো অনুরোধগুলি `Literal::u32_unsuffixed(1)` এর সমতুল্য।
        /// নেতিবাচক সংখ্যাগুলি থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে rountrips এ টিকতে পারে না এবং দুটি tokens (`-` এবং ধনাত্মক আক্ষরিক) মধ্যে বিভক্ত হতে পারে।
        ///
        ///
        /// এই পদ্ধতির মাধ্যমে তৈরি লিটারালগুলিতে ডিফল্টরূপে `Span::call_site()` স্প্যান থাকে, যা নীচে `set_span` পদ্ধতিতে কনফিগার করা যায়।
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// একটি নতুন অসমাপ্ত ভাসমান-পয়েন্ট আক্ষরিক তৈরি করে।
    ///
    /// এই কনস্ট্রাক্টরটি `Literal::i8_unsuffixed` এর মতো যেখানে ফ্লোটের মানটি সরাসরি জেড টোকেন0 জেডে নির্গত হয় তবে কোনও প্রত্যয় ব্যবহার করা হয় না, তাই এটি সংকলকটির পরে `f64` হতে পারে বলে অনুমান করা যেতে পারে।
    ///
    /// নেতিবাচক সংখ্যাগুলি থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে rountrips এ টিকতে পারে না এবং দুটি tokens (`-` এবং ধনাত্মক আক্ষরিক) মধ্যে বিভক্ত হতে পারে।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটির জন্য নির্দিষ্ট ফ্লোট সীমাবদ্ধ হওয়া দরকার, উদাহরণস্বরূপ যদি এটি অনন্ত বা NaN হয় তবে এই ফাংশনটি panic করবে।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// একটি নতুন প্রত্যয়যুক্ত ভাসমান-পয়েন্ট আক্ষরিক তৈরি করে।
    ///
    /// এই কনস্ট্রাক্টরটি `1.0f32` এর মতো একটি আক্ষরিক তৈরি করবে যেখানে নির্দিষ্ট করা মানটি token এর পূর্ববর্তী অংশ এবং `f32` token এর প্রত্যয়।
    /// এই token সর্বদা সংকলকটিতে একটি `f32` হতে অনুমিত হবে।
    /// নেতিবাচক সংখ্যাগুলি থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে rountrips এ টিকতে পারে না এবং দুটি tokens (`-` এবং ধনাত্মক আক্ষরিক) মধ্যে বিভক্ত হতে পারে।
    ///
    ///
    /// # Panics
    ///
    /// এই ফাংশনটির জন্য নির্দিষ্ট ফ্লোট সীমাবদ্ধ হওয়া দরকার, উদাহরণস্বরূপ যদি এটি অনন্ত বা NaN হয় তবে এই ফাংশনটি panic করবে।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// একটি নতুন অসমাপ্ত ভাসমান-পয়েন্ট আক্ষরিক তৈরি করে।
    ///
    /// এই কনস্ট্রাক্টরটি `Literal::i8_unsuffixed` এর মতো যেখানে ফ্লোটের মানটি সরাসরি জেড টোকেন0 জেডে নির্গত হয় তবে কোনও প্রত্যয় ব্যবহার করা হয় না, তাই এটি সংকলকটির পরে `f64` হতে পারে বলে অনুমান করা যেতে পারে।
    ///
    /// নেতিবাচক সংখ্যাগুলি থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে rountrips এ টিকতে পারে না এবং দুটি tokens (`-` এবং ধনাত্মক আক্ষরিক) মধ্যে বিভক্ত হতে পারে।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটির জন্য নির্দিষ্ট ফ্লোট সীমাবদ্ধ হওয়া দরকার, উদাহরণস্বরূপ যদি এটি অনন্ত বা NaN হয় তবে এই ফাংশনটি panic করবে।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// একটি নতুন প্রত্যয়যুক্ত ভাসমান-পয়েন্ট আক্ষরিক তৈরি করে।
    ///
    /// এই কনস্ট্রাক্টরটি `1.0f64` এর মতো একটি আক্ষরিক তৈরি করবে যেখানে নির্দিষ্ট করা মানটি token এর পূর্ববর্তী অংশ এবং `f64` token এর প্রত্যয়।
    /// এই token সর্বদা সংকলকটিতে একটি `f64` হতে অনুমিত হবে।
    /// নেতিবাচক সংখ্যাগুলি থেকে তৈরি লিটারেলগুলি `TokenStream` বা স্ট্রিংগুলির মাধ্যমে rountrips এ টিকতে পারে না এবং দুটি tokens (`-` এবং ধনাত্মক আক্ষরিক) মধ্যে বিভক্ত হতে পারে।
    ///
    ///
    /// # Panics
    ///
    /// এই ফাংশনটির জন্য নির্দিষ্ট ফ্লোট সীমাবদ্ধ হওয়া দরকার, উদাহরণস্বরূপ যদি এটি অনন্ত বা NaN হয় তবে এই ফাংশনটি panic করবে।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// আক্ষরিক স্ট্রিং।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// অক্ষর আক্ষরিক।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// বাইট স্ট্রিং আক্ষরিক।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// এই আক্ষরিককে ঘিরে স্প্যানটি দেয়
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// এই আক্ষরিক জন্য সম্পর্কিত স্প্যান কনফিগার করে।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// একটি `Span` প্রদান করে যা `self.span()` এর একটি উপসেট যা কেবলমাত্র `range` রেঞ্জের সোর্স বাইট রয়েছে।
    /// এক্স-01 এক্স প্রদান করে যদি বিছানা ছাঁটাই স্প্যানটি `self` এর সীমার বাইরে থাকে।
    ///
    // FIXME(SergioBenitez): উত্সের UTF-8 সীমানায় বাইট পরিসরটি শুরু হয় এবং শেষ হয় তা পরীক্ষা করে দেখুন।
    // অন্যথায়, সম্ভবত উত্স পাঠ্যটি মুদ্রিত হওয়ার পরে একটি panic অন্য কোথাও ঘটবে।
    // FIXME(SergioBenitez): ব্যবহারকারীর পক্ষে `self.span()` আসলে কী ম্যাপ করে তা জানার কোনও উপায় নেই, সুতরাং এই পদ্ধতিটি বর্তমানে কেবল অন্ধভাবে বলা যেতে পারে।
    // উদাহরণস্বরূপ, 'c' অক্ষরের জন্য `to_string()` এক্স01 এক্স প্রদান করে;উত্সের পাঠ্যটি 'c' ছিল কি না এটি '\u{63}' কিনা তা ব্যবহারকারীর পক্ষে জানার কোনও উপায় নেই।
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` এর মতো কিছু, তবে `Bound<&T>` এর মতো।
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// এনবি, সেতুটি কেবলমাত্র `to_string` সরবরাহ করে, এর উপর ভিত্তি করে এক্স01 এক্স বাস্তবায়ন করে (উভয়ের মধ্যে স্বাভাবিক সম্পর্কের বিপরীতে)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// আক্ষরিককে একটি স্ট্রিং হিসাবে মুদ্রণ করে যা ক্ষতিহীনভাবে একই আক্ষরিক পরিবর্তিত হওয়া উচিত (ভাসমান পয়েন্ট আক্ষরিকের জন্য সম্ভাব্য গোলাকার ব্যতীত)।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// পরিবেশের ভেরিয়েবলগুলিতে ট্র্যাক অ্যাক্সেস।
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// পরিবেশের পরিবর্তনশীলটি পুনরুদ্ধার করুন এবং নির্ভরতা তথ্য তৈরি করতে এটি যুক্ত করুন।
    /// সংকলক নির্বাহকারী বিল্ড সিস্টেমটি জানবে যে সংকলনের সময় চলকটি অ্যাক্সেস করা হয়েছিল এবং সেই পরিবর্তনশীলটির মান পরিবর্তিত হলে বিল্ডটি পুনরায় চালু করতে সক্ষম হবে।
    ///
    /// নির্ভরতা অনুসরণ করে এই ফাংশনটি স্ট্যান্ডার্ড লাইব্রেরি থেকে `env::var` এর সমতুল্য হওয়া উচিত, ব্যতীত UTF-8 হওয়া উচিত।
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}