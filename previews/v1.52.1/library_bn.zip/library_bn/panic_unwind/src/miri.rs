//! মিরির জন্য আনইন্ডিং জেড0প্যানিক্স0 জেড।
use alloc::boxed::Box;
use core::any::Any;

// মিরি ইঞ্জিন আমাদের জন্য আনওয়াইন্ডিংয়ের মাধ্যমে যে ধরণের পেওড প্রচার করে।
// পয়েন্টার আকারের হতে হবে।
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// মিনির সরবরাহিত বাহ্যিক ফাংশন আনওয়াইন্ডিং শুরু করতে।
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // আমরা `miri_start_panic` এ প্রদত্ত পেডলোডটি নীচে `cleanup` এ পাওয়া ঠিক যুক্তি হবে।
    // পয়েন্টার আকারের কিছু পেতে আমরা কেবল এটি একবার বাক্সবাক্স করি।
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // অন্তর্নিহিত `Box` পুনরুদ্ধার করুন।
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}