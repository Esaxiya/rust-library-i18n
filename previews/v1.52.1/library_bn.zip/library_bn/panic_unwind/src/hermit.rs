//! *হার্মিট* টার্গেটের জন্য অনাকাঙ্ক্ষিত।
//!
//! এখনই আমরা এটি সমর্থন করি না, সুতরাং এটি কেবল স্টাবস ub

use alloc::boxed::Box;
use core::any::Any;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}