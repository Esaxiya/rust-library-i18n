//! এক্স 00 এক্স (কিছু আকারে) দ্বারা জেড জেড0প্যানিক্স0 জেড এর বাস্তবায়ন।
//!
//! ব্যতিক্রম পাতায় ব্যতিক্রমের জন্য হ্যান্ডলিং এবং স্ট্যাক আনওয়াইন্ডিংয়ের জন্য দয়া করে "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) এবং এর থেকে লিঙ্কযুক্ত নথি দেখুন।
//! এগুলিও ভাল পড়ে:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## একটি সংক্ষিপ্ত সারাংশ
//!
//! ব্যতিক্রম হ্যান্ডলিং দুটি ধাপে ঘটে: একটি অনুসন্ধান পর্ব এবং একটি পরিষ্কারের ধাপ phase
//!
//! উভয় পর্যায়ে আনওয়িন্দার স্ট্যাক ফ্রেম থেকে বর্তমান প্রক্রিয়াটির মডিউলগুলির বিভাগগুলি আনওয়াইন্ড বিভাগের তথ্য ব্যবহার করে উপরের থেকে নীচে স্ট্যাক ফ্রেমগুলি হাঁটা করে (এখানে "module" একটি ওএস মডিউলটি বোঝায়, অর্থাত্ এক্সিকিউটেবল বা ডায়নামিক লাইব্রেরি)।
//!
//!
//! প্রতিটি স্ট্যাক ফ্রেমের জন্য, এটি সম্পর্কিত "personality routine"-কে অনুরোধ করে, যার ঠিকানাটি আনইন্ডিং তথ্য বিভাগেও সংরক্ষণ করা হয়।
//!
//! অনুসন্ধানের পর্যায়ে, ব্যক্তিত্বের রুটিনের কাজ হ'ল ব্যতিক্রম বস্তুটি ফেলে দেওয়া হচ্ছে তা পরীক্ষা করা এবং এটি স্ট্যাক ফ্রেমে ধরা উচিত কিনা তা সিদ্ধান্ত নেওয়া।হ্যান্ডলার ফ্রেমটি চিহ্নিত হয়ে গেলে, পরিষ্কারের পর্ব শুরু হয়।
//!
//! ক্লিনআপ পর্বে আনভিন্ভার প্রতিটি ব্যক্তিত্বের রুটিনকে আবার আমন্ত্রণ জানায়।
//! এবার এটি স্থির করে যে কোন (যদি থাকে) ক্লিনআপ কোডটি বর্তমান স্ট্যাক ফ্রেমের জন্য চালানো দরকার।যদি তা হয় তবে নিয়ন্ত্রণটি ফাংশন বডি, "landing pad"-এ একটি বিশেষ জেড 0 ব্র্যাঞ্চ0 জেডে স্থানান্তরিত হয় যা ডিস্ট্রাক্টরদের আহ্বান করে, মেমরি মুক্ত করে etc.
//! ল্যান্ডিং প্যাডের শেষে, নিয়ন্ত্রণটি আনউইন্ডার এবং অযত্নহীন পুনরায় চালুগুলিতে ফিরে স্থানান্তরিত হয়।
//!
//! একবার স্ট্যাক হ্যান্ডলার ফ্রেম স্তরে অযাচিত হয়ে গেলে, অযত্নহীন স্টপস এবং শেষ ব্যক্তিত্বের রুটিনটি নিয়ন্ত্রণ ব্লকটিতে নিয়ন্ত্রণ স্থানান্তর করে।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust এর ব্যতিক্রম শ্রেণি শনাক্তকারী।
// ব্যতিক্রমটি তাদের নিজস্ব রানটাইম দ্বারা ছুঁড়েছিল কিনা তা নির্ধারণ করতে এটি ব্যক্তিত্বের রুটিন দ্বারা ব্যবহৃত হয়।
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // মোজ\0 রুস্ট-বিক্রেতা, ভাষা
    0x4d4f5a_00_52555354
}

// প্রতিটি আর্কিটেকচারের জন্য রেজিস্টার আইডিগুলি এলএলভিএম এর এক্স00 এক্স এবং এক্স01 এক্স থেকে উত্তোলন করা হয়েছিল, তারপরে রেজিস্ট্রার সংজ্ঞা টেবিলের মাধ্যমে DWARF রেজিস্টার নম্বরগুলিতে ম্যাপ করা হয়েছে (সাধারণত<arch>RegisterInfo.td, এক্স02 এক্স অনুসন্ধান করুন)।
//
// এক্স 100 এক্সও দেখুন।
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // আরএক্স, আরডিএক্স

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// নিম্নলিখিত কোডটি GCC এর সি এবং সি ++ ব্যক্তিত্বের রুটিনের উপর ভিত্তি করে।রেফারেন্সের জন্য, দেখুন:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI ব্যক্তিত্ব রুটিন।
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS এর পরিবর্তে এটি ডিফল্ট রুটিন ব্যবহার করে যেহেতু এটি SjLj আনওয়ন্ডিং ব্যবহার করে।
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // এআরএম-এ ব্যাকট্রেসগুলি রাষ্ট্রের সাথে ব্যক্তিত্বের রুটিনকে কল করবে==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND।
                // এই ক্ষেত্রে আমরা স্ট্যাকটি আনওয়াইন্ডিং চালিয়ে যেতে চাই, অন্যথায় আমাদের সমস্ত পশ্চাদপদগুলি __rust_try এ শেষ হবে
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF আনভিন্ভার ধরে নিয়েছে যে _উন্ডইন্ড_ কনটেক্সট ফাংশন এবং এলএসডিএ পয়েন্টারগুলির মতো জিনিস রাখে, তবে এআরএম এহাবি এগুলি ব্যতিক্রম বস্তুতে রাখে।
            // _Unwind_GetLanguageSpecificData() এর মতো ক্রিয়াকলাপগুলির স্বাক্ষর সংরক্ষণের জন্য, যা কেবল প্রসঙ্গ পয়েন্টার নেয়, জেড 0 জিসিসি 0 জেড পার্সোনালিটি রুটিনগুলি এআরএম এর এক্স02 এক্স এক্স00 এক্সের জন্য সংরক্ষিত অবস্থানটি ব্যবহার করে, প্রসঙ্গে প্রেরণে ব্যতিক্রমী পয়েন্টারে একটি পয়েন্টারকে স্ট্যাশ করে।
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... আরও নীতিগত পন্থাটি হ'ল আমাদের লাইবউন্ড বাইন্ডিংগুলিতে এআরএম এর _উইনউইন্ড_সংশোধনের সম্পূর্ণ সংজ্ঞা প্রদান করা এবং DWARF সামঞ্জস্যতা ফাংশনগুলিকে বাইপাস করে সেখান থেকে সরাসরি প্রয়োজনীয় তথ্য আনা।
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI ব্যতিক্রম বস্তুর বাধা ক্যাশে এসপি মান আপডেট করার জন্য ব্যক্তিত্বের রুটিন প্রয়োজন requires
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // এআরএম এএইচবিআইতে ব্যক্তিত্বের রুটিনটি আসলে ফিরে আসার আগে একটি একক স্ট্যাক ফ্রেমটি আনওয়াইন্ড করার জন্য দায়ী (এআরএম এএহবিআই সেকেন্ড)।
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc সংজ্ঞায়িত
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ডিফল্ট ব্যক্তিত্বের রুটিন, যা বেশিরভাগ লক্ষ্যমাত্রায় এবং অপ্রত্যক্ষভাবে এসইএইচ এর মাধ্যমে Windows x86_64 এ ব্যবহৃত হয়।
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW লক্ষ্যবস্তুগুলিতে, আনইন্ডিং মেকানিজমটি এসইএইচ হয় তবে আনইন্ডিং হ্যান্ডলার ডেটা (ওরফে এলএসডিএ) GCC-সামঞ্জস্যপূর্ণ এনকোডিং ব্যবহার করে।
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // আমাদের বেশিরভাগ লক্ষ্যবস্তুর জন্য ব্যক্তিত্বের রুটিন।
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // কল নির্দেশের আগে ফিরতি ঠিকানা পয়েন্ট 1 বাইট, যা এলএসডিএ রেঞ্জ সারণীতে পরবর্তী আইপি পরিসরে থাকতে পারে।
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ফ্রেমটি অনির্দিষ্ট তথ্য নিবন্ধকরণ
//
// প্রতিটি মডিউলের চিত্রটিতে একটি ফ্রেম আনওয়াইন্ড তথ্য বিভাগ থাকে (সাধারণত ".eh_frame")।যখন কোনও মডিউল প্রক্রিয়াটিতে loaded/unloaded হয়, আনভিন্ভারকে মেমরিতে এই বিভাগের অবস্থান সম্পর্কে অবহিত করতে হবে।প্ল্যাটফর্মের দ্বারা পৃথক হওয়া অর্জনের পদ্ধতিগুলি।
// কিছু (উদাহরণস্বরূপ, Linux), আনউইন্ডার নিজে থেকে আনইন্ড ইনফরমেশন বিভাগগুলি আবিষ্কার করতে পারে (এক্স00 এক্স এর মাধ্যমে বর্তমানে লোড হওয়া মডিউলগুলিকে গতিশীলভাবে গণনা করে; এক্স, এক্স এক্স এর মতো অন্যদের আনউইন্ডির এপিআইয়ের মাধ্যমে আন-ওয়াইন্ড তথ্য বিভাগগুলিকে সক্রিয়ভাবে নিবন্ধকরণ করার জন্য মডিউলগুলি প্রয়োজন।
//
//
// এই মডিউলটি দুটি প্রতীককে সংজ্ঞায়িত করে যা GCC রানটাইমের সাথে আমাদের তথ্য নিবন্ধ করার জন্য rsbegin.rs থেকে রেফারেন্স করা হয়েছে এবং কল করা হয়েছে।
// স্ট্যাক আনওয়াইন্ডিংয়ের বাস্তবায়নটি (আপাতত) libgcc_eh এ স্থগিত করা হয়েছে, তবে Rust crates কোনও GCC রানটাইমের সাথে সম্ভাব্য সংঘর্ষ এড়াতে এই Rust-নির্দিষ্ট এন্ট্রি পয়েন্টগুলি ব্যবহার করুন।
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}