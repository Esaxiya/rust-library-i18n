//! *Wasm32* টার্গেটের জন্য আনওয়ানডিং।
//!
//! এখনই আমরা এটি সমর্থন করি না, সুতরাং এটি কেবল স্টাবস ub

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}