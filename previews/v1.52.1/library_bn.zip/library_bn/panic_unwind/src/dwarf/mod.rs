//! DWARF-এনকোডড ডেটা স্ট্রিমগুলি পার্স করার জন্য ইউটিলিটিস।
//! <http://www.dwarfstd.org>, DWARF-4 স্ট্যান্ডার্ড, বিভাগ 7, "Data Representation" দেখুন
//!

// এই মডিউলটি এখনই কেবল x86_64-pc-Windows-gnu দ্বারা ব্যবহৃত হয়েছে তবে আমরা এগ্রেশনগুলি এড়াতে সর্বত্র এটি সংকলন করছি।
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF স্ট্রিমগুলি প্যাক করা হয়েছে, সুতরাং উদাহরণস্বরূপ, একটি u32 অগত্যা 4-বাইট সীমানায় সারিবদ্ধ হবে না।
    // এটি কঠোর প্রান্তিককরণের প্রয়োজনীয়তা সহ প্ল্যাটফর্মগুলিতে সমস্যা সৃষ্টি করতে পারে।
    // একটি "packed" স্ট্রাক্টে ডেটা মোড়ানো দ্বারা, আমরা ব্যাকএন্ডকে "misalignment-safe" কোড উত্পন্ন করতে বলছি।
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 এবং SLEB128 এনকোডিংগুলি বিভাগ 7.6, "Variable Length Data" এ সংজ্ঞায়িত করা হয়েছে।
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}