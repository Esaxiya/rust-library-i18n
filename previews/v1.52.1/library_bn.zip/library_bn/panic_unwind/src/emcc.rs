//! *এমস্ক্রিপ্টেন* টার্গেটের জন্য আনওয়াইন্ডিং।
//!
//! যেখানে Rust এর Unix প্ল্যাটফর্মের জন্য সাধারণ আনওয়ানডিং বাস্তবায়ন সরাসরি লাইবুনউইন্ড এপিআইগুলিতে সরাসরি কল করে, এমস্ক্রিপ্টে আমরা পরিবর্তে সি ++ আনওয়াইন্ডিং এপিআইগুলিতে কল করি।
//! এটি কেবলমাত্র একটি এক্সপিলিয়েন্স, যেহেতু এমস্ক্রিপ্টেনের রানটাইম সবসময় API সমস্ত এপিআই প্রয়োগ করে এবং লাইবুনউইন্ড প্রয়োগ করে না।
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// এটি সি ++ এ std::type_info এর বিন্যাসের সাথে মেলে
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // এখানে শীর্ষস্থানীয় এক্স 100 এক্স বাইটটি আসলে এলএলভিএমকে একটি এক্স 01 এক্স অক্ষরের সাথে উপসর্গের মতো অন্য কোনও ম্যাংলিং প্রয়োগ করতে *নয়* করার জন্য একটি যাদু সংকেত।
    //
    //
    // এই প্রতীকটি সি ++ এর এক্স 100 এক্স দ্বারা ব্যবহৃত vtable।
    // `std::type_info` প্রকারের অবজেক্টস, টাইপ বর্ণনাকারীগুলির এই টেবিলটিতে একটি পয়েন্টার রয়েছে।
    // প্রকার বর্ণনাকারী উপরে বর্ণিত সি ++ ইএইচ কাঠামোগুলি দ্বারা উল্লেখ করা হয় এবং আমরা নীচে এটি নির্মাণ করি।
    //
    // মনে রাখবেন যে আসল আকারটি 3 ইউজির চেয়ে বড়, তবে তৃতীয় উপাদানটির দিকে নির্দেশ করার জন্য আমাদের কেবল আমাদের টেবিলের প্রয়োজন।
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info একটি জং_প্যানিক ক্লাসের জন্য
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // সাধারণত আমরা .as_ptr().add(2) ব্যবহার করব তবে এটি কোনও কনস্ট কনটেক্সটে কাজ করে না।
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // এটি ইচ্ছাকৃতভাবে সাধারণ নামের ম্যাংলিং স্কিমটি ব্যবহার করে না কারণ আমরা চাই না যে সি ++ জেড 0 রিস্ট0 জেড জেডপ্যানিক্স0 জেড উত্পাদন করতে বা ধরতে সক্ষম হোক।
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // এটি প্রয়োজনীয় কারণ সি ++ কোডটি এক্স এক্সএক্সএক্সের সাহায্যে আমাদের এক্সিকিউশনটি ক্যাপচার করতে পারে এবং একাধিকবার এটি পুনরায় বিতরণ করতে পারে, সম্ভবত অন্য থ্রেডেও।
    //
    //
    caught: AtomicBool,

    // এটি একটি অপশন হওয়া দরকার কারণ অবজেক্টটির জীবনকাল সি ++ শব্দার্থবিজ্ঞানের অনুসরণ করে: যখন ক্যাচ_উনউইন্ড বাক্সটিকে ব্যতিক্রমের বাইরে নিয়ে যায় তখন অবশ্যই এটি ব্যতিক্রম অবজেক্টটিকে একটি বৈধ অবস্থায় ফেলে দিতে হবে কারণ এর ডেস্ট্রাক্টর এখনও __cxa_end_catch দ্বারা ডাকা হতে চলেছে।
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try আসলে আমাদের এই কাঠামোর একটি পয়েন্টার দেয়।
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // যেহেতু cleanup() panic এর অনুমতি নেই, আমরা কেবল তার পরিবর্তে গর্ভপাত বাতিল করব।
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}