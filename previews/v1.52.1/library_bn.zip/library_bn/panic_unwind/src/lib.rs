//! আনয়নিংয়ের স্ট্যাকের মাধ্যমে panics বাস্তবায়ন
//!
//! এই জেড 0 ক্রেট0 জেডটি Rust এ জেড 0 প্যানিক্স 0 জেড এর একটি বাস্তবায়ন যা প্ল্যাটফর্মটির জন্য এটি সঙ্কলিত করা হচ্ছে "most native" স্ট্যাক আনওয়ানডিং প্রক্রিয়া ব্যবহার করে।
//! এটি বর্তমানে তিনটি বালতিতে মূলত শ্রেণীবদ্ধ করা হয়েছে:
//!
//! 1. এমএসভিসি লক্ষ্যবস্তুগুলি `seh.rs` ফাইলে এসএইচ ব্যবহার করে।
//! 2. এমস্ক্রিপ্টন `emcc.rs` ফাইলে C++ ব্যতিক্রম ব্যবহার করে।
//! 3. অন্যান্য সমস্ত লক্ষ্যগুলি `gcc.rs` ফাইলে libunwind/libgcc ব্যবহার করে।
//!
//! প্রতিটি বাস্তবায়ন সম্পর্কে আরও ডকুমেন্টেশন সংশ্লিষ্ট মডিউলে পাওয়া যাবে।
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` মিরির সাথে অব্যবহৃত, তাই নীরব সতর্কতা।
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust রানটাইমের স্টার্টআপ অবজেক্টগুলি এই চিহ্নগুলির উপর নির্ভর করে, তাই তাদের সর্বজনীন করুন।
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // টার্গেটগুলি যা অবাঞ্ছিত সমর্থন করে না।
        // - arch=wasm32
        // - OS=কিছুই নয় ("bare metal" লক্ষ্য)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // মিরির রানটাইম ব্যবহার করুন।
        // আমাদের এখনও উপরে সাধারণ রানটাইমটি লোড করতে হবে, কারণ জেড 0 রিস্ট্রক0 জেড সেখান থেকে নির্দিষ্ট ল্যাং আইটেম সংজ্ঞায়িত হওয়ার প্রত্যাশা করে।
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // আসল রানটাইম ব্যবহার করুন।
        use real_imp as imp;
    }
}

extern "C" {
    /// একটি panic অবজেক্টটি `catch_unwind` এর বাইরে ফেলে দেওয়া হলে libstd এ হ্যান্ডলার বলা হয়।
    ///
    fn __rust_drop_panic() -> !;

    /// বিদেশী ব্যতিক্রম ধরা পড়লে লিবিডডিতে হ্যান্ডলারকে ডাকা হয়।
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// ব্যতিক্রম বাড়াতে প্রবেশের পয়েন্ট, প্ল্যাটফর্ম-নির্দিষ্ট প্রয়োগের জন্য কেবল প্রতিনিধিরা।
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}