//! Windows SEH
//!
//! Windows-এ (বর্তমানে কেবলমাত্র এমএসভিসিতে), ডিফল্ট ব্যতিক্রম হ্যান্ডলিং প্রক্রিয়াটি স্ট্রাকচার্ড ব্যতিক্রম হ্যান্ডলিং এক্স00 এক্স 00
//! এটি বামন ভিত্তিক ব্যতিক্রম হ্যান্ডলিংয়ের তুলনায় একেবারেই আলাদা (যেমন, এক্সএক্সএক্স এক্স প্ল্যাটফর্মগুলি কী ব্যবহার করে) সংকলক ইন্টার্নালগুলির ক্ষেত্রে, তাই এলএইচভিএমকে এসইএইচ জন্য অতিরিক্ত সহায়তার জন্য ভাল প্রয়োজন।
//!
//! সংক্ষেপে, এখানে যা ঘটে তা হ'ল:
//!
//! 1. এক্স 100 এক্স ফাংশনটি এক্স-1x এক্স ফাংশনটি এক্স02 এক্সকে একটি সি ++ নিক্ষেপ করতে অনুরোধ করে-ব্যতিক্রমের মতো, আনইন্ডিং প্রক্রিয়াটিকে ট্রিগার করে।
//! 2.
//! সংকলক দ্বারা উত্পন্ন সমস্ত ল্যান্ডিং প্যাডগুলি ব্যাক্তিগত ফাংশন `__CxxFrameHandler3`, সিআরটি-র একটি ফাংশন এবং এক্স01 এক্স-এ আনইন্ডিং কোড ব্যবহার করে স্ট্যাকের সমস্ত ক্লিনআপ কোড কার্যকর করতে এই ব্যক্তিত্ব ফাংশনটি ব্যবহার করবে।
//!
//! 3. `invoke`-এ সমস্ত সংকলক-উত্পন্ন কলগুলিতে একটি ল্যান্ডিং প্যাড রয়েছে একটি `cleanuppad` এলএলভিএম নির্দেশ হিসাবে সেট করুন, যা ক্লিনআপ রুটিনের সূচনা নির্দেশ করে।
//! ব্যক্তিত্ব (সিআরটি সংজ্ঞায়িত দ্বিতীয় ধাপে) ক্লিনআপ রুটিনগুলি চালনার জন্য দায়ী।
//! 4. অবশেষে `try` অন্তর্নিহিত (সংকলক দ্বারা উত্পাদিত) মধ্যে "catch" কোডটি কার্যকর হয় এবং নির্দেশ দেয় যে নিয়ন্ত্রণটি Rust এ ফিরে আসা উচিত।
//! এটি একটি `catchswitch` প্লাস দ্বারা একটি `catchpad` নির্দেশের মাধ্যমে এলএলভিএম আইআর শর্তাদির মাধ্যমে করা হয়, শেষ পর্যন্ত এক্স02 এক্স নির্দেশের মাধ্যমে প্রোগ্রামটিতে স্বাভাবিক নিয়ন্ত্রণ ফিরে আসে।
//!
//! gcc-ভিত্তিক ব্যতিক্রম হ্যান্ডলিং থেকে কিছু নির্দিষ্ট পার্থক্য হ'ল:
//!
//! * Rust এর কোনও কাস্টম ব্যক্তিত্বের ফাংশন নেই, এটি সর্বদা *সর্বদা*`__CxxFrameHandler3`।অতিরিক্তভাবে, কোনও অতিরিক্ত ফিল্টারিং সঞ্চালিত হয় না, তাই আমরা যে ধরনের সি ++ ব্যতিক্রম ছুঁড়ে ফেলি তার মতো দেখতে আমরা শেষ করি।
//! নোট করুন যে Rust এ ব্যতিক্রম ছুঁড়ে ফেলা কোনওভাবেই সংজ্ঞায়িত আচরণ, সুতরাং এটি ঠিক করা উচিত।
//! * আমরা উইন্ডোন্ডিং সীমানা জুড়ে প্রেরণ করার জন্য কিছু ডেটা পেয়েছি, বিশেষত একটি এক্স 100 এক্স।বামন ব্যতিক্রমগুলির মতো এই দুটি পয়েন্টার ব্যতিক্রমের মধ্যেই পেডলোড হিসাবে সঞ্চিত হয়।
//! এমএসভিসিতে, তবে অতিরিক্ত গাদা বরাদ্দের দরকার নেই কারণ ফিল্টার ফাংশনগুলি সম্পাদন করার সময় কল স্ট্যাক সংরক্ষণ করা হয়।
//! এর অর্থ এই যে পয়েন্টারগুলি সরাসরি `_CxxThrowException` এ পৌঁছে যায় যা ফিল্টার ফাংশনে পুনরুদ্ধার হয়ে এক্স01 এক্স ইন্টারসনিকের স্ট্যাক ফ্রেমে লিখিত হয়।
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // এটি একটি বিকল্প হওয়া দরকার কারণ আমরা রেফারেন্স অনুসারে ব্যতিক্রমটি ধরি এবং এর ডেস্ট্রাক্টর সি ++ রানটাইম দ্বারা কার্যকর করা হয়।
    // বাক্সটি যখন আমরা ব্যতিক্রম থেকে বাইরে নিয়ে যাই, তখন বাক্সটিকে ডাবল-ড্রপ না করে চালকরা তার ধ্বংসকারীকে চালানোর জন্য আমাদের ব্যতিক্রমটি একটি বৈধ অবস্থায় রেখে যেতে হবে।
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// প্রথমত, ধরণের সংজ্ঞাগুলির পুরো গুচ্ছ।এখানে কয়েকটি প্ল্যাটফর্ম-নির্দিষ্ট অদ্ভুততা রয়েছে এবং এমন অনেক কিছুই যা এলএলভিএম থেকে কেবল নির্লজ্জভাবে অনুলিপি করা হয়েছিল।এই সমস্তটির উদ্দেশ্য হ'ল `_CxxThrowException` এ কলের মাধ্যমে নীচে `panic` ফাংশনটি বাস্তবায়ন করা।
//
// এই ফাংশন দুটি আর্গুমেন্ট লাগে।প্রথমটি হ'ল আমরা যে ডেটাটিতে যাচ্ছি তার দিকে একটি পয়েন্টার, যা এই ক্ষেত্রে আমাদের trait অবজেক্ট।খুঁজে পাওয়া খুব সহজ!পরেরটি অবশ্য আরও জটিল।
// এটি একটি `_ThrowInfo` কাঠামোর একটি পয়েন্টার এবং এটি সাধারণত কেবল ব্যতিক্রম নিক্ষেপ করা হচ্ছে তা বর্ণনা করার উদ্দেশ্যে।
//
// বর্তমানে এই ধরণের [1] এর সংজ্ঞাটি কিছুটা লোমশ, এবং প্রধান বিজোড়তা (এবং অনলাইন নিবন্ধ থেকে পার্থক্য) হ'ল 32-বিটের উপরে পয়েন্টারগুলি পয়েন্টার হয় তবে 64৪-বিট-তে পয়েন্টারগুলি 32-বিট অফসেট হিসাবে প্রকাশিত হয় `__ImageBase` প্রতীক।
//
// নীচের মডিউলগুলিতে `ptr_t` এবং `ptr!` ম্যাক্রো এটি প্রকাশ করতে ব্যবহৃত হয়।
//
// প্রকারের সংজ্ঞাগুলির গোলকধাঁধাটি এলএলভিএম এই ধরণের ক্রিয়াকলাপের জন্য কীভাবে নির্গত হয় তা নিবিড়ভাবে অনুসরণ করে।উদাহরণস্বরূপ, আপনি যদি এমএসভিসিতে এই সি ++ কোডটি সংকলন করেন এবং এলএলভিএম আইআর নিঃসরণ করেন:
//
//      #include <stdint.h>
//
//      কাঠামো মরিচা_প্যানিক {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      অকার্যকর foo() { rust_panic a = {0, 1};
//          নিক্ষেপ করা;}
//
// এটি মূলত যা আমরা অনুকরণ করার চেষ্টা করছি।নীচের বেশিরভাগ ধ্রুবক মানগুলি কেবলমাত্র এলএলভিএম থেকে অনুলিপি করা হয়েছিল,
//
// যাই হোক না কেন, এই কাঠামোগুলি সব একইভাবে নির্মিত হয়, এবং এটি আমাদের জন্য কিছুটা ভার্জোজ।
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// মনে রাখবেন যে আমরা এখানে ইচ্ছাকৃতভাবে নাম ম্যাংলিংয়ের নিয়মগুলি উপেক্ষা করছি: আমরা চাই না যে C++ কেবল একটি `struct rust_panic` ঘোষণা করে Rust panics ধরতে সক্ষম হবে।
//
//
// সংশোধন করার সময়, নিশ্চিত হয়ে নিন যে টাইপ নামের স্ট্রিংটি `compiler/rustc_codegen_llvm/src/intrinsic.rs` এ ব্যবহৃত একটির সাথে ঠিক মিলছে।
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // এখানে শীর্ষস্থানীয় এক্স 100 এক্স বাইটটি আসলে এলএলভিএমকে একটি এক্স 01 এক্স অক্ষরের সাথে উপসর্গের মতো অন্য কোনও ম্যাংলিং প্রয়োগ করতে *নয়* করার জন্য একটি যাদু সংকেত।
    //
    //
    // এই প্রতীকটি সি ++ এর এক্স 100 এক্স দ্বারা ব্যবহৃত vtable।
    // `std::type_info` প্রকারের অবজেক্টস, টাইপ বর্ণনাকারীগুলির এই টেবিলটিতে একটি পয়েন্টার রয়েছে।
    // প্রকার বর্ণনাকারী উপরে বর্ণিত সি ++ ইএইচ কাঠামোগুলি দ্বারা উল্লেখ করা হয় এবং আমরা নীচে এটি নির্মাণ করি।
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// এই ধরণের বর্ণনাকারী কেবলমাত্র ব্যতিক্রম ছোঁড়ার সময় ব্যবহৃত হয়।
// ক্যাচ অংশটি ট্রান্স ইন্টারনসিক দ্বারা পরিচালিত হয়, যা এটির নিজস্ব টাইপডেস্কিটার তৈরি করে।
//
// এমএসভিসি রানটাইম পয়েন্টার সমতার চেয়ে টাইপডেস্ক্রিপ্টরের সাথে মেলে টাইপ নামের উপর স্ট্রিং তুলনা ব্যবহার করে এটি ঠিক আছে।
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// সি ++ কোড ব্যতিক্রম ক্যাপচার এবং প্রচার না করে এটিকে ফেলে দেওয়ার সিদ্ধান্ত নিলে ডেস্ট্রাক্টর ব্যবহৃত হয়।
// ট্রান্স ইন্টারস্টিকের ক্যাচ অংশটি ব্যতিক্রমের প্রথম শব্দের 0 তে সেট করবে যাতে এটি ডেস্ট্রাক্টর এড়িয়ে যায়।
//
// দ্রষ্টব্য যে x86 Windows ডিফল্ট "C" কলিং কনভেনশনের পরিবর্তে সি ++ সদস্য ফাংশনের জন্য এক্স02 এক্স কলিং কনভেনশন ব্যবহার করে।
//
// ব্যতিক্রম_কপি ফাংশনটি এখানে কিছুটা বিশেষ: এটি এমএসভিসি রানটাইম দ্বারা একটি try/catch ব্লকের অধীনে আমন্ত্রণ জানানো হয়েছে এবং আমরা এখানে যে জেড 0 স্প্যানিক0 জেড উত্পন্ন করি তা ব্যতিক্রম অনুলিপিটির ফলাফল হিসাবে ব্যবহৃত হবে।
//
// এটি std::exception_ptr এর ব্যতিক্রম ক্যাপচার সমর্থন করতে সি ++ রানটাইম দ্বারা ব্যবহৃত হয়, যা আমরা বক্সের কারণে সমর্থন করতে পারি না<dyn Any>ক্লোনযোগ্য নয়
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException এই স্ট্যাক ফ্রেমে পুরোপুরি কার্যকর করে, তাই অন্যথায় `data` কে গাদাতে স্থানান্তর করার দরকার নেই।
    // আমরা এই ফাংশনটিতে কেবল একটি স্ট্যাক পয়েন্টারটি পাস করি।
    //
    // ম্যানুয়ালিড্রপ এখানে প্রয়োজনীয় যেহেতু আমরা চাই না আনইন্ডিংয়ের সময় এক্সেসপশন বাদ দেওয়া।
    // পরিবর্তে এটি C++ রানটাইম দ্বারা চালিত ব্যতিক্রম_ক্যালানআপ দ্বারা বাদ দেওয়া হবে।
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // এটি ... আশ্চর্যজনক এবং ন্যায়সঙ্গতভাবে মনে হতে পারে।32-বিট এমএসভিসি-তে এই কাঠামোর মধ্যে পয়েন্টার কেবলমাত্র, পয়েন্টার।
    // 64৪-বিট এমএসভিসি-তে, তবে, কাঠামোর মধ্যে পয়েন্টারগুলি `__ImageBase` থেকে 32-বিট অফসেট হিসাবে প্রকাশ করা হয়েছে।
    //
    // ফলস্বরূপ, 32-বিট এমএসভিসি-তে আমরা উপরের `স্ট্যাটিকগুলিতে এই সমস্ত পয়েন্টারগুলি ঘোষণা করতে পারি।
    // - ৪-বিট এমএসভিসি-তে, আমাদের স্ট্যাটিকগুলিতে পয়েন্টারগুলির বিয়োগকে প্রকাশ করতে হবে, যা জেড 0 রিস্ট0 জেড বর্তমানে মঞ্জুরি দেয় না, তাই আমরা আসলে এটি করতে পারি না।
    //
    // পরবর্তী সর্বোত্তম জিনিস, তারপরে রানটাইমের সময় এই কাঠামোগুলি পূরণ করা (আতঙ্কিত হওয়া ইতিমধ্যে "slow path" যাইহোক)।
    // সুতরাং এখানে আমরা এই সমস্ত পয়েন্টার ক্ষেত্রগুলিকে 32-বিট পূর্ণসংখ্যার হিসাবে পুনরায় ব্যাখ্যা করি এবং তারপরে প্রাসঙ্গিক মানটি সংরক্ষণ করি (পরমাণু হিসাবে, সমবর্তী panics ঘটতে পারে)।
    //
    // প্রযুক্তিগতভাবে রানটাইম সম্ভবত এই ক্ষেত্রগুলির একটি ননোটমিক পড়বে, তবে তাত্ত্বিকভাবে তারা কখনই *ভুল* মানটি পড়ে না তাই এটি খুব খারাপ হওয়া উচিত নয় ...
    //
    // যাই হোক না কেন, স্ট্যাটিক্সে আরও ক্রিয়াকলাপ প্রকাশ না করা পর্যন্ত আমাদের মূলত এ জাতীয় কিছু করা প্রয়োজন (এবং আমরা কখনই সক্ষম হতে পারি না)।
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // এখানে একটি নুল পে-লোডের অর্থ হ'ল আমরা এখানে___রাস্ট_ট্রি এর (...) ধরা থেকে পেয়েছি।
    // একটি Z-Rust0Z বিদেশী ব্যতিক্রম ধরা পড়লে এটি ঘটে।
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// এটি সংকলকটির অস্তিত্বের জন্য প্রয়োজন (যেমন, এটি কোনও ল্যাং আইটেম) তবে এটি কখনই সংকলক বলে না কারণ __C_specific_handler বা _except_handler3 হ'ল ব্যাক্তিত্বের ফাংশন যা সর্বদা ব্যবহৃত হয়।
//
// অতএব এটি কেবল একটি বিসর্জনযোগ্য স্টাব।
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}