// rsbegin.o এবং এক্স0 এক্স এক্স কথিত এক্স 100 এক্স।
// সংকলক রানটাইমটি সঠিকভাবে শুরু করার জন্য এগুলিতে কোড রয়েছে।
//
// যখন একটি এক্সিকিউটেবল বা ডাইলিব চিত্র যুক্ত হয়, সমস্ত ব্যবহারকারী কোড এবং গ্রন্থাগারগুলি এই দুটি অবজেক্ট ফাইলের মধ্যে "sandwiched" হয়, সুতরাং rsbegin.o এর কোড বা ডেটা চিত্রের সংশ্লিষ্ট বিভাগে প্রথম হয়ে যায়, যেখানে rsend.o থেকে কোড এবং ডেটা শেষ হয়ে যায়।
// এই প্রভাবটি শুরুতে বা কোনও বিভাগের শেষে চিহ্নগুলি রাখার পাশাপাশি কোনও প্রয়োজনীয় শিরোনাম বা পাদচরণ সন্নিবেশ করতে ব্যবহার করা যেতে পারে।
//
// নোট করুন যে আসল মডিউল এন্ট্রি পয়েন্টটি সি রানটাইম স্টার্টআপ অবজেক্টে (সাধারণত `crtX.o` বলা হয়) অবস্থিত, যা অন্য রানটাইম উপাদানগুলির আরম্ভকৃত কলব্যাকগুলি আহ্বান করে (অন্য একটি বিশেষ চিত্র বিভাগের মাধ্যমে নিবন্ধিত)।
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // স্ট্যাক ফ্রেমের আনওয়াইন্ড তথ্য বিভাগের শুরু চিহ্নিত করে
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // আনভিন্ভারের অভ্যন্তরীণ বইয়ের জন্য স্ক্র্যাচ স্পেস space
    // এটি `struct object` হিসাবে CC GCC/unwind-dw2-fde.h এ সংজ্ঞায়িত করা হয়েছে।
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // এক্স-এক্স এক্স রুটিনগুলি উন্মুক্ত করুন।
    // লিপ্প্যানিক_উইনবাইন্ডের ডক্স দেখুন।
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // মডিউল প্রারম্ভের সময় আনইন্ড উইন্ডোর তথ্য নিবন্ধ করুন
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // শাটডাউনে নিবন্ধন করুন
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-নির্দিষ্ট init/uninit রুটিন রেজিস্ট্রেশন
    pub mod mingw_init {
        // MinGW এর স্টার্টআপ অবজেক্টস (crt0.o/dllcrt0.o) .ctors এবং .dtors বিভাগে গ্লোবাল কনস্ট্রাক্টরদের স্টার্টআপ এবং প্রস্থান করার জন্য অনুরোধ করবে।
        // ডিএলএলগুলির ক্ষেত্রে, যখন ডিএলএল লোড এবং লোড করা হয় তখন এটি করা হয়।
        //
        // লিঙ্কারটি বিভাগগুলি বাছাই করবে, যা আমাদের কলব্যাকগুলি তালিকার শেষে অবস্থিত তা নিশ্চিত করে।
        // যেহেতু কনস্ট্রাক্টরগুলি বিপরীত ক্রমে চালিত হয়, এটি নিশ্চিত করে যে আমাদের কলব্যাকগুলি প্রথম এবং শেষটি কার্যকর করা হয়েছে।
        //
        //

        #[link_section = ".ctors.65535"] // .ctors। *: সি আরম্ভের কলব্যাক
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors। *: সি টার্মিনেশন কলব্যাক্স
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}