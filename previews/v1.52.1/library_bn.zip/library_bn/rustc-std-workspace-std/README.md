# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate এর জন্য ডকুমেন্টেশন দেখুন।