//! এক্স 100 এক্স ম্যাক্রোর বাস্তবায়ন
//!
//! `stdarch` crate পরীক্ষা করার সময় এই ম্যাক্রো ব্যবহার করা হয় এবং পরীক্ষার কেসগুলি উত্পন্ন করতে ব্যবহৃত হয় যে ফাংশনগুলিতে সত্যিকার অর্থে আমরা যে নির্দেশনাগুলি সেগুলি রাখার প্রত্যাশা করে তা ধারণ করে।
//!
//! এখানে কার্যনির্বাহী ম্যাক্রো তুলনামূলকভাবে সহজ, এটি কেবলমাত্র token স্ট্রিমের সাথে একটি `#[test]` ফাংশন যুক্ত করে যা ফাংশনটি নিজেই প্রাসঙ্গিক নির্দেশনা রয়েছে বলে দাবি করে।
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // অ্যাভেক্স সক্ষমের সাথে সংকলিত x86 টার্গেটের জন্য assert_instr কে অক্ষম করুন, যার কারণে আমরা LLVM এর জন্য বিভিন্ন পরীক্ষা নিরীক্ষা করছি যা আমরা পরীক্ষা করছি।
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // যদি নির্দেশাবলী পরীক্ষাগুলি অক্ষম থাকে তবে এই শিমটি একেবারে নির্গত হওয়া এড়াতে, কেবল আমাদের অ্যাট্রিবিটি ব্যতীত মূল আইটেমটি ফিরিয়ে দিন।
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // এই নামটি পরে এটিকে ছিন্নমূল করার জন্য আমাদের পক্ষে যথেষ্ট অনন্য হতে হবে:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // ডিফল্টরূপে Unix (আমার মনে হয়?) এ যা ঘটে তা যেমন রেজিস্টারগুলিতে সিমডি মানগুলি পাস করে এমন Windows এ এমন একটি এবিআই ব্যবহার করুন।
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ডিফল্টরূপে অনুকূলিত মোডে সংকলকটি "mergefunc" নামে একটি পাস চালায় যেখানে এটি অভিন্ন দেখায় এমন ফাংশনগুলি মার্জ করবে।
            // কিছু অন্তর্নির্ভর অভিন্ন কোড তৈরি করে এবং সেগুলি একসাথে ভাঁজ হয়, যার অর্থ একটি কেবল অন্যটিতে লাফ দেয়।
            // এটি এই ফাংশনটি ছিন্ন করার বিষয়ে আমাদের পরিদর্শনকে বিশৃঙ্খলা করে এবং আমরা এর বিশাল ভক্ত নই।
            //
            // এই পাসটিকে ব্যর্থ করতে এবং ফাংশনগুলিকে একীভূত হতে আটকাতে আমরা এমন কিছু কোড উত্পন্ন করি যা আশা করি কোডজেনের ক্ষেত্রে খুব শক্ত কিন্তু কোডটি ভাঁজ হওয়া থেকে রোধ করার জন্য অন্যথায় অনন্য।
            //
            //
            // এই মুহুর্তে Wasm32 এ এড়ানো হয়েছে যেহেতু এই ফাংশনগুলি ইনলাইন করা হয়নি যা আমাদের পরীক্ষাগুলি ভঙ্গ করে যেহেতু প্রতিটি অন্তর্হীন দেখায় যে এটি ফাংশনগুলি বলে calls
            // সক্রিয় ফাংশনগুলি যাইহোক wasm32 এ একত্রিত হওয়ার জন্য যথেষ্ট সমান নয়।
            // এই বাগটি rust-lang/rust#74320 এ ট্র্যাক করা হয়েছে।
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}