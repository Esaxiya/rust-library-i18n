#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_READ: i32 = 0;

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_WRITE: i32 = 1;

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// এক্স 100 এক্স দেখুন।
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// প্রদত্ত `rw` এবং `locality` ব্যবহার করে `p` ঠিকানাযুক্ত ক্যাশে রেখাটি আনুন।
///
/// `rw` অবশ্যই একটি হতে হবে:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): উপসাগর একটি পড়ার জন্য প্রস্তুত করা হয়।
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): উপসাগর একটি লেখার জন্য প্রস্তুতি নিচ্ছে।
///
/// `locality` অবশ্যই একটি হতে হবে:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): কেবলমাত্র একবার ব্যবহার করা হয় এমন ডেটার জন্য স্ট্রিমিং বা অ-অস্থায়ী প্রিফেচ।
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): স্তর 3 ক্যাশে আনুন।
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): স্তর 2 ক্যাশে আনুন।
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): স্তর 1 ক্যাশে আনুন।
///
/// প্রিফেচ মেমরির নির্দেশাবলী মেমরি সিস্টেমে সিগন্যাল করে যে একটি নির্দিষ্ট ঠিকানা থেকে মেমরি অ্যাক্সেস করে সম্ভবত future এর কাছাকাছি হতে পারে।
/// মেমরি সিস্টেম এমন ক্রিয়া করে প্রতিক্রিয়া জানাতে পারে যা যখন ঘটে থাকে তখন মেমরি অ্যাক্সেসের গতি বাড়ানোর প্রত্যাশা করা হয়, যেমন এক বা একাধিক ক্যাশে নির্দিষ্ট ঠিকানাটি আগে লোড করা।
///
/// এই সংকেতগুলি কেবলমাত্র ইঙ্গিতগুলির জন্য, কোনও নির্দিষ্ট সিপিইউয়ের জন্য কোনও এনওপি হিসাবে কোনও বা সমস্ত প্রিফেচ নির্দেশাবলী বিবেচনা করা বৈধ।
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // আমরা `cache type` =1 (ডেটা ক্যাশে) সহ `llvm.prefetch` ইনস্ট্রিনসিক ব্যবহার করি।
    // `rw` এবং `strategy` ফাংশন পরামিতিগুলির উপর ভিত্তি করে।
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}