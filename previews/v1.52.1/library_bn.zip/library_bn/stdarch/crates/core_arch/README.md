`core::arch` - Rust এর মূল গ্রন্থাগার আর্কিটেকচার-নির্দিষ্ট অন্তর্নিহিত
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` মডিউল আর্কিটেকচার-নির্ভর আন্তভুক্তি (যেমন সিমডি) প্রয়োগ করে।

# Usage 

`core::arch` `libcore` এর অংশ হিসাবে উপলব্ধ এবং এটি এক্স 100 এক্স দ্বারা পুনরায় রফতানি করা হয়েছে।এই crate এর চেয়ে `core::arch` বা `std::arch` এর মাধ্যমে এটি ব্যবহার পছন্দ করুন।
অস্থির বৈশিষ্ট্যগুলি প্রায়শই `feature(stdsimd)` এর মাধ্যমে রাত্রে জেড 0 রিস্ট0 জেডে উপলভ্য।

এই crate এর মাধ্যমে `core::arch` ব্যবহারের জন্য রাতের বেলা Rust প্রয়োজন, এবং এটি প্রায়শই বিরতি (এবং করতে পারে) করতে পারে।এই crate এর মাধ্যমে কেবলমাত্র এটির ক্ষেত্রে আপনাকে এটি বিবেচনা করা উচিত:

* আপনার যদি নিজেকে `core::arch` পুনরায় সংকলন করা দরকার, উদাহরণস্বরূপ, নির্দিষ্ট টার্গেট-বৈশিষ্ট্যগুলি সক্ষম করা হয়েছে যা `libcore`/`libstd` এর জন্য সক্ষম নয়।
Note: যদি আপনাকে এটি একটি মানহীন টার্গেটের জন্য পুনরায় সংকলন করতে হয় তবে দয়া করে `xargo` ব্যবহার করতে এবং এই জেড 0 ক্রেট 0 জেডটি ব্যবহার না করে `libcore`/`libstd` কে যথাযথ হিসাবে পুনরায় সংকলন করতে পছন্দ করুন।
  
* কিছু বৈশিষ্ট্য ব্যবহার করে যা অস্থির Rust বৈশিষ্ট্যগুলির পিছনেও উপলভ্য নাও হতে পারে।আমরা এগুলি সর্বনিম্ন রাখার চেষ্টা করি।
আপনার যদি এই বৈশিষ্ট্যগুলির কয়েকটি ব্যবহার করার প্রয়োজন হয় তবে দয়া করে একটি সমস্যা খুলুন যাতে আমরা সেগুলি রাতের Rust এ প্রকাশ করতে পারি এবং আপনি সেখান থেকে সেগুলি ব্যবহার করতে পারেন।

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` মূলত এমআইটি লাইসেন্স এবং জেড 0 অ্যাপাচি0 জেড লাইসেন্স (সংস্করণ এক্স 100 এক্স) উভয় শর্তের অধীনে বিতরণ করা হয়, বিভিন্ন বিএসডি-মতো লাইসেন্সের আওতাভুক্ত অংশগুলি।

বিস্তারিত জানার জন্য লিসেনএস-জেড-এপচএইচজেড এবং লিসেনস-এমআইটি দেখুন।

# Contribution

আপনি অন্যথায় স্পষ্টভাবে বিবরণ না দিলে Apache-2.0 লাইসেন্সে সংজ্ঞায়িত হিসাবে আপনার দ্বারা `core_arch` এ অন্তর্ভুক্তির জন্য ইচ্ছাকৃতভাবে জমা দেওয়া কোনও অবদান, কোনও অতিরিক্ত শর্ত বা শর্ত ছাড়াই উপরোক্ত হিসাবে দ্বৈত লাইসেন্সপ্রাপ্ত হবে।


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












