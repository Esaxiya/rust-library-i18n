use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // আমাদের `#[assert_instr]` টীকাটি বলার জন্য ব্যবহৃত হয়েছিল যে সমস্ত কোডযুক্ত কোডগুলি তাদের কোডজেন পরীক্ষা করার জন্য উপলব্ধ, যেহেতু কিছু অতিরিক্ত `-Ctarget-feature=+unimplemented-simd128` এর পিছনে জেটেড রয়েছে যার এখনই `#[target_feature]` এর সমতুল্য নেই।
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}