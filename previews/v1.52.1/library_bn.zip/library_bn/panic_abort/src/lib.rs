//! প্রক্রিয়া অবতরণের মাধ্যমে Rust panics বাস্তবায়ন
//!
//! আনওয়াইন্ডিংয়ের মাধ্যমে বাস্তবায়নের সাথে তুলনা করা হলে, এই জেড 0 ক্রেট0 জেড *অনেক বেশি* সহজ!বলা হচ্ছে, এটি একেবারে বহুমুখী নয়, তবে এখানেও!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" প্রশ্নে প্ল্যাটফর্মে প্রবণতা সম্পর্কিত পেওলোড এবং শিম।
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal কল করুন
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // এক্স 100 এক্স-তে, প্রসেসর-নির্দিষ্ট __رفাইফেল প্রক্রিয়াটি ব্যবহার করুন।Windows 8 এ এবং তারপরে, এটি কোনও প্রক্রিয়া ব্যতিক্রম হ্যান্ডলারগুলি না চালিয়ে তত্ক্ষণাত্ প্রক্রিয়াটি বন্ধ করে দেবে।
            // Windows এর পূর্ববর্তী সংস্করণগুলিতে, নির্দেশাবলীর এই ক্রমটি একটি অ্যাক্সেস লঙ্ঘন হিসাবে বিবেচিত হবে, প্রক্রিয়াটি শেষ করে তবে অগত্যা সমস্ত ব্যতিক্রম হ্যান্ডলারের বাইপাস ছাড়াই।
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: এটি libstd এর `abort_internal` এর মতো একই বাস্তবায়ন
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// এটি ... কিছুটা বিজোড়তা।Tl; dr;এটি সঠিকভাবে লিঙ্ক করা প্রয়োজন যে, দীর্ঘতর বিবরণ নীচে রয়েছে।
//
// এখনই আমরা প্রেরিত libcore/libstd এর বাইনারিগুলি সমস্তই `-C panic=unwind` এর সাথে সংকলিত।বাইনারিগুলি যতটা সম্ভব পরিস্থিতি সর্বাধিক সুসংগত হয় তা নিশ্চিত করার জন্য এটি করা হয়।
// সংকলকটি অবশ্য `-C panic=unwind` এর সাথে সংকলিত সমস্ত ফাংশনের জন্য একটি "personality function" প্রয়োজন।এই ব্যক্তিত্ব ফাংশনটি `rust_eh_personality` প্রতীকটিতে হার্ডকোডযুক্ত এবং `eh_personality` ল্যাং আইটেম দ্বারা সংজ্ঞায়িত করা হয়েছে।
//
// So...
// এখানে শুধু ল্যাং আইটেম সংজ্ঞায়িত করা হয় না কেন?ভাল প্রশ্ন!জেডপ্যানিক0 জেড রানটাইমগুলি যেভাবে সংযুক্ত রয়েছে তা আসলে সংক্ষিপ্ত আকারের কিছুটা সূক্ষ্ম যে তারা কম্পাইলারের জেড0crate0Z স্টোরের "sort of", তবে অন্যটি আসলে লিঙ্কযুক্ত না হলে কেবলমাত্র লিঙ্কযুক্ত।
//
// এটির অর্থ শেষ হয়ে যায় যে এই crate এবং প্যানিক_উনওয়াইন্ড জেড 0crate0Z উভয়ই সংকলকের crate স্টোরটিতে উপস্থিত হতে পারে এবং যদি উভয়ই `eh_personality` ল্যাং আইটেমটি সংজ্ঞায়িত করে তবে এটি একটি ত্রুটি ঘটবে।
//
// এই সংকলকটি হ্যান্ডেল করার জন্য কেবলমাত্র 0panic রানটাইমের সাথে যুক্ত হওয়া অযৌক্তিক রানটাইমটি হ'ল এক্স00 এক্স সংজ্ঞায়িত করা প্রয়োজন, এবং অন্যথায় এটি সংজ্ঞায়িত করার প্রয়োজন নেই (যথাযথভাবে তাই)।
// এই ক্ষেত্রে, তবে, এই গ্রন্থাগারটি কেবল এই প্রতীকটিকে সংজ্ঞায়িত করে তাই কমপক্ষে কোথাও কোথাও না কিছু ব্যক্তিত্ব আছে।
//
// মূলত এই প্রতীকটি কেবলমাত্র libcore/libstd বাইনারি পর্যন্ত ওয়্যার্ড হওয়ার জন্য সংজ্ঞায়িত করা হয়েছে, তবে এটি কখনই ডাকা উচিত নয় কারণ আমরা কোনও অযাচিত রানটাইমটিতে লিঙ্ক করি না।
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-Windows-gnu এ আমরা আমাদের নিজস্ব ব্যক্তিত্ব ফাংশন ব্যবহার করি যা আমাদের সমস্ত ফ্রেমের উপর দিয়ে যাওয়ার সাথে সাথে `ExceptionContinueSearch` ফেরত আসা দরকার।
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // উপরের মতই, এটি বর্তমানে এক্সপ্রেসটিতে কেবল ব্যবহৃত এসএসএক্সএক্স ল্যাং আইটেমের সাথে মিলে যায়।
    //
    // যেহেতু panics ব্যতিক্রমগুলি উত্পন্ন করে না এবং বিদেশী ব্যতিক্রমগুলি বর্তমানে -C panic=বিসর্জন সহ ইউবি হয় (যদিও এটি পরিবর্তনের সাপেক্ষে হতে পারে), কোনও ক্যাচ_উইনবাইন্ড কল কখনই এই টাইপফর্মটি ব্যবহার করবে না।
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // এই দু'জনকেই আমাদের স্টার্টআপ অবজেক্টগুলি i686-pc-Windows-gnu এ ডাকা হয়, তবে দেহগুলি অনাবৃত হয়ে এগুলির জন্য তাদের কিছু করার দরকার নেই।
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}