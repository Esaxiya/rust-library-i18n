# `rustc-std-workspace-core` crate

এই crate একটি শিম এবং খালি crate যা কেবল `libcore` এর উপর নির্ভর করে এবং এর সমস্ত বিষয়বস্তু পুনঃবন্দর করে।
crate হ'ল crates.io থেকে crates এর উপর নির্ভর করতে স্ট্যান্ডার্ড লাইব্রেরিটিকে শক্তিশালীকরণের কৌশল

crates.io-এ Crates যে স্ট্যান্ডার্ড গ্রন্থাগারটি crates.io থেকে `rustc-std-workspace-core` crate এর উপর নির্ভর করতে হবে যা খালি।

আমরা এই সংগ্রহস্থলে এই crate এ ওভাররাইড করতে `[patch]` ব্যবহার করি।
ফলস্বরূপ, crates.io-এ crates `libcore`-তে নির্ভরতা edge এ আঁকবে, এই সংগ্রহস্থলে সংজ্ঞায়িত সংস্করণ।
Cargo সফলভাবে crates তৈরি করে তা নিশ্চিত করার জন্য এটি সমস্ত নির্ভরতা প্রান্তগুলি আঁকতে হবে!

দ্রষ্টব্য যে crates.io-এ crates-কে সঠিকভাবে কাজ করার জন্য `core` নামের এই crate এর উপর নির্ভর করতে হবে।তারা ব্যবহার করতে পারে তা করার জন্য:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` কী ব্যবহারের মাধ্যমে crate এর নাম পরিবর্তন করে `core` করা হয়েছে, এর অর্থ এটির মতো দেখাবে

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

যখন Cargo সংকলককে অনুরোধ করে, সংকলক দ্বারা ইনজেকশিত নিষ্ক্রিয় `extern crate core` নির্দেশকে সন্তুষ্ট করে।




