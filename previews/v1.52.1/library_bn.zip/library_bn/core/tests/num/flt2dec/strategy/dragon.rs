use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // মিরি খুব ধীর
fn exact_sanity_test() {
    // এই পরীক্ষাটি কেবলমাত্র আমি ধরে নিতে পারি যা চালানো শেষ হয় `exp2` গ্রন্থাগার ফাংশনের কিছু কোণার-ইশ কেস, যা আমরা ব্যবহার করছি সি রানটাইমের ক্ষেত্রে সংজ্ঞায়িত।
    // ভিএস ২০১৩-তে এই ফাংশনটির দৃশ্যত একটি ত্রুটি ছিল কারণ লিঙ্কিত হওয়ার সময় এই পরীক্ষাটি ব্যর্থ হয়, তবে ভিএস 2015 এর সাথে বাগটি ঠিকঠাক হিসাবে পরীক্ষাটি ঠিকঠাক চলার সাথে সংশোধন করা হয়।
    //
    // বাগটি `exp2(-1057)` এর রিটার্ন মানের মধ্যে পার্থক্য বলে মনে হচ্ছে, যেখানে ভিএস 2013 এ এটি বিট প্যাটার্ন 0x2 এর সাথে ডাবল ফেরত দেয় এবং ভিএস 2015 সালে এটি এক্স 100 এক্সকে ফেরত দেয়।
    //
    //
    // আপাতত এমএসভিসি-তে কেবল এই পরীক্ষাটিকে পুরোপুরি উপেক্ষা করুন কারণ এটি অন্য যে কোনও জায়গায় পরীক্ষা করা হয়েছে এবং আমরা প্রতিটি প্ল্যাটফর্মের exp2 বাস্তবায়ন পরীক্ষায় আগ্রহী নই।
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}