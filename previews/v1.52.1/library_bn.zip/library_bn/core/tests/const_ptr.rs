// দুটি বাইট এ সারিবদ্ধ
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // যেহেতু DATA.as_ptr() দুটি বাইটের সাথে সংযুক্ত থাকে, এতে 1 বাইট যুক্ত করা হয় যা একটি স্বাক্ষরহীন * কনস্ট u16 উত্পাদন করে
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// fn write() X core::ptr ব্যবহার করুন;
//
//    কনস্ট এফএন এক্স00 এক্স-> এক্স01 এক্স {চলুন মিট রেজো=0;
//        অনিরাপদ {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        রেজ} কনস্টিটেড ALIGNED: i32 = write_aligned();
//    assert_eq! (ALIGNED, 42);
//
//    কনস্ট এফএন এক্স01 এক্স-> এক্স02 এক্স {চলুন মিট টু_সিল্যান্ড=এক্স00 এক্স;
//        অনিরাপদ {যাক আনইলাইনযুক্ত_পিটার= (two_aligned.as_mut_ptr()* * এক্স এক্স 2 এক্স হিসাবে * মিট এক্স 100 এক্স;
//            পিটিআর: : রেকট_অনলাইনাইনড (আনইলাইনড_পিটার, এক্স01 এক্স;} দুই_সিলাইন্ড} কনসাল ইউএনএলআইজিএনড: এক্স02 এক্স=এক্স 100 এক্স;
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 {চলুন মিট রিজ=0;
//        অনিরাপদ { (&mut res as *mut i32).write(42); } রেজি} কনস্টিটেড ALIGNED: i32 = aligned();
//
//    assert_eq! (ALIGNED, 42);
//
//    কনস্ট এফএন এক্স01 এক্স-> এক্স02 এক্স {চলুন মিট টু_সিল্যান্ড=এক্স00 এক্স;
//        অনিরাপদ {যাক আনইলাইনযুক্ত_পিটার= (two_aligned.as_mut_ptr()* * এক্স এক্স 2 এক্স হিসাবে * মিট এক্স 100 এক্স;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//
//