use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // এটি স্থিতিশীল অঞ্চল নয়, তবে এলএলভিএম এই মুহুর্তে সর্বদা এটির সুবিধা নিতে না পারলেও, তাদের মধ্যে `?` সস্তা রাখতে সহায়তা করে।
    //
    // (দুঃখের সাথে রেজাল্ট এবং অপশনটি অসঙ্গত, তাই কন্ট্রোলফ্লো উভয়ের সাথেই মেলে না))

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}