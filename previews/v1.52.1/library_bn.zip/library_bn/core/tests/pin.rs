use core::pin::Pin;

#[test]
fn pin_const() {
    // পরীক্ষা করুন যে `Pin` এর পদ্ধতিগুলি কোনও কনস্ট কনটেক্সটে ব্যবহারযোগ্য

    const POINTER: &'static usize = &2;

    const PINNED: Pin<&'static usize> = Pin::new(POINTER);
    const PINNED_UNCHECKED: Pin<&'static usize> = unsafe { Pin::new_unchecked(POINTER) };
    assert_eq!(PINNED_UNCHECKED, PINNED);

    const INNER: &'static usize = Pin::into_inner(PINNED);
    assert_eq!(INNER, POINTER);

    const INNER_UNCHECKED: &'static usize = unsafe { Pin::into_inner_unchecked(PINNED) };
    assert_eq!(INNER_UNCHECKED, POINTER);

    const REF: &'static usize = PINNED.get_ref();
    assert_eq!(REF, POINTER);

    // Note: `pin_mut_const` পরীক্ষা করে যে `Pin<&mut T>` এর পদ্ধতিগুলি কোনও কনস্ট কনটেক্সটে ব্যবহারযোগ্য।
    // কনস্ট্যান্ট এফএন ব্যবহার করা হয়েছে কারণ এক্স 100 এক্স ধ্রুবকগুলিতে এক্স01 এক্স ব্যবহারযোগ্য নয়।
    const fn pin_mut_const() {
        let _ = Pin::new(&mut 2).into_ref();
        let _ = Pin::new(&mut 2).get_mut();
        let _ = unsafe { Pin::new(&mut 2).get_unchecked_mut() };
    }

    pin_mut_const();
}