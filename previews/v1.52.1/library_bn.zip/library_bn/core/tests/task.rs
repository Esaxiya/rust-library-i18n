use core::task::Poll;

#[test]
fn poll_const() {
    // পরীক্ষা করুন যে `Poll` এর পদ্ধতিগুলি কোনও কনস্ট কনটেক্সটে ব্যবহারযোগ্য

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}