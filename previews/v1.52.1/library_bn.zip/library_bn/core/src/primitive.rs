//! এই মডিউলটি সম্ভবত অন্যান্য ঘোষিত প্রকারের ছায়াযুক্ত নয় এমন ব্যবহারের অনুমতি দেওয়ার জন্য আদিম প্রকারগুলিকে পুনরায় সরবরাহ করে।
//!
//! এটি সাধারণত ম্যাক্রো উত্পন্ন কোডে কার্যকর।
//!
//! একটি নতুন কাঠামো তৈরি করার সময় এর উদাহরণ হ'ল এবং এর জন্য একটি ইমপ্লিট:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! নোট করুন যে `SOME_PROPERTY` সম্পর্কিত ধ্রুবকটি সংকলন করবে না, কারণ প্রকারভেদ bool টাইপের পরিবর্তে এর ধরণের `bool` স্ট্রাক্টকে বোঝায়।
//!
//!
//! একটি সঠিক বাস্তবায়ন দেখতে পাওয়া যেতে পারে:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;