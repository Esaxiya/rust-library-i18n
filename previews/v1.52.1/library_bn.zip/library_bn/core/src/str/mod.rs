//! স্ট্রিং ম্যানিপুলেশন।
//!
//! আরও তথ্যের জন্য, [`std::str`] মডিউলটি দেখুন।
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. সীমার বাইরে
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. শুরু <=শেষ
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. চরিত্রের সীমা
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // চরিত্রটি সন্ধান করুন
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` লেনের চেয়ে কম এবং চরের সীমা হতে হবে
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` দৈর্ঘ্য প্রদান করে।
    ///
    /// এই দৈর্ঘ্যটি বাইটে রয়েছে, [`চর`] এর বা গ্রাফিমগুলিতে নয়।
    /// অন্য কথায়, কোনও মানুষ স্ট্রিংয়ের দৈর্ঘ্য বিবেচনা করে না।
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // অভিনব চ!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` এর শূন্য বাইটের দৈর্ঘ্য থাকলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `Index`-th বাইটটি UTF-8 কোড পয়েন্ট ক্রম বা স্ট্রিংয়ের শেষের প্রথম বাইট is
    ///
    ///
    /// স্ট্রিংয়ের শুরু এবং শেষ (যখন `সূচক== self.len()`) সীমানা হিসাবে বিবেচিত হয়)।
    ///
    /// `index` যদি `self.len()` এর চেয়ে বেশি হয় তবে `false` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` এর শুরু
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` এর দ্বিতীয় বাইট
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` এর তৃতীয় বাইট
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 এবং লেন সবসময় ঠিক থাকে।
        // 0 এর জন্য স্পষ্টভাবে পরীক্ষা করুন যাতে এটি চেকটিকে সহজেই অপ্টিমাইজ করতে পারে এবং সে ক্ষেত্রে স্ট্রিং ডেটা পড়তে ছাড়তে পারে।
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // এটি বিট ম্যাজিকের সমতুল্য: খ <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// একটি স্ট্রিং স্লাইসকে বাইট স্লাইসে রূপান্তর করে।
    /// বাইট স্লাইসটিকে স্ট্রিং স্লাইসে রূপান্তর করতে, [`from_utf8`] ফাংশনটি ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // নিরাপত্তা: কনস্ট শব্দ, কারণ আমরা একই লেআউটটি সহ দুটি প্রকারের ট্রান্সমিট করি
        unsafe { mem::transmute(self) }
    }

    /// একটি পরিবর্তনীয় স্ট্রিং স্লাইসকে একটি পরিবর্তনীয় বাইট স্লাইসে রূপান্তর করে।
    ///
    /// # Safety
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে slণ শেষ হওয়ার আগে এবং অন্তর্নিহিত `str` ব্যবহারের আগে স্লাইসের সামগ্রীটি UTF-8 এর বৈধ is
    ///
    ///
    /// এমন একটি `str` ব্যবহার করুন যার বিষয়বস্তুগুলি বৈধ নয় UTF-8 হ'ল অপরিজ্ঞাত আচরণ।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // নিরাপদ: `&str` থেকে `&[u8]` এ Xালাই `str` সাল থেকে নিরাপদ
        // এক্স 100 এক্সের মতো একই লেআউট রয়েছে (কেবলমাত্র লিবিস্টডি এই গ্যারান্টিটি তৈরি করতে পারে)।
        // পয়েন্টার ডিरेফারেন্সটি নিরাপদ যেহেতু এটি পরিবর্তনীয় রেফারেন্স থেকে আসে যা লেখার জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// স্ট্রিং স্লাইসটিকে কাঁচা পয়েন্টারে রূপান্তরিত করে।
    ///
    /// স্ট্রিং স্লাইসগুলি বাইটের স্লাইস হিসাবে, কাঁচা পয়েন্টারটি একটি [`u8`] এ নির্দেশ করে।
    /// এই পয়েন্টারটি স্ট্রিং স্লাইসের প্রথম বাইটে নির্দেশ করবে।
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে ফিরে আসা পয়েন্টারটি কখনই লিখিত হয় না।
    /// আপনার যদি স্ট্রিং স্লাইসের বিষয়বস্তু পরিবর্তন করতে হয় তবে [`as_mut_ptr`] ব্যবহার করুন।
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// পরিবর্তনীয় স্ট্রিং স্লাইসকে কাঁচা পয়েন্টারে রূপান্তরিত করে।
    ///
    /// স্ট্রিং স্লাইসগুলি বাইটের স্লাইস হিসাবে, কাঁচা পয়েন্টারটি একটি [`u8`] এ নির্দেশ করে।
    /// এই পয়েন্টারটি স্ট্রিং স্লাইসের প্রথম বাইটে নির্দেশ করবে।
    ///
    /// এটি নিশ্চিত করা আপনার দায়িত্ব যে স্ট্রিং স্লাইসটি এমনভাবে পরিবর্তিত হবে যাতে এটি বৈধ UTF-8 অবধি থাকবে।
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` এর সাব্লাইস ফিরে আসে।
    ///
    /// এটি `str` সূচীকরণের জন্য অ-আতঙ্কিত বিকল্প।
    /// যখনই সমতুল্য ইনডেক্সিং অপারেশনটি panic করবে তখন [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // সূচকগুলি UTF-8 ক্রম সীমানায় নয় on
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // সীমার বাইরে
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` এর একটি পরিবর্তনীয় সাবসিলেস প্রদান করে।
    ///
    /// এটি `str` সূচীকরণের জন্য অ-আতঙ্কিত বিকল্প।
    /// যখনই সমতুল্য ইনডেক্সিং অপারেশনটি panic করবে তখন [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // সঠিক দৈর্ঘ্য
    /// assert!(v.get_mut(0..5).is_some());
    /// // সীমার বাইরে
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` এর একটি চেক করা সাবস্কাইসটি ফেরত দেয়।
    ///
    /// এটি `str` এর সূচীকরণের চেক না করা বিকল্প।
    ///
    /// # Safety
    ///
    /// এই ফাংশনটির কলকারীরা দায়বদ্ধ যে এই পূর্বশর্তগুলি সন্তুষ্ট:
    ///
    /// * প্রারম্ভিক সূচকটি অবশ্যই শেষ সূচকটি অতিক্রম করবে না;
    /// * সূচকগুলি অবশ্যই মূল স্লাইসের সীমানার মধ্যে থাকতে হবে;
    /// * সূচকগুলি অবশ্যই UTF-8 সিকোয়েন্সের সীমানায় থাকা উচিত।
    ///
    /// এটি ব্যর্থ হয়ে, ফিরে আসা স্ট্রিং স্লাইসটি অবৈধ মেমরিটিকে উল্লেখ করতে পারে বা এক্স 100 এক্স টাইপের মাধ্যমে আগত আক্রমণকারীদের লঙ্ঘন করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // নিরাপত্তা: কলকারীকে অবশ্যই `get_unchecked` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` এর একটি পরিবর্তনীয়, চেক না করা সাবস্কাইসটি প্রদান করে।
    ///
    /// এটি `str` এর সূচীকরণের চেক না করা বিকল্প।
    ///
    /// # Safety
    ///
    /// এই ফাংশনটির কলকারীরা দায়বদ্ধ যে এই পূর্বশর্তগুলি সন্তুষ্ট:
    ///
    /// * প্রারম্ভিক সূচকটি অবশ্যই শেষ সূচকটি অতিক্রম করবে না;
    /// * সূচকগুলি অবশ্যই মূল স্লাইসের সীমানার মধ্যে থাকতে হবে;
    /// * সূচকগুলি অবশ্যই UTF-8 সিকোয়েন্সের সীমানায় থাকা উচিত।
    ///
    /// এটি ব্যর্থ হয়ে, ফিরে আসা স্ট্রিং স্লাইসটি অবৈধ মেমরিটিকে উল্লেখ করতে পারে বা এক্স 100 এক্স টাইপের মাধ্যমে আগত আক্রমণকারীদের লঙ্ঘন করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // নিরাপত্তা: কলকারীকে অবশ্যই `get_unchecked_mut` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// সুরক্ষা চেকগুলি বাইপাস করে অন্য স্ট্রিং স্লাইস থেকে একটি স্ট্রিং স্লাইস তৈরি করে।
    ///
    /// এটি সাধারণত প্রস্তাবিত নয়, সতর্কতার সাথে ব্যবহার করুন!নিরাপদ বিকল্পের জন্য দেখুন [`str`] এবং [`Index`]।
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// এই নতুন টুকরাটি `end` থেকে এক্স01 এক্সে চলে গেছে, `begin` সহ তবে `end` বাদে।
    ///
    /// পরিবর্তে একটি পরিবর্তনীয় স্ট্রিং স্লাইস পেতে, [`slice_mut_unchecked`] পদ্ধতিটি দেখুন।
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// এই ফাংশনের কলকারীরা দায়বদ্ধ যে তিনটি পূর্বশর্ত সন্তুষ্ট:
    ///
    /// * `begin` অবশ্যই `end` ছাড়িয়ে যাবে না।
    /// * `begin` এবং `end` অবশ্যই স্ট্রিং স্লাইসের মধ্যে বাইট পজিশনে থাকতে হবে।
    /// * `begin` এবং `end` অবশ্যই UTF-8 ক্রম সীমানায় থাকা উচিত on
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // নিরাপত্তা: কলকারীকে অবশ্যই `get_unchecked` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// সুরক্ষা চেকগুলি বাইপাস করে অন্য স্ট্রিং স্লাইস থেকে একটি স্ট্রিং স্লাইস তৈরি করে।
    /// এটি সাধারণত প্রস্তাবিত নয়, সতর্কতার সাথে ব্যবহার করুন!নিরাপদ বিকল্পের জন্য দেখুন [`str`] এবং [`IndexMut`]।
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// এই নতুন টুকরাটি `end` থেকে এক্স01 এক্সে চলে গেছে, `begin` সহ তবে `end` বাদে।
    ///
    /// পরিবর্তে একটি অপরিবর্তনীয় স্ট্রিং স্লাইস পেতে, [`slice_unchecked`] পদ্ধতিটি দেখুন।
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// এই ফাংশনের কলকারীরা দায়বদ্ধ যে তিনটি পূর্বশর্ত সন্তুষ্ট:
    ///
    /// * `begin` অবশ্যই `end` ছাড়িয়ে যাবে না।
    /// * `begin` এবং `end` অবশ্যই স্ট্রিং স্লাইসের মধ্যে বাইট পজিশনে থাকতে হবে।
    /// * `begin` এবং `end` অবশ্যই UTF-8 ক্রম সীমানায় থাকা উচিত on
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // নিরাপত্তা: কলকারীকে অবশ্যই `get_unchecked_mut` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// একটি সূচীতে একটি স্ট্রিং স্লাইস দুটি ভাগে ভাগ করুন।
    ///
    /// আর্গুমেন্ট, `mid`, স্ট্রিংয়ের শুরু থেকে একটি বাইট অফসেট হওয়া উচিত।
    /// এটি অবশ্যই একটি UTF-8 কোড পয়েন্টের সীমানায় থাকতে হবে।
    ///
    /// দুটি স্লাইস ফিরে এসেছে স্ট্রিং স্লাইসটির শুরু থেকে শুরু করে `mid`, এবং `mid` থেকে স্ট্রিং স্লাইসের শেষ পর্যন্ত।
    ///
    /// পরিবর্তে পরিবর্তনীয় স্ট্রিং স্লাইসগুলি পেতে, [`split_at_mut`] পদ্ধতিটি দেখুন।
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics যদি `mid` কোনও UTF-8 কোড পয়েন্টের সীমানায় না থাকে বা স্ট্রিং স্লাইসের শেষ কোড পয়েন্টের শেষের হয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_ সীমানা পরীক্ষা করে যে সূচকটি [0, .len()]
        if self.is_char_boundary(mid) {
            // নিরাপদ: সবেমাত্র `mid` একটি চরের সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে।
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// একটি সূচকগুলিতে একটি পরিবর্তনীয় স্ট্রিং স্লাইস দুটি ভাগে ভাগ করুন।
    ///
    /// আর্গুমেন্ট, `mid`, স্ট্রিংয়ের শুরু থেকে একটি বাইট অফসেট হওয়া উচিত।
    /// এটি অবশ্যই একটি UTF-8 কোড পয়েন্টের সীমানায় থাকতে হবে।
    ///
    /// দুটি স্লাইস ফিরে এসেছে স্ট্রিং স্লাইসটির শুরু থেকে শুরু করে `mid`, এবং `mid` থেকে স্ট্রিং স্লাইসের শেষ পর্যন্ত।
    ///
    /// পরিবর্তে অপরিবর্তনীয় স্ট্রিং স্লাইসগুলি পেতে, [`split_at`] পদ্ধতিটি দেখুন।
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics যদি `mid` কোনও UTF-8 কোড পয়েন্টের সীমানায় না থাকে বা স্ট্রিং স্লাইসের শেষ কোড পয়েন্টের শেষের হয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_ সীমানা পরীক্ষা করে যে সূচকটি [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // নিরাপদ: সবেমাত্র `mid` একটি চরের সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে।
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// একটি স্ট্রিং স্লাইসের [`চারি] এর ওপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    ///
    /// স্ট্রিং স্লাইসটিতে বৈধ UTF-8 রয়েছে, তাই আমরা [`char`] দ্বারা স্ট্রিং স্লাইসের মাধ্যমে পুনরাবৃত্তি করতে পারি।
    /// এই পদ্ধতিটি এ জাতীয় পুনরাবৃত্তি প্রদান করে।
    ///
    /// এটি মনে রাখা গুরুত্বপূর্ণ যে [`char`] একটি ইউনিকোড স্কেলারের মান উপস্থাপন করে এবং 'character' কী তা আপনার ধারণার সাথে মেলে না।
    ///
    /// গ্রাফেম ক্লাস্টারগুলির মধ্যে বিভাজনগুলি আপনি যা চান তা হতে পারে।
    /// এই কার্যকারিতাটি Rust এর স্ট্যান্ডার্ড লাইব্রেরি দ্বারা সরবরাহ করা হয়নি, পরিবর্তে crates.io পরীক্ষা করুন।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// মনে রাখবেন, [`char`] গুলি অক্ষর সম্পর্কে আপনার স্বজ্ঞানের সাথে মেলে না:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // এক্স 100 এক্স নয়
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// একটি স্ট্রিং স্লাইসের [`চারি] এর ওপরে একটি পুনরাবৃত্তিকে এবং তাদের অবস্থানগুলি প্রদান করে।
    ///
    /// স্ট্রিং স্লাইসটিতে বৈধ UTF-8 রয়েছে, তাই আমরা [`char`] দ্বারা স্ট্রিং স্লাইসের মাধ্যমে পুনরাবৃত্তি করতে পারি।
    /// এই পদ্ধতিটি এই দুটি [`char`] গুলি এর পাশাপাশি তাদের বাইট অবস্থানের একটি পুনরাবৃত্তি প্রদান করে।
    ///
    /// পুনরুক্তি করে টিপলস দেয়।অবস্থানটি প্রথম, [`char`] দ্বিতীয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// মনে রাখবেন, [`char`] গুলি অক্ষর সম্পর্কে আপনার স্বজ্ঞানের সাথে মেলে না:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // (0, 'y̆') নয়
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // এখানে 3 টি নোট করুন, শেষ চরিত্রটি দুটি বাইট নিয়েছে
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// স্ট্রিং স্লাইসের বাইটের উপরে একটি পুনরাবৃত্তকারী।
    ///
    /// স্ট্রিং স্লাইস যেমন বাইটের ক্রম নিয়ে গঠিত, আমরা বাইট দ্বারা স্ট্রিং স্লাইসের মাধ্যমে পুনরাবৃত্তি করতে পারি।
    /// এই পদ্ধতিটি এ জাতীয় পুনরাবৃত্তি প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// হোয়াইটস্পেসের মাধ্যমে একটি স্ট্রিং স্লাইস বিভক্ত করে।
    ///
    /// পুনরুদ্ধার করা পুনরুদ্ধারকারী স্ট্রিং স্লাইসগুলি আসবে যা মূল স্ট্রিং স্লাইসের সাব-স্লাইস, যে কোনও পরিমাণ স্পেসস্পেসের দ্বারা পৃথক করা হবে।
    ///
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    /// আপনি যদি কেবল তার পরিবর্তে ASCII সাদা স্পেসে বিভক্ত করতে চান তবে [`split_ascii_whitespace`] ব্যবহার করুন।
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// সমস্ত ধরণের সাদা স্থান বিবেচনা করা হয়:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII সাদা স্থান দ্বারা একটি স্ট্রিং স্লাইস বিভক্ত।
    ///
    /// পুনরুদ্ধারকটি ফিরে আসবে এমন স্ট্রিং স্লাইসগুলি যা আসল স্ট্রিং স্লাইসের উপ-স্লাইস, কোনও পরিমাণ ASCII সাদা স্থানের দ্বারা পৃথক করা হবে।
    ///
    ///
    /// পরিবর্তে ইউনিকোড `Whitespace` দ্বারা বিভক্ত করতে, [`split_whitespace`] ব্যবহার করুন।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// সমস্ত ধরনের ASCII সাদা স্থান বিবেচনা করা হয়:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// স্ট্রিংয়ের টুকরো হিসাবে একটি স্ট্রিংয়ের রেখার উপরে একটি পুনরাবৃত্তি।
    ///
    /// লাইনগুলি একটি নতুন লাইন (`\n`) বা লাইন ফিড (`\r\n`) এর সাথে ক্যারেজ রিটার্ন দিয়ে শেষ হয়।
    ///
    /// চূড়ান্ত লাইন সমাপ্তি isচ্ছিক।
    /// চূড়ান্ত রেখার সমাপ্তির সাথে শেষ হওয়া একটি স্ট্রিং চূড়ান্ত লাইন শেষ না করেই একই লাইনগুলিকে অন্যথায় অভিন্ন স্ট্রিং হিসাবে ফিরিয়ে দেবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// চূড়ান্ত লাইনের সমাপ্তি প্রয়োজন হয় না:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// একটি স্ট্রিংয়ের রেখার উপরে একটি পুনরাবৃত্তি
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 হিসাবে এনকোড করা স্ট্রিংয়ের উপরে `u16` এর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// প্রদত্ত প্যাটার্নটি এই স্ট্রিং স্লাইসের উপ-স্লাইসের সাথে মিলে গেলে `true` প্রদান করে।
    ///
    /// এটি না হলে `false` প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// প্রদত্ত প্যাটার্নটি এই স্ট্রিং স্লাইসের উপসর্গের সাথে মিলে গেলে `true` প্রদান করে।
    ///
    /// এটি না হলে `false` প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// প্রদত্ত প্যাটার্নটি যদি এই স্ট্রিং স্লাইসের প্রত্যয়টির সাথে মেলে তবে `true` প্রদান করে।
    ///
    /// এটি না হলে `false` প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// প্যাটার্নটির সাথে মেলে এই স্ট্রিং স্লাইসের প্রথম চরিত্রের বাইট সূচকটি প্রদান করে।
    ///
    /// প্যাটার্নটি মেলে না তবে [`None`] প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// বিন্দু মুক্ত শৈলী এবং বন্ধকরণ ব্যবহার করে আরও জটিল নিদর্শন:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// প্যাটার্নটি খুঁজে পাচ্ছে না:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// এই স্ট্রিং স্লাইসে প্যাটার্নের ডানদিকের ম্যাচের প্রথম চরিত্রের জন্য বাইট সূচকটি প্রদান করে।
    ///
    /// প্যাটার্নটি মেলে না তবে [`None`] প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ক্লোজার সহ আরও জটিল নিদর্শন:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// প্যাটার্নটি খুঁজে পাচ্ছে না:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// একটি প্যাটার্নের সাথে মিলিত অক্ষর দ্বারা পৃথক করা এই স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// যদি প্যাটার্নটি একটি বিপরীত অনুসন্ধানের অনুমতি দেয় এবং এক্স01 এক্স অনুসন্ধান একই উপাদান দেয় তবে প্রত্যাবর্তিত পুনরাবৃত্তিটি একটি [`DoubleEndedIterator`] হবে।
    /// এটি উদাহরণস্বরূপ, [`char`] এর ক্ষেত্রে সত্য তবে `&str` এর জন্য নয়।
    ///
    /// যদি প্যাটার্নটি বিপরীত অনুসন্ধানের অনুমতি দেয় তবে এর ফলাফলগুলি সামনের অনুসন্ধানে পৃথক হতে পারে, [`rsplit`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// যদি প্যাটার্নটি অক্ষরের টুকরো হয় তবে যে কোনও একটি অক্ষরের প্রতিটি উপস্থিতিতে বিভক্ত করুন:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// যদি কোনও স্ট্রিংয়ে একাধিক সংলগ্ন বিভাজক থাকে, আপনি আউটপুটে খালি স্ট্রিংয়ের সাথে শেষ করবেন:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// খালি স্ট্রিং দ্বারা নিয়মিত বিভাজক পৃথক করা হয়।
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// স্ট্রিংয়ের শুরু বা শেষে পৃথককারীরা খালি স্ট্রিং দ্বারা প্রতিবেশী হয়।
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// খালি স্ট্রিংটি বিভাজক হিসাবে ব্যবহৃত হয়, এটি স্ট্রিংয়ের শুরু এবং শেষের পাশাপাশি স্ট্রিংয়ের প্রতিটি অক্ষরকে পৃথক করে।
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// যখন সাদা অংশটি বিভাজক হিসাবে ব্যবহৃত হয় তখন সংবিধান বিচ্ছিন্নকারীরা সম্ভবত বিস্মিতকর আচরণ করতে পারে।এই কোডটি সঠিক:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// এটি আপনাকে _not_ দেয়:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// এই আচরণের জন্য [`split_whitespace`] ব্যবহার করুন।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// একটি প্যাটার্নের সাথে মিলিত অক্ষর দ্বারা পৃথক করা এই স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী
    /// `split` এক্সে এক্স 100 এক্স দ্বারা উত্পাদিত পুনরাবৃত্তির থেকে পৃথক পৃথক স্ট্রিংয়ের টার্মিনেটর হিসাবে ম্যাচ করা অংশটি ছেড়ে দেয় leaves
    ///
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// যদি স্ট্রিংয়ের শেষ উপাদানটি মিলে যায়, তবে সেই উপাদানটি পূর্ববর্তী সাবস্ট্রিংয়ের টার্মিনেটর হিসাবে বিবেচিত হবে।
    /// সেই স্ট্রিংিংটি আইট্রেটর দ্বারা ফিরিয়ে দেওয়া শেষ আইটেম হবে।
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// প্রদত্ত স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী, কোনও প্যাটার্নের সাথে মিলিয়ে অক্ষর দ্বারা পৃথক হয়ে বিপরীত ক্রমে ফলিত হয়েছে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তকারীটির প্রয়োজন হয় যে প্যাটার্নটি একটি বিপরীত অনুসন্ধানকে সমর্থন করে এবং এটি যদি কোনও এক্স0 এক্স এক্স একই উপাদান দেয় তবে এটি [`DoubleEndedIterator`] হবে।
    ///
    ///
    /// সামনে থেকে পুনরাবৃত্তি করার জন্য, [`split`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// প্রদত্ত স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী, একটি প্যাটার্নের সাথে মিলিত অক্ষর দ্বারা পৃথক।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] এর সমতুল্য, ট্রেইলিং সাবস্ট্রিংটি খালি থাকলে এড়ানো যায়।
    ///
    /// [`split`]: str::split
    ///
    /// এই পদ্ধতিটি স্ট্রিং ডেটার জন্য ব্যবহার করা যেতে পারে যা _terminated_ নয়, কোনও প্যাটার্নের দ্বারা _separated_ এর চেয়ে বেশি।
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// যদি প্যাটার্নটি একটি বিপরীত অনুসন্ধানের অনুমতি দেয় এবং এক্স01 এক্স অনুসন্ধান একই উপাদান দেয় তবে প্রত্যাবর্তিত পুনরাবৃত্তিটি একটি [`DoubleEndedIterator`] হবে।
    /// এটি উদাহরণস্বরূপ, [`char`] এর ক্ষেত্রে সত্য তবে `&str` এর জন্য নয়।
    ///
    /// যদি প্যাটার্নটি বিপরীত অনুসন্ধানের অনুমতি দেয় তবে এর ফলাফলগুলি সামনের অনুসন্ধানে পৃথক হতে পারে, [`rsplit_terminator`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` এর সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী, কোনও প্যাটার্নের সাথে মিলিয়ে অক্ষর দ্বারা পৃথক এবং বিপরীত ক্রমে ফলিত হয়েছে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] এর সমতুল্য, ট্রেইলিং সাবস্ট্রিংটি খালি থাকলে এড়ানো যায়।
    ///
    /// [`split`]: str::split
    ///
    /// এই পদ্ধতিটি স্ট্রিং ডেটার জন্য ব্যবহার করা যেতে পারে যা _terminated_ নয়, কোনও প্যাটার্নের দ্বারা _separated_ এর চেয়ে বেশি।
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তকারীটির প্রয়োজন হয় যে প্যাটার্নটি একটি বিপরীত অনুসন্ধানকে সমর্থন করে এবং যদি কোনও forward/reverse অনুসন্ধান একই উপাদানগুলি উত্পাদন করে তবে এটি দ্বিগুণ হয়ে যাবে।
    ///
    ///
    /// সামনে থেকে পুনরাবৃত্তি করার জন্য, [`split_terminator`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// প্রদত্ত স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তি, কোনও প্যাটার্ন দ্বারা পৃথকীকৃত, সর্বাধিক `n` আইটেমগুলিতে ফিরতে সীমাবদ্ধ।
    ///
    /// যদি এক্স 100 এক্স সাবস্ট্রিংগুলি ফিরে আসে তবে শেষের স্ট্রিংগুলিতে (`n` তম স্ট্রিং) স্ট্রিংয়ের বাকী অংশ থাকবে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তিকে দ্বিগুণ শেষ করা হবে না, কারণ এটি সমর্থন করার পক্ষে দক্ষ নয়।
    ///
    /// যদি প্যাটার্নটি বিপরীত অনুসন্ধানের অনুমতি দেয়, [`rsplitn`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// এই স্ট্রিং স্লাইসের সাবস্ট্রিংগুলির উপরে একটি পুনরাবৃত্তকারী, স্ট্রিংয়ের শেষে থেকে শুরু করে, কোনও প্যাটার্ন দ্বারা পৃথক করা, বেশিরভাগ `n` আইটেমগুলিতে ফিরে আসতে সীমাবদ্ধ।
    ///
    ///
    /// যদি এক্স 100 এক্স সাবস্ট্রিংগুলি ফিরে আসে তবে শেষের স্ট্রিংগুলিতে (`n` তম স্ট্রিং) স্ট্রিংয়ের বাকী অংশ থাকবে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তিকে দ্বিগুণ শেষ করা হবে না, কারণ এটি সমর্থন করার পক্ষে দক্ষ নয়।
    ///
    /// সামনে থেকে বিভাজনের জন্য, [`splitn`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// নির্দিষ্ট ডিলিমিটারের প্রথম উপস্থিতিতে স্ট্রিংকে বিভক্ত করে এবং ডিলিমিটারের পূর্বে উপসর্গ এবং ডিলিমিটারের পরে প্রত্যয় প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// নির্দিষ্ট ডিলিমিটারের শেষ ঘটনাটিতে স্ট্রিংকে বিভক্ত করে এবং ডিলিমিটারের পূর্বে উপসর্গ এবং ডিলিমিটারের পরে প্রত্যয় প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// প্রদত্ত স্ট্রিং স্লাইসের মধ্যে একটি প্যাটার্নের বিপর্যয় মেলে over
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// যদি প্যাটার্নটি একটি বিপরীত অনুসন্ধানের অনুমতি দেয় এবং এক্স01 এক্স অনুসন্ধান একই উপাদান দেয় তবে প্রত্যাবর্তিত পুনরাবৃত্তিটি একটি [`DoubleEndedIterator`] হবে।
    /// এটি উদাহরণস্বরূপ, [`char`] এর ক্ষেত্রে সত্য তবে `&str` এর জন্য নয়।
    ///
    /// যদি প্যাটার্নটি বিপরীত অনুসন্ধানের অনুমতি দেয় তবে এর ফলাফলগুলি সামনের অনুসন্ধানে পৃথক হতে পারে, [`rmatches`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// এই স্ট্রিং স্লাইসের মধ্যে একটি প্যাটার্নের বিশৃঙ্খলা মিলে ওঠার জন্য একটি পুনরাবৃত্তি বিপরীত ক্রমে অর্জিত।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তকারীটির প্রয়োজন হয় যে প্যাটার্নটি একটি বিপরীত অনুসন্ধানকে সমর্থন করে এবং এটি যদি কোনও এক্স0 এক্স এক্স একই উপাদান দেয় তবে এটি [`DoubleEndedIterator`] হবে।
    ///
    ///
    /// সামনে থেকে পুনরাবৃত্তি করার জন্য, [`matches`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// এই স্ট্রিং স্লাইসের মধ্যে কোনও প্যাটার্নের বিপর্যয় ম্যাচগুলির পাশাপাশি একটি সূচক যে ম্যাচটি শুরু হয় over
    ///
    /// `self` এর মধ্যে থাকা `pat` এর ম্যাচগুলির ক্ষেত্রে ওভারল্যাপ হয়, কেবল প্রথম ম্যাচের সাথে সম্পর্কিত সূচকগুলিই ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// যদি প্যাটার্নটি একটি বিপরীত অনুসন্ধানের অনুমতি দেয় এবং এক্স01 এক্স অনুসন্ধান একই উপাদান দেয় তবে প্রত্যাবর্তিত পুনরাবৃত্তিটি একটি [`DoubleEndedIterator`] হবে।
    /// এটি উদাহরণস্বরূপ, [`char`] এর ক্ষেত্রে সত্য তবে `&str` এর জন্য নয়।
    ///
    /// যদি প্যাটার্নটি বিপরীত অনুসন্ধানের অনুমতি দেয় তবে এর ফলাফলগুলি সামনের অনুসন্ধানে পৃথক হতে পারে, [`rmatch_indices`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // শুধুমাত্র প্রথম `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` এর মধ্যে একটি প্যাটার্নের বিশৃঙ্খলা ম্যাচগুলির উপর একটি পুনরাবৃত্তিকারী ম্যাচের সূচী সহ বিপরীত ক্রমে ফলস্বরূপ।
    ///
    /// `self` এর মধ্যে থাকা `pat` এর ম্যাচগুলির জন্য ওভারল্যাপ হয়, কেবল শেষ ম্যাচের সাথে সম্পর্কিত সূচকগুলিই ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # আইট্রেটার আচরণ
    ///
    /// ফিরে আসা পুনরাবৃত্তকারীটির প্রয়োজন হয় যে প্যাটার্নটি একটি বিপরীত অনুসন্ধানকে সমর্থন করে এবং এটি যদি কোনও এক্স0 এক্স এক্স একই উপাদান দেয় তবে এটি [`DoubleEndedIterator`] হবে।
    ///
    ///
    /// সামনে থেকে পুনরাবৃত্তি করার জন্য, [`match_indices`] পদ্ধতিটি ব্যবহার করা যেতে পারে।
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // শুধুমাত্র শেষ `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// শীর্ষস্থানীয় এবং অনুসরণযোগ্য শ্বেতস্পেস সরানো সহ একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// শীর্ষস্থানীয় হোয়াইটস্পেস সরানো সহ একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// `start` এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের প্রথম অবস্থান;ইংরাজী বা রাশিয়ান এর মতো বাম থেকে ডান ভাষার জন্য, এটি বাম দিকে থাকবে এবং আরবি বা হিব্রু-র মতো ডান-থেকে-বাম ভাষার জন্য, এটি ডান দিক হবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// শ্বেত স্পেস সরানো সহ একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// `end` এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের শেষ অবস্থান;বাম-থেকে-ডান ভাষার জন্য ইংরাজী বা রাশিয়ান এর মতো, এটি ডানদিকে থাকবে এবং আরবি বা হিব্রু-র মতো ডান-থেকে-বাম ভাষার জন্য এটি বাম দিক হবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// শীর্ষস্থানীয় হোয়াইটস্পেস সরানো সহ একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// 'Left' এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের প্রথম অবস্থান;আরবি বা হিব্রু ভাষার মতো ভাষার জন্য যা 'বাম থেকে ডান' না হয়ে 'ডান থেকে বাম', এটি _right_ দিক হবে, বাম নয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// শ্বেত স্পেস সরানো সহ একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// 'Whitespace' ইউনিকোড ডেরিভড কোর সম্পত্তি `White_Space` এর শর্তাবলী অনুসারে সংজ্ঞায়িত করা হয়।
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// 'Right' এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের শেষ অবস্থান;আরবি বা হিব্রু ভাষার মতো ভাষার জন্য যা 'বাম থেকে ডান' না হয়ে 'ডান থেকে বাম', এটি _left_ দিকের হবে, ডান নয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// বারবার মুছে ফেলা একটি প্যাটার্নের সাথে মেলে এমন সমস্ত উপসর্গ এবং প্রত্যয়গুলির সাথে একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// [pattern] একটি [`char`], [`চর`] এর একটি টুকরো বা কোনও ফাংশন বা বন্ধ হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // সর্বাধিক পরিচিত ম্যাচ মনে রাখবেন, নীচে এটি সংশোধন করুন
            // শেষ ম্যাচটি আলাদা
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // নিরাপত্তা: এক্স 100 এক্স বৈধ সূচকগুলি ফেরত দিতে পরিচিত।
        unsafe { self.get_unchecked(i..j) }
    }

    /// বারবার মুছে ফেলা একটি প্যাটার্নের সাথে মেলে এমন সমস্ত উপসর্গের সাথে একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// `start` এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের প্রথম অবস্থান;ইংরাজী বা রাশিয়ান এর মতো বাম থেকে ডান ভাষার জন্য, এটি বাম দিকে থাকবে এবং আরবি বা হিব্রু-র মতো ডান-থেকে-বাম ভাষার জন্য, এটি ডান দিক হবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // নিরাপত্তা: এক্স 100 এক্স বৈধ সূচকগুলি ফেরত দিতে পরিচিত।
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// উপসর্গ সরানো সঙ্গে একটি স্ট্রিং স্লাইস ফেরত।
    ///
    /// যদি স্ট্রিংটি `prefix` প্যাটার্ন দিয়ে শুরু হয়, `Some` এ মোড়ানো উপসর্গের পরে সাবস্ট্রিং দেয়।
    /// `trim_start_matches` এর বিপরীতে, এই পদ্ধতিটি ঠিক একবারে উপসর্গটি সরিয়ে দেয়।
    ///
    /// যদি স্ট্রিংটি `prefix` দিয়ে শুরু না হয়, `None` প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// প্রত্যয়টি সরানোর সাথে একটি স্ট্রিং স্লাইস ফেরায়।
    ///
    /// যদি স্ট্রিংটি `suffix` প্যাটার্ন দিয়ে শেষ হয়, `Some` এ আবৃত প্রত্যয়টির আগে স্ট্রিংটি প্রদান করে।
    /// `trim_end_matches` এর বিপরীতে, এই পদ্ধতিটি প্রত্যয়টি ঠিক একবারে সরিয়ে দেয়।
    ///
    /// যদি স্ট্রিংটি `suffix` দিয়ে শেষ না হয় তবে এক্স 100 এক্স প্রদান করে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// বারবার মুছে ফেলা একটি প্যাটার্নের সাথে মেলে এমন সমস্ত প্রত্যয়গুলির সাথে একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// `end` এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের শেষ অবস্থান;বাম-থেকে-ডান ভাষার জন্য ইংরাজী বা রাশিয়ান এর মতো, এটি ডানদিকে থাকবে এবং আরবি বা হিব্রু-র মতো ডান-থেকে-বাম ভাষার জন্য এটি বাম দিক হবে।
    ///
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // নিরাপত্তা: এক্স 100 এক্স বৈধ সূচকগুলি ফেরত দিতে পরিচিত।
        unsafe { self.get_unchecked(0..j) }
    }

    /// বারবার মুছে ফেলা একটি প্যাটার্নের সাথে মেলে এমন সমস্ত উপসর্গের সাথে একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// 'Left' এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের প্রথম অবস্থান;আরবি বা হিব্রু ভাষার মতো ভাষার জন্য যা 'বাম থেকে ডান' না হয়ে 'ডান থেকে বাম', এটি _right_ দিক হবে, বাম নয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// বারবার মুছে ফেলা একটি প্যাটার্নের সাথে মেলে এমন সমস্ত প্রত্যয়গুলির সাথে একটি স্ট্রিং স্লাইস ফিরে আসে।
    ///
    /// [pattern] একটি `&str`, [`char`], [`চর`] এর একটি ফালি বা কোনও ফাংশন বা সমাপন হতে পারে যা কোনও চরিত্রের সাথে মেলে কিনা তা নির্ধারণ করে।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # পাঠ্য দিকনির্দেশনা
    ///
    /// একটি স্ট্রিং বাইটের ক্রম।
    /// 'Right' এই প্রসঙ্গে মানে বাইট স্ট্রিংয়ের শেষ অবস্থান;আরবি বা হিব্রু ভাষার মতো ভাষার জন্য যা 'বাম থেকে ডান' না হয়ে 'ডান থেকে বাম', এটি _left_ দিকের হবে, ডান নয়।
    ///
    ///
    /// # Examples
    ///
    /// সাধারণ নিদর্শন:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// একটি ক্লোজার ব্যবহার করে আরও জটিল প্যাটার্ন:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// এই স্ট্রিং স্লাইসটিকে অন্য ধরণের পার্স করে।
    ///
    /// `parse` যেহেতু সাধারণ, তাই এটি টাইপ ইনফারেন্সে সমস্যা তৈরি করতে পারে।
    /// এর মতো, `parse` হল কয়েকবার আপনি সিন্টেক্সটি স্নেহের সাথে 'turbofish' হিসাবে পরিচিত: `::<>`.
    ///
    /// এটি অনুমানের অ্যালগরিদমকে বিশেষত বুঝতে সাহায্য করে যে আপনি কোন ধরণের পার্স করার চেষ্টা করছেন।
    ///
    /// `parse` [`FromStr`] trait প্রয়োগকারী যে কোনও প্রকারে পার্স করতে পারে।
    ///

    /// # Errors
    ///
    /// এই স্ট্রিং স্লাইসটিকে পছন্দসই প্রকারে পার্স করা সম্ভব না হলে [`Err`] ফিরবে।
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` টি টিকিয়ে দেওয়ার পরিবর্তে 'turbofish' ব্যবহার করে:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// পার্স করতে ব্যর্থ:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// এই স্ট্রিংয়ের সমস্ত অক্ষর ASCII সীমার মধ্যে রয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // আমরা এখানে প্রতিটি বাইটকে চরিত্র হিসাবে বিবেচনা করতে পারি: সমস্ত মাল্টিবাইট অক্ষর এমন একটি বাইট দিয়ে শুরু হয় যা এসকি রেঞ্জে নেই, তাই আমরা ইতিমধ্যে সেখানে থামব।
        //
        //
        self.as_bytes().is_ascii()
    }

    /// দুটি স্ট্রিং একটি এএসসিআইআই কেস-সংবেদনশীল মিল Che
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` হিসাবে একই, কিন্তু অস্থায়ী বরাদ্দ এবং অনুলিপি ছাড়াই।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// এই স্ট্রিংটিকে তার ASCII আপার ক্ষেত্রে সমতুল্য স্থানান্তর করে।
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন বড় মানের ফেরত দিতে, [`to_ascii_uppercase()`] ব্যবহার করুন।
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // নিরাপদ: নিরাপদ কারণ আমরা একই লেআউট সহ দুটি প্রকারের ট্রান্সমিট করি।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// এই স্ট্রিংটিকে তার ASCII লোয়ার কেস ইন-প্লেসে রূপান্তর করে।
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন নিম্নতর মানটি ফেরত দিতে, [`to_ascii_lowercase()`] ব্যবহার করুন।
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // নিরাপদ: নিরাপদ কারণ আমরা একই লেআউট সহ দুটি প্রকারের ট্রান্সমিট করি।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// একটি পুনরুক্তি ফেরান যা `self` এর প্রতিটি চরকে [`char::escape_debug`] দিয়ে পালিয়ে যায়।
    ///
    ///
    /// Note: স্ট্রিং শুরু হওয়া কেবল প্রসারিত গ্রাফি কোডপয়েন্টগুলি এড়ানো যাবে।
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// একটি পুনরুক্তি ফেরান যা `self` এর প্রতিটি চরকে [`char::escape_default`] দিয়ে পালিয়ে যায়।
    ///
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// একটি পুনরুক্তি ফেরান যা `self` এর প্রতিটি চরকে [`char::escape_unicode`] দিয়ে পালিয়ে যায়।
    ///
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// একটি খালি str তৈরি করে
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// একটি ফাঁকা পরিবর্তনযোগ্য str তৈরি করে
    #[inline]
    fn default() -> Self {
        // নিরাপদ: খালি স্ট্রিংটি বৈধ UTF-8।
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// একটি নামকরণযোগ্য, ক্লোনযোগ্য এফএন টাইপ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // নিরাপদ: নিরাপদ নয়
        unsafe { from_utf8_unchecked(bytes) }
    };
}