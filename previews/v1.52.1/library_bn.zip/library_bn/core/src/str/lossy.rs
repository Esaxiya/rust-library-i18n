use crate::char;
use crate::fmt::{self, Write};
use crate::mem;

use super::from_utf8_unchecked;
use super::validations::utf8_char_width;

/// লসী এক্স00 এক্স স্ট্রিং।
#[unstable(feature = "str_internals", issue = "none")]
pub struct Utf8Lossy {
    bytes: [u8],
}

impl Utf8Lossy {
    pub fn from_str(s: &str) -> &Utf8Lossy {
        Utf8Lossy::from_bytes(s.as_bytes())
    }

    pub fn from_bytes(bytes: &[u8]) -> &Utf8Lossy {
        // নিরাপত্তা: উভয়ই একই মেমরি লেআউট ব্যবহার করে এবং UTF-8 যথার্থতা প্রয়োজন হয় না।
        unsafe { mem::transmute(bytes) }
    }

    pub fn chunks(&self) -> Utf8LossyChunksIter<'_> {
        Utf8LossyChunksIter { source: &self.bytes }
    }
}

/// ক্ষতিকারক UTF-8 স্ট্রিংয়ের উপরে আইট্রেটার
#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_debug_implementations)]
pub struct Utf8LossyChunksIter<'a> {
    source: &'a [u8],
}

#[unstable(feature = "str_internals", issue = "none")]
#[derive(PartialEq, Eq, Debug)]
pub struct Utf8LossyChunk<'a> {
    /// বৈধ অক্ষরের ক্রম
    /// ভাঙা UTF-8 অক্ষরের মাঝে খালি থাকতে পারে।
    pub valid: &'a str,
    /// একক ভাঙা চর, খালি যদি না হয়।
    /// খালি iff পুনরাবৃত্তি আইটেম শেষ।
    pub broken: &'a [u8],
}

impl<'a> Iterator for Utf8LossyChunksIter<'a> {
    type Item = Utf8LossyChunk<'a>;

    fn next(&mut self) -> Option<Utf8LossyChunk<'a>> {
        if self.source.is_empty() {
            return None;
        }

        const TAG_CONT_U8: u8 = 128;
        fn safe_get(xs: &[u8], i: usize) -> u8 {
            *xs.get(i).unwrap_or(&0)
        }

        let mut i = 0;
        while i < self.source.len() {
            let i_ = i;

            // নিরাপদ: `i` `0` থেকে শুরু হয়, `self.source.len()` এর চেয়ে কম, এবং
            // শুধুমাত্র বৃদ্ধি, তাই `0 <= i < self.source.len()`।
            let byte = unsafe { *self.source.get_unchecked(i) };
            i += 1;

            if byte < 128 {
            } else {
                let w = utf8_char_width(byte);

                macro_rules! error {
                    () => {{
                        // নিরাপত্তা: আমরা `i` পর্যন্ত পরীক্ষা করেছি যে উত্সটি বৈধ UTF-8।
                        unsafe {
                            let r = Utf8LossyChunk {
                                valid: from_utf8_unchecked(&self.source[0..i_]),
                                broken: &self.source[i_..i],
                            };
                            self.source = &self.source[i..];
                            return Some(r);
                        }
                    }};
                }

                match w {
                    2 => {
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    3 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xE0, 0xA0..=0xBF) => (),
                            (0xE1..=0xEC, 0x80..=0xBF) => (),
                            (0xED, 0x80..=0x9F) => (),
                            (0xEE..=0xEF, 0x80..=0xBF) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    4 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xF0, 0x90..=0xBF) => (),
                            (0xF1..=0xF3, 0x80..=0xBF) => (),
                            (0xF4, 0x80..=0x8F) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    _ => {
                        error!();
                    }
                }
            }
        }

        let r = Utf8LossyChunk {
            // নিরাপত্তা: আমরা পরীক্ষা করেছি যে পুরো উত্সটি বৈধ UTF-8।
            valid: unsafe { from_utf8_unchecked(self.source) },
            broken: &[],
        };
        self.source = &[];
        Some(r)
    }
}

impl fmt::Display for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // আমরা যদি খালি স্ট্রিং হয়ে থাকি তবে আমাদের পুনরুক্তিকারী আসলে কোনও ফল দেয় না, সুতরাং নিজেই ফরম্যাটিংটি সম্পাদন করুন
        //
        if self.bytes.is_empty() {
            return "".fmt(f);
        }

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // যদি আমরা সফলভাবে পুরো খণ্ডটিকে একটি বৈধ স্ট্রিং হিসাবে ডিকোড করি তবে আমরা স্ট্রিংয়ের সরাসরি ফর্ম্যাটিংটি ফিরিয়ে দিতে পারি যা সম্ভব হলে বিভিন্ন ফর্ম্যাটিং ফ্ল্যাগকে সম্মান জানায়।
            //
            //
            if valid.len() == self.bytes.len() {
                assert!(broken.is_empty());
                return valid.fmt(f);
            }

            f.write_str(valid)?;
            if !broken.is_empty() {
                f.write_char(char::REPLACEMENT_CHARACTER)?;
            }
        }
        Ok(())
    }
}

impl fmt::Debug for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_char('"')?;

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // বৈধ অংশ।
            // এখানে আমরা আংশিকভাবে আবার UTF-8 কে পার্স করে যা সাবপটিমাল।
            {
                let mut from = 0;
                for (i, c) in valid.char_indices() {
                    let esc = c.escape_debug();
                    // চরটি যদি পালানোর দরকার হয় তবে এতক্ষণ ব্যাকলগটি ফ্লাশ করুন এবং লিখুন, অন্যথায় এড়িয়ে যান
                    if esc.len() != 1 {
                        f.write_str(&valid[from..i])?;
                        for c in esc {
                            f.write_char(c)?;
                        }
                        from = i + c.len_utf8();
                    }
                }
                f.write_str(&valid[from..])?;
            }

            // হেক্স পলায়নের জন্য স্ট্রিংয়ের ভাঙা অংশ।
            for &b in broken {
                write!(f, "\\x{:02x}", b)?;
            }
        }

        f.write_char('"')
    }
}