//! utf8 ত্রুটি প্রকারের সংজ্ঞা দেয়।

use crate::fmt;

/// ত্রুটিগুলি যা [`u8`] এর ক্রমটিকে স্ট্রিং হিসাবে ব্যাখ্যা করার চেষ্টা করার সময় ঘটতে পারে।
///
/// যেমন, [`স্ট্রিং] এর এবং [`&str`] উভয়ের জন্য ফাংশন এবং পদ্ধতিগুলির `from_utf8` পরিবার এই ত্রুটিটি ব্যবহার করে, উদাহরণস্বরূপ।
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// এই ত্রুটি ধরণের পদ্ধতিগুলি হ্যাপ মেমরির বরাদ্দ না করে `String::from_utf8_lossy` এর অনুরূপ কার্যকারিতা তৈরি করতে ব্যবহার করা যেতে পারে:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// প্রদত্ত স্ট্রিংয়ে সূচিটি প্রদান করে যা বৈধ UTF-8 যাচাই করা হয়েছিল।
    ///
    /// এটি সর্বাধিক সূচক যে `from_utf8(&input[..index])` `Ok(_)` প্রদান করবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::str;
    ///
    /// // একটি vector এ কিছু অবৈধ বাইট
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 একটি Utf8Error প্রদান করে
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // দ্বিতীয় বাইটটি এখানে অবৈধ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ব্যর্থতা সম্পর্কে আরও তথ্য সরবরাহ করে:
    ///
    /// * `None`: ইনপুটটির শেষটি অপ্রত্যাশিতভাবে পৌঁছেছিল।
    ///   `self.valid_up_to()` ইনপুট শেষে 1 থেকে 3 বাইট হয়।
    ///   যদি কোনও বাইট স্ট্রিম (যেমন কোনও ফাইল বা কোনও নেটওয়ার্ক সকেট) ক্রমবর্ধমানভাবে ডিকোড করা হচ্ছে, এটি একটি বৈধ `char` হতে পারে যার এক্স01 এক্স বাইট ক্রমটি একাধিক খণ্ড বিস্তৃত।
    ///
    ///
    /// * `Some(len)`: একটি অপ্রত্যাশিত বাইট সম্মুখীন হয়েছিল।
    ///   প্রদত্ত দৈর্ঘ্যটি `valid_up_to()` এর দেওয়া সূচীতে শুরু হওয়া অবৈধ বাইট অনুক্রমটি।
    ///   ক্ষতিকারক ডিকোডিংয়ের ক্ষেত্রে সেই অনুক্রমের পরে (একটি [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] সন্নিবেশ করার পরে) ডিকোডিং আবার শুরু করা উচিত।
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] ব্যবহার করে একটি `bool` পার্স করার সময় একটি ত্রুটি ফিরে এসেছিল
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}