//! বাইট স্লাইস থেকে একটি `str` তৈরি করার উপায়।

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// বাইটের স্লাইসটিকে স্ট্রিং স্লাইসে রূপান্তর করে।
///
/// একটি স্ট্রিং স্লাইস ([`&str`]) বাইট ([`u8`]) দ্বারা তৈরি করা হয়, এবং একটি বাইট স্লাইস ([`&[u8]`][byteslice]) বাইট দ্বারা তৈরি করা হয়, সুতরাং এই ফাংশনটি দুটির মধ্যে রূপান্তরিত হয়।
/// সমস্ত বাইট স্লাইস বৈধ স্ট্রিং স্লাইস নয়, তবে: [`&str`] এর বৈধ UTF-8 হওয়া দরকার।
/// `from_utf8()` বাইটগুলি UTF-8 X বৈধ কিনা তা নিশ্চিত করার জন্য চেক করে এবং তারপরে রূপান্তরটি করে।
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// আপনি যদি নিশ্চিত হন যে বাইট স্লাইসটি বৈধ UTF-8, এবং আপনি বৈধতা চেকের ওভারহেডটি ব্যয় করতে চান না, তবে এই ফাংশনটির একটি অনিরাপদ সংস্করণ রয়েছে, এক্স01 এক্স, যা একই আচরণ করে তবে চেকটি এড়িয়ে যায়।
///
///
/// আপনার যদি `&str` এর পরিবর্তে `String` দরকার হয় তবে [`String::from_utf8`][string] বিবেচনা করুন।
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// আপনি একটি `[u8; N]` স্ট্যাক-বরাদ্দ করতে পারেন এবং আপনি এটির একটি [`&[u8]`][byteslice] নিতে পারেন, এই স্ট্যাকটি স্ট্যাক-বরাদ্দ স্ট্রিংয়ের এক উপায়।নীচে উদাহরণ বিভাগে এর একটি উদাহরণ রয়েছে।
///
/// [byteslice]: slice
///
/// # Errors
///
/// প্রদত্ত স্লাইসটি UTF-8 কেন নয় তা বিবরণ দিয়ে স্লাইস UTF-8 না হলে `Err` প্রদান করে।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::str;
///
/// // কিছু বাইট, একটি vector এ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // আমরা জানি এই বাইটগুলি বৈধ, তাই কেবল `unwrap()` ব্যবহার করুন।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ভুল বাইট:
///
/// ```
/// use std::str;
///
/// // একটি vector এ কিছু অবৈধ বাইট
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// যে ধরণের ত্রুটি ফিরে আসতে পারে সে সম্পর্কে আরও বিশদের জন্য ডক্সগুলি [`Utf8Error`] এর জন্য দেখুন।
///
/// একটি এক্স 100 এক্স:
///
/// ```
/// use std::str;
///
/// // কিছু বাইট, একটি স্ট্যাক বরাদ্দ অ্যারে
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // আমরা জানি এই বাইটগুলি বৈধ, তাই কেবল `unwrap()` ব্যবহার করুন।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // নিরাপদ: সবেমাত্র বৈধতা চালানো।
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// বাইটের একটি মিউটেবল স্লাইসকে একটি পরিবর্তনীয় স্ট্রিং স্লাইসে রূপান্তর করে।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" একটি পরিবর্তনীয় vector হিসাবে
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // যেহেতু আমরা জানি এই বাইটগুলি বৈধ, আমরা `unwrap()` ব্যবহার করতে পারি
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ভুল বাইট:
///
/// ```
/// use std::str;
///
/// // একটি পরিবর্তনীয় vector এ কিছু অবৈধ বাইট
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// যে ধরণের ত্রুটি ফিরে আসতে পারে সে সম্পর্কে আরও বিশদের জন্য ডক্সগুলি [`Utf8Error`] এর জন্য দেখুন।
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // নিরাপদ: সবেমাত্র বৈধতা চালানো।
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// বাইটের একটি স্লাইসটি স্ট্রিং স্লাইসে রূপান্তর করে যাচাই করেই স্ট্রিংটিতে বৈধ UTF-8 রয়েছে।
///
/// আরও তথ্যের জন্য নিরাপদ সংস্করণ, [`from_utf8`] দেখুন।
///
/// # Safety
///
/// এই ফাংশনটি অনিরাপদ কারণ এটি পরীক্ষিত বাইটগুলি বৈধ UTF-8 কিনা তা পরীক্ষা করে না।
/// যদি এই সীমাবদ্ধতা লঙ্ঘন করা হয়, অপরিজ্ঞাত আচরণের ফলাফল, যেমন Rust এর বাকী অংশ ধরে নেওয়া হয়েছে যে [`&str`] গুলি বৈধ UTF-8।
///
///
/// [`&str`]: str
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::str;
///
/// // কিছু বাইট, একটি vector এ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // নিরাপদ: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে বাইটগুলি `v` বৈধ UTF-8।
    // এছাড়াও একই লেআউট থাকা `&str` এবং `&[u8]` উপর নির্ভর করে।
    unsafe { mem::transmute(v) }
}

/// বাইটের একটি স্লাইসটি স্ট্রিং স্লাইসে রূপান্তর করে যাচাই করেই স্ট্রিংটিতে বৈধ UTF-8 রয়েছে;পরিবর্তনীয় সংস্করণ।
///
///
/// আরও তথ্যের জন্য অপরিবর্তনীয় সংস্করণ, [`from_utf8_unchecked()`] দেখুন।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // নিরাপদ: কলার অবশ্যই গ্যারান্টি দেয় যে বাইটস X00 এক্স
    // বৈধ এক্স 100 এক্স, সুতরাং `*mut str` এ castালাই নিরাপদ।
    // এছাড়াও, পয়েন্টারের বিন্যাসটি নিরাপদ কারণ পয়েন্টারটি এমন একটি রেফারেন্স থেকে আসে যা লেখার জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}