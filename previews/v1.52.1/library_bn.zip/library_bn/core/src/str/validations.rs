//! UTF-8 বৈধতা সম্পর্কিত অপারেশন।

use crate::mem;

use super::Utf8Error;

/// প্রথম বাইটের জন্য প্রাথমিক কোডপয়েন্ট নিয়োগকারীকে ফেরত দেয়।
/// প্রথম বাইটটি বিশেষ, কেবল প্রস্থ 2 এর নীচে 5 বিট, 3 প্রস্থের 4 বিট এবং প্রস্থ 4 এর জন্য 3 বিট চাই।
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// ধারাবাহিকতা বাইট `byte` এর সাথে আপডেট হওয়া `ch` এর মান প্রদান করে।
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// বাইটটি কোনও UTF-8 ধারাবাহিকতা বাইট কিনা (যেমন, বিট `10` দিয়ে শুরু হয়) তা পরীক্ষা করে।
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// বাইট পুনরুক্তকারী (পরবর্তীকালে একটি ইউটিএফ-8-এর মতো এনকোডিং ধরে রেখে) পরবর্তী কোড পয়েন্টটি পড়ে।
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ডিকোড এক্স 100 এক্স
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // মাল্টিবাইট কেস বাইট কম্বিনেশন থেকে ডিকোড অনুসরণ করে: [[[x y] z] w]
    //
    // NOTE: পারফরম্যান্স এখানে সঠিক গঠনের সংবেদনশীল
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] ডাব্লু] কেস
        // 0xE0 এ 5 তম বিট .. 0xEF সর্বদা পরিষ্কার থাকে, তাই `init` এখনও বৈধ
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] কেস কেবলমাত্র `init` এর নিম্ন 3 বিট ব্যবহার করুন
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// বাইট পুনরুক্তি (শেষ পর্যন্ত একটি ইউটিএফ-8-এর মতো এনকোডিং ধরে রেখে) এর শেষ কোড পয়েন্টটি পড়ে।
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ডিকোড এক্স 100 এক্স
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // মাল্টিবাইট কেস বাইট কম্বিনেশন থেকে ডিকোড অনুসরণ করে: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// এক্স 100 এক্সকে ইউজ করতে ফিট করতে ট্র্যাঙ্কেশন ব্যবহার করুন
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` শব্দটির কোনও বাইট যদি ননাসেই (>=128) হয় তবে `true` প্রদান করে।
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` পরীক্ষা করে দেখুন যে এটি বৈধ UTF-8 অনুক্রম, সেই ক্ষেত্রে `Ok(())` ফেরত, বা, যদি এটি অবৈধ হয়, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // আমাদের ডেটা দরকার, কিন্তু কিছুই ছিল না: ত্রুটি!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-বাইট এনকোডিং কোডপয়েন্টস\u {0080} থেকে\u {07ff} প্রথম C2 80 সর্বশেষ ডিএফ বিএফের জন্য
            // 3-বাইট এনকোডিং কোডপয়েন্টস\u {0800} থেকে\u {ffff for প্রথম E0 A0 80 সর্বশেষ ইএফ বিএফ বিএফ ব্যতীত সারোগেটস কোডপয়েন্টস\u {d800} থেকে\u {dfff} ED A0 80 থেকে ED BF BF
            // 4-বাইট এনকোডিং কোডপয়েন্টগুলির জন্য\u {1000} 0 থেকে\u {10ff} ff প্রথম F0 90 80 80 সর্বশেষ F4 8F বিএফ বিএফ
            //
            // আরএফসি থেকে UTF-8 সিনট্যাক্স ব্যবহার করুন
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-লেজ UTF8-3= %xE0% xA0-BF UTF8-লেজ/% xE1-ইসি 2( UTF8-tail )/%xED% x80-9F UTF8-লেজ/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // আসকি কেস, দ্রুত এগিয়ে যাওয়ার চেষ্টা করুন।
            // যখন পয়েন্টারটি সারিবদ্ধ থাকে, ততক্ষণ পর্যন্ত পুনরাবৃত্তির জন্য 2 টি ডেটার শব্দ পড়ুন যতক্ষণ না আমরা অ-এস্কি বাইটযুক্ত কোনও শব্দ খুঁজে না পাই।
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // নিরাপদ: যেহেতু `align - index` এবং `ascii_block_size` রয়েছে
                    // `usize_bytes`, `block = ptr.add(index)` এর গুণাগুণ সর্বদা একটি `usize` এর সাথে সংযুক্ত থাকে তাই এটি `block` এবং `block.offset(1)` উভয়কেই ডিফারেন্স করা নিরাপদ।
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // একটি ননস্কি বাইট থাকলে বিরতি
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // শব্দবহুল লুপ যে বিন্দুতে থামল সেখান থেকে পদক্ষেপ নিন
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// একটি প্রথম বাইট দেওয়া, নির্ধারণ করে যে এই এক্স 100 এক্স অক্ষরে কত বাইট রয়েছে।
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// একটি ধারাবাহিকতা বাইটের মান বিটের মুখোশ।
const CONT_MASK: u8 = 0b0011_1111;
/// ধারাবাহিকতা বাইটের ট্যাগ বিটের মান (ট্যাগ মাস্কটি !CONT_MASK)।
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` কে দৈর্ঘ্যে সর্বাধিক সমান করে `max` রিটার্ন করুন `true` যদি এটি কেটে ফেলা হয় এবং নতুন স্ট্রিং থাকে।
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}