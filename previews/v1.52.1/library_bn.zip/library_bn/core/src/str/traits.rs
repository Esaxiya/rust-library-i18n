//! `str` এর জন্য জেড 0 ট্রায়িট0 জেড বাস্তবায়ন।

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// স্ট্রিংয়ের ক্রম সরবরাহ করে।
///
/// স্ট্রিংগুলি তাদের বাইট মান দ্বারা [lexicographically](Ord#lexicographical-comparison) অর্ডার করা হয়।
/// কোড চার্টে তাদের অবস্থানের ভিত্তিতে এই ইউনিকোড কোড পয়েন্ট অর্ডার করে।
/// এটি অগত্যা "alphabetical" আদেশের মতো নয়, যা ভাষা এবং স্থানীয়ভাবে পরিবর্তিত হয়।
/// সাংস্কৃতিকভাবে-স্বীকৃত মান অনুযায়ী স্ট্রিং সাজানোর জন্য লোকেল-নির্দিষ্ট ডেটা প্রয়োজন যা `str` প্রকারের বাইরে নয় scope
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// স্ট্রিংগুলিতে তুলনা অপারেশনগুলি কার্যকর করে।
///
/// স্ট্রিংগুলি তাদের বাইট মান দ্বারা [lexicographically](Ord#lexicographical-comparison) এর সাথে তুলনা করা হয়।
/// এটি কোড চার্টে তাদের অবস্থানের ভিত্তিতে ইউনিকোড কোড পয়েন্টগুলির তুলনা করে।
/// এটি অগত্যা "alphabetical" আদেশের মতো নয়, যা ভাষা এবং স্থানীয়ভাবে পরিবর্তিত হয়।
/// সাংস্কৃতিকভাবে-স্বীকৃত মান অনুযায়ী স্ট্রিং তুলনা করতে লোকেল-নির্দিষ্ট ডেটা প্রয়োজন যা `str` প্রকারের বাইরে নয়।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// পুরো স্ট্রিংয়ের এক স্লাইস, অর্থাৎ `&self` বা `&mut self` প্রদান করে।`&স্বের সাথে সমান [0 ..
/// লেন] `বা`&স্ব পরিবর্তন করুন [0 ..
/// len]`.
/// অন্যান্য সূচীকরণ অপারেশনগুলির বিপরীতে, এটি কখনই panic করতে পারে না।
///
/// এই অপারেশনটি *ও*(1)।
///
/// 1.20.0 এর আগে, এই সূচীকরণ ক্রিয়াকলাপগুলি এখনও `Index` এবং `IndexMut` সরাসরি প্রয়োগের দ্বারা সমর্থিত ছিল।
///
/// `&self[0 .. len]` বা `&mut self[0 .. len]` এর সমান।
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// বাইট পরিসীমা [`বিগিনিউ, এক্স00 এক্স) থেকে প্রদত্ত স্ট্রিংয়ের একটি স্লাইস প্রদান করে।
///
/// এই অপারেশনটি *ও*(1)।
///
/// 1.20.0 এর আগে, এই সূচীকরণ ক্রিয়াকলাপগুলি এখনও `Index` এবং `IndexMut` সরাসরি প্রয়োগের দ্বারা সমর্থিত ছিল।
///
/// # Panics
///
/// যদি `begin` বা `end` কোনও অক্ষরের প্রারম্ভিক বাইট অফসেটটি নির্দেশ করে না তবে Panics (`is_char_boundary` দ্বারা নির্ধারিত হিসাবে), যদি `begin > end`, অথবা `end > len` হয়।
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // এগুলি panic করবে:
/// // বাইট 2 `ö` এর মধ্যে রয়েছে:
/// // &গুলি [2 ..3];
///
/// // বাইট 8 এক্স X এক্স এর মধ্যে রয়েছে [1 ..
/// // 8];
///
/// // বাইট 100 স্ট্রিং এর বাইরে রয়েছে [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // নিরাপত্তা: সবেমাত্র `start` এবং `end` চরের সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            // আমরা চরের সীমানাও পরীক্ষা করেছিলাম, সুতরাং এটি কার্যকর UTF-8।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // নিরাপদ: সবেমাত্র `start` এবং `end` চরের সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে।
            // আমরা জানি যে পয়েন্টারটি অনন্য, কারণ আমরা এটি `slice` থেকে পেয়েছি।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // নিরাপত্তা: কলার গ্যারান্টি দেয় যে `self` `slice` এর সীমানায় রয়েছে
        // যা `add` এর সমস্ত শর্ত পূরণ করে।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // নিরাপদ: `get_unchecked` এর জন্য মন্তব্যগুলি দেখুন।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary চেক করে যে সূচকটি [0, .len()] NLL সমস্যার কারণে `get` পুনরায় ব্যবহার করতে পারে না
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // নিরাপত্তা: সবেমাত্র `start` এবং `end` চরের সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// বাইট পরিসর [`0`, `end`) থেকে প্রদত্ত স্ট্রিংয়ের একটি টুকরা ফেরত দেয়।
/// `&self[0 .. end]` বা `&mut self[0 .. end]` এর সমান।
///
/// এই অপারেশনটি *ও*(1)।
///
/// 1.20.0 এর আগে, এই সূচীকরণ ক্রিয়াকলাপগুলি এখনও `Index` এবং `IndexMut` সরাসরি প্রয়োগের দ্বারা সমর্থিত ছিল।
///
/// # Panics
///
/// Panics যদি `end` কোনও অক্ষরের প্রারম্ভিক বাইট অফসেট (`is_char_boundary` দ্বারা নির্ধারিত হিসাবে) বা `end > len` নির্দেশ করে না।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // নিরাপত্তা: সবেমাত্র `end` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // নিরাপত্তা: সবেমাত্র `end` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // নিরাপত্তা: সবেমাত্র `end` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// বাইট পরিসীমা [`বিগিনিউ, এক্স00 এক্স) থেকে প্রদত্ত স্ট্রিংয়ের একটি স্লাইস প্রদান করে।`&স্বের সমান [শুরু ..
/// লেন] `বা`&স্বতঃপ্রণালী [আরম্ভ করুন ..
/// len]`.
///
/// এই অপারেশনটি *ও*(1)।
///
/// 1.20.0 এর আগে, এই সূচীকরণ ক্রিয়াকলাপগুলি এখনও `Index` এবং `IndexMut` সরাসরি প্রয়োগের দ্বারা সমর্থিত ছিল।
///
/// # Panics
///
/// Panics যদি `begin` কোনও অক্ষরের প্রারম্ভিক বাইট অফসেট (`is_char_boundary` দ্বারা নির্ধারিত হিসাবে) বা `begin > len` নির্দেশ করে না।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // নিরাপত্তা: সবেমাত্র `start` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // নিরাপত্তা: সবেমাত্র `start` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // নিরাপত্তা: কলার গ্যারান্টি দেয় যে `self` `slice` এর সীমানায় রয়েছে
        // যা `add` এর সমস্ত শর্ত পূরণ করে।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // নিরাপদ: `get_unchecked` এর অনুরূপ।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // নিরাপত্তা: সবেমাত্র `start` একটি চতুর্দিকে সীমানায় রয়েছে তা পরীক্ষা করে দেখেছে,
            // এবং আমরা একটি নিরাপদ রেফারেন্সে যাচ্ছি, সুতরাং ফেরতের মানটিও এক হবে।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// [`begin`, `end`] বাইট পরিসর থেকে প্রদত্ত স্ট্রিংয়ের একটি স্লাইস প্রদান করে।`&self [begin .. end + 1]` বা `&mut self[begin .. end + 1]` এর সমতুল্য, যদি `end` এর `usize` এর সর্বাধিক মান থাকে।
///
/// এই অপারেশনটি *ও*(1)।
///
/// # Panics
///
/// Panics যদি `begin` একটি অক্ষরের প্রারম্ভিক বাইট অফসেটটি নির্দেশ না করে (`is_char_boundary` দ্বারা সংজ্ঞায়িত করা হয়), যদি `end` কোনও অক্ষরের শেষ বাইট অফসেটটি নির্দেশ না করে (`end + 1` হয় হয় একটি শুরু বাইট অফসেট বা `len` এর সমান), যদি `begin > end` হয়, বা যদি `end >= len` হয়।
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // সুরক্ষা: কলকারীকে অবশ্যই `get_unchecked` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // সুরক্ষা: কলকারীকে অবশ্যই `get_unchecked_mut` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// সিনট্যাক্স এক্স01 এক্স বা এক্স 100 এক্সের সাথে স্ট্রাইং স্লাস্টিং প্রয়োগ করে।
///
/// [0, `end`] বাইট পরিসর থেকে প্রদত্ত স্ট্রিংয়ের একটি স্লাইস প্রদান করে।
/// `&self [0 .. end + 1]` এর সমান, যদি `end` এর `usize` এর সর্বাধিক মান থাকে।
///
/// এই অপারেশনটি *ও*(1)।
///
/// # Panics
///
/// Panics যদি `end` কোনও অক্ষরের শেষ বাইট অফসেটটি নির্দেশ না করে (`end + 1` হয় `is_char_boundary` দ্বারা সংজ্ঞায়িত হিসাবে বা একটি এক্স04 এক্স এর সমান) একটি প্রারম্ভিক বাইট অফসেট, অথবা যদি `end >= len` হয়।
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // সুরক্ষা: কলকারীকে অবশ্যই `get_unchecked` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // সুরক্ষা: কলকারীকে অবশ্যই `get_unchecked_mut` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// স্ট্রিং থেকে একটি মান পার্স করুন
///
/// `FromStr` এর [`from_str`] পদ্ধতিটি [imp str`] এর [`parse`] পদ্ধতির মাধ্যমে প্রায়শই স্পষ্টভাবে ব্যবহৃত হয়।
/// উদাহরণের জন্য [ars পার্সে] এর ডকুমেন্টেশন দেখুন।
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` আজীবন প্যারামিটারটি নেই এবং তাই আপনি কেবলমাত্র এমন পার্স করতে পারেন যা আজীবন প্যারামিটারে থাকে না।
///
/// অন্য কথায়, আপনি `FromStr` দিয়ে একটি এক্স 2 এক্স এক্স পার্স করতে পারেন, তবে এক্স 100 এক্স নয়।
/// আপনি এমন একটি কাঠামো পার্স করতে পারেন যাতে একটি `i32` রয়েছে তবে এটিতে একটি `&i32` রয়েছে।
///
/// # Examples
///
/// `Point` ধরণের উদাহরণে `FromStr` এর বেসিক বাস্তবায়ন:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// সম্পর্কিত ত্রুটি যা পার্সিং থেকে ফিরে আসতে পারে।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// এই ধরণের একটি মান ফেরত দিতে একটি স্ট্রিং `s` পার্স করে।
    ///
    /// যদি পার্সিং সফল হয়, [`Ok`] এর মধ্যে মানটি ফিরিয়ে দিন, অন্যথায় স্ট্রিংটি যখন ফর্ম্যাট হয় তখন [`Err`] এর ভিতরে নির্দিষ্ট একটি ত্রুটি ফিরে আসে।
    /// ত্রুটির ধরণটি trait বাস্তবায়নের জন্য নির্দিষ্ট।
    ///
    /// # Examples
    ///
    /// [`i32`] এর সাথে প্রাথমিক ব্যবহার, এক প্রকার যা `FromStr` প্রয়োগ করে:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// একটি স্ট্রিং থেকে একটি এক্স 100 এক্স পার্স করুন।
    ///
    /// একটি `Result<bool, ParseBoolError>` ফলন দেয় কারণ `s` আসলে পার্সেবল হতে পারে বা নাও পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// দ্রষ্টব্য, অনেক ক্ষেত্রে `str` এর `.parse()` পদ্ধতিটি আরও সঠিক।
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}