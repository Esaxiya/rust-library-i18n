#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! বিদেশী ফাংশন ইন্টারফেস (FFI) বাইন্ডিং সম্পর্কিত ইউটিলিটিস।

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// এক্স এর এক্স X1 এক্স টাইপের সমান যখন এক্স 100 এক্স হিসাবে ব্যবহৃত হয়।
///
/// সংক্ষেপে, `*const c_void` সি এর এক্স02 এক্স এর সমতুল্য এবং এক্স03 এক্স সি এর এক্স 100 এক্স এর সমতুল্য।
/// এটি বলেছিল, এটি সি এর এক্স 100 এক্স রিটার্ন টাইপের মতো নয় * যা জেড 0 রুস্ট0 জেড এর এক্স01 এক্স টাইপ।
///
/// এফএফআই-তে অস্বচ্ছ ধরণের পয়েন্টার মডেল করতে, `extern type` স্থিতিশীল না হওয়া পর্যন্ত খালি বাইট অ্যারের আশেপাশে একটি newtype র‌্যাপার ব্যবহার করার পরামর্শ দেওয়া হয়।
///
/// বিশদের জন্য এক্স 100 এক্স দেখুন।
///
/// কেউ যদি 1.1.0 এ পুরানো জেড 0 রিস্ট0 জেড সংকলকটি সমর্থন করতে চান তবে কেউ `std::os::raw::c_void` ব্যবহার করতে পারেন।
/// Rust 1.30.0 এর পরে, এই সংজ্ঞা দ্বারা এটি পুনরায় রফতানি করা হয়েছিল।
/// আরও তথ্যের জন্য, দয়া করে [RFC 2521] পড়ুন।
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// এনবি, এলএলভিএম শূন্য পয়েন্টার প্রকারটি সনাক্ত করতে এবং এক্স 100 এক্স এর মতো এক্সটেনশন ফাংশন দ্বারা, এটি এলএলভিএম বিটকোডে আই 8 * হিসাবে উপস্থাপন করা আমাদের দরকার।
// এখানে ব্যবহৃত এনাম এটি নিশ্চিত করে এবং কেবলমাত্র ব্যক্তিগত ভেরিয়েন্ট ব্যবহার করে "raw" প্রকারের অপব্যবহার প্রতিরোধ করে।
// আমাদের দুটি রূপের প্রয়োজন, কারণ সংকলক অন্যথায় repr বৈশিষ্ট্য সম্পর্কে অভিযোগ করে এবং আমাদের কমপক্ষে একটি বৈকল্পিক প্রয়োজন অন্যথায় এনাম নির্বাসিত হবে এবং কমপক্ষে এই জাতীয় পয়েন্টারগুলি UB হবে।
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// একটি `va_list` এর বেসিক বাস্তবায়ন।
// নামটি ডাব্লুআইপি, আপাতত `VaListImpl` ব্যবহার করে।
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` এর চেয়ে বেশি অবিচ্ছিন্ন, সুতরাং প্রতিটি `VaListImpl<'f>` অবজেক্টটি এর সংজ্ঞায়িত ফাংশনের অঞ্চলে আবদ্ধ থাকে
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI একটি `va_list` এর বাস্তবায়ন।
/// আরও তথ্যের জন্য [AArch64 Procedure Call Standard] দেখুন।
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI একটি `va_list` এর বাস্তবায়ন।
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI একটি `va_list` এর বাস্তবায়ন।
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` এর জন্য একটি মোড়ক
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// কোনও `VaListImpl` কে `VaList` তে রূপান্তর করুন যা সি এর এক্স 100 এক্সের সাথে বাইনারি-সামঞ্জস্যপূর্ণ।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// কোনও `VaListImpl` কে `VaList` তে রূপান্তর করুন যা সি এর এক্স 100 এক্সের সাথে বাইনারি-সামঞ্জস্যপূর্ণ।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait জনসাধারণের ইন্টারফেসে ব্যবহার করা দরকার, তবে, trait নিজেই এই মডিউলটির বাইরে ব্যবহারের অনুমতি দেওয়া উচিত নয়।
// ব্যবহারকারীদের একটি নতুন ধরণের জন্য trait বাস্তবায়নের মঞ্জুরি দেওয়া (এর ফলে va_arg অভ্যন্তরীণটিকে একটি নতুন ধরণের ক্ষেত্রে ব্যবহার করার অনুমতি দেওয়া হবে) অপরিবর্তিত আচরণের কারণ হতে পারে।
//
// FIXME(dlrobertson): ভ্যাআআআরআরগসেফ জেডট্রেইট0 জেড একটি সার্বজনীন ইন্টারফেসে ব্যবহার করার জন্য তবে এটি অন্য কোথাও ব্যবহার করা যাবে না তা নিশ্চিত করার জন্য, trait একটি ব্যক্তিগত মডিউলের মধ্যে সর্বজনীন হওয়া দরকার।
// একবার আরএফসি 2145 কার্যকর করা হয়েছে এটির উন্নতির দিকে নজর দিন।
//
//
//
//
mod sealed_trait {
    /// Trait যা [super::VaListImpl::arg] এর সাথে অনুমোদিত প্রকারের ব্যবহারের অনুমতি দেয়।
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// পরের আর্গ থেকে অগ্রিম।
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // সুরক্ষা: কলকারীকে অবশ্যই `va_arg` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { va_arg(self) }
    }

    /// বর্তমান অবস্থানে `va_list` অনুলিপি করে।
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // সুরক্ষা: কলকারীকে অবশ্যই `va_end` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // নিরাপদ: আমরা `MaybeUninit` এ লিখি, সুতরাং এটি সূচনা হয় এবং `assume_init` আইনী
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: এটিতে `va_end` কল করা উচিত, তবে এর কোনও পরিষ্কার উপায় নেই
        // গ্যারান্টি দিন যে `drop` সর্বদা তার কলারের সাথে যুক্ত হয়, সুতরাং `va_end` একই এক্স ফ্যাক্স থেকে সরাসরি `va_copy` এর মতোই ডাকা হবে।
        // `man va_end` সি উল্লেখ করেছে যে, এবং এলএলভিএম মূলত সি শব্দার্থকে অনুসরণ করে, তাই আমাদের নিশ্চিত করা দরকার যে `va_end` সর্বদা `va_copy` হিসাবে একই ফাংশন থেকে ডাকা হয়।
        //
        // বিস্তারিত জানার জন্য, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // এটি এখনের জন্য কাজ করে, যেহেতু `va_end` সমস্ত বর্তমান এলএলভিএম লক্ষ্যবস্তুগুলির একটি অপশন নয়।
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` বা `va_copy` দিয়ে আরম্ভ করার পরে আরগলিস্ট `ap` ধ্বংস করুন।
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// আরগলিস্ট `src` এর বর্তমান অবস্থানটি আরগলিস্ট `dst` এ অনুলিপি করে।
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` থেকে `T` প্রকারের একটি আর্গুমেন্ট লোড করে এবং `ap` পয়েন্টে আর্গুমেন্ট বৃদ্ধি করে।
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}