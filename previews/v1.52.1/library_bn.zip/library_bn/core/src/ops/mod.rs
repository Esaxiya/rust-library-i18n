//! ওভারলোডযোগ্য অপারেটররা।
//!
//! এই traits বাস্তবায়ন আপনাকে নির্দিষ্ট অপারেটরদের ওভারলোড করতে দেয়।
//!
//! এর মধ্যে কয়েকটি traits prelude দ্বারা আমদানি করা হয়, তাই এগুলি প্রতিটি Rust প্রোগ্রামে উপলব্ধ।কেবল traits দ্বারা সমর্থিত অপারেটরগুলি ওভারলোড করা যাবে।
//! উদাহরণস্বরূপ, সংযোজন অপারেটর (`+`) [`Add`] trait এর মাধ্যমে ওভারলোড করা যেতে পারে, তবে যেহেতু অ্যাসাইনমেন্ট অপারেটর (`=`) এর কোনও সমর্থন নেই trait, তাই এর শব্দার্থবিজ্ঞানগুলি ওভারলোড করার কোনও উপায় নেই।
//! অতিরিক্তভাবে, এই মডিউলটি নতুন অপারেটর তৈরির কোনও ব্যবস্থা সরবরাহ করে না।
//! যদি ট্রিটলেস ওভারলোডিং বা কাস্টম অপারেটরগুলির প্রয়োজন হয়, আপনার জেড 0 রিস্ট0 জেড এর সিনট্যাক্স প্রসারিত করতে ম্যাক্রোগুলি বা সংকলক প্লাগইনগুলির দিকে নজর দেওয়া উচিত।
//!
//! অপারেটর traits এর বাস্তবায়নগুলি তাদের যথাযথ অর্থ এবং [operator precedence] মাথায় রেখে তাদের নিজ নিজ প্রসঙ্গে উদ্বেগজনক হওয়া উচিত।
//! উদাহরণস্বরূপ, [`Mul`] বাস্তবায়ন করার সময়, অপারেশনের গুণনের সাথে কিছুটা সাদৃশ্য থাকা উচিত (এবং অস্পৃশ্যতার মতো প্রত্যাশিত বৈশিষ্ট্যগুলি ভাগ করে নেওয়া)।
//!
//! উল্লেখ্য যে `&&` এবং `||` অপারেটরগুলি শর্ট সার্কিট, অর্থাত্‍যদি তারা ফলাফলটিতে অবদান রাখে তবে কেবলমাত্র তাদের দ্বিতীয় অপারেন্ডকে মূল্যায়ন করে।যেহেতু এই আচরণটি traits দ্বারা প্রয়োগযোগ্য নয়, তাই `&&` এবং `||` ওভারলোডযোগ্য অপারেটর হিসাবে সমর্থিত নয়।
//!
//! অপারেটরদের অনেকেই তাদের অপারেটরগুলি মূল্য দিয়ে নেন।অন্তর্নির্মিত প্রকারগুলিতে জড়িত অ-জেনেরিক প্রসঙ্গে, এটি সাধারণত কোনও সমস্যা হয় না।
//! যাইহোক, জেনেরিক কোডে এই অপারেটরগুলি ব্যবহার করে, অপারেটরদের গ্রাস করতে দেওয়ার বিপরীতে যদি মানগুলি পুনরায় ব্যবহার করতে হয় তবে কিছু মনোযোগের প্রয়োজন।একটি বিকল্প হ'ল মাঝেমধ্যে [`clone`] ব্যবহার করা।
//! আরেকটি বিকল্প হ'ল রেফারেন্সের জন্য অতিরিক্ত অপারেটর বাস্তবায়ন সরবরাহ করার জন্য জড়িত ধরণের উপর নির্ভর করা।
//! উদাহরণস্বরূপ, ব্যবহারকারী-সংজ্ঞায়িত প্রকারের `T` যা সংযোজনকে সমর্থন করে বলে মনে করা হচ্ছে, `T` এবং `&T` উভয়ই traits [`Add<T>`][`Add`] এবং [`Add<&T>`][`Add`] বাস্তবায়ন করা যাতে জেনেরিক কোডটি অপ্রয়োজনীয় ক্লোনিং ছাড়াই লেখা যায়।
//!
//!
//! # Examples
//!
//! এই উদাহরণটি একটি `Point` স্ট্রাক্ট তৈরি করে যা [`Add`] এবং [`Sub`] প্রয়োগ করে এবং তারপরে দুটি `পয়েন্ট` যোগ এবং বিয়োগ করে দেখায়।
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! উদাহরণস্বরূপ বাস্তবায়নের জন্য প্রতিটি trait এর জন্য ডকুমেন্টেশন দেখুন।
//!
//! [`Fn`], [`FnMut`], এবং [`FnOnce`] traits এমন ধরণের মাধ্যমে প্রয়োগ করা হয় যা ফাংশনের মতো আহ্বান জানানো যেতে পারে।দ্রষ্টব্য যে [`Fn`] `&self` নেয়, [`FnMut`] এক্স07 এক্স নেয় এবং এক্স08 এক্স `self` নেয়।
//! এগুলি তিন ধরণের পদ্ধতির সাথে সামঞ্জস্য হয় যা উদাহরণ হিসাবে আহ্বান করা যেতে পারে: কল-বাই-রেফারেন্স, কল-বাই-মিউটেবল-রেফারেন্স এবং কল-বাই-ভ্যালু।
//! এই traits এর সর্বাধিক সাধারণ ব্যবহার হ'ল উচ্চ-স্তরের ফাংশনের সীমানা হিসাবে কাজ করা যা আর্গুমেন্ট হিসাবে ফাংশন বা ক্লোজার গ্রহণ করে।
//!
//! একটি প্যারামিটার হিসাবে একটি [`Fn`] নেওয়া:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! একটি প্যারামিটার হিসাবে একটি [`FnMut`] নেওয়া:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! একটি প্যারামিটার হিসাবে একটি [`FnOnce`] নেওয়া:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` এটির ক্যাপচারড ভেরিয়েবলগুলি গ্রাস করে, তাই এটি একাধিকবার চালানো যায় না
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // আবার এক্স01 এক্স চাওয়ার চেষ্টা করা `func` এর জন্য একটি এক্স02 এক্স ত্রুটি নিক্ষেপ করবে
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` এই মুহুর্তে আর প্রার্থনা করা যাবে না
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;