/// অপরিবর্তনীয় প্রসঙ্গে (`container[index]`) সূচীকরণের জন্য ব্যবহৃত হয়।
///
/// `container[index]` আসলে এক্স00 এক্স এর সিনট্যাকটিক চিনি, তবে কেবল তখনই যখন অপরিবর্তনীয় মান হিসাবে ব্যবহৃত হয়।
/// যদি কোনও পরিবর্তনীয় মানটির অনুরোধ করা হয়, তবে পরিবর্তে [`IndexMut`] ব্যবহৃত হবে।
/// এটি `value` এর মতো দুর্দান্ত জিনিসগুলিকে মঞ্জুরি দেয় যদি `value` প্রকারের [`Copy`] প্রয়োগ করে।
///
/// # Examples
///
/// নিম্নলিখিত উদাহরণটি কেবল পঠনযোগ্য `NucleotideCount` ধারকটিতে `Index` প্রয়োগ করে, পৃথক গণনাগুলি সূচীকরণ সিনট্যাক্স সহ পুনরুদ্ধার করতে সক্ষম করে।
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// সূচকের পরে ফিরে আসা প্রকার।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// সূচক (`container[index]`) অপারেশন সম্পাদন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// পরিবর্তনীয় প্রসঙ্গে (`container[index]`) সূচীকরণের জন্য ব্যবহৃত হয়।
///
/// `container[index]` আসলে এক্স00 এক্স এর সিনট্যাকটিক চিনি, তবে কেবলমাত্র পরিবর্তিত মান হিসাবে ব্যবহৃত হলে।
/// যদি একটি অপরিবর্তনীয় মান অনুরোধ করা হয়, তবে [`Index`] trait এর পরিবর্তে ব্যবহৃত হবে।
/// এটি `v[index] = value` এর মতো দুর্দান্ত জিনিসগুলিকে মঞ্জুরি দেয়।
///
/// # Examples
///
/// একটি `Balance` কাঠামোর একটি খুব সাধারণ বাস্তবায়ন যার দুটি দিক রয়েছে, যেখানে প্রতিটিকে পরস্পর এবং অপরিবর্তিতভাবে সূচকযুক্ত করা যেতে পারে।
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // এই ক্ষেত্রে, `balance[Side::Right]` এক্স 100 এক্স এর জন্য চিনি, যেহেতু আমরা কেবল * এক্সড 1 এক্স পড়ছি, এটি লিখছি না।
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // তবে, এই ক্ষেত্রে `balance[Side::Left]` `*balance.index_mut(Side::Left)` এর জন্য চিনি, যেহেতু আমরা `balance[Side::Left]` লিখছি।
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// পরিবর্তনীয় সূচক (`container[index]`) অপারেশন সম্পাদন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}