/// এক্স00 এক্সের মতো অপরিবর্তনীয় ডেরেফারেন্সিং অপারেশনের জন্য ব্যবহৃত।
///
/// অপরিবর্তনীয় প্রসঙ্গে (unary) `*` অপারেটরের সাথে সুস্পষ্ট ডিসিফেরেন্সিং অপারেশনের জন্য ব্যবহার করা ছাড়াও, `Deref` অনেক পরিস্থিতিতে সংকলক দ্বারা স্পষ্টভাবে ব্যবহৃত হয়।
/// এই প্রক্রিয়াটিকে ['`Deref` coercion'][more] বলা হয়।
/// পরিবর্তনীয় প্রসঙ্গে [`DerefMut`] ব্যবহার করা হয়।
///
/// স্মার্ট পয়েন্টারগুলির জন্য এক্স01 এক্স প্রয়োগ করা তাদের পিছনে থাকা ডেটা অ্যাক্সেসকে সুবিধাজনক করে তোলে, এ কারণেই তারা `Deref` প্রয়োগ করে।
/// অন্যদিকে, `Deref` এবং [`DerefMut`] সম্পর্কিত বিধিগুলি স্মার্ট পয়েন্টারগুলিকে সামঞ্জস্য করার জন্য বিশেষভাবে তৈরি করা হয়েছিল।
/// এ কারণে, বিভ্রান্তি এড়াতে **`ডেরেফ কেবল স্মার্ট পয়েন্টারগুলির জন্য প্রয়োগ করা উচিত**।
///
/// অনুরূপ কারণে,**এই trait কখনই ব্যর্থ হয় না**।ডিসিফারেন্সিংয়ের সময় ব্যর্থতা অত্যন্ত বিভ্রান্তিকর হতে পারে যখন এক্স 100 এক্সকে অন্তর্ভুক্তভাবে ডাকা হয়।
///
/// # `Deref` জবরদস্তিতে আরও
///
/// যদি `T` `Deref<Target = U>` প্রয়োগ করে এবং `x` `T` প্রকারের মান হয় তবে:
///
/// * অপরিবর্তনীয় প্রসঙ্গে `*x` (যেখানে `T` কোনও রেফারেন্স বা কাঁচা পয়েন্টার নয়) `* Deref::deref(&x)` এর সমতুল্য।
/// * প্রকারের `&T` এর মানগুলি `&U` প্রকারের মানগুলিতে বাধ্য হয়
/// * `T` `U` প্রকারের সমস্ত (immutable) পদ্ধতি কার্যকরভাবে প্রয়োগ করে।
///
/// আরও বিশদের জন্য [the chapter in *The Rust Programming Language*][book] এবং [the dereference operator][ref-deref-op], [method resolution] এবং [type coercions] এর রেফারেন্স বিভাগগুলি দেখুন।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// একক ক্ষেত্রের সাথে একটি কাঠামো যা স্ট্রাকটিকে ডিফারেন্স করে অ্যাক্সেসযোগ্য।
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ডিসেরেন্সিংয়ের পরে ফলাফল প্রকার।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// মানটির মূল্যায়ন করে।
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` এর মতো পরিবর্তনীয় ডেরেফারেন্সিং অপারেশনের জন্য ব্যবহৃত।
///
/// পরিবর্তনীয় প্রসঙ্গে (unary) `*` অপারেটরের সাথে সুস্পষ্ট ডিসিফেরেন্সিং অপারেশনের জন্য ব্যবহার করা ছাড়াও, `DerefMut` বিভিন্ন পরিস্থিতিতে সংকলক দ্বারা স্পষ্টভাবে ব্যবহৃত হয়।
/// এই প্রক্রিয়াটিকে ['`Deref` coercion'][more] বলা হয়।
/// অপরিবর্তনীয় প্রসঙ্গে, [`Deref`] ব্যবহৃত হয়।
///
/// স্মার্ট পয়েন্টারগুলির জন্য এক্স01 এক্স প্রয়োগ করা তাদের পিছনে থাকা ডেটাগুলিকে পরিবর্তন করতে সুবিধাজনক করে তোলে, যার কারণে তারা এক্স00 এক্স প্রয়োগ করে।
/// অন্যদিকে, [`Deref`] এবং `DerefMut` সম্পর্কিত বিধিগুলি স্মার্ট পয়েন্টারগুলিকে সামঞ্জস্য করার জন্য বিশেষভাবে তৈরি করা হয়েছিল।
/// এর কারণে,**বিভ্রান্তি এড়াতে কেবল** ters ডেরেফমুট` স্মার্ট পয়েন্টারগুলির জন্য প্রয়োগ করা উচিত।
///
/// অনুরূপ কারণে,**এই trait কখনই ব্যর্থ হয় না**।ডিসিফারেন্সিংয়ের সময় ব্যর্থতা অত্যন্ত বিভ্রান্তিকর হতে পারে যখন এক্স 100 এক্সকে অন্তর্ভুক্তভাবে ডাকা হয়।
///
/// # `Deref` জবরদস্তিতে আরও
///
/// যদি `T` `DerefMut<Target = U>` প্রয়োগ করে এবং `x` `T` প্রকারের মান হয় তবে:
///
/// * পরিবর্তনীয় প্রসঙ্গে `*x` (যেখানে `T` কোনও রেফারেন্স বা কাঁচা পয়েন্টার নয়) `* DerefMut::deref_mut(&mut x)` এর সমতুল্য।
/// * প্রকারের `&mut T` এর মানগুলি `&mut U` প্রকারের মানগুলিতে বাধ্য হয়
/// * `T` `U` প্রকারের সমস্ত (mutable) পদ্ধতি কার্যকরভাবে প্রয়োগ করে।
///
/// আরও বিশদের জন্য [the chapter in *The Rust Programming Language*][book] এবং [the dereference operator][ref-deref-op], [method resolution] এবং [type coercions] এর রেফারেন্স বিভাগগুলি দেখুন।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// একটি একক ক্ষেত্রের সাথে একটি কাঠামো যা স্ট্রাকটিকে ডিফারেন্সিং দ্বারা সংশোধনযোগ্য।
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// পারস্পরিকভাবে মানটিকে অবলম্বন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// ইঙ্গিত করে যে কোনও স্ট্রোকটি `arbitrary_self_types` বৈশিষ্ট্য ছাড়াই একটি পদ্ধতি রিসিভার হিসাবে ব্যবহার করা যেতে পারে।
///
/// এটি x01X, `Rc<T>`, `&T`, এবং `Pin<P>` এর মতো stdlib পয়েন্টার ধরণের দ্বারা প্রয়োগ করা হয়েছে।
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}