/// `?` অপারেটরের আচরণ কাস্টমাইজ করার জন্য একটি জেড0ট্রাইট0 জেড।
///
/// এক্স টাইম এক্সপ্লোরেশন এমন একটি যা success/failure ডিকোটোমির দিক থেকে এটি দেখার এক কমনীয় উপায়।
/// এই trait বিদ্যমান সাফল্য বা ব্যর্থতার মানগুলি বিদ্যমান উদাহরণ থেকে বের করতে এবং সাফল্য বা ব্যর্থতার মান থেকে একটি নতুন উদাহরণ তৈরি করতে উভয়কেই অনুমতি দেয়।
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// যখন সফল হিসাবে দেখা হয় তখন এই মানটির ধরণ।
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ব্যর্থ হিসাবে দেখা হলে এই মানটির ধরণ।
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// এক্স01 এক্স অপারেটর প্রয়োগ করে।এক্স0 টেক্স এক্স এর রিটার্নের অর্থ হ'ল এক্সিকিউশনটি স্বাভাবিকভাবেই চালিয়ে যাওয়া উচিত এবং এক্স0৩ এক্স এর ফলাফল হ'ল এক্স ২০০ এক্স।
    /// `Err(e)` এর রিটার্নের অর্থ হল মৃত্যুদন্ড কার্যকর হওয়া উচিত branch ভিতরের অন্তর্নিহিত `catch` এ, বা ফাংশন থেকে ফিরে।
    ///
    /// যদি কোনও `Err(e)` ফলাফল ফিরে আসে, তবে এনকোলেসিং স্কোপের (যা নিজেই `Try` প্রয়োগ করতে হবে) প্রকারের প্রকারের `e` মান হবে "wrapped"।
    ///
    /// বিশেষত, `X::from_error(From::from(e))` মানটি ফিরে আসে, যেখানে `X` হল এনক্লোজিং ফাংশনের রিটার্ন টাইপ।
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// যৌগিক ফলাফল তৈরি করতে একটি ত্রুটির মান মোড়ানো।
    /// উদাহরণস্বরূপ, `Result::Err(x)` এবং `Result::from_error(x)` সমতুল্য।
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// যৌগিক ফলাফল তৈরি করতে একটি ওকে মান rapেকে দিন।
    /// উদাহরণস্বরূপ, `Result::Ok(x)` এবং `Result::from_ok(x)` সমতুল্য।
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}