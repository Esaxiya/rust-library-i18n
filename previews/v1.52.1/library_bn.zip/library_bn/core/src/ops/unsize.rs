use crate::marker::Unsize;

/// Trait যা নির্দেশ করে যে এটি একটি পয়েন্টার বা একটি এর জন্য একটি মোড়ক, যেখানে পয়েন্টটিতে আনসাইজ করা যায়।
///
/// আরও তথ্যের জন্য [DST coercion RFC][dst-coerce] এবং [the nomicon entry on coercion][nomicon-coerce] দেখুন।
///
/// অন্তর্নির্মিত পয়েন্টার ধরণের জন্য, `T`-এ পয়েন্টারগুলি `U` এ পয়েন্টারগুলিকে বাধ্য করবে যদি `T: Unsize<U>` একটি পাতলা পয়েন্টার থেকে ফ্যাট পয়েন্টারে রূপান্তর করে।
///
/// কাস্টম ধরণের জন্য, এখানে জবরদস্তি `Foo<T>` কে `Foo<U>` জোর করে `CoerceUnsized<Foo<U>> for Foo<T>` এর ইমপ্লিট উপস্থিত থাকলে কাজ করে।
/// এই জাতীয় ইমপালটি কেবল তখনই লেখা যেতে পারে যদি `Foo<T>`-এ কেবলমাত্র একটি একক নন-ফ্যান্টমডাটা ক্ষেত্র থাকে যার সাথে `T` থাকে।
/// যদি ক্ষেত্রের প্রকারটি `Bar<T>` হয়, তবে `CoerceUnsized<Bar<U>> for Bar<T>` এর একটি বাস্তবায়ন অবশ্যই বিদ্যমান।
/// `Bar<T>` ফিল্ডটি `Bar<U>` তে জোর করে এবং `Foo<T>` থেকে বাকী ক্ষেত্রগুলিতে একটি `Foo<U>` তৈরি করে জোর করে কাজ করবে।
/// এটি কার্যকরভাবে একটি পয়েন্টার ক্ষেত্রের নিচে ড্রিল করবে এবং বাধ্য করবে।
///
/// সাধারণত, স্মার্ট পয়েন্টারগুলির জন্য আপনি `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` বাস্তবায়ন করবেন, `T` নিজেই আবদ্ধ একটি Xচ্ছিক `?Sized` দিয়ে।
/// মোড়কের ধরণের জন্য যা `T`-কে সরাসরি এক্স03 এক্স এবং এক্স01 এক্স এম্বেড করে আপনি সরাসরি `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` প্রয়োগ করতে পারেন।
///
/// এটি `Cell<Box<T>>` এর মতো ধরণের দমনকে কাজ করতে দেয়।
///
/// [`Unsize`][unsize] এমন ধরণের চিহ্ন চিহ্নিত করতে ব্যবহৃত হয় যা পয়েন্টারগুলির পিছনে থাকলে ডিএসটিগুলিতে জোর করা যায়।এটি সংকলক দ্বারা স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয়।
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut টি-> এক্স 100 এক্স ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut টি-> এক্স 100 এক্স
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut টি-> * মিট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut টি-> * কনস্টেট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * কনস্ট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *মিট টি->* মিট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *মিট টি->* কনস্টেট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *কনস্ট টি->* কনস্ট ইউ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// কোনও পদ্ধতির রিসিভার প্রকারটি প্রেরণ করা যায় কিনা তা পরীক্ষা করতে এটি অবজেক্ট সুরক্ষার জন্য ব্যবহৃত হয়।
///
/// trait এর উদাহরণ প্রয়োগ:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut টি-> এক্স 100 এক্স ইউ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *কনস্ট টি->* কনস্ট ইউ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *মিট টি->* মিট ইউ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}