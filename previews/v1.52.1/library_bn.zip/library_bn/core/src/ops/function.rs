/// কল অপারেটরের সংস্করণ যা অপরিবর্তনীয় রিসিভার নেয়।
///
/// এক্স 100 এক্স এর উদাহরণগুলিকে বারবার পরিবর্তিত অবস্থা ছাড়াই ডাকা যেতে পারে।
///
/// *এই trait (`Fn`) [function pointers] (`fn`) এর সাথে বিভ্রান্ত হওয়ার দরকার নেই।*
///
/// `Fn` ক্লোজারগুলির মাধ্যমে স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয় যা কেবল ক্যাপচারেড ভেরিয়েবলগুলির জন্য অপরিবর্তনীয় রেফারেন্স গ্রহণ করে বা কিছুতেই ক্যাপচার করে না, পাশাপাশি (safe) [function pointers] (কিছু ক্যাভেট সহ, আরও তথ্যের জন্য তাদের ডকুমেন্টেশন দেখুন)।
///
/// অতিরিক্তভাবে, যে কোনও প্রকারের `F` যা `Fn` প্রয়োগ করে, এক্স02 এক্সও এক্স01 এক্স প্রয়োগ করে।
///
/// যেহেতু [`FnMut`] এবং [`FnOnce`] উভয়ই `Fn` এর সুপাররেটস তাই `Fn` এর যে কোনও উদাহরণ প্যারামিটার হিসাবে ব্যবহার করা যেতে পারে যেখানে একটি [`FnMut`] বা [`FnOnce`] প্রত্যাশিত।
///
/// আপনি যখন ফাংশন-জাতীয় টাইপের কোনও পরামিতি গ্রহণ করতে চান এবং এক্সট্যাক্ট স্টেটটি ছাড়াই বারবার এবং কল করতে হবে (যেমন, যখন এটি একযোগে কল করার সময়) তখন `Fn` কে বাউন্ড হিসাবে ব্যবহার করুন।
/// আপনার যদি এমন কঠোর প্রয়োজনীয়তার প্রয়োজন না হয়, সীমা হিসাবে [`FnMut`] বা [`FnOnce`] ব্যবহার করুন।
///
/// এই বিষয়ে আরও কিছু তথ্যের জন্য [chapter on closures in *The Rust Programming Language*][book] দেখুন।
///
/// দ্রষ্টব্যটি হল `Fn` traits এর জন্য বিশেষ বাক্য গঠন (যেমন উদাঃ)
/// `Fn(usize, bool) -> usize`)।এর প্রযুক্তিগত বিশদ সম্পর্কে যারা আগ্রহী তারা [the relevant section in the *Rustonomicon*][nomicon] উল্লেখ করতে পারেন।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## বন্ধের ডাক দিচ্ছে
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## একটি `Fn` পরামিতি ব্যবহার করে
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // যাতে regex যে `&str: !FnMut` নির্ভর করতে পারে
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// কল অপারেশন সম্পাদন করে।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// কল অপারেটরের সংস্করণ যা একটি পরিবর্তনীয় রিসিভার নেয়।
///
/// এক্স 100 এক্স এর উদাহরণগুলি বারবার কল করা যেতে পারে এবং স্থিতি পরিবর্তন করতে পারে।
///
/// `FnMut` ক্লোজারগুলির মাধ্যমে স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয় যা ক্যাপচারড ভেরিয়েবলগুলির পরিবর্তনীয় রেফারেন্স গ্রহণ করে, পাশাপাশি [`Fn`] বাস্তবায়িত সমস্ত ধরণের উদাহরণস্বরূপ, (safe) [function pointers] (যেহেতু `FnMut` এক্স04 এক্স এর একটি সুপাররেট)।
/// অতিরিক্তভাবে, যে কোনও প্রকারের `F` যা `FnMut` প্রয়োগ করে, এক্স02 এক্সও এক্স01 এক্স প্রয়োগ করে।
///
/// যেহেতু [`FnOnce`] এক্স 100 এক্সের একটি সুপারট্রাইট, তাই `FnMut` এর যে কোনও উদাহরণ ব্যবহার করা যেতে পারে যেখানে একটি [`FnOnce`] প্রত্যাশিত এবং [`Fn`] যেহেতু `FnMut` এর একটি সাবট্রাইট, তাই [`Fn`] এর কোনও উদাহরণ ব্যবহার করা যেতে পারে যেখানে `FnMut` প্রত্যাশিত।
///
/// আপনি যখন ফাংশন-জাতীয় টাইপের কোনও পরামিতি গ্রহণ করতে চান এবং এক্সটেনের অবস্থায় যাওয়ার সময় এটি বারবার কল করার প্রয়োজন হয় তখন একটি বাঁধ হিসাবে `FnMut` ব্যবহার করুন।
/// আপনি যদি প্যারামিটারটিকে পরিবর্তন করতে চান না তবে [`Fn`] কে বাউন্ড হিসাবে ব্যবহার করুন;আপনার যদি বারবার এটির কল করার প্রয়োজন না হয় তবে এক্স 100 এক্স ব্যবহার করুন।
///
/// এই বিষয়ে আরও কিছু তথ্যের জন্য [chapter on closures in *The Rust Programming Language*][book] দেখুন।
///
/// দ্রষ্টব্যটি হল `Fn` traits এর জন্য বিশেষ বাক্য গঠন (যেমন উদাঃ)
/// `Fn(usize, bool) -> usize`)।এর প্রযুক্তিগত বিশদ সম্পর্কে যারা আগ্রহী তারা [the relevant section in the *Rustonomicon*][nomicon] উল্লেখ করতে পারেন।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## পারস্পরিকভাবে ক্যাপচারিং বন্ধের ডাক
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## একটি `FnMut` পরামিতি ব্যবহার করে
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // যাতে regex যে `&str: !FnMut` নির্ভর করতে পারে
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// কল অপারেশন সম্পাদন করে।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// কল অপারেটরের সংস্করণ যা বাই-ভ্যালু রিসিভার নেয়।
///
/// `FnOnce` এর উদাহরণগুলি বলা যেতে পারে, তবে একাধিকবার কল করা যায় না।এই কারণে, যদি কোনও প্রকার সম্পর্কে কেবল জানা জিনিসটি এটি `FnOnce` প্রয়োগ করে তবে এটি কেবল একবার কল করা যেতে পারে।
///
/// `FnOnce` ক্লোজার দ্বারা স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয় যা ক্যাপচারড ভেরিয়েবলগুলি গ্রাস করতে পারে এবং সেই সাথে [`FnMut`] প্রয়োগকারী সমস্ত ধরণের উদাহরণস্বরূপ, (safe) [function pointers] (যেহেতু `FnOnce` এক্স04 এক্স এর একটি সুপাররেট)।
///
///
/// যেহেতু [`Fn`] এবং [`FnMut`] উভয়ই `FnOnce` এর সাবট্রাইটস, তাই [`Fn`] বা [`FnMut`] এর যে কোনও উদাহরণ ব্যবহার করা যেতে পারে যেখানে একটি `FnOnce` প্রত্যাশিত।
///
/// আপনি যখন ফাংশন-জাতীয় ধরণের পরামিতি গ্রহণ করতে চান এবং কেবল একবার এটি কল করার দরকার হয় তখন `FnOnce` কে বাউন্ড হিসাবে ব্যবহার করুন।
/// আপনার যদি বারবার প্যারামিটারটি কল করার প্রয়োজন হয় তবে এক্স01 এক্সকে বাউন্ড হিসাবে ব্যবহার করুন;যদি আপনারও এটির অবস্থা পরিবর্তন না করার প্রয়োজন হয়, এক্স00 এক্স ব্যবহার করুন।
///
/// এই বিষয়ে আরও কিছু তথ্যের জন্য [chapter on closures in *The Rust Programming Language*][book] দেখুন।
///
/// দ্রষ্টব্যটি হল `Fn` traits এর জন্য বিশেষ বাক্য গঠন (যেমন উদাঃ)
/// `Fn(usize, bool) -> usize`)।এর প্রযুক্তিগত বিশদ সম্পর্কে যারা আগ্রহী তারা [the relevant section in the *Rustonomicon*][nomicon] উল্লেখ করতে পারেন।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## একটি `FnOnce` পরামিতি ব্যবহার করে
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` এটির ক্যাপচারড ভেরিয়েবলগুলি গ্রাস করে, তাই এটি একাধিকবার চালানো যায় না।
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // আবার এক্স01 এক্স চাওয়ার চেষ্টা করা `func` এর জন্য একটি এক্স02 এক্স ত্রুটি নিক্ষেপ করবে।
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` এই মুহুর্তে আর প্রার্থনা করা যাবে না
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // যাতে regex যে `&str: !FnMut` নির্ভর করতে পারে
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// কল অপারেটর ব্যবহারের পরে ফেরত প্রকার।
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// কল অপারেশন সম্পাদন করে।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}