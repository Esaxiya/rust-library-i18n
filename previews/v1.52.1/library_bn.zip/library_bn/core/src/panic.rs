//! স্ট্যান্ডার্ড লাইব্রেরিতে Panic সমর্থন।

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic সম্পর্কিত তথ্য সরবরাহকারী একটি কাঠামো।
///
/// `PanicInfo` কাঠামোটি [`set_hook`] ফাংশন দ্বারা সেট করা একটি panic hook এ পাস করা হয়েছে।
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic এর সাথে যুক্ত পেডলোড প্রদান করে।
    ///
    /// এটি সাধারণত, তবে সর্বদা নয়, `&'static str` বা [`String`] হবে।
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// যদি `core` crate (`std` থেকে নয়) থেকে `panic!` ম্যাক্রো বিন্যাসকরণ স্ট্রিং এবং কিছু অতিরিক্ত যুক্তি ব্যবহার করে ব্যবহৃত হয়, তবে বার্তাটি উদাহরণস্বরূপ [`fmt::write`] এর সাথে ব্যবহার করার জন্য প্রস্তুত
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// যদি পাওয়া যায় তবে panic যে জায়গা থেকে উদ্ভূত হয়েছিল সে সম্পর্কে তথ্য প্রদান করে।
    ///
    /// এই পদ্ধতিটি সর্বদা সর্বদা [`Some`] প্রদান করবে তবে এটি future সংস্করণে পরিবর্তিত হতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: যদি এটি কখনও কখনও পরিবর্তন হয় তবে কিছুই না,
        // std::panicking::default_hook এবং std::panicking::begin_panic_fmt এ ক্ষেত্রে মোকাবেলা করুন।
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: আমরা ডাউনকাস্ট_রেফ: : ব্যবহার করতে পারি না<String>() এখানে
        // যেহেতু স্ট্রিং লাইবকরে উপলভ্য নয়!
        // পে-লোডটি একটি স্ট্রিং থাকে যখন একাধিক তর্ক সঙ্গে `std::panic!` কল করা হয়, তবে সেক্ষেত্রে বার্তাটি উপলব্ধ।
        //

        self.location.fmt(formatter)
    }
}

/// panic এর অবস্থান সম্পর্কিত তথ্য সম্বলিত একটি কাঠামো।
///
/// এই কাঠামোটি [`PanicInfo::location()`] দ্বারা নির্মিত।
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// সাম্য এবং অর্ডার দেওয়ার তুলনা ফাইল, লাইন এবং তারপরে কলামের অগ্রাধিকারে করা হয়।
/// ফাইলগুলি `Path` নয়, স্ট্রিং হিসাবে তুলনা করা হয়েছে যা অপ্রত্যাশিত হতে পারে।
/// আরও আলোচনার জন্য [`অবস্থান: : ফাইল`] এর ডকুমেন্টেশন দেখুন।
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// এই ফাংশনটির কলারের উত্সের অবস্থানটি প্রদান করে।
    /// যদি সেই ফাংশনের কলারটি টীকাযুক্ত করা হয় তবে তার কল অবস্থানটি ফিরে আসবে, এবং অন্য কোনও ট্র্যাক না করা ফাংশন বডিটির মধ্যে প্রথম কলটিতে স্ট্যাক আপ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// এটি বলা হয় এমন [`Location`] প্রদান করে।
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// এই ফাংশনটির সংজ্ঞা থেকে একটি [`Location`] ফেরত দেয়।
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ভিন্ন ভিন্ন স্থানে একই অচিহ্নযুক্ত ফাংশনটি চালানো আমাদের একই ফলাফল দেয়
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ট্র্যাকড ক্রিয়াকলাপটি অন্য কোনও স্থানে চালনা করা একটি আলাদা মান তৈরি করে
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic উত্স থেকে উত্স ফাইলের নাম ফেরত দেয়।
    ///
    /// # `&str`, এক্স 100 এক্স নয়
    ///
    /// প্রত্যাবর্তিত নামটি সংকলন সিস্টেমের উত্স পাথকে বোঝায়, তবে এটি সরাসরি `&Path` হিসাবে উপস্থাপন করা বৈধ নয়।
    /// সংকলিত কোডটি সামগ্রী সরবরাহকারী সিস্টেমের চেয়ে আলাদা আলাদা `Path` বাস্তবায়ন সহ একটি ভিন্ন সিস্টেমে চালিত হতে পারে এবং এই লাইব্রেরিতে বর্তমানে আলাদা "host path" প্রকার নেই।
    ///
    /// সর্বাধিক আশ্চর্যজনক আচরণটি ঘটে যখন মডিউল সিস্টেমে একাধিক পাথের মাধ্যমে "the same" ফাইলটি পৌঁছানো যায় (সাধারণত `#[path = "..."]` বৈশিষ্ট্য বা অনুরূপ ব্যবহার করা হয়), যা এই ফাংশন থেকে পৃথক মানগুলি ফিরিয়ে আনতে অভিন্ন কোড হিসাবে উপস্থিত বলে মনে করতে পারে।
    ///
    ///
    /// # Cross-compilation
    ///
    /// হোস্ট প্ল্যাটফর্ম এবং লক্ষ্য প্ল্যাটফর্ম পৃথক হলে এই মানটি `Path::new` বা অনুরূপ নির্মাণকারীদের কাছে যাওয়ার জন্য উপযুক্ত নয়।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic যে লাইন নম্বর থেকে উদ্ভূত হয়েছিল তা লাইন নম্বর প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic যে কলাম থেকে উত্পন্ন হয়েছিল তার কলামটি ফিরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd থেকে `panic_unwind` এবং অন্যান্য panic রানটাইমগুলিতে ডেটা পাস করার জন্য libstd দ্বারা ব্যবহৃত একটি অভ্যন্তরীণ trait।
/// শীঘ্রই যে কোনও সময় স্থিতিশীল হওয়ার উদ্দেশ্যে নয়, ব্যবহার করবেন না।
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// সামগ্রীর সম্পূর্ণ মালিকানা নিন।
    /// রিটার্নের ধরণটি আসলে `Box<dyn Any + Send>`, তবে আমরা লাইবকোরে `Box` ব্যবহার করতে পারি না।
    ///
    /// এই পদ্ধতিটি কল করার পরে, কেবলমাত্র কিছু ডামি ডিফল্ট মান `self` এ বাকী রয়েছে।
    /// এই পদ্ধতিটি কল করার পরে দুটি বার কল করা বা এই পদ্ধতিটি কল করার পরে `get` কল করা একটি ত্রুটি।
    ///
    /// আর্গুমেন্ট ধার করা হয়েছে কারণ panic রানটাইম এক্স01 এক্স কেবল একটি ধার নেওয়া `dyn BoxMeUp` পায়।
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// শুধু বিষয়বস্তু ধার।
    fn get(&mut self) -> &(dyn Any + Send);
}