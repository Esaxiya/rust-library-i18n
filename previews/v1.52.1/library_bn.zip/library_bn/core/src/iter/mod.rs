//! কম্পোজেবল বাহ্যিক পুনরাবৃত্তি।
//!
//! যদি আপনি নিজেকে কোনও প্রকারের সংগ্রহের সাথে খুঁজে পেয়েছেন এবং বলেন যে সংগ্রহের উপাদানগুলির উপর কোনও ক্রিয়াকলাপ করা প্রয়োজন, আপনি দ্রুত 'iterators' এ চলে যান।
//! ইডিয়েটারগুলি প্রচুর পরিমাণে আইডিয়োমেটিক জেড0 রিস্ট0 জেড কোডে ব্যবহৃত হয়, তাই তাদের সাথে পরিচিত হওয়া ভাল।
//!
//! আরও ব্যাখ্যা দেওয়ার আগে আসুন কীভাবে এই মডিউলটি কাঠামোযুক্ত করা হয়েছে সে সম্পর্কে কথা বলি:
//!
//! # Organization
//!
//! এই মডিউলটি মূলত প্রকার অনুসারে সংগঠিত:
//!
//! * [Traits] মূল অংশটি: এই traits সংজ্ঞা দেয় যে কোন ধরণের পুনরাবৃত্তির উপস্থিত রয়েছে এবং আপনি তাদের সাথে কী করতে পারেন।এই traits এর পদ্ধতিগুলি কিছু অতিরিক্ত স্টাডি সময়কে মূল্যায়নের উপযুক্ত।
//! * [Functions] কিছু বেসিক পুনরুক্তি তৈরির জন্য কিছু সহায়ক উপায় সরবরাহ করুন।
//! * [Structs] এই মডিউলটির traits এ প্রায়শই বিভিন্ন পদ্ধতির রিটার্নের ধরণ।আপনি সাধারণত `struct` এর পরিবর্তে `struct` তৈরির পদ্ধতিটি দেখতে চান।
//! কেন সম্পর্কে আরও তথ্যের জন্য '[ইমপ্লিমেন্টিং আইট্রেটার]' (#প্রয়োগকারী-পুনরুক্তিকারী) 'দেখুন।
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! এটাই!আসুন পুনরাবৃত্তির মধ্যে খনন।
//!
//! # Iterator
//!
//! এই মডিউলটির হৃদয় এবং আত্মা হ'ল [`Iterator`] trait।[`Iterator`] এর মূলটি এর মতো দেখাচ্ছে:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! একটি পুনরাবৃত্তকারীটির একটি পদ্ধতি থাকে [`next`], যা ডাকা হলে এটি একটি [`বিকল্প`] returns দেয়`<Item>।
//! [`next`] যতক্ষণ না উপাদান রয়েছে ততক্ষণ [`Some(Item)`] ফিরিয়ে দেবে, এবং একবারে তারা সমস্ত ক্লান্ত হয়ে গেলে, পুনরাবৃত্তি শেষ হয়ে গেছে তা বোঝাতে `None` ফিরে আসবে।
//! স্বতন্ত্র পুনরাবৃত্তি পুনরাবৃত্তি পুনরায় শুরু করতে বেছে নিতে পারে, এবং তাই [`next`] আবার কল করা শেষ পর্যন্ত কিছু সময় [`Some(Item)`] ফেরত আসতে বা নাও শুরু করতে পারে (উদাহরণস্বরূপ, এক্স02 এক্স দেখুন)।
//!
//!
//! [Te Iterator`] এর সম্পূর্ণ সংজ্ঞায় অন্যান্য বেশ কয়েকটি পদ্ধতিও অন্তর্ভুক্ত রয়েছে তবে সেগুলি ডিফল্ট পদ্ধতি, [`next`] এর শীর্ষে নির্মিত এবং তাই আপনি সেগুলি বিনামূল্যে পান।
//!
//! আইট্রেটারগুলিও কমপোজ্য এবং প্রসেসিংয়ের আরও জটিল আকারে তাদের একসাথে চেইন করা সাধারণ toআরও তথ্যের জন্য নীচের [Adapters](#adapters) বিভাগটি দেখুন।
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # পুনরাবৃত্তির তিনটি রূপ
//!
//! এখানে তিনটি সাধারণ পদ্ধতি যা সংগ্রহ থেকে পুনরুক্তি তৈরি করতে পারে:
//!
//! * `iter()`, যা `&T` এর উপরে পুনরাবৃত্তি করে।
//! * `iter_mut()`, যা `&mut T` এর উপরে পুনরাবৃত্তি করে।
//! * `into_iter()`, যা `T` এর উপরে পুনরাবৃত্তি করে।
//!
//! স্ট্যান্ডার্ড লাইব্রেরির বিভিন্ন জিনিস যথাযথ যেখানে তিনটিতে এক বা একাধিক প্রয়োগ করতে পারে।
//!
//! # আইট্রেটার বাস্তবায়ন করা হচ্ছে
//!
//! আপনার নিজের পুনরুক্তি তৈরির ক্ষেত্রে দুটি পদক্ষেপ জড়িত: পুনরুক্তির স্থিতি ধরে রাখতে একটি `struct` তৈরি করা এবং তারপরে সেই `struct` এর জন্য [`Iterator`] প্রয়োগ করা।
//! এই কারণেই এই মডিউলটিতে অনেকগুলি `কাঠামোগত রয়েছে: প্রতিটি পুনরুক্তি এবং পুনরাবৃত্তকারী অ্যাডাপ্টারের জন্য একটি রয়েছে।
//!
//! `Counter` নামের একটি পুনরাবৃত্তি করা যাক যা `1` থেকে `5` পর্যন্ত গণনা:
//!
//! ```
//! // প্রথম, কাঠামো:
//!
//! /// একটি পুনরাবৃত্তি যা এক থেকে পাঁচ পর্যন্ত গণনা করে
//! struct Counter {
//!     count: usize,
//! }
//!
//! // আমরা আমাদের গণনাটি শুরু করতে চাই, সুতরাং সাহায্যের জন্য একটি new() পদ্ধতি যুক্ত করুন।
//! // এটি কঠোরভাবে প্রয়োজনীয় নয়, তবে সুবিধাজনক।
//! // মনে রাখবেন যে আমরা `count` শূন্য থেকে শুরু করি, আমরা নীচে কেন `next()`'s বাস্তবায়নে দেখব।
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // তারপরে, আমরা আমাদের `Counter` এর জন্য `Iterator` প্রয়োগ করি:
//!
//! impl Iterator for Counter {
//!     // আমরা usize সঙ্গে গণনা করা হবে
//!     type Item = usize;
//!
//!     // next() একমাত্র প্রয়োজনীয় পদ্ধতি
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // আমাদের গণনা বৃদ্ধি করুন।এই কারণেই আমরা শূন্য থেকে শুরু করেছিলাম।
//!         self.count += 1;
//!
//!         // আমরা গণনা শেষ করেছি কিনা তা পরীক্ষা করে দেখুন।
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // এবং এখন আমরা এটি ব্যবহার করতে পারি!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! এইভাবে এক্স01 এক্স কল করা পুনরাবৃত্তি হয়।Rust এর একটি কনস্ট্রাক্ট রয়েছে যা এটি `None` না পৌঁছানো অবধি আপনার পুনরুক্তিতে [`next`] কল করতে পারে।এর পরের দিকে যাওয়া যাক।
//!
//! এছাড়াও লক্ষ করুন যে `Iterator` `nth` এবং `fold` এর মতো পদ্ধতির একটি ডিফল্ট বাস্তবায়ন সরবরাহ করে যা `next` অভ্যন্তরীণভাবে কল করে।
//! তবে, কোনও পুনরুক্তিকারী `next` কল না করে যদি আরও দক্ষতার সাথে সেগুলি গণনা করতে পারে তবে `nth` এবং `fold` এর মতো পদ্ধতির একটি কাস্টম বাস্তবায়ন লিখতেও সম্ভব।
//!
//! # `for` লুপস এবং এক্স 100 এক্স
//!
//! Rust এর এক্স01 এক্স লুপ সিনট্যাক্স আসলে পুনরাবৃত্তিকারীদের জন্য চিনি।এখানে `for` এর একটি বেসিক উদাহরণ:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! এটি প্রতিটি তাদের নিজস্ব লাইনে পাঁচটির মাধ্যমে এক নম্বর মুদ্রণ করবে।তবে আপনি এখানে কিছু লক্ষ্য করবেন: পুনরুক্তি তৈরির জন্য আমরা আমাদের vector তে কোনও কিছুই কল করি নি।কি দেয়?
//!
//! কোনও কিছুকে পুনরুক্তিতে রূপান্তর করার জন্য স্ট্যান্ডার্ড লাইব্রেরিতে একটি trait রয়েছে: [`IntoIterator`].
//! এই trait এর একটি পদ্ধতি রয়েছে [`into_iter`], যা [`IntoIterator`] প্রয়োগকারী জিনিসটিকে একটি পুনরুক্তিতে রূপান্তর করে।
//! আবার সেই `for` লুপটি একবার দেখে নেওয়া যাক এবং সংকলকটি এটিকে কী রূপান্তরিত করে:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! জেড 0 রিস্ট0 জেড এটিকে ডি-সুগার করে:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! প্রথমত, আমরা মানটির সাথে `into_iter()` কল করি।তারপরে, আমরা পুনরাবৃত্তির সাথে মিলিত হই যা প্রত্যাবর্তন করে [`next`] ডাকে যতক্ষণ না আমরা একটি `None` না দেখি calling
//! এই মুহুর্তে, আমরা লুপটির বাইরে `break` করেছি, এবং আমরা পুনরাবৃত্তি সম্পন্ন করেছি।
//!
//! এখানে আরও একটি সূক্ষ্ম বিট রয়েছে: স্ট্যান্ডার্ড লাইব্রেরিতে [`IntoIterator`] এর একটি আকর্ষণীয় বাস্তবায়ন রয়েছে:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! অন্য কথায়, সমস্ত [`Iterator`] কেবল নিজেরাই ফিরে এসে [`IntoIterator`] প্রয়োগ করে।এর অর্থ দুটি জিনিস:
//!
//! 1. আপনি যদি [`Iterator`] লিখছেন তবে আপনি এটি `for` লুপের সাহায্যে ব্যবহার করতে পারেন।
//! 2. আপনি যদি কোনও সংগ্রহ তৈরি করে থাকেন তবে এর জন্য [`IntoIterator`] প্রয়োগ করে আপনার সংগ্রহটি `for` লুপের সাথে ব্যবহার করার অনুমতি দেবে।
//!
//! # রেফারেন্স দ্বারা Iterating
//!
//! যেহেতু [`into_iter()`] মান অনুসারে `self` নেয়, কোনও সংগ্রহের পুনরাবৃত্তি করতে `for` লুপ ব্যবহার করে সে সংগ্রহটি গ্রাস করে।প্রায়শই, আপনি কোনও সংগ্রহ ব্যয় না করে পুনরাবৃত্তি করতে চাইতে পারেন।
//! প্রচুর সংগ্রহগুলি এমন পদ্ধতিগুলি সরবরাহ করে যা রেফারেন্সের মাধ্যমে পুনরাবৃত্তি সরবরাহ করে, প্রচলিতভাবে যথাক্রমে `iter()` এবং `iter_mut()` নামে পরিচিত:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` এখনও এই ফাংশন দ্বারা মালিকানাধীন।
//! ```
//!
//! যদি কোনও সংগ্রহের ধরণের `C` এক্স01 এক্স সরবরাহ করে তবে এটি সাধারণত `&C` এর জন্য `&C` প্রয়োগ করে, এমন একটি বাস্তবায়ন যা কেবলমাত্র `iter()` ডাকে।
//! তেমনি, `iter_mut()` সরবরাহ করে এমন একটি সংগ্রহ `C` সাধারণত `iter_mut()` এক্স এর জন্য `&mut C` এর জন্য `IntoIterator` প্রয়োগ করে।এটি একটি সুবিধাজনক শর্টহ্যান্ড সক্ষম করে:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` এর মতোই
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` এর মতোই
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! যদিও অনেকগুলি সংগ্রহ `iter()` সরবরাহ করে, সমস্ত অফার `iter_mut()` নয়।
//! উদাহরণস্বরূপ, [`HashSet<T>`] বা [`HashMap<K, V>`] এর কীগুলিকে পরিবর্তন করতে যদি কী হ্যাশগুলি পরিবর্তন হয় তবে সংগ্রহটি একটি বেমানান অবস্থায় ফেলতে পারে, সুতরাং এই সংগ্রহগুলি কেবলমাত্র `iter()` সরবরাহ করে।
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! যে ক্রিয়াকলাপগুলি একটি [`Iterator`] নেয় এবং অন্য [`Iterator`] ফেরত দেয় তাদের প্রায়শই 'পুনরাবৃত্তকারী অ্যাডাপ্টার' বলা হয়, কারণ তারা 'অ্যাডাপ্টারের একটি রূপ're
//! pattern'.
//!
//! সাধারণ পুনরাবৃত্তির অ্যাডাপ্টারগুলির মধ্যে [`map`], [`take`], এবং [`filter`] অন্তর্ভুক্ত।
//! আরও জন্য, তাদের ডকুমেন্টেশন দেখুন।
//!
//! যদি কোনও পুনরুক্তিকারী অ্যাডাপ্টার panics হয় তবে পুনরুক্তিটি একটি অনির্ধারিত (তবে মেমরি নিরাপদ) অবস্থায় থাকবে।
//! এই রাজ্যটি জেড 0 রিস্ট0 জেড এর সমস্ত সংস্করণে একই থাকার গ্যারান্টিযুক্তও নয়, সুতরাং আতঙ্কিত হওয়া কোনও পুনরাবৃত্তির দ্বারা ফিরে আসা সঠিক মানের উপর নির্ভর করা আপনার উচিত নয়।
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! আইট্রেটারগুলি (এবং এক্সেটর এক্স01 এক্স *অলস* This এটির অর্থ হ'ল কেবলমাত্র একটি পুনরুক্তি তৈরি করা পুরো পরিমাণে _do_ করে না you আপনি [`next`] কল না করা পর্যন্ত আসলেই কিছুই হয় না।
//! সম্পূর্ণরূপে এর পার্শ্ব প্রতিক্রিয়াগুলির জন্য একটি পুনরুক্তি তৈরি করার সময় এটি বিভ্রান্তির উত্স হয়ে থাকে।
//! উদাহরণস্বরূপ, [`map`] পদ্ধতিটি পুনরাবৃত্তি করে এমন প্রতিটি উপাদানকে একটি বন্ধের ডাক দেয়:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! এটি কোনও মান মুদ্রণ করবে না, কারণ আমরা এটির পরিবর্তে কেবল একটি পুনরুক্তি তৈরি করেছি।সংকলক আমাদের এই ধরণের আচরণ সম্পর্কে সতর্ক করবে:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! এর পার্শ্ব প্রতিক্রিয়াগুলির জন্য একটি [`map`] লেখার মুশকিল পদ্ধতিটি হল `for` লুপ ব্যবহার করা বা [`for_each`] পদ্ধতিটি কল করা:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! একটি পুনরুক্তি মূল্যায়নের অন্য সাধারণ উপায় হ'ল নতুন সংগ্রহ উত্পাদন করতে [`collect`] পদ্ধতিটি ব্যবহার করা।
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! আইট্রেটারদের সসীম হতে হবে না।উদাহরণস্বরূপ, একটি মুক্ত-সীমার পরিসর হ'ল অসীম পুনরাবৃত্তিকারী:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! অসীম পুনরাবৃত্তিকে সসীম আকারে রূপান্তর করতে [`take`] পুনরাবৃত্তকারী অ্যাডাপ্টার ব্যবহার করা সাধারণ:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! এটি `4` এর মাধ্যমে `0` নম্বরগুলি প্রতিটি তাদের নিজস্ব লাইনে মুদ্রণ করবে।
//!
//! মনে রাখবেন যে সীমাহীন পুনরাবৃত্তির পদ্ধতিগুলি এমনকি এমনকী যার জন্য ফল সীমাবদ্ধ সময়ে গাণিতিকভাবে নির্ধারণ করা যেতে পারে, এটি সমাপ্ত হতে পারে না।
//! বিশেষতঃ [`min`] এর মতো পদ্ধতিগুলির ক্ষেত্রে, যা সাধারণ ক্ষেত্রে পুনরাবৃত্তির প্রতিটি উপাদানকে অনুসরণ করতে পারে, সম্ভবত কোনও অসীম পুনরাবৃত্তির জন্য সফলভাবে ফিরে না আসতে পারে।
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ওহ না!অসীম লুপ!
//! // `ones.min()` অসীম লুপের কারণ, তাই আমরা এই পর্যায়ে পৌঁছাতে পারব না!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;