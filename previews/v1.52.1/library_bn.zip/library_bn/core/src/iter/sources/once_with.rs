use crate::iter::{FusedIterator, TrustedLen};

/// একটি পুনরাবৃত্তি তৈরি করে যা সরবরাহকৃত বন্ধের অনুরোধ করে অলসভাবে একবারে একটি মান উৎপন্ন করে।
///
/// এটি সাধারণত একক মান জেনারেটরকে অন্য ধরণের পুনরাবৃত্তির [`chain()`] এর সাথে অভিযোজিত করতে ব্যবহৃত হয়।
/// হতে পারে আপনার কাছে এমন একটি পুনরুক্তি রয়েছে যা প্রায় সবগুলি জুড়ে থাকে তবে আপনার একটি অতিরিক্ত বিশেষ ক্ষেত্রে প্রয়োজন।
/// হতে পারে আপনার একটি ফাংশন যা পুনরাবৃত্তকারীদের উপর কাজ করে তবে আপনার কেবল একটি মান প্রক্রিয়াকরণ করতে হবে।
///
/// [`once()`] এর বিপরীতে, এই ফাংশনটি আলস্যভাবে অনুরোধের ভিত্তিতে মান উত্পন্ন করবে।
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::iter;
///
/// // একটি হ'ল একাকী সংখ্যা
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // একটি মাত্র, আমরা কেবল এটিই পাই
/// assert_eq!(None, one.next());
/// ```
///
/// অন্য একজনের সাথে এক সাথে শৃঙ্খলাবদ্ধ।
/// ধরা যাক যে আমরা `.foo` ডিরেক্টরি প্রতিটি ফাইলের উপরে পুনরাবৃত্তি করতে চাই, তবে একটি কনফিগারেশন ফাইলও,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // আমাদের DirEntry-s এর একটি পুনরুক্তিকারীকে পাঠবুফের একটি পুনরাবৃত্তিতে রূপান্তর করতে হবে, তাই আমরা মানচিত্রটি ব্যবহার করি
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // এখন, আমাদের কনফিগার ফাইলের জন্য আমাদের পুনরাবৃত্তি
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // দুটি পুনরাবৃত্তিকে একত্রে একটি বড় পুনরায় বিবর্তক হিসাবে শৃঙ্খলাবদ্ধ করুন
/// let files = dirs.chain(config);
///
/// // এটি আমাদের .foo এর পাশাপাশি এক্স 100 এক্স এর সমস্ত ফাইল দেবে
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// প্রদত্ত ক্লোজার `F: FnOnce() -> A` প্রয়োগ করে একটি পুনরাবৃত্তি যা `A` প্রকারের একক উপাদানকে দেয়।
///
///
/// এই `struct` [`once_with()`] ফাংশন দ্বারা নির্মিত হয়েছে।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}