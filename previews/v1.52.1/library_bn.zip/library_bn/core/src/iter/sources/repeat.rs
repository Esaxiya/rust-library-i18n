use crate::iter::{FusedIterator, TrustedLen};

/// একটি নতুন পুনরাবৃত্তি তৈরি করে যা একক উপাদানকে অবিরাম পুনরাবৃত্তি করে।
///
/// `repeat()` ফাংশন বারবার একক মান পুনরাবৃত্তি করে।
///
/// এক্স-0 এক্স এর মতো অসীম পুনরাবৃত্তকারীগুলি প্রায়শই [`Iterator::take()`] এর মতো অ্যাডাপ্টারের সাথে ব্যবহৃত হয় যাতে তাদের সীমাবদ্ধ করা যায়।
///
/// আপনার যে পুনরাবৃত্তির প্রয়োজনীয় উপাদান উপাদানটি `Clone` প্রয়োগ করে না, বা আপনি যদি পুনরাবৃত্ত উপাদানটিকে মেমরিতে রাখতে চান না, আপনি পরিবর্তে [`repeat_with()`] ফাংশনটি ব্যবহার করতে পারেন।
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::iter;
///
/// // চার নম্বর চারটি:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // হ্যাঁ, এখনও চার
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] এর সাথে সসীম চলছে:
///
/// ```
/// use std::iter;
///
/// // যে শেষ উদাহরণটি ছিল অনেক চারটি।আসুন কেবল চারটি বাউন্ডারি থাকি।
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... এবং এখন আমরা সম্পন্ন করেছি
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// এমন একটি পুনরাবৃত্তি যা কোনও উপাদানকে অবিরাম পুনরাবৃত্তি করে।
///
/// এই `struct` [`repeat()`] ফাংশন দ্বারা নির্মিত হয়েছে।আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}