use crate::iter::{FusedIterator, TrustedLen};

/// একটি পুনরুক্তি তৈরি করে যা একবারে একবারে একটি উপাদান দেয়।
///
/// এটি সাধারণত একক মানকে অন্য ধরণের পুনরাবৃত্তির [`chain()`] এর সাথে অভিযোজিত করতে ব্যবহৃত হয়।
/// হতে পারে আপনার কাছে এমন একটি পুনরুক্তি রয়েছে যা প্রায় সবগুলি জুড়ে থাকে তবে আপনার একটি অতিরিক্ত বিশেষ ক্ষেত্রে প্রয়োজন।
/// হতে পারে আপনার একটি ফাংশন যা পুনরাবৃত্তকারীদের উপর কাজ করে তবে আপনার কেবল একটি মান প্রক্রিয়াকরণ করতে হবে।
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::iter;
///
/// // একটি হ'ল একাকী সংখ্যা
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // একটি মাত্র, আমরা কেবল এটিই পাই
/// assert_eq!(None, one.next());
/// ```
///
/// অন্য একজনের সাথে এক সাথে শৃঙ্খলাবদ্ধ।
/// ধরা যাক যে আমরা `.foo` ডিরেক্টরি প্রতিটি ফাইলের উপরে পুনরাবৃত্তি করতে চাই, তবে একটি কনফিগারেশন ফাইলও,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // আমাদের DirEntry-s এর একটি পুনরুক্তিকারীকে পাঠবুফের একটি পুনরাবৃত্তিতে রূপান্তর করতে হবে, তাই আমরা মানচিত্রটি ব্যবহার করি
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // এখন, আমাদের কনফিগার ফাইলের জন্য আমাদের পুনরাবৃত্তি
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // দুটি পুনরাবৃত্তিকে একত্রে একটি বড় পুনরায় বিবর্তক হিসাবে শৃঙ্খলাবদ্ধ করুন
/// let files = dirs.chain(config);
///
/// // এটি আমাদের .foo এর পাশাপাশি এক্স 100 এক্স এর সমস্ত ফাইল দেবে
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// একটি পুনরাবৃত্তি যা একবারে একবারে উপাদান দেয়।
///
/// এই `struct` [`once()`] ফাংশন দ্বারা নির্মিত হয়েছে।আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}