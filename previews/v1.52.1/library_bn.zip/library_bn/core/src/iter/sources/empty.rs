use crate::fmt;
use crate::iter::{FusedIterator, TrustedLen};
use crate::marker;

/// এমন একটি পুনরুক্তি তৈরি করে যা কিছুই দেয় না।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::iter;
///
/// // এটি i32 এর উপর একটি পুনরাবৃত্তি হতে পারে, কিন্তু হায়, এটি ঠিক নয়।
/// let mut nope = iter::empty::<i32>();
///
/// assert_eq!(None, nope.next());
/// ```
#[stable(feature = "iter_empty", since = "1.2.0")]
#[rustc_const_stable(feature = "const_iter_empty", since = "1.32.0")]
pub const fn empty<T>() -> Empty<T> {
    Empty(marker::PhantomData)
}

/// একটি পুনরুক্তি যা কিছুই দেয় না।
///
/// এই `struct` [`empty()`] ফাংশন দ্বারা নির্মিত হয়েছে।আরও জন্য এর ডকুমেন্টেশন দেখুন।
#[stable(feature = "iter_empty", since = "1.2.0")]
pub struct Empty<T>(marker::PhantomData<T>);

#[stable(feature = "iter_empty_send_sync", since = "1.42.0")]
unsafe impl<T> Send for Empty<T> {}
#[stable(feature = "iter_empty_send_sync", since = "1.42.0")]
unsafe impl<T> Sync for Empty<T> {}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T> fmt::Debug for Empty<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Empty")
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Iterator for Empty<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(0))
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> DoubleEndedIterator for Empty<T> {
    fn next_back(&mut self) -> Option<T> {
        None
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> ExactSizeIterator for Empty<T> {
    fn len(&self) -> usize {
        0
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Empty<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Empty<T> {}

// # নয় [উত্পন্ন] কারণ এটি টি তে আবদ্ধ ক্লোন যুক্ত করে, যা প্রয়োজনীয় নয়।
//
#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Clone for Empty<T> {
    fn clone(&self) -> Empty<T> {
        Empty(marker::PhantomData)
    }
}

// # নয় [উত্পন্ন] কারণ এটি টি তে একটি ডিফল্ট বাউন্ড যুক্ত করে, যা প্রয়োজনীয় নয়।
//
#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Default for Empty<T> {
    fn default() -> Empty<T> {
        Empty(marker::PhantomData)
    }
}