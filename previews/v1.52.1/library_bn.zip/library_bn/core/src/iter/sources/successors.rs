use crate::{fmt, iter::FusedIterator};

/// একটি নতুন পুনরাবৃত্তি তৈরি করে যেখানে প্রতিটি ধারাবাহিক আইটেম পূর্ববর্তীটির উপর ভিত্তি করে গণনা করা হয়।
///
/// পুনরুক্তি প্রদত্ত প্রথম আইটেমটি (যদি থাকে) দিয়ে শুরু হয় এবং প্রতিটি আইটেমের উত্তরসূরি গণনা করার জন্য প্রদত্ত `FnMut(&T) -> Option<T>` বন্ধকে কল করে।
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // যদি এই ফাংশনটি `impl Iterator<Item=T>` ফিরিয়ে দেয় তবে এটি `unfold` এর উপর ভিত্তি করে হতে পারে এবং কোনও উত্সর্গীকৃত প্রকারের প্রয়োজন হবে না।
    //
    // তবে একটি নামযুক্ত `Successors<T, F>` প্রকারটি `T` এবং `F` থাকা অবস্থায় এটি `Clone` হতে দেয়।
    Successors { next: first, succ }
}

/// একটি নতুন পুনরুক্তি যেখানে প্রতিটি ধারাবাহিক আইটেম পূর্ববর্তী একটি উপর ভিত্তি করে গণনা করা হয়।
///
/// এই `struct` [`iter::successors()`] ফাংশন দ্বারা নির্মিত হয়েছে।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}