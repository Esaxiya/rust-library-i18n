// উপেক্ষা-পরিপাটি-ফাইললেন্থ এই ফাইলটি প্রায় একচেটিয়াভাবে `Iterator` এর সংজ্ঞা নিয়ে গঠিত।
// আমরা এটিকে একাধিক ফাইলে বিভক্ত করতে পারি না।
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// পুনরাবৃত্তিকারীদের সাথে ডিল করার জন্য একটি ইন্টারফেস।
///
/// এটি প্রধান পুনরুক্তিকারী trait Z
/// সাধারণত পুনরাবৃত্তিকারীদের ধারণা সম্পর্কে আরও জানতে দয়া করে এক্স00 এক্স দেখুন।
/// বিশেষত, আপনি কীভাবে [implement `Iterator`][impl] করবেন তা জানতে চাইতে পারেন।
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// উপাদানগুলির ধরণটি পুনরাবৃত্তি হচ্ছে।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// পুনরাবৃত্তিকে অগ্রসর করে এবং পরবর্তী মানটি প্রদান করে।
    ///
    /// পুনরাবৃত্তি শেষ হয়ে গেলে [`None`] প্রদান করে।
    /// স্বতন্ত্র পুনরাবৃত্তির প্রয়োগগুলি পুনরাবৃত্তি পুনরায় শুরু করতে বেছে নিতে পারে এবং তাই `next()` আবার কল করা শেষ পর্যন্ত আবার কোনও মুহুর্তে X01 এক্স ফিরে আসতে শুরু করতে পারে বা নাও করতে পারে।
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() এ একটি কল পরবর্তী মানটি ফেরত দেয় ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... এবং তারপরে একবারও শেষ হবে না।
    /// assert_eq!(None, iter.next());
    ///
    /// // আরও কলগুলি `None` ফিরে আসতে পারে এবং নাও পারে।এখানে, তারা সর্বদা করবে।
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// পুনরাবৃত্তির অবশিষ্ট দৈর্ঘ্যের সীমানা প্রদান করে।
    ///
    /// বিশেষত, `size_hint()` একটি টুপল ফেরত দেয় যেখানে প্রথম উপাদানটি নিম্ন বাউন্ড এবং দ্বিতীয় উপাদানটি উপরের বাউন্ড হয়।
    ///
    /// যে টিউপল ফিরে আসে তার দ্বিতীয়ার্ধটি হ'ল একটি [`বিকল্প`]`<`[`usize`] `>` `
    /// এখানে একটি এক্স0১ এক্স এর অর্থ হল হয় হয় কোনও উচ্চতর বাউন্ড নেই, বা উপরের বাউন্ডটি [`usize`] এর চেয়ে বড়।
    ///
    /// # বাস্তবায়ন নোট
    ///
    /// এটি প্রয়োগ করা হয় না যে কোনও পুনরায় প্রয়োগকারী প্রয়োগের দ্বারা ঘোষিত সংখ্যক উপাদানের ফলস্বরূপ।কোনও বগি ইটারেটর নিম্ন বাউন্ডের চেয়ে কম বা উপাদানের উপরের সীমানার চেয়ে বেশি ফলন করতে পারে।
    ///
    /// `size_hint()` প্রাথমিকভাবে পুনরুক্তির উপাদানগুলির জন্য স্থান সংরক্ষণের মতো অপ্টিমাইজেশনের জন্য ব্যবহার করার উদ্দেশ্যে করা হয়েছে তবে এটি বিশ্বাসযোগ্য হবে না যেমন, অনিরাপদ কোডে সীমা ছাড়িয়ে চেক বাদ দিতে হবে।
    /// `size_hint()` এর একটি ভুল বাস্তবায়ন মেমরির সুরক্ষা লঙ্ঘনের দিকে পরিচালিত করা উচিত নয়।
    ///
    /// এটি বলেছে, বাস্তবায়নের একটি সঠিক অনুমান দেওয়া উচিত, কারণ অন্যথায় এটি trait এর প্রোটোকল লঙ্ঘন হবে।
    ///
    /// ডিফল্ট বাস্তবায়ন `(0,` [`কিছুই নয়]]`) returns দেয় যা কোনও পুনরুক্তারের জন্য সঠিক।
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// আরও জটিল উদাহরণ:
    ///
    /// ```
    /// // এমনকি শূন্য থেকে দশ পর্যন্ত সংখ্যা।
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // আমরা শূন্য থেকে দশ বার পুনরাবৃত্তি হতে পারে।
    /// // এটি পাঁচটি হ'ল জেনেও filter() এক্সিকিউট না করেই সম্ভব হবে না।
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() এর সাথে আরও পাঁচটি সংখ্যা যুক্ত করা যাক
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // এখন উভয় সীমানা পাঁচ দ্বারা বৃদ্ধি করা হয়েছে
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// উপরের সীমানার জন্য `None` রিটার্ন করা:
    ///
    /// ```
    /// // অসীম পুনরাবৃত্তির কোনও উপরের বাউন্ড এবং সর্বাধিক সম্ভাব্য নিম্ন বাঁধাই নেই
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// পুনরাবৃত্তি গ্রহণ করে, পুনরাবৃত্তির সংখ্যা গণনা করে এবং এটি ফেরত দেয়।
    ///
    /// [`None`] না আসা পর্যন্ত এই পদ্ধতিটি [`next`] বারবার কল করবে, এটি [`Some`] যতবার দেখেছিল তার সংখ্যা ফিরে আসবে।
    /// দ্রষ্টব্য যে পুনরাবৃত্তকারীটির কোনও উপাদান না থাকলেও [`next`] কমপক্ষে একবার কল করতে হবে।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ওভারফ্লো আচরণ
    ///
    /// পদ্ধতিটি ওভারফ্লো থেকে রক্ষা করে না, সুতরাং [`usize::MAX`] এর বেশি উপাদান সহ একটি পুনরাবৃত্তির উপাদান গণনা করা হয় ভুল ফলাফল বা panics উত্পাদন করে।
    ///
    /// যদি ডিবাগ assertions সক্ষম করা থাকে, একটি panic গ্যারান্টিযুক্ত হয়।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটিতে panic হতে পারে যদি ইটারেটরটিতে [`usize::MAX`] এর বেশি উপাদান থাকে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// শেষ উপাদানটি ফেরত, পুনরাবৃত্তি গ্রহণ করে।
    ///
    /// এই পদ্ধতিটি পুনরাবৃত্তিকারীকে [`None`] প্রদান না করা পর্যন্ত মূল্যায়ন করবে।
    /// এটি করার সময় এটি বর্তমান উপাদানটির উপর নজর রাখে।
    /// [`None`] ফিরে আসার পরে, `last()` তারপরে দেখা শেষ উপাদানটি ফিরিয়ে দেবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` উপাদান দ্বারা পুনরাবৃত্তি অগ্রসর করে।
    ///
    /// এই পদ্ধতিটি [`next`] এর মুখোমুখি হওয়া অবধি [`next`] পর্যন্ত [`next`] কল করে `n` উপাদানগুলিকে আগ্রহী করে এড়িয়ে যাবে।
    ///
    /// `advance_by(n)` এক্সট্রেস `n` উপাদানগুলির দ্বারা সাফল্যের সাথে অগ্রসর হলে [`Ok(())`][Ok], অথবা [`None`] সম্মুখীন হলে [`Err(k)`][Err] ফিরে আসবে, যেখানে `k` উপাদানগুলির সংখ্যা শেষ হওয়ার আগেই ইটারেটরটি উন্নত হয়েছে এমন সংখ্যার সংখ্যা রয়েছে (উদাঃ
    /// পুনরাবৃত্তির দৈর্ঘ্য)।
    /// দ্রষ্টব্য যে `k` সর্বদা `n` এর চেয়ে কম থাকে।
    ///
    /// `advance_by(0)` কল করা কোনও উপাদান গ্রাস করে না এবং সর্বদা [`Ok(())`][Ok] প্রদান করে।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // কেবলমাত্র `&4` এড়িয়ে গেছে
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// পুনরাবৃত্তির element n` তম উপাদানটি প্রদান করে।
    ///
    /// বেশিরভাগ সূচকের কাজগুলির মতো, গণনাটি শূন্য থেকে শুরু হয়, সুতরাং `nth(0)` প্রথম মান, দ্বিতীয়টি `nth(1)` প্রদান করে।
    ///
    /// দ্রষ্টব্য যে পূর্ববর্তী সমস্ত উপাদান, পাশাপাশি ফিরে আসা উপাদানগুলি পুনরাবৃত্তকারী থেকে গ্রাস করা হবে।
    /// এর অর্থ হ'ল পূর্ববর্তী উপাদানগুলি বাতিল করা হবে এবং একই পুনরুক্তারে একাধিকবার `nth(0)` কল করা বিভিন্ন উপাদানকে ফিরিয়ে দেবে।
    ///
    ///
    /// `nth()` `n` যদি পুনরাবৃত্তির দৈর্ঘ্যের চেয়ে বড় বা সমান হয় তবে [`None`] প্রদান করবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` একাধিকবার কল করা পুনরাবৃত্তিকারীকে রিওয়াইন্ড করে না:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` এর চেয়ে কম উপাদান থাকলে `None` রিটার্নিং:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// একই পয়েন্টে শুরু করে একটি পুনরুক্তি তৈরি করে তবে প্রতিটি পুনরাবৃত্তিতে প্রদত্ত পরিমাণে পদক্ষেপ নেওয়া।
    ///
    /// দ্রষ্টব্য 1: প্রদত্ত পদক্ষেপ নির্বিশেষে পুনরুক্তকারীর প্রথম উপাদানটি সর্বদা ফিরে আসবে।
    ///
    /// দ্রষ্টব্য 2: উপেক্ষিত উপাদানগুলিকে টানানোর সময় নির্দিষ্ট করা হয়নি।
    /// `StepBy` সিকোয়েন্স এক্স00 এক্স এর মতো আচরণ করে তবে সিকোয়েন্সের মতো আচরণ করতেও বিনামূল্যে
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// কোন উপায়ে ব্যবহৃত হয় তা কার্যকারণের কারণে কিছু পুনরাবৃত্তির জন্য পরিবর্তিত হতে পারে।
    /// দ্বিতীয় উপায়টি পূর্বে পুনরুক্তকারীকে অগ্রসর করবে এবং আরও আইটেম গ্রহণ করতে পারে।
    ///
    /// `advance_n_and_return_first` এর সমতুল্য:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// প্রদত্ত পদক্ষেপটি `0` হলে পদ্ধতিটি panic করবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// দুটি পুনরুক্তি নেয় এবং ক্রমানুসারে উভয়ের উপরে একটি নতুন পুনরাবৃত্তি তৈরি করে।
    ///
    /// `chain()` একটি নতুন পুনরাবৃত্তি ফিরিয়ে দেবে যা প্রথমে প্রথম পুনরুক্তিকারীর মান এবং তারপরে দ্বিতীয় পুনরাবৃত্তির মানগুলির উপরে পুনরাবৃত্তি করবে।
    ///
    /// অন্য কথায়, এটি দুটি পুনরাবৃত্তিকে এক সাথে শৃঙ্খলে লিঙ্ক করে।🔗
    ///
    /// [`once`] সাধারণত একক মানকে অন্য ধরণের পুনরাবৃত্তির শৃঙ্খলে রূপান্তর করতে ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `chain()`-তে যুক্তিটি [`IntoIterator`] ব্যবহার করে, তাই আমরা কেবল একটি [`Iterator`] নয়, একটি [`Iterator`] রূপান্তর করতে পারে এমন কোনও কিছু পাস করতে পারি।
    /// উদাহরণস্বরূপ, স্লাইসগুলি (`&[T]`) [`IntoIterator`] বাস্তবায়ন করে এবং তাই সরাসরি এক্স0 2 এক্সে যেতে পারে:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// আপনি যদি Windows এপিআই দিয়ে কাজ করেন তবে আপনি [`OsStr`] কে `Vec<u16>` এ রূপান্তর করতে পারেন:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// জোড়গুলির একক পুনরাবৃত্তিতে দু'টি পুনরায় 'জিপ আপ' করুন।
    ///
    /// `zip()` একটি নতুন পুনরাবৃত্তি প্রদান করে যা অন্য দুটি পুনরাবৃত্তির উপর পুনরাবৃত্তি করবে, এমন একটি টুপল ফিরে আসবে যেখানে প্রথম উপাদানটি প্রথম পুনরুক্তিদ্বার থেকে আসে এবং দ্বিতীয় উপাদানটি দ্বিতীয় পুনরুক্তি থেকে আসে।
    ///
    ///
    /// অন্য কথায়, এটি এককভাবে দুটি পুনরুক্তিকারীকে একসাথে জিপ করে।
    ///
    /// যদি পুনরাবৃত্তকারীরা [`None`] প্রদান করে তবে জিপযুক্ত পুনরুক্তিকারী থেকে [`next`] [`None`] প্রদান করবে।
    /// যদি প্রথম পুনরাবৃত্তকারী [`None`] প্রদান করে, `zip` শর্ট সার্কিট করবে এবং দ্বিতীয় পুনরুক্তিकर्ताটিতে `next` ডাকা হবে না।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `zip()`-তে যুক্তিটি [`IntoIterator`] ব্যবহার করে, তাই আমরা কেবল একটি [`Iterator`] নয়, একটি [`Iterator`] রূপান্তর করতে পারে এমন কোনও কিছু পাস করতে পারি।
    /// উদাহরণস্বরূপ, স্লাইসগুলি (`&[T]`) [`IntoIterator`] বাস্তবায়ন করে এবং তাই সরাসরি এক্স0 2 এক্সে যেতে পারে:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` একটি সীমিত একটি অনন্ত পুনরাবৃত্তি জিপ জন্য প্রায়শই ব্যবহৃত হয়।
    /// এটি কাজ করে কারণ সীমাবদ্ধ পুনরাবৃত্তকারী শেষ পর্যন্ত জিপারটি শেষ করে [`None`] ফিরে আসবে।`(0..)` দিয়ে জিপ করা অনেকটা [`enumerate`] এর মতো দেখতে পাওয়া যায়:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// একটি নতুন পুনরুক্তি তৈরি করে যা মূল পুনরুক্তকারীর সংলগ্ন আইটেমগুলির মধ্যে `separator` এর একটি অনুলিপি রাখে।
    ///
    /// `separator` [`Clone`] বাস্তবায়িত না করে বা প্রতিবার গণনা করা দরকার হলে [`intersperse_with`] ব্যবহার করুন।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` থেকে প্রথম উপাদান।
    /// assert_eq!(a.next(), Some(&100)); // বিভাজক।
    /// assert_eq!(a.next(), Some(&1));   // এক্স00 এক্স থেকে পরবর্তী উপাদান।
    /// assert_eq!(a.next(), Some(&100)); // বিভাজক।
    /// assert_eq!(a.next(), Some(&2));   // `a` থেকে শেষ উপাদান।
    /// assert_eq!(a.next(), None);       // পুনরুক্তি সম্পন্ন হয়।
    /// ```
    ///
    /// `intersperse` একটি সাধারণ উপাদান ব্যবহার করে পুনরাবৃত্তির আইটেমগুলিতে যোগদানের জন্য খুব দরকারী হতে পারে:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// একটি নতুন পুনরাবৃত্তি তৈরি করে যা `separator` দ্বারা উত্পন্ন আইটেমটি মূল পুনরুক্তকারীর সংলগ্ন আইটেমগুলির মধ্যে রাখে।
    ///
    /// অন্তর্নিহিত পুনরুক্তকারী থেকে দুটি আইটেম সংলগ্ন আইটেমগুলির মধ্যে প্রতিবার স্থাপন করার সময় বন্ধটি বলা হবে;
    /// বিশেষত, অন্তর্নিহিত পুনরাবৃত্তকারী দুটি আইটেমের কম ফলন করলে এবং শেষ আইটেমটি উত্পাদিত হওয়ার পরে ক্লোজার বলা হয় না।
    ///
    ///
    /// যদি পুনরুক্তিকারী আইটেমটি [`Clone`] প্রয়োগ করে তবে এটি [`intersperse`] ব্যবহার করা আরও সহজ হতে পারে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` থেকে প্রথম উপাদান।
    /// assert_eq!(it.next(), Some(NotClone(99))); // বিভাজক।
    /// assert_eq!(it.next(), Some(NotClone(1)));  // এক্স00 এক্স থেকে পরবর্তী উপাদান।
    /// assert_eq!(it.next(), Some(NotClone(99))); // বিভাজক।
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` থেকে শেষ উপাদান।
    /// assert_eq!(it.next(), None);               // পুনরুক্তি সম্পন্ন হয়।
    /// ```
    ///
    /// `intersperse_with` বিভাজককে গণনা করা দরকার এমন পরিস্থিতিতে ব্যবহার করা যেতে পারে:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // বন্ধটি পরস্পরভাবে কোনও আইটেম উত্পন্ন করার জন্য এর প্রসঙ্গটি ধার করে।
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// একটি অবসান নেয় এবং একটি পুনরুক্তি তৈরি করে যা প্রতিটি উপাদানকে সেই ক্লোজার বলে।
    ///
    /// `map()` একটি আউটরেটারকে তার যুক্তির মাধ্যমে অন্যটিতে রূপান্তরিত করে:
    /// [`FnMut`] প্রয়োগ করে এমন কিছু।এটি একটি নতুন পুনরুত্পাদনকারী উত্পাদন করে যা মূল পুনরুক্তির প্রতিটি উপাদানকে এই বন্ধ করে।
    ///
    /// আপনি যদি টাইপগুলিতে চিন্তা করতে ভাল হন তবে আপনি `map()` এর মতো চিন্তা করতে পারেন:
    /// যদি আপনার কাছে এমন একটি পুনরুক্তি থাকে যা আপনাকে কিছু প্রকারের `A` এর উপাদান দেয় এবং আপনি অন্য কোনও ধরণের `B` এর পুনরুক্তি চান, আপনি `map()` ব্যবহার করতে পারেন, একটি ক্লোজার যা `A` নেয় এবং একটি `B` প্রদান করে।
    ///
    ///
    /// `map()` এক্সএক্সএক্স লুপের সাথে ধারণার মতো।তবে, `map()` অলস হওয়ার কারণে, আপনি ইতিমধ্যে অন্যান্য পুনরাবৃত্তকারীদের সাথে কাজ করার সময় এটি সবচেয়ে ভাল ব্যবহৃত হয়।
    /// আপনি যদি পার্শ্ব প্রতিক্রিয়াটির জন্য কোনও ধরণের লুপিং করেন তবে এটি `map()` এর চেয়ে [`for`] ব্যবহার করা আরও মূর্খতা বলে মনে করা হয়।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// আপনি যদি কিছু ধরণের পার্শ্ব প্রতিক্রিয়া করছেন তবে [`for`] থেকে `map()` পছন্দ করুন:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // এটি করবেন না:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // এমনকি এটি কার্যকর করা হবে না, কারণ এটি অলস।Rust আপনাকে এই সম্পর্কে সতর্ক করবে।
    ///
    /// // পরিবর্তে, এর জন্য ব্যবহার করুন:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// একটি পুনরাবৃত্তকারী প্রতিটি উপাদান একটি বন্ধ কল।
    ///
    /// এটি পুনরুক্তিতে [`for`] লুপটি ব্যবহারের সমতুল্য, যদিও বন্ধ হওয়ার ফলে `break` এবং `continue` সম্ভব নয়।
    /// এটি `for` লুপটি ব্যবহার করার জন্য সাধারণত মুশকিল, তবে লম্বা পুনরাবৃত্ত শৃঙ্খলার শেষে আইটেমগুলি প্রক্রিয়াকরণ করার সময় `for_each` আরও সুগঠিত হতে পারে।
    ///
    /// কিছু ক্ষেত্রে `for_each` লুপের চেয়েও দ্রুত হতে পারে, কারণ এটি `Chain` এর মতো অ্যাডাপ্টারে অভ্যন্তরীণ পুনরাবৃত্তি ব্যবহার করবে।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// যেমন একটি ছোট উদাহরণের জন্য, একটি `for` লুপটি ক্লিনার হতে পারে তবে `for_each` দীর্ঘতর পুনরাবৃত্তকারীগুলির সাথে কার্যকরী শৈলী বজায় রাখা ভাল:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// এমন একটি পুনরুক্তি তৈরি করে যা কোনও উপাদানটি পাওয়া উচিত কিনা তা নির্ধারণের জন্য একটি ক্লোজার ব্যবহার করে।
    ///
    /// একটি উপাদান দেওয়া বন্ধের অবশ্যই `true` বা `false` ফেরত আসতে হবে।প্রত্যাবর্তিত পুনরাবৃত্তকারী কেবলমাত্র সেই উপাদানগুলি সরবরাহ করবে যার জন্য বন্ধটি সত্য হয় returns
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `filter()` এ দেওয়া বন্ধটি একটি রেফারেন্স নেয় এবং অনেক পুনরাবৃত্তি রেফারেন্সগুলি দিয়ে পুনরাবৃত্তি করে, এটি সম্ভবত একটি বিভ্রান্তিকর পরিস্থিতির দিকে নিয়ে যায় যেখানে বন্ধের ধরণটি দ্বৈত রেফারেন্স:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // দু'টি দরকার!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// পরিবর্তে যুক্তিটি ছুঁড়ে ফেলার জন্য ডেস্ট্রাকচারিং ব্যবহার করা সাধারণ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // দুটোই এবং *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// অথবা উভয়:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // দুটি এক্স 100 এক্স
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// এই স্তরগুলির।
    ///
    /// দ্রষ্টব্য যে `iter.filter(f).next()` `iter.find(f)` এর সমতুল্য।
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// একটি পুনরাবৃত্তি তৈরি করে যা ফিল্টার এবং মানচিত্র উভয়ই।
    ///
    /// প্রত্যাবর্তিত পুনরাবৃত্তকারী কেবলমাত্র `মান` ফলন করে যার জন্য সরবরাহকৃত ক্লোজার `Some(value)` প্রদান করে।
    ///
    /// `filter_map` এক্স 100 এক্স এবং এক্স01 এক্সকে আরও সংক্ষিপ্ত করে শৃঙ্খলা তৈরি করতে ব্যবহার করা যেতে পারে।
    /// নীচের উদাহরণটিতে দেখানো হয়েছে যে কীভাবে একটি এক্স01 এক্সকে একক কলে `filter_map` এ সংক্ষিপ্ত করা যেতে পারে।
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// এখানে একই উদাহরণ, তবে [`filter`] এবং [`map`] সহ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// একটি পুনরুক্তি তৈরি করে যা বর্তমান পুনরাবৃত্তির গণনা পাশাপাশি পরবর্তী মান দেয়।
    ///
    /// পুনরুক্তিটি `(i, val)` জোড়া দেয়, যেখানে `i` পুনরাবৃত্তির বর্তমান সূচক এবং `val` পুনরাবৃত্তির দ্বারা প্রত্যাবর্তিত মান।
    ///
    ///
    /// `enumerate()` এটি একটি [`usize`] হিসাবে গণনা রাখে।
    /// আপনি যদি কোনও ভিন্ন আকারের পূর্ণসংখ্যার দ্বারা গণনা করতে চান, [`zip`] ফাংশন অনুরূপ কার্যকারিতা সরবরাহ করে।
    ///
    /// # ওভারফ্লো আচরণ
    ///
    /// পদ্ধতিটি ওভারফ্লো থেকে রক্ষা করে না, সুতরাং [`usize::MAX`] এর বেশি উপাদান গণনা করা হয় ভুল ফলাফল বা panics উত্পাদন করে।
    /// যদি ডিবাগ assertions সক্ষম করা থাকে, একটি panic গ্যারান্টিযুক্ত হয়।
    ///
    /// # Panics
    ///
    /// প্রত্যাবর্তিত পুনরাবৃত্তিটি panic হতে পারে যদি টু-বি-রিটার্ন ইনডেক্সটি একটি [`usize`] উপচে পড়ে।
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// একটি পুনরুক্তি তৈরি করে যা এক্সট্রাক্টরটি ব্যবহার না করে পুনরুক্তির পরবর্তী উপাদানটি দেখার জন্য [`peek`] ব্যবহার করতে পারে।
    ///
    /// একটি পুনরুক্তিতে একটি [`peek`] পদ্ধতি যুক্ত করে।আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// মনে রাখবেন যে প্রথমবারের জন্য [`peek`] ডাকলে অন্তর্নিহিত পুনরুক্তিটি এখনও উন্নত: পরবর্তী উপাদানটি পুনরুদ্ধার করার জন্য, এক্স 300 এক্সকে অন্তর্নিহিত পুনরুক্তকারীটিতে ডাকা হয়, সুতরাং কোনও পার্শ্ব প্রতিক্রিয়া (যেমন
    ///
    /// [`next`] পদ্ধতির পরবর্তী মানটি আনয়ন ব্যতীত অন্য কিছু ঘটবে।
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() আমাদের জেডফিউচার0 জেডে দেখতে দিন
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // আমরা একাধিকবার peek() করতে পারি, পুনরাবৃত্তিটি অগ্রসর হবে না
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // পুনরুক্তি সমাপ্ত হওয়ার পরে, তাই এক্স 100 এক্স
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// একটি পূর্বাভাসের উপর ভিত্তি করে [`skip s] এর উপাদানগুলির একটি পুনরাবৃত্তি তৈরি করে।
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` যুক্তি হিসাবে একটি ক্লোজার গ্রহণ করে।এটি পুনরুক্তরের প্রতিটি উপাদানকে এই ক্লোজারটিকে কল করবে এবং এটি `false` ফেরত না দেওয়া পর্যন্ত উপাদানগুলিকে উপেক্ষা করবে।
    ///
    /// `false` ফিরে আসার পরে, `skip_while()`'s কাজ শেষ হয়ে গেছে এবং বাকি উপাদানগুলি পাওয়া যায়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `skip_while()` এ বন্ধ হওয়াটি একটি রেফারেন্স নেয় এবং অনেক পুনরাবৃত্তি রেফারেন্সগুলি দিয়ে পুনরাবৃত্তি করে, এটি সম্ভবত একটি বিভ্রান্তিকর পরিস্থিতির দিকে নিয়ে যায় যেখানে বন্ধের যুক্তির ধরণটি দ্বৈত রেফারেন্স:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // দু'টি দরকার!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// প্রাথমিক `false` এর পরে থামছে:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // যদিও এটি মিথ্যা হত, যেহেতু আমরা ইতিমধ্যে একটি মিথ্যা পেয়েছি, এক্স00 এক্স আর ব্যবহার করা হয় না
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// একটি পুনরুদ্ধারের উপর ভিত্তি করে উপাদান উত্পাদন করে এমন একটি পুনরুক্তি তৈরি করে।
    ///
    /// `take_while()` যুক্তি হিসাবে একটি ক্লোজার গ্রহণ করে।এটি পুনরুক্তরের প্রতিটি উপাদানকে এই ক্লোজারটিকে কল করবে এবং এটি `true` প্রদান করার সময় উপাদানগুলি প্রদান করবে।
    ///
    /// `false` ফিরে আসার পরে, `take_while()`'s কাজ শেষ হয়ে গেছে এবং বাকি উপাদানগুলি উপেক্ষা করা হবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `take_while()` এ দেওয়া বন্ধটি একটি রেফারেন্স নেয় এবং অনেক পুনরাবৃত্তি রেফারেন্সগুলি দিয়ে পুনরাবৃত্তি করে, এটি সম্ভবত একটি বিভ্রান্তিকর পরিস্থিতির দিকে নিয়ে যায় যেখানে বন্ধের ধরণটি দ্বৈত রেফারেন্স:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // দু'টি দরকার!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// প্রাথমিক `false` এর পরে থামছে:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // আমাদের কাছে আরও উপাদান রয়েছে যা শূন্যের চেয়ে কম, তবে যেহেতু আমরা ইতিমধ্যে একটি মিথ্যা পেয়েছি, take_while() আর ব্যবহার করা হয়নি
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যেহেতু `take_while()` এর মূল্য অন্তর্ভুক্ত করা উচিত কিনা তা দেখার জন্য প্রয়োজন, গ্রাহক পুনরুক্তিকারীরা দেখতে পাবেন যে এটি সরিয়ে ফেলা হয়েছে:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// এক্স 100 এক্স আর নেই, কারণ এটি পুনরুক্তি বন্ধ হওয়া উচিত কিনা তা দেখার জন্য এটি গ্রাস করা হয়েছিল, তবে এটি পুনরায় পুনরুক্তকারীর মধ্যে স্থাপন করা হয়নি।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// একটি পূরক এবং মানচিত্রের ভিত্তিতে উভয়ই উপাদান দেয় এমন একটি পুনরুক্তি তৈরি করে।
    ///
    /// `map_while()` যুক্তি হিসাবে একটি ক্লোজার গ্রহণ করে।
    /// এটি পুনরুক্তরের প্রতিটি উপাদানকে এই ক্লোজারটিকে কল করবে এবং এটি [`Some(_)`][`Some`] প্রদান করার সময় উপাদানগুলি প্রদান করবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// এখানে একই উদাহরণ, তবে [`take_while`] এবং [`map`] সহ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// প্রাথমিক [`None`] এর পরে থামছে:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // আমাদের কাছে আরও উপাদান রয়েছে যা u32 (4, 5) এ ফিট করতে পারে তবে `map_while` `-3` এর জন্য `None` ফিরিয়েছিল (`predicate` `None` প্রত্যাবর্তন করেছিল) এবং `collect` সম্মুখীন হওয়া প্রথম `None` এ থামে।
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// যেহেতু `map_while()` এর মূল্য অন্তর্ভুক্ত করা উচিত কিনা তা দেখার জন্য প্রয়োজন, গ্রাহক পুনরুক্তিকারীরা দেখতে পাবেন যে এটি সরিয়ে ফেলা হয়েছে:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// এক্স 100 এক্স আর নেই, কারণ এটি পুনরুক্তি বন্ধ হওয়া উচিত কিনা তা দেখার জন্য এটি গ্রাস করা হয়েছিল, তবে এটি পুনরায় পুনরুক্তকারীর মধ্যে স্থাপন করা হয়নি।
    ///
    /// নোট করুন যে [`take_while`] এর বিপরীতে এই পুনরাবৃত্তিকে **নয়** ফিউজ করা হয়েছে।
    /// প্রথম [`None`] ফেরার পরে এই পুনরাবৃত্তির কী ফিরে আসে তাও নির্দিষ্ট করা হয়নি।
    /// যদি আপনার ফিউজড আইট্রেটার প্রয়োজন হয় তবে এক্স00 এক্স ব্যবহার করুন।
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// একটি পুনরুক্তি তৈরি করে যা প্রথম `n` উপাদানগুলিকে এড়িয়ে যায়।
    ///
    /// সেগুলি গ্রাস হওয়ার পরে, বাকি উপাদানগুলি ফলন করে।
    /// সরাসরি এই পদ্ধতিটিকে ওভাররাইড না করে `nth` পদ্ধতিটি ওভাররাইড করুন।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// এমন একটি পুনরুক্তি তৈরি করে যা তার প্রথম `n` উপাদান দেয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` এটি সীমাবদ্ধ করতে প্রায়শই অসীম পুনরাবৃত্তকারীগুলির সাথে ব্যবহৃত হয়:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// যদি `n` এর চেয়ে কম উপাদান উপলব্ধ থাকে তবে `take` এটিকে অন্তর্নিহিত পুনরাবৃত্তির আকারের মধ্যে সীমাবদ্ধ করবে:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] এর অনুরূপ একটি পুনরাবৃত্তির অ্যাডাপ্টার যা অভ্যন্তরীণ স্থিতি রাখে এবং একটি নতুন পুনরায় উত্পাদক উত্পাদন করে।
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` দুটি আর্গুমেন্ট গ্রহণ করে: একটি প্রাথমিক মান যা অভ্যন্তরীণ অবস্থার বীজ দেয় এবং দুটি যুক্তি সহ একটি সমাপ্তি, প্রথমটি অভ্যন্তরীণ অবস্থার পরিবর্তিত রেফারেন্স এবং দ্বিতীয়টি একটি পুনরুক্তি উপাদান element
    ///
    /// সমাপনটি পুনরাবৃত্তির মধ্যে রাষ্ট্র ভাগ করে নেওয়ার জন্য অভ্যন্তরীণ অবস্থাকে অর্পণ করতে পারে।
    ///
    /// পুনরাবৃত্তির সময়, ক্লোজারটি পুনরাবৃত্তির প্রতিটি উপাদানগুলিতে প্রয়োগ করা হবে এবং ক্লোজারের থেকে ফেরতের মান, একটি এক্স 100 এক্স, পুনরুক্তি দ্বারা উত্পাদিত হবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // প্রতিটি পুনরাবৃত্তি, আমরা উপাদান দ্বারা রাজ্য গুন করব
    ///     *state = *state * x;
    ///
    ///     // তারপরে, আমরা রাষ্ট্রের অবহেলা করব
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// একটি পুনরাবৃত্তি তৈরি করে যা মানচিত্রের মতো কাজ করে তবে নেস্টেড কাঠামোকে সমতল করে।
    ///
    /// এক্স 100 এক্স অ্যাডাপ্টারটি খুব দরকারী, তবে কেবল যখন ক্লোজার আর্গুমেন্টটি মান দেয়।
    /// পরিবর্তে এটি যদি একটি আয়রেটর তৈরি করে তবে সেখানে অতিরিক্ত দিকনির্দেশের একটি অতিরিক্ত স্তর রয়েছে।
    /// `flat_map()` এই অতিরিক্ত স্তরটি নিজে থেকে সরিয়ে ফেলবে।
    ///
    /// আপনি `flat_map(f)` কে [`মানচিত্র`] পিং এর অর্থসূচক সমতুল্য হিসাবে এবং তারপরে [` ফ্ল্যাটেন] এক্স ২০০ এক্স এর মতো ভাবতে পারেন।
    ///
    /// এক্স00 এক্স সম্পর্কে চিন্তা করার আর একটি উপায়: [`মানচিত্রের] বন্ধ হওয়া প্রতিটি উপাদানটির জন্য একটি আইটেম দেয় এবং এক্স01 এক্স বন্ধ প্রতিটি উপাদানের জন্য একটি পুনরাবৃত্তিকে দেয়।
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() একটি পুনরাবৃত্তি প্রদান করে
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// একটি পুনরাবৃত্তি তৈরি করে যা নীড়ের কাঠামোকে সমতল করে।
    ///
    /// এটি কার্যকর যখন আপনার কাছে পুনরাবৃত্তির একটি পুনরাবৃত্তিকারী বা এমন কোনও জিনিসের পুনরুক্তি করা হবে যা পুনরাবৃত্তিতে পরিণত হতে পারে এবং আপনি ইন্ডিরিশনের একটি স্তর সরাতে চান।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// ম্যাপিং এবং তারপরে সমতলকরণ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() একটি পুনরাবৃত্তি প্রদান করে
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// আপনি এটি [`flat_map()`] এর শর্তে আবারও লিখতে পারেন, যা এই ক্ষেত্রে আরও ভাল কারণ এটি আরও স্পষ্টভাবে অভিপ্রায় জানায়:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() একটি পুনরাবৃত্তি প্রদান করে
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// সমতলকরণ একবারে বাসা বাঁধার এক স্তরকে সরিয়ে দেয়:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// এখানে আমরা দেখতে পাই যে `flatten()` একটি "deep" সমতল সম্পাদন করে না।
    /// পরিবর্তে, শুধুমাত্র একটি স্তর নীড় অপসারণ করা হয়।অর্থাৎ, আপনি যদি ত্রিমাত্রিক অ্যারে `flatten()` করেন তবে ফলাফলটি দ্বিমাত্রিক হবে এবং এক-মাত্রিক নয়।
    /// একটি মাত্রিক কাঠামো পেতে, আপনাকে আবার `flatten()` করতে হবে।
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// একটি পুনরুক্তি তৈরি করে যা প্রথম [`None`] এর পরে শেষ হয়।
    ///
    /// কোনও পুনরুক্তিকারী [`None`] ফেরত দেওয়ার পরে, জেডফিউচার0 জেড কলগুলি আবারও এক্স01 এক্স প্রদান করতে পারে বা নাও পারে।
    /// `fuse()` একটি পুনরাবৃত্তিকে অ্যাডাপ্ট করে, এটি নিশ্চিত করে যে কোনও [`None`] দেওয়ার পরে, এটি সর্বদা [`None`] চিরতরে ফিরে আসবে।
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // একটি পুনরাবৃত্তি যা কিছু এবং কোনওটির মধ্যেই বিকল্প নয়
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // যদি এটি সমান হয় তবে এক্স00 এক্স, অন্য কোনও নয়
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // আমরা আমাদের পুনরাবৃত্তিকে পিছনে পিছনে যেতে দেখছি
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // তবে, একবার আমরা এটি ফিউজ ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // এটি সর্বদা প্রথমবারের পরে `None` ফেরত আসবে।
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// মানটি পাস করে একটি পুনরুক্তকারকের প্রতিটি উপাদান দিয়ে কিছু করে।
    ///
    /// পুনরাবৃত্তকারী ব্যবহার করার সময়, আপনি প্রায়শই তাদের বেশ কয়েকটিকে এক সাথে শৃঙ্খলাবদ্ধ করে রাখবেন।
    /// এই জাতীয় কোডে কাজ করার সময়, আপনি পাইপলাইনের বিভিন্ন অংশে কী ঘটছে তা যাচাই করতে চাইতে পারেন।এটি করতে, `inspect()` এ একটি কল sertোকান।
    ///
    /// আপনার চূড়ান্ত কোডে উপস্থিত হওয়ার চেয়ে `inspect()` কে ডিবাগিংয়ের সরঞ্জাম হিসাবে ব্যবহার করা আরও সাধারণ, তবে ত্রুটিগুলি ফেলে দেওয়ার আগে লগ করা দরকার হলে অ্যাপ্লিকেশনগুলি কিছু পরিস্থিতিতে কার্যকর হতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // এই পুনরুক্তি ক্রম জটিল।
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // আসুন কী হচ্ছে তা তদন্ত করতে কয়েকটি এক্স00 এক্স কল যুক্ত করা যাক
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// এটি মুদ্রণ করবে:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ত্যাগ করার আগে লগিং ত্রুটিগুলি:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// এটি মুদ্রণ করবে:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// এটির ব্যবহারের চেয়ে একটি পুনরুক্তি ধার করে।
    ///
    /// মূল পুনরুদ্ধারের মালিকানা ধরে রাখার সময় এটির পুনরায় অ্যাডাপ্টার প্রয়োগ করার জন্য এটি দরকারী।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // যদি আমরা আবার এটির ব্যবহার করার চেষ্টা করি তবে এটি কার্যকর হবে না।
    /// // নিম্নলিখিত লাইনটি "ত্রুটি দেয়: স্থানান্তরিত মানটির ব্যবহার: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // এর আবার চেষ্টা করুন
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // পরিবর্তে, আমরা একটি .by_ref() যুক্ত করি
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // এখন এটি ঠিক আছে:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// একটি পুনরুক্তি সংগ্রহের মধ্যে রূপান্তর।
    ///
    /// `collect()` পুনরাবৃত্তিযোগ্য যে কোনও কিছু নিতে পারে এবং এটিকে প্রাসঙ্গিক সংগ্রহে পরিণত করতে পারে।
    /// এটি প্রমিত লাইব্রেরির অন্যতম শক্তিশালী পদ্ধতি যা বিভিন্ন প্রসঙ্গে ব্যবহৃত হয়।
    ///
    /// `collect()` ব্যবহার করা হয় এমন সর্বাধিক প্রাথমিক প্যাটার্ন হ'ল একটি সংগ্রহকে অন্যটিতে পরিণত করা।
    /// আপনি একটি সংগ্রহ নেন, এতে [`iter`] কল করুন, একগুচ্ছ রূপান্তর করুন এবং তারপরে শেষে `collect()`।
    ///
    /// `collect()` সাধারণ সংগ্রহ নয় এমন ধরণের উদাহরণগুলিও তৈরি করতে পারে।
    /// উদাহরণস্বরূপ, একটি এক্স01 এক্স [`চার`] গুলি থেকে তৈরি করা যেতে পারে এবং এক্স02 এক্স আইটেমগুলির একটি পুনরায় `Result<Collection<T>, E>` এ সংগ্রহ করা যেতে পারে।
    ///
    /// আরও জন্য নীচের উদাহরণ দেখুন।
    ///
    /// `collect()` যেহেতু সাধারণ, তাই এটি টাইপ ইনফারেন্সে সমস্যা তৈরি করতে পারে।
    /// এর মতো, `collect()` হল কয়েকবার আপনি সিন্টেক্সটি স্নেহের সাথে 'turbofish' হিসাবে পরিচিত: `::<>`.
    /// এটি অনুমানের অ্যালগরিদমকে বিশেষভাবে বুঝতে সাহায্য করে আপনি কোন সংগ্রহটি সংগ্রহ করতে চেষ্টা করছেন।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// নোট করুন যে আমাদের বাম দিকে `: Vec<i32>` প্রয়োজন।এটি কারণ আমরা উদাহরণস্বরূপ, এটির পরিবর্তে একটি [`VecDeque<T>`] সংগ্রহ করতে পারি:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` টি টিকিয়ে দেওয়ার পরিবর্তে 'turbofish' ব্যবহার করে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// যেহেতু `collect()` কেবল আপনি কী সংগ্রহ করছেন তা যত্নশীল তাই আপনি টার্বোফিশ সহ আংশিক প্রকারের ইঙ্গিত, `_` ব্যবহার করতে পারেন:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] তৈরি করতে `collect()` ব্যবহার করে:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// আপনার যদি [`ফলাফলের তালিকা থাকে<T, E>`][`ফলাফল`] গুলি, এর মধ্যে কোনওটি ব্যর্থ হয়েছে কিনা তা দেখতে আপনি `collect()` ব্যবহার করতে পারেন:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // আমাদের প্রথম ত্রুটি দেয়
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // আমাদের উত্তর তালিকা দেয়
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// এটি থেকে দুটি সংগ্রহ তৈরি করে একটি পুনরুক্তি গ্রহণ করে।
    ///
    /// `partition()` এ পাসডিকেটটি `true` বা `false` ফিরে আসতে পারে।
    /// `partition()` একটি জুড়ি, সমস্ত উপাদান যেটির জন্য এটি `true` প্রদান করেছিল, এবং যে উপাদানগুলির জন্য এটি `false` ফিরিয়েছিল তাদের সমস্ত প্রদান করে।
    ///
    ///
    /// এক্স01 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// প্রদত্ত পূর্বাভাস অনুযায়ী এই পুনরাবৃত্তির উপাদানগুলিকে * * স্থানে * পুনঃক্রম করে, যেমন `true` ফেরত যারা `false` ফিরে আসে তাদের সকলের আগেই।
    ///
    /// পাওয়া `true` উপাদানগুলির সংখ্যা প্রদান করে।
    ///
    /// বিভক্ত আইটেমগুলির আপেক্ষিক ক্রম বজায় রাখা হয় না।
    ///
    /// এক্স01 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // সন্ধ্যা ও প্রতিকূলতার মধ্যে পার্টিশন স্থানে থাকা
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: আমাদের কি গণনা উপচে পড়া নিয়ে চিন্তা করা উচিত?এর চেয়ে বেশি থাকার একমাত্র উপায়
        // `usize::MAX` পরিবর্তনীয় রেফারেন্সগুলি জেডএসটিগুলির সাথে রয়েছে, যা বিভাজনের পক্ষে কার্যকর নয় ...

        // `Self` এ উদারতা এড়াতে এই ক্লোজার এক্স01 এক্স ফাংশনগুলি বিদ্যমান।

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // বারবার প্রথম `false` সন্ধান করুন এবং শেষ `true` এর সাথে এটি স্যুপ করুন।
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// এই পুনরাবৃত্তকারীটির উপাদানগুলি প্রদত্ত প্রিকিকেট অনুসারে বিভাজন করা হয়েছে কিনা তা পরীক্ষা করে, যেমন `true` ফেরত আসে এমন সমস্ত যারা `false` ফেরত দেয় তাদের আগে রয়েছে।
    ///
    ///
    /// এক্স01 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // হয় সমস্ত আইটেম `true` পরীক্ষা করে, অথবা প্রথম ধারাটি `false` এ থামে এবং আমরা পরীক্ষা করে দেখি যে এর পরে আর কোনও এক্স0 2 এক্স নেই।
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// একটি পুনরুক্তি পদ্ধতি যা একটি ফাংশন প্রয়োগ করে যতক্ষণ না এটি সাফল্যের সাথে ফিরে আসে, একক, চূড়ান্ত মান উত্পাদন করে।
    ///
    /// `try_fold()` দুটি আর্গুমেন্ট নেয়: একটি প্রাথমিক মান এবং দুটি আর্গুমেন্টের সাথে বন্ধ: একটি এক্স 100 এক্স এবং একটি উপাদান।
    /// ক্লোজারটি সফলভাবে ফিরে আসে, পরবর্তী পুনরাবৃত্তির জন্য সংগ্রহকারীর থাকা উচিত এমন মান সহকারে বা এটি ব্যর্থতার সাথে ফিরে আসে, তাত্ক্ষণিকভাবে ফোন করে এক্সএক্সএক্স এক্সপ্লোর করা হয় X
    ///
    ///
    /// প্রারম্ভিক মান হ'ল প্রথম কলটিতে সংগ্রহকারীর মান।যদি ক্লোজারটি প্রয়োগ করা পুনরুক্তরের প্রতিটি উপাদানের বিপরীতে সফল হয়, `try_fold()` চূড়ান্ত সংগ্রহকারীকে সাফল্য হিসাবে দেয়।
    ///
    /// আপনি যখনই কোনও কিছুর সংকলন পাবেন তখন ভাঁজ কার্যকর হয় এবং এ থেকে একটি একক মান উত্পাদন করতে চান।
    ///
    /// # প্রয়োগকারীদের নোট
    ///
    /// অন্যান্য কয়েকটি এক্স00 এক্স পদ্ধতির মধ্যে এর ডিফল্ট বাস্তবায়ন রয়েছে, তাই এটি ডিফল্ট এক্স01 এক্স লুপ বাস্তবায়নের চেয়ে আরও ভাল কিছু করতে পারলে এটি স্পষ্টতই প্রয়োগ করার চেষ্টা করুন।
    ///
    /// বিশেষত, অভ্যন্তরীণ অংশগুলি থেকে এই কলটি রচনা করা হয়েছে যাতে এই কলটি `try_fold()` করার চেষ্টা করুন।
    /// যদি একাধিক কলের প্রয়োজন হয়, এক্স00 এক্স অপারেটরটি সাথে সাথে সঞ্চয়ের মানটি শৃঙ্খলাবদ্ধ করতে সুবিধাজনক হতে পারে, তবে যে কোনও আক্রমণকারীকে তাড়াতাড়ি রিটার্নের আগে ধরে রাখতে হবে সাবধান।
    /// এটি একটি এক্স 100 এক্স পদ্ধতি, সুতরাং এখানে ত্রুটি মারার পরে পুনরাবৃত্তির পুনরায় শুরু হওয়া দরকার।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // অ্যারের সমস্ত উপাদানগুলির পরীক্ষিত যোগফল
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 টি উপাদান যুক্ত করার সময় এই যোগফল ওভারফ্লো হয়
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // এটি সংক্ষিপ্ত প্রচারিত হওয়ার কারণে, বাকি উপাদানগুলি এখনও পুনরুক্তকারীর মাধ্যমে উপলব্ধ।
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// একটি পুনরুক্তি পদ্ধতি যা পুনরুদ্ধারের প্রতিটি আইটেমে একটি ফলস্বরূপ ফাংশন প্রয়োগ করে, প্রথম ত্রুটিতে থামিয়ে সেই ত্রুটিটি ফিরিয়ে দেয়।
    ///
    ///
    /// এটি [`for_each()`] এর ফলস্বরূপ হিসাবে বা [`try_fold()`] এর স্টেটলেস সংস্করণ হিসাবেও ভাবা যেতে পারে।
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // এটি সংক্ষিপ্তভাবে প্রচারিত হয়েছে, তাই বাকী আইটেমগুলি এখনও পুনরুক্তিতে রয়েছে:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// চূড়ান্ত ফলাফলটি ফিরে আসার মাধ্যমে একটি অপারেশন প্রয়োগ করে প্রতিটি উপাদান একটি সংযোজকের মধ্যে ভাঁজ করে।
    ///
    /// `fold()` দুটি আর্গুমেন্ট নেয়: একটি প্রাথমিক মান এবং দুটি আর্গুমেন্টের সাথে বন্ধ: একটি এক্স 100 এক্স এবং একটি উপাদান।
    /// ক্লোজারটি পরবর্তী পুনরাবৃত্তির জন্য সংগ্রহকারীর থাকা উচিত এমন মানটি ফিরিয়ে দেয়।
    ///
    /// প্রারম্ভিক মান হ'ল প্রথম কলটিতে সংগ্রহকারীর মান।
    ///
    /// পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই ক্লোজার প্রয়োগের পরে, `fold()` সঞ্চয়েরকে ফেরত দেয়।
    ///
    /// এই অপারেশনটিকে কখনও কখনও 'reduce' বা 'inject' বলা হয়।
    ///
    /// আপনি যখনই কোনও কিছুর সংকলন পাবেন তখন ভাঁজ কার্যকর হয় এবং এ থেকে একটি একক মান উত্পাদন করতে চান।
    ///
    /// Note: `fold()` এবং একই ধরণের পদ্ধতিগুলি যা পুরো আয়রেটরকে অতিক্রম করে, অসীম পুনরাবৃত্তির জন্য এমনকি traits এও শেষ হতে পারে না যার ফলস্বরূপ সীমাবদ্ধ সময়ে নির্ধারিত হয়।
    ///
    /// Note: প্রাথমিক উপাদান হিসাবে প্রথম উপাদানটি ব্যবহার করতে [`reduce()`] ব্যবহার করা যেতে পারে, যদি সঞ্চয়ের ধরণ এবং আইটেমের ধরণ একই থাকে।
    ///
    /// # প্রয়োগকারীদের নোট
    ///
    /// অন্যান্য কয়েকটি এক্স00 এক্স পদ্ধতির মধ্যে এর ডিফল্ট বাস্তবায়ন রয়েছে, তাই এটি ডিফল্ট এক্স01 এক্স লুপ বাস্তবায়নের চেয়ে আরও ভাল কিছু করতে পারলে এটি স্পষ্টতই প্রয়োগ করার চেষ্টা করুন।
    ///
    ///
    /// বিশেষত, অভ্যন্তরীণ অংশগুলি থেকে এই কলটি রচনা করা হয়েছে যাতে এই কলটি `fold()` করার চেষ্টা করুন।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // অ্যারের সমস্ত উপাদানের যোগফল
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// আসুন এখানে পুনরাবৃত্তির প্রতিটি পদক্ষেপের মধ্য দিয়ে চলুন:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// এবং তাই, আমাদের চূড়ান্ত ফলাফল, `6`.
    ///
    /// ফলাফল তৈরির জন্য এমন লোকদের জন্য যারা এক্সটার 01X লুপটি ব্যবহার করতে পুনরাবৃত্তিকারীদের প্রচুর ব্যবহার করেন নি তাদের পক্ষে এটি সাধারণ।এগুলি `fold()`s এ রূপান্তরিত করা যেতে পারে:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // লুপের জন্য:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // তারা একই
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// বারবার একটি হ্রাস অপারেশন প্রয়োগ করে উপাদানগুলিকে একক হিসাবে হ্রাস করে।
    ///
    /// যদি পুনরুক্তিটি খালি থাকে, এক্স 100 এক্স প্রদান করে;অন্যথায়, হ্রাস ফলাফল প্রদান করে।
    ///
    /// কমপক্ষে একটি উপাদান সহ পুনরাবৃত্তকারীদের জন্য, এটি প্রাথমিক মান হিসাবে পুনরাবৃত্তির প্রথম উপাদানটির সাথে [`fold()`] এর সমান, প্রতিটি পরবর্তী উপাদানকে এতে ভাঁজ করে।
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// সর্বাধিক মান সন্ধান করুন:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// পুনরুক্তরের প্রতিটি উপাদান একটি প্রাকটিকের সাথে মেলে কিনা পরীক্ষা করে।
    ///
    /// `all()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।এটি পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই ক্লোজারের প্রয়োগ করে এবং যদি তারা সকলে `true` ফেরত দেয়, তবে এক্স00 এক্সও করে।
    /// যদি তাদের মধ্যে কেউ `false` প্রদান করে তবে এটি `false` প্রদান করে।
    ///
    /// `all()` শর্ট সার্কিট হয়;অন্য কথায়, এটি `false` সন্ধান করার সাথে সাথে এটি প্রক্রিয়াজাতকরণ বন্ধ করে দেবে, অন্য যে কী ঘটুক না কেন, ফলাফলটিও `false` হবে।
    ///
    ///
    /// একটি খালি পুনরাবৃত্তি `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// প্রথম `false` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// পুনরুক্তিগুলির কোনও উপাদান একটি প্রাকটিকের সাথে মেলে কিনা পরীক্ষা করে।
    ///
    /// `any()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।এটি পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই বন্ধনটি প্রয়োগ করে এবং যদি তাদের মধ্যে কেউ যদি `true` ফেরত দেয় তবে এক্স 100 এক্সও করে।
    /// যদি তারা সকলে `false` ফেরত দেয় তবে এটি `false` প্রদান করে।
    ///
    /// `any()` শর্ট সার্কিট হয়;অন্য কথায়, এটি `true` সন্ধান করার সাথে সাথে এটি প্রক্রিয়াজাতকরণ বন্ধ করে দেবে, অন্য যে কী ঘটুক না কেন, ফলাফলটিও `true` হবে।
    ///
    ///
    /// একটি খালি পুনরাবৃত্তি `false` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// প্রথম `true` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// একটি পুনরাবৃত্তিকে সন্তুষ্ট করে এমন একটি পুনরুক্তির উপাদানটির অনুসন্ধান করে।
    ///
    /// `find()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।
    /// এটি পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই ক্লোজারটি প্রযোজ্য এবং তাদের মধ্যে যদি কেউ `true` ফেরত দেয় তবে `find()` [`Some(element)`] প্রদান করে।
    /// যদি তারা সকলে `false` ফেরত দেয় তবে এটি [`None`] প্রদান করে।
    ///
    /// `find()` শর্ট সার্কিট হয়;অন্য কথায়, ক্লোজারটি `true` ফেরার সাথে সাথে এটি প্রক্রিয়া বন্ধ করবে stop
    ///
    /// যেহেতু `find()` একটি রেফারেন্স নিয়েছে এবং অনেকগুলি পুনরাবৃত্তি রেফারেন্সগুলি দিয়ে পুনরাবৃত্তি করে, এটি সম্ভবত বিভ্রান্তিকর পরিস্থিতির দিকে নিয়ে যায় যেখানে যুক্তিটি দ্বৈত রেফারেন্স।
    ///
    /// আপনি `&&x` এর সাহায্যে নীচের উদাহরণগুলিতে এই প্রভাবটি দেখতে পারেন।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// প্রথম `true` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// দ্রষ্টব্য যে `iter.find(f)` `iter.filter(f).next()` এর সমতুল্য।
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// পুনরাবৃত্তির উপাদানগুলিতে ফাংশন প্রয়োগ করে এবং প্রথম নয় এমন ফলাফল প্রদান করে।
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` এর সমতুল্য।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// পুনরাবৃত্তির উপাদানগুলিতে ফাংশন প্রয়োগ করে এবং প্রথম সত্য ফলাফল বা প্রথম ত্রুটি প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// একটি পুনরুক্তকারীতে একটি উপাদান অনুসন্ধান করে, তার সূচকটি ফেরত দেয়।
    ///
    /// `position()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।
    /// এটি পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই ক্লোজারের প্রযোজ্য এবং যদি তাদের মধ্যে একটির যদি `true` প্রদান করে তবে `position()` [`Some(index)`] প্রদান করে।
    /// যদি তাদের সমস্তই `false` ফেরত দেয় তবে এটি [`None`] প্রদান করে।
    ///
    /// `position()` শর্ট সার্কিট হয়;অন্য কথায়, এটি `true` খুঁজে পাওয়ার সাথে সাথে এটি প্রক্রিয়াজাতকরণ বন্ধ করবে।
    ///
    /// # ওভারফ্লো আচরণ
    ///
    /// পদ্ধতিটি ওভারফ্লোগুলির বিরুদ্ধে কোনও রক্ষা করে না, সুতরাং যদি [`usize::MAX`] এর চেয়ে বেশি মিল না-পাওয়া উপাদান থাকে, তবে এটি ভুল ফলাফল বা panics উত্পাদন করে।
    ///
    /// যদি ডিবাগ assertions সক্ষম করা থাকে, একটি panic গ্যারান্টিযুক্ত হয়।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটিতে panic হতে পারে যদি ইটারেটারে `usize::MAX` এর চেয়েও বেশি মিল-না থাকা উপাদান থাকে।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// প্রথম `true` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // প্রত্যাবর্তিত সূচক পুনরুক্তি স্থিতির উপর নির্ভর করে
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ডান দিক থেকে একটি পুনরাবৃত্তিতে একটি উপাদান অনুসন্ধান করে, তার সূচকটি ফেরত।
    ///
    /// `rposition()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।
    /// এটি শেষ থেকে শুরু করে পুনরাবৃত্তির প্রতিটি উপাদানগুলিতে এই বন্ধনটি প্রয়োগ করে এবং যদি তাদের মধ্যে কোনওটি `true` প্রদান করে তবে `rposition()` [`Some(index)`] প্রদান করে।
    ///
    /// যদি তাদের সমস্তই `false` ফেরত দেয় তবে এটি [`None`] প্রদান করে।
    ///
    /// `rposition()` শর্ট সার্কিট হয়;অন্য কথায়, এটি `true` খুঁজে পাওয়ার সাথে সাথে এটি প্রক্রিয়াজাতকরণ বন্ধ করবে।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// প্রথম `true` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // এখানে ওভারফ্লো চেকের দরকার নেই, কারণ `ExactSizeIterator` বোঝায় যে উপাদানগুলির সংখ্যা একটি `usize` এ ফিট করে।
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// একটি আয়রকের সর্বাধিক উপাদান প্রদান করে।
    ///
    /// যদি বেশ কয়েকটি উপাদান সমান সর্বাধিক হয় তবে শেষ উপাদানটি ফিরে আসে।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// একটি পুনরাবৃত্তির সর্বনিম্ন উপাদান প্রদান করে।
    ///
    /// বেশ কয়েকটি উপাদান সমান ন্যূনতম হলে প্রথম উপাদানটি ফেরত দেওয়া হয়।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// নির্দিষ্ট ফাংশন থেকে সর্বাধিক মান দেয় এমন উপাদানটি প্রদান করে।
    ///
    ///
    /// যদি বেশ কয়েকটি উপাদান সমান সর্বাধিক হয় তবে শেষ উপাদানটি ফিরে আসে।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// নির্দিষ্ট তুলনা ফাংশনটি সর্বাধিক মান দেয় এমন উপাদানটি প্রদান করে।
    ///
    ///
    /// যদি বেশ কয়েকটি উপাদান সমান সর্বাধিক হয় তবে শেষ উপাদানটি ফিরে আসে।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// নির্দিষ্ট ফাংশন থেকে ন্যূনতম মান দেয় এমন উপাদানটি প্রদান করে।
    ///
    ///
    /// বেশ কয়েকটি উপাদান সমান ন্যূনতম হলে প্রথম উপাদানটি ফেরত দেওয়া হয়।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// নির্দিষ্ট তুলনা ফাংশনটি সম্মানের সাথে ন্যূনতম মান দেয় এমন উপাদানটি প্রদান করে।
    ///
    ///
    /// বেশ কয়েকটি উপাদান সমান ন্যূনতম হলে প্রথম উপাদানটি ফেরত দেওয়া হয়।
    /// যদি পুনরুক্তিটি খালি থাকে, [`None`] ফিরে আসবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// একটি পুনরাবৃত্তির দিককে বিপরীত করে।
    ///
    /// সাধারণত, পুনরাবৃত্তিগুলি বাম থেকে ডানে পুনরাবৃত্তি হয়।
    /// `rev()` ব্যবহার করার পরে, একটি পুনরাবৃত্তি পরিবর্তে ডান থেকে বামে পুনরাবৃত্তি করবে।
    ///
    /// এটি কেবল তখনই সম্ভব যখন পুনরুক্তিটির কোনও শেষ থাকে, সুতরাং `rev()` কেবলমাত্র [`DoubleEidedIterator`] এর উপর কাজ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// জোড়াগুলির একটি পুনরাবৃত্তিকে পাত্রে এক জোড়া রূপান্তর করে।
    ///
    /// `unzip()` জোড়াগুলির পুরো পুনরুক্তি গ্রহণ করে, দুটি সংগ্রহ তৈরি করে: একটি জোড়গুলির বাম উপাদান থেকে এবং একটি সঠিক উপাদান থেকে।
    ///
    ///
    /// এই ফাংশনটি এক অর্থে [`zip`] এর বিপরীত।
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// একটি পুনরুক্তি তৈরি করে যা এর সমস্ত উপাদানকে অনুলিপি করে।
    ///
    /// `&T` এর উপরে আপনার যখন একটি পুনরাবৃত্তি রয়েছে তখন এটি কার্যকর হয় তবে আপনার `T` এর চেয়ে বেশি একটি পুনরাবৃত্তির প্রয়োজন।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // অনুলিপি করা .map(|&x| x) এর সমান
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// একটি পুনরুক্তি তৈরি করে যা [`ক্লোন`] এর সমস্ত উপাদান।
    ///
    /// `&T` এর উপরে আপনার যখন একটি পুনরাবৃত্তি রয়েছে তখন এটি কার্যকর হয় তবে আপনার `T` এর চেয়ে বেশি একটি পুনরাবৃত্তির প্রয়োজন।
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // ক্লোন করাটি পূর্ণসংখ্যার জন্য .map(|&x| x) এর সমান
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// একটি পুনরাবৃত্তি অবিরাম পুনরাবৃত্তি।
    ///
    /// [`None`] এ থামার পরিবর্তে পুনরাবৃত্তিটি শুরু থেকে আবার শুরু হবে।আবার পুনরাবৃত্তি করার পরে, এটি আবার শুরুতে শুরু হবে।এবং আবার.
    /// এবং আবার.
    /// Forever.
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// একটি পুনরাবৃত্তির উপাদানগুলির যোগফল।
    ///
    /// প্রতিটি উপাদান নেয়, তাদের একসাথে যুক্ত করে এবং ফলাফলটি প্রদান করে।
    ///
    /// একটি খালি পুনরাবৃত্তকারী টাইপের শূন্য মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// `sum()`-এ কল করার সময় এবং কোনও আদিম পূর্ণসংখ্যার প্রকার ফিরে পাওয়া যায়, যদি গণনা ওভারফ্লো এবং ডিবাগের দৃ as়তা সক্ষম হয় তবে এই পদ্ধতিটি panic করবে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// সমস্ত উপাদানকে গুণিত করে পুরো পুনরাবৃত্তকারীকে পরিমাপ করে
    ///
    /// একটি খালি পুনরাবৃত্তকারী টাইপের এক মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// `product()`-এ কল করার সময় এবং কোনও আদিম পূর্ণসংখ্যার প্রকার ফিরে পাওয়া যায়, যদি গণনা ওভারফ্লো এবং ডিবাগের দৃ enabled়তা সক্ষম করা থাকে তবে পদ্ধতিটি panic করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) এই [`Iterator`] এর উপাদানগুলির সাথে অন্যগুলির তুলনা করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) নির্দিষ্ট করা তুলনা ফাংশনটির সাথে এই এক্স 100 এক্সের উপাদানগুলির সাথে অন্যগুলির সাথে তুলনা করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) এই [`Iterator`] এর উপাদানগুলির সাথে অন্যগুলির তুলনা করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) নির্দিষ্ট করা তুলনা ফাংশনটির সাথে এই এক্স 100 এক্সের উপাদানগুলির সাথে অন্যগুলির সাথে তুলনা করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// এই [`Iterator`] এর উপাদানগুলি অন্যগুলির সাথে সমান কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// নির্দিষ্ট করা সমতা ফাংশনের ক্ষেত্রে এই [`Iterator`] এর উপাদানগুলি অন্যগুলির সাথে সমান কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// এই [`Iterator`] এর উপাদানগুলি অন্যগুলির সাথে অসম কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// এই [`Iterator`] এর উপাদানগুলি অন্যগুলির তুলনায় [lexicographically](Ord#lexicographical-comparison) কম কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// এই [`Iterator`] এর উপাদানগুলি [lexicographically](Ord#lexicographical-comparison) এর চেয়ে কম বা অন্যটির তুলনায় সমান কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// এই [`Iterator`] এর উপাদানগুলি অন্যগুলির তুলনায় [lexicographically](Ord#lexicographical-comparison) বেশি কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// এই [`Iterator`] এর উপাদানগুলি অন্যগুলির তুলনায় [lexicographically](Ord#lexicographical-comparison) বৃহত্তর বা সমান কিনা তা নির্ধারণ করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// এই পুনরুক্তরের উপাদানগুলি সাজানো হয়েছে কিনা তা পরীক্ষা করে দেখুন।
    ///
    /// এটি হ'ল প্রতিটি উপাদান `a` এবং এর নিম্নলিখিত উপাদান `b` এর জন্য, `a <= b` অবশ্যই রাখা উচিত।যদি পুনরুক্তিটি শূন্য বা একটি উপাদান দেয় তবে `true` ফিরে আসে।
    ///
    /// দ্রষ্টব্য যে `Self::Item` যদি কেবলমাত্র `PartialOrd` হয় তবে `Ord` নয়, উপরোক্ত সংজ্ঞাটি সূচিত করে যে এই ক্রিয়াকলাপটি যদি কোনও দুটি পরপর আইটেমের তুলনা না করে থাকে তবে এই ফাংশনটি `PartialOrd` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// প্রদত্ত তুলনাকারী ফাংশনটি ব্যবহার করে এই পুনরুক্তারের উপাদানগুলি সাজানো হয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// `PartialOrd::partial_cmp` ব্যবহার করার পরিবর্তে, এই ফাংশনটি দুটি উপাদানের ক্রম নির্ধারণ করতে প্রদত্ত `compare` ফাংশনটি ব্যবহার করে।
    /// তা ছাড়া এটি [`is_sorted`] এর সমতুল্য;আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// প্রদত্ত কী এক্সট্রাকশন ফাংশনটি ব্যবহার করে এই পুনরুক্তারের উপাদানগুলি সাজানো হয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// পুনরাবৃত্তির উপাদানগুলি সরাসরি তুলনা করার পরিবর্তে, এই ফাংশনটি `f` দ্বারা নির্ধারিত উপাদানগুলির কীগুলির সাথে তুলনা করে।
    /// তা ছাড়া এটি [`is_sorted`] এর সমতুল্য;আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// এক্স 100 এক্স দেখুন
    // পদ্ধতির রেজোলিউশনে নামের সংঘর্ষগুলি এড়ানোর জন্য এই অস্বাভাবিক নামটি দেখুন দেখুন #76479।
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}