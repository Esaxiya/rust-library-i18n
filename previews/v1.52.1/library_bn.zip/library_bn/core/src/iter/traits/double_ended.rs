use crate::ops::{ControlFlow, Try};

/// উভয় প্রান্ত থেকে উপাদান উত্পন্ন করতে সক্ষম একটি পুনরাবৃত্তকারী।
///
/// এক্স 001 এক্স প্রয়োগ করে এমন কিছুতে [`Iterator`] প্রয়োগ করে এমন কিছু ক্ষেত্রে একটি অতিরিক্ত ক্ষমতা রয়েছে: পিছন থেকে পাশাপাশি সামনের দিক থেকে `আইটেমগুলিও নেওয়ার ক্ষমতা।
///
///
/// এটি লক্ষ্য করা গুরুত্বপূর্ণ যে পিছনে এবং উভয়ই একই পরিসরে কাজ করে এবং ক্রস করবেন না: মাঝখানে মিলিত হওয়ার পরে পুনরাবৃত্তি শেষ হয়।
///
/// এক্স01 এক্স প্রোটোকলের অনুরূপ ফ্যাশনে, একবার কোনও এক্স 2 এক্স এক্স 100 এক্স থেকে এক্স03 এক্স ফিরিয়ে দেয়, আবার কল করে আবারও এক্স04 এক্স ফিরে আসতে পারে বা নাও পারে।
/// [`next()`] এবং [`next_back()`] এই উদ্দেশ্যে বিনিময়যোগ্য।
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// পুনরাবৃত্তির শেষ থেকে একটি উপাদান সরিয়ে দেয় এবং প্রদান করে।
    ///
    /// যখন আর কোনও উপাদান নেই তখন `None` প্রদান করে।
    ///
    /// [trait-level] ডক্সে আরও বিশদ রয়েছে।
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEenderIterator` এর পদ্ধতি দ্বারা উত্পাদিত উপাদানগুলি [`Iterator`] এর পদ্ধতি দ্বারা উপার্জন করা থেকে পৃথক হতে পারে:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` উপাদান দ্বারা পিছন থেকে পুনরুক্তি অগ্রসর করে।
    ///
    /// `advance_back_by` [`advance_by`] এর বিপরীত সংস্করণ।এই পদ্ধতিটি [`next_back`] সম্মুখীন হওয়ার পূর্ব পর্যন্ত [`next_back`] ফোনটিকে [`next_back`] পর্যন্ত কল করে `n` উপাদানগুলি আগ্রহের সাথে পিছনে থেকে শুরু করবে।
    ///
    /// `advance_back_by(n)` এক্সট্রেটর `n` উপাদান দ্বারা সফলভাবে অগ্রসর হলে [`Ok(())`], অথবা [`None`] সম্মুখীন হলে [`Err(k)`] ফিরে আসবে, যেখানে `k` উপাদানগুলির সংখ্যা শেষ হওয়ার আগেই ইটারেটরটি উন্নত হয়েছে এমন সংখ্যার সংখ্যা রয়েছে (উদাঃ
    /// পুনরাবৃত্তির দৈর্ঘ্য)।
    /// দ্রষ্টব্য যে `k` সর্বদা `n` এর চেয়ে কম থাকে।
    ///
    /// `advance_back_by(0)` কল করা কোনও উপাদান গ্রাস করে না এবং সর্বদা [`Ok(())`] প্রদান করে।
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // কেবলমাত্র `&3` এড়িয়ে গেছে
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// পুনরাবৃত্তির শেষে থেকে element n` তম উপাদানটি প্রদান করে।
    ///
    /// এটি মূলত [`Iterator::nth()`] এর বিপরীত সংস্করণ।
    /// যদিও বেশিরভাগ সূচক অপারেশনগুলির মতো, গণনাটি শূন্য থেকে শুরু হয়, সুতরাং `nth_back(0)` শেষ থেকে প্রথম মানটি, দ্বিতীয়টি `nth_back(1)` প্রদান করে।
    ///
    ///
    /// মনে রাখবেন যে ফিরে আসা উপাদান সহ শেষ এবং ফিরে আসা উপাদানগুলির মধ্যে থাকা সমস্ত উপাদান গ্রাস করা হবে।
    /// এর অর্থ হ'ল একই পুনরুক্তিতে একাধিকবার `nth_back(0)` কল করা বিভিন্ন উপাদানকে ফিরে আসবে।
    ///
    /// `nth_back()` `n` যদি পুনরাবৃত্তির দৈর্ঘ্যের চেয়ে বড় বা সমান হয় তবে [`None`] প্রদান করবে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// একাধিকবার `nth_back()` কল করা পুনরুক্তিকারীকে রিওয়াইন্ড করে না:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` এর চেয়ে কম উপাদান থাকলে `None` রিটার্নিং:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// এটি [`Iterator::try_fold()`] এর বিপরীত সংস্করণ: এটি পুনরুক্তির পিছন থেকে শুরু হওয়া উপাদানগুলিতে লাগে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // এটি সংক্ষিপ্ত প্রচারিত হওয়ার কারণে, বাকি উপাদানগুলি এখনও পুনরুক্তকারীর মাধ্যমে উপলব্ধ।
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// একটি পুনরুক্তি পদ্ধতি যা পিছন থেকে শুরু করে একক, চূড়ান্ত মানগুলিতে পুনরাবৃত্তির উপাদানকে হ্রাস করে।
    ///
    /// এটি [`Iterator::fold()`] এর বিপরীত সংস্করণ: এটি পুনরুক্তির পিছন থেকে শুরু হওয়া উপাদানগুলিতে লাগে।
    ///
    /// `rfold()` দুটি আর্গুমেন্ট নেয়: একটি প্রাথমিক মান এবং দুটি আর্গুমেন্টের সাথে বন্ধ: একটি এক্স 100 এক্স এবং একটি উপাদান।
    /// ক্লোজারটি পরবর্তী পুনরাবৃত্তির জন্য সংগ্রহকারীর থাকা উচিত এমন মানটি ফিরিয়ে দেয়।
    ///
    /// প্রারম্ভিক মান হ'ল প্রথম কলটিতে সংগ্রহকারীর মান।
    ///
    /// পুনরুক্তরের প্রতিটি উপাদানগুলিতে এই ক্লোজার প্রয়োগের পরে, `rfold()` সঞ্চয়েরকে ফেরত দেয়।
    ///
    /// এই অপারেশনটিকে কখনও কখনও 'reduce' বা 'inject' বলা হয়।
    ///
    /// আপনি যখনই কোনও কিছুর সংকলন পাবেন তখন ভাঁজ কার্যকর হয় এবং এ থেকে একটি একক মান উত্পাদন করতে চান।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // এ এর সমস্ত উপাদানের যোগফল
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// এই উদাহরণটি একটি স্ট্রিং তৈরি করে, প্রাথমিক মান দিয়ে শুরু করে এবং প্রতিটি উপাদানকে পিছন থেকে সামনে অবধি চালিয়ে যাওয়া:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// পিছন থেকে একটি পুনরাবৃত্তির উপাদানটির সন্ধান করে যা কোনও ভবিষ্যদ্বাণীকে সন্তুষ্ট করে।
    ///
    /// `rfind()` `true` বা `false` প্রদান করে এমন একটি ক্লোজেশন নেয়।
    /// এটি শেষে থেকে শুরু করে পুনরাবৃত্তির প্রতিটি উপাদানগুলিতে এই বন্ধকরণটি প্রয়োগ করে এবং যদি তাদের মধ্যে কেউ যদি `true` ফেরত দেয় তবে `rfind()` [`Some(element)`] প্রদান করে।
    /// যদি তারা সকলে `false` ফেরত দেয় তবে এটি [`None`] প্রদান করে।
    ///
    /// `rfind()` শর্ট সার্কিট হয়;অন্য কথায়, ক্লোজারটি `true` ফেরার সাথে সাথে এটি প্রক্রিয়া বন্ধ করবে stop
    ///
    /// যেহেতু `rfind()` একটি রেফারেন্স নিয়েছে এবং অনেকগুলি পুনরাবৃত্তি রেফারেন্সগুলি দিয়ে পুনরাবৃত্তি করে, এটি সম্ভবত বিভ্রান্তিকর পরিস্থিতির দিকে নিয়ে যায় যেখানে যুক্তিটি দ্বৈত রেফারেন্স।
    ///
    /// আপনি `&&x` এর সাহায্যে নীচের উদাহরণগুলিতে এই প্রভাবটি দেখতে পারেন।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// প্রথম `true` এ থামছে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // আরও উপাদান রয়েছে বলে আমরা এখনও `iter` ব্যবহার করতে পারি।
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}