use crate::iter;
use crate::num::Wrapping;

/// Trait এমন একটি ধরণের প্রতিনিধিত্ব করতে যা একটি পুনরুক্তি যোগ করে তৈরি করা যায়।
///
/// এই trait পুনরাবৃত্তকারীগুলিতে [`sum()`] পদ্ধতিটি প্রয়োগ করতে ব্যবহৃত হয়।
/// trait প্রয়োগকারী প্রকারগুলি [`sum()`] পদ্ধতি দ্বারা উত্পন্ন করা যেতে পারে।
/// এক্স01 এক্স এর মতো এই জেড 0 ট্রাইট0 জেডকে খুব কমই সরাসরি ডাকা উচিত এবং এর পরিবর্তে এক্স00 এক্স এর মাধ্যমে যোগাযোগ করা উচিত।
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// পদ্ধতি যা একটি পুনরুক্তি নেয় এবং "summing up" আইটেমগুলির মাধ্যমে উপাদানগুলি থেকে `Self` উত্পন্ন করে।
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait এমন একটি প্রকারের প্রতিনিধিত্ব করতে যা কোনও পুনরুক্তরের উপাদানকে গুণিত করে তৈরি করা যায়।
///
/// এই trait পুনরাবৃত্তকারীগুলিতে [`product()`] পদ্ধতিটি প্রয়োগ করতে ব্যবহৃত হয়।
/// trait প্রয়োগকারী প্রকারগুলি [`product()`] পদ্ধতি দ্বারা উত্পন্ন করা যেতে পারে।
/// এক্স01 এক্স এর মতো এই জেড 0 ট্রাইট0 জেডকে খুব কমই সরাসরি ডাকা উচিত এবং এর পরিবর্তে এক্স00 এক্স এর মাধ্যমে যোগাযোগ করা উচিত।
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// পদ্ধতি যা একটি পুনরুক্তি নেয় এবং আইটেমগুলি গুণিত করে উপাদান থেকে `Self` উত্পন্ন করে।
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] এ প্রতিটি উপাদান নেয়: এটি যদি [`Err`] হয় তবে আর কোনও উপাদান নেওয়া হবে না এবং [`Err`] ফেরত দেওয়া হবে।
    /// যদি কোনও [`Err`] না ঘটে, সমস্ত উপাদানের যোগফল ফিরে আসে।
    ///
    /// # Examples
    ///
    /// এটি একটি vector এর প্রতিটি পূর্ণসংখ্যার যোগফলকে যোগ করে, কোনও নেতিবাচক উপাদানের সম্মুখীন হলে যোগফলটিকে প্রত্যাখ্যান করে:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] এ প্রতিটি উপাদান নেয়: এটি যদি [`Err`] হয় তবে আর কোনও উপাদান নেওয়া হবে না এবং [`Err`] ফেরত দেওয়া হবে।
    /// কোনও [`Err`] না হওয়া উচিত, সমস্ত উপাদানগুলির পণ্যটি ফিরে আসে।
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// প্রতিটি উপাদানকে [`Iterator`] এ নিয়ে যায়: এটি যদি [`None`] হয় তবে আর কোনও উপাদান নেওয়া হয় না এবং এক্স0 2 এক্স ফিরে আসে।
    /// যদি কোনও [`None`] না ঘটে, সমস্ত উপাদানের যোগফল ফিরে আসে।
    ///
    /// # Examples
    ///
    /// এটি একটি vector স্ট্রিংয়ের 'a' অক্ষরের অবস্থানটি যোগ করে, যদি কোনও শব্দে 'a' অক্ষর না থাকে তবে ক্রিয়াটি `None` প্রদান করে:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// প্রতিটি উপাদানকে [`Iterator`] এ নিয়ে যায়: এটি যদি [`None`] হয় তবে আর কোনও উপাদান নেওয়া হয় না এবং এক্স0 2 এক্স ফিরে আসে।
    /// কোনও [`None`] না হওয়া উচিত, সমস্ত উপাদানগুলির পণ্যটি ফিরে আসে।
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}