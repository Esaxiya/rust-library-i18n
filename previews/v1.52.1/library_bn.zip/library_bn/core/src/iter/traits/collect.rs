/// একটি [`Iterator`] থেকে রূপান্তর।
///
/// কোনও প্রকারের জন্য `FromIterator` প্রয়োগ করে আপনি এটি নির্ধারণ করেন যে এটি কীভাবে পুনরুক্তিকারী থেকে তৈরি করা হবে।
/// এটি এমন ধরণের জন্য সাধারণ যা কোনও ধরণের সংকলন বর্ণনা করে।
///
/// [`FromIterator::from_iter()`] খুব কমই স্পষ্টভাবে বলা হয়, এবং এর পরিবর্তে [`Iterator::collect()`] পদ্ধতিতে ব্যবহৃত হয়।
///
/// আরও উদাহরণের জন্য [`Iterator::collect()`]'s ডকুমেন্টেশন দেখুন।
///
/// আরো দেখুন: [`IntoIterator`].
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// স্পষ্টভাবে `FromIterator` ব্যবহার করতে [`Iterator::collect()`] ব্যবহার করা:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// আপনার ধরণের জন্য `FromIterator` বাস্তবায়ন করা হচ্ছে:
///
/// ```
/// use std::iter::FromIterator;
///
/// // একটি নমুনা সংগ্রহ, এটি ভেকের উপরে কেবল একটি মোড়ক<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // আসুন এটির কিছু পদ্ধতি দিন যাতে আমরা একটি তৈরি করতে পারি এবং এতে জিনিস যুক্ত করতে পারি।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // এবং আমরা fromIterator বাস্তবায়ন করব
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // এখন আমরা একটি নতুন পুনরুক্তি করতে পারি ...
/// let iter = (0..5).into_iter();
///
/// // ... এবং এটি থেকে একটি আমার সংগ্রহ তৈরি করুন
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // কাজগুলিও সংগ্রহ করুন!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// একটি পুনরুক্তিকারী থেকে একটি মান তৈরি করে।
    ///
    /// আরও জন্য [module-level documentation] দেখুন।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// একটি [`Iterator`] এ রূপান্তর।
///
/// কোনও প্রকারের জন্য `IntoIterator` প্রয়োগ করে আপনি এটি নির্ধারণ করেন যে এটি কীভাবে পুনরুক্তিতে রূপান্তরিত হবে।
/// এটি এমন ধরণের জন্য সাধারণ যা কোনও ধরণের সংকলন বর্ণনা করে।
///
/// `IntoIterator` প্রয়োগের একটি সুবিধা হ'ল আপনার ধরণটি [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) হবে।
///
///
/// আরো দেখুন: [`FromIterator`].
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// আপনার ধরণের জন্য `IntoIterator` প্রয়োগ করা হচ্ছে:
///
/// ```
/// // একটি নমুনা সংগ্রহ, এটি ভেকের উপরে কেবল একটি মোড়ক<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // আসুন এটির কিছু পদ্ধতি দিন যাতে আমরা একটি তৈরি করতে পারি এবং এতে জিনিস যুক্ত করতে পারি।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // এবং আমরা ইন্টিওটিরেটর প্রয়োগ করব
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // এখন আমরা একটি নতুন সংগ্রহ করতে পারি ...
/// let mut c = MyCollection::new();
///
/// // ... এটিতে কিছু জিনিস যুক্ত করুন ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... এবং তারপরে এটিকে একটি আইট্রেটারে পরিণত করুন:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` কে trait bound হিসাবে ব্যবহার করা সাধারণ।এটি ইনপুট সংগ্রহের ধরণের পরিবর্তন করতে দেয়, যতক্ষণ না এটি এখনও পুনরাবৃত্তিকারী।
/// অতিরিক্ত সীমাবদ্ধতা সীমাবদ্ধ করে নির্দিষ্ট করা যেতে পারে
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// উপাদানগুলির ধরণটি পুনরাবৃত্তি হচ্ছে।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// কোন ধরণের পুনরাবৃত্তিকে আমরা এটিকে রূপান্তর করছি?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// একটি মান থেকে একটি পুনরুক্তি তৈরি করে।
    ///
    /// আরও জন্য [module-level documentation] দেখুন।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// একটি পুনরাবৃত্তির সামগ্রী সহ একটি সংগ্রহ প্রসারিত করুন।
///
/// Iteters মান একটি সিরিজ উত্পাদন, এবং সংগ্রহ এছাড়াও মান একটি সিরিজ হিসাবে ভাবা যেতে পারে।
/// `Extend` trait এই ব্যবধানটি সরিয়ে দেয়, আপনাকে সেই পুনরাবৃত্তির সামগ্রীগুলি অন্তর্ভুক্ত করে একটি সংগ্রহ প্রসারিত করতে দেয়।
/// ইতিমধ্যে বিদ্যমান কী সহ কোনও সংগ্রহ প্রসারিত করার সময়, সেই প্রবেশটি আপডেট করা হয় বা সমান কীগুলির সাথে একাধিক এন্ট্রি দেওয়ার অনুমতি সংগ্রহের ক্ষেত্রে, সেই প্রবেশটি সন্নিবেশ করা হয়।
///
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// // আপনি কিছু অক্ষর সহ একটি স্ট্রিং প্রসারিত করতে পারেন:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// এক্স 100 এক্স প্রয়োগ করা হচ্ছে:
///
/// ```
/// // একটি নমুনা সংগ্রহ, এটি ভেকের উপরে কেবল একটি মোড়ক<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // আসুন এটির কিছু পদ্ধতি দিন যাতে আমরা একটি তৈরি করতে পারি এবং এতে জিনিস যুক্ত করতে পারি।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // যেহেতু মাই কালেকশনে আই 32 এর তালিকা রয়েছে, তাই আমরা এক্স 100 এক্সের জন্য এক্সটেন্ড প্রয়োগ করি
/// impl Extend<i32> for MyCollection {
///
///     // এটি কংক্রিটের ধরণের স্বাক্ষরের সাথে কিছুটা সহজ: আমরা এমন কোনও কিছুতে প্রসারণ কল করতে পারি যা একটি আইট্রেটারে পরিণত হতে পারে যা আমাদের i32s দেয়।
///     // কারণ মাই কালেকশনে রাখার জন্য আমাদের আইপিএস দরকার।
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // বাস্তবায়নটি খুব সোজা: আয়রটারের মধ্য দিয়ে লুপ করুন এবং প্রতিটি উপাদানকে নিজের কাছে এক্স 100 এক্স করুন।
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // আসুন আরও তিনটি সংখ্যার সাথে আমাদের সংগ্রহ প্রসারিত করুন
/// c.extend(vec![1, 2, 3]);
///
/// // আমরা এই উপাদানগুলি শেষ পর্যন্ত যুক্ত করেছি
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// একটি পুনরাবৃত্তির সামগ্রী সহ একটি সংগ্রহ প্রসারিত করে।
    ///
    /// যেহেতু এই trait এর জন্য এটি একমাত্র প্রয়োজনীয় পদ্ধতি, তাই [trait-level] ডক্সে আরও বিশদ রয়েছে।
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // আপনি কিছু অক্ষর সহ একটি স্ট্রিং প্রসারিত করতে পারেন:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ঠিক একটি উপাদান সহ একটি সংগ্রহ প্রসারিত করে।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// অতিরিক্ত সংখ্যার প্রদত্ত সংখ্যার জন্য সংগ্রহের মধ্যে ক্ষমতা সংরক্ষণ করে।
    ///
    /// ডিফল্ট বাস্তবায়ন কিছুই করে না।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}