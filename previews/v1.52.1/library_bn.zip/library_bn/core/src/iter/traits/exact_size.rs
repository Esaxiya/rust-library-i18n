/// একটি পুনরাবৃত্তি যা তার সঠিক দৈর্ঘ্য জানে।
///
/// অনেক [`Iterator`] s তারা জানেন না যে তারা কতবার পুনরাবৃত্তি করতে পারে তবে কেউ কেউ তা করে।
/// যদি কোনও পুনরাবৃত্তিকারী জানেন যে এটি কতবার পুনরাবৃত্তি করতে পারে তবে সেই তথ্যে অ্যাক্সেস সরবরাহ করা কার্যকর হতে পারে।
/// উদাহরণস্বরূপ, আপনি যদি পিছনের দিকে পুনরাবৃত্তি করতে চান তবে একটি ভাল শুরুটি শেষ কোথায় তা জানা উচিত।
///
/// একটি `ExactSizeIterator` বাস্তবায়ন করার সময়, আপনাকে অবশ্যই [`Iterator`] বাস্তবায়ন করতে হবে।
/// এটি করার সময়, [`Iterator::size_hint`]*এর বাস্তবায়ন অবশ্যই* পুনরাবৃত্তির সঠিক আকারটি প্রদান করবে।
///
/// [`len`] পদ্ধতিটির একটি ডিফল্ট বাস্তবায়ন রয়েছে, সুতরাং আপনার সাধারণত এটি প্রয়োগ করা উচিত নয়।
/// তবে, আপনি ডিফল্টের চেয়ে আরও বেশি পারফরম্যান্ট বাস্তবায়ন সরবরাহ করতে সক্ষম হতে পারেন, সুতরাং এই ক্ষেত্রে এটিকে ওভাররাইড করা অর্থবোধ করে।
///
///
/// মনে রাখবেন যে এই জেড 0 ট্রাইট0 জেডটি একটি নিরাপদ জেডট্রেট0 জেড এবং যেমন *না* এবং * * গ্যারান্টি দিতে পারে না যে প্রত্যাবর্তিত দৈর্ঘ্যটি সঠিক।
/// এর অর্থ `unsafe` কোড **অবশ্যই**[`Iterator::size_hint`] এর নির্ভুলতার উপর নির্ভর করতে পারে না।
/// অস্থির এবং অনিরাপদ [`TrustedLen`](super::marker::TrustedLen) trait এই অতিরিক্ত গ্যারান্টি দেয়।
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// // একটি সীমাবদ্ধ পরিসীমা ঠিক কতবার এটি পুনরাবৃত্তি হবে তা জানে
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] এ আমরা একটি [`Iterator`] প্রয়োগ করেছি, `Counter`.
/// এর জন্য এটিও `ExactSizeIterator` বাস্তবায়ন করুন:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // আমরা সহজেই পুনরাবৃত্তির অবশিষ্ট সংখ্যা গণনা করতে পারি।
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // এবং এখন আমরা এটি ব্যবহার করতে পারি!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// পুনরাবৃত্তির সঠিক দৈর্ঘ্য প্রদান করে।
    ///
    /// বাস্তবায়নটি নিশ্চিত করে যে পুনরাবৃত্তিটি [`None`] ফেরার আগে [`Some(T)`] মান আরও একবার `len()` ফিরে আসবে।
    ///
    /// এই পদ্ধতির একটি ডিফল্ট বাস্তবায়ন রয়েছে, সুতরাং আপনার সাধারণত এটি সরাসরি প্রয়োগ করা উচিত নয়।
    /// তবে, আপনি যদি আরও দক্ষ বাস্তবায়ন সরবরাহ করতে পারেন তবে আপনি এটি করতে পারেন।
    /// উদাহরণের জন্য [trait-level] ডক্স দেখুন।
    ///
    /// এই ফাংশনটির [`Iterator::size_hint`] ফাংশনের মতোই সুরক্ষার গ্যারান্টি রয়েছে।
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // একটি সীমাবদ্ধ পরিসীমা ঠিক কতবার এটি পুনরাবৃত্তি হবে তা জানে
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: এই দাবিটি অত্যধিক প্রতিরক্ষামূলক তবে এটি আক্রমণকারীটিকে পরীক্ষা করে
        // trait দ্বারা গ্যারান্টিযুক্ত।
        // এই trait যদি rust-অভ্যন্তরীণ হয় তবে আমরা ডিবাগ_সেসার্টটি ব্যবহার করতে পারি;assert_eq!সমস্ত Rust ব্যবহারকারীর প্রয়োগগুলিও চেক করবে।
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// পুনরুক্তি খালি থাকলে `true` প্রদান করে।
    ///
    /// এই পদ্ধতির [`ExactSizeIterator::len()`] ব্যবহার করে একটি ডিফল্ট বাস্তবায়ন রয়েছে, সুতরাং আপনার নিজের এটি প্রয়োগ করার দরকার নেই।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}