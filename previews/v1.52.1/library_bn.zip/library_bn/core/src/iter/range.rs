use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// যে বিষয়গুলিতে *উত্তরসূরি* এবং *পূর্বসূরি* ক্রিয়াকলাপের ধারণা রয়েছে।
///
/// *উত্তরাধিকারী* অপারেশন মানগুলির তুলনায় অগ্রসর হয় যা আরও বেশি তুলনা করে।
/// *পূর্বসূরী* অপারেশন এমন মানগুলির দিকে অগ্রসর হয় যা কম তুলনা করে।
///
/// # Safety
///
/// এই trait `unsafe`, কারণ এটি `unsafe trait TrustedLen` বাস্তবায়নগুলির সুরক্ষার জন্য অবশ্যই কার্যকর করা উচিত এবং এই trait ব্যবহারের ফলাফল অন্যথায় `unsafe` কোড দ্বারা বিশ্বাসযোগ্য হতে পারে সঠিকভাবে এবং তালিকাভুক্ত বাধ্যবাধকতাগুলি পূরণ করতে।
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` থেকে `end` এ পেতে প্রয়োজনীয় *উত্তরসূরি* পদক্ষেপের সংখ্যা প্রদান করে।
    ///
    /// যদি পদক্ষেপের সংখ্যাটি `usize` উপচে পড়বে (বা অসীম বা `end` কখনই পৌঁছতে না পারে) `None` প্রদান করে।
    ///
    ///
    /// # Invariants
    ///
    /// যে কোনও `a`, `b`, এবং `n` এর জন্য:
    ///
    /// * `steps_between(&a, &b) == Some(n)` যদি এবং কেবলমাত্র `Step::forward_checked(&a, n) == Some(b)` হয়
    /// * `steps_between(&a, &b) == Some(n)` যদি এবং কেবলমাত্র `Step::backward_checked(&a, n) == Some(a)` হয়
    /// * `steps_between(&a, &b) == Some(n)` শুধুমাত্র যদি `a <= b`
    ///   * আনুষঙ্গিক: `steps_between(&a, &b) == Some(0)` যদি এবং কেবলমাত্র `a == b` হয়
    ///   * দ্রষ্টব্য যে `a <= b` X02 এক্সকে `steps_between(&a, &b) != None` বোঝায়;
    ///     এটি তখন ঘটে যখন `b` এ যাওয়ার জন্য `usize::MAX` ধাপের বেশি প্রয়োজন
    /// * `steps_between(&a, &b) == None` যদি এক্স 100 এক্স
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` বারের *উত্তরসূরি* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// এটি যদি `Self` দ্বারা সমর্থিত মানের পরিসীমাকে উপচে ফেলে, তবে `None` প্রদান করে।
    ///
    /// # Invariants
    ///
    /// যে কোনও `a`, `n`, এবং `m` এর জন্য:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// যে কোনও `a`, `n`, এবং `m` এর জন্য যেখানে `n + m` ওভারফ্লো হয় না:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// যে কোনও `a` এবং `n` এর জন্য:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` বারের *উত্তরসূরি* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// এটি যদি `Self` দ্বারা সমর্থিত মানের পরিসীমাকে উপচে ফেলে তবে এই ফাংশনটি panic, মোড়ানো, বা স্যাচুর করার অনুমতি রয়েছে।
    ///
    /// প্রস্তাবিত আচরণটি panic এর দিকে হয় যখন ডিবাগের দৃser়তা সক্ষম করা থাকে এবং অন্যভাবে মোড়ানো বা পরিপূর্ণ করা যায়।
    ///
    /// অনিরাপদ কোডটি ওভারফ্লোর পরে আচরণের নির্ভুলতার উপর নির্ভর করা উচিত নয়।
    ///
    /// # Invariants
    ///
    /// যে কোনও `a`, `n`, এবং `m` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// যে কোনও `a` এবং `n` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` বারের *উত্তরসূরি* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// # Safety
    ///
    /// এই অপারেশনটি `Self` দ্বারা সমর্থিত মানের সীমাটি ছাড়িয়ে যাওয়ার জন্য এটি অপরিবর্তিত আচরণ।
    /// আপনি যদি গ্যারান্টি দিতে না পারেন যে এটি উপচে পড়বে না, পরিবর্তে `forward` বা `forward_checked` ব্যবহার করুন।
    ///
    /// # Invariants
    ///
    /// যে কোনও এক্স 100 এক্সের জন্য:
    ///
    /// * যদি `b` এর মতো `b > a` উপস্থিত থাকে তবে এটি `Step::forward_unchecked(a, 1)` কল করা নিরাপদ
    /// * যদি `b`, `n` এর মতো `steps_between(&a, &b) == Some(n)` বিদ্যমান থাকে তবে যে কোনও `m <= n` এর জন্য `Step::forward_unchecked(a, m)` কল করা নিরাপদ।
    ///
    ///
    /// যে কোনও `a` এবং `n` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` এর সমতুল্য
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` বারের *পূর্বসূরী* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// এটি যদি `Self` দ্বারা সমর্থিত মানের পরিসীমাকে উপচে ফেলে, তবে `None` প্রদান করে।
    ///
    /// # Invariants
    ///
    /// যে কোনও `a`, `n`, এবং `m` এর জন্য:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// যে কোনও `a` এবং `n` এর জন্য:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` বারের *পূর্বসূরী* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// এটি যদি `Self` দ্বারা সমর্থিত মানের পরিসীমাকে উপচে ফেলে তবে এই ফাংশনটি panic, মোড়ানো, বা স্যাচুর করার অনুমতি রয়েছে।
    ///
    /// প্রস্তাবিত আচরণটি panic এর দিকে হয় যখন ডিবাগের দৃser়তা সক্ষম করা থাকে এবং অন্যভাবে মোড়ানো বা পরিপূর্ণ করা যায়।
    ///
    /// অনিরাপদ কোডটি ওভারফ্লোর পরে আচরণের নির্ভুলতার উপর নির্ভর করা উচিত নয়।
    ///
    /// # Invariants
    ///
    /// যে কোনও `a`, `n`, এবং `m` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// যে কোনও `a` এবং `n` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` বারের *পূর্বসূরী* গ্রহণ করে প্রাপ্ত মানটি প্রদান করে।
    ///
    /// # Safety
    ///
    /// এই অপারেশনটি `Self` দ্বারা সমর্থিত মানের সীমাটি ছাড়িয়ে যাওয়ার জন্য এটি অপরিবর্তিত আচরণ।
    /// আপনি যদি গ্যারান্টি দিতে না পারেন যে এটি উপচে পড়বে না, পরিবর্তে `backward` বা `backward_checked` ব্যবহার করুন।
    ///
    /// # Invariants
    ///
    /// যে কোনও এক্স 100 এক্সের জন্য:
    ///
    /// * যদি `b` এর মতো `b < a` উপস্থিত থাকে তবে এটি `Step::backward_unchecked(a, 1)` কল করা নিরাপদ
    /// * যদি `b`, `n` এর মতো `steps_between(&b, &a) == Some(n)` বিদ্যমান থাকে তবে যে কোনও `m <= n` এর জন্য `Step::backward_unchecked(a, m)` কল করা নিরাপদ।
    ///
    ///
    /// যে কোনও `a` এবং `n` এর জন্য, যেখানে কোনও ওভারফ্লো হয় না:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` এর সমতুল্য
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// এগুলি এখনও ম্যাক্রো-উত্পাদিত কারণ পূর্ণসংখ্যার লিটারাল বিভিন্ন ধরণের সমাধান করে।
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // নিরাপত্তা: কলকারীকে গ্যারান্টি দিতে হবে যে `start + n` ওভারফ্লো হয় না।
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // নিরাপত্তা: কলকারীকে গ্যারান্টি দিতে হবে যে `start - n` ওভারফ্লো হয় না।
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ডিবাগ বিল্ডগুলিতে, ওভারফ্লোতে একটি panic ট্রিগার করুন।
            // এটি রিলিজ বিল্ডগুলিতে সম্পূর্ণরূপে অনুকূলিত হওয়া উচিত।
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // উদাহরণস্বরূপ অনুমতি দেওয়ার জন্য গণিতে মোড়ক করুন `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ডিবাগ বিল্ডগুলিতে, ওভারফ্লোতে একটি panic ট্রিগার করুন।
            // এটি রিলিজ বিল্ডগুলিতে সম্পূর্ণরূপে অনুকূলিত হওয়া উচিত।
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // উদাহরণস্বরূপ অনুমতি দেওয়ার জন্য গণিতে মোড়ক করুন `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // এটি $u_narrower <=usize এর উপর নির্ভর করে
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // যদি এন সীমার বাইরে থাকে তবে এক্স 100 এক্সও খুব বেশি
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // যদি এন সীমার বাইরে থাকে তবে এক্স 100 এক্সও খুব বেশি
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // এটি $i_narrower <=usize এর উপর নির্ভর করে
                        //
                        // আইসাইজে কাস্ট করা প্রস্থকে প্রসারিত করে তবে সাইনটি সংরক্ষণ করে।
                        // আইসাইজ স্পেসে র্যাপিং_সুব ব্যবহার করুন এবং আইসাইজের ব্যাপ্তির মধ্যে উপযুক্ত নয় এমন পার্থক্যটি গণনা করতে ইউজ করতে কাস্ট করতে পারেন।
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // মোছা `Step::forward(-120_i8, 200) == Some(80_i8)` এর মতো কেসগুলি পরিচালনা করে, যদিও 200 i8 এর সীমার বাইরে নয়।
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // সংযোজন উপচে পড়েছে
                            }
                        }
                        // যদি এন যেমন সীমার বাইরে থাকে
                        // u8, তবে এটি i8 এর পুরো ব্যাপ্তির চেয়ে বৃহত্তর তাই `any_i8 + n` অগত্যা i8 কে প্রবাহিত করবে।
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // মোছা `Step::forward(-120_i8, 200) == Some(80_i8)` এর মতো কেসগুলি পরিচালনা করে, যদিও 200 i8 এর সীমার বাইরে নয়।
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // বিয়োগফল উপচে পড়েছে
                            }
                        }
                        // যদি এন যেমন সীমার বাইরে থাকে
                        // u8, তবে এটি i8 এর পুরো ব্যাপ্তির চেয়ে বৃহত্তর তাই `any_i8 - n` অগত্যা i8 কে প্রবাহিত করবে।
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // পার্থক্য যদি খুব বড় হয় যেমন
                            // i128, কম বিট সহ ব্যবহারের পক্ষে এটি খুব বড় হবে।
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // সুরক্ষা: পুনর্বাসনা একটি বৈধ ইউনিকোড স্কেলার
            // (0x110000 এর নীচে এবং 0xD800..0xE000 এ নয়)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // সুরক্ষা: পুনর্বাসনা একটি বৈধ ইউনিকোড স্কেলার
        // (0x110000 এর নীচে এবং 0xD800..0xE000 এ নয়)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে এটি প্রবাহিত হবে না
        // একটি চরের জন্য মানগুলির ব্যাপ্তি।
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে এটি প্রবাহিত হবে না
            // একটি চরের জন্য মানগুলির ব্যাপ্তি।
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // নিরাপত্তা: পূর্ববর্তী চুক্তির কারণে এটি গ্যারান্টিযুক্ত
        // কলারের দ্বারা একটি বৈধ চর হবে।
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে এটি প্রবাহিত হবে না
        // একটি চরের জন্য মানগুলির ব্যাপ্তি।
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে এটি প্রবাহিত হবে না
            // একটি চরের জন্য মানগুলির ব্যাপ্তি।
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // নিরাপত্তা: পূর্ববর্তী চুক্তির কারণে এটি গ্যারান্টিযুক্ত
        // কলারের দ্বারা একটি বৈধ চর হবে।
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// এই ম্যাক্রোগুলি বিভিন্ন পরিসরের প্রকারের জন্য `ExactSizeIterator` ইমপ্লিট উত্পন্ন করে।
//
// * `ExactSizeIterator::len` সর্বদা সঠিক `usize` ফেরত দেওয়া দরকার, তাই কোনও ব্যাপ্তি `usize::MAX` এর চেয়ে বেশি দীর্ঘ হতে পারে না।
//
// * এক্স01 এক্স-তে পূর্ণসংখ্যার ধরণের ক্ষেত্রে এটি `usize` এর চেয়ে সঙ্কুচিত বা প্রশস্ত প্রকারগুলির ক্ষেত্রে।
//   এক্স 100 এক্স-তে পূর্ণসংখ্যার ধরণের ক্ষেত্রে এটি `usize` এর তুলনায় *কঠোরভাবে সংক্ষিপ্ত* প্রকারের ক্ষেত্রে যেমন
//   `(0..=u64::MAX).len()` `u64::MAX + 1` হবে।
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // এগুলি উপরোক্ত যুক্তি অনুসারে বিরক্তিকর, তবে এগুলি অপসারণ একটি ব্রেকিং পরিবর্তন হবে কারণ এগুলি Rust 1.0.0 এ স্থিতিশীল ছিল।
    // সুতরাং যেমন
    // `(0..66_000_u32).len()` উদাহরণস্বরূপ 16-বিট প্ল্যাটফর্মগুলিতে ত্রুটি বা সতর্কতা ছাড়াই সংকলন করবে তবে ভুল ফলাফল দেওয়া অবিরত থাকবে।
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // এগুলি উপরোক্ত যুক্তি অনুসারে বিরক্তিকর, তবে এগুলি অপসারণ একটি ব্রেকিং পরিবর্তন হবে কারণ এগুলি Rust 1.26.0 এ স্থিতিশীল ছিল।
    // সুতরাং যেমন
    // `(0..=u16::MAX).len()` উদাহরণস্বরূপ 16-বিট প্ল্যাটফর্মগুলিতে ত্রুটি বা সতর্কতা ছাড়াই সংকলন করবে তবে ভুল ফলাফল দেওয়া অবিরত থাকবে।
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // নিরাপদ: সবেমাত্র পূর্বশর্ত পরীক্ষা করা হয়েছে
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}