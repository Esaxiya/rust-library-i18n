use crate::{iter::FusedIterator, ops::Try};

/// এমন একটি পুনরাবৃত্তি যা অন্তহীনভাবে পুনরাবৃত্তি করে।
///
/// এই `struct` [`Iterator`] এ [`cycle`] পদ্ধতি দ্বারা তৈরি করা হয়েছে।
/// আরও জন্য এর ডকুমেন্টেশন দেখুন।
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // চক্র পুনরাবৃত্তকারী হয় খালি বা অসীম
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // সম্পূর্ণরূপে বর্তমান পুনরাবৃত্তি পুনরাবৃত্তি।
        // এটি প্রয়োজনীয় কারণ `self.iter` এক্স না থাকা সত্ত্বেও `self.iter` খালি থাকতে পারে
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // চক্রযুক্ত পুনরুক্তি খালি আছে কিনা তা খতিয়ে রেখে পুরো চক্রটি সম্পূর্ণ করুন।
        // অসীম লুপটি রোধ করতে আমাদের খালি পুনরাবৃত্তির ক্ষেত্রে প্রথম দিকে ফিরে আসতে হবে to
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` ওভাররাইড নয়, কারণ `fold` `Cycle` এর জন্য খুব বেশি অর্থ দেয় না এবং আমরা ডিফল্টের চেয়ে ভাল কিছু করতে পারি না।
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}