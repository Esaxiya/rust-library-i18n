//! .চ্ছিক মান।
//!
//! প্রকার [`Option`] একটি alচ্ছিক মান উপস্থাপন করে: প্রতিটি [`Option`] হয় হয় [`Some`] এবং এর মধ্যে একটি মান বা [`None`] থাকে এবং তা হয় না।
//! [`Option`] প্রকারগুলি Rust কোডে খুব সাধারণ, কারণ তাদের বেশ কয়েকটি ব্যবহার রয়েছে:
//!
//! * প্রাথমিক মান
//! * ফাংশনগুলির জন্য ফিরে আসা মানগুলি যা তাদের পুরো ইনপুট পরিসীমা (আংশিক ফাংশন) এর সাথে সংজ্ঞায়িত হয় না
//! * অন্যথায় সরল ত্রুটিগুলির প্রতিবেদন করার জন্য ফেরতের মান, যেখানে [`None`] ত্রুটিতে ফিরে আসে
//! * .চ্ছিক কাঠামো ক্ষেত্র
//! * Fieldsণ নেওয়া বা "taken" হতে পারে এমন ক্ষেত্রগুলি গঠন করুন
//! * Functionচ্ছিক ফাংশন যুক্তি
//! * নলাবল পয়েন্টার
//! * কঠিন পরিস্থিতিগুলির বাইরে জিনিসগুলি অদলবদল করা
//!
//! [`অপশন`] গুলি সাধারণত কোনও মানের উপস্থিতি সম্পর্কে জিজ্ঞাসা করতে এবং পদক্ষেপ নিতে সর্বদা [`None`] কেসের জন্য অ্যাকাউন্টিং করে প্যাটার্ন ম্যাচিংয়ের সাথে যুক্ত হয়।
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ফাংশনের রিটার্ন মান একটি বিকল্প
//! let result = divide(2.0, 3.0);
//!
//! // মান পুনরুদ্ধার করতে প্যাটার্ন ম্যাচ
//! match result {
//!     // বিভাগটি বৈধ ছিল
//!     Some(x) => println!("Result: {}", x),
//!     // বিভাগটি অবৈধ ছিল
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: প্রচুর পদ্ধতিতে `Option` অনুশীলনে কীভাবে ব্যবহৃত হয় তা দেখান
//
//! # বিকল্প এবং পয়েন্টার ("nullable" পয়েন্টার)
//!
//! Rust এর পয়েন্টার ধরণেরগুলি সর্বদা একটি বৈধ অবস্থানের দিকে নির্দেশ করতে হবে;কোনও "null" উল্লেখ নেই।পরিবর্তে, Rust এর *optionচ্ছিক* পয়েন্টার রয়েছে, ownedচ্ছিক মালিকানার বাক্সের মতো, [`বিকল্প`]`<`[`বক্স<T>`]`>``
//!
//! নিম্নলিখিত উদাহরণটি [`i32`] এর একটি alচ্ছিক বাক্স তৈরি করতে [`Option`] ব্যবহার করে।
//! লক্ষ করুন যে প্রথমে অভ্যন্তরীণ [`i32`] মানটি ব্যবহার করার জন্য, বাক্সটির কোনও মান আছে (যেমন, এটি [`Some(...)`][`Some`]) অথবা ([`None`]) নয়) তা নির্ধারণের জন্য এক্স02 এক্স ফাংশনটিতে প্যাটার্ন ম্যাচিং ব্যবহার করা প্রয়োজন।
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust নিম্নলিখিত ধরণের `T` কে অনুকূল করতে গ্যারান্টি দেয় যে [`Option<T>`] এর আকার `T` এর মতো হয়:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` এই তালিকার মধ্যে এক প্রকারের স্ট্রাক্ট।
//!
//! এটি আরও গ্যারান্টিযুক্ত যে উপরের কেসগুলির জন্য, `T` এর সমস্ত বৈধ মানগুলি থেকে `Option<T>` এবং `Some::<T>(_)` থেকে `T`-তে [`mem::transmute`] (তবে `None::<T>` থেকে এক্স06 এক্সে ট্রান্সমিশন করা অপরিজ্ঞাত আচরণ) can
//!
//! # Examples
//!
//! [`Option`] এর সাথে বেসিক প্যাটার্নের মিল:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // থাকা স্ট্রিংয়ের একটি রেফারেন্স নিন
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // বিকল্পটি ধ্বংস করে থাকা সংযুক্ত স্ট্রিংটি সরান
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! লুপের আগে [`None`] এ ফলাফল শুরু করুন:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // মাধ্যমে অনুসন্ধানের জন্য ডেটার একটি তালিকা।
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // আমরা বৃহত্তম প্রাণীর নাম অনুসন্ধান করতে যাচ্ছি, তবে কেবলমাত্র `None` পেয়েছি start
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // এখন আমরা কিছু বড় প্রাণীর নাম পেয়েছি
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// এক্স 100 এক্স টাইপ।আরও জন্য এক্স01 এক্স দেখুন।
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// মূল্যহীন
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// কিছু মান `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// প্রকারের প্রয়োগ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // থাকা মানগুলি জিজ্ঞাসা করা হচ্ছে
    /////////////////////////////////////////////////////////////////////////

    /// বিকল্পটি [`Some`] মান হলে `true` প্রদান করে Return
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// বিকল্পটি [`None`] মান হলে `true` প্রদান করে Return
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// বিকল্পটি প্রদত্ত মান সমেত একটি [`Some`] মান হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // রেফারেন্স সহ কাজ করার জন্য অ্যাডাপ্টার
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` থেকে `Option<&T>` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// আসলটি সংরক্ষণ করে একটি `বিকল্প <` [`স্ট্রিং`]`>`কে একটি`বিকল্প <`[`ইউজাইজ]]`>` এ রূপান্তর করে।
    /// [`map`] পদ্ধতিটি মূলটি গ্রাস করে `self` টি আর্গুমেন্ট গ্রহণ করে, সুতরাং এই কৌশলটি প্রথমে `as_ref` ব্যবহার করে মূলটির অভ্যন্তরের মানের সাথে সম্পর্কিত একটি রেফারেন্সের জন্য `Option` নিতে।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // প্রথমে `Option<String>` কে `as_ref` দিয়ে `Option<&String>` এ castালুন, তারপরে স্ট্যাকের উপর দিয়ে `text` রেখে `map` দিয়ে * ব্যবহার করুন।
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` থেকে `Option<&mut T>` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`]`<ও বিকল্প থেকে রূপান্তর<T>>`থেকে ption বিকল্প <`[`পিন`]` <ও টি>> ``
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // নিরাপত্তা: এক্স0 এক্স এক্স পিন করার গ্যারান্টিযুক্ত কারণ এটি `self` থেকে এসেছে
        // যা পিন করা আছে।
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`] from <ও রূপান্তর বিকল্প থেকে রূপান্তর<T>> `থেকে ption বিকল্প <` [`পিন`]` <&টি টি>> mut।
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // নিরাপদ: `get_unchecked_mut` `self` এর ভিতরে `Option` সরানোর জন্য কখনও ব্যবহৃত হয় না।
        // `x` পিন করা গ্যারান্টিযুক্ত কারণ এটি `self` থেকে আসে যা পিনযুক্ত।
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ধারণকৃত মানগুলি প্রাপ্ত করা
    /////////////////////////////////////////////////////////////////////////

    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Some`] মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি `msg` সরবরাহ করে একটি কাস্টম panic বার্তা সহ একটি [`None`] হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Some`] মান প্রদান করে।
    ///
    /// এই ফাংশনটি panic হতে পারে, এর ব্যবহারটি সাধারণত নিরুৎসাহিত করা হয়।
    /// পরিবর্তে, প্যাটার্ন মিলটি ব্যবহার করতে এবং স্পষ্টভাবে [`None`] কেসটিকে পরিচালনা করতে পছন্দ করুন বা এক্স01 এক্স, এক্স02 এক্স, বা এক্স 100 এক্সকে কল করুন।
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics যদি স্ব মানটি [`None`] এর সমান হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// এতে থাকা [`Some`] মান বা প্রদত্ত ডিফল্টটি প্রদান করে।
    ///
    /// `unwrap_or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`unwrap_or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// অন্তর্ভুক্ত থাকা [`Some`] মানটি ফেরত দেয় বা একটি বন্ধ হওয়া থেকে এটি গণনা করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// মানটি [`None`] নয় তা যাচাই না করে, `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Some`] মান প্রদান করে।
    ///
    ///
    /// # Safety
    ///
    /// [`None`] এ এই পদ্ধতিটি কল করা হ'ল *[অপরিবর্তিত আচরণ]*।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // নির্ধারিত আচরণ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ধারণকৃত মানগুলি রূপান্তরকরণ
    /////////////////////////////////////////////////////////////////////////

    /// কোনও মানকে একটি কার্যকরী বৈশিষ্ট্য প্রয়োগ করে একটি `Option<T>` থেকে `Option<U>` মানচিত্র করুন।
    ///
    /// # Examples
    ///
    /// মূলটিকে গ্রাস করে একটি `বিকল্প <` [`স্ট্রিং`]`>`কে একটি`বিকল্প <`[`ইউজাইজ]]`>` এ রূপান্তর করে:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` গ্রাস করে *মান দ্বারা স্ব* নেয়
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// থাকা মানটিতে (যদি থাকে) একটি ফাংশন প্রয়োগ করে বা সরবরাহিত ডিফল্ট (যদি না হয়) প্রদান করে।
    ///
    /// `map_or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`map_or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// থাকা মানটিতে (যদি থাকে) একটি ফাংশন প্রয়োগ করে, বা একটি ডিফল্ট গণনা করে (যদি না হয়)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` কে [`Result<T, E>`] এবং [`None`] কে [`Err(err)`] এ `Option<T>` ম্যাপিং করে `Option<T>` কে [`Result<T, E>`] রূপান্তর করে।
    ///
    /// `ok_or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`ok_or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` কে [`Result<T, E>`] এবং [`None`] কে [`Err(err())`] এ `Option<T>` ম্যাপিং করে `Option<T>` কে [`Result<T, E>`] রূপান্তর করে।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// বিকল্পে `value` সন্নিবেশ করান এরপরে এটিতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// বিকল্পটিতে যদি ইতিমধ্যে একটি মান থাকে তবে পুরানো মান বাদ দেওয়া হবে।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // নিরাপদ: উপরের কোডটি কেবলমাত্র বিকল্পটি পূরণ করেছে
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator নির্মাণকারী
    /////////////////////////////////////////////////////////////////////////

    /// সম্ভবত অন্তর্ভুক্ত মানের উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// সম্ভাব্য সংখ্যার মানের পরিবর্তে একটি পরিবর্তনীয় পুনরাবৃত্তি প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // উত্সাহী এবং অলস মানগুলিতে বুলিয়ান ক্রিয়াকলাপ
    /////////////////////////////////////////////////////////////////////////

    /// বিকল্পটি [`None`] হলে [`None`] প্রদান করে, অন্যথায় `optb` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// বিকল্পটি [`None`] হলে [`None`] প্রদান করে, অন্যথায় মোড়ানো মান সহ `f` কে কল করে এবং ফলাফলটি প্রদান করে।
    ///
    ///
    /// কিছু ভাষা এই অপারেশনটিকে ফ্ল্যাটম্যাপ বলে।
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// বিকল্পটি [`None`] হলে [`None`] প্রদান করে, অন্যথায় মোড়ানো মান সহ `predicate` কে কল করে ফিরে আসে:
    ///
    ///
    /// - [`Some(t)`] যদি `predicate` `true` (যেখানে `t` মোড়ানো মান), এবং
    /// - [`None`] `predicate` যদি `false` প্রদান করে।
    ///
    /// এই ফাংশনটি [`Iterator::filter()`] এর মতো কাজ করে।
    /// আপনি `Option<T>` এক বা শূন্য উপাদানগুলির দ্বারা পুনরাবৃত্তকারী হিসাবে কল্পনা করতে পারেন।
    /// `filter()` কোন উপাদানগুলি রাখা উচিত তা আপনাকে সিদ্ধান্ত নিতে দেয়।
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// বিকল্পটিতে যদি এর কোনও মান থাকে তবে তা ফিরিয়ে দেয়, অন্যথায় `optb` প্রদান করে।
    ///
    /// `or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// বিকল্পটিতে এটির কোনও মান থাকলে তা ফিরিয়ে দেয়, অন্যথায় `f` কে কল করে ফলাফলটি দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self` এর ঠিক এক, `optb` এক্স02 এক্স হলে এক্স04 এক্স প্রদান করে, অন্যথায় [`None`] প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // কোনও না হলে sertোকাতে এবং কোনও রেফারেন্স ফেরত প্রবেশের মতো ক্রিয়াকলাপ
    /////////////////////////////////////////////////////////////////////////

    /// এটি [`None`] হলে বিকল্পটিতে `value` সন্নিবেশ করান, তারপরে অন্তর্ভুক্ত মানটির পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// বিকল্পটিতে ডিফল্ট মান সন্নিবেশ করানো হয় যদি এটি [`None`] হয়, তবে এতে থাকা মানটির পরিবর্তে পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` থেকে বিকল্পে X গণনা করা কোনও মান সন্নিবেশ করানো হয় যদি এটি [`None`] হয়, তবে অন্তর্ভুক্ত মানটির পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // নিরাপদ: `self` এর জন্য একটি `None` রূপটি একটি `Some` দ্বারা প্রতিস্থাপন করা হত
            // উপরের কোডে বৈকল্পিক।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// বিকল্পটিতে মানটি নিয়ে যায়, তার জায়গায় একটি [`None`] রেখে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// প্যারামিটারে প্রদত্ত মান দ্বারা বিকল্পটিতে প্রকৃত মানকে প্রতিস্থাপন করে, উপস্থিত থাকলে পুরানো মানটি ফিরিয়ে দেয়, একটিরও নির্দিষ্টকরণ ছাড়াই একটি [`Some`] কে তার জায়গায় রেখে দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// অন্য `Option` এর সাথে জিপস X01 এক্স।
    ///
    /// যদি `self` এক্স03 এক্স হয় এবং এক্স04 এক্স এক্স01 এক্স হয়, এই পদ্ধতিটি `Some((s, o))` প্রদান করে।
    /// অন্যথায়, `None` ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// X001 ফাংশন সহ জিপস X01 এক্স এবং অন্য `Option`।
    ///
    /// যদি `self` এক্স03 এক্স হয় এবং এক্স04 এক্স এক্স01 এক্স হয়, এই পদ্ধতিটি `Some(f(s, o))` প্রদান করে।
    /// অন্যথায়, `None` ফিরে আসে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// বিকল্পের বিষয়বস্তু অনুলিপি করে একটি এক্স 100 এক্সকে একটি এক্স0 এক্স এ ম্যাপ করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// বিকল্পের বিষয়বস্তু অনুলিপি করে একটি এক্স 100 এক্সকে একটি এক্স0 এক্স এ ম্যাপ করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// বিকল্পের বিষয়বস্তুগুলিকে ক্লোন করে একটি এক্স 100 এক্সকে একটি এক্স0 এক্স এ ম্যাপ করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// বিকল্পের বিষয়বস্তুগুলিকে ক্লোন করে একটি এক্স 100 এক্সকে একটি এক্স0 এক্স এ ম্যাপ করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// এক্স01 এক্স আশা করার সময় এবং কিছুই ফেরার সময় এক্স00 এক্স গ্রহণ করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি [`Some`] হয় তবে একটি panic বার্তা এবং [`Some`] এর সামগ্রী সহ একটি panic বার্তা থাকে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // এটি panic করবে না, যেহেতু সমস্ত কীগুলি অনন্য।
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// এক্স01 এক্স আশা করার সময় এবং কিছুই ফেরার সময় এক্স00 এক্স গ্রহণ করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি একটি [`Some`] হয় তবে [`Some`] এর মান দ্বারা সরবরাহিত একটি কাস্টম panic বার্তা রয়েছে।
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // এটি panic করবে না, যেহেতু সমস্ত কীগুলি অনন্য।
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// থাকা [`Some`] মান বা একটি ডিফল্ট প্রদান করে
    ///
    /// `self` টি আর্গুমেন্ট গ্রহণ করে তারপরে, যদি [`Some`], অন্তর্ভুক্ত মানটি প্রদান করে, অন্যথায় যদি [`None`], সেই ধরণের জন্য [default value] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// একটি স্ট্রিংকে পূর্ণসংখ্যায় রূপান্তরিত করে, খারাপভাবে গঠিত স্ট্রিংগুলিকে 0 (পূর্ণসংখ্যার জন্য ডিফল্ট মান) তে পরিণত করে।
    /// [`parse`] [`FromStr`] প্রয়োগ করে অন্য কোনও ধরণের স্ট্রিং রূপান্তর করে, ত্রুটিতে [`None`] প্রদান করে।
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (বা `&Option<T>`) থেকে `Option<&T::Target>` এ রূপান্তর করে।
    ///
    /// আসল অপশনটি জায়গায় রেখে দেয়, মূলটির সাথে উল্লেখ করে একটি নতুন তৈরি করে, অতিরিক্তভাবে [`Deref`] এর মাধ্যমে সামগ্রীগুলি জোর করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (বা `&mut Option<T>`) থেকে `Option<&mut T::Target>` এ রূপান্তর করে।
    ///
    /// অভ্যন্তরীণ প্রকারের `Deref::Target` প্রকারের ক্ষেত্রে পরিবর্তনীয় রেফারেন্স যুক্ত একটি নতুন তৈরি করে মূল `Option`-কে রেখে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] এর একটি `Option` কে `Option` এর [`Result`] রূপান্তর করে।
    ///
    /// [`None`] [`Ok`]`(`[`কিছুই নয়]] ma) এ ম্যাপ করা হবে`
    /// [`কিছু`]`(`[`Ok`] `(_))` এবং [`কিছু`] `(` [`ত্রুটি]` (_))[`Ok`]`এ ম্যাপ করা হবে (`[`কিছু`] `(_))` এবং [`এরে]` (_) ``
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// এটি নিজেই .expect() এর কোড আকার হ্রাস করার জন্য একটি পৃথক ফাংশন।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// এটি নিজেই .expect_none() এর কোড আকার হ্রাস করার জন্য একটি পৃথক ফাংশন।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait বাস্তবায়ন
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// এক্স 100 এক্স প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// সম্ভবত ধারণিত মানটির চেয়ে গ্রাসকারী পুনরুক্তি ফেরত দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// এক্স 011 এক্সকে একটি নতুন এক্স 100 এক্সে অনুলিপি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` থেকে `Option<&T>` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// আসলটি সংরক্ষণ করে একটি `বিকল্প <` [`স্ট্রিং`]`>`কে একটি`বিকল্প <`[`ইউজাইজ]]`>` এ রূপান্তর করে।
    /// [`map`] পদ্ধতিটি মূলটি গ্রাস করে `self` টি আর্গুমেন্ট গ্রহণ করে, সুতরাং এই কৌশলটি প্রথমে `as_ref` ব্যবহার করে মূলটির অভ্যন্তরের মানের সাথে সম্পর্কিত একটি রেফারেন্সের জন্য `Option` নিতে।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` থেকে `Option<&mut T>` এ রূপান্তর করে
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// অপশন আইটারেটর
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// একটি [`Option`] এর [`Some`] বৈকল্পিকের রেফারেন্সের উপর একটি পুনরাবৃত্তি।
///
/// [`Option`] যদি একটি [`Some`] হয় তবে পুনরুক্তিটি একটি মান দেয় otherwise
///
/// এই `struct` [`Option::iter`] ফাংশন দ্বারা নির্মিত হয়েছে।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] এর [`Some`] বৈকল্পিকের পরিবর্তনীয় রেফারেন্সের উপর একটি পুনরাবৃত্তি।
///
/// [`Option`] যদি একটি [`Some`] হয় তবে পুনরুক্তিটি একটি মান দেয় otherwise
///
/// এই `struct` [`Option::iter_mut`] ফাংশন দ্বারা নির্মিত হয়েছে।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// একটি [`Option`] এর [`Some`] বৈকল্পিকের মানের চেয়ে একটি পুনরাবৃত্তি।
///
/// [`Option`] যদি একটি [`Some`] হয় তবে পুনরুক্তিটি একটি মান দেয় otherwise
///
/// এই `struct` [`Option::into_iter`] ফাংশন দ্বারা নির্মিত হয়েছে।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// প্রতিটি উপাদানকে [`Iterator`] এ নিয়ে যায়: এটি যদি [`None`][Option::None] হয় তবে আর কোনও উপাদান নেওয়া হয় না এবং এক্স02 এক্স ফিরে আসে।
    /// কোনও [`None`][Option::None] না হওয়া উচিত, প্রতিটি এক্স01 এক্সের মান সহ একটি ধারক ফিরে আসে।
    ///
    /// # Examples
    ///
    /// এখানে একটি উদাহরণ যা vector এর প্রতিটি পূর্ণসংখ্যাকে বৃদ্ধি করে।
    /// আমরা `add` এর চেক করা বৈকল্পিকটি ব্যবহার করি যা `None` প্রদান করে যখন গণনার ফলে ওভারফ্লো হয়।
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// আপনি দেখতে পাচ্ছেন, এটি প্রত্যাশিত, বৈধ আইটেমগুলি ফিরিয়ে দেবে।
    ///
    /// এখানে আরেকটি উদাহরণ যা অন্য একটি পূর্ণসংখ্যার তালিকা থেকে একটিকে বিয়োগ করার চেষ্টা করে, এবার আন্ডারফ্লো পরীক্ষা করছে:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// যেহেতু শেষ উপাদানটি শূন্য, এটি প্রবাহিত হবে।সুতরাং, ফলাফল মান `None` হয়।
    ///
    /// পূর্ববর্তী উদাহরণে এখানে একটি পার্থক্য রয়েছে যা দেখায় যে প্রথম `None` এর পরে আর কোনও উপাদান `iter` থেকে নেওয়া হয় না।
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// যেহেতু তৃতীয় উপাদানটি একটি জলের তলদেশ সৃষ্টি করেছিল, তাই আর কোনও উপাদান নেওয়া হয়নি, সুতরাং `shared` এর চূড়ান্ত মান 16 (= `3 + 2 + 1`), 16 নয়।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): এই পারফরম্যান্স বাগটি বন্ধ হয়ে গেলে এটি Iterator::scan এর সাথে প্রতিস্থাপন করা যেতে পারে।
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ট্র্যাক অপারেটর (`?`) কে `None` মান প্রয়োগ করার ফলে ত্রুটি প্রকারের ফলাফল।
/// যদি আপনি `x?` (যেখানে `x` একটি `Option<T>` হয়) আপনার ত্রুটি প্রকারে রূপান্তরিত করতে চান তবে আপনি `YourErrorType` এর জন্য `impl From<NoneError>` প্রয়োগ করতে পারেন।
///
/// সেক্ষেত্রে `Result<_, YourErrorType>` প্রদান করে এমন একটি ফাংশনের মধ্যে `x?` একটি `None` মানকে একটি এক্স03 এক্স ফলাফলের মধ্যে অনুবাদ করবে।
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` থেকে `Option<T>` এ রূপান্তর করে
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// সমতলকরণ একবারে বাসা বাঁধার এক স্তরকে সরিয়ে দেয়:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}