//! লাইবকোয়ার জেড0প্রিলিড0 জেড
//!
//! এই মডিউলটি লাইবকোরের ব্যবহারকারীদের জন্য তৈরি করা হয়েছে যা লিবিস্টডির সাথেও লিঙ্ক করে না।
//! এই মডিউলটি ডিফল্টরূপে আমদানি করা হয় যখন স্ট্যান্ডার্ড লাইব্রেরির জেড0প্রিলিডিজেডের মতো `#![no_std]` একইভাবে ব্যবহৃত হয়।
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// কোর prelude এর 2015 সংস্করণ।
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// মূল prelude এর 2018 সংস্করণ।
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// মূল prelude এর 2021 সংস্করণ।
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: আরও জিনিস যুক্ত করুন।
}