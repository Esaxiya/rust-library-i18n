#![stable(feature = "futures_api", since = "1.36.0")]

//! অ্যাসিনক্রোনাস মান।

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// এই ধরণের প্রয়োজন কারণ:
///
/// ক) জেনারেটর এক্স00 এক্স বাস্তবায়ন করতে পারে না, সুতরাং আমাদের একটি কাঁচা পয়েন্টার (এক্স01 এক্স দেখুন) পাস করতে হবে।
///
/// খ) কাঁচা পয়েন্টার এবং X01 এক্স এক্স0 2 এক্স বা এক্স 100 এক্স নয়, যাতে প্রতি একক জেডফিউচার0 জেড এক্স03 এক্সও তৈরি হয় এবং আমরা এটিও চাই না।
///
/// এটি `.await` এর এইচআইআর হ্রাসও সরল করে।
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// জেডফিউচার0 জেডে জেনারেটর মোড়ানো rap
///
/// এই ফাংশনটি নীচে একটি `GenFuture` ফেরত দেয়, তবে এটি আরও ভাল ত্রুটি বার্তা (`GenFuture<[closure.....]>` এর চেয়ে `impl Future`) দিতে `impl Trait` এ লুকায় h
///
// এক্স এক্স এক্স থেকে পুনরুদ্ধার করার পরে অতিরিক্ত ত্রুটিগুলি এড়াতে এটি `const`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // আমরা অন্তর্নিহিত জেনারেটরে স্ব-রেফারেনশিয়াল createণ গ্রহণের জন্য async/await futures স্থাবর হওয়ার উপর নির্ভর করি।
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // নিরাপদ: নিরাপদ কারণ আমরা !Unpin + !Drop, এবং এটি কেবল একটি ক্ষেত্রের অভিক্ষেপ।
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` কে `NonNull` কাঁচা পয়েন্টারে পরিণত করে জেনারেটরটি আবার চালু করুন।
            // এক্স01 এক্স নিম্নতর করা নিরাপদে এটিকে একটি `&mut Context` এ ফেলে দেবে।
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `cx.0` একটি বৈধ পয়েন্টার
    // যে কোনও পরিবর্তনীয় রেফারেন্সের জন্য সমস্ত প্রয়োজনীয়তা পূরণ করে।
    unsafe { &mut *cx.0.as_ptr().cast() }
}