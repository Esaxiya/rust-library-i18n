use crate::future::Future;

/// `Future` এ রূপান্তর।
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future সমাপ্তির পরে উত্পাদিত হবে আউটপুট।
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// কোন ধরণের জেড 0 ফিউচার0 জেড আমরা এটিকে রূপান্তর করছি?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// একটি মান থেকে একটি জেডফিউচার0 জেড তৈরি করে।
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}