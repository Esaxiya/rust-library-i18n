use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// যদিও এই ফাংশনটি এক জায়গায় ব্যবহৃত হয় এবং এর প্রয়োগটি ইনলাইন করা যেতে পারে, এর আগে করার চেষ্টাগুলি rustc ধীর করে তুলেছিল:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// মেমরির একটি ব্লকের বিন্যাস।
///
/// এক্স00 এক্স এর উদাহরণ মেমরির একটি নির্দিষ্ট বিন্যাস বর্ণনা করে।
/// কোনও বরাদ্দকারীকে দেওয়ার জন্য আপনি ইনপুট হিসাবে একটি `Layout` আপ তৈরি করেন।
///
/// সমস্ত বিন্যাসের একটি সম্পর্কিত আকার এবং একটি পাওয়ার-টু টু সারিবদ্ধকরণ রয়েছে।
///
/// (দ্রষ্টব্য যে বিন্যাসগুলি শূন্য-নন আকারের প্রয়োজন * নয়, যদিও `GlobalAlloc` এর জন্য সমস্ত মেমরি অনুরোধের আকারের শূন্য নয় be
/// একজন কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে এর মতো শর্ত পূরণ হয়েছে, আলসার প্রয়োজনীয়তার সাথে সুনির্দিষ্ট বরাদ্দকারী ব্যবহার করুন, বা আরও লেনিয়েন্ট `Allocator` ইন্টারফেস ব্যবহার করুন))
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // মেমরির অনুরোধ করা ব্লকের আকার, বাইটগুলি পরিমাপ করা হয়।
    size_: usize,

    // বাইটগুলিতে পরিমাপ করা মেমরির অনুরোধ করা ব্লকের সারিবদ্ধতা।
    // আমরা নিশ্চিত করি যে এটি সর্বদা একটি পাওয়ার-অফ-টু, কারণ এপিআই'র এক্স এক্স এক্স এর মতো এটি দরকার এবং এটি লেআউট কনস্ট্রাক্টরদের উপর চাপিয়ে দেওয়া যুক্তিসঙ্গত বাধা।
    //
    //
    // (তবে, আমাদের একত্রে `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) প্রয়োজন হয় না
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// প্রদত্ত `size` এবং `align` থেকে একটি `Layout` গঠন করে, বা নিম্নলিখিত শর্তগুলির কোনওটি পূরণ না করা হলে `LayoutError` প্রদান করে:
    ///
    /// * `align` শূন্য হতে হবে না,
    ///
    /// * `align` দু'জনের শক্তি হতে হবে,
    ///
    /// * `size`, যখন `align` এর নিকটতম একাধিক পর্যন্ত গোলাকার হবে তখন অবশ্যই উপচে পড়বে না (অর্থাত গোলাকার মান অবশ্যই `usize::MAX` এর চেয়ে কম বা এর সমান হবে)।
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (দু'জনের পাওয়ার মানেই সারিবদ্ধ!=0.)

        // বৃত্তাকার আপ আকার:
        //   সাইজ_সাগত_ আপ=(আকার + প্রান্তিককরণ, 1)&! (সারিবদ্ধ, 1);
        //
        // উপরে থেকে আমরা জানি যে প্রান্তিককরণ!=0
        // যদি যোগ করা হয় (সারিবদ্ধ, 1) ওভারফ্লো না হয়, তবে রাউন্ডিং ঠিক থাকবে।
        //
        // বিপরীতে,&-masking! (সারিবদ্ধ, 1) কেবলমাত্র নিম্ন-অর্ডার-বিটগুলি বিয়োগ করবে।
        // সুতরাং যোগফলের সাথে যদি ওভারফ্লো ঘটে তবে&-মাস্ক সেই ওভারফ্লোটিকে পূর্বাবস্থায় ফেলার জন্য যথেষ্ট বিয়োগ করতে পারে না।
        //
        //
        // উপরের দিক থেকে বোঝা যাচ্ছে যে সমষ্টি ওভারফ্লো পরীক্ষা করা প্রয়োজনীয় এবং পর্যাপ্ত উভয়ই।
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // নিরাপদ: `from_size_align_unchecked` এর শর্ত ছিল
        // উপরে পরীক্ষা করা হয়েছে।
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// সমস্ত চেককে বাইপাস করে একটি বিন্যাস তৈরি করে।
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি অনিরাপদ কারণ এটি [`Layout::from_size_align`] এর পূর্ব শর্তাদি যাচাই করে না।
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // নিরাপদ: কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে `align` শূন্যের চেয়ে বড়।
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// এই বিন্যাসটির একটি মেমরি ব্লকের জন্য বাইটের সর্বনিম্ন আকার।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// এই বিন্যাসটির একটি মেমরি ব্লকের জন্য সর্বনিম্ন বাইট সারিবদ্ধকরণ।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` প্রকারের মান ধরে রাখার জন্য উপযুক্ত একটি `Layout` তৈরি করে।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // সুরক্ষা: প্রান্তিককরণ দুটি এবং এর শক্তি হওয়ার জন্য Rust দ্বারা গ্যারান্টিযুক্ত
        // আকার + সারিবদ্ধ কম্বোটি আমাদের ঠিকানার জায়গায় ফিট করার গ্যারান্টিযুক্ত।
        // ফলস্বরূপ এখানে panics যদি যথেষ্ট পরিমাণে অনুকূলিত না হয় তবে কোডটি সন্নিবেশ করা এড়াতে এখানে চেক করা নির্মাতারা ব্যবহার করুন।
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` এর জন্য ব্যাকিং কাঠামো বরাদ্দ করতে ব্যবহৃত হতে পারে এমন একটি রেকর্ড বর্ণন করে লেআউট তৈরি করে (যা কোনও trait বা একটি স্লাইসের মতো অন্যান্য আকারযুক্ত আকার হতে পারে)।
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // নিরাপদ: এটি অনিরাপদ বৈকল্পিক কেন ব্যবহার করছে তার জন্য `new` এর যুক্তি দেখুন
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` এর জন্য ব্যাকিং কাঠামো বরাদ্দ করতে ব্যবহৃত হতে পারে এমন একটি রেকর্ড বর্ণন করে লেআউট তৈরি করে (যা কোনও trait বা একটি স্লাইসের মতো অন্যান্য আকারযুক্ত আকার হতে পারে)।
    ///
    /// # Safety
    ///
    /// নিম্নলিখিত শর্তগুলি ধরে থাকলে এই ফাংশনটি কেবল কল করতে নিরাপদ:
    ///
    /// - `T` যদি `Sized` হয় তবে এই ফাংশনটি কল করা সর্বদা নিরাপদ।
    /// - যদি `T` এর আনসাইজড লেজটি হয়:
    ///     - একটি এক্স0১ এক্স, তারপরে স্লাইস লেজের দৈর্ঘ্য অবশ্যই একটি আন্তঃসংযোগ পূর্ণ পূর্ণসংখ্যার হতে হবে এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই হবে।
    ///     - একটি এক্স0১ এক্স, তারপরে পয়েন্টারের ভেটেবল অংশটি একটি আনসাইজিং কোয়ার্সিয়নের দ্বারা অর্জিত এক্স0২ এক্স প্রকারের জন্য একটি বৈধ ভ্যাটেবলের দিকে নির্দেশ করবে এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই হবে।
    ///
    ///     - একটি (unstable) [extern type], তারপরে এই ফাংশনটি সর্বদা কল করা নিরাপদ তবে panic বা অন্যথায় ভুল মানটি ফিরে আসতে পারে, কারণ বাহ্যিক ধরণের লেআউটটি জানা যায়নি।
    ///     বাহ্যিক ধরণের লেজের রেফারেন্সে এটি [`Layout::for_value`] এর মতো একই আচরণ।
    ///     - অন্যথায়, রক্ষণশীলভাবে এই ফাংশনটি কল করার অনুমতি নেই।
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // সুরক্ষা: আমরা এই ফাংশনগুলির পূর্বশর্তগুলি কলারের কাছে প্রেরণ করি
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // নিরাপদ: এটি অনিরাপদ বৈকল্পিক কেন ব্যবহার করছে তার জন্য `new` এর যুক্তি দেখুন
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ঝুঁকছে এমন একটি `NonNull` তৈরি করে তবে এই লেআউটটির জন্য সুসংযুক্ত al
    ///
    /// নোট করুন যে পয়েন্টার মানটি একটি বৈধ পয়েন্টারকে সম্ভাব্যভাবে উপস্থাপন করতে পারে যার অর্থ এটি অবশ্যই একটি "not yet initialized" সেন্ডিনেল মান হিসাবে ব্যবহার করা উচিত নয়।
    /// যে ধরণের অলসভাবে বরাদ্দ করা হয় সেগুলি অবশ্যই অন্য কোনও উপায়ে সূচনা ট্র্যাক করতে হবে।
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // নিরাপদ: প্রান্তিককরণটি শূন্য-শূন্য হওয়ার গ্যারান্টিযুক্ত
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// রেকর্ডকে বর্ণনা করে এমন একটি বিন্যাস তৈরি করে যা `self` এর মতো একই লেআউটের মান ধরে রাখতে পারে, তবে এটি প্রান্তিককরণে `align` (বাইটগুলিতে পরিমাপ) করা হয় to
    ///
    ///
    /// যদি `self` ইতিমধ্যে নির্ধারিত প্রান্তিককরণটি পূরণ করে তবে `self` প্রদান করে।
    ///
    /// দ্রষ্টব্য যে এই পদ্ধতিটি সামগ্রিক আকারে কোনও প্যাডিং যুক্ত করবে না, ফিরে দেওয়া বিন্যাসের আলাদা প্রান্তিককরণ আছে কিনা তা বিবেচনা না করেই।
    /// অন্য কথায়, যদি `K` এর আকার 16 হয়, তবে `K.align_to(32)` এর আকার=16 থাকবে 16
    ///
    /// `self.size()` এবং প্রদত্ত `align` এর সংমিশ্রণ [`Layout::from_size_align`] এ তালিকাভুক্ত শর্ত লঙ্ঘন করলে একটি ত্রুটি ফেরায়।
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// নিম্নলিখিত ঠিকানাটি `align` (বাইটে পরিমাপ করা) সন্তুষ্ট করবে তা নিশ্চিত করার জন্য আমাদের `self` এর পরে যে পরিমাণ প্যাডিং inোকাতে হবে তা ফেরত দেয়।
    ///
    /// উদাহরণস্বরূপ, যদি `self.size()` 9 হয়, তবে `self.padding_needed_for(4)` 3 টি প্রত্যাবর্তন করবে কারণ এটি 4-সারিবদ্ধ ঠিকানা পেতে প্রয়োজনীয় প্যাডিংয়ের ন্যূনতম সংখ্যার সংখ্যা (অনুমান করে যে সংশ্লিষ্ট মেমরি ব্লকটি 4-প্রান্তিক ঠিকানা থেকে শুরু হয়)।
    ///
    ///
    /// `align` যদি পাওয়ার-অফ-টু না হয় তবে এই ফাংশনের রিটার্ন মানটির কোনও অর্থ নেই।
    ///
    /// নোট করুন যে প্রত্যাবর্তিত মানটির ইউটিলিটিটির জন্য মেমরির পুরো বরাদ্দকৃত ব্লকের জন্য প্রারম্ভিক ঠিকানার প্রান্তিককরণের চেয়ে কম বা সমান হতে হবে `align`।এই সীমাবদ্ধতা মেটানোর একটি উপায় `align <= self.align()` নিশ্চিত করা ensure
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // গোলাকার মানটি হ'ল:
        //   len_rounded_up=(লেন + সারিবদ্ধ, 1)&! (সারিবদ্ধ, 1);
        // এবং তারপরে আমরা প্যাডিং পার্থক্যটি ফিরিয়ে দেব: `len_rounded_up - len`.
        //
        // আমরা জুড়ে মডুলার গাণিতিক ব্যবহার করি:
        //
        // 1. প্রান্তিককরণটি 0 0 হওয়ার গ্যারান্টিযুক্ত, সুতরাং সারিবদ্ধ করুন, 1 সর্বদা বৈধ।
        //
        // 2.
        // `len + align - 1` সর্বাধিক `align - 1` দ্বারা উপচে পড়তে পারে, সুতরাং এক্স02 এক্স সহ&মাস্কটি নিশ্চিত করবে যে ওভারফ্লো এর ক্ষেত্রে, এক্স01 এক্স নিজেই 0 হবে।
        //
        //    সুতরাং প্রত্যাবর্তিত প্যাডিং, যখন এক্স0 এক্স এক্স যুক্ত করা হয় তখন 0 ফলন করে যা ক্ষুদ্রতরভাবে প্রান্তিক `align` সন্তুষ্ট করে।
        //
        // (অবশ্যই, উপরের পদ্ধতিতে যার আকার এবং প্যাডিং ওভারফ্লো এর মেমোরির ব্লকগুলি বরাদ্দ করার চেষ্টাগুলি বরাদ্দকারীকে যে কোনওভাবে ত্রুটি ঘটায় cause
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// বিন্যাসটির সারিবদ্ধকরণের একাধিক পর্যন্ত এই বিন্যাসের আকারটি বৃত্তাকার করে একটি বিন্যাস তৈরি করে।
    ///
    ///
    /// এটি বিন্যাসের বর্তমান আকারে `padding_needed_for` এর ফলাফল যুক্ত করার সমতুল্য।
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // এটি উপচে পড়তে পারে না।লেআউটের আক্রমণকারী থেকে উদ্ধৃতি দেওয়া:
        // > `size`, যখন `align` এর নিকটতম একাধিক পর্যন্ত গোল করা হবে,
        // > উপচে পড়া উচিত নয় (অর্থাত্, গোলাকার মানটি অবশ্যই এর চেয়ে কম হওয়া উচিত
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// প্রতিটি উদাহরণটিকে অনুরোধ করা আকার এবং প্রান্তিককরণ দেওয়া হয়েছে তা নিশ্চিত করার জন্য প্রতিটি মধ্যে উপযুক্ত পরিমাণে প্যাডিং সহ `self` এর `n` উদাহরণগুলির রেকর্ড বর্ণনা করে একটি বিন্যাস তৈরি করে।
    /// সাফল্যের সাথে, `(k, offs)` প্রদান করে যেখানে `k` অ্যারের বিন্যাস এবং `offs` অ্যারের প্রতিটি উপাদান শুরুর মধ্যবর্তী দূরত্ব distance
    ///
    /// গাণিতিক ওভারফ্লোতে, `LayoutError` প্রদান করে।
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // এটি উপচে পড়তে পারে না।লেআউটের আক্রমণকারী থেকে উদ্ধৃতি দেওয়া:
        // > `size`, যখন `align` এর নিকটতম একাধিক পর্যন্ত গোল করা হবে,
        // > উপচে পড়া উচিত নয় (অর্থাত্, গোলাকার মানটি অবশ্যই এর চেয়ে কম হওয়া উচিত
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // নিরাপদ: self.align ইতিমধ্যে বৈধ হিসাবে পরিচিত এবং বরাদ্দ_ আকার হয়েছে
        // ইতিমধ্যে প্যাড
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` এক্স যথাযথভাবে সারিবদ্ধ করা হবে তা নিশ্চিত করার জন্য প্রয়োজনীয় কোনও প্যাডিং সহ `self` এর পরে রেকর্ড বর্ণনা করে একটি বিন্যাস তৈরি করে, তবে *কোনও পিছনে প্যাডিং নেই*।
    ///
    /// সি উপস্থাপনা বিন্যাস `repr(C)` এর সাথে মিল রাখতে, সমস্ত ক্ষেত্রের সাথে বিন্যাস প্রসারিত করার পরে আপনার `pad_to_align` কল করা উচিত।
    /// (ডিফল্ট Rust উপস্থাপনা বিন্যাস `repr(Rust)`, as it is unspecified.) এর সাথে কোনও মিলের উপায় নেই
    ///
    /// নোট করুন যে উভয় অংশের সারিবদ্ধকরণ নিশ্চিত করার জন্য ফলাফলের বিন্যাসটির প্রান্তিককরণটি `self` এবং `next` এর সর্বাধিক হবে।
    ///
    /// `Ok((k, offset))` প্রদান করে, যেখানে `k` সংক্ষিপ্ত রেকর্ডের বিন্যাস এবং `offset` সংক্ষিপ্ত রেকর্ডের মধ্যে এম্বেড হওয়া `next` এর প্রারম্ভিক অবস্থান, বাইটে, (রেকর্ডটি নিজেই অফসেট 0 থেকে শুরু হয় বলে ধরে নেওয়া হয়) এর আপেক্ষিক অবস্থান।
    ///
    ///
    /// গাণিতিক ওভারফ্লোতে, `LayoutError` প্রদান করে।
    ///
    /// # Examples
    ///
    /// একটি `#[repr(C)]` কাঠামোর বিন্যাস এবং তার ক্ষেত্রের বিন্যাস থেকে ক্ষেত্রগুলির অফসেট গণনা করতে:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` দিয়ে চূড়ান্ত করতে ভুলবেন না!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // এটি কাজ করে যে পরীক্ষা
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// প্রতিটি উদাহরণের মধ্যে কোনও প্যাডিং না করে `self` এর `n` উদাহরণগুলির রেকর্ড বর্ণনা করে একটি বিন্যাস তৈরি করে।
    ///
    /// দ্রষ্টব্য, `repeat` এর বিপরীতে, `repeat_packed` গ্যারান্টি দেয় না যে `self` এর পুনরাবৃত্তি উদাহরণগুলি সঠিকভাবে প্রান্তিককরণ করা হবে, এমনকি যদি `self` এর প্রদত্ত উদাহরণটি সঠিকভাবে প্রান্তিক করা থাকে।
    /// অন্য কথায়, যদি `repeat_packed` এ ফিরে আসা লেআউটটি অ্যারে বরাদ্দের জন্য ব্যবহার করা হয় তবে এটির নিশ্চয়তা নেই যে অ্যারের সমস্ত উপাদান সঠিকভাবে প্রান্তিক করা হবে।
    ///
    /// গাণিতিক ওভারফ্লোতে, `LayoutError` প্রদান করে।
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// দুজনের মধ্যে কোনও অতিরিক্ত প্যাডিং ছাড়াই `self` এর পরে রেকর্ডটি বর্ণনা করে একটি বিন্যাস তৈরি করে।
    /// যেহেতু কোনও প্যাডিং sertedোকানো হয়নি, তাই `next` এর প্রান্তিককরণ অপ্রাসঙ্গিক, এবং ফলাফলটি বিন্যাসে *মোটেও* সংযুক্ত নয়।
    ///
    ///
    /// গাণিতিক ওভারফ্লোতে, `LayoutError` প্রদান করে।
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` এর রেকর্ড বর্ণনা করে একটি বিন্যাস তৈরি করে।
    ///
    /// গাণিতিক ওভারফ্লোতে, `LayoutError` প্রদান করে।
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` বা অন্য কোনও `Layout` কনস্ট্রাক্টরকে দেওয়া প্যারামিটারগুলি এর ডকুমেন্টেড সীমাবদ্ধতাগুলি পূরণ করে না।
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait ত্রুটিটি ডাউন স্ট্রিম ইমপ্লের জন্য আমাদের এটির প্রয়োজন)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}