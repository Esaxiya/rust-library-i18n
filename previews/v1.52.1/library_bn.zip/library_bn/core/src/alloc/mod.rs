//! মেমরি বরাদ্দ এপিআই

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` ত্রুটি একটি বরাদ্দ ব্যর্থতা নির্দেশ করে যা এই বরাদ্দকারীর সাথে প্রদত্ত ইনপুট আর্গুমেন্টগুলির সংমিশ্রণের সময় সংস্থান সংস্থান বা কিছু ভুল হতে পারে।
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait ত্রুটিটি ডাউন স্ট্রিম ইমপ্লের জন্য আমাদের এটির প্রয়োজন)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` এর একটি প্রয়োগ [`Layout`][] এর মাধ্যমে বর্ণিত ডেটার স্বেচ্ছাসেবক ব্লকগুলি বরাদ্দ, বৃদ্ধি, সঙ্কুচিত করতে এবং হ্রাস করতে পারে।
///
/// `Allocator` জেডএসটি, রেফারেন্স, বা স্মার্ট পয়েন্টারগুলিতে প্রয়োগ করার জন্য ডিজাইন করা হয়েছে কারণ বরাদ্দ মেমরিতে পয়েন্টারগুলি আপডেট না করে `MyAlloc([u8; N])` এর মতো বরাদ্দকারী স্থানান্তর করা যায় না।
///
/// [`GlobalAlloc`][] এর বিপরীতে, `Allocator` এ শূন্য আকারের বরাদ্দ অনুমোদিত allowed
/// যদি অন্তর্নিহিত বরাদ্দকারী এটি (জেমলোকের মতো) সমর্থন করে না বা শূন্য পয়েন্টার (যেমন `libc::malloc`) ফেরত দেয় তবে এটি অবশ্যই বাস্তবায়নের মাধ্যমে ধরা পড়বে।
///
/// ### বর্তমানে বরাদ্দ মেমরি
///
/// কয়েকটি পদ্ধতির জন্য প্রয়োজন একটি মেমোরি ব্লক একটি বরাদ্দকারীর মাধ্যমে *বর্তমানে বরাদ্দ*।এই যে মানে:
///
/// * সেই মেমরি ব্লকের সূচনা ঠিকানাটি আগে [`allocate`], [`grow`], বা [`shrink`], এবং দ্বারা ফিরে এসেছিল
///
/// * মেমরি ব্লকটি পরবর্তীকালে ডিলোক্যাট করা হয়নি, যেখানে ব্লকগুলি হয় সরাসরি এক্স01 এক্স এ চলে যাওয়ার দ্বারা এক্সএল 2 এক্স বা এক্স03 এক্স পাস করে পরিবর্তন করা হয়েছিল যা `Ok` প্রদান করে।
///
/// যদি `grow` বা `shrink` `Err` ফিরিয়ে দেয় তবে উত্তীর্ণ পয়েন্টারটি বৈধ থাকে।
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### মেমরি ফিটিং
///
/// কিছু পদ্ধতির জন্য একটি লেআউট *ফিট* মেমরি ব্লক প্রয়োজন।
/// মেমোরি ব্লকটি "fit" করার জন্য এটি একটি লেআউটটির অর্থ কী (বা সমতুল্য, মেমরির ব্লকের জন্য "fit" একটি বিন্যাসের জন্য) নিচের শর্তগুলি অবশ্যই ধরে রাখতে হবে:
///
/// * ব্লকটি অবশ্যই [`layout.align()`] এর মতো একই সারিবদ্ধকরণের সাথে বরাদ্দ করতে হবে এবং
///
/// * প্রদত্ত [`layout.size()`] অবশ্যই `min ..= max` এর মধ্যে আসতে হবে যেখানে:
///   - `min` ব্লক বরাদ্দ করতে সম্প্রতি ব্যবহৃত লেআউটটির আকার এবং
///   - `max` [`allocate`], [`grow`], বা [`shrink`] থেকে ফিরে আসা সর্বশেষতম আসল আকার।
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * একটি বরাদ্দকারী থেকে ফিরে আসা মেমরি ব্লকগুলি অবশ্যই বৈধ মেমরিটির দিকে নির্দেশ করতে হবে এবং উদাহরণটি এবং এর সমস্ত ক্লোনগুলি বাদ না দেওয়া পর্যন্ত তাদের বৈধতা বজায় রাখতে হবে,
///
/// * ক্লোনিং বা বরাদ্দকারীকে সরানো অবশ্যই এই বরাদ্দকারীর থেকে ফিরে আসা মেমরি ব্লকগুলিকে অবৈধ করতে হবে না।একটি ক্লোনড বরাদ্দকারীকে একই বরাদ্দকারীর মতো আচরণ করতে হবে এবং
///
/// * মেমোরি ব্লকের যে কোনও পয়েন্টার যা [*currently allocated*], বরাদ্দকারীর অন্য কোনও পদ্ধতিতে যেতে পারে।
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// মেমরির একটি ব্লক বরাদ্দ করার চেষ্টা।
    ///
    /// সাফল্যে, `layout` এর আকার এবং প্রান্তিককরণ গ্যারান্টি পূরণ করে একটি [`NonNull<[u8]>`][NonNull] প্রদান করে।
    ///
    /// ফিরে আসা ব্লকের `layout.size()` দ্বারা বর্ণিত চেয়ে বড় আকার থাকতে পারে এবং এর সামগ্রিক সূচনা হতে পারে বা নাও পারে।
    ///
    /// # Errors
    ///
    /// এক্স 100 এক্স রিটার্নিং ইঙ্গিত দেয় যে মেমরিটি শেষ হয়ে গেছে বা এক্স01 এক্স বরাদ্দকারীর আকার বা প্রান্তিককরণের সীমাবদ্ধতাগুলি পূরণ করে না।
    ///
    /// বাস্তবায়নগুলি আতঙ্কিত বা বিসর্জন না দিয়ে মেমরি ক্লান্তিতে `Err` ফিরিয়ে আনতে উত্সাহিত করা হয়, তবে এটি কোনও কঠোর প্রয়োজন নয়।
    /// (বিশেষত: মেমরির অবসন্নতা অবলম্বন করে এমন একটি অন্তর্নিহিত নেটিভ বন্টন গ্রন্থাগারের উপরে এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করা আইনত * is)
    ///
    /// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক ক্লায়েন্টরা [`handle_alloc_error`] এক্স বা এর অনুরূপ সরাসরি অনুরোধ না করে [`handle_alloc_error`] ফাংশনটি কল করতে উত্সাহিত করা হয়।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` এর মতো আচরণ করে তবে এটিও নিশ্চিত করে যে ফিরে আসা মেমরি শূন্য-আরম্ভ হয়।
    ///
    /// # Errors
    ///
    /// এক্স 100 এক্স রিটার্নিং ইঙ্গিত দেয় যে মেমরিটি শেষ হয়ে গেছে বা এক্স01 এক্স বরাদ্দকারীর আকার বা প্রান্তিককরণের সীমাবদ্ধতাগুলি পূরণ করে না।
    ///
    /// বাস্তবায়নগুলি আতঙ্কিত বা বিসর্জন না দিয়ে মেমরি ক্লান্তিতে `Err` ফিরিয়ে আনতে উত্সাহিত করা হয়, তবে এটি কোনও কঠোর প্রয়োজন নয়।
    /// (বিশেষত: মেমরির অবসন্নতা অবলম্বন করে এমন একটি অন্তর্নিহিত নেটিভ বন্টন গ্রন্থাগারের উপরে এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করা আইনত * is)
    ///
    /// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক ক্লায়েন্টরা [`handle_alloc_error`] এক্স বা এর অনুরূপ সরাসরি অনুরোধ না করে [`handle_alloc_error`] ফাংশনটি কল করতে উত্সাহিত করা হয়।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // নিরাপদ: `alloc` একটি বৈধ মেমরি ব্লক প্রদান করে
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` দ্বারা রেফারেন্সযুক্ত মেমরিটিকে ডিলোকোট করে।
    ///
    /// # Safety
    ///
    /// * `ptr` এই বরাদ্দকারীর মাধ্যমে মেমরি [*currently allocated*] এর একটি ব্লক অবশ্যই চিহ্নিত করতে হবে এবং
    /// * `layout` মেমরির ব্লক অবশ্যই [*fit*]
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// মেমরি ব্লক প্রসারিত করার চেষ্টা।
    ///
    /// একটি পয়েন্টার এবং বরাদ্দ মেমরির আসল আকার ধারণ করে একটি নতুন [`NonNull<[u8]>`][NonNull] প্রদান করে।নির্দেশকটি `new_layout` দ্বারা বর্ণিত ডেটা ধরে রাখার জন্য উপযুক্ত।
    /// এটি সম্পাদন করতে, বরাদ্দকারী নতুন লেআউটে ফিট করার জন্য `ptr` দ্বারা বরাদ্দকৃত বরাদ্দ বাড়িয়ে দিতে পারে।
    ///
    /// যদি এটি `Ok` প্রদান করে, তবে এক্স01 এক্স দ্বারা রেফারেন্সযুক্ত মেমরি ব্লকের মালিকানা এই বরাদ্দকারীর কাছে স্থানান্তরিত হয়েছে।
    /// মেমোরিটি মুক্তি পেয়েছে বা নাও হতে পারে এবং এ পদ্ধতির ফেরতের মানের মাধ্যমে আবার কলারের কাছে স্থানান্তর না করা না হলে এটি অকেজো হিসাবে বিবেচনা করা উচিত।
    ///
    /// যদি এই পদ্ধতিটি `Err` প্রদান করে, তবে মেমোরি ব্লকের মালিকানা এই বরাদ্দকারীর কাছে স্থানান্তরিত হয়নি এবং মেমরির ব্লকের বিষয়বস্তু অপরিবর্তিত রয়েছে।
    ///
    /// # Safety
    ///
    /// * `ptr` এই বরাদ্দকারীর মাধ্যমে মেমরি [*currently allocated*] এর একটি ব্লককে অবশ্যই বোঝানো উচিত।
    /// * `old_layout` মেমরির এই ব্লকটি অবশ্যই [*fit*] হওয়া উচিত (`new_layout` টি আর্গুমেন্ট এটি ফিট করতে হবে না))
    /// * `new_layout.size()` `old_layout.size()` এর চেয়ে বড় বা সমান হতে হবে।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// নতুন লেআউট যদি বরাদ্দকারীর আকার এবং প্রান্তিককরণের সীমাবদ্ধতাগুলি পূরণ না করে বা অন্যথায় বাড়তে ব্যর্থ হয় তবে `Err` প্রদান করে।
    ///
    /// বাস্তবায়নগুলি আতঙ্কিত বা বিসর্জন না দিয়ে মেমরি ক্লান্তিতে `Err` ফিরিয়ে আনতে উত্সাহিত করা হয়, তবে এটি কোনও কঠোর প্রয়োজন নয়।
    /// (বিশেষত: মেমরির অবসন্নতা অবলম্বন করে এমন একটি অন্তর্নিহিত নেটিভ বন্টন গ্রন্থাগারের উপরে এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করা আইনত * is)
    ///
    /// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক ক্লায়েন্টরা [`handle_alloc_error`] এক্স বা এর অনুরূপ সরাসরি অনুরোধ না করে [`handle_alloc_error`] ফাংশনটি কল করতে উত্সাহিত করা হয়।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // সুরক্ষা: কারণ `new_layout.size()` এর চেয়ে বড় বা সমান হতে হবে
        // `old_layout.size()`, পুরানো এবং নতুন উভয়ই মেমরির বরাদ্দ `old_layout.size()` বাইটের জন্য পড়ার জন্য এবং লেখার জন্য বৈধ।
        // এছাড়াও, যেহেতু পুরানো বরাদ্দটি এখনও অবনমিত হয়নি, এটি `new_ptr` কে ওভারল্যাপ করতে পারে না।
        // সুতরাং, `copy_nonoverlapping` এ কল নিরাপদ।
        // `dealloc` এর সুরক্ষা চুক্তি অবশ্যই কলার দ্বারা বহাল রাখা উচিত।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// এক্স00 এক্স এর মতো আচরণ করে তবে এটি নিশ্চিত করে যে নতুন সামগ্রীগুলি ফিরে আসার আগে শূন্যে সেট করা আছে।
    ///
    /// সফল কল করার পরে মেমরি ব্লকটিতে নিম্নলিখিত বিষয়বস্তু থাকবে
    /// `grow_zeroed`:
    ///   * বাইটস `0..old_layout.size()` মূল বরাদ্দ থেকে সংরক্ষণ করা হয়।
    ///   * বাইটস এক্স 100 এক্স বরাদ্দ বাস্তবায়নের উপর নির্ভর করে হয় সংরক্ষণ বা শূন্য হবে।
    ///   `old_size` `grow_zeroed` কলের আগে মেমরি ব্লকের আকারকে বোঝায়, যা বরাদ্দকালে মূলত অনুরোধ করা মাপের চেয়ে বড় হতে পারে।
    ///   * বাইটস এক্স 01 এক্স শূন্য করা হয়েছে।`new_size` `grow_zeroed` কল দ্বারা ফিরে আসা মেমরি ব্লকের আকারকে বোঝায়।
    ///
    /// # Safety
    ///
    /// * `ptr` এই বরাদ্দকারীর মাধ্যমে মেমরি [*currently allocated*] এর একটি ব্লককে অবশ্যই বোঝানো উচিত।
    /// * `old_layout` মেমরির এই ব্লকটি অবশ্যই [*fit*] হওয়া উচিত (`new_layout` টি আর্গুমেন্ট এটি ফিট করতে হবে না))
    /// * `new_layout.size()` `old_layout.size()` এর চেয়ে বড় বা সমান হতে হবে।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// নতুন লেআউট যদি বরাদ্দকারীর আকার এবং প্রান্তিককরণের সীমাবদ্ধতাগুলি পূরণ না করে বা অন্যথায় বাড়তে ব্যর্থ হয় তবে `Err` প্রদান করে।
    ///
    /// বাস্তবায়নগুলি আতঙ্কিত বা বিসর্জন না দিয়ে মেমরি ক্লান্তিতে `Err` ফিরিয়ে আনতে উত্সাহিত করা হয়, তবে এটি কোনও কঠোর প্রয়োজন নয়।
    /// (বিশেষত: মেমরির অবসন্নতা অবলম্বন করে এমন একটি অন্তর্নিহিত নেটিভ বন্টন গ্রন্থাগারের উপরে এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করা আইনত * is)
    ///
    /// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক ক্লায়েন্টরা [`handle_alloc_error`] এক্স বা এর অনুরূপ সরাসরি অনুরোধ না করে [`handle_alloc_error`] ফাংশনটি কল করতে উত্সাহিত করা হয়।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // সুরক্ষা: কারণ `new_layout.size()` এর চেয়ে বড় বা সমান হতে হবে
        // `old_layout.size()`, পুরানো এবং নতুন উভয়ই মেমরির বরাদ্দ `old_layout.size()` বাইটের জন্য পড়ার জন্য এবং লেখার জন্য বৈধ।
        // এছাড়াও, যেহেতু পুরানো বরাদ্দটি এখনও অবনমিত হয়নি, এটি `new_ptr` কে ওভারল্যাপ করতে পারে না।
        // সুতরাং, `copy_nonoverlapping` এ কল নিরাপদ।
        // `dealloc` এর সুরক্ষা চুক্তি অবশ্যই কলার দ্বারা বহাল রাখা উচিত।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// মেমরি ব্লক সঙ্কুচিত করার চেষ্টা।
    ///
    /// একটি পয়েন্টার এবং বরাদ্দ মেমরির আসল আকার ধারণ করে একটি নতুন [`NonNull<[u8]>`][NonNull] প্রদান করে।নির্দেশকটি `new_layout` দ্বারা বর্ণিত ডেটা ধরে রাখার জন্য উপযুক্ত।
    /// এটি সম্পাদন করতে, বরাদ্দকারী নতুন লেআউটে ফিট করতে `ptr` দ্বারা উল্লিখিত বরাদ্দ সঙ্কুচিত করতে পারে।
    ///
    /// যদি এটি `Ok` প্রদান করে, তবে এক্স01 এক্স দ্বারা রেফারেন্সযুক্ত মেমরি ব্লকের মালিকানা এই বরাদ্দকারীর কাছে স্থানান্তরিত হয়েছে।
    /// মেমোরিটি মুক্তি পেয়েছে বা নাও হতে পারে এবং এ পদ্ধতির ফেরতের মানের মাধ্যমে আবার কলারের কাছে স্থানান্তর না করা না হলে এটি অকেজো হিসাবে বিবেচনা করা উচিত।
    ///
    /// যদি এই পদ্ধতিটি `Err` প্রদান করে, তবে মেমোরি ব্লকের মালিকানা এই বরাদ্দকারীর কাছে স্থানান্তরিত হয়নি এবং মেমরির ব্লকের বিষয়বস্তু অপরিবর্তিত রয়েছে।
    ///
    /// # Safety
    ///
    /// * `ptr` এই বরাদ্দকারীর মাধ্যমে মেমরি [*currently allocated*] এর একটি ব্লককে অবশ্যই বোঝানো উচিত।
    /// * `old_layout` মেমরির এই ব্লকটি অবশ্যই [*fit*] হওয়া উচিত (`new_layout` টি আর্গুমেন্ট এটি ফিট করতে হবে না))
    /// * `new_layout.size()` `old_layout.size()` এর চেয়ে ছোট বা সমান হতে হবে।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// যদি নতুন লেআউট বরাদ্দকারীর আকার এবং প্রান্তিককরণের সীমাবদ্ধতাগুলি পূরণ না করে বা সঙ্কুচিত হয়ে অন্যথায় ব্যর্থ হয় তবে এক্স 100 এক্স প্রদান করে।
    ///
    /// বাস্তবায়নগুলি আতঙ্কিত বা বিসর্জন না দিয়ে মেমরি ক্লান্তিতে `Err` ফিরিয়ে আনতে উত্সাহিত করা হয়, তবে এটি কোনও কঠোর প্রয়োজন নয়।
    /// (বিশেষত: মেমরির অবসন্নতা অবলম্বন করে এমন একটি অন্তর্নিহিত নেটিভ বন্টন গ্রন্থাগারের উপরে এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করা আইনত * is)
    ///
    /// বরাদ্দ ত্রুটির প্রতিক্রিয়া হিসাবে গণনা বাতিল করতে ইচ্ছুক ক্লায়েন্টরা [`handle_alloc_error`] এক্স বা এর অনুরূপ সরাসরি অনুরোধ না করে [`handle_alloc_error`] ফাংশনটি কল করতে উত্সাহিত করা হয়।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // নিরাপদ: কারণ `new_layout.size()` এর চেয়ে কম বা সমান হতে হবে
        // `old_layout.size()`, পুরানো এবং নতুন উভয়ই মেমরির বরাদ্দ `new_layout.size()` বাইটের জন্য পড়ার জন্য এবং লেখার জন্য বৈধ।
        // এছাড়াও, যেহেতু পুরানো বরাদ্দটি এখনও অবনমিত হয়নি, এটি `new_ptr` কে ওভারল্যাপ করতে পারে না।
        // সুতরাং, `copy_nonoverlapping` এ কল নিরাপদ।
        // `dealloc` এর সুরক্ষা চুক্তি অবশ্যই কলার দ্বারা বহাল রাখা উচিত।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` এর এই উদাহরণের জন্য একটি "by reference" অ্যাডাপ্টার তৈরি করে।
    ///
    /// প্রত্যাবর্তিত অ্যাডাপ্টার `Allocator` প্রয়োগ করে এবং এটি সহজভাবে ধার করবে।
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}