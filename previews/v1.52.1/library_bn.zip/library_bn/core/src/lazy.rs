//! অলস মান এবং স্থিতিশীল ডেটার এককালীন সূচনা।

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// একটি কক্ষ যা কেবল একবারে লেখা যায়।
///
/// `RefCell` এর বিপরীতে, একটি `OnceCell` কেবল তার মানটির সাথে ভাগ করা `&T` রেফারেন্স সরবরাহ করে।
/// `Cell` এর বিপরীতে, একটি এক্স 01 এক্স এর অ্যাক্সেসের জন্য মানটি অনুলিপি করা বা প্রতিস্থাপনের প্রয়োজন হয় না।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // আক্রমণকারী: একবারে লিখিত
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// একটি নতুন ফাঁকা ঘর তৈরি করে।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// অন্তর্নিহিত মানটি উল্লেখ করে।
    ///
    /// সেলটি খালি থাকলে `None` প্রদান করে।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // সুরক্ষা: `অভ্যন্তরীণ'র আক্রমণকারী কারণে নিরাপদ
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// অন্তর্নিহিত মানটির জন্য পরিবর্তনীয় রেফারেন্স পান।
    ///
    /// সেলটি খালি থাকলে `None` প্রদান করে।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // নিরাপদ: নিরাপদ কারণ আমাদের অনন্য অ্যাক্সেস রয়েছে
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// কক্ষের সামগ্রীগুলি `value` এ সেট করুন।
    ///
    /// # Errors
    ///
    /// এই পদ্ধতিটি সেল খালি থাকলে `Ok(())` এবং পূর্ণ থাকলে `Err(value)` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // সুরক্ষা: নিরাপদ কারণ আমাদের ওভারল্যাপিং মিউটেবল orrowণ নিতে পারি না
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // নিরাপত্তা: এটিই একমাত্র জায়গা যেখানে আমরা স্লট সেট করেছিলাম, কোন রেস নেই
        // reentrancy/concurrency এর কারণে সম্ভব, এবং আমরা পরীক্ষা করেছি যে স্লটটি বর্তমানে `None`, তাই এই লেখায় "অভ্যন্তরীণ" এর আক্রমণকারীকে বজায় রাখা হয়।
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// ঘরটি খালি থাকলে `f` দিয়ে এটি সূচনা করে কক্ষের সামগ্রী সরবরাহ করে।
    ///
    /// # Panics
    ///
    /// যদি `f` panics, panic কলারের কাছে প্রচারিত হয় এবং সেলটি অবিচ্ছিন্ন থাকে।
    ///
    ///
    /// এক্স00 এক্স থেকে ঘরে পুনরায় তাত্ক্ষণিকভাবে আরম্ভ করা এটি একটি ত্রুটি।এটি করার ফলে একটি panic ফলাফল হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// ঘরটি খালি থাকলে `f` দিয়ে এটি সূচনা করে কক্ষের সামগ্রী সরবরাহ করে।
    /// সেলটি খালি থাকলে এবং `f` ব্যর্থ হলে একটি ত্রুটি ফিরে আসে।
    ///
    /// # Panics
    ///
    /// যদি `f` panics, panic কলারের কাছে প্রচারিত হয় এবং সেলটি অবিচ্ছিন্ন থাকে।
    ///
    ///
    /// এক্স00 এক্স থেকে ঘরে পুনরায় তাত্ক্ষণিকভাবে আরম্ভ করা এটি একটি ত্রুটি।এটি করার ফলে একটি panic ফলাফল হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // মনে রাখবেন যে *কিছু* প্রবর্তক সূচনার ফর্মগুলি ইউবি হতে পারে (দেখুন `reentrant_init` পরীক্ষা)।
        // আমি বিশ্বাস করি যে `set/get` রাখার সময় কেবল এই `assert` মুছে ফেলা ভাল হবে তবে পুরানো মানটি নিঃশব্দে ব্যবহার না করে panic এর চেয়ে ভাল মনে হয়।
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// মোড়ানো মানটি ফিরিয়ে সেলটি গ্রহণ করে।
    ///
    /// সেলটি খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` মান অনুসারে `self` নেয় বলে, সংকলকটি স্থিরভাবে যাচাই করে যে এটি বর্তমানে ধার করা হয়নি।
        // সুতরাং এটি `Option<T>` এ সরিয়ে নেওয়া নিরাপদ।
        self.inner.into_inner()
    }

    /// এই `OnceCell` এর বাইরে মানটি নিয়ে যায়, এটিকে আবার অবিশ্রুত অবস্থায় নিয়ে যায়।
    ///
    /// কোনও প্রভাব নেই এবং `None` প্রদান করে যদি `OnceCell` আরম্ভ না করা হয়।
    ///
    /// একটি পরিবর্তনীয় রেফারেন্স প্রয়োজনীয়তার মাধ্যমে সুরক্ষা গ্যারান্টিযুক্ত।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// একটি মান যা প্রথম অ্যাক্সেসে শুরু করা হয়।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   প্রস্তুত প্রস্তুত
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// প্রদত্ত সূচনা কার্যক্রমে একটি নতুন আলস্য মান তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// এই অলস মানের মূল্যায়নকে জোর করে এবং ফলাফলটির একটি রেফারেন্স দেয়।
    ///
    ///
    /// এটি `Deref` ইমপ্লের সমতুল্য, তবে এটি স্পষ্ট।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// আরম্ভের ফাংশন হিসাবে `Default` ব্যবহার করে একটি নতুন আলস্য মান তৈরি করে।
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}