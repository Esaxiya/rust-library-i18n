//! স্মৃতি নিয়ে কাজ করার জন্য বেসিক ফাংশন।
//!
//! এই মডিউলটিতে ধরণের আকার এবং প্রান্তিককরণ অনুসন্ধান করা, মেমরি আরম্ভ এবং ম্যানিপুলেট করার জন্য ফাংশন রয়েছে।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **এর ডেস্ট্রাক্টর না চালিয়ে মান** সম্পর্কে মালিকানা এবং "forgets" নেয়।
///
/// মানটি পরিচালনা করে এমন কোনও সংস্থান, যেমন হিপ মেমরি বা একটি ফাইল হ্যান্ডেল, অলঙ্ঘনীয় অবস্থায় চিরকাল স্থায়ী থাকবে।তবে, এটি গ্যারান্টি দেয় না যে এই মেমরিটির পয়েন্টারগুলি বৈধ থাকবে।
///
/// * আপনি যদি মেমরি ফাঁস করতে চান তবে [`Box::leak`] দেখুন।
/// * আপনি যদি মেমরির কোনও কাঁচা পয়েন্টার পেতে চান তবে [`Box::into_raw`] দেখুন।
/// * যদি আপনি কোনও মানটিকে সঠিকভাবে নিষ্পত্তি করতে চান, তার ডেস্ট্রাক্টরটি চালাচ্ছেন, এক্স00 এক্স দেখুন।
///
/// # Safety
///
/// `forget` `unsafe` হিসাবে চিহ্নিত নয়, কারণ Rust এর সুরক্ষা গ্যারান্টিতে কোনও গ্যারান্টি অন্তর্ভুক্ত নয় যা সর্বদা ধ্বংসকারীরা চলবে।
/// উদাহরণস্বরূপ, একটি প্রোগ্রাম [`Rc`][rc] ব্যবহার করে একটি রেফারেন্স চক্র তৈরি করতে পারে, বা এক্সস্ট্যাক্স এক্সকে ডেক্সট্রাক্টর ছাড়াই প্রস্থান করতে কল করতে পারে।
/// সুতরাং, নিরাপদ কোড থেকে `mem::forget` অনুমতি দেওয়া Rust এর সুরক্ষা গ্যারান্টিগুলিকে মৌলিকভাবে পরিবর্তন করে না।
///
/// এটি বলেছিল, মেমোরি বা I/O অবজেক্টের মতো রিসোর্সগুলি ফাঁস করা সাধারণত অনাকাঙ্ক্ষিত।
/// এফএফআই বা অনিরাপদ কোডের জন্য কিছু বিশেষায়িত ব্যবহারের ক্ষেত্রে প্রয়োজনীয়তাটি উপস্থিত হয় তবে এরপরেও [`ManuallyDrop`] সাধারণত পছন্দ হয়।
///
/// যেহেতু কোনও মান ভুলে যাওয়ার অনুমতি দেওয়া হয়েছে, আপনি যে কোনও এক্স 100 এক্স কোড লিখেছেন এটি এই সম্ভাবনার জন্য অবশ্যই অনুমতি দেবে।আপনি কোনও মান ফেরত দিতে পারবেন না এবং আশা করতে পারেন যে কলার অগত্যা মানটির ডেস্ট্রাক্টরটি চালাবেন।
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` এর আঞ্চলিক নিরাপদ ব্যবহার হল `Drop` trait দ্বারা বাস্তবায়িত কোনও মানের ডেস্ট্রাক্টরকে আটকানো।উদাহরণস্বরূপ, এটি একটি `File`, যেমন ফাঁস করবে
/// ভেরিয়েবল দ্বারা নেওয়া স্থানটি পুনরায় দাবি করুন তবে অন্তর্নিহিত সিস্টেমের সংস্থানটি কখনই বন্ধ করবেন না:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// অন্তর্নিহিত উত্সের মালিকানা আগে Rust এর বাইরে কোডে স্থানান্তরিত হয়েছিল, উদাহরণস্বরূপ, কাঁচা ফাইল বর্ণনাকারীকে সি কোডে স্থানান্তরিত করে এটি কার্যকর হয়।
///
/// # এক্স 100 এক্স এর সাথে সম্পর্ক
///
/// `mem::forget`*মেমরির* মালিকানা স্থানান্তর করতেও ব্যবহার করা যেতে পারে, এটি করা ত্রুটি-প্রবণ।
/// [`ManuallyDrop`] পরিবর্তে ব্যবহার করা উচিত।উদাহরণস্বরূপ, এই কোডটি বিবেচনা করুন:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` এর সামগ্রীগুলি ব্যবহার করে একটি `String` তৈরি করুন
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` লিক করুন কারণ এর মেমরিটি এখন `s` দ্বারা পরিচালিত হয়
/// mem::forget(v);  // ত্রুটি, ভি অবৈধ এবং কোনও ক্রিয়াকলাপে প্রেরণ করা উচিত নয়
/// assert_eq!(s, "Az");
/// // `s` স্পষ্টতই বাদ পড়েছে এবং এর স্মৃতিটি হ্রাস পেয়েছে।
/// ```
///
/// উপরোক্ত উদাহরণ সহ দুটি সমস্যা রয়েছে:
///
/// * যদি `String` নির্মাণ এবং `mem::forget()` এর আহ্বানের মধ্যে আরও কোড যুক্ত করা হয় তবে এর মধ্যে একটি panic এর দ্বিগুণ ফ্রি হতে পারে কারণ একই মেমরিটি `v` এবং `s` উভয়ই পরিচালনা করে।
/// * `v.as_mut_ptr()` কল করার পরে এবং ডেটার মালিকানাটি `s` এ স্থানান্তরিত করার পরে, `v` মানটি অবৈধ।
/// এমনকি যখন কোনও মান মাত্র `mem::forget` এ স্থানান্তরিত হয় (যা এটি পরিদর্শন করবে না), কিছু ধরণের মানগুলির কঠোর প্রয়োজনীয়তা থাকে যা ঝুঁকির সাথে বা মালিকানাধীন না হলে এগুলি অবৈধ করে তোলে।
/// কোনওভাবেই তাদের অবৈধ মানগুলি ব্যবহার করা, যাতে সেগুলিতে প্রেরণ বা ফাংশন থেকে তাদের ফিরিয়ে দেওয়া, অপরিজ্ঞাত আচরণ গঠন করে এবং সংকলক কর্তৃক করা অনুমানগুলি ভেঙে দিতে পারে।
///
/// `ManuallyDrop` এ স্যুইচ করা উভয় সমস্যা এড়ানো:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // আমরা `v` এর কাঁচা অংশগুলিতে বিচ্ছিন্ন করার আগে, নিশ্চিত হয়ে নিন যে এটি বাদ পড়েছে না!
/////
/// let mut v = ManuallyDrop::new(v);
/// // এখন এক্স00 এক্স বিযুক্ত করুন।এই ক্রিয়াকলাপগুলি panic করতে পারে না, তাই কোনও ফাঁস হতে পারে না।
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // অবশেষে, একটি `String` তৈরি করুন।
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` স্পষ্টতই বাদ পড়েছে এবং এর স্মৃতিটি হ্রাস পেয়েছে।
/// ```
///
/// `ManuallyDrop` দৃ double়ভাবে ডাবল-মুক্ত প্রতিরোধ করে কারণ আমরা অন্য কিছু করার আগে before v` এর ডেস্ট্রাক্টরকে অক্ষম করি।
/// `mem::forget()` এটি এর অনুমতি দেয় না কারণ এটি তার যুক্তিটি গ্রাস করে, `v` থেকে আমাদের প্রয়োজনীয় যে কোনও কিছু বের করার পরে কেবল আমাদের এটি কল করতে বাধ্য করে।
/// এমনকি যদি `ManuallyDrop` নির্মাণ এবং স্ট্রিং (যা দেখানো হিসাবে কোডটিতে ঘটতে পারে না) তৈরির মধ্যে একটি panic চালু করা হয়েছিল, তবে এটি ফাঁস হবে এবং ডাবল মুক্ত নয়।
/// অন্য কথায়, এক্স 200 এক্স ফাঁস হওয়ার পরিবর্তে ফাঁসির পরিবর্তে (ডাবল-) নেমে যাওয়ার পথে ভুল করে।
///
/// এছাড়াও, `ManuallyDrop` মালিকানাটি `s` এ স্থানান্তর করার পরে "touch" `v` হওয়া থেকে আমাদের বাধা দেয়-এর ডেস্ট্রাক্টর চালনা না করে নিষ্পত্তি করার জন্য `v` এর সাথে আলাপচারিতার চূড়ান্ত পদক্ষেপ সম্পূর্ণ এড়ানো যায়।
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] এর মতো তবে আনসাইজড মানগুলিও গ্রহণ করে।
///
/// `unsized_locals` বৈশিষ্ট্য স্থিতিশীল হয়ে উঠলে এই ফাংশনটি সরিয়ে ফেলার উদ্দেশ্যে কেবল শিহরিত।
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// বাইটের মধ্যে একটি ধরণের আকার প্রদান করে।
///
/// আরও সুনির্দিষ্টভাবে বলা যায়, এ্যালাইমেন্ট প্যাডিং সহ আইটেমের ধরণের সাথে অ্যারেটিতে ক্রমিক উপাদানগুলির মধ্যে এটি অফসেট।
///
/// সুতরাং, কোনও প্রকারের `T` এবং দৈর্ঘ্যের এক্স01 এক্সের জন্য, এক্স0 2 এক্স এর আকার `n * size_of::<T>()` রয়েছে।
///
/// সাধারণভাবে, কোনও ধরণের আকার সংকলন জুড়ে স্থিতিশীল নয়, তবে নির্দিষ্ট ধরণের যেমন আদিমগুলি।
///
/// নিম্নলিখিত টেবিলটি আদিমদের জন্য আকার দেয়।
///
/// প্রকার |আকার: :\<Type>()
/// ---- | ---------------
/// () |0 জেড0বুল0 জেড |1 এক্স 100 এক্স |1 এক্স01 এক্স |2 এক্স02 এক্স |4 এক্স03 এক্স |8 u128 |16 এক্স04 এক্স |1 এক্স05 এক্স |2 এক্স06 এক্স |4 এক্স07 এক্স |8 আই 128 |16 এক্স08 এক্স |4 এক্স09 এক্স |8 চর |ঘ
///
/// তদতিরিক্ত, `usize` এবং `isize` এর আকার একই।
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>`, এবং `Option<Box<T>>` প্রকারগুলির আকার একই রকম।
/// যদি এক্স01 এক্স আকারযুক্ত হয় তবে এই ধরণের সমস্তগুলিরই আকার `usize` এর মতো।
///
/// পয়েন্টারের পরিবর্তনের ফলে এর আকার পরিবর্তন হয় না।যেমন, `&T` এবং `&mut T` এর আকার একই।
/// তেমনিভাবে `*const T` এবং `* mut T` এর জন্য।
///
/// # `#[repr(C)]` আইটেমের আকার
///
/// আইটেমগুলির জন্য `C` উপস্থাপনার একটি সংজ্ঞায়িত বিন্যাস রয়েছে।
/// এই বিন্যাসটি সহ, সমস্ত ক্ষেত্রের স্থিতিশীল আকারের আকার পর্যন্ত আইটেমগুলির আকারও স্থিতিশীল।
///
/// ## স্ট্রাক্টের আকার
///
/// এক্স00 এক্স এর জন্য আকারটি নিম্নলিখিত অ্যালগরিদম দ্বারা নির্ধারিত হয়।
///
/// কাঠামোর প্রতিটি ক্ষেত্রের জন্য ঘোষণার আদেশ দ্বারা অর্ডার করা:
///
/// 1. ক্ষেত্রের আকার যুক্ত করুন।
/// 2. পরবর্তী আকারের [alignment] এর নিকটতম একাধিকটিতে বর্তমান আকারটিকে গোল করুন।
///
/// অবশেষে স্ট্রাক্টটির আকারটিকে তার [alignment] এর নিকটতম একাধিকতে গোল করুন।
/// কাঠামোর প্রান্তিককরণ সাধারণত এর সমস্ত ক্ষেত্রের বৃহত্তম প্রান্তিককরণ;এটি `repr(align(N))` ব্যবহার করে পরিবর্তন করা যেতে পারে।
///
/// `C` এর বিপরীতে শূন্য আকারের স্ট্রোকগুলি এক বাইট অবধি আকারে গোল হয় না।
///
/// ## এনমসের আকার
///
/// যে এনামগুলি বৈষম্যমূলক ব্যতীত অন্য কোনও ডেটা বহন করে না সেগুলির প্ল্যাটফর্মটিতে সি এনামগুলির সমান আকার থাকে for
///
/// ## ইউনিয়নের আকার
///
/// ইউনিয়নের আকার তার বৃহত্তম ক্ষেত্রের আকার।
///
/// `C` এর বিপরীতে, শূন্য আকারের ইউনিয়নগুলি আকারে এক বাইট অবধি গোল হয় না।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // কিছু আদিম
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // কিছু অ্যারে
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // পয়েন্টার আকারের সমতা
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// এক্স 100 এক্স ব্যবহার করা হচ্ছে।
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // প্রথম ক্ষেত্রের আকার 1, সুতরাং আকারে 1 যুক্ত করুন।আকার 1।
/// // দ্বিতীয় ক্ষেত্রের প্রান্তিককরণটি 2, তাই প্যাডিংয়ের জন্য আকারে 1 যুক্ত করুন।আকার 2।
/// // দ্বিতীয় ক্ষেত্রের আকার 2, সুতরাং আকারে 2 যোগ করুন।আকার 4।
/// // তৃতীয় ক্ষেত্রের প্রান্তিককরণ 1, সুতরাং প্যাডিংয়ের জন্য আকারে 0 যুক্ত করুন।আকার 4।
/// // তৃতীয় ক্ষেত্রের আকার 1, সুতরাং আকারে 1 যুক্ত করুন।আকার 5।
/// // অবশেষে, কাঠামোর সারিবদ্ধতা 2 (কারণ এর ক্ষেত্রগুলির মধ্যে বৃহত্তম সারিবদ্ধতা 2), সুতরাং প্যাডিংয়ের জন্য আকারে 1 যুক্ত করুন।
/// // আকার 6।
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // টুপল স্ট্রাক্ট একই নিয়ম অনুসরণ করে।
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // নোট করুন যে ক্ষেত্রগুলি পুনরায় সাজানোর ফলে আকার কমতে পারে।
/// // আমরা `second` এর আগে `third` রেখে উভয় প্যাডিং বাইটগুলি সরাতে পারি।
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ইউনিয়নের আকার বৃহত্তম ক্ষেত্রের আকার।
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// বাইটে পয়েন্ট-টু মানের আকার প্রদান করে।
///
/// এটি সাধারণত `size_of::<T>()` এর সমান।
/// যাইহোক, যখন `T`*এর* কোনও স্ট্যাটিকালি-পরিচিত আকার নেই, উদাহরণস্বরূপ, একটি স্লাইস [`[T]`][slice] বা একটি এক্স 100 এক্স, তখন গতিশীলভাবে পরিচিত আকার পেতে `size_of_val` ব্যবহার করা যেতে পারে।
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // নিরাপদ: `val` একটি রেফারেন্স, সুতরাং এটি একটি বৈধ কাঁচা পয়েন্টার
    unsafe { intrinsics::size_of_val(val) }
}

/// বাইটে পয়েন্ট-টু মানের আকার প্রদান করে।
///
/// এটি সাধারণত `size_of::<T>()` এর সমান।তবে, যখন `T`*এর* কোনও স্ট্যাটিকালি-পরিচিত আকার নেই, উদাহরণস্বরূপ, একটি স্লাইস [`[T]`][slice] বা একটি এক্স01 এক্স, তখন গতিশীলভাবে পরিচিত আকার পেতে `size_of_val_raw` ব্যবহার করা যেতে পারে।
///
/// # Safety
///
/// নিম্নলিখিত শর্তগুলি ধরে থাকলে এই ফাংশনটি কেবল কল করতে নিরাপদ:
///
/// - `T` যদি `Sized` হয় তবে এই ফাংশনটি কল করা সর্বদা নিরাপদ।
/// - যদি `T` এর আনসাইজড লেজটি হয়:
///     - একটি এক্স0১ এক্স, তারপরে স্লাইস লেজের দৈর্ঘ্য অবশ্যই একটি প্রাথমিক পূর্ণসংখ্যা এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই করা উচিত।
///     - একটি এক্স0১ এক্স, তারপরে পয়েন্টারের vtable অংশটি একটি আনসাইজিং জবরদস্তি দ্বারা অর্জিত বৈধ vtable এর দিকে নির্দেশ করতে হবে এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই করা উচিত।
///
///     - একটি (unstable) [extern type], তারপরে এই ফাংশনটি সর্বদা কল করা নিরাপদ তবে panic বা অন্যথায় ভুল মানটি ফিরে আসতে পারে, কারণ বাহ্যিক ধরণের লেআউটটি জানা যায়নি।
///     বহিরাগত ধরণের লেজের সাথে কোনও প্রকারের রেফারেন্সে এটি [`size_of_val`] এর মতো একই আচরণ।
///     - অন্যথায়, রক্ষণশীলভাবে এই ফাংশনটি কল করার অনুমতি নেই।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // সুরক্ষা: কলকারীকে অবশ্যই একটি বৈধ কাঁচা পয়েন্টার সরবরাহ করতে হবে
    unsafe { intrinsics::size_of_val(val) }
}

/// [এবিআই] প্রত্যাশিত কোনও প্রকারের ন্যূনতম প্রান্তিককরণটি দেয়।
///
/// প্রকারের `T` মানের প্রতিটি রেফারেন্স অবশ্যই এই সংখ্যার একাধিক হতে হবে।
///
/// এটি স্ট্রাক্ট ক্ষেত্রগুলির জন্য ব্যবহৃত প্রান্তিককরণ।এটি পছন্দসই প্রান্তিককরণের চেয়ে ছোট হতে পারে।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` নির্দেশিত মানের ধরণের ন্যূনতম প্রান্তিককরণের [ABI] ফেরত দেয়।
///
/// প্রকারের `T` মানের প্রতিটি রেফারেন্স অবশ্যই এই সংখ্যার একাধিক হতে হবে।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // সুরক্ষা: ভাল একটি রেফারেন্স, সুতরাং এটি একটি বৈধ কাঁচা পয়েন্টার
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [এবিআই] প্রত্যাশিত কোনও প্রকারের ন্যূনতম প্রান্তিককরণটি দেয়।
///
/// প্রকারের `T` মানের প্রতিটি রেফারেন্স অবশ্যই এই সংখ্যার একাধিক হতে হবে।
///
/// এটি স্ট্রাক্ট ক্ষেত্রগুলির জন্য ব্যবহৃত প্রান্তিককরণ।এটি পছন্দসই প্রান্তিককরণের চেয়ে ছোট হতে পারে।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` নির্দেশিত মানের ধরণের ন্যূনতম প্রান্তিককরণের [ABI] ফেরত দেয়।
///
/// প্রকারের `T` মানের প্রতিটি রেফারেন্স অবশ্যই এই সংখ্যার একাধিক হতে হবে।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // সুরক্ষা: ভাল একটি রেফারেন্স, সুতরাং এটি একটি বৈধ কাঁচা পয়েন্টার
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` নির্দেশিত মানের ধরণের ন্যূনতম প্রান্তিককরণের [ABI] ফেরত দেয়।
///
/// প্রকারের `T` মানের প্রতিটি রেফারেন্স অবশ্যই এই সংখ্যার একাধিক হতে হবে।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// নিম্নলিখিত শর্তগুলি ধরে থাকলে এই ফাংশনটি কেবল কল করতে নিরাপদ:
///
/// - `T` যদি `Sized` হয় তবে এই ফাংশনটি কল করা সর্বদা নিরাপদ।
/// - যদি `T` এর আনসাইজড লেজটি হয়:
///     - একটি এক্স0১ এক্স, তারপরে স্লাইস লেজের দৈর্ঘ্য অবশ্যই একটি প্রাথমিক পূর্ণসংখ্যা এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই করা উচিত।
///     - একটি এক্স0১ এক্স, তারপরে পয়েন্টারের vtable অংশটি একটি আনসাইজিং জবরদস্তি দ্বারা অর্জিত বৈধ vtable এর দিকে নির্দেশ করতে হবে এবং *সম্পূর্ণ মান*(গতিশীল লেজের দৈর্ঘ্য + স্ট্যাটিক আকারের উপসর্গ) এর আকার অবশ্যই `isize` এ মাপসই করা উচিত।
///
///     - একটি (unstable) [extern type], তারপরে এই ফাংশনটি সর্বদা কল করা নিরাপদ তবে panic বা অন্যথায় ভুল মানটি ফিরে আসতে পারে, কারণ বাহ্যিক ধরণের লেআউটটি জানা যায়নি।
///     বহিরাগত ধরণের লেজের সাথে কোনও প্রকারের রেফারেন্সে এটি [`align_of_val`] এর মতো একই আচরণ।
///     - অন্যথায়, রক্ষণশীলভাবে এই ফাংশনটি কল করার অনুমতি নেই।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // সুরক্ষা: কলকারীকে অবশ্যই একটি বৈধ কাঁচা পয়েন্টার সরবরাহ করতে হবে
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` প্রকারের মান বাদ দিলে `true` প্রদান করে।
///
/// এটি নিখুঁতভাবে একটি অপ্টিমাইজেশনের ইঙ্গিত, এবং এটি রক্ষণশীলভাবে প্রয়োগ করা যেতে পারে:
/// এটি এমন ধরণের জন্য `true` ফেরত আসতে পারে যা আসলে বাদ দেওয়ার দরকার নেই।
/// যেমন সর্বদা `true` ফেরত দেওয়া এই ফাংশনটির বৈধ বাস্তবায়ন হবে।তবে যদি এই ফাংশনটি আসলে `false` ফেরত দেয় তবে আপনি নিশ্চিত হতে পারেন যে `T` ছাড়ার কোনও পার্শ্ব প্রতিক্রিয়া নেই।
///
/// সংগ্রহের মতো জিনিসগুলির নিম্ন স্তরের বাস্তবায়ন, যার ম্যানুয়ালি তাদের ডেটা ড্রপ করা দরকার, অকারণে তাদের সমস্ত বিষয়বস্তু নষ্ট হয়ে যাওয়ার চেষ্টা না করার জন্য এই ফাংশনটি ব্যবহার করা উচিত।
///
/// এটি রিলিজ বিল্ডগুলিতে কোনও পার্থক্য তৈরি করতে পারে না (যেখানে কোনও লুপের কোনও পার্শ্ব-প্রতিক্রিয়া নেই সহজেই সনাক্ত এবং নির্মূল করা যায়) তবে এটি প্রায়শই ডিবাগ বিল্ডগুলির জন্য একটি বড় জয়।
///
/// নোট করুন যে [`drop_in_place`] ইতিমধ্যে এই চেকটি সম্পাদন করে, তাই যদি আপনার কাজের চাপটি কিছু অল্প সংখ্যক [`drop_in_place`] কলকে হ্রাস করা যায় তবে এটি ব্যবহার করা অপ্রয়োজনীয়।
/// বিশেষভাবে নোট করুন যে আপনি একটি স্লাইস [`drop_in_place`] করতে পারেন, এবং এটি সমস্ত মানগুলির জন্য একক প্রয়োজন_ড্রোড চেক করবে।
///
/// ভেকের মতো প্রকারগুলি তাই `needs_drop` স্পষ্টভাবে ব্যবহার না করে কেবল `drop_in_place(&mut self[..])`।
/// অন্যদিকে [`HashMap`] এর মতো ধরণগুলিতে একবারে মানগুলি ফেলে দিতে হবে এবং এই API টি ব্যবহার করা উচিত।
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// কোনও সংগ্রহ কীভাবে `needs_drop` ব্যবহার করতে পারে তার উদাহরণ এখানে রয়েছে:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ডেটা ফেলে দিন
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// সমস্ত শূন্য বাইট-প্যাটার্ন দ্বারা প্রতিনিধিত্ব করে `T` প্রকারের মানটি প্রদান করে।
///
/// এর অর্থ হল, উদাহরণস্বরূপ, `(u8, u16)` এ প্যাডিং বাইট অগত্যা শূন্য নয়।
///
/// কোনও গ্যারান্টি নেই যে একটি অল-শূন্য বাইট-প্যাটার্নটি কোনও প্রকারের `T` এর বৈধ মানকে উপস্থাপন করে।
/// উদাহরণস্বরূপ, সমস্ত শূন্য বাইট-প্যাটার্নটি রেফারেন্স ধরণের (`&T`, `&mut T`) এবং ফাংশন পয়েন্টারগুলির জন্য একটি কার্যকর মান নয়।
/// এই জাতীয় ধরণের উপর `zeroed` ব্যবহারের ফলে তাত্ক্ষণিক [undefined behavior][ub] হয় কারণ [the Rust compiler assumes][inv] যে সর্বদা একটি ভেরিয়েবলের বৈধ মান থাকে যা এটি আরম্ভকৃত বলে মনে করে।
///
///
/// এটি [`MaybeUninit::zeroed().assume_init()`][zeroed] এর মতো একই প্রভাব ফেলে।
/// এটি কখনও কখনও এফএফআইয়ের জন্য দরকারী, তবে সাধারণত এড়ানো উচিত।
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// এই ফাংশনটির সঠিক ব্যবহার: শূন্য দিয়ে পূর্ণসংখ্যা শুরু করা।
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// এই ফাংশনের *ভুল* ব্যবহার: শূন্যের সাথে একটি রেফারেন্স সূচনা করা।
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // নির্ধারিত আচরণ!
/// let _y: fn() = unsafe { mem::zeroed() }; // এবং আবার!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // নিরাপদ: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে সমস্ত শূন্যের মান `T` এর জন্য বৈধ।
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// মোটেও কিছুই না করে জেড 0 রুস্ট0 জেড এর সাধারণ মেমোরি-ইনিশিয়ালাইজেশন চেক করে `T` টাইপের মান উত্পন্ন করার ভান করে পরীক্ষা করে।
///
/// **এই ফাংশনটি অবচিত করা হয়েছে*** পরিবর্তে [`MaybeUninit<T>`] ব্যবহার করুন।
///
/// অবমূল্যায়নের কারণ হ'ল মূলত ফাংশনটি সঠিকভাবে ব্যবহার করা যায় না: এটির এক্সএক্সএক্সের মতো একই প্রভাব রয়েছে।
///
/// [`assume_init` documentation][assume_init] ব্যাখ্যা হিসাবে, [the Rust compiler assumes][inv] যে মানগুলি সঠিকভাবে শুরু হয়।
/// ফলস্বরূপ, ডাকা যেমন
/// `mem::uninitialized::<bool>()` `bool` ফিরিয়ে দেওয়ার জন্য তাত্ক্ষণিক অপরিজ্ঞাত আচরণের কারণ হয়ে থাকে যা অবশ্যই `true` বা `false` নয়।
/// আরও খারাপ, সত্যিকার অর্থে অবিরাম মেমরিটি এখানে ফিরে আসে তার জন্য বিশেষ যে সংকলকটি জানে যে এটির একটি নির্দিষ্ট মান নেই।
/// এটি ভেরিয়েবলের পূর্ণসংখ্যার ধরণের হলেও ভেরিয়েবলটিতে অবিচ্ছিন্ন ডেটা রাখা এটিকে নির্ধারিত আচরণ করে makes
/// (লক্ষ করুন যে অবিচ্ছিন্ন পূর্ণসংখ্যার চার্জের নিয়মগুলি এখনও চূড়ান্ত হয়নি, তবে যতক্ষণ না এটি হওয়া উচিত সেগুলি এড়ানো উচিত))
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে একটি ইউনিটযুক্ত মানটি `T` এর জন্য বৈধ।
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// দুটির পরিবর্তিত স্থানে মানগুলি অদলবদল করে, একটিরও বিন্যাস ছাড়াই।
///
/// * আপনি যদি কোনও ডিফল্ট বা ডামি মান নিয়ে অদলবদল করতে চান তবে এক্স00 এক্স দেখুন।
/// * আপনি যদি পুরানো মানটি ফিরিয়ে দিয়ে কোনও পাস করা মান নিয়ে অদলবদল করতে চান তবে এক্স00 এক্স দেখুন।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // সুরক্ষা: কাঁচা পয়েন্টারগুলি সমস্ত সন্তুষ্ট করে নিরাপদ পরিবর্তনযোগ্য রেফারেন্সগুলি থেকে তৈরি করা হয়েছে
    // `ptr::swap_nonoverlapping_one` এ সীমাবদ্ধতা
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `T` এক্সকে ডিফল্ট মান `T` এর সাথে প্রতিস্থাপিত করে, পূর্ববর্তী `dest` মানটি ফিরিয়ে দেয়।
///
/// * আপনি যদি দুটি ভেরিয়েবলের মানগুলি প্রতিস্থাপন করতে চান তবে [`swap`] দেখুন।
/// * আপনি যদি ডিফল্ট মানের পরিবর্তে পাস করা মান দিয়ে প্রতিস্থাপন করতে চান তবে [`replace`] দেখুন।
///
/// # Examples
///
/// একটি সহজ উদাহরণ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` কোনও স্ট্রাক্ট ক্ষেত্রের একটি "empty" মান দিয়ে এটি প্রতিস্থাপনের মালিকানার অনুমতি দেয়।
/// `take` ছাড়াই আপনি এই জাতীয় সমস্যার মধ্যে চলে যেতে পারেন:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// দ্রষ্টব্য যে `T` অগত্যা [`Clone`] বাস্তবায়িত করে না, তাই এটি এক্স 00 এক্স ক্লোন করে পুনরায় সেট করতেও পারে না।
/// তবে `take` এটি `self` থেকে `self.buf` এর মূল মানটি বিচ্ছিন্ন করতে ব্যবহার করা যেতে পারে, এটির ফিরে আসার সুযোগ দিয়ে:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// পূর্ববর্তী `dest` মানটি ফিরিয়ে `src` কে রেফারেন্স করা `dest` এ স্থানান্তরিত করে।
///
/// কোনও মানই বাদ যায় না।
///
/// * আপনি যদি দুটি ভেরিয়েবলের মানগুলি প্রতিস্থাপন করতে চান তবে [`swap`] দেখুন।
/// * আপনি যদি কোনও ডিফল্ট মান দিয়ে প্রতিস্থাপন করতে চান তবে [`take`] দেখুন।
///
/// # Examples
///
/// একটি সহজ উদাহরণ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` স্ট্রাক্ট ক্ষেত্রটিকে অন্য মান দিয়ে প্রতিস্থাপনের মাধ্যমে ব্যবহারের অনুমতি দেয়।
/// `replace` ছাড়াই আপনি এই জাতীয় সমস্যার মধ্যে চলে যেতে পারেন:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// দ্রষ্টব্য যে `T` অগত্যা [`Clone`] বাস্তবায়িত করে না, তাই আমরা সরানো এড়াতে `self.buf[i]` এমনকি ক্লোন করতে পারি না।
/// তবে এক্স01 এক্সকে এই সূচকটিতে `self` থেকে মূল মানটি বিচ্ছিন্ন করতে ব্যবহার করা যেতে পারে, এটি ফেরত দেওয়ার অনুমতি দিয়ে:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // সুরক্ষা: আমরা `dest` থেকে পড়েছি তবে এর মধ্যে সরাসরি `src` লিখি,
    // যেমন পুরানো মান সদৃশ হয় না।
    // কিছুই বাদ যায় না এবং এখানে কিছুই panic করতে পারে না।
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// একটি মান নিষ্পত্তি।
///
/// এটি যুক্তিটির [`Drop`][drop] এর বাস্তবায়নকে কল করে does
///
/// এটি কার্যকরভাবে `Copy` প্রয়োগকারী প্রকারের জন্য কিছুই করে না, যেমন
/// integers.
/// এই জাতীয় মানগুলি অনুলিপি করা হয় এবং _then_ ফাংশনে স্থানান্তরিত হয়, সুতরাং এই ফাংশন কলের পরেও মানটি টিকে থাকে।
///
///
/// এই ফাংশনটি যাদু নয়;এটি আক্ষরিক হিসাবে সংজ্ঞায়িত করা হয়
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` ফাংশনে স্থানান্তরিত হওয়ায় ফাংশনটি ফিরে আসার আগে এটি স্বয়ংক্রিয়ভাবে বাদ পড়ে যায়।
///
/// [drop]: Drop
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // স্পষ্টত vector বাদ দিন
/// ```
///
/// যেহেতু [`RefCell`] রানটাইম সময়ে orrowণ সংক্রান্ত নিয়ম কার্যকর করে, তাই `drop` একটি এক্স0 2 এক্স releaseণ প্রকাশ করতে পারে:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // এই স্লটে পরিবর্তনীয় orrowণ ত্যাগ করুন
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] প্রয়োগকারী পূর্ণসংখ্যা এবং অন্যান্য ধরণেরগুলি `drop` দ্বারা প্রভাবিত নয়।
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` এর একটি অনুলিপি স্থানান্তরিত এবং বাদ দেওয়া হয়
/// drop(y); // `y` এর একটি অনুলিপি স্থানান্তরিত এবং বাদ দেওয়া হয়
///
/// println!("x: {}, y: {}", x, y.0); // এখনও লভ্য
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// এক্স 100 এক্সকে এক্স 100 এক্স টাইপ হিসাবে ব্যাখ্যা করে এবং তারপরে থাকা মানটি না সরিয়ে `src` পড়ে।
///
/// এই ফাংশনটি নিরাপদে `src` এক্স এক্স 2 এক্স এক্স এক্স 3 এক্স ট্রান্সমিশন করে এবং তারপরে এক্স04 এক্স পড়ে [`size_of::<U>`][size_of] বাইটের জন্য X0X বৈধ বলে ধরে নেওয়া হবে (`&U` `&T` এর তুলনায় কঠোর প্রান্তিককরণের প্রয়োজনীয়তা তৈরি করার পরেও এটি এমনভাবে করা হয় যেটি ব্যতীত)।
/// এটি নিরাপদে `src` এর বাইরে চলে যাওয়ার পরিবর্তে থাকা মানটির অনুলিপি তৈরি করবে।
///
/// `T` এবং `U` এর বিভিন্ন আকার থাকলে এটি একটি সংকলন-সময় ত্রুটি নয়, তবে `T` এবং `U` একই আকারের যেখানে কেবল এই ফাংশনটি চালিত করতে এটি উত্সাহিত করা হয়।`U` যদি `T` এর চেয়ে বড় হয় তবে এই ফাংশনটি [undefined behavior][ub] ট্রিগার করে।
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' থেকে ডেটা অনুলিপি করুন এবং এটিকে 'Foo' হিসাবে গণ্য করুন
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // অনুলিপি করা ডেটা পরিবর্তন করুন
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' এর সামগ্রীগুলি পরিবর্তন করা উচিত হয়নি
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // যদি U এর উচ্চতর সারিবদ্ধকরণের প্রয়োজনীয়তা থাকে তবে src উপযুক্তভাবে প্রান্তিক নাও হতে পারে।
    if align_of::<U>() > align_of::<T>() {
        // সুরক্ষা: `src` একটি উল্লেখ যা পাঠকদের জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        // কলকারীকে নিশ্চয়তা দিতে হবে যে প্রকৃত রূপান্তর নিরাপদ।
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // সুরক্ষা: `src` একটি উল্লেখ যা পাঠকদের জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        // আমরা সন্ধান করেছি যে `src as *const U` সঠিকভাবে প্রান্তিক করা হয়েছে।
        // কলকারীকে নিশ্চয়তা দিতে হবে যে প্রকৃত রূপান্তর নিরাপদ।
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// একটি এনামের বৈষম্যমূলক প্রতিনিধিত্ব করে ওপ্পিক টাইপ।
///
/// আরও তথ্যের জন্য এই মডিউলে [`discriminant`] ফাংশনটি দেখুন।
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. এই trait বাস্তবায়নগুলি উত্পন্ন করা যাবে না কারণ আমরা টি তে কোনও সীমানা চাই না we

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` এ এনাম বৈকল্পিক সনাক্তকরণের জন্য অনন্যভাবে একটি মান ফেরত দেয়।
///
/// যদি এক্স 100 এক্স কোনও এনাম না হয় তবে এই ফাংশনটি কল করার ফলে অনির্ধারিত আচরণের ফল পাওয়া যাবে না, তবে ফেরতের মান নির্ধারিত।
///
///
/// # Stability
///
/// এনাম সংজ্ঞা পরিবর্তিত হলে এনাম বৈকল্পিকের বৈষম্যমূলক পরিবর্তন হতে পারে।
/// কিছু বৈকল্পিকের বৈষম্যমূলক একই সংকলক সহ সংকলনের মধ্যে পরিবর্তন হবে না।
///
/// # Examples
///
/// প্রকৃত ডেটা উপেক্ষা করার সময় ডেটা বহনকারী এনামগুলির সাথে তুলনা করতে এটি ব্যবহার করা যেতে পারে:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// এনাম টাইপ `T` এ ভেরিয়েন্টের সংখ্যা প্রদান করে।
///
/// যদি এক্স 100 এক্স কোনও এনাম না হয় তবে এই ফাংশনটি কল করার ফলে অনির্ধারিত আচরণের ফল পাওয়া যাবে না, তবে ফেরতের মান নির্ধারিত।
/// একইভাবে, যদি `T` `usize::MAX` এর চেয়ে বেশি বৈকল্পিক সহ একটি এনাম হয় তবে ফেরতের মান নির্ধারিত হয়।
/// অব্যাহত রূপগুলি গণনা করা হবে।
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}