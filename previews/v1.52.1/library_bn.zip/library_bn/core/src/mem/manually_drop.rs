use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// স্বয়ংক্রিয়ভাবে `T` এর ডেস্ট্রাক্টর কল করা থেকে সংকলককে বাধা দেওয়ার জন্য একটি মোড়ক।
/// এই মোড়ক 0-দামের।
///
/// `ManuallyDrop<T>` `T` হিসাবে একই লেআউট অপ্টিমাইজেশনের সাপেক্ষে।
/// ফলস্বরূপ, সংকলকটি এর বিষয়বস্তুগুলি নিয়ে যে অনুমান করে তাতে এর কোনও প্রভাব নেই।
/// উদাহরণস্বরূপ, [`mem::zeroed`] দিয়ে একটি `ManuallyDrop<&mut T>` আরম্ভ করা অনির্ধারিত আচরণ।
/// আপনার যদি অনির্দেশিত ডেটা হ্যান্ডেল করতে হয় তবে তার পরিবর্তে [`MaybeUninit<T>`] ব্যবহার করুন।
///
/// নোট করুন যে কোনও `ManuallyDrop<T>` এর মধ্যে মান অ্যাক্সেস করা নিরাপদ।
/// এর অর্থ হ'ল এমন একটি `ManuallyDrop<T>` যার বিষয়বস্তু ফেলে দেওয়া হয়েছে অবশ্যই সর্বজনীন নিরাপদ API এর মাধ্যমে প্রকাশ করা উচিত নয়।
/// অনুসারে, `ManuallyDrop::drop` অনিরাপদ।
///
/// # `ManuallyDrop` এবং ড্রপ অর্ডার।
///
/// Rust এর মানগুলির একটি সুস্পষ্ট সংজ্ঞাযুক্ত [drop order] রয়েছে।
/// ক্ষেত্র বা স্থানীয়দের একটি নির্দিষ্ট ক্রমে ফেলে দেওয়া হয়েছে তা নিশ্চিত করার জন্য, ঘোষণাগুলি পুনরায় অর্ডার করুন যাতে অন্তর্ভুক্ত ড্রপ অর্ডারটি সঠিক one
///
/// ড্রপ অর্ডার নিয়ন্ত্রণ করতে `ManuallyDrop` ব্যবহার করা সম্ভব, তবে এটির জন্য অনিরাপদ কোড দরকার এবং আনওয়াইন্ডিংয়ের উপস্থিতিতে সঠিকভাবে করা শক্ত।
///
///
/// উদাহরণস্বরূপ, আপনি যদি নিশ্চিত করতে চান যে অন্যের পরে একটি নির্দিষ্ট ক্ষেত্র বাদ পড়েছে তবে এটিকে কাঠামোর শেষ ক্ষেত্র করুন:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` এর পরে বাদ দেওয়া হবে।
///     // জেড 0 রিস্ট0 জেড গ্যারান্টি দেয় যে ক্ষেত্রগুলি ঘোষণার ক্রম হিসাবে বাদ পড়ে।
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ম্যানুয়ালি বাদ দিতে হবে এমন কোনও মান rapেকে রাখুন।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // আপনি এখনও মানটির সাথে নিরাপদে পরিচালনা করতে পারেন
    /// assert_eq!(*x, "Hello");
    /// // তবে `Drop` এখানে চালানো হবে না
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` ধারক থেকে মানটি বের করে।
    ///
    /// এটি মানটিকে আবার বাদ দিতে দেয়।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // এটি `Box` ছাড়বে।
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// এক্স 100 এক্স ধারক থেকে মান নেয়।
    ///
    /// এই পদ্ধতিটি প্রাথমিকভাবে ড্রপে মানগুলি সরিয়ে নেওয়ার জন্য তৈরি।
    /// মানটিকে ম্যানুয়ালি ড্রপ করতে [`ManuallyDrop::drop`] ব্যবহার করার পরিবর্তে, আপনি মানটি নিতে এবং পছন্দসইভাবে ব্যবহার করতে এই পদ্ধতিটি ব্যবহার করতে পারেন।
    ///
    /// যখনই সম্ভব, এর পরিবর্তে [`into_inner`][`ManuallyDrop::into_inner`] ব্যবহার করা ভাল, যা `ManuallyDrop<T>` এর সামগ্রীটিকে নকল করতে বাধা দেয়।
    ///
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি এই ব্যবহারকারীর অবস্থা অপরিবর্তিত রেখে, আরও ব্যবহার রোধ না করে অন্তর্ভুক্ত মানটিকে শব্দার্থভাবে সরিয়ে দেয়।
    /// এই `ManuallyDrop` আবার ব্যবহার করা হবে না তা নিশ্চিত করা আপনার দায়িত্ব।
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // সুরক্ষা: আমরা একটি রেফারেন্স থেকে পড়ছি, যার নিশ্চয়তা রয়েছে
        // পড়ার জন্য বৈধ হতে।
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ম্যানুয়ালি থাকা মানটি ড্রপ করে।এটি অন্তর্ভুক্ত মানের একটি পয়েন্টার সহ [`ptr::drop_in_place`] কল করার ঠিক সমান।
    /// যেমন, অন্তর্ভুক্ত মানটি কোনও প্যাকড স্ট্রাক্ট না হলে ডিস্ট্রাক্টরকে মান সরিয়ে না নিয়ে জায়গায় জায়গায় ডাকা হবে এবং এভাবে [pinned] ডেটা নিরাপদে ফেলে দিতে ব্যবহার করা যেতে পারে।
    ///
    /// যদি মানটির মালিকানা থাকে তবে আপনি পরিবর্তে [`ManuallyDrop::into_inner`] ব্যবহার করতে পারেন।
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি অন্তর্ভুক্ত মানের ডেস্ট্রাক্টরকে চালায়।
    /// ডেস্ট্রাক্টর নিজেই করা পরিবর্তনগুলি ব্যতীত, স্মৃতিটি অপরিবর্তিত রেখে যায় এবং তাই সংকলকটি এখনও একটি বিট-প্যাটার্ন ধারণ করে যা `T` টাইপের জন্য বৈধ।
    ///
    ///
    /// তবে, এই "zombie" মানটি নিরাপদ কোডে প্রকাশ করা উচিত নয় এবং এই ফাংশনটি একাধিকবার কল করা উচিত নয়।
    /// নাম বাদ পড়ার পরে কোনও মান ব্যবহার করার জন্য, বা একাধিকবার একটি মান ফেলে দেওয়ার ফলে অপরিজ্ঞাত আচরণের কারণ হতে পারে (`drop` কী করবে তার উপর নির্ভর করে)।
    /// এটি সাধারণত টাইপ সিস্টেম দ্বারা প্রতিরোধ করা হয়, তবে `ManuallyDrop` এর ব্যবহারকারীগণকে সংকলকটির সহায়তা ছাড়াই এই গ্যারান্টিগুলি বহন করতে হবে।
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // নিরাপদ: আমরা একটি পরিবর্তনীয় রেফারেন্স দ্বারা নির্দেশিত মান বাদ দিচ্ছি
        // যা লেখার জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        // এক্স00 এক্স আবার বাদ পড়েছে না তা নিশ্চিত করা কলারের উপর নির্ভর করে।
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}