use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// এক্স00 এক্স এর অবিচ্ছিন্ন দৃষ্টান্ত তৈরি করতে একটি মোড়কের প্রকার।
///
/// # প্রারম্ভিক আক্রমণ
///
/// সংকলক, সাধারণভাবে, ধরে নেয় যে ভেরিয়েবলের ধরণের প্রয়োজনীয়তা অনুসারে একটি পরিবর্তনশীল সঠিকভাবে শুরু হয়।উদাহরণস্বরূপ, রেফারেন্স টাইপের একটি পরিবর্তনশীল অবশ্যই প্রান্তিককরণ এবং নন-নুল হতে হবে।
/// এটি এমন একটি আক্রমণকারী যা অবশ্যই অনিরাপদ কোডেও *সর্বদা* বহাল থাকবে।
/// ফলস্বরূপ, রেফারেন্সের ধরণের শূন্য-সূচনাটি তাত্ক্ষণিক [undefined behavior][ub] এর কারণ হয়ে দাঁড়ায়, সেই রেফারেন্সটি মেমরি অ্যাক্সেস করতে কখনও ব্যবহৃত হয় কিনা তা বিবেচনা করে নয়:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // অপরিবর্তিত আচরণ!⚠️
/// // `MaybeUninit<&i32>` সমতুল্য কোড:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // অপরিবর্তিত আচরণ!⚠️
/// ```
///
/// এটি বিভিন্ন অপ্টিমাইজেশনের জন্য সংকলক দ্বারা শোষণ করা হয়েছে, যেমন রান-টাইম চেকগুলি এলিডিং করা এবং `enum` লেআউটটি অনুকূল করা।
///
/// একইভাবে, সম্পূর্ণ অবিচ্ছিন্ন মেমরির কোনও সামগ্রী থাকতে পারে, যখন একটি `bool` সর্বদা `true` বা `false` হওয়া উচিত।অতএব, একটি অবিচ্ছিন্ন `bool` তৈরি করা অনির্ধারিত আচরণ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // অপরিবর্তিত আচরণ!⚠️
/// // `MaybeUninit<bool>` সমতুল্য কোড:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // অপরিবর্তিত আচরণ!⚠️
/// ```
///
/// তদ্ব্যতীত, অবিচ্ছিন্ন মেমরিটি বিশেষ যে এটির একটি নির্দিষ্ট মান নেই ("fixed" যার অর্থ "it won't change without being written to")।একই অবিচ্ছিন্ন বাইট একাধিকবার পড়া বিভিন্ন ফলাফল দিতে পারে।
/// এটি ভেরিয়েবলের অবিচ্ছিন্ন ডেটা রাখা অপরিজ্ঞাত আচরণকে এমন করে তোলে যে এমনকি যদি সেই ভেরিয়েবলটির একটি পূর্ণসংখ্যা থাকে, যা অন্যথায় কোনও *স্থির* বিট প্যাটার্ন ধরে রাখতে পারে:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // অপরিবর্তিত আচরণ!⚠️
/// // `MaybeUninit<i32>` সমতুল্য কোড:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // অপরিবর্তিত আচরণ!⚠️
/// ```
/// (লক্ষ করুন যে অবিচ্ছিন্ন পূর্ণসংখ্যার চার্জের নিয়মগুলি এখনও চূড়ান্ত হয়নি, তবে যতক্ষণ না এটি হওয়া উচিত সেগুলি এড়ানো উচিত))
///
/// তার উপরে, মনে রাখবেন যে বেশিরভাগ ধরণের কেবলমাত্র টাইপ স্তরে প্রাথমিক বিবেচনা করা ছাড়াও অতিরিক্ত আক্রমণকারী থাকে।
/// উদাহরণস্বরূপ, একটি `1`-প্রারম্ভিক এক্স 100 এক্সকে প্রাথমিক হিসাবে বিবেচনা করা হয় (বর্তমান বাস্তবায়নের অধীনে; এটি একটি স্থিতিশীল গ্যারান্টি গঠন করে না) কারণ কম্পাইলার সম্পর্কে এটি জানার একমাত্র প্রয়োজনীয়তা হ'ল ডেটা পয়েন্টারটি অবশ্যই শূন্য হওয়া উচিত।
/// এই জাতীয় এক্স 100 এক্স তৈরি করা *তাত্ক্ষণিক* অপরিজ্ঞাত আচরণের কারণ হয় না, তবে বেশিরভাগ সুরক্ষিত ক্রিয়াকলাপের সাথে এটি অপরিবর্তিত আচরণের কারণ ঘটায় (এটি বাদ দেওয়া সহ)।
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` অনির্দেশিত ডেটা মোকাবেলা করতে অনিরাপদ কোড সক্ষম করতে পরিবেশন করে।
/// এটি সংকলকটির সংকেত যা এখানে নির্দেশ করে যে এখানে ডেটা শুরু হতে পারে না:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // একটি সুস্পষ্টভাবে অস্বীকারহীন রেফারেন্স তৈরি করুন।
/// // সংকলক জানে যে একটি `MaybeUninit<T>` এর ভিতরে থাকা ডেটা অবৈধ হতে পারে এবং তাই এটি ইউবি নয়:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // এটি একটি বৈধ মান সেট করুন।
/// unsafe { x.as_mut_ptr().write(&0); }
/// // প্রারম্ভিক ডেটা বের করুন-এটি কেবলমাত্র *পরে* যথাযথভাবে `x` আরম্ভ করার অনুমতি রয়েছে!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// সংকলকটি তখন এই কোডটিতে কোনও ভুল অনুমান বা অনুকূলকরণ করতে না জানে।
///
/// আপনি `MaybeUninit<T>` কে `Option<T>` এর মতো বলে মনে করতে পারেন তবে কোনও রান-টাইম ট্র্যাকিং ছাড়াই এবং কোনও সুরক্ষা চেক ছাড়াই।
///
/// ## out-pointers
///
/// আপনি "out-pointers" বাস্তবায়নের জন্য `MaybeUninit<T>` ব্যবহার করতে পারেন: কোনও ফাংশন থেকে ডেটা ফেরানোর পরিবর্তে ফলাফলটিকে কিছু এক্স-এক্স এক্স মেমোরিতে একটি পয়েন্টারটি পাস করুন।
/// এটি কার্যকর হতে পারে যখন কলারের পক্ষে কীভাবে ফলস্বরূপ মেমরিটি সংরক্ষণ করা হয় তা নিয়ন্ত্রণ করা গুরুত্বপূর্ণ এবং আপনি অপ্রয়োজনীয় পদক্ষেপগুলি এড়াতে চান moves
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` পুরানো বিষয়বস্তু বাদ দেয় না, যা গুরুত্বপূর্ণ।
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // এখন আমরা জানি `v` আরম্ভ হয়!এটি vector সঠিকভাবে বাদ পড়েছে তাও নিশ্চিত করে।
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## অ্যারে উপাদান-বাই-এলিমেন্টের সূচনা করা হচ্ছে
///
/// `MaybeUninit<T>` একটি বড় অ্যারে উপাদান-বাই-উপাদানটি প্রাথমিক করতে ব্যবহার করা যেতে পারে:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` এর একটি অবিবেচনাযুক্ত অ্যারে তৈরি করুন।
///     // এক্স00 এক্স নিরাপদ কারণ আমরা যে ধরণের দাবিটি এখানে শুরু করার দাবি করছি তা হ'ল গুচ্ছ `সম্ভবতউইনিটিস, যার আরম্ভ করার প্রয়োজন নেই।
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // একটি `MaybeUninit` ফেলে দেওয়া কিছুই করে না।
///     // সুতরাং `ptr::write` এর পরিবর্তে কাঁচা পয়েন্টার অ্যাসাইনমেন্ট ব্যবহার করা পুরানো অবিশ্বাস্য মান বাদ দেয় না।
/////
///     // এছাড়াও এই লুপটির সময় যদি কোনও panic থাকে তবে আমাদের একটি মেমরি ফাঁস রয়েছে তবে মেমরির সুরক্ষা সমস্যা নেই।
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // সবকিছুই শুরু করা হয়েছে।
///     // আর্যিকে প্রারম্ভিক প্রকারে ট্রান্সমিট করুন।
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// আপনি আংশিকভাবে প্রাথমিক অ্যারেগুলির সাথেও কাজ করতে পারেন যা নিম্ন স্তরের ডেটাস্ট্রাকচারে পাওয়া যেতে পারে।
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` এর একটি অবিবেচনাযুক্ত অ্যারে তৈরি করুন।
/// // এক্স00 এক্স নিরাপদ কারণ আমরা যে ধরণের দাবিটি এখানে শুরু করার দাবি করছি তা হ'ল গুচ্ছ `সম্ভবতউইনিটিস, যার আরম্ভ করার প্রয়োজন নেই।
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // আমরা নির্ধারিত উপাদানগুলির সংখ্যা গণনা করুন।
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // অ্যারেতে প্রতিটি আইটেমের জন্য, যদি আমরা এটি বরাদ্দ করি তবে ড্রপ করুন।
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ফিল্ড-বাই-ফিল্ড স্ট্রাক্টের সূচনা
///
/// ক্ষেত্রের মাধ্যমে স্ট্রাক্ট ক্ষেত্রের সূচনা করতে আপনি `MaybeUninit<T>` এবং [`std::ptr::addr_of_mut`] ম্যাক্রো ব্যবহার করতে পারেন:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ফিল্ড শুরু করা হচ্ছে
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ক্ষেত্রের সূচনা যদি এখানে কোনও panic হয় তবে `name` ফিল্ডে এক্স01 এক্স।
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // সমস্ত ক্ষেত্র আরম্ভ করা হয়েছে, তাই আমরা একটি প্রাথমিকীকৃত ফু পেতে `assume_init` কল করি।
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` এর মতো একই আকার, প্রান্তিককরণ এবং এবিআইয়ের গ্যারান্টিযুক্ত:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// তবে মনে রাখবেন যে * এক্স এক্স এক্স থাকা একটি প্রকারের অগত্যা একই লেআউট নয়;Rust সাধারণ গ্যারান্টি দেয় না যে `Foo<T>` এর ক্ষেত্রগুলিতে `Foo<U>` এর সমান ক্রম রয়েছে এমনকি `T` এবং `U` একই আকার এবং প্রান্তিককরণ থাকলেও।
///
/// অধিকন্তু যে কোনও বিট মান `MaybeUninit<T>` এর জন্য বৈধ, সংকলকটি non-zero/niche-filling অপ্টিমাইজেশান প্রয়োগ করতে পারে না, সম্ভাব্যত বৃহত্তর আকারের ফলস্বরূপ:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// যদি `T` এফএফআই-নিরাপদ হয়, তবে এক্স 100 এক্সও।
///
/// যদিও `MaybeUninit` এক্স01 এক্স (এটি একই আকার, প্রান্তিককরণ এবং এবিআই কে `T` হিসাবে গ্যারান্টি দেয়), এটি *পূর্ববর্তী কোনও সতর্কীকরণের* পরিবর্তন করে না *।
/// `Option<T>` এবং `Option<MaybeUninit<T>>` এর এখনও বিভিন্ন আকার থাকতে পারে এবং `T` প্রকারের ক্ষেত্রযুক্ত প্রকারগুলি ক্ষেত্রটি `MaybeUninit<T>` এর চেয়ে আলাদাভাবে ছড়িয়ে দেওয়া (এবং আকারের) থাকতে পারে।
/// `MaybeUninit` ইউনিয়নের ধরণ, এবং ইউনিয়নগুলিতে `#[repr(transparent)]` অস্থির (এক্স 100 এক্স দেখুন)।
/// সময়ের সাথে সাথে, ইউনিয়নগুলিতে `#[repr(transparent)]` এর সঠিক গ্যারান্টিগুলি বিবর্তিত হতে পারে এবং `MaybeUninit` `#[repr(transparent)]` থাকতে পারে বা থাকতে পারে না।
/// এটি বলেছিল, এক্স0 এক্স এক্স সর্বদা * গ্যারান্টি দিবে যে এটির আকার, প্রান্তিককরণ এবং এবিআই এক্স X এক্স হিসাবে রয়েছে;এটি কেবলমাত্র `MaybeUninit` বাস্তবায়নের যে গ্যারান্টিটি বিকশিত হতে পারে।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ল্যাং আইটেম যাতে আমরা এতে অন্যান্য প্রকার গুটিয়ে রাখতে পারি।এটি জেনারেটরের জন্য দরকারী।
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // এক্স 100 এক্সকে কল করা হচ্ছে না, আমরা জানতে পারি না যে আমরা এর জন্য পর্যাপ্ত পর্যায়ে আছি কিনা।
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// প্রদত্ত মানটি দিয়ে নতুন একটি এক্স 100 এক্স তৈরি করে।
    /// এই ফাংশনের রিটার্ন মানটিতে [`assume_init`] কল করা নিরাপদ।
    ///
    /// নোট করুন যে একটি `MaybeUninit<T>` ছাড়ানো কখনই `T` এর ড্রপ কোডকে কল করবে না।
    /// `T` শুরু হয়ে গেলে তা বাদ দেওয়া নিশ্চিত করা আপনার দায়িত্ব।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// অবিশ্রুত অবস্থায় একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// নোট করুন যে একটি `MaybeUninit<T>` ছাড়ানো কখনই `T` এর ড্রপ কোডকে কল করবে না।
    /// `T` শুরু হয়ে গেলে তা বাদ দেওয়া নিশ্চিত করা আপনার দায়িত্ব।
    ///
    /// কয়েকটি উদাহরণের জন্য [type-level documentation][MaybeUninit] দেখুন।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// অবিশ্রুত অবস্থায়, `MaybeUninit<T>` আইটেমগুলির একটি নতুন অ্যারে তৈরি করুন।
    ///
    /// Note: একটি জেডফিউচার0 জেড জেড 0 রিস্ট0 জেড সংস্করণে অ্যারে আক্ষরিক সিনট্যাক্স [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) এর অনুমতি দিলে এই পদ্ধতিটি অপ্রয়োজনীয় হয়ে উঠতে পারে।
    ///
    /// নীচের উদাহরণটি এরপরে `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ব্যবহার করতে পারে।
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// প্রকৃতপক্ষে পড়া একটি ডেটা (সম্ভবত আরও ছোট) ফালি দেয় Return
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // নিরাপদ: একটি অনির্দিষ্ট `[MaybeUninit<_>; LEN]` বৈধ।
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// এক্স01 এক্স বাইট দিয়ে মেমরিটি ভরাট হয়ে অবিশ্রুত অবস্থায় একটি নতুন এক্স00 এক্স তৈরি করে।এটি `T` এর উপর নির্ভর করে যে এটি ইতিমধ্যে সঠিক আরম্ভের জন্য তৈরি করে কিনা।
    ///
    /// উদাহরণস্বরূপ, `MaybeUninit<usize>::zeroed()` আরম্ভ করা হয়েছে তবে `MaybeUninit<&'static i32>::zeroed()` নয় কারণ উল্লেখগুলি অবশ্যই নਾਲ হওয়া উচিত নয়।
    ///
    /// নোট করুন যে একটি `MaybeUninit<T>` ছাড়ানো কখনই `T` এর ড্রপ কোডকে কল করবে না।
    /// `T` শুরু হয়ে গেলে তা বাদ দেওয়া নিশ্চিত করা আপনার দায়িত্ব।
    ///
    /// # Example
    ///
    /// এই ফাংশনের সঠিক ব্যবহার: শূন্য দিয়ে একটি কাঠামো সূচনা করা, যেখানে কাঠামোর সমস্ত ক্ষেত্র বিট-প্যাটার্ন 0 একটি বৈধ মান হিসাবে ধরে রাখতে পারে।
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *এই ফাংশনের ভুল* ব্যবহার: `0` টাইপের জন্য কোনও বৈধ বিট-প্যাটার্ন না হলে `x.zeroed().assume_init()` কল করা:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // একটি জুটির অভ্যন্তরে, আমরা একটি `NotZero` তৈরি করি যার বৈধ বৈষম্য নেই।
    /// // এটি অনির্ধারিত আচরণ।⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // নিরাপদ: বরাদ্দ মেমরির জন্য `u.as_mut_ptr()` পয়েন্ট।
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` এর মান সেট করে।
    /// এটি পূর্বের কোনও মান এটি বাদ না দিয়েই ওভাররাইট করে, তাই আপনি যদি ডেস্ট্রাক্টর চালানো এড়াতে না চান তবে এটিকে দুবার ব্যবহার না করার বিষয়ে সতর্ক থাকুন।
    ///
    /// আপনার সুবিধার জন্য, এটি `self`-এর (এখন নিরাপদে আরম্ভ করা) বিষয়বস্তুতে একটি পরিবর্তনীয় রেফারেন্সও দেয়।
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // নিরাপত্তা: আমরা সবেমাত্র এই মানটি আরম্ভ করেছি।
        unsafe { self.assume_init_mut() }
    }

    /// থাকা মানটির জন্য একটি পয়েন্টার পায়।
    /// এই পয়েন্টারটি থেকে পড়া বা এটি একটি রেফারেন্সে পরিণত করা `MaybeUninit<T>` আরম্ভ না করা অবধারিত আচরণ।
    /// এই পয়েন্টারটি (non-transitively) এ নির্দেশ করে মেমোরিতে লেখার বিষয়টি অনির্ধারিত আচরণ (কোনও `UnsafeCell<T>` এর বাইরে)।
    ///
    /// # Examples
    ///
    /// এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` এ একটি রেফারেন্স তৈরি করুন।এটি ঠিক আছে কারণ আমরা এটি সূচনা করেছি।
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// এই পদ্ধতির *ভুল* ব্যবহার:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // আমরা একটি অস্বীকারহীন vector এর জন্য একটি রেফারেন্স তৈরি করেছি!এটি অনির্ধারিত আচরণ।⚠️
    /// ```
    ///
    /// (লক্ষ্য করুন যে অবিচ্ছিন্ন তথ্য সম্পর্কিত রেফারেন্সের চারপাশের বিধিগুলি এখনও চূড়ান্ত হয়নি, তবে যতক্ষণ না সেগুলি এড়ানো উচিত advis)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` এবং `ManuallyDrop` উভয়ই `repr(transparent)` তাই আমরা পয়েন্টারটি কাস্ট করতে পারি।
        self as *const _ as *const T
    }

    /// এতে থাকা মানটিতে একটি পরিবর্তনীয় পয়েন্টার পায়।
    /// এই পয়েন্টারটি থেকে পড়া বা এটি একটি রেফারেন্সে পরিণত করা `MaybeUninit<T>` আরম্ভ না করা অবধারিত আচরণ।
    ///
    /// # Examples
    ///
    /// এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` এ একটি রেফারেন্স তৈরি করুন।
    /// // এটি ঠিক আছে কারণ আমরা এটি সূচনা করেছি।
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// এই পদ্ধতির *ভুল* ব্যবহার:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // আমরা একটি অস্বীকারহীন vector এর জন্য একটি রেফারেন্স তৈরি করেছি!এটি অনির্ধারিত আচরণ।⚠️
    /// ```
    ///
    /// (লক্ষ্য করুন যে অবিচ্ছিন্ন তথ্য সম্পর্কিত রেফারেন্সের চারপাশের বিধিগুলি এখনও চূড়ান্ত হয়নি, তবে যতক্ষণ না সেগুলি এড়ানো উচিত advis)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` এবং `ManuallyDrop` উভয়ই `repr(transparent)` তাই আমরা পয়েন্টারটি কাস্ট করতে পারি।
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` ধারক থেকে মানটি বের করে।ডেটা বাদ হবে তা নিশ্চিত করার জন্য এটি একটি দুর্দান্ত উপায়, কারণ ফলস্বরূপ `T` স্বাভাবিক ড্রপ হ্যান্ডলিংয়ের সাপেক্ষে।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` সত্যিকার অর্থে একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।সামগ্রীটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এটিকে কল করা তাত্ক্ষণিক সংজ্ঞায়িত আচরণের কারণ হয়।
    /// [type-level documentation][inv] এ আরম্ভের আগমনকারী সম্পর্কে আরও তথ্য রয়েছে।
    ///
    /// [inv]: #initialization-invariant
    ///
    /// তার উপরে, মনে রাখবেন যে বেশিরভাগ ধরণের কেবলমাত্র টাইপ স্তরে প্রাথমিক বিবেচনা করা ছাড়াও অতিরিক্ত আক্রমণকারী থাকে।
    /// উদাহরণস্বরূপ, একটি `1`-প্রারম্ভিক এক্স 100 এক্সকে প্রাথমিক হিসাবে বিবেচনা করা হয় (বর্তমান বাস্তবায়নের অধীনে; এটি একটি স্থিতিশীল গ্যারান্টি গঠন করে না) কারণ কম্পাইলার সম্পর্কে এটি জানার একমাত্র প্রয়োজনীয়তা হ'ল ডেটা পয়েন্টারটি অবশ্যই শূন্য হওয়া উচিত।
    ///
    /// এই জাতীয় এক্স 100 এক্স তৈরি করা *তাত্ক্ষণিক* অপরিজ্ঞাত আচরণের কারণ হয় না, তবে বেশিরভাগ সুরক্ষিত ক্রিয়াকলাপের সাথে এটি অপরিবর্তিত আচরণের কারণ ঘটায় (এটি বাদ দেওয়া সহ)।
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// এই পদ্ধতির *ভুল* ব্যবহার:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` এখনও আরম্ভ করা হয়নি, সুতরাং এই শেষ লাইনটি অপরিবর্তিত আচরণের কারণে ঘটেছে।⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` আরম্ভ হয়েছে।
        // এর অর্থ হ'ল `self` অবশ্যই একটি `value` বৈকল্পিক হতে হবে।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` ধারক থেকে মান পড়ে।ফলাফল `T` স্বাভাবিক ড্রপ হ্যান্ডলিং সাপেক্ষে।
    ///
    /// যখনই সম্ভব, এর পরিবর্তে [`assume_init`] ব্যবহার করা ভাল, যা `MaybeUninit<T>` এর সামগ্রীটিকে নকল করতে বাধা দেয়।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` সত্যিকার অর্থে একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।বিষয়বস্তুটি এখনও পুরোপুরি আরম্ভ না করা হলে এটিকে কল করা অপরিজ্ঞাপিত আচরণের কারণ হয়।
    /// [type-level documentation][inv] এ আরম্ভের আগমনকারী সম্পর্কে আরও তথ্য রয়েছে।
    ///
    /// তদুপরি, এটি `MaybeUninit<T>` এর পিছনে একই ডেটার একটি অনুলিপি ছেড়ে দেয়।
    /// ডেটার একাধিক অনুলিপি ব্যবহার করার সময় (একাধিকবার `assume_init_read` কল করে, বা প্রথমে `assume_init_read` এবং তারপরে [`assume_init`] কল করে), তথ্যটি সত্যই নকল হতে পারে তা নিশ্চিত করা আপনার দায়িত্ব।
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` এক্স 100 এক্স, তাই আমরা একাধিকবার পড়তে পারি।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // একটি `None` মান সদৃশ করা ঠিক আছে, তাই আমরা একাধিকবার পড়তে পারি।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// এই পদ্ধতির *ভুল* ব্যবহার:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // আমরা এখন একই vector এর দুটি অনুলিপি তৈরি করেছি, যা ডাবল-মুক্তের দিকে নিয়ে যায়-যখন তারা উভয়ই বাদ যায়!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` আরম্ভ হয়েছে।
        // `self.as_ptr()` থেকে পড়া নিরাপদ, যেহেতু `self` শুরু করা উচিত।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// জায়গায় থাকা মানটি ফেলে দেয়।
    ///
    /// যদি আপনার `MaybeUninit` এর মালিকানা থাকে তবে আপনি তার পরিবর্তে [`assume_init`] ব্যবহার করতে পারেন।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` সত্যিকার অর্থে একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই কলারের উপর নির্ভর করে।বিষয়বস্তুটি এখনও পুরোপুরি আরম্ভ না করা হলে এটিকে কল করা অপরিজ্ঞাপিত আচরণের কারণ হয়।
    ///
    /// তার উপরে, `T` প্রকারের সমস্ত অতিরিক্ত আক্রমণকারী সন্তুষ্ট থাকতে হবে, কারণ `T` (বা এর সদস্য) এর `Drop` বাস্তবায়ন এতে নির্ভর করতে পারে।
    /// উদাহরণস্বরূপ, একটি `1`-প্রারম্ভিক এক্স 100 এক্সকে প্রাথমিক হিসাবে বিবেচনা করা হয় (বর্তমান বাস্তবায়নের অধীনে; এটি একটি স্থিতিশীল গ্যারান্টি গঠন করে না) কারণ কম্পাইলার সম্পর্কে এটি জানার একমাত্র প্রয়োজনীয়তা হ'ল ডেটা পয়েন্টারটি অবশ্যই শূন্য হওয়া উচিত।
    ///
    /// এ জাতীয় `Vec<T>` বাদ দেওয়া অপরিজ্ঞাত আচরণের কারণ হবে।
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // নিরাপত্তা: কলারের অবশ্যই গ্যারান্টি দিতে হবে যে `self` আরম্ভ হয়েছে এবং
        // `T` এর সমস্ত আক্রমণকারীকে সন্তুষ্ট করে।
        // যদি মান হয় তবে জায়গায় মানটি ফেলে রাখা নিরাপদ।
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// থাকা মানটির জন্য একটি ভাগ করা রেফারেন্স পায়।
    ///
    /// এটি কার্যকর হতে পারে যখন আমরা শুরু করা একটি `MaybeUninit` অ্যাক্সেস করতে চাই তবে `MaybeUninit` এর মালিকানা না থাকে (`.assume_init()`) এর ব্যবহার প্রতিরোধ করে)।
    ///
    /// # Safety
    ///
    /// কন্টেন্টটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এই কল করা অপরিজ্ঞাত আচরণের কারণ ঘটায়: `MaybeUninit<T>` সত্যিকার অর্থে একটি আরম্ভিত অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই ফোনকারীর পক্ষে।
    ///
    ///
    /// # Examples
    ///
    /// ### এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // এক্স00 এক্স শুরু করুন:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // এখন যেহেতু আমাদের `MaybeUninit<_>` সূচনা হিসাবে পরিচিত, এটির একটি ভাগ করে নেওয়া রেফারেন্স তৈরি করা ঠিক আছে:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // নিরাপদ: এক্স 100 এক্স শুরু করা হয়েছে।
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### এই পদ্ধতির *ভুল* ব্যবহারসমূহ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // আমরা একটি অস্বীকারহীন vector এর জন্য একটি রেফারেন্স তৈরি করেছি!এটি অনির্ধারিত আচরণ।⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ব্যবহার করে `MaybeUninit` সূচনা করুন:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // একটি অনির্দিষ্ট `Cell<bool>` এর উল্লেখ: ইউবি!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` আরম্ভ হয়েছে।
        // এর অর্থ হ'ল `self` অবশ্যই একটি `value` বৈকল্পিক হতে হবে।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// থাকা মানটির জন্য একটি পরিবর্তনীয় (unique) রেফারেন্স পান।
    ///
    /// এটি কার্যকর হতে পারে যখন আমরা শুরু করা একটি `MaybeUninit` অ্যাক্সেস করতে চাই তবে `MaybeUninit` এর মালিকানা না থাকে (`.assume_init()`) এর ব্যবহার প্রতিরোধ করে)।
    ///
    /// # Safety
    ///
    /// কন্টেন্টটি এখনও সম্পূর্ণরূপে আরম্ভ না করা হলে এই কল করা অপরিজ্ঞাত আচরণের কারণ ঘটায়: `MaybeUninit<T>` সত্যিকার অর্থে একটি আরম্ভিত অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া এই ফোনকারীর পক্ষে।
    /// উদাহরণস্বরূপ, `.assume_init_mut()` একটি `MaybeUninit` আরম্ভ করতে ব্যবহার করা যাবে না।
    ///
    /// # Examples
    ///
    /// ### এই পদ্ধতির সঠিক ব্যবহার:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ইনপুট বাফারের *সমস্ত* বাইট সূচনা করে।
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // এক্স00 এক্স শুরু করুন:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // এখন আমরা জানি যে `buf` সূচনা করা হয়েছে, তাই আমরা এটি `.assume_init()` করতে পারি।
    /// // তবে, `.assume_init()` ব্যবহার করে 2048 বাইটের একটি `memcpy` ট্রিগার করতে পারে।
    /// // আমাদের বাফারটি অনুলিপি না করেই সূচনা করা হয়েছে তা নিশ্চিত করার জন্য, আমরা `&mut MaybeUninit<[u8; 2048]>` কে একটি `&mut [u8; 2048]` এ আপগ্রেড করেছি:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // নিরাপদ: এক্স 100 এক্স শুরু করা হয়েছে।
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // এখন আমরা সাধারণ টুকরা হিসাবে `buf` ব্যবহার করতে পারি:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### এই পদ্ধতির *ভুল* ব্যবহারসমূহ:
    ///
    /// আপনি কোনও মান শুরু করতে `.assume_init_mut()` ব্যবহার করতে পারবেন না:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // আমরা একটি অনির্দিষ্ট `bool` এর জন্য একটি (mutable) রেফারেন্স তৈরি করেছি!
    ///     // এটি অনির্ধারিত আচরণ।⚠️
    /// }
    /// ```
    ///
    /// উদাহরণস্বরূপ, আপনি অবিচ্ছিন্ন বাফারে [`Read`] করতে পারবেন না:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) অবিরাম মেমরি রেফারেন্স!
    ///                             // এটি অনির্ধারিত আচরণ।
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// এছাড়াও আপনি ক্ষেত্রের দ্বারা ক্ষেত্রের ধীরে ধীরে সূচনা করতে সরাসরি ক্ষেত্র অ্যাক্সেস ব্যবহার করতে পারবেন না:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) অবিরাম মেমরি রেফারেন্স!
    ///                  // এটি অনির্ধারিত আচরণ।
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) অবিরাম মেমরি রেফারেন্স!
    ///                  // এটি অনির্ধারিত আচরণ।
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): আমরা বর্তমানে উপরেরটি ভুল হওয়ার উপর নির্ভর করি, অর্থাত্, আমাদের অবিবেচনাযুক্ত ডেটা (যেমন, `libcore/fmt/float.rs` এ) সম্পর্কিত উল্লেখ রয়েছে।
    // স্থিতিশীল হওয়ার আগে নিয়ম সম্পর্কে আমাদের চূড়ান্ত সিদ্ধান্ত নেওয়া উচিত।
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` আরম্ভ হয়েছে।
        // এর অর্থ হ'ল `self` অবশ্যই একটি `value` বৈকল্পিক হতে হবে।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` ধারকগুলির একটি অ্যারে থেকে মানগুলি বের করে।
    ///
    /// # Safety
    ///
    /// অ্যারের সমস্ত উপাদান একটি প্রাথমিক অবস্থায় রয়েছে এর গ্যারান্টি দেওয়া এটি কলারের উপর নির্ভর করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // নিরাপত্তা: এখন আমরা নিরাপদে সমস্ত উপাদান শুরু করেছি
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * কলার গ্যারান্টি দেয় যে অ্যারের সমস্ত উপাদান সূচনা করা হয়েছে
        // * `MaybeUninit<T>` এবং টি একই লেআউট থাকার গ্যারান্টিযুক্ত
        // * হতে পারে ইউনিন্ট ড্রপ করে না, সুতরাং কোনও ডাবল-ফ্রি নেই এবং এইভাবে রূপান্তরটি নিরাপদ
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ধরে নিই যে সমস্ত উপাদান সূচনা হয়েছে, তাদের একটি টুকরো পেয়ে নিন।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` উপাদানগুলি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া কলারের উপর নির্ভর করে।
    ///
    /// বিষয়বস্তুটি এখনও পুরোপুরি আরম্ভ না করা হলে এটিকে কল করা অপরিজ্ঞাপিত আচরণের কারণ হয়।
    ///
    /// আরও বিশদ এবং উদাহরণের জন্য [`assume_init_ref`] দেখুন।
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // সুরক্ষা: কলার যে গ্যারান্টি দেয় সেহেতু `*const [T]` এ স্লাইস castালাই নিরাপদ
        // `slice` আরম্ভ করা হয়েছে, এবং ayMaybeUninit` `T` এর মতো একই লেআউট থাকার গ্যারান্টিযুক্ত।
        // প্রাপ্ত পয়েন্টারটি বৈধ কারণ এটি `slice` এর মালিকানাধীন মেমরিটিকে বোঝায় যা একটি রেফারেন্স এবং এভাবে পাঠকের জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// ধরে নিই যে সমস্ত উপাদান সূচনা হয়েছে, তাদের একটি পরিবর্তনীয় স্লাইস পান।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` উপাদানগুলি একটি প্রাথমিক অবস্থায় রয়েছে তা গ্যারান্টি দেওয়া কলারের উপর নির্ভর করে।
    ///
    /// বিষয়বস্তুটি এখনও পুরোপুরি আরম্ভ না করা হলে এটিকে কল করা অপরিজ্ঞাপিত আচরণের কারণ হয়।
    ///
    /// আরও বিশদ এবং উদাহরণের জন্য [`assume_init_mut`] দেখুন।
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // নিরাপদ: `slice_get_ref` এর সুরক্ষা নোটের সমান, তবে আমাদের কাছে একটি
        // পরিবর্তনীয় রেফারেন্স যা লেখার জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত।
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// অ্যারের প্রথম উপাদানটিতে একটি পয়েন্টার পায়।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// অ্যারের প্রথম উপাদানটিতে একটি পরিবর্তনীয় পয়েন্টার পায়।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` থেকে `this` এ উপাদানগুলিকে অনুলিপি করে, এখন `this`-এর ইনিটালাইজড সামগ্রীতে একটি পরিবর্তনীয় রেফারেন্স ফিরে আসে।
    ///
    /// যদি `T` `Copy` প্রয়োগ না করে তবে [`write_slice_cloned`] ব্যবহার করুন
    ///
    /// এটি [`slice::copy_from_slice`] এর মতো।
    ///
    /// # Panics
    ///
    /// দুটি ফালিগুলির দৈর্ঘ্য পৃথক থাকলে এই ফাংশনটি panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // নিরাপত্তা: আমরা খালি লেনের সমস্ত উপাদানগুলি অতিরিক্ত ক্ষমতাতে অনুলিপি করেছি
    /// // ভিসির প্রথম src.len() উপাদানগুলি এখন বৈধ।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // নিরাপদ: &[টি] এবং&[সম্ভবতউইনুইনিট<T>] একই লেআউট আছে
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // নিরাপত্তা: বৈধ উপাদানগুলিকে সবেমাত্র `this` এ অনুলিপি করা হয়েছে যাতে এটি ইনটালাইজড হয়
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` থেকে `this` এ উপাদানগুলিকে ক্লোন করে, এখন `this`-এর ইনিটালাইজড বিষয়বস্তুর পরিবর্তিত রেফারেন্সটি ফিরিয়ে আনছে।
    /// ইতিমধ্যে যে কোনও উদ্ভাবিত উপাদান বাদ দেওয়া হবে না।
    ///
    /// যদি `T` `Copy` প্রয়োগ করে, [`write_slice`] ব্যবহার করুন
    ///
    /// এটি [`slice::clone_from_slice`] এর অনুরূপ তবে বিদ্যমান উপাদানগুলি ড্রপ করে না।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটি panic করবে যদি দুটি স্লাইসের আলাদা দৈর্ঘ্য হয়, বা যদি `Clone` panics বাস্তবায়ন করা হয়।
    ///
    /// যদি কোনও panic থাকে তবে ইতিমধ্যে ক্লোন করা উপাদানগুলি বাদ দেওয়া হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // নিরাপত্তা: আমরা খালি লেনের সমস্ত উপাদানগুলিকে অতিরিক্ত ক্ষমতাতে ক্লোন করেছি
    /// // ভিসির প্রথম src.len() উপাদানগুলি এখন বৈধ।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice এর বিপরীতে এটি স্লাইসে ক্লোন_ফ্রোম_স্লাইস কল করে না কারণ এটি `MaybeUninit<T: Clone>` ক্লোন বাস্তবায়ন করে না।
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // নিরাপত্তা: এই কাঁচা টুকরোতে কেবলমাত্র প্রাথমিক জিনিসগুলি থাকবে
                // এ কারণেই এটি এটিকে ফেলে দেওয়ার অনুমতি রয়েছে।
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: আমাদের তাদের স্পষ্টভাবে একই দৈর্ঘ্যে টুকরো টুকরো করা দরকার
        // সীমাবদ্ধতা যাচাইয়ের জন্য, এবং অপ্টিমাইজার সাধারণ ক্ষেত্রে (উদাহরণস্বরূপ T= u8) মেমকি তৈরি করবে।
        //
        let len = this.len();
        let src = &src[..len];

        // প্রহরী প্রয়োজন b/c panic একটি ক্লোন চলাকালীন ঘটতে পারে
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // নিরাপত্তা: বৈধ উপাদানগুলিকে সবেমাত্র `this` এ লিখিত হয়েছে তাই এটি ইনজিলাইজড
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}