//! `Default` trait এমন ধরণের জন্য যা অর্থপূর্ণ ডিফল্ট মান থাকতে পারে।

#![stable(feature = "rust1", since = "1.0.0")]

/// কোনও ধরণের একটি কার্যকর ডিফল্ট মান দেওয়ার জন্য একটি trait।
///
/// কখনও কখনও, আপনি কোনও ধরণের ডিফল্ট মানটিতে ফিরে যেতে চান এবং বিশেষত এটি কী তা যত্নশীল হন না।
/// এটি প্রায়শই `কাঠামোগুলি নিয়ে আসে যা বিকল্পগুলির সেটকে সংজ্ঞায়িত করে:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// আমরা কীভাবে কিছু ডিফল্ট মান নির্ধারণ করতে পারি?আপনি `Default` ব্যবহার করতে পারেন:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// এখন, আপনি সমস্ত ডিফল্ট মান পাবেন।Rust বিভিন্ন আদিম ধরণের জন্য `Default` প্রয়োগ করে।
///
/// আপনি যদি কোনও নির্দিষ্ট বিকল্পকে ওভাররাইড করতে চান তবে অন্য ডিফল্টগুলি ধরে রাখুন:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// এই ধরণের সমস্ত ক্ষেত্র যদি `Default` প্রয়োগ করে তবে এই জেড 0 ট্রাইটজেড এক্স01 এক্স এর সাথে ব্যবহার করা যেতে পারে।
/// যখন প্রাপ্ত হয়, এটি প্রতিটি ক্ষেত্রের ধরণের জন্য ডিফল্ট মান ব্যবহার করবে।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// `default()` পদ্ধতির জন্য একটি বাস্তবায়ন সরবরাহ করুন যা আপনার ধরণের মানটি ডিফল্ট হওয়া উচিত:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// এক প্রকারের জন্য "default value" প্রদান করে।
    ///
    /// ডিফল্ট মানগুলি প্রায়শই এক ধরণের প্রাথমিক মান, পরিচয় মান বা অন্য কোনও কিছু যা ডিফল্ট হিসাবে বোধ করতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// অন্তর্নির্মিত ডিফল্ট মানগুলি ব্যবহার করে:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// নিজের তৈরি:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait অনুযায়ী কোনও ধরণের ডিফল্ট মানটি ফিরিয়ে দিন।
///
/// ফেরতের ধরণটি প্রসঙ্গ থেকে অনুমান করা হয়;এটি `Default::default()` এর সমতুল্য তবে টাইপ করার চেয়ে ছোট।
///
/// উদাহরণ স্বরূপ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }