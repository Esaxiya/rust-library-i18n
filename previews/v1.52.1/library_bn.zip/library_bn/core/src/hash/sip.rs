//! সিপহ্যাশের একটি বাস্তবায়ন।

#![allow(deprecated)] // এই মডিউলটির ধরণগুলি হ্রাস করা হয়েছে

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// সিপহ্যাশ 1-3-এর একটি বাস্তবায়ন।
///
/// এটি বর্তমানে স্ট্যান্ডার্ড লাইব্রেরি দ্বারা ব্যবহৃত ডিফল্ট হ্যাশিং ফাংশন (যেমন, `collections::HashMap` এটি ডিফল্টরূপে ব্যবহার করে)।
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// সিপহ্যাশ 2-4 এর একটি বাস্তবায়ন।
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// সিপহ্যাশ 2-4 এর একটি বাস্তবায়ন।
///
/// See: <https://131002.net/siphash/>
///
/// সিপহ্যাশ একটি সাধারণ-উদ্দেশ্যযুক্ত হ্যাশিং ফাংশন: এটি একটি ভাল গতিতে চলে (স্পকি এবং সিটির সাথে প্রতিযোগিতামূলক) এবং শক্তিশালী _keyed_ হ্যাশিংকে অনুমতি দেয়।
///
/// এটি আপনাকে [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) এর মতো শক্তিশালী আরএনজি থেকে আপনার হ্যাশ টেবিলগুলি কী করতে দেয়।
///
/// যদিও সিপহ্যাশ অ্যালগরিদমকে সাধারণত শক্তিশালী বলে মনে করা হয়, এটি ক্রিপ্টোগ্রাফিক উদ্দেশ্যে নয়।
/// এই হিসাবে, এই প্রয়োগের সমস্ত ক্রিপ্টোগ্রাফিক ব্যবহারগুলি _strongly discouraged_ are
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // আমরা কতগুলি বাইট প্রক্রিয়াজাত করেছি
    state: State,  // হ্যাশ রাজ্য
    tail: u64,     // অপ্রসেসড বাইটস লে
    ntail: usize,  // লেজের কতগুলি বাইট বৈধ are
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 এবং v1, v3 অ্যালগোরিদমের জোড়ায় প্রদর্শিত হবে এবং সিপহ্যাশের সিমড বাস্তবায়নগুলি v02 এবং v13 এর vectors ব্যবহার করবে।
    //
    // স্ট্রাক্টে তাদের এই ক্রমে রেখে, সংকলক নিজে থেকে কয়েকটি সিমড অপ্টিমাইজেশন নিতে পারে।
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// লে ক্রমে বাইট স্ট্রিম থেকে পছন্দসই ধরণের পূর্ণসংখ্যা লোড করে।
/// সংকলকটিকে সম্ভবত একটি স্বাক্ষরযুক্ত ঠিকানা থেকে লোড করার সবচেয়ে কার্যকর উপায় তৈরি করতে `copy_nonoverlapping` ব্যবহার করে।
///
///
/// অনিরাপদ কারণ: i..i+size_of(int_ty) এ চেক না করা সূচি
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// বাইট স্লাইসের 7 টি বাইট ব্যবহার করে একটি এক্স 100 এক্স লোড করে।
/// এটি আনাড়ি মনে হয় তবে `copy_nonoverlapping` কলগুলি ঘটে (`load_int_le!` এর মাধ্যমে) সমস্তগুলির নির্দিষ্ট আকার থাকে এবং `memcpy` কল করা এড়ানো যায় যা গতির পক্ষে ভাল।
///
///
/// অনিরাপদ কারণ: চেক না করা সূচকে শুরু করা .. স্টার্ট + লেন +
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // u64 আউটপুটে বর্তমান বাইট সূচক (এলএসবি থেকে)
    let mut out = 0;
    if i + 3 < len {
        // নিরাপদ: `i` `len` এর চেয়ে বড় হতে পারে না, এবং কলকারীকে নিশ্চয়তা দিতে হবে
        // সূচকটি শুরু করুন ... স্টার্ট + লেন সীমানায় রয়েছে।
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // নিরাপদ: উপরের মত।
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // নিরাপদ: উপরের মত।
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// দুটি প্রাথমিক কী 0 তে সেট করে একটি নতুন এক্স00 এক্স তৈরি করে।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// প্রদত্ত কীগুলি বন্ধ করে দেওয়া এমন একটি `SipHasher` তৈরি করে।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// দুটি প্রাথমিক কী 0 তে সেট করে একটি নতুন এক্স00 এক্স তৈরি করে।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// প্রদত্ত কীগুলি বন্ধ করে দেওয়া এমন একটি `SipHasher13` তৈরি করে।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: কোনও পূর্ণসংখ্যার হ্যাশিং পদ্ধতি (`Writ_u *`, `write_i*`) সংজ্ঞায়িত করা হয় না
    // এই ধরণের জন্য।
    // আমরা সেগুলি যুক্ত করতে, librustc_data_structures/sip128.rs এ `short_write` বাস্তবায়ন অনুলিপি করতে এবং `SipHasher`, `SipHasher13` এবং `DefaultHasher` এ `write_u *`/`write_i*` পদ্ধতি যুক্ত করতে পারি।
    //
    // এটি কিছু বেঞ্চমার্কগুলিতে সামান্য গতি কমিয়ে আনার ব্যয়ে এই হ্যাশারগুলির দ্বারা পূর্ণসংখ্যার হ্যাশিংয়ের গতি বাড়িয়ে তুলবে।
    // বিশদ জানতে এক্স00 এক্স দেখুন।
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // নিরাপদ: এক্স0 এক্স এক্স 10000 এর বেশি না হওয়ার গ্যারান্টিযুক্ত
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // বাফার্ড লেজ এখন ফ্লাশ করা হয়েছে, নতুন ইনপুট প্রক্রিয়া করুন।
        let len = length - needed;
        let left = len & 0x7; // লেন% 8

        let mut i = needed;
        while i < len - left {
            // সুরক্ষা: কারণ `len - left` 8 এর অধীনে সবচেয়ে বড় একাধিক
            // `len`, এবং যেহেতু `i` `needed` থেকে শুরু হয় যেখানে `len` হয় `length - needed`, `i + 8` এটি `length` এর চেয়ে কম বা সমান হওয়ার গ্যারান্টিযুক্ত।
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // নিরাপদ: `i` এখন এক্স 100 এক্স,
        // সুতরাং `i + left` = `needed + len` = `length` যা `msg.len()` এর সমান সংজ্ঞা দ্বারা।
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// দুটি প্রাথমিক কী 0 তে সেট করে একটি এক্স 100 এক্স তৈরি করে।
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}