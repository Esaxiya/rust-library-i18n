//! জেনেরিক হ্যাশিং সমর্থন।
//!
//! এই মডিউলটি একটি মানের [hash] গণনা করার জন্য একটি জেনেরিক উপায় সরবরাহ করে।
//! হ্যাশগুলি [`HashMap`] এবং [`HashSet`] এর সাথে সর্বাধিক ব্যবহৃত হয়।
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! কোনও ধরণের হ্যাশেবল তৈরির সহজ উপায় হ'ল এক্স00 এক্স ব্যবহার করা:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! মানটি কীভাবে ধাবিত হয় তার উপর যদি আপনার আরও নিয়ন্ত্রণের প্রয়োজন হয় তবে আপনাকে [`Hash`] trait বাস্তবায়ন করতে হবে:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// একটি হ্যাশযোগ্য প্রকার।
///
/// `Hash` প্রয়োগকারী প্রকারগুলি [`Hasher`] এর উদাহরণ সহ [`হ্যাশ] এড করতে সক্ষম।
///
/// ## এক্স 100 এক্স প্রয়োগ করা হচ্ছে
///
/// সমস্ত ক্ষেত্র যদি `Hash` বাস্তবায়ন করে তবে আপনি `Hash` দিয়ে এক্স01 এক্স অর্জন করতে পারেন।
/// ফলাফলের হ্যাশ প্রতিটি ক্ষেত্রে [`hash`] কল করা থেকে মানগুলির সংমিশ্রণ হবে।
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// মানটি কীভাবে হ্যাশ হয় তার উপর যদি আপনার আরও নিয়ন্ত্রণের প্রয়োজন হয় তবে আপনি অবশ্যই `Hash` trait নিজেই প্রয়োগ করতে পারেন:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` এবং `Eq`
///
/// `Hash` এবং [`Eq`] উভয়ই প্রয়োগ করার সময়, নিম্নলিখিত সম্পত্তিটি রাখা জরুরী:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// অন্য কথায়, দুটি কী সমান হলে তাদের হ্যাশগুলিও সমান হতে হবে।
/// [`HashMap`] এবং এক্স00 এক্স উভয়ই এই আচরণের উপর নির্ভর করে।
///
/// ধন্যবাদ, X001 এক্স এবং এক্স02 এক্স উভয়ই এক্স00 এক্স সহ প্রাপ্ত করার সময় আপনার এই সম্পত্তিটি ধরে রাখার বিষয়ে চিন্তা করার দরকার নেই।
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// প্রদত্ত [`Hasher`] এ এই মানটি ফিড করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// প্রদত্ত [`Hasher`] এ এই ধরণের একটি ফালি ফিড করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` ছাড়াই preolve থেকে ম্যাক্রো `Hash` পুনরায় রপ্তানি করতে মডিউল পৃথক করুন।
pub(crate) mod macros {
    /// trait `Hash` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// বাইটগুলির একটি স্বেচ্ছাসেবী স্ট্রিম হ্যাশ করার জন্য একটি জেড 0 ট্রাইট0 জেড।
///
/// এক্স 100 এক্স এর উদাহরণগুলি সাধারণত এমন রাষ্ট্রের প্রতিনিধিত্ব করে যা ডেটা হ্যাশ করার সময় পরিবর্তিত হয়।
///
/// `Hasher` উত্পন্ন হ্যাশ পুনরুদ্ধার করার জন্য মোটামুটি প্রাথমিক ইন্টারফেস সরবরাহ করে ([`finish`] সহ), এবং পূর্ণসংখ্যার পাশাপাশি বাইটের স্লাইসগুলি উদাহরণে ([`write`] এবং [`write_u8`] ইত্যাদিতে) সরবরাহ করে।
/// বেশিরভাগ সময়, `Hasher` উদাহরণগুলি [`Hash`] trait এর সাথে একত্রে ব্যবহৃত হয়।
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// এখনও পর্যন্ত লিখিত মানগুলির জন্য হ্যাশ মান প্রদান করে।
    ///
    /// এর নাম সত্ত্বেও, পদ্ধতিটি হ্যাশারের অভ্যন্তরীণ অবস্থাকে পুনরায় সেট করে না।
    /// অতিরিক্ত [`Writ`] গুলি বর্তমান মান থেকে চালিয়ে যাবে।
    /// আপনার যদি নতুন করে হ্যাশ মান শুরু করতে হয় তবে আপনাকে একটি নতুন হ্যাশার তৈরি করতে হবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// এই `Hasher` এ কিছু ডেটা লিখে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// এই হ্যাশারে একটি একক `u8` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// এই হ্যাশারে একটি একক `u16` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// এই হ্যাশারে একটি একক `u32` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// এই হ্যাশারে একটি একক `u64` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// এই হ্যাশারে একটি একক `u128` লিখেছেন।
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// এই হ্যাশারে একটি একক `usize` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// এই হ্যাশারে একটি একক `i8` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// এই হ্যাশারে একটি একক `i16` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// এই হ্যাশারে একটি একক `i32` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// এই হ্যাশারে একটি একক `i64` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// এই হ্যাশারে একটি একক `i128` লিখেছেন।
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// এই হ্যাশারে একটি একক `isize` লিখেছেন।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// এক্স 100 এক্স এর উদাহরণ তৈরি করার জন্য একটি জেড 0 ট্রাইট0 জেড।
///
/// একটি এক্স00 এক্স সাধারণত ব্যবহৃত হয় (উদাহরণস্বরূপ, এক্স01 এক্স দ্বারা) প্রতিটি কীগুলির জন্য [`হাশের] গুলি তৈরি করতে যাতে সেগুলি একে অপরের থেকে স্বাধীনভাবে ধাবিত হয়, যেহেতু [` হাশের] এর রাষ্ট্র থাকে।
///
///
/// `BuildHasher` এর প্রতিটি উদাহরণের জন্য, [`build_hasher`] দ্বারা নির্মিত [`হাশের] গুলি অভিন্ন হওয়া উচিত।
/// এটি হ'ল, যদি প্রতিটি হ্যাশারে একই বাইটের স্ট্রিম সরবরাহ করা হয় তবে একই আউটপুটও উত্পন্ন হবে।
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// তৈরি করা হবে এমন হ্যাশারের ধরণ।
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// একটি নতুন হ্যাশার তৈরি করে।
    ///
    /// একই উদাহরণে `build_hasher` এ থাকা প্রতিটি কলের জন্য অভিন্ন [`হাশের] গুলি তৈরি করা উচিত।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] এবং [`Default`] প্রয়োগ করে এমন ধরণের জন্য একটি ডিফল্ট [`BuildHasher`] উদাহরণ তৈরি করতে ব্যবহৃত হয়।
///
/// `BuildHasherDefault<H>` যখন কোনও ধরণের `H` [`Hasher`] এবং [`Default`] প্রয়োগ করে এবং আপনার একটি সম্পর্কিত [`BuildHasher`] উদাহরণ প্রয়োজন, তবে কোনওটিই সংজ্ঞায়িত হয় না।
///
///
/// যে কোনও এক্স 02 এক্স এক্স01 এক্স।এটি [`default`][method.default] দিয়ে তৈরি করা যেতে পারে।
/// [`HashMap`] বা [`HashSet`] দিয়ে [`HashSet`] ব্যবহার করার সময়, এটি করার দরকার নেই, যেহেতু তারা যথাযথ [`Default`] উদাহরণগুলি নিজেরাই প্রয়োগ করে।
///
/// # Examples
///
/// `BuildHasherDefault` ব্যবহার করে একটি কাস্টম [`BuildHasher`] নির্দিষ্ট করতে
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // আপনার হ্যাশিং অ্যালগরিদম এখানে যায়!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // আপনার হ্যাশিং অ্যালগরিদম এখানে যায়!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // সুরক্ষা: এক্স ম্যাক্সএক্সটি বৈধ এবং প্রান্তিক, কারণ এই ম্যাক্রোটি কেবল ব্যবহৃত হয়
                    // সংখ্যাগত আদিমদের জন্য যার কোনও প্যাডিং নেই।
                    // নতুন স্লাইসটি কেবল এক্স01 এক্স জুড়ে বিস্তৃত এবং কখনও রূপান্তরিত হয় না এবং এর মোট আকারটি মূল এক্স02 এক্স এর সমান তাই এটি `isize::MAX` এর বেশি হতে পারে না।
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // পাতলা পয়েন্টার
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ফ্যাট পয়েন্টার নিরাপদ: আমরা `self` দ্বারা দখল করা মেমরিটি অ্যাক্সেস করছি যা বৈধ হওয়ার গ্যারান্টিযুক্ত।
                    // এটি ধরে নিয়েছে যে একটি ফ্যাট পয়েন্টারটি `(usize, usize)` দ্বারা প্রতিনিধিত্ব করা যেতে পারে, যা `std` এ করা নিরাপদ কারণ এটি প্রেরণ করা হয় এবং `rustc` এ ফ্যাট পয়েন্টারগুলির প্রয়োগের সাথে সিঙ্কে রাখা হয়।
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // পাতলা পয়েন্টার
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ফ্যাট পয়েন্টার নিরাপদ: আমরা `self` দ্বারা দখল করা মেমরিটি অ্যাক্সেস করছি যা বৈধ হওয়ার গ্যারান্টিযুক্ত।
                    // এটি ধরে নিয়েছে যে একটি ফ্যাট পয়েন্টারটি `(usize, usize)` দ্বারা প্রতিনিধিত্ব করা যেতে পারে, যা `std` এ করা নিরাপদ কারণ এটি প্রেরণ করা হয় এবং `rustc` এ ফ্যাট পয়েন্টারগুলির প্রয়োগের সাথে সিঙ্কে রাখা হয়।
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}