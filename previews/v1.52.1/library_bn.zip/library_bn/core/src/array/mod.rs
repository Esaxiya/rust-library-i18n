//! নির্দিষ্ট দৈর্ঘ্য অ্যারেগুলির জন্য `Eq` এর মতো জিনিসের প্রয়োগ।
//! অবশেষে, আমাদের সকল দৈর্ঘ্যে সাধারণকরণ করতে সক্ষম হওয়া উচিত।
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` এর একটি রেফারেন্স 1 দৈর্ঘ্যের অ্যারে রেফারেন্সে রূপান্তর করে (অনুলিপি ছাড়াই)।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // নিরাপদ: `&T` কে `&[T; 1]` এ রূপান্তর করা শক্ত।
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` এর পরিবর্তিত রেফারেন্সটিকে দৈর্ঘ্যের 1 অ্যারে (অনুলিপি ছাড়াই) একটি পরিবর্তনীয় রেফারেন্সে রূপান্তর করে।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // নিরাপদ: `&mut T` কে `&mut [T; 1]` এ রূপান্তর করা শক্ত।
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// ইউটিলিটি trait শুধুমাত্র নির্দিষ্ট আকারের অ্যারেগুলিতে প্রয়োগ করা হয়েছে
///
/// এই trait বেশি মেটাডাটা ফোলাভাবের কারণ ছাড়াই স্থির আকারের অ্যারেগুলিতে অন্যান্য জেড 0 ট্রাইট0 জেড প্রয়োগ করতে ব্যবহার করা যেতে পারে।
///
/// trait স্থির আকারের অ্যারেগুলিতে প্রয়োগকারীদের সীমাবদ্ধ করার জন্য অনিরাপদ চিহ্নিত করা হয়েছে।
/// এই trait এর ব্যবহারকারী ধরে নিতে পারেন যে নির্ধারকগুলির একটি নির্দিষ্ট আকারের অ্যারের স্মৃতিতে সঠিক লেআউট থাকে (উদাহরণস্বরূপ, অনিরাপদ আরম্ভের জন্য)।
///
///
/// নোট করুন যে traits [`AsRef`] এবং [`AsMut`] এমন ধরণের জন্য একই ধরণের পদ্ধতি সরবরাহ করে যা নির্দিষ্ট আকারের অ্যারেগুলি নাও হতে পারে।
/// প্রয়োগকারীদের পরিবর্তে সেইগুলি traits পছন্দ করতে হবে।
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// অ্যারেটিকে অপরিবর্তনীয় টুকরোতে রূপান্তর করে
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// অ্যারেটিকে পরিবর্তনীয় স্লাইসে রূপান্তরিত করে
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// একটি স্লাইস থেকে অ্যারেতে রূপান্তর ব্যর্থ হলে ত্রুটির ধরণটি ফিরে আসে।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // নিরাপত্তা: ঠিক আছে কারণ আমরা মাত্র পরীক্ষা করেছি যে দৈর্ঘ্য ফিট করে fits
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // নিরাপত্তা: ঠিক আছে কারণ আমরা মাত্র পরীক্ষা করেছি যে দৈর্ঘ্য ফিট করে fits
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: কোড ব্লাট কমাতে কিছু কম গুরুত্বপূর্ণ ইমপ্লস বাদ দেওয়া হয়েছে
// _সিম্পল_স্লাইস_এক 2!এক্স01 এক্স_সিম্পল_স্লাইস_এইচ 2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// অ্যারে এক্স00 এক্স এর তুলনা কার্যকর করে।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// ডিফল্ট ইমেলগুলি কনস্ট জেনেরিক দিয়ে করা যায় না কারণ `[T; 0]`-এ ডিফল্ট প্রয়োগ করার প্রয়োজন হয় না এবং বিভিন্ন সংখ্যার জন্য আলাদা ইমপ্ল ব্লক থাকা এখনও সমর্থিত নয়।
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// প্রতিটি উপাদানটিতে ক্রমানুসারে `f` ফাংশন প্রয়োগ করে `self` এর মতো একই আকারের একটি অ্যারে ফেরত দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // নিরাপত্তা: আমরা নিশ্চিত জানি যে এই পুনরাবৃত্তিটি ঠিক `N` ফলন করবে
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'জিপস আপ' জোড়ের একক অ্যারেতে দুটি অ্যারে।
    ///
    /// `zip()` একটি নতুন অ্যারে প্রদান করে যেখানে প্রতিটি উপাদান একটি টিপল যেখানে প্রথম উপাদানটি প্রথম অ্যারে থেকে আসে এবং দ্বিতীয় উপাদানটি দ্বিতীয় অ্যারে থেকে আসে।
    ///
    /// অন্য কথায়, এটি এককভাবে দুটি অ্যারে জিপ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // নিরাপত্তা: আমরা নিশ্চিত জানি যে এই পুনরাবৃত্তিটি ঠিক `N` ফলন করবে
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// পুরো অ্যারেযুক্ত একটি স্লাইস ফেরায়।`&s[..]` এর সমান।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// পুরো অ্যারে সমন্বিত একটি পরিবর্তনীয় স্লাইস প্রদান করে।
    /// `&mut s[..]` এর সমান।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// প্রতিটি উপাদান ধার করে এবং `self` এর সমান আকারের সাথে রেফারেন্সের অ্যারে দেয়।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) এর মতো অন্যান্য পদ্ধতির সাথে একত্রিত হলে এই পদ্ধতিটি বিশেষভাবে কার্যকর।
    /// এইভাবে, আপনি মূল অ্যারেটি সরানো এড়াতে পারবেন যদি এর উপাদানগুলি `Copy` না হয়।
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // আমরা এখনও মূল অ্যারে অ্যাক্সেস করতে পারি: এটি সরানো হয়নি।
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // নিরাপত্তা: আমরা নিশ্চিত জানি যে এই পুনরাবৃত্তিটি ঠিক `N` ফলন করবে
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// প্রতিটি উপাদানকে পারস্পরিকভাবে Bণ নেয় এবং `self` এর মতো একই আকারের সাথে পরিবর্তনীয় রেফারেন্সগুলির একটি অ্যারে প্রদান করে।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // নিরাপত্তা: আমরা নিশ্চিত জানি যে এই পুনরাবৃত্তিটি ঠিক `N` ফলন করবে
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` থেকে `N` আইটেম টানুন এবং অ্যারে হিসাবে এগুলি প্রদান করে।
/// যদি পুনরুক্তিটি `N` আইটেমের চেয়ে কম ফলন করে তবে এই ফাংশনটি সংজ্ঞায়িত আচরণ প্রদর্শন করে।
///
///
/// আরও তথ্যের জন্য [`collect_into_array`] দেখুন।
///
/// # Safety
///
/// `iter` কমপক্ষে `N` আইটেমের গ্যারান্টি দেয় এটি গ্যারান্টিযুক্তের কাছে।
/// এই অবস্থার লঙ্ঘন অনির্ধারিত আচরণের কারণ।
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` এখানে কিছুটা পরীক্ষামূলক।এই মাত্র একটি
    // অভ্যন্তরীণ ফাংশন, তাই যদি এই সীমাবদ্ধ কোনও খারাপ ধারণা হয়ে যায় তবে সরিয়ে ফ্রি মনে করুন।
    // সেক্ষেত্রে নীচের নিচে `debug_assert!` টি সরিয়ে ফেলতেও মনে রাখবেন!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // নিরাপদ: ফাংশন চুক্তি দ্বারা আচ্ছাদিত।
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` থেকে `N` আইটেম টানুন এবং অ্যারে হিসাবে এগুলি প্রদান করে।যদি পুনরুক্তিটি `N` আইটেমের চেয়ে কম ফলন করে তবে `None` ফিরে আসে এবং ইতিমধ্যে উত্পাদিত সমস্ত আইটেম বাদ দেওয়া হয়।
///
/// যেহেতু পুনরুক্তিটি পরিবর্তনীয় রেফারেন্স হিসাবে পাস হয়েছে এবং এই ফাংশনটি `next` কে সর্বাধিক `N` বার কল করে, ততক্ষণে পুনরুক্তিটি বাকী আইটেমগুলি পুনরুদ্ধারে ব্যবহার করা যেতে পারে।
///
///
/// যদি `iter.next()` প্যানিক হয় তবে ইতিমধ্যে পুনরুক্তকারী দ্বারা উত্পাদিত সমস্ত আইটেম বাদ দেওয়া হবে।
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // নিরাপত্তা: একটি খালি অ্যারে সর্বদা বসবাস করে এবং এর কোনও বৈধতা আগত না থাকে।
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // নিরাপত্তা: এই কাঁচা টুকরোতে কেবলমাত্র প্রাথমিক জিনিসগুলি থাকবে।
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // নিরাপদ: `guard.initialized` 0 থেকে শুরু হয়, এর মধ্যে একটি দ্বারা বৃদ্ধি পেয়েছে
        // লুপ এবং লুপটি N এ পৌঁছানোর পরে বাতিল হয়ে যায় (যা `array.len()`) হয়।
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // পুরো অ্যারেটি আরম্ভ করা হয়েছে কিনা তা পরীক্ষা করে দেখুন।
        if guard.initialized == N {
            mem::forget(guard);

            // নিরাপদ: উপরের শর্তটি জোর দেয় যে সমস্ত উপাদান
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // এটি কেবল তখনই পৌঁছে যায় যখন এক্সটেক্স এক্স এক্স 100 এক্স পৌঁছানোর আগেই পুনরুক্তিটি ক্লান্ত হয়ে পড়ে।
    //
    // এছাড়াও খেয়াল করুন যে `guard` এখানে ফেলে দেওয়া হয়েছে, ইতিমধ্যে সমস্ত প্রাথমিক উপাদান বাদ দিয়ে।
    None
}