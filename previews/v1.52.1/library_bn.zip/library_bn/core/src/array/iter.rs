//! অ্যারেগুলির জন্য `IntoIter` মালিকানাধীন পুনরাবৃত্তি সংজ্ঞা দেয়।

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// একটি বাই-মান [array] পুনরুক্তি।
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// এই অ্যারেটি আমরা পুনরাবৃত্তি করছি।
    ///
    /// সূচক `i` সহ উপাদানগুলি যেখানে `alive.start <= i < alive.end` এখনও পাওয়া যায় নি এবং বৈধ অ্যারে এন্ট্রি।
    /// সূচকগুলি `i < alive.start` বা `i >= alive.end` সহ উপাদানগুলি ইতিমধ্যে পাওয়া গেছে এবং এটি আর অ্যাক্সেস করা উচিত নয়!এই মৃত উপাদানগুলি এমনকি একটি সম্পূর্ণ অবিচ্ছিন্ন অবস্থায় থাকতে পারে!
    ///
    ///
    /// সুতরাং আক্রমণকারীরা হলেন:
    /// - `data[alive]` জীবিত (যেমন বৈধ উপাদান রয়েছে)
    /// - `data[..alive.start]` এবং এক্স 100 এক্স মারা গেছে (যেমন উপাদানগুলি ইতিমধ্যে পঠিত ছিল এবং অবশ্যই আর স্পর্শ করা উচিত নয়!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` এ থাকা উপাদানগুলি যা এখনও পাওয়া যায় নি।
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// প্রদত্ত `array` এর উপরে একটি নতুন পুনরাবৃত্তি তৈরি করে।
    ///
    /// *দ্রষ্টব্য*: এই পদ্ধতিটি [`IntoIterator` is implemented for arrays][array-into-iter] এর পরে future এ অবহেলা করা যেতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` এর ধরণটি এখানে `&i32` এর পরিবর্তে একটি `i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // সুরক্ষা: এখানে ট্রান্সমিটটি আসলে নিরাপদ।`MaybeUninit` এর ডক্স
        // promise:
        //
        // > `MaybeUninit<T>` একই আকার এবং প্রান্তিককরণের গ্যারান্টিযুক্ত
        // > এক্স 100 এক্স হিসাবে
        //
        // দস্তাবেজগুলি এমনকি `MaybeUninit<T>` এর অ্যারে থেকে `T` এর অ্যারেতে ট্রান্সমিট দেখায়।
        //
        //
        // তার সাথে, এই সূচনাটি আক্রমণকারীদের সন্তুষ্ট করে।

        // FIXME(LukasKalbertodt): বাস্তবে `mem::transmute` ব্যবহার করুন, এটি একবার জেনারিকগুলির সাথে কাজ করে:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ততক্ষণে আমরা আলাদা ধরণের হিসাবে কিছুটা বিটওয়ালা অনুলিপি তৈরি করতে `mem::transmute_copy` ব্যবহার করতে পারি, তারপরে `array` ভুলে যা যাতে এটি বাদ না যায়।
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// এখনও পাওয়া যায় নি যে সমস্ত উপাদান একটি অপরিবর্তনীয় টুকরা ফেরত।
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // নিরাপত্তা: আমরা জানি যে `alive` এর মধ্যে সমস্ত উপাদান সঠিকভাবে শুরু হয়েছে।
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// এখনও পাওয়া যায় নি এমন সমস্ত উপাদানগুলির একটি পরিবর্তনীয় স্লাইস প্রদান করে।
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // নিরাপত্তা: আমরা জানি যে `alive` এর মধ্যে সমস্ত উপাদান সঠিকভাবে শুরু হয়েছে।
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // সামনে থেকে পরবর্তী সূচি পান।
        //
        // `alive.start` 1 দ্বারা বৃদ্ধি করা `alive` সম্পর্কিত আক্রমণকারী বজায় রাখে।
        // যাইহোক, এই পরিবর্তনের কারণে অল্প সময়ের জন্য, জীবিত অঞ্চলটি আর `data[alive]` নয়, তবে `data[idx..alive.end]`।
        //
        self.alive.next().map(|idx| {
            // অ্যারে থেকে উপাদানটি পড়ুন।
            // নিরাপদ: এক্স 100 এক্স এর পূর্বের এক্স01 এক্স অঞ্চলে একটি সূচক
            // অ্যারে।এই উপাদানটি পড়ার অর্থ হল যে `data[idx]` এখন মৃত হিসাবে গণ্য হবে (অর্থাত স্পর্শ করবেন না)।
            // যেহেতু এক্স00 এক্স জীবিত-জোনটির সূচনা ছিল, জীবিত অঞ্চলটি এখন আবার এক্স 011 এক্স, সমস্ত আক্রমণকারীকে পুনরুদ্ধার করে।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // পিছন থেকে পরবর্তী সূচি পান।
        //
        // `alive.end` কে 1 দ্বারা হ্রাস করা `alive` সম্পর্কিত আক্রমণকারী বজায় রাখে।
        // যাইহোক, এই পরিবর্তনের কারণে অল্প সময়ের জন্য, জীবিত অঞ্চলটি আর `data[alive]` নয়, তবে `data[alive.start..=idx]`।
        //
        self.alive.next_back().map(|idx| {
            // অ্যারে থেকে উপাদানটি পড়ুন।
            // নিরাপদ: এক্স 100 এক্স এর পূর্বের এক্স01 এক্স অঞ্চলে একটি সূচক
            // অ্যারে।এই উপাদানটি পড়ার অর্থ হল যে `data[idx]` এখন মৃত হিসাবে গণ্য হবে (অর্থাত স্পর্শ করবেন না)।
            // যেহেতু এক্স00 এক্স জীবন্ত-অঞ্চলের শেষ ছিল, জীবিত অঞ্চলটি এখন আবার এক্স01 এক্স, সমস্ত আক্রমণকারীকে পুনরুদ্ধার করে।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // নিরাপদ: এটি নিরাপদ: এক্স00 এক্স ঠিক সাব-স্লাইস ফেরায়
        // এমন উপাদানগুলির মধ্যে যেগুলি এখনও সরানো হয়নি এবং সেগুলি ফেলে দেওয়া হবে।
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // আক্রমণকারী `live.start <=এর কারণে কখনও ডুবে থাকবে না
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// পুনরুক্তিকারী প্রকৃতপক্ষে সঠিক দৈর্ঘ্যের রিপোর্ট করে।
// "alive" উপাদানগুলির সংখ্যা (এটি এখনও পাওয়া যাবে) `alive` এর ব্যাপ্তির দৈর্ঘ্য।
// এই ব্যাপ্তিটি `next` বা `next_back` হয় দৈর্ঘ্যে হ্রাস করা হয়।
// এই পদ্ধতিগুলিতে এটি সর্বদা 1 দ্বারা হ্রাস করা হয় তবে কেবলমাত্র `Some(_)` ফেরত দেওয়া হয়।
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // দ্রষ্টব্য, আমাদের সত্যিকারের একই জীবন্ত পরিসরের মিলের প্রয়োজন নেই, তাই `self` যেখানেই থাকুক না কেন আমরা কেবল অফসেট 0-এ ক্লোন করতে পারি।
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // সমস্ত জীবন্ত উপাদান ক্লোন করুন।
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // নতুন অ্যারেতে একটি ক্লোন লিখুন, তারপরে তার জীবন্ত পরিসীমাটি আপডেট করুন।
            // যদি panics ক্লোনিং হয় তবে আমরা পূর্ববর্তী আইটেমগুলি সঠিকভাবে ফেলে দেব।
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // কেবলমাত্র সেই উপাদানগুলি মুদ্রণ করুন যা এখনও ফলিত হয়নি: আমরা ফলিত উপাদানগুলিতে আর অ্যাক্সেস করতে পারি না।
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}