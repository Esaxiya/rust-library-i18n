#![stable(feature = "futures_api", since = "1.36.0")]

//! অ্যাসিনক্রোনাস টাস্কগুলির সাথে কাজ করার জন্য প্রকারগুলি এবং জেড 0 ট্রাইটস জেড।

mod poll;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::poll::Poll;

mod wake;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::wake::{Context, RawWaker, RawWakerVTable, Waker};

mod ready;
#[unstable(feature = "ready_macro", issue = "70922")]
pub use ready::ready;