//! লাইবকোরের জন্য Panic সমর্থন
//!
//! মূল লাইব্রেরি প্যানিকিং সংজ্ঞায়িত করতে পারে না, তবে এটি *ডিক্লেয়ার* প্যানিকিং does
//! এর অর্থ হল যে লাইবকোরের ভিতরে থাকা ফাংশনগুলি জেডপ্যানিক0জেডের জন্য অনুমোদিত, তবে একটি উপবাহিত জেড0crate0Z অবশ্যই লাইবকোরের জন্য প্যানিকিং সংজ্ঞায়িত করতে হবে।
//! আতঙ্কিত হওয়ার জন্য বর্তমান ইন্টারফেসটি হ'ল:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! এই সংজ্ঞাটি কোনও সাধারণ বার্তা নিয়ে আতঙ্কিত করতে দেয় তবে এটি `Box<Any>` মান দিয়ে ব্যর্থ হওয়ার অনুমতি দেয় না।
//! (`PanicInfo`-এ কেবল একটি `&(dyn Any + Send)` রয়েছে, যার জন্য আমরা `PanicInfo: : অভ্যন্তরীণ_ কনস্ট্রাক্টর` এ একটি ডামি মান পূরণ করি)) এর কারণ হ'ল লাইবকোর বরাদ্দ করার অনুমতি নেই।
//!
//!
//! এই মডিউলে কয়েকটি অন্যান্য প্যানিকিং ফাংশন রয়েছে তবে এটি কেবল সংকলকটির জন্য প্রয়োজনীয় ল্যাং আইটেম।সমস্ত panics এই এক ফাংশনটির মাধ্যমে সজ্জিত।
//! আসল প্রতীকটি `#[panic_handler]` বৈশিষ্ট্যের মাধ্যমে ঘোষিত হয়।
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// লাইবকোরের `panic!` ম্যাক্রোর অন্তর্নিহিত বাস্তবায়ন যখন কোনও বিন্যাস ব্যবহার করা হয় না।
#[cold]
// কল সাইটগুলিতে যতটা সম্ভব ফোন ব্লাট এড়ানোর জন্য প্যানিক_মিডিয়েট_এবোর্ট না এড়ুন না
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ওভারফ্লো এবং অন্যান্য এক্স 100 এক্স এমআইআর টার্মিনেটরগুলিতে জেড 0 প্যানিক0 জেড এর কোডজেন দ্বারা প্রয়োজনীয়
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // সম্ভাব্যভাবে ওভারহেডের আকার হ্রাস করতে format_args এর পরিবর্তে Arguments::new_v1 ব্যবহার করুন ("{}", এক্সপ্রেস)।
    // ফর্ম্যাট_আর্গস!ম্যাক্রো এক্সপ্রেস লিখতে str এর প্রদর্শন trait ব্যবহার করে, যা Formatter::pad কল করে, যা অবশ্যই স্ট্রিং ট্রাঙ্কেশন এবং প্যাডিং সামঞ্জস্য করতে পারে (যদিও এখানে কোনওটি ব্যবহৃত হয় না)।
    //
    // Arguments::new_v1 ব্যবহার করে সংকলকটি কয়েক কিলোবাইট পর্যন্ত সাশ্রয় করে আউটপুট বাইনারি থেকে Formatter::pad বাদ দিতে পারে।
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // কনস্ট্যান্ড-মূল্যায়িত panics এর জন্য প্রয়োজনীয়
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice অ্যাক্সেসে panic এর জন্য কোডজেন দ্বারা প্রয়োজনীয়
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ফর্ম্যাটিং ব্যবহার করার সময় লাইবকোরের `panic!` ম্যাক্রোর অন্তর্নিহিত বাস্তবায়ন।
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // দ্রষ্টব্য এই ফাংশনটি কখনই এফএফআই সীমানা অতিক্রম করে না;এটি একটি Rust-to-Rust কল যা `#[panic_handler]` ফাংশনে সমাধান হয়ে যায়।
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // নিরাপদ: `panic_impl` নিরাপদ Rust কোডে সংজ্ঞায়িত করা হয়েছে এবং এভাবে কল করা নিরাপদ।
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` এবং `assert_ne!` ম্যাক্রোগুলির জন্য অভ্যন্তরীণ ফাংশন
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}