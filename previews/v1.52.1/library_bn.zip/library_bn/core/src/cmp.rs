//! অর্ডার এবং তুলনা জন্য কার্যকারিতা।
//!
//! এই মডিউলটিতে মানগুলি তুলনা এবং তুলনা করার জন্য বিভিন্ন সরঞ্জাম রয়েছে।সংক্ষেপে:
//!
//! * [`Eq`] এবং [`PartialEq`] হল traits যা আপনাকে যথাক্রমে মানগুলির মধ্যে মোট এবং আংশিক সাম্যতা সংজ্ঞায়িত করতে দেয়।
//! এগুলি কার্যকর করে `==` এবং `!=` অপারেটরগুলি ওভারলোড করে।
//! * [`Ord`] এবং [`PartialOrd`] হল traits যা আপনাকে যথাক্রমে মানগুলির মধ্যে মোট এবং আংশিক ক্রম সংজ্ঞা দিতে দেয় allow
//!
//! এগুলি প্রয়োগ করে `<`, `<=`, `>`, এবং `>=` অপারেটরগুলি ওভারলোড করে।
//! * [`Ordering`] [`Ord`] এবং [`PartialOrd`] এর মূল ফাংশন দ্বারা ফিরে আসা এনাম, এবং একটি অর্ডার বর্ণনা করে describes
//! * [`Reverse`] এমন একটি কাঠামো যা আপনাকে সহজেই একটি অর্ডারকে বিপরীত করতে দেয়।
//! * [`max`] এবং [`min`] হ'ল ফাংশন যা [`Ord`] ছাড়িয়ে যায় এবং আপনাকে সর্বোচ্চ বা সর্বনিম্ন দুটি মান সন্ধান করতে দেয়।
//!
//! আরও তথ্যের জন্য, তালিকার প্রতিটি আইটেমের সম্পর্কিত ডকুমেন্টেশন দেখুন।
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) এর সমতার তুলনা করার জন্য Z0 ট্র্যাটিটজেড।
///
/// এই জেড 0 ট্রাইট0 জেড আংশিক সমতার জন্য মঞ্জুরি দেয়, এমন ধরণের জন্য যাদের সম্পূর্ণ সমতার সম্পর্ক নেই।
/// উদাহরণস্বরূপ, ভাসমান পয়েন্ট সংখ্যা `NaN != NaN` এ, তাই ভাসমান পয়েন্টের ধরণেরগুলি `PartialEq` প্রয়োগ করে তবে [`trait@Eq`] নয়।
///
/// আনুষ্ঠানিকভাবে, সাম্যতা অবশ্যই হবে (সমস্ত `a`, `b`, `A`, `B`, `C` প্রকারের `c`):
///
/// - **প্রতিসাম্য**: যদি `A: PartialEq<B>` এবং `B: PartialEq<A>` হয়, তবে **`a==b` বোঝায়`বি==এ`**;এবং
///
/// - **ট্রানজিটিভ**: যদি `A: PartialEq<B>` এবং `B: PartialEq<C>` এবং `A:
///   আংশিক<C>`, তারপরে **` a==b`এবং `b == c` বোঝায়`a==সি***।
///
/// নোট করুন যে `B: PartialEq<A>` (symmetric) এবং `A: PartialEq<C>` (transitive) ইমপ্লগুলি উপস্থিত থাকতে বাধ্য হয় না, তবে এই প্রয়োজনীয়তাগুলি যখনই বিদ্যমান থাকে তখনই প্রযোজ্য।
///
/// ## Derivable
///
/// এই trait `#[derive]` এর সাথে ব্যবহার করা যেতে পারে।স্ট্রাক্টগুলিতে অঙ্কিত হওয়ার সময়, সমস্ত ক্ষেত্র সমান হলে দুটি ঘটনা সমান হয় এবং কোনও ক্ষেত্র সমান না হলে সমান হয় না।যখন এনামগুলিতে উদ্ভূত হয়, প্রতিটি বৈকল্পিক নিজের সমান এবং অন্য রূপগুলির সমান নয়।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// `PartialEq` কেবলমাত্র [`eq`] পদ্ধতিটি প্রয়োগ করা প্রয়োজন;এক্স02 এক্স এর শর্তাবলী ডিফল্টরূপে সংজ্ঞায়িত করা হয়।[`ne`] * এর যেকোন ম্যানুয়াল প্রয়োগকরণকে অবশ্যই এই বিধিটি সম্মান করতে হবে যে [`eq`] [`ne`] এর কঠোর বিপরীত;এটি হল `!(a == b)` যদি এবং কেবলমাত্র `a != b`।
///
/// `PartialEq`, [`PartialOrd`] এবং [`Ord`]*এর বাস্তবায়ন অবশ্যই* একে অপরের সাথে একমত হতে হবে।দুর্ঘটনাক্রমে traits এর কিছু সংগ্রহ করে এবং অন্যকে ম্যানুয়ালি প্রয়োগ করে এগুলিকে ভুল করে দেওয়া সহজ।
///
/// কোনও ডোমেনের জন্য উদাহরণ বাস্তবায়ন যেখানে ফর্ম্যাটগুলি পৃথক হলেও তার আইএসবিএন মেলে দুটি বই একই বই হিসাবে বিবেচিত হবে:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## আমি কীভাবে দুটি ভিন্ন ধরণের তুলনা করতে পারি?
///
/// আপনি যে ধরণের সাথে তুলনা করতে পারেন তা `আংশিকEq` টাইপ পরামিতি দ্বারা নিয়ন্ত্রিত হয়।
/// উদাহরণস্বরূপ, আসুন আমাদের আগের কোডটি কিছুটা টুইট করুন:
///
/// ```
/// // উদ্ভূত সরঞ্জাম<BookFormat>==<BookFormat>তুলনা
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // বাস্তবায়ন<Book>==<BookFormat>তুলনা
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // বাস্তবায়ন<BookFormat>==<Book>তুলনা
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` কে `impl PartialEq<BookFormat> for Book` এ পরিবর্তন করে, আমরা `Bookformat`s কে`Book`s এর সাথে তুলনা করার অনুমতি দিই।
///
/// উপরের মত একটি তুলনা, যা কাঠামোর কিছু ক্ষেত্র উপেক্ষা করে, বিপজ্জনক হতে পারে।এটি সহজেই আংশিক সমতুল্য সম্পর্কের জন্য প্রয়োজনীয়তার অযৌক্তিক লঙ্ঘনের দিকে পরিচালিত করতে পারে।
/// উদাহরণস্বরূপ, যদি আমরা `BookFormat` এর জন্য `PartialEq<Book>` এর উপরের প্রয়োগটি রেখেছি এবং `Book` এর জন্য `PartialEq<Book>` এর একটি প্রয়োগ যুক্ত করেছি (হয় একটি এক্স04 এক্স এর মাধ্যমে অথবা প্রথম উদাহরণ থেকে ম্যানুয়াল প্রয়োগের মাধ্যমে) তবে ফলাফলটি ট্রানজিটিভিটি লঙ্ঘন করবে:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// এই পদ্ধতিটি `self` এবং `other` মানগুলির সমান হতে পারে এবং এটি `==` দ্বারা ব্যবহৃত হয় tests
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// এই পদ্ধতিটি `!=` এর জন্য পরীক্ষা করে।
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) এর সমতার তুলনা করার জন্য Z0 ট্র্যাটিটজেড।
///
/// এর অর্থ, `a == b` এবং `a != b` কঠোর বিপরীত হওয়া ছাড়াও, সাম্যতাটি অবশ্যই হবে (সমস্ত `a`, `b` এবং `c` এর জন্য):
///
/// - reflexive: `a == a`;
/// - প্রতিসম: `a == b` এর অর্থ `b == a`;এবং
/// - ট্রানজিটিভ: `a == b` এবং `b == c` বোঝায় `a == c`।
///
/// এই সম্পত্তিটি সংকলক দ্বারা চেক করা যায় না, এবং তাই `Eq` [`PartialEq`] বোঝায় এবং এর কোনও অতিরিক্ত পদ্ধতি নেই।
///
/// ## Derivable
///
/// এই trait `#[derive]` এর সাথে ব্যবহার করা যেতে পারে।
/// যখন ডেরিভেড করা হয়, কারণ `Eq` এর কোনও অতিরিক্ত পদ্ধতি নেই, তবে এটি কেবল সংকলককে জানিয়ে দিচ্ছে যে এটি একটি আংশিক সমতা সম্পর্কের চেয়ে সমতা সম্পর্ক nce
///
/// দ্রষ্টব্য যে `derive` কৌশলটি সমস্ত ক্ষেত্রের প্রয়োজন `Eq` যা সর্বদা পছন্দসই নয়।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// আপনি যদি `derive` কৌশলটি ব্যবহার করতে না পারেন তবে উল্লেখ করুন যে আপনার প্রকারটি `Eq` প্রয়োগ করে, যার কোনও পদ্ধতি নেই:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // এই পদ্ধতিটি কেবল#[deriving] দ্বারা ব্যবহৃত হয় যে এক ধরণের প্রতিটি উপাদান নিজেই প্রয়োগ করে [[ডারিং]], বর্তমান ডেরাইভিং অবকাঠামো মানে এই trait এ কোনও পদ্ধতি ব্যবহার না করেই এই দৃ doing়তা করা প্রায় অসম্ভব।
    //
    //
    // এটি কখনও হাতে প্রয়োগ করা উচিত নয়।
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: এই কাঠামোটি সম্পূর্ণরূপে#[ডেরিভ] দ্বারা ব্যবহৃত হয়
// প্রতিস্থাপন করুন যে প্রকারের প্রতিটি উপাদান Eq প্রয়োগ করে।
//
// এই কাঠামোটি কখনই ব্যবহারকারীর কোডে প্রদর্শিত হবে না।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// একটি এক্স00 এক্স দুটি মানের মধ্যে তুলনার ফলাফল।
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// একটি অর্ডার যেখানে তুলনামূলক মান অন্যের চেয়ে কম হয়।
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// একটি অর্ডার যেখানে তুলনামূলক মান অন্যটির সমান।
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// একটি অর্ডার যেখানে তুলনামূলক মান অন্যের চেয়ে বেশি।
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ক্রমটি `Equal` বৈকল্পিক হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ক্রমটি `Equal` বৈকল্পিক না হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ক্রমটি `Less` বৈকল্পিক হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ক্রমটি `Greater` বৈকল্পিক হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ক্রমটি `Less` বা `Equal` বৈকল্পিক হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ক্রমটি `Greater` বা `Equal` বৈকল্পিক হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` বিপরীত।
    ///
    /// * `Less` এক্স 100 এক্স হয়ে যায়।
    /// * `Greater` এক্স 100 এক্স হয়ে যায়।
    /// * `Equal` এক্স 100 এক্স হয়ে যায়।
    ///
    /// # Examples
    ///
    /// বেসিক আচরণ:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// এই পদ্ধতিটি একটি তুলনা বিপরীতে ব্যবহার করা যেতে পারে:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // বৃহত্তম থেকে ক্ষুদ্রতম বিন্যাস সাজান।
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// চেইন দুটি অর্ডারিং।
    ///
    /// `Equal` না হলে `self` প্রদান করে।অন্যথায় `other` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// প্রদত্ত ফাংশন সহ ক্রম শৃঙ্খলাবদ্ধ করে।
    ///
    /// এক্স 100 এক্স না হলে এক্স01 এক্স প্রদান করে।
    /// অন্যথায় `f` কে কল করে ফলাফলটি দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// বিপরীত ক্রমের জন্য একটি সহায়ক কাঠামো।
///
/// এই স্ট্রাক্টটি [`Vec::sort_by_key`] এর মতো ফাংশনগুলির সাথে ব্যবহৃত হেল্পার এবং এটি কোনও কী এর অংশকে বিপরীত অর্ডার করতে ব্যবহার করা যেতে পারে।
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) আকারের ধরণের জন্য Trait।
///
/// একটি অর্ডার মোট অর্ডার হয় যদি তা হয় (সমস্ত `a`, `b` এবং `c` এর জন্য):
///
/// - মোট এবং অসম্পূর্ণ: `a < b`, `a == b` বা `a > b` এর মধ্যে একটি সত্য;এবং
/// - ট্রানজিটিভ, `a < b` এবং `b < c` এক্স01 এক্সকে বোঝায়।এটি অবশ্যই `==` এবং `>` উভয়ের জন্যই রাখা উচিত।
///
/// ## Derivable
///
/// এই trait `#[derive]` এর সাথে ব্যবহার করা যেতে পারে।
/// যখন স্ট্রাক্টগুলিতে ডারভেড করা হয়, এটি স্ট্রাক্টের সদস্যদের উপরে থেকে নীচে ঘোষণার আদেশের উপর ভিত্তি করে একটি এক্স00 এক্স অর্ডার তৈরি করে।
///
/// যখন এনামগুলিতে প্রাপ্ত হয়, তখন ভেরিয়েন্টগুলি তাদের শীর্ষ থেকে নীচে বৈষম্যমূলক আদেশ অনুসারে অর্ডার করা হয়।
///
/// ## অভিধানের তুলনা
///
/// ডিক্সোগ্রাফিকাল তুলনা নিম্নলিখিত বৈশিষ্ট্যগুলির সাথে একটি অপারেশন:
///  - দুটি ক্রম উপাদান দ্বারা উপাদান তুলনা করা হয়।
///  - প্রথম অমিল উপাদানটি নির্ধারণ করে যে কোন অনুক্রমটি অভিধানের তুলনায় অন্যের চেয়ে কম বা বেশি।
///  - যদি একটি সিকোয়েন্স অন্যটির উপসর্গ হয় তবে সংক্ষিপ্ত ক্রমটি অন্যের তুলনায় শব্দকোষগতভাবে কম।
///  - যদি দুটি অনুক্রমের সমতুল্য উপাদান থাকে এবং একই দৈর্ঘ্যের হয় তবে সিকোয়েন্সগুলি অভিধানিকভাবে সমান।
///  - একটি খালি সিকোয়েন্সটি কোনও খালি খালি অনুক্রমের চেয়ে অভিধানিকভাবে কম।
///  - দুটি খালি সিকোয়েন্স ডিক্সিকোগ্রাফিকভাবে সমান।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// `Ord` প্রকারটি [`PartialOrd`] এবং [`Eq`] (যার জন্য [`PartialEq`] প্রয়োজন) হওয়া দরকার।
///
/// তারপরে আপনাকে অবশ্যই [`cmp`] এর জন্য একটি বাস্তবায়ন সংজ্ঞায়িত করতে হবে।আপনার ধরণের ক্ষেত্রগুলিতে [`cmp`] ব্যবহার করা আপনার পক্ষে দরকারী হতে পারে।
///
/// [`PartialEq`], [`PartialOrd`] এবং `Ord`*এর বাস্তবায়ন অবশ্যই* একে অপরের সাথে একমত হতে হবে।
/// এটি হল `a.cmp(b) == Ordering::Equal` যদি এবং কেবলমাত্র `a == b` এবং সমস্ত `a` এবং `b` এর জন্য এক্স03 এক্স।
/// দুর্ঘটনাক্রমে traits এর কিছু সংগ্রহ করে এবং অন্যকে ম্যানুয়ালি প্রয়োগ করে এগুলিকে ভুল করে দেওয়া সহজ।
///
/// `id` এবং `name` উপেক্ষা করে আপনি কেবল উচ্চতা অনুসারে লোককে বাছাই করতে চান এমন একটি উদাহরণ এখানে:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// এই পদ্ধতিটি `self` এবং `other` এর মধ্যে একটি [`Ordering`] প্রদান করে।
    ///
    /// কনভেনশন দ্বারা, `self.cmp(&other)` সত্য হিসাবে যদি এক্স01 এক্স এক্সপ্রেশনটির সাথে মিলিত ক্রমটি প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// সর্বাধিক দুটি মান তুলনা করে এবং প্রদান করে।
    ///
    /// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে দ্বিতীয় যুক্তিটি ফিরিয়ে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// সর্বনিম্ন দুটি মানের তুলনা করে এবং প্রদান করে।
    ///
    /// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে প্রথম যুক্তিটি ফেরত দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// একটি নির্দিষ্ট বিরতিতে একটি মান সীমাবদ্ধ করুন।
    ///
    /// `self` `max` এর চেয়ে বেশি হলে `max` এবং `self` যদি `min` এর চেয়ে কম হয় তবে `max` প্রদান করে।
    /// অন্যথায় এটি `self` প্রদান করে।
    ///
    /// # Panics
    ///
    /// `min > max` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// সজ্জা-ক্রমের সাথে তুলনা করা যায় এমন মানগুলির জন্য Trait।
///
/// `a`, `b` এবং `c` এর জন্য অবশ্যই তুলনাটি সন্তুষ্ট করতে হবে:
///
/// - অসম্পূর্ণতা: যদি `a < b` হয় তবে `!(a > b)`, পাশাপাশি `a > b` বোঝায় `!(a < b)`;এবং
/// - ট্রানজিটিভিটি: `a < b` এবং `b < c` এক্স01 এক্সকে বোঝায়।এটি অবশ্যই `==` এবং `>` উভয়ের জন্যই রাখা উচিত।
///
/// নোট করুন যে এই প্রয়োজনীয়তার অর্থ trait নিজেই প্রতিসম ও ট্রানজিটিভভাবে প্রয়োগ করা উচিত: যদি `T: PartialOrd<U>` এবং `U: PartialOrd<V>` তবে `U: PartialOrd<T>` এবং `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// এই trait `#[derive]` এর সাথে ব্যবহার করা যেতে পারে।স্ট্রাক্টগুলিতে যখন ডারভেড করা হয়, তখন এটি স্ট্রাক্টের সদস্যদের উপরে থেকে নীচে ঘোষণার আদেশের উপর ভিত্তি করে একটি অভিধান সংক্রান্ত অর্ডার তৈরি করে।
/// যখন এনামগুলিতে প্রাপ্ত হয়, তখন ভেরিয়েন্টগুলি তাদের শীর্ষ থেকে নীচে বৈষম্যমূলক আদেশ অনুসারে অর্ডার করা হয়।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// `PartialOrd` ডিফল্ট বাস্তবায়ন থেকে উত্পন্ন অন্যান্যগুলির সাথে কেবলমাত্র [`partial_cmp`] পদ্ধতি বাস্তবায়ন প্রয়োজন।
///
/// তবে সামগ্রিক অর্ডার নেই এমন ধরণের জন্য পৃথকভাবে পৃথকভাবে প্রয়োগ করা সম্ভব remains
/// উদাহরণস্বরূপ, ভাসমান পয়েন্ট সংখ্যাগুলির জন্য, `NaN < 0 == false` এবং `NaN >= 0 == false` (সিএফ।
/// আইইইই 754-2008 বিভাগ 5.11)।
///
/// `PartialOrd` আপনার টাইপটি [`PartialEq`] হওয়া দরকার।
///
/// [`PartialEq`], `PartialOrd` এবং [`Ord`]*এর বাস্তবায়ন অবশ্যই* একে অপরের সাথে একমত হতে হবে।
/// দুর্ঘটনাক্রমে traits এর কিছু সংগ্রহ করে এবং অন্যকে ম্যানুয়ালি প্রয়োগ করে এগুলিকে ভুল করে দেওয়া সহজ।
///
/// যদি আপনার প্রকারটি [`Ord`] হয়, আপনি [`cmp`] ব্যবহার করে [`partial_cmp`] প্রয়োগ করতে পারেন:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// আপনি আপনার টাইপের ক্ষেত্রগুলিতে [`partial_cmp`] ব্যবহার করাও দরকারী বলে মনে করতে পারেন।
/// এখানে `Person` প্রকারের উদাহরণ রয়েছে যার স্লোটিং পয়েন্ট `height` ক্ষেত্র রয়েছে যা বাছাইয়ের জন্য কেবলমাত্র ক্ষেত্র:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// এই পদ্ধতিটি যদি বিদ্যমান থাকে তবে `self` এবং `other` মানের মধ্যে অর্ডার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// তুলনা যখন অসম্ভব:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// এই পদ্ধতিটি (`self` এবং `other` এর চেয়ে কম) পরীক্ষা করে এবং `<` অপারেটর দ্বারা ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// এই পদ্ধতিটি (`self` এবং `other` এর জন্য) এর চেয়ে কম বা সমান পরীক্ষা করে এবং `<=` অপারেটর দ্বারা ব্যবহৃত হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// এই পদ্ধতিটি (`self` এবং `other` এর চেয়ে বেশি) পরীক্ষা করে এবং `>` অপারেটর দ্বারা ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// এই পদ্ধতিটি (`self` এবং `other` এর জন্য) এর চেয়ে বড় বা সমান পরীক্ষা করে এবং `>=` অপারেটর দ্বারা ব্যবহৃত হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// সর্বনিম্ন দুটি মানের তুলনা করে এবং প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে প্রথম যুক্তিটি ফেরত দেয়।
///
/// অভ্যন্তরীণভাবে [`Ord::min`] থেকে একটি উপকরণ ব্যবহার করে।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// নির্দিষ্ট তুলনা ফাংশনটি সম্মানের সাথে সর্বনিম্ন দুটি মান প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে প্রথম যুক্তিটি ফেরত দেয়।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// নির্দিষ্ট ফাংশন থেকে ন্যূনতম মান দেয় এমন উপাদানটি প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে প্রথম যুক্তিটি ফেরত দেয়।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// সর্বাধিক দুটি মান তুলনা করে এবং প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে দ্বিতীয় যুক্তিটি ফিরিয়ে দেয়।
///
/// অভ্যন্তরীণভাবে [`Ord::max`] থেকে একটি উপনাম ব্যবহার করে।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// নির্দিষ্ট তুলনা ফাংশনটি সম্মানের সাথে সর্বাধিক দুটি মান প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে দ্বিতীয় যুক্তিটি ফিরিয়ে দেয়।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// নির্দিষ্ট ফাংশন থেকে সর্বাধিক মান দেয় এমন উপাদানটি প্রদান করে।
///
/// তুলনা যদি তাদের সমান হতে নির্ধারণ করে তবে দ্বিতীয় যুক্তিটি ফিরিয়ে দেয়।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// আদিম ধরণের জন্য আংশিকEq, এক, আংশিক ও অর্ডের প্রয়োগ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // আরও অনুকূল সমাবেশ উত্পন্ন করার জন্য এখানে আদেশটি গুরুত্বপূর্ণ।
                    // আরও তথ্যের জন্য <https://github.com/rust-lang/rust/issues/63758> দেখুন।
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // আই 8 এর মধ্যে কাস্টিং এবং পার্থক্যটিকে একটি অর্ডারিংয়ে রূপান্তর করা আরও অনুকূল সমাবেশ তৈরি করে।
            //
            // আরও তথ্যের জন্য <https://github.com/rust-lang/rust/issues/66780> দেখুন।
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // নিরাপদ: i8 হিসাবে 0 বা 1 হিসাবে bool প্রত্যাবর্তন করে, তাই পার্থক্য অন্য কিছু হতে পারে না
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &পয়েন্টার

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}