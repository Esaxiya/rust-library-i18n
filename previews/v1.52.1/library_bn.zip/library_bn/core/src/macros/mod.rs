#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // কলারের সংস্করণের উপর নির্ভর করে `$crate::panic::panic_2015` বা `$crate::panic::panic_2021` হয় প্রসারিত।
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// দুটি এক্সপ্রেশন একে অপরের সমান বলে দাবি করে (এক্স 100 এক্স ব্যবহার করে)।
///
/// panic এ, এই ম্যাক্রো তাদের ডিবাগ উপস্থাপনাগুলি দিয়ে এক্সপ্রেশনগুলির মানগুলি মুদ্রণ করবে।
///
///
/// এক্স00 এক্সের মতো, এই ম্যাক্রোর একটি দ্বিতীয় ফর্ম রয়েছে, যেখানে একটি কাস্টম জেড 0 স্প্যানিক0 জেড বার্তা সরবরাহ করা যেতে পারে।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // নীচের reborrows ইচ্ছাকৃত।
                    // তাদের ছাড়া, comparedণের জন্য স্ট্যাক স্লটটি মানগুলির তুলনা করার আগেই শুরু করা হয়, যার ফলে লক্ষণীয়ভাবে ধীরগতি হয়।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // নীচের reborrows ইচ্ছাকৃত।
                    // তাদের ছাড়া, comparedণের জন্য স্ট্যাক স্লটটি মানগুলির তুলনা করার আগেই শুরু করা হয়, যার ফলে লক্ষণীয়ভাবে ধীরগতি হয়।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// দুটি এক্সপ্রেশন একে অপরের সমান নয় বলে দাবি করে (এক্স 100 এক্স ব্যবহার করে)।
///
/// panic এ, এই ম্যাক্রো তাদের ডিবাগ উপস্থাপনাগুলি দিয়ে এক্সপ্রেশনগুলির মানগুলি মুদ্রণ করবে।
///
///
/// এক্স00 এক্সের মতো, এই ম্যাক্রোর একটি দ্বিতীয় ফর্ম রয়েছে, যেখানে একটি কাস্টম জেড 0 স্প্যানিক0 জেড বার্তা সরবরাহ করা যেতে পারে।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // নীচের reborrows ইচ্ছাকৃত।
                    // তাদের ছাড়া, comparedণের জন্য স্ট্যাক স্লটটি মানগুলির তুলনা করার আগেই শুরু করা হয়, যার ফলে লক্ষণীয়ভাবে ধীরগতি হয়।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // নীচের reborrows ইচ্ছাকৃত।
                    // তাদের ছাড়া, comparedণের জন্য স্ট্যাক স্লটটি মানগুলির তুলনা করার আগেই শুরু করা হয়, যার ফলে লক্ষণীয়ভাবে ধীরগতি হয়।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// জোর দিয়েছিল যে রানির সময় একটি বুলিয়ান এক্সপ্রেশন `true`।
///
/// এটি প্রদত্ত এক্সপ্রেশনটি যদি রানটাইমের সময় `true` এ মূল্যায়ন না করা যায় তবে এটি [`panic!`] ম্যাক্রোকে ডেকে আনবে।
///
/// [`assert!`] এর মতো, এই ম্যাক্রোরও একটি দ্বিতীয় সংস্করণ রয়েছে, যেখানে একটি কাস্টম জেড 0 স্প্যানিক0 জেড বার্তা সরবরাহ করা যেতে পারে।
///
/// # Uses
///
/// [`assert!`] এর বিপরীতে, `debug_assert!` বিবৃতি কেবলমাত্র ডিফল্টরূপে অপ্টিমাইজড বিল্ডগুলিতে সক্ষম হয়।
/// `-C debug-assertions` সংকলকটি পাস না করা হলে একটি অনুকূলিত বিল্ড `debug_assert!` বিবৃতি কার্যকর করবে না।
/// এটি এক্স 100 এক্সকে চেকগুলির জন্য দরকারী করে তোলে যা একটি রিলিজ বিল্ডে উপস্থিত হওয়া খুব ব্যয়বহুল তবে বিকাশের সময় সহায়ক হতে পারে।
/// এক্স00 এক্স প্রসারণের ফলাফল সর্বদা টাইপ করে পরীক্ষা করা হয়।
///
/// একটি চেক না করা দৃser়তা একটি অসামঞ্জস্যপূর্ণ অবস্থার মধ্যে একটি প্রোগ্রাম চালিয়ে যেতে দেয়, যার অপ্রত্যাশিত পরিণতি হতে পারে তবে যতক্ষণ না এটি কেবল নিরাপদ কোডে ঘটে ততক্ষণ অনর্থক পরিচয় দেয় না।
///
/// দাবিগুলির পারফরম্যান্স ব্যয়টি অবশ্য সাধারণভাবে পরিমাপযোগ্য নয়।
/// [`assert!`] কে `debug_assert!` এর সাথে প্রতিস্থাপন করা কেবল পুরোপুরি প্রোফাইলের পরে উত্সাহিত করা হয় এবং আরও গুরুত্বপূর্ণ, কেবল নিরাপদ কোডেই!
///
/// # Examples
///
/// ```
/// // এই প্রতিবেদনের জন্য panic বার্তাটি দেওয়া অভিব্যক্তিটির স্ট্রিংফাইড মান।
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // একটি খুব সাধারণ ফাংশন
/// debug_assert!(some_expensive_computation());
///
/// // একটি কাস্টম বার্তা সহ জোড়
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// দুটি এক্সপ্রেশন একে অপরের সমান বলে দাবি করে।
///
/// panic এ, এই ম্যাক্রো তাদের ডিবাগ উপস্থাপনাগুলি দিয়ে এক্সপ্রেশনগুলির মানগুলি মুদ্রণ করবে।
///
/// [`assert_eq!`] এর বিপরীতে, `debug_assert_eq!` বিবৃতি কেবলমাত্র ডিফল্টরূপে অপ্টিমাইজড বিল্ডগুলিতে সক্ষম হয়।
/// `-C debug-assertions` সংকলকটি পাস না করা হলে একটি অনুকূলিত বিল্ড `debug_assert_eq!` বিবৃতি কার্যকর করবে না।
/// এটি এক্স 100 এক্সকে চেকগুলির জন্য দরকারী করে তোলে যা একটি রিলিজ বিল্ডে উপস্থিত হওয়া খুব ব্যয়বহুল তবে বিকাশের সময় সহায়ক হতে পারে।
///
/// এক্স00 এক্স প্রসারণের ফলাফল সর্বদা টাইপ করে পরীক্ষা করা হয়।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// দুটি এক্সপ্রেশন একে অপরের সমান নয় বলে দাবি করে।
///
/// panic এ, এই ম্যাক্রো তাদের ডিবাগ উপস্থাপনাগুলি দিয়ে এক্সপ্রেশনগুলির মানগুলি মুদ্রণ করবে।
///
/// [`assert_ne!`] এর বিপরীতে, `debug_assert_ne!` বিবৃতি কেবলমাত্র ডিফল্টরূপে অপ্টিমাইজড বিল্ডগুলিতে সক্ষম হয়।
/// `-C debug-assertions` সংকলকটিতে পাস না করা হলে একটি অনুকূলিত বিল্ড `debug_assert_ne!` বিবৃতি কার্যকর করবে না।
/// এটি এক্স 100 এক্সকে চেকগুলির জন্য দরকারী করে তোলে যা একটি রিলিজ বিল্ডে উপস্থিত হওয়া খুব ব্যয়বহুল তবে বিকাশের সময় সহায়ক হতে পারে।
///
/// এক্স00 এক্স প্রসারণের ফলাফল সর্বদা টাইপ করে পরীক্ষা করা হয়।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// প্রদত্ত অভিব্যক্তি প্রদত্ত নিদর্শনগুলির কোনওটির সাথে মেলে কিনা s
///
/// একটি `match` মত প্রকাশের মতো, প্যাটার্নটি বিকল্পভাবে `if` এবং গার্ড অভিব্যক্তি দ্বারা অনুসরণ করা যেতে পারে যা প্যাটার্ন দ্বারা আবদ্ধ নামগুলিতে অ্যাক্সেস রয়েছে।
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// কোনও ফলাফলকে মোড়ানো হয় না বা এর ত্রুটি প্রচার করে।
///
/// `?` অপারেটরটি `try!` প্রতিস্থাপন করতে যুক্ত করা হয়েছিল এবং এর পরিবর্তে ব্যবহার করা উচিত।
/// তদ্ব্যতীত, `try` Rust 2018 এর একটি সংরক্ষিত শব্দ, সুতরাং আপনার যদি এটি অবশ্যই ব্যবহার করতে হয় তবে আপনাকে [raw-identifier syntax][ris] ব্যবহার করতে হবে: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` প্রদত্ত [`Result`] এর সাথে মেলে।`Ok` বৈকল্পিকের ক্ষেত্রে, অভিব্যক্তিটির মোড়ানো মানটির মান থাকে।
///
/// `Err` বৈকল্পিকের ক্ষেত্রে এটি অভ্যন্তরীণ ত্রুটিটি পুনরুদ্ধার করে।`try!` এর পরে `From` ব্যবহার করে রূপান্তর সম্পাদন করে।
/// এটি বিশেষায়িত ত্রুটি এবং আরও সাধারণগুলির মধ্যে স্বয়ংক্রিয় রূপান্তর সরবরাহ করে।
/// এরপরে ত্রুটি তত্ক্ষণাত্ ফিরিয়ে দেওয়া হয়।
///
/// প্রারম্ভিক রিটার্নের কারণে, `try!` কেবলমাত্র ফাংশনগুলিতে ব্যবহার করা যেতে পারে যা [`Result`] ফেরত দেয়।
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ত্রুটি দ্রুত ফেরত দেওয়ার পছন্দের পদ্ধতি
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // তাত্ক্ষণিক তাড়াতাড়ি ফিরে আসার আগের পদ্ধতি
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // এটি সমান:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ফর্ম্যাট করা ডেটা বাফারে লিখে দেয়।
///
/// এই ম্যাক্রো একটি 'writer', একটি ফর্ম্যাট স্ট্রিং এবং যুক্তিগুলির তালিকা গ্রহণ করে।
/// যুক্তিগুলি নির্দিষ্ট বিন্যাসের স্ট্রিং অনুসারে ফর্ম্যাট করা হবে এবং ফলাফলটি লেখকের কাছে পৌঁছে দেওয়া হবে।
/// `write_fmt` পদ্ধতিতে লেখকের কোনও মূল্য হতে পারে;সাধারণত এটি [`fmt::Write`] বা [`io::Write`] trait এর বাস্তবায়ন থেকে আসে।
/// `write_fmt` পদ্ধতিটি যাই হোক না কেন ম্যাক্রো ফিরিয়ে দেয়;সাধারণত একটি [`fmt::Result`], বা একটি এক্স 100 এক্স।
///
/// বিন্যাসের স্ট্রিং সিনট্যাক্স সম্পর্কিত আরও তথ্যের জন্য [`std::fmt`] দেখুন।
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// একটি মডিউল `std::fmt::Write` এবং `std::io::Write` উভয়ই আমদানি করতে পারে এবং এক্সট্যাকশন প্রয়োগকারীগুলিতে `write!` কল করতে পারে, কারণ বস্তুগুলি সাধারণত উভয় প্রয়োগ করে না।
///
/// তবে মডিউলটি অবশ্যই traits যোগ্যকে আমদানি করতে হবে যাতে তাদের নামগুলি বিরোধ না করে:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // এক্স 100 এক্স ব্যবহার করে
///     write!(&mut v, "s = {:?}", s)?; // এক্স 100 এক্স ব্যবহার করে
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: এই ম্যাক্রোটি `no_std` সেটআপগুলিতেও ব্যবহার করা যেতে পারে।
/// একটি এক্স 100 এক্স সেটআপে আপনি উপাদানগুলির প্রয়োগের বিশদটির জন্য দায়বদ্ধ।
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// একটি নতুন লাইন যুক্ত করা সহ একটি বাফারে ফর্ম্যাট করা ডেটা লিখুন।
///
/// সমস্ত প্ল্যাটফর্মে, নতুনলাইনটি একা লাইন ফিড অক্ষর (`\n`/`U+000A`) (কোনও অতিরিক্ত ক্যারিজ রিটার্ন (`\r`/`U+000D`) এক্স নয়।
///
/// আরও তথ্যের জন্য, এক্স01 এক্স দেখুন।বিন্যাস স্ট্রিং সিনট্যাক্স সম্পর্কিত তথ্যের জন্য, [`std::fmt`] দেখুন।
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// একটি মডিউল `std::fmt::Write` এবং `std::io::Write` উভয়ই আমদানি করতে পারে এবং এক্সট্যাকশন প্রয়োগকারীগুলিতে `write!` কল করতে পারে, কারণ বস্তুগুলি সাধারণত উভয় প্রয়োগ করে না।
/// তবে মডিউলটি অবশ্যই traits যোগ্যকে আমদানি করতে হবে যাতে তাদের নামগুলি বিরোধ না করে:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // এক্স 100 এক্স ব্যবহার করে
///     writeln!(&mut v, "s = {:?}", s)?; // এক্স 100 এক্স ব্যবহার করে
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// অ্যাক্সেসযোগ্য কোডটি ইঙ্গিত করে।
///
/// এটি যে কোনও সময় কার্যকর যখন সংকলকটি নির্ধারণ করতে পারে না যে কিছু কোড অ্যাক্সেসযোগ্য।উদাহরণ স্বরূপ:
///
/// * গার্ডের শর্তের সাথে অস্ত্র মিলান।
/// * গতিশীলভাবে শেষ হওয়া লুপগুলি।
/// * গতিশীলরূপে সমাপ্তিকারী ইটারেটর।
///
/// কোডটি অ্যাক্সেসযোগ্য নয় এমন সংকল্পটি যদি ভুল প্রমাণ করে তবে প্রোগ্রামটি তত্ক্ষণাত একটি [`panic!`] দিয়ে সমাপ্ত হবে।
///
/// এই ম্যাক্রোর অনিরাপদ অংশটি হল [`unreachable_unchecked`] ফাংশন, কোডটি পৌঁছে গেলে অপরিজ্ঞাত আচরণের কারণ হবে।
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// এটি সর্বদা [`panic!`] থাকবে।
///
/// # Examples
///
/// অস্ত্র মিল:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // মন্তব্য করা হলে সংকলন ত্রুটি
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // এক্স00 এক্স এর দরিদ্রতম বাস্তবায়নগুলির মধ্যে একটি
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" এর বার্তা নিয়ে আতঙ্কিত করে অবিহিত কোডটি ইঙ্গিত করে।
///
/// এটি আপনার কোডকে টাইপ-চেক করার অনুমতি দেয়, যা আপনি যদি কোনও trait প্রোটোটাইপিং বা প্রয়োগ করে থাকেন তবে এমন একাধিক পদ্ধতির প্রয়োজন হয় যা আপনি সমস্ত ব্যবহারের পরিকল্পনা করেন না useful
///
/// `unimplemented!` এবং [`todo!`] এর মধ্যে পার্থক্যটি হ'ল `todo!` পরে কার্যকারিতা বাস্তবায়নের একটি অভিপ্রায় জানায় এবং বার্তাটি "not yet implemented", এক্স01 এক্স এরকম কোনও দাবি করে না।
/// এর বার্তাটি "not implemented"।
/// এছাড়াও কিছু আইডিই `টুডো! Mark গুলি চিহ্নিত করবে।
///
/// # Panics
///
/// এটি সর্বদা [`panic!`] থাকবে কারণ `unimplemented!` একটি নির্দিষ্ট, নির্দিষ্ট বার্তা সহ `panic!` এর জন্য কেবল একটি শর্টহ্যান্ড।
///
/// `panic!` এর মতো, এই ম্যাক্রোর কাস্টম মানগুলি প্রদর্শনের জন্য একটি দ্বিতীয় ফর্ম রয়েছে।
///
/// # Examples
///
/// বলুন আমাদের একটি trait `Foo` রয়েছে:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// আমরা 'MyStruct' এর জন্য `Foo` বাস্তবায়ন করতে চাই, তবে কিছু কারণে এটি কেবল `bar()` ফাংশনটি বাস্তবায়িত করার জন্য বোধগম্য।
/// `baz()` এবং `qux()` এখনও আমাদের `Foo` এর বাস্তবায়নে সংজ্ঞায়িত করা দরকার, তবে আমরা আমাদের কোডটি সংকলন করার জন্য তাদের সংজ্ঞাগুলিতে `unimplemented!` ব্যবহার করতে পারি।
///
/// আমরা যদি এখনও প্রয়োগ না করা পদ্ধতিগুলিতে পৌঁছে যাই তবে আমাদের প্রোগ্রামটি বন্ধ হওয়া চাই।
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // এটি `baz` কে একটি `MyStruct` করার কোনও অর্থ দেয় না, সুতরাং আমাদের এখানে কোনও যুক্তি নেই।
/////
///         // এটি এক্স 100 এক্স প্রদর্শন করবে।
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // আমাদের এখানে কিছু যুক্তি রয়েছে, আমরা অযৌক্তিকভাবে একটি বার্তা যুক্ত করতে পারি!আমাদের বাদ দেওয়ার জন্য।
///         // এটি প্রদর্শিত হবে: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// অসম্পূর্ণ কোড নির্দেশ করে।
///
/// আপনি যদি প্রোটোটাইপ করছেন এবং কেবল আপনার কোড টাইপচেকের সন্ধান করছেন তবে এটি কার্যকর হতে পারে।
///
/// [`unimplemented!`] এবং `todo!` এর মধ্যে পার্থক্যটি হ'ল `todo!` পরে কার্যকারিতা বাস্তবায়নের একটি অভিপ্রায় জানায় এবং বার্তাটি "not yet implemented", এক্স01 এক্স এরকম কোনও দাবি করে না।
/// এর বার্তাটি "not implemented"।
/// এছাড়াও কিছু আইডিই `টুডো! Mark গুলি চিহ্নিত করবে।
///
/// # Panics
///
/// এটি সর্বদা [`panic!`] থাকবে।
///
/// # Examples
///
/// কিছু অগ্রগতি কোডের একটি উদাহরণ এখানে।আমাদের একটি trait `Foo` রয়েছে:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// আমরা আমাদের যে কোনও একটিতে `Foo` প্রয়োগ করতে চাই, তবে আমরা প্রথমে কেবল `bar()` এ কাজ করতে চাই।আমাদের কোডটি সংকলন করার জন্য, আমাদের `baz()` প্রয়োগ করতে হবে, যাতে আমরা `todo!` ব্যবহার করতে পারি:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // বাস্তবায়ন এখানে যায়
///     }
///
///     fn baz(&self) {
///         // আপাতত baz() বাস্তবায়ন সম্পর্কে চিন্তা করবেন না
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // আমরা এমনকি baz() ব্যবহার করছি না, তাই এটি ঠিক আছে।
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// অন্তর্নির্মিত ম্যাক্রোর সংজ্ঞা।
///
/// সর্বাধিক ম্যাক্রো বৈশিষ্ট্য (স্থিতিশীলতা, দৃশ্যমানতা ইত্যাদি) এখানে উত্স কোড থেকে নেওয়া হয়েছে, ম্যাক্রো ইনপুটগুলিকে আউটপুটগুলিতে রূপান্তরকারী সম্প্রসারণ ফাংশন ব্যতীত functions ফাংশনগুলি সংকলক দ্বারা সরবরাহ করা হয়।
///
///
pub(crate) mod builtin {

    /// সংঘটিত হওয়ার সময় প্রদত্ত ত্রুটি বার্তাটি দিয়ে সংকলন ব্যর্থ হয়।
    ///
    /// এই ম্যাক্রোটি ব্যবহার করা উচিত যখন কোনও crate ভুল অবস্থার জন্য আরও ভাল ত্রুটি বার্তাগুলি সরবরাহ করার জন্য শর্তসাপেক্ষ সংকলনের কৌশল ব্যবহার করে।
    ///
    /// এটি [`panic!`] এর সংকলক-স্তর ফর্ম, তবে *রানটাইম* এর পরিবর্তে *সংকলন* চলাকালীন একটি ত্রুটি প্রকাশ করে।
    ///
    /// # Examples
    ///
    /// এরকম দুটি উদাহরণ হ'ল ম্যাক্রোগুলি এবং এক্স00 এক্স পরিবেশ।
    ///
    /// কোনও ম্যাক্রো অবৈধ মানগুলি পাস করা হলে আরও ভাল সংকলক ত্রুটি নির্গত করুন।
    /// চূড়ান্ত জেড0 ফ্রেঞ্চ0 জেড ব্যতীত, সংকলকটি এখনও একটি ত্রুটি নির্গত করবে, তবে ত্রুটির বার্তাটি দুটি বৈধ মান উল্লেখ করবে না।
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// সংখ্যক বৈশিষ্ট্যগুলির মধ্যে একটি উপলব্ধ না হলে সংকলক ত্রুটি নির্গত করুন।
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// অন্যান্য স্ট্রিং-ফর্ম্যাট ম্যাক্রোগুলির জন্য প্যারামিটার তৈরি করে।
    ///
    /// এই ম্যাক্রো প্রতিটি অতিরিক্ত আর্গুমেন্ট পাস করার জন্য `{}` যুক্ত ফর্ম্যাটিং স্ট্রিং আক্ষরিক গ্রহণ করে functions
    /// `format_args!` আউটপুটটিকে একটি স্ট্রিং হিসাবে ব্যাখ্যা করা যায় এবং আর্গুমেন্টগুলিকে একক প্রকারে রূপান্তর করতে পারে তা নিশ্চিত করতে অতিরিক্ত পরামিতি প্রস্তুত করে।
    /// [`Display`] trait প্রয়োগকারী যে কোনও মান `format_args!` এ যেতে পারে, যে কোনও [`Debug`] বাস্তবায়ন বিন্যাসের স্ট্রিংয়ের মধ্যে একটি `{:?}` এ যেতে পারে।
    ///
    ///
    /// এই ম্যাক্রো প্রকারের [`fmt::Arguments`] এর মান তৈরি করে।দরকারী পুনঃনির্দেশ সঞ্চালনের জন্য এই মানটি [`std::fmt`] এর মধ্যে ম্যাক্রোগুলিতে প্রেরণ করা যেতে পারে।
    /// অন্যান্য সমস্ত ফর্ম্যাটিং ম্যাক্রো ([`ফর্ম্যাট!`], এক্স00 এক্স, এক্স0১ এক্স, ইত্যাদি) এর মাধ্যমে প্রক্সাইড করা হয়েছে।
    /// `format_args!`, এর উত্সযুক্ত ম্যাক্রোগুলির বিপরীতে, গাদা বরাদ্দ এড়ানো হয়।
    ///
    /// আপনি [`fmt::Arguments`] মানটি ব্যবহার করতে পারেন যা `format_args!` `Debug` এবং `Display` প্রসঙ্গে নীচে দেখেছে returns
    /// উদাহরণটি একই জিনিসকে `Debug` এবং `Display` ফর্ম্যাটটিও দেখায়: `format_args!` এ ইন্টারপোলটেড ফর্ম্যাট স্ট্রিং।
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// আরও তথ্যের জন্য ডকুমেন্টেশনটি [`std::fmt`] এ দেখুন।
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` হিসাবে একই, তবে শেষ পর্যন্ত একটি নতুন লাইন যুক্ত করে।
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// সংকলন সময়ে পরিবেশের পরিবর্তনশীল পরীক্ষা করে।
    ///
    /// এই ম্যাক্রোটি সংকলন সময়ে নামকরা পরিবেশের পরিবর্তনশীলের মানগুলিতে প্রসারিত হবে, `&'static str` টাইপের এক্সপ্রেশন দেয় yield
    ///
    ///
    /// যদি পরিবেশের পরিবর্তনশীল সংজ্ঞায়িত না হয় তবে একটি সংকলন ত্রুটি নির্গত হবে।
    /// একটি সংকলন ত্রুটি নির্গত না করতে, পরিবর্তে [`option_env!`] ম্যাক্রো ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// আপনি দ্বিতীয় পরামিতি হিসাবে একটি স্ট্রিং পাস করে ত্রুটি বার্তা কাস্টমাইজ করতে পারেন:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// যদি `documentation` পরিবেশের পরিবর্তনশীল সংজ্ঞায়িত না করা হয় তবে আপনি নিম্নলিখিত ত্রুটিটি পাবেন:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// সংকলনের সময় environmentচ্ছিকভাবে একটি পরিবেশের পরিবর্তনশীল পরীক্ষা করে।
    ///
    /// যদি নামকরণ পরিবেশ পরিবর্তনশীল সংকলন সময়ে উপস্থিত হয়, এটি `Option<&'static str>` প্রকারের অভিব্যক্তিতে প্রসারিত হবে যার মান পরিবেশের ভেরিয়েবলের মানের `Some`।
    /// যদি পরিবেশের পরিবর্তনশীল উপস্থিত না হয়, তবে এটি `None` এ প্রসারিত হবে।
    /// এই ধরণের আরও তথ্যের জন্য [`Option<T>`][Option] দেখুন।
    ///
    /// পরিবেশের পরিবর্তনশীল উপস্থিত কিনা তা নির্বিশেষে এই ম্যাক্রোটি ব্যবহার করার সময় কোনও সংকলন সময় ত্রুটি কখনই নির্গত হয় না।
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// সনাক্তকারীদের একটি সনাক্তকারী হিসাবে সংঘবদ্ধ করে।
    ///
    /// এই ম্যাক্রো বহু সংখ্যক কমা-বিচ্ছিন্ন শনাক্তকারী গ্রহণ করে এবং সেগুলি সমস্তকে একত্রে যুক্ত করে, একটি এক্সপ্রেশন দেয় যা একটি নতুন শনাক্তকারী।
    /// নোট করুন যে স্বাস্থ্যকরন এটিকে এমন করে তোলে যে এই ম্যাক্রো স্থানীয় ভেরিয়েবলগুলি ক্যাপচার করতে পারে না।
    /// এছাড়াও, একটি সাধারণ নিয়ম হিসাবে, ম্যাক্রোগুলি কেবলমাত্র আইটেম, বিবৃতি বা অভিব্যক্তি অবস্থানের মধ্যে অনুমোদিত allowed
    /// এর অর্থ আপনি যখন এই ম্যাক্রোটি বিদ্যমান ভেরিয়েবল, ফাংশন বা মডিউল ইত্যাদির উল্লেখ করতে ব্যবহার করতে পারেন তবে আপনি এটির সাথে কোনও নতুন সংজ্ঞা দিতে পারবেন না।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn কনক্যাট_বাসী! (নতুন, মজাদার, নাম) { }//এইভাবে ব্যবহারযোগ্য নয়!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// আক্ষরিককে একটি স্ট্যাটিক স্ট্রিং স্লাইসে প্রতিযোগিত করে।
    ///
    /// এই ম্যাক্রোটি বহু সংখ্যক কমা-বিভাজিত আক্ষরিক গ্রহণ করে, প্রকারের `&'static str` এর একটি বহিঃপ্রকাশ যা সমস্ত আক্ষরিককে বাম থেকে ডানে একত্রিত করে উপস্থাপন করে।
    ///
    ///
    /// সংক্ষিপ্ত হওয়ার জন্য পূর্ণসংখ্যার এবং ভাসমান পয়েন্ট আক্ষরিকগুলিকে স্ট্রাইফ করা হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// যে রেখাটিটি চাওয়া হয়েছিল তাতে প্রসারিত হয়।
    ///
    /// [`column!`] এবং [`file!`] এর সাহায্যে, এই ম্যাক্রোগুলি উত্সের মধ্যে অবস্থান সম্পর্কে বিকাশকারীদের জন্য ডিবাগিং তথ্য সরবরাহ করে।
    ///
    /// প্রসারিত এক্সপ্রেশনটিতে `u32` টাইপ রয়েছে এবং এটি 1-ভিত্তিক, সুতরাং প্রতিটি ফাইলের প্রথম লাইনটি 1, দ্বিতীয় থেকে 2, ইত্যাদিতে মূল্যায়ন করে
    /// এটি সাধারণ সংকলক বা জনপ্রিয় সম্পাদকদের ত্রুটি বার্তাগুলির সাথে সামঞ্জস্যপূর্ণ।
    /// ফিরে আসা রেখাটি *অগত্যা*`line!` অনুরোধের লাইন নয়, বরং প্রথম ম্যাক্রো অনুরোধটি `line!` ম্যাক্রোর অনুরোধ অবধি সঞ্চারিত হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// এটি যে কলাম নম্বরটিতে প্রেরণ করা হয়েছিল তা প্রসারিত করে।
    ///
    /// [`line!`] এবং [`file!`] এর সাহায্যে, এই ম্যাক্রোগুলি উত্সের মধ্যে অবস্থান সম্পর্কে বিকাশকারীদের জন্য ডিবাগিং তথ্য সরবরাহ করে।
    ///
    /// প্রসারিত এক্সপ্রেশনটিতে `u32` টাইপ রয়েছে এবং এটি 1-ভিত্তিক, সুতরাং প্রতিটি লাইনের প্রথম কলামটি 1, দ্বিতীয় থেকে 2, ইত্যাদি মূল্যায়ন করে etc.
    /// এটি সাধারণ সংকলক বা জনপ্রিয় সম্পাদকদের ত্রুটি বার্তাগুলির সাথে সামঞ্জস্যপূর্ণ।
    /// ফিরে আসা কলামটি *অগত্যা* নিজেই `column!` অনুরোধের লাইন নয়, বরং প্রথম ম্যাক্রো অনুরোধটি `column!` ম্যাক্রোর প্রার্থনা অবধি নেতৃত্ব দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// যে ফাইল ফাইলটি এটি চাওয়া হয়েছিল তাতে প্রসারিত হয়।
    ///
    /// [`line!`] এবং [`column!`] এর সাহায্যে, এই ম্যাক্রোগুলি উত্সের মধ্যে অবস্থান সম্পর্কে বিকাশকারীদের জন্য ডিবাগিং তথ্য সরবরাহ করে।
    ///
    /// প্রসারিত এক্সপ্রেশনটিতে `&'static str` টাইপ রয়েছে এবং ফিরে আসা ফাইলটি নিজেই এক্স01 এক্স ম্যাক্রোর অনুরোধ নয়, বরং প্রথম ম্যাক্রো অনুরোধ যা এক্স0 2 এক্স ম্যাক্রোকে ডেকে আনে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// এর যুক্তিগুলি স্ট্রিংফাই করে।
    ///
    /// এই ম্যাক্রোটি `&'static str` প্রকারের একটি অভিব্যক্তি প্রকাশ করবে যা ম্যাক্রোতে পাস হওয়া সমস্ত tokens এর স্ট্রিংফিকেশন।
    /// নিজেই ম্যাক্রো অনুরোধের বাক্য গঠনতে কোনও বিধিনিষেধ স্থাপন করা হয় না।
    ///
    /// নোট করুন যে tokens ইনপুটটির প্রসারিত ফলাফলগুলি future এ পরিবর্তিত হতে পারে।আপনি যদি আউটপুটে ভরসা করেন তবে আপনার সাবধান হওয়া উচিত।
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// স্ট্রিং হিসাবে একটি UTF-8 এনকোডযুক্ত ফাইল অন্তর্ভুক্ত।
    ///
    /// ফাইলটি বর্তমান ফাইলের সাথে সম্পর্কিত (একইভাবে মডিউলগুলি কীভাবে পাওয়া যায়) সম্পর্কিত।
    /// প্রদত্ত পাথটি সংকলনের সময় প্ল্যাটফর্ম-নির্দিষ্ট উপায়ে ব্যাখ্যা করা হয়।
    /// সুতরাং, উদাহরণস্বরূপ, ব্যাকস্ল্যাশস `\` যুক্ত একটি Windows পাথের সাথে একটি অনুরোধটি Unix এ সঠিকভাবে সংকলন করবে না।
    ///
    ///
    /// এই ম্যাক্রোটি `&'static str` প্রকারের একটি এক্সপ্রেশন প্রকাশ করবে যা ফাইলের বিষয়বস্তু।
    ///
    /// # Examples
    ///
    /// ধরুন নিম্নলিখিত ডিরেক্টরিতে একই ডিরেক্টরিতে দুটি ফাইল রয়েছে:
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' সংকলন এবং ফলাফল বাইনারি চালানো "adiós" মুদ্রণ করবে।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// বাইট অ্যারের রেফারেন্স হিসাবে একটি ফাইল অন্তর্ভুক্ত।
    ///
    /// ফাইলটি বর্তমান ফাইলের সাথে সম্পর্কিত (একইভাবে মডিউলগুলি কীভাবে পাওয়া যায়) সম্পর্কিত।
    /// প্রদত্ত পাথটি সংকলনের সময় প্ল্যাটফর্ম-নির্দিষ্ট উপায়ে ব্যাখ্যা করা হয়।
    /// সুতরাং, উদাহরণস্বরূপ, ব্যাকস্ল্যাশস `\` যুক্ত একটি Windows পাথের সাথে একটি অনুরোধটি Unix এ সঠিকভাবে সংকলন করবে না।
    ///
    ///
    /// এই ম্যাক্রোটি `&'static [u8; N]` প্রকারের একটি এক্সপ্রেশন প্রকাশ করবে যা ফাইলের বিষয়বস্তু।
    ///
    /// # Examples
    ///
    /// ধরুন নিম্নলিখিত ডিরেক্টরিতে একই ডিরেক্টরিতে দুটি ফাইল রয়েছে:
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' সংকলন এবং ফলাফল বাইনারি চালানো "adiós" মুদ্রণ করবে।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// একটি স্ট্রিংয়ে প্রসারিত হয় যা বর্তমান মডিউল পথকে উপস্থাপন করে।
    ///
    /// বর্তমান মডিউল পাথটি crate root পর্যন্ত ফিরে যাওয়া মডিউলগুলির শ্রেণিবিন্যাস হিসাবে ভাবা যেতে পারে।
    /// ফিরে আসা পথের প্রথম উপাদানটি বর্তমানে সংকলিত জেড 0 ক্রেট 0 জেডের নাম।
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// সংকলন সময়ে কনফিগারেশন পতাকাগুলির বুলিয়ান সংমিশ্রণগুলি মূল্যায়ন করে।
    ///
    /// `#[cfg]` গুণাবলী ছাড়াও, এই ম্যাক্রোটি কনফিগারেশন পতাকাগুলির বুলিয়ান অভিব্যক্তি মূল্যায়নের অনুমতি দেওয়ার জন্য সরবরাহ করা হয়।
    /// এটি প্রায়শই কম সদৃশ কোডের দিকে নিয়ে যায়।
    ///
    /// এই ম্যাক্রোর দেওয়া সিনট্যাক্সটি [`cfg`] অ্যাট্রিবিউটের মতো একই সিনট্যাক্স।
    ///
    /// `cfg!`, `#[cfg]` এর বিপরীতে, কোনও কোড অপসারণ করে না এবং কেবল সত্য বা মিথ্যাতে মূল্যায়ন করে।
    /// উদাহরণস্বরূপ,if/else এক্স মূল্যায়ন করছে তা নির্বিশেষে শর্তের জন্য `cfg!` ব্যবহার করার সময় একটি এক্স00 এক্স এক্সপ্রেশনের সমস্ত ব্লকের বৈধ হওয়া দরকার।
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// প্রসঙ্গ অনুযায়ী কোনও ফাইলকে এক্সপ্রেশন বা আইটেম হিসাবে পার্স করে।
    ///
    /// ফাইলটি বর্তমান ফাইলের তুলনায় অবস্থিত (একইভাবে মডিউলগুলি কীভাবে পাওয়া যায়)।প্রদত্ত পাথটি সংকলনের সময় প্ল্যাটফর্ম-নির্দিষ্ট উপায়ে ব্যাখ্যা করা হয়।
    /// সুতরাং, উদাহরণস্বরূপ, ব্যাকস্ল্যাশস `\` যুক্ত একটি Windows পাথের সাথে একটি অনুরোধটি Unix এ সঠিকভাবে সংকলন করবে না।
    ///
    /// এই ম্যাক্রোটি ব্যবহার করা প্রায়শই একটি খারাপ ধারণা, কারণ যদি ফাইলটি একটি এক্সপ্রেশন হিসাবে পার্স করা হয় তবে এটি আশেপাশের কোডটিতে অসুস্থ্যভাবে স্থাপন করা হবে।
    /// এটির পরিবর্তে ভেরিয়েবল বা ফাংশনগুলি ফাইলের প্রত্যাশার থেকে আলাদা হতে পারে যদি বর্তমান ফাইলে একই নাম থাকা ভেরিয়েবল বা ফাংশন থাকে।
    ///
    ///
    /// # Examples
    ///
    /// ধরুন নিম্নলিখিত ডিরেক্টরিতে একই ডিরেক্টরিতে দুটি ফাইল রয়েছে:
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ফাইল এক্স 100 এক্স:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' সংকলন এবং ফলাফল বাইনারি চালানো "🙈🙊🙉🙈🙊🙉" মুদ্রণ করবে।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// জোর দিয়েছিল যে রানির সময় একটি বুলিয়ান এক্সপ্রেশন `true`।
    ///
    /// এটি প্রদত্ত এক্সপ্রেশনটি যদি রানটাইমের সময় `true` এ মূল্যায়ন না করা যায় তবে এটি [`panic!`] ম্যাক্রোকে ডেকে আনবে।
    ///
    /// # Uses
    ///
    /// দৃ always়তা সর্বদা ডিবাগ এবং রিলিজ উভয় বিল্ডে চেক করা হয়, এবং অক্ষম করা যায় না।
    /// ডিফল্টরূপে রিলিজ বিল্ডগুলিতে সক্ষম নয় এমন প্রতিবেদনের জন্য [`debug_assert!`] দেখুন।
    ///
    /// অন-সুরক্ষিত কোড রান-টাইম ইনগ্রেন্টদের কার্যকর করতে `assert!` এর উপর নির্ভর করতে পারে যা লঙ্ঘন করা হলে অকার্যকর হতে পারে।
    ///
    /// এক্স00 এক্স এর অন্যান্য ব্যবহারের ক্ষেত্রে নিরাপদ কোডে রান-টাইম আক্রমণকারীদের পরীক্ষা করা এবং প্রয়োগ করা (যার লঙ্ঘন অসফল হতে পারে না)।
    ///
    ///
    /// # কাস্টম বার্তা
    ///
    /// এই ম্যাক্রোর একটি দ্বিতীয় ফর্ম রয়েছে, যেখানে বিন্যাসকরণের জন্য বা যুক্তি ছাড়াই একটি কাস্টম panic বার্তা সরবরাহ করা যেতে পারে।
    /// এই ফর্মটির জন্য সিনট্যাক্সের জন্য [`std::fmt`] দেখুন।
    /// ফর্ম্যাট আর্গুমেন্ট হিসাবে ব্যবহৃত অভিব্যক্তিগুলি কেবলমাত্র দৃser়তা ব্যর্থ হলে মূল্যায়ন করা হবে।
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // এই প্রতিবেদনের জন্য panic বার্তাটি দেওয়া অভিব্যক্তিটির স্ট্রিংফাইড মান।
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // একটি খুব সাধারণ ফাংশন
    ///
    /// assert!(some_computation());
    ///
    /// // একটি কাস্টম বার্তা সহ জোড়
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ইনলাইন সমাবেশ।
    ///
    /// ব্যবহারের জন্য [unstable book] পড়ুন।
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-শৈলীর ইনলাইন সমাবেশ।
    ///
    /// ব্যবহারের জন্য [unstable book] পড়ুন।
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// মডিউল স্তরের ইনলাইন সমাবেশ।
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// প্রিন্টগুলি tokens স্ট্যান্ডার্ড আউটপুটটিতে পাস করেছে।
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// অন্যান্য ম্যাক্রো ডিবাগ করার জন্য ব্যবহৃত ট্রেসিং কার্যকারিতা সক্ষম বা অক্ষম করে।
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ডেরিভ ম্যাক্রোগুলি প্রয়োগ করতে ব্যবহৃত অ্যাট্রিবিউট ম্যাক্রো।
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// বৈশিষ্ট্য ম্যাক্রোটিকে কোনও ইউনিট পরীক্ষায় রূপান্তরিত করতে কোনও ফাংশনে প্রয়োগ করা হয়েছে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// বৈশিষ্ট্য ম্যাক্রো কোনও ক্রিয়াকলাপটিকে এটিকে একটি বেঞ্চমার্ক পরীক্ষায় পরিণত করার জন্য প্রয়োগ করা হয়েছিল।
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` এবং `#[bench]` ম্যাক্রোগুলির একটি বাস্তবায়ন বিশদ।
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// বিশ্বব্যাপী বরাদ্দকারী হিসাবে নিবন্ধীকৃত করতে স্ট্যাটিকটিতে অ্যাট্রিবিউট ম্যাক্রো প্রয়োগ করা হয়েছে।
    ///
    /// এক্স 100 এক্সও দেখুন।
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// উত্তীর্ণ পথটি অ্যাক্সেসযোগ্য হলে এটি প্রয়োগ করা আইটেমটি রাখে এবং অন্যথায় এটি সরিয়ে দেয়।
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// কোড বিভাজনে এটি প্রয়োগ করা সমস্ত `#[cfg]` এবং `#[cfg_attr]` গুণাবলী প্রসারিত করে।
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// এক্স 100 এক্স সংকলকটির অস্থির বাস্তবায়ন বিশদ, ব্যবহার করবেন না।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// এক্স 100 এক্স সংকলকটির অস্থির বাস্তবায়ন বিশদ, ব্যবহার করবেন না।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}