// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// এক্স 100 এক্স পরিসীমাটি এমনভাবে ঘোরান যাতে `mid` এ উপাদানটি প্রথম উপাদান হয়ে যায়।সমানভাবে, `left` উপাদানগুলি বাম দিকে বা `right` উপাদানগুলি ডানদিকে ঘোরান।
///
/// # Safety
///
/// নির্দিষ্ট পরিসরটি পড়া এবং লেখার জন্য বৈধ হতে হবে।
///
/// # Algorithm
///
/// অ্যালগরিদম 1 `left + right` এর ছোট মানগুলির জন্য বা বৃহত্তর `T` এর জন্য ব্যবহৃত হয়।
/// এক্সগুলি `mid - left` থেকে শুরু হয়ে `right` পদক্ষেপগুলি মডুলো এক্স00 এক্স দ্বারা এগিয়ে একবারে তাদের চূড়ান্ত অবস্থানে স্থানান্তরিত করা হয়, যেমন কেবলমাত্র একটি অস্থায়ী প্রয়োজন needed
/// অবশেষে, আমরা এক্স 100 এক্স এ ফিরে আসি।
/// যাইহোক, যদি `gcd(left + right, right)` 1 না হয় তবে উপরের পদক্ষেপগুলি উপাদানগুলির বাইরে চলে যায়।
/// উদাহরণ স্বরূপ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ভাগ্যক্রমে, চূড়ান্ত উপাদানগুলির মধ্যে থাকা উপাদানগুলির উপর ছেড়ে যাওয়া সংখ্যা সর্বদা সমান, তাই আমরা কেবল আমাদের শুরু অবস্থানটি অফসেট করতে পারি এবং আরও বেশি রাউন্ড করতে পারি (রাউন্ডের মোট সংখ্যাটি `gcd(left + right, right)` value))।
///
/// শেষ ফলাফলটি হল যে সমস্ত উপাদান একবারে এবং একবারে চূড়ান্ত হয়।
///
/// অ্যালগরিদম 2 ব্যবহৃত হয় যদি `left + right` বড় হয় তবে স্ট্যাক বাফারের সাথে ফিট করার জন্য `min(left, right)` যথেষ্ট ছোট।
/// `min(left, right)` উপাদানগুলি বাফারে অনুলিপি করা হয়, অন্যদের সাথে `memmove` প্রয়োগ করা হয় এবং বাফারে থাকা উপাদানগুলি যেখানে উত্পন্ন হয়েছিল তার বিপরীত দিকে গর্তে ফিরে যায়।
///
/// `left + right` পর্যাপ্ত পরিমাণে বড় হয়ে যাওয়ার পরে উপরের দিক থেকে ভেক্টরাইজ করা যায় এমন অ্যালগরিদমগুলি।
/// অ্যালগরিদম 1 একবারে অনেকগুলি রাউন্ড ছান করে এবং সম্পাদন করে ভেক্টরাইজ করা যায়, তবে `left + right` প্রচুর পরিমাণে না হওয়া পর্যন্ত গড়ে খুব কম রাউন্ড থাকে এবং একক রাউন্ডের সবচেয়ে খারাপ পরিস্থিতি সর্বদা থাকে।
/// পরিবর্তে, অ্যালগোরিদম 3 পুনরায় `min(left, right)` উপাদানগুলির স্ব্যাপিং ব্যবহার করে যতক্ষণ না ছোট ঘোরান সমস্যাটি বাকি থাকে।
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` এর পরিবর্তে বাম দিক থেকে অদলবদল ঘটে।
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. যদি এই কেসগুলি পরীক্ষা না করা হয় তবে নীচের অ্যালগরিদমগুলি ব্যর্থ হতে পারে
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // অ্যালগরিদম 1 মাইক্রোবেঞ্চমার্কগুলি ইঙ্গিত দেয় যে প্রায় `left + right == 32` অবধি র্যান্ডম শিফটগুলির গড় পারফরম্যান্স আরও ভাল, তবে সবচেয়ে খারাপের পারফরম্যান্স এমনকি প্রায় 16 টির মতো বিরতি।
            // 24 মিডল গ্রাউন্ড হিসাবে নির্বাচিত হয়েছিল।
            // যদি `T` এর আকার 4 `usize`s এর চেয়ে বড় হয় তবে এই অ্যালগরিদম অন্যান্য অ্যালগরিদমকেও ছাড়িয়ে যায়।
            //
            //
            let x = unsafe { mid.sub(left) };
            // প্রথম রাউন্ডের শুরু
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` এক্স00 এক্স গণনা করে হাতের আগে পাওয়া যাবে, তবে একটি লুপ করা দ্রুত যা গিসিডি কে পার্শ্ব প্রতিক্রিয়া হিসাবে গণনা করে, তারপর বাকী অংশটি করে
            //
            //
            let mut gcd = right;
            // মানদণ্ডগুলি প্রকাশ করে যে একবারে অস্থায়ী একবার পড়ার পরিবর্তে পিছনের দিকে অনুলিপি করার পরিবর্তে অস্থায়ীভাবে অদলবদল করা দ্রুত এবং তারপরে সেই অস্থায়ী লেখার পক্ষে খুব দ্রুত।
            // এটি সম্ভবত অস্থায়ীভাবে অদলবদল করা বা প্রতিস্থাপনের কারণে দুটি পরিচালনা করার প্রয়োজনের পরিবর্তে লুপে কেবল একটি মেমরি ঠিকানা ব্যবহার করে due
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // এক্স00 এক্স বাড়ানো এবং তারপরে এটি সীমানার বাইরে রয়েছে কিনা তা পরীক্ষা করার পরিবর্তে, আমরা `i` পরের ইনক্রিমেন্টের সীমানার বাইরে চলে কিনা তা পরীক্ষা করে দেখি।
                // এটি পয়েন্টার বা `usize` এর কোনও মোড়ানো বাধা দেয়।
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // প্রথম রাউন্ডের সমাপ্তি
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` হলে এই শর্তসাপেক্ষ অবশ্যই হওয়া উচিত
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // আরও বৃত্তাকার সঙ্গে খণ্ড শেষ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` একটি শূন্য আকারের প্রকার নয়, সুতরাং এটির আকার দিয়ে ভাগ করা ঠিক।
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // অ্যালগরিদম 2 টি X এর জন্য উপযুক্তভাবে প্রান্তিক করা হয়েছে তা নিশ্চিত করার জন্য এখানে `[T; 0]` is
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // অ্যালগরিদম 3 অদলবদলের একটি বিকল্প উপায় রয়েছে যার মধ্যে রয়েছে এই অ্যালগরিদমের শেষ অদলবদলটি কোথায় রয়েছে তা খুঁজে পাওয়া এবং এই অ্যালগরিদমের মতো সংলগ্ন অংশগুলি অদলবদলের পরিবর্তে শেষ অংশটি ব্যবহার করে অদলবদল করা, তবে এই পথটি এখনও আরও দ্রুত।
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // অ্যালগরিদম 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}