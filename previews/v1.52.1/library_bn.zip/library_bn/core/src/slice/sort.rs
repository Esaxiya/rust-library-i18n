//! স্লাইস বাছাই
//!
//! এই মডিউলটিতে ওরসন পিটার্সের প্যাটার্ন-পরাস্তকরণ কোকসোর্টের ভিত্তিতে বাছাই করা অ্যালগরিদম রয়েছে, এখানে প্রকাশিত: <https://github.com/orlp/pdqsort>
//!
//!
//! অস্থির বাছাই লাইবকোরের সাথে সামঞ্জস্যপূর্ণ কারণ এটি আমাদের স্থিতিশীল বাছাইয়ের প্রয়োগের বিপরীতে মেমরির বরাদ্দ দেয় না।
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// নামানো হলে `src` থেকে `dest` এ অনুলিপিগুলি।
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // নিরাপত্তা: এটি একটি সহায়ক শ্রেণি।
        //          সঠিকতার জন্য দয়া করে এর ব্যবহারটি দেখুন।
        //          যথা, এক অবশ্যই `src` এবং `dst` `ptr::copy_nonoverlapping` দ্বারা প্রয়োজনীয় ওভারল্যাপ না করে তা নিশ্চিত হওয়া উচিত।
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// যতক্ষণ না এটি বৃহত্তর বা সমান উপাদানের মুখোমুখি হয় ততক্ষণ প্রথম উপাদানটিকে ডানে সরিয়ে দেয়।
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // নিরাপত্তা: নীচে অনিরাপদ ক্রিয়াকলাপগুলিতে একটি বাউন্ড চেক (`get_unchecked` এবং `get_unchecked_mut`) ছাড়াই ইনডেক্সিং জড়িত
    // এবং মেমরি (`ptr::copy_nonoverlapping`) অনুলিপি করা হচ্ছে।
    //
    // ক।সূচক:
    //  1. আমরা অ্যারেটির আকার>=2 এ যাচাই করেছি।
    //  2. সমস্ত সূচক যা আমরা করব তা সর্বদা সর্বাধিক {0 <= index < len} এর মধ্যে থাকে।
    //
    // খ।স্মৃতি কপি করা
    //  1. আমরা রেফারেন্সগুলিতে পয়েন্টারগুলি পাই যা বৈধ হওয়ার গ্যারান্টিযুক্ত।
    //  2. এগুলি ওভারল্যাপ করতে পারে না কারণ আমরা স্লাইসের সূচকগুলিকে আলাদা করতে পয়েন্টার পাই।
    //     যথা, `i` এবং `i-1`।
    //  3. যদি স্লাইসটি সঠিকভাবে সংযুক্ত থাকে তবে উপাদানগুলি সঠিকভাবে প্রান্তিক করা হয়।
    //     স্লাইসটি সঠিকভাবে সংযুক্ত করা হয়েছে তা নিশ্চিত করা কলারের দায়িত্ব।
    //
    // আরও বিস্তারিত জানার জন্য নীচে মন্তব্য দেখুন।
    unsafe {
        // প্রথম দুটি উপাদান যদি ক্রম ছাড়িয়ে যায় ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // প্রথম উপাদানটি স্ট্যাক-বরাদ্দ ভেরিয়েবলের মধ্যে পড়ুন।
            // যদি নিম্নলিখিত তুলনা অপারেশন panics, `hole` বাদ পড়বে এবং স্বয়ংক্রিয়ভাবে উপাদানটি স্লাইসে ফিরে লিখবে।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-th উপাদানটিকে এক জায়গায় বামে সরান, এভাবে গর্তটি ডানদিকে সরিয়ে নেওয়া হয়।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ফেলে দেওয়া হয় এবং এইভাবে এক্স0 এক্স এক্সকে `v` এর অবশিষ্ট গর্তে অনুলিপি করে।
        }
    }
}

/// কোনও ছোট বা সমান উপাদানের মুখোমুখি না হওয়া অবধি শেষ উপাদানটিকে বামে স্থানান্তর করুন।
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // নিরাপত্তা: নীচে অনিরাপদ ক্রিয়াকলাপগুলিতে একটি বাউন্ড চেক (`get_unchecked` এবং `get_unchecked_mut`) ছাড়াই ইনডেক্সিং জড়িত
    // এবং মেমরি (`ptr::copy_nonoverlapping`) অনুলিপি করা হচ্ছে।
    //
    // ক।সূচক:
    //  1. আমরা অ্যারেটির আকার>=2 এ যাচাই করেছি।
    //  2. সমস্ত সূচক যা আমরা করব তা সর্বদা সর্বাধিক `0 <= index < len-1` এর মধ্যে থাকে।
    //
    // খ।স্মৃতি কপি করা
    //  1. আমরা রেফারেন্সগুলিতে পয়েন্টারগুলি পাই যা বৈধ হওয়ার গ্যারান্টিযুক্ত।
    //  2. এগুলি ওভারল্যাপ করতে পারে না কারণ আমরা স্লাইসের সূচকগুলিকে আলাদা করতে পয়েন্টার পাই।
    //     যথা, `i` এবং `i+1`।
    //  3. যদি স্লাইসটি সঠিকভাবে সংযুক্ত থাকে তবে উপাদানগুলি সঠিকভাবে প্রান্তিক করা হয়।
    //     স্লাইসটি সঠিকভাবে সংযুক্ত করা হয়েছে তা নিশ্চিত করা কলারের দায়িত্ব।
    //
    // আরও বিস্তারিত জানার জন্য নীচে মন্তব্য দেখুন।
    unsafe {
        // শেষ দুটি উপাদান যদি ক্রমহীন থাকে ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // স্ট্যাক-বরাদ্দ ভেরিয়েবলের মধ্যে শেষ উপাদানটি পড়ুন।
            // যদি নিম্নলিখিত তুলনা অপারেশন panics, `hole` বাদ পড়বে এবং স্বয়ংক্রিয়ভাবে উপাদানটি স্লাইসে ফিরে লিখবে।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I the-th উপাদানটিকে এক জায়গায় ডান দিকে সরান, এইভাবে গর্তটি বামে স্থানান্তরিত করুন।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ফেলে দেওয়া হয় এবং এইভাবে এক্স0 এক্স এক্সকে `v` এর অবশিষ্ট গর্তে অনুলিপি করে।
        }
    }
}

/// চারপাশে বেশ কয়েকটি অর্ড-অফ-অর্ডার উপাদানগুলি স্থানান্তর করে আংশিকভাবে একটি স্লাইস সাজান।
///
/// স্লাইসটি শেষে বাছাই করা থাকলে `true` প্রদান করে।এই ফাংশনটি *ও*(*এন*) সবচেয়ে খারাপ ক্ষেত্রে।
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // সর্বাধিক সংখ্যক সংলগ্ন আউট-অফ-অর্ডার জোড়গুলি স্থানান্তরিত হবে।
    const MAX_STEPS: usize = 5;
    // যদি স্লাইস এর চেয়ে কম হয় তবে কোনও উপাদান স্থানান্তর করবেন না।
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // নিরাপত্তা: আমরা ইতিমধ্যে স্পষ্টভাবে `i < len` এর সাথে সীমাবদ্ধ চেকিং করেছি।
        // আমাদের পরবর্তী সমস্ত সূচকগুলি কেবলমাত্র `0 <= index < len` এর মধ্যে রয়েছে
        unsafe {
            // অর্ডার-এর বাইরে থাকা উপাদানগুলির পরের জোড়াটি সন্ধান করুন।
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // আমরা কি সম্পন্ন করেছি?
        if i == len {
            return true;
        }

        // সংক্ষিপ্ত অ্যারেগুলিতে উপাদানগুলি স্থানান্তর করবেন না, এতে পারফরম্যান্স ব্যয় হয়।
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // উপাদানগুলির জোড়া জোড়া অদলবদল করুন।এটি তাদের সঠিক ক্রমে রাখে।
        v.swap(i - 1, i);

        // ছোট উপাদানটিকে বামে স্থানান্তর করুন।
        shift_tail(&mut v[..i], is_less);
        // বৃহত্তর উপাদানটি ডানদিকে স্থানান্তর করুন।
        shift_head(&mut v[i..], is_less);
    }

    // সীমিত সংখ্যক পদক্ষেপে স্লাইসটি সাজানোর ব্যবস্থা করেননি।
    false
}

/// সন্নিবেশ বাছাই করে স্লাইস বাছাই করে, যা *ও*(*এন*^ 2) সবচেয়ে খারাপ অবস্থা।
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// হিপসোর্টটি ব্যবহার করে এক্স 100 এক্স পছন্দ করুন, যা *ও*(*এন*\* এক্স01 এক্স সবচেয়ে খারাপ ক্ষেত্রে) এর গ্যারান্টি দেয়।
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // এই বাইনারি গাদা আক্রমণকারী এক্স 100 এক্সকে সম্মান করে।
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` এর শিশুরা:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // বৃহত্তর শিশু চয়ন করুন।
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // যদি আক্রমণকারীটি `node` এ ধরে থাকে তবে থামুন।
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // বৃহত্তর সন্তানের সাথে এক্স00 এক্স অদলবদল করুন, এক ধাপ নীচে সরুন এবং চালনা চালিয়ে যান।
            v.swap(node, greater);
            node = greater;
        }
    };

    // রৈখিক সময়ে গাদা তৈরি করুন।
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // গাদা থেকে সর্বাধিক উপাদানগুলি পপ করুন।
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` এর চেয়ে ছোট উপাদানগুলিতে পার্টিশনগুলি `v`, এর পরে `pivot` এর চেয়ে বড় বা সমান উপাদানগুলি অনুসরণ করে।
///
///
/// `pivot` এর চেয়ে ছোট উপাদানের সংখ্যা প্রদান করে।
///
/// শাখাগুলি পরিচালনার ব্যয় কমিয়ে আনার জন্য পার্টিশনটি ব্লক বাই ব্লক করা হয় is
/// এই ধারণাটি [BlockQuicksort][pdf] কাগজে উপস্থাপন করা হয়েছে।
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // একটি সাধারণ ব্লকের উপাদানগুলির সংখ্যা।
    const BLOCK: usize = 128;

    // বিভাজন অ্যালগরিদম সমাপ্ত না হওয়া পর্যন্ত নিম্নলিখিত পদক্ষেপ পুনরাবৃত্তি করে:
    //
    // 1. পিভটের চেয়ে বড় বা সমান উপাদানগুলি সনাক্ত করতে বাম দিক থেকে একটি ব্লক সন্ধান করুন।
    // 2. পিভটের চেয়ে ছোট উপাদান চিহ্নিত করতে ডান দিক থেকে একটি ব্লক সন্ধান করুন।
    // 3. বাম এবং ডান পাশের মধ্যে চিহ্নিত উপাদানগুলি বিনিময় করুন।
    //
    // উপাদানগুলির একটি ব্লকের জন্য আমরা নিম্নলিখিত ভেরিয়েবলগুলি রাখি:
    //
    // 1. `block` - ব্লকের উপাদানগুলির সংখ্যা।
    // 2. `start` - `offsets` অ্যারেতে পয়েন্টার শুরু করুন।
    // 3. `end` - এক্স00 এক্স অ্যারেতে শেষ পয়েন্টার।
    // 4. se অফসেটস, ব্লকের মধ্যে আউট-অফ-অর্ডার উপাদানগুলির সূচকগুলি।

    // বাম দিকে বর্তমান ব্লক (`l` থেকে `l.add(block_l)`) এ)।
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ডানদিকে বর্তমান ব্লক (`r.sub(block_r)` to `r`) থেকে)।
    // নিরাপদ: .add() এর ডকুমেন্টেশনে উল্লেখ করা হয়েছে যে `vec.as_ptr().add(vec.len())` সর্বদা নিরাপদ `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: যখন আমরা ভিএলএগুলি পাই, তার পরিবর্তে এক্স এস এক্স এক্স, 2 * ব্লক) এর একটি অ্যারে তৈরি করে দেখুন
    // `BLOCK` দৈর্ঘ্যের দুটি স্থির-আকারের অ্যারের চেয়ে বেশি।VLA গুলি আরও ক্যাশে-দক্ষ হতে পারে।

    // `l` (inclusive) এবং `r` (exclusive) পয়েন্টারগুলির মধ্যে উপাদানের সংখ্যা প্রদান করে।
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` এবং `r` খুব কাছাকাছি আসার সাথে সাথে ব্লক-বাই-ব্লক বিভাজন নিয়ে আমাদের কাজ শেষ।
        // তারপরে অবশিষ্ট উপাদানগুলিকে মাঝখানে ভাগ করার জন্য আমরা কিছু প্যাচ-আপ কাজ করি।
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // অবশিষ্ট উপাদানগুলির সংখ্যা (এখনও পাইভোটের সাথে তুলনা করা হয়নি)।
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ব্লকের আকারগুলি সামঞ্জস্য করুন যাতে বাম এবং ডান ব্লকটি ওভারল্যাপ না হয় তবে পুরো অবশিষ্ট ফাঁকটি coverাকতে পুরোপুরি সারিবদ্ধ হয়ে যান।
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // বাম দিক থেকে `block_l` উপাদানগুলি সন্ধান করুন।
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // নিরাপত্তা: নীচে অসম্পূর্ণ অপারেশনগুলি `offset` এর ব্যবহারের সাথে জড়িত।
                //         ফাংশনটির প্রয়োজনীয় শর্ত অনুযায়ী আমরা তাদের সন্তুষ্ট করি কারণ:
                //         1. `offsets_l` স্ট্যাক বরাদ্দ করা হয়, এবং এইভাবে পৃথক বরাদ্দকৃত বস্তু হিসাবে বিবেচিত হয়।
                //         2. `is_less` ফাংশনটি একটি `bool` প্রদান করে।
                //            একটি `bool` কাস্ট করা কখনই `isize` উপচে পড়বে না।
                //         3. আমরা গ্যারান্টি দিয়েছি যে `block_l` `<= BLOCK` হবে।
                //            প্লাস, `end_l` প্রথমে `offsets_` এর সূচনা পয়েন্টারে সেট করা হয়েছিল যা স্ট্যাকের উপর ঘোষিত হয়েছিল।
                //            সুতরাং, আমরা জানি যে সবচেয়ে খারাপ ক্ষেত্রেও (`is_less` এর সমস্ত আহ্বান মিথ্যা প্রত্যাবর্তন করে) আমরা কেবলমাত্র সর্বোচ্চ 1 বাইট শেষ হয়ে যাব।
                //        এখানে অন্য একটি অসতর্কতা অপারেশন হ'ল এক্স00 এক্সকে নিখুঁত করছে।
                //        তবে `elem` প্রথমে স্লাইসের শুরু সূচক ছিল যা সর্বদা বৈধ।
                unsafe {
                    // শাখাবিহীন তুলনা।
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // ডান দিক থেকে `block_r` উপাদানগুলি সন্ধান করুন।
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // নিরাপত্তা: নীচে অসম্পূর্ণ অপারেশনগুলি `offset` এর ব্যবহারের সাথে জড়িত।
                //         ফাংশনটির প্রয়োজনীয় শর্ত অনুযায়ী আমরা তাদের সন্তুষ্ট করি কারণ:
                //         1. `offsets_r` স্ট্যাক বরাদ্দ করা হয়, এবং এইভাবে পৃথক বরাদ্দকৃত বস্তু হিসাবে বিবেচিত হয়।
                //         2. `is_less` ফাংশনটি একটি `bool` প্রদান করে।
                //            একটি `bool` কাস্ট করা কখনই `isize` উপচে পড়বে না।
                //         3. আমরা গ্যারান্টি দিয়েছি যে `block_r` `<= BLOCK` হবে।
                //            প্লাস, `end_r` প্রথমে `offsets_` এর সূচনা পয়েন্টারে সেট করা হয়েছিল যা স্ট্যাকের উপর ঘোষিত হয়েছিল।
                //            সুতরাং, আমরা জানি যে সবচেয়ে খারাপ ক্ষেত্রেও (`is_less` এর সমস্ত অনুরোধ সত্য হয়) আমরা কেবলমাত্র সর্বোচ্চ 1 বাইট শেষ হয়ে যাব।
                //        এখানে অন্য একটি অসতর্কতা অপারেশন হ'ল এক্স00 এক্সকে নিখুঁত করছে।
                //        তবে, `elem` প্রারম্ভিক শুরুতে `1 *sizeof(T)` ছিল এবং এটি অ্যাক্সেস করার আগে আমরা এটি `1* sizeof(T)` দ্বারা হ্রাস পেয়েছি।
                //        এছাড়াও, `block_r` কে `BLOCK` এর চেয়ে কম বলে মনে করা হয়েছিল এবং `elem` তাই স্লাইসের শুরুতে সবচেয়ে বেশি নির্দেশ করবে।
                unsafe {
                    // শাখাবিহীন তুলনা।
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // বাম এবং ডান পাশের মধ্যে অদলবদ-অর্ডার উপাদানের সংখ্যা।
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // সেই সময়ে একটি জুটি অদলবদল করার পরিবর্তে, একটি চক্রীয় ক্রান্তিকরণ সম্পাদন করা আরও দক্ষ।
            // এটি কঠোরভাবে অদলবদলের সমতুল্য নয়, তবে কম মেমোরি অপারেশন ব্যবহার করে একটি অনুরূপ ফলাফল তৈরি করে।
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // বাম ব্লকের সমস্ত আউট-অফ-অর্ডার উপাদান সরানো হয়েছিল।পরের ব্লকে যান।
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // ডান ব্লকের সমস্ত আউট-অফ-অর্ডার উপাদান সরানো হয়েছিল।পূর্ববর্তী ব্লকে যান।
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // এখন যা রয়েছে তা হ'ল সর্বাধিক এক ব্লক (বাম বা ডান হয়) এর বাইরে থাকা-অর্ডার উপাদান রয়েছে যা সরানো দরকার।
    // এ জাতীয় অবশিষ্ট উপাদানগুলি কেবল তাদের ব্লকের মধ্যেই শেষ দিকে স্থানান্তরিত হতে পারে।
    //

    if start_l < end_l {
        // বাম ব্লকটি রয়ে গেছে।
        // এর অবশিষ্ট আউট-অফ-অর্ডার উপাদানগুলি ডানদিকে সরান।
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // ডান ব্লক রয়ে গেছে।
        // এর বাকী আউট-অফ-অর্ডার উপাদানগুলি বাম দিকে সরান।
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // আর কিছু করার নেই, আমরা শেষ করেছি।
        width(v.as_mut_ptr(), l)
    }
}

/// `v` এর চেয়ে ছোট উপাদানগুলিতে পার্টিশনগুলি `v`, এর পরে `v[pivot]` এর চেয়ে বড় বা সমান উপাদানগুলি অনুসরণ করে।
///
///
/// এর একটি টিপল ফেরত দেয়:
///
/// 1. `v[pivot]` এর চেয়ে ছোট উপাদানের সংখ্যা।
/// 2. `v` ইতিমধ্যে পার্টিশন করা থাকলে সত্য।
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // স্লাইসের শুরুতে পিভটটি রাখুন।
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // দক্ষতার জন্য পাইভটকে স্ট্যাক-বরাদ্দ ভেরিয়েবলের মধ্যে পড়ুন।
        // যদি নিম্নলিখিত তুলনা অপারেশন panics হয়, পিভটটি স্বয়ংক্রিয়ভাবে স্লাইসে ফিরে লেখা হবে।
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // আদেশের বাইরে থাকা উপাদানগুলির প্রথম জুড়িটি সন্ধান করুন।
        let mut l = 0;
        let mut r = v.len();

        // নিরাপত্তা: নীচে অসম্পূর্ণ একটি অ্যারে সূচীকরণ জড়িত।
        // প্রথমটির জন্য: আমরা ইতিমধ্যে `l < r` এর সাথে এখানে সীমাবদ্ধতা পরীক্ষা করে দেখছি।
        // দ্বিতীয়টির জন্য: আমাদের প্রাথমিকভাবে `l == 0` এবং `r == v.len()` রয়েছে এবং আমরা প্রতিটি ইনডেক্সিং ক্রিয়ায় সেই `l < r` পরীক্ষা করেছি।
        //                     এখান থেকে আমরা জানি যে `r` অবশ্যই কমপক্ষে `r == l` হওয়া উচিত যা প্রথমটি থেকে বৈধ বলে প্রদর্শিত হয়েছিল।
        unsafe {
            // পিভটের চেয়ে বড় বা তার সমান প্রথম উপাদানটি সন্ধান করুন।
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // পিভট যে শেষ উপাদানটি আরও ছোট আবিষ্কার করুন।
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` সুযোগের বাইরে চলে যায় এবং পাইভট (যা একটি স্ট্যাক-বরাদ্দ ভেরিয়েবল) মূলত যেখানে স্লাইসে ছিল সেখানে লিখে দেয়।
        // এই পদক্ষেপটি সুরক্ষা নিশ্চিত করার ক্ষেত্রে গুরুত্বপূর্ণ!
        //
    };

    // দুটি পার্টিশনের মধ্যে পিভট রাখুন।
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` এর সমতুল্য উপাদানগুলিতে `v` পার্টিশনগুলি এবং তারপরে `v[pivot]` এর চেয়েও বেশি উপাদান।
///
/// পিভটের সমান উপাদানের সংখ্যা প্রদান করে।
/// এটি ধরে নেওয়া হয় যে `v` এ পিভটের চেয়ে ছোট উপাদান নেই।
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // স্লাইসের শুরুতে পিভটটি রাখুন।
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // দক্ষতার জন্য পাইভটকে স্ট্যাক-বরাদ্দ ভেরিয়েবলের মধ্যে পড়ুন।
    // যদি নিম্নলিখিত তুলনা অপারেশন panics হয়, পিভটটি স্বয়ংক্রিয়ভাবে স্লাইসে ফিরে লেখা হবে।
    // নিরাপত্তা: এখানে পয়েন্টারটি বৈধ কারণ এটি কোনও স্লাইসের রেফারেন্স থেকে প্রাপ্ত।
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // এবার স্লাইসটি পার্টিশন করুন।
    let mut l = 0;
    let mut r = v.len();
    loop {
        // নিরাপত্তা: নীচে অসম্পূর্ণ একটি অ্যারে সূচীকরণ জড়িত।
        // প্রথমটির জন্য: আমরা ইতিমধ্যে `l < r` এর সাথে এখানে সীমাবদ্ধতা পরীক্ষা করে দেখছি।
        // দ্বিতীয়টির জন্য: আমাদের প্রাথমিকভাবে `l == 0` এবং `r == v.len()` রয়েছে এবং আমরা প্রতিটি ইনডেক্সিং ক্রিয়ায় সেই `l < r` পরীক্ষা করেছি।
        //                     এখান থেকে আমরা জানি যে `r` অবশ্যই কমপক্ষে `r == l` হওয়া উচিত যা প্রথমটি থেকে বৈধ বলে প্রদর্শিত হয়েছিল।
        unsafe {
            // পিভটের চেয়ে বড় উপাদানটি সন্ধান করুন।
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // পিভটের সমান শেষ উপাদানটি সন্ধান করুন।
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // আমরা কি সম্পন্ন করেছি?
            if l >= r {
                break;
            }

            // অর্ড-অফ-অর্ডার উপাদানগুলির জোড়া জোড়া অদলবদল করুন।
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // আমরা পাইভটের সমান `l` উপাদান পেয়েছি।পিভট নিজেই অ্যাকাউন্টে 1 যোগ করুন।
    l + 1

    // `_pivot_guard` সুযোগের বাইরে চলে যায় এবং পাইভট (যা একটি স্ট্যাক-বরাদ্দ ভেরিয়েবল) মূলত যেখানে স্লাইসে ছিল সেখানে লিখে দেয়।
    // এই পদক্ষেপটি সুরক্ষা নিশ্চিত করার ক্ষেত্রে গুরুত্বপূর্ণ!
}

/// নিদর্শনগুলি ভাঙ্গার প্রয়াসে আশেপাশে এমন কিছু উপাদান ছড়িয়ে দেয় যা কোকোর্টে ভারসাম্যহীন পার্টিশনের কারণ হতে পারে।
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // জর্জ মার্সাগ্লিয়া দ্বারা "Xorshift RNGs" কাগজ থেকে সিউডোরান্ডম নম্বর জেনারেটর।
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // এই সংখ্যাটি মডুলো এলোমেলোভাবে নিন।
        // সংখ্যাটি `usize` এর সাথে ফিট করে কারণ `len` `isize::MAX` এর চেয়ে বেশি নয়।
        let modulus = len.next_power_of_two();

        // কিছু সূচিত প্রার্থী এই সূচকের নিকটে থাকবেন।আসুন এলোমেলো করা যাক।
        let pos = len / 4 * 2;

        for i in 0..3 {
            // একটি এলোমেলো সংখ্যা মডুলো এক্স00 এক্স উত্পন্ন করুন।
            // তবে ব্যয়বহুল ক্রিয়াকলাপ এড়ানোর জন্য আমরা প্রথমে এটির দুটি শক্তি নিয়েছি এবং তারপরে `len` দ্বারা এটি কমে যায় যতক্ষণ না এটি `[0, len - 1]` রেঞ্জের সাথে ফিট করে।
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` এর চেয়ে কম হওয়ার গ্যারান্টিযুক্ত।
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` এ একটি পাইভট চয়ন করে এবং যদি স্লাইসটি ইতিমধ্যে সাজানো থাকে তবে সূচক এবং X01 এক্স প্রদান করে।
///
/// `v` এ উপাদানগুলি প্রক্রিয়াটিতে পুনরায় সাজানো হতে পারে।
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // মিডিয়ান-অফ-মিডিয়ান পদ্ধতি বেছে নেওয়ার জন্য সর্বনিম্ন দৈর্ঘ্য।
    // সংক্ষিপ্ত টুকরোগুলি তিনটি সরল মিডিয়েন অফ-থ্রি পদ্ধতি ব্যবহার করে।
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // এই ফাংশনটিতে সঞ্চালিত হতে পারে সর্বাধিক সংখ্যক অদলবদল।
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // তিনটি সূচক যার কাছাকাছি আমরা একটি পিভট বেছে নিতে চলেছি।
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // সূচকগুলি বাছাই করার সময় আমরা যে পরিমাণ অদলবদল করতে চলেছি তা গণনা করে।
    let mut swaps = 0;

    if len >= 8 {
        // সূচকগুলি অদলবদল করে যাতে `v[a] <= v[b]`।
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // সূচকগুলি অদলবদল করে যাতে `v[a] <= v[b] <= v[c]`।
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` এর মাঝারি সন্ধান করে এবং সূচকটি `a` এ সঞ্চয় করে।
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, এবং `c` এর আশেপাশে মিডিয়ানদের সন্ধান করুন।
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b`, এবং `c` এর মধ্যে মাঝারি সন্ধান করুন।
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // সর্বাধিক সংখ্যক অদলবদল সম্পাদিত হয়েছিল।
        // স্লাইসটি নামছে বা বেশিরভাগ অবতরণ করছে এমন সম্ভাবনা রয়েছে, সুতরাং বিপরীতমুখীকরণ সম্ভবত এটি দ্রুত সাজানোর ক্ষেত্রে সহায়তা করবে।
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` পুনরাবৃত্তভাবে সাজান।
///
/// যদি স্লাইসের মূল অ্যারেতে পূর্বসূরী থাকে তবে এটি `pred` হিসাবে নির্দিষ্ট করা হয়েছে।
///
/// `limit` `heapsort` এ যাওয়ার আগে অনুমোদিত ভারসাম্যহীন পার্টিশনের সংখ্যা।
/// যদি শূন্য হয় তবে এই ফাংশনটি তত্ক্ষণাত হিপসোর্টে স্যুইচ করবে।
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // এই দৈর্ঘ্য পর্যন্ত স্লাইস সন্নিবেশ সাজানোর মাধ্যমে বাছাই করা হয়।
    const MAX_INSERTION: usize = 20;

    // শেষ পার্টিশনটি যথাযথভাবে ভারসাম্যপূর্ণ হলেই সত্য।
    let mut was_balanced = true;
    // সত্য যদি শেষ বিভাজনে উপাদানগুলি বদলান না (স্লাইসটি ইতিমধ্যে বিভাজনযুক্ত ছিল)।
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // সন্নিবেশ বাছাই করে খুব ছোট টুকরো সাজানো হয়।
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // যদি খুব বেশি খারাপ পাইভট পছন্দ করা হয়ে থাকে, তবে `O(n * log(n))` সবচেয়ে খারাপ ক্ষেত্রে গ্যারান্টি দেওয়ার জন্য কেবল হিপসোর্টে ফিরে যান।
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // যদি শেষ বিভাজনটি ভারসাম্যহীন হয় তবে আশেপাশে কিছু উপাদানকে ঘুরিয়ে ঘুরিয়ে টুকরো টুকরো করার চেষ্টা করুন।
        // আশা করি আমরা এবার আরও ভাল একটি মূল পিভট বেছে নেব।
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // একটি পাইভট চয়ন করুন এবং স্লাইসটি ইতিমধ্যে সাজানো হয়েছে কিনা তা অনুমান করার চেষ্টা করুন।
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // যদি শেষ বিভাজনটি শালীনভাবে সুষম হয় এবং উপাদানগুলিকে বদলাতে না পারে এবং পিভট নির্বাচন পূর্বাভাস দেয় তবে স্লাইসটি ইতিমধ্যে সাজানো হয়েছে ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // বেশ কয়েকটি অর্ড-অফ-অর্ডার উপাদান সনাক্ত করতে এবং সেগুলিকে সঠিক অবস্থানে সরিয়ে দেওয়ার চেষ্টা করুন।
            // যদি টুকরোটি সম্পূর্ণরূপে বাছাই করা শেষ হয়ে যায় তবে আমরা শেষ করেছি।
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // যদি নির্বাচিত পিভট পূর্বসূরীর সমান হয়, তবে এটি স্লাইসের মধ্যে সবচেয়ে ছোট উপাদান।
        // পিভটের চেয়েও বেশি সমান উপাদানগুলিতে বিভাজন করুন।
        // এই কেসটি সাধারণত হিট হয় যখন স্লাইসে অনেকগুলি নকল উপাদান থাকে।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // পিভটের চেয়েও বড় উপাদানগুলিকে বাছাই করা চালিয়ে যান।
                v = &mut { v }[mid..];
                continue;
            }
        }

        // টুকরা পার্টিশন।
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // স্লাইসটি `left`, `pivot`, এবং `right` এ বিভক্ত করুন।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // মোট পুনরাবৃত্ত কলগুলির সংখ্যা কমাতে এবং কম স্ট্যাক স্পেস ব্যবহার করার জন্য কেবল সংক্ষিপ্ত দিকে পুনরাবৃত্তি করুন।
        // তারপরে কেবল দীর্ঘ পাশ দিয়ে চালিয়ে যান (এটি পুচ্ছ পুনরাবৃত্তির অনুরূপ)।
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// প্যাটার্ন-পরাজয়কারী কোউকোর্টটি ব্যবহার করে এক্স 100 এক্স সাজান, যা *ও*(*এন*\* এক্স01 এক্স সবচেয়ে খারাপ ক্ষেত্রে)।
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // শূন্য আকারের ধরণের ক্ষেত্রে বাছাইয়ের কোনও অর্থবহ আচরণ নেই।
    if mem::size_of::<T>() == 0 {
        return;
    }

    // ভারসাম্যহীন পার্টিশনের সংখ্যাটি `floor(log2(len)) + 1` এ সীমাবদ্ধ করুন।
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // এই দৈর্ঘ্য পর্যন্ত টুকরো টুকরো জন্য এগুলি সম্ভবত সহজে সাজানোর জন্য দ্রুত।
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // একটি পিভট চয়ন করুন
        let (pivot, _) = choose_pivot(v, is_less);

        // যদি নির্বাচিত পিভট পূর্বসূরীর সমান হয়, তবে এটি স্লাইসের মধ্যে সবচেয়ে ছোট উপাদান।
        // পিভটের চেয়েও বেশি সমান উপাদানগুলিতে বিভাজন করুন।
        // এই কেসটি সাধারণত হিট হয় যখন স্লাইসে অনেকগুলি নকল উপাদান থাকে।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // যদি আমরা আমাদের সূচকটি পাস করেছি তবে আমরা ভাল।
                if mid > index {
                    return;
                }

                // অন্যথায়, পিভটের চেয়েও বড় উপাদানগুলিকে বাছাই করা চালিয়ে যান।
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // স্লাইসটি `left`, `pivot`, এবং `right` এ বিভক্ত করুন।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // যদি মাঝ==সূচক হয়, তবে আমাদের সম্পন্ন হয়েছে, যেহেতু partition() গ্যারান্টি দিয়েছে যে মধ্যবর্তী পরে সমস্ত উপাদানগুলি মাঝের চেয়ে বড় বা সমান।
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // শূন্য আকারের ধরণের ক্ষেত্রে বাছাইয়ের কোনও অর্থবহ আচরণ নেই।কিছু করনা.
    } else if index == v.len() - 1 {
        // সর্বাধিক উপাদান সন্ধান করুন এবং অ্যারের শেষ অবস্থানে রাখুন।
        // আমরা এখানে `unwrap()` ব্যবহারে নির্দ্বিধায় রয়েছি কারণ আমরা জানি v অবশ্যই খালি থাকবে না।
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // মিনিট উপাদান সন্ধান করুন এবং অ্যারের প্রথম অবস্থানে রাখুন।
        // আমরা এখানে `unwrap()` ব্যবহারে নির্দ্বিধায় রয়েছি কারণ আমরা জানি v অবশ্যই খালি থাকবে না।
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}