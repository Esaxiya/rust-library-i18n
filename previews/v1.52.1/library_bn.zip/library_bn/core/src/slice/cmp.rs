//! `[T]` এর জন্য তুলনা traits।

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// কলগুলি বাস্তবায়ন মেমক্যাম্প সরবরাহ করে।
    ///
    /// ডেটাটিকে u8 হিসাবে ব্যাখ্যা করে।
    ///
    /// সমান হিসাবে 0, এর চেয়ে কম <0 এবং এর চেয়ে বড় 0 প্রদান করে।
    ///
    // FIXME(#32610): রিটার্ন টাইপ সি_আইঙ্ক্ট হওয়া উচিত
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) এর তুলনা কার্যকর করে।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) এর তুলনা কার্যকর করে।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// স্লাইস এর আংশিকEq বিশেষায়নের জন্য অন্তর্বর্তী trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// জেনেরিক ফালি সমতা
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// প্রকারগুলি যখন অনুমতি দেয় তখন বাইটওয়াই সমতার জন্য মেমক্যাম্প ব্যবহার করুন
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // নিরাপদ: `self` এবং `other` উল্লেখ এবং এইভাবে বৈধ হওয়ার গ্যারান্টিযুক্ত।
        // দুটি স্লাইস উপরে একই আকারের জন্য চেক করা হয়েছে।
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// স্লাইসের পার্টিশালর্ডের বিশেষায়নের জন্য ইন্টারমিডিয়েট জেড0ট্রাইট0 জেড
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // সংকলকটিতে সীমাবদ্ধ চেক নির্মূলকরণ সক্ষম করতে লুপ পুনরাবৃত্তির পরিসরে স্লাইস করুন
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// এটি ইম্পল যা আমরা রাখতে চাই।দুর্ভাগ্যক্রমে এটি শব্দ না।
// এক্স 100 এক্স দেখুন।
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// স্লাইস অর্ডের বিশেষীকরণের জন্য ইন্টারমিডিয়েট trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // সংকলকটিতে সীমাবদ্ধ চেক নির্মূলকরণ সক্ষম করতে লুপ পুনরাবৃত্তির পরিসরে স্লাইস করুন
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp লেসিকোগ্রাফিকভাবে স্বাক্ষরযুক্ত বাইটের ক্রম তুলনা করে।
// এটি [u8] এর জন্য আমরা যে আদেশটি চেয়েছি তার সাথে মেলে তবে অন্য কেউ নেই (এমনকি X01 এক্সও নয়)।
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // নিরাপদ: `left` এবং `right` উল্লেখ এবং এইভাবে বৈধ হওয়ার গ্যারান্টিযুক্ত।
            // আমরা উভয় দৈর্ঘ্যের সর্বনিম্ন ব্যবহার করি যা গ্যারান্টি দেয় যে উভয় অঞ্চল সেই ব্যবধানে পড়ার জন্য বৈধ।
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` এর একটি পদ্ধতি থাকলেও `Eq` এ বিশেষজ্ঞের অনুমতি দেওয়ার জন্য হ্যাক।
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait এমন উপায়ে প্রয়োগ করা হয়েছে যা তাদের বাই-বাই উপস্থাপনা ব্যবহার করে সাম্যের জন্য তুলনা করা যেতে পারে
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // নিরাপদ: `i8` এবং `u8` এর একই মেমরি লেআউট রয়েছে, এভাবে `x.as_ptr()` ingালাই
        // `*const u8` নিরাপদ হিসাবে।
        // `x.as_ptr()` একটি রেফারেন্স থেকে আসে এবং এটি স্লাইস `x.len()` দৈর্ঘ্যের জন্য পঠনের জন্য বৈধ হওয়ার গ্যারান্টিযুক্ত, যা `isize::MAX` এর চেয়ে বড় হতে পারে না।
        // প্রত্যাবর্তিত টুকরা কখনও রূপান্তরিত হয় না।
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}