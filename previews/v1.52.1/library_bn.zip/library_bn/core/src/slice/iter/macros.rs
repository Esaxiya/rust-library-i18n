//! স্লাইসের পুনরাবৃত্তকারী দ্বারা ব্যবহৃত ম্যাক্রো।

// ইনলাইনিং is_empty এবং লেন একটি বিশাল পারফরম্যান্স পার্থক্য করে
macro_rules! is_empty {
    // যেভাবে আমরা জেডএসটি পুনরুক্তকারীর দৈর্ঘ্যকে এনকোড করেছি, এটি জেডএসটি এবং নন-জেডএসটি উভয়ের জন্যই কাজ করে।
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// কিছু সীমা পরীক্ষা থেকে মুক্তি পেতে (`position` দেখুন), আমরা কিছুটা অপ্রত্যাশিত উপায়ে দৈর্ঘ্যটি গণনা করি।
// (`কোডজেন/স্লাইস-পজিশন-বাউন্ডস-চেক দ্বারা পরীক্ষিত))
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // আমরা মাঝে মাঝে একটি অনিরাপদ ব্লকের মধ্যে ব্যবহার করি

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // এই _cannot_ `unchecked_sub` ব্যবহার করে কারণ আমরা দীর্ঘ জেডএসটি স্লাইস পুনরাবৃত্তির দৈর্ঘ্যের প্রতিনিধিত্ব করতে মোড়কের উপরে নির্ভর করি।
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // আমরা জানি যে `start <= end`, তাই `offset_from` এর চেয়ে আরও ভাল করতে পারে, যা সাইন ইন থাকা দরকার।
            // এখানে উপযুক্ত পতাকা সেট করে আমরা LLVM কে এটি বলতে পারি, এটি এটি সীমানা চেকগুলি সরাতে সহায়তা করে।
            // নিরাপদ: আক্রমণকারী প্রকার অনুসারে, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // এলএলভিএমকেও জানিয়ে দিয়ে যে পয়েন্টারগুলি টাইপ আকারের সঠিক একাধিক দ্বারা পৃথক হয়, এটি `(end - start) < size` এর পরিবর্তে `len() == 0` কে `start == end` এ অনুকূলিত করতে পারে।
            //
            // নিরাপদ: আক্রমণকারী প্রকারের দ্বারা, পয়েন্টারগুলি সারিবদ্ধ হয় তাই
            //         তাদের মধ্যে দূরত্ব অবশ্যই পয়েন্টি আকারের একাধিক হতে হবে
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` এবং `IterMut` পুনরাবৃত্তির ভাগ করা সংজ্ঞা
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // প্রথম উপাদানটি ফেরত দেয় এবং পুনরাবৃত্তির শুরুটি 1 দ্বারা এগিয়ে যায়।
        // একটি অন্তর্ভুক্ত ফাংশনটির তুলনায় কর্মক্ষমতাটি দুর্দান্তভাবে উন্নত করে।
        // পুনরুক্তিকারী অবশ্যই খালি হবে না।
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // শেষ উপাদানটি প্রদান করে এবং পুনরুক্তির প্রান্তটি 1 দ্বারা পিছনে সরায়।
        // একটি অন্তর্ভুক্ত ফাংশনটির তুলনায় কর্মক্ষমতাটি দুর্দান্তভাবে উন্নত করে।
        // পুনরুক্তিকারী অবশ্যই খালি হবে না।
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // টি, এস, এস, টি, টি, এস, এস, এস, সি, এস, এস, এল, সি, এস, এল, সি, এস, এল, এল, পি, এস, এস, এস, এল, সি, এস, এল, সি, এস, এল, সি, এস, এল, সি, এস, এল, সি, এস, সি, এস, এল, সি, এস, সি, এস, সি, এস, এল থেকে হবে।
        // `n` অবশ্যই `self.len()` ছাড়িয়ে যাবে না।
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // পুনরুক্তিকারী থেকে স্লাইস তৈরির জন্য সহায়ক ফাংশন।
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // নিরাপদ: পুনরুক্তিটি পয়েন্টার সহ একটি স্লাইস থেকে তৈরি করা হয়েছিল
                // `self.ptr` এবং দৈর্ঘ্য `len!(self)`।
                // এটি গ্যারান্টি দেয় যে `from_raw_parts` এর জন্য সমস্ত পূর্বশর্তগুলি সম্পন্ন হয়েছে।
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // পুরানো শুরুটি ফিরিয়ে `offset` উপাদানগুলির দ্বারা পুনরাবৃত্তির শুরুটিকে এগিয়ে নেওয়ার জন্য সহায়ক ফাংশন।
            //
            // অনিরাপদ কারণ অফসেটটি অবশ্যই `self.len()` এর বেশি হবে না।
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // নিরাপত্তা: কলার গ্যারান্টি দেয় যে `offset` `self.len()` এর বেশি হবে না,
                    // সুতরাং এই নতুন পয়েন্টারটি `self` এর অভ্যন্তরে এবং এভাবে নন-নাল হওয়ার গ্যারান্টিযুক্ত।
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // এক্সটারএক্স উপাদানগুলির দ্বারা পুনরাবৃত্তির প্রান্তটি পিছনের দিকে সরিয়ে নতুন প্রান্তটি ফিরিয়ে আনার জন্য সহায়ক ফাংশন।
            //
            // অনিরাপদ কারণ অফসেটটি অবশ্যই `self.len()` এর বেশি হবে না।
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // নিরাপত্তা: কলার গ্যারান্টি দেয় যে `offset` `self.len()` এর বেশি হবে না,
                    // যা কোনও `isize` ওভারফ্লো না করার গ্যারান্টিযুক্ত।
                    // এছাড়াও, ফলস্বরূপ পয়েন্টারটি `slice` এর সীমানায় রয়েছে, যা `offset` এর অন্যান্য প্রয়োজনীয়তা পূরণ করে।
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // টুকরা দিয়ে প্রয়োগ করা যেতে পারে, কিন্তু এটি সীমাবদ্ধ চেকগুলি এড়িয়ে চলে

                // সুরক্ষা: স্লাইস শুরুর পয়েন্টার থেকে `assume` কলগুলি নিরাপদ
                // অবশ্যই নন-নাল, এবং নন-জেডএসটি-র উপরের টুকরাগুলির অবশ্যই একটি নন-নাল প্রান্ত পয়েন্টার থাকতে হবে।
                // `next_unchecked!` এ কল করা নিরাপদ যেহেতু আমরা পরীক্ষা করে দেখছি যে পুনরায় পুনরুক্তিকারীটি খালি রয়েছে।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // এই পুনরুক্তি এখন খালি।
                    if mem::size_of::<T>() == 0 {
                        // `ptr` কখনই 0 হতে পারে না সেহেতু আমাদের এইভাবে এটি করতে হবে তবে `end` হতে পারে (মোড়ানোর কারণে)।
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // সুরক্ষা: টিটি জেডএসটি না হলে শেষ 0 হতে পারে না কারণ পিটিআর 0 এবং শেষ>=পিটিআর নয়
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // নিরাপদ: আমরা সীমাবদ্ধ।`post_inc_start` এমনকি ZSTs এর জন্যও সঠিক কাজ করে।
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            // এছাড়াও, `assume` একটি বাউন্ডস চেক এড়িয়ে চলে।
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // নিরাপত্তা: আমরা লুপ ইনগ্রায়েন্টের সীমানায় থাকার গ্যারান্টিযুক্ত:
                        // যখন `i >= n`, `self.next()` এক্স02 এক্স প্রদান করে এবং লুপ ব্রেক হয়।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // আমরা ডিফল্ট বাস্তবায়নটি ওভাররাইড করি যা `try_fold` ব্যবহার করে, কারণ এই সাধারণ বাস্তবায়নটি কম এলএলভিএম আইআর তৈরি করে এবং সংকলনের জন্য দ্রুত।
            // এছাড়াও, `assume` একটি বাউন্ডস চেক এড়িয়ে চলে।
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // সুরক্ষা: `n` থেকে শুরু হওয়া থেকে `i` অবশ্যই `n` এর চেয়ে কম হতে হবে
                        // এবং কেবল হ্রাস পাচ্ছে।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `i` সীমানায় রয়েছে
                // অন্তর্নিহিত স্লাইস, সুতরাং `i` কোনও `isize` উপচে পড়তে পারে না, এবং ফিরে আসা রেফারেন্সগুলি স্লাইসের একটি উপাদান উল্লেখ করার গ্যারান্টিযুক্ত এবং এভাবে বৈধ হওয়ার গ্যারান্টিযুক্ত।
                //
                // এছাড়াও নোট করুন যে কলারটিও গ্যারান্টি দেয় যে আমাদের আর একই সূচির সাথে আর কখনও ডাকা হয়নি, এবং এই সাব্লাইসটি অ্যাক্সেস করবে এমন অন্য কোনও পদ্ধতি কল করা হয়নি, সুতরাং প্রত্যাবর্তনযোগ্য রেফারেন্সটি ক্ষেত্রে পরিবর্তনযোগ্য হওয়ার পক্ষে এটি বৈধ?
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // টুকরা দিয়ে প্রয়োগ করা যেতে পারে, কিন্তু এটি সীমাবদ্ধ চেকগুলি এড়িয়ে চলে

                // সুরক্ষা: স্লাইস শুরুর পয়েন্টারটি অবশ্যই নাল হতে হবে, তাই `assume` কলগুলি নিরাপদ,
                // এবং নন-জেডএসটি-র উপরের টুকরাগুলির অবশ্যই একটি নন-নাল প্রান্ত পয়েন্টার থাকতে হবে।
                // `next_back_unchecked!` এ কল করা নিরাপদ যেহেতু আমরা পরীক্ষা করে দেখছি যে পুনরায় পুনরুক্তিকারীটি খালি রয়েছে।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // এই পুনরুক্তি এখন খালি।
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // নিরাপদ: আমরা সীমাবদ্ধ।`pre_dec_end` এমনকি ZSTs এর জন্যও সঠিক কাজ করে।
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}