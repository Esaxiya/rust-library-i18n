// ignore-tidy-filelength

//! স্লাইস ম্যানেজমেন্ট এবং হেরফের
//!
//! আরও তথ্যের জন্য [`std::slice`] দেখুন।
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// খাঁটি rust মেমচার বাস্তবায়ন, rust-memchr থেকে নেওয়া
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// এই ফাংশনটি কেবলমাত্র ইউনিট পরীক্ষার হিপসোর্টের অন্য কোনও উপায় না থাকায় সর্বজনীন।
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// স্লাইসে উপাদানগুলির সংখ্যা প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // সাফাই: কনস্ট সাউন্ড কারণ আমরা দৈর্ঘ্য ক্ষেত্রটি ব্যবহার হিসাবে ব্যবহার করি (যা এটি হওয়া উচিত)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // নিরাপদ: এটি নিরাপদ কারণ `&[T]` এবং `FatPtr<T>` এর একই বিন্যাস রয়েছে।
            // কেবলমাত্র `std` এই গ্যারান্টিটি তৈরি করতে পারে।
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: যখন কনস্ট্যান্ট স্থিতিশীল থাকে তখন `crate::ptr::metadata(self)` এর সাথে প্রতিস্থাপন করুন।
            // এই লেখার হিসাবে এটি একটি "Const-stable functions can only call other const-stable functions" ত্রুটি ঘটায়।
            //

            // সুরক্ষা: * কনস্ট টি থেকে এক্স 100 এক্স ইউনিয়ন থেকে মান অ্যাক্সেস করা নিরাপদ
            // এবং পিটিআরসি কম্পোনেন্টস<T>একই মেমরি লেআউট আছে।
            // কেবলমাত্র std এই গ্যারান্টিটি তৈরি করতে পারে।
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// যদি স্লাইসের দৈর্ঘ্য 0 থাকে তবে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// স্লাইসের প্রথম উপাদানটি, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// স্লাইসের প্রথম উপাদানটিতে পরিবর্তনীয় পয়েন্টার বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// স্লাইসের প্রথম এবং বাকী সমস্ত উপাদান, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// স্লাইসের প্রথম এবং বাকী সমস্ত উপাদান, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// স্লাইসের সর্বশেষ এবং বাকী সমস্ত উপাদান, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// স্লাইসের সর্বশেষ এবং বাকী সমস্ত উপাদান, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// স্লাইসের শেষ উপাদানটি, বা খালি থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// স্লাইসের শেষ আইটেমটিতে একটি পরিবর্তনীয় পয়েন্টার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// সূচকের ধরণের উপর নির্ভর করে কোনও উপাদান বা সাব্লাইসিসের রেফারেন্স প্রদান করে।
    ///
    /// - যদি কোনও অবস্থান দেওয়া হয়, সীমা ছাড়াই সেই অবস্থানে থাকা উপাদানটির জন্য রেফারেন্স বা সীমা ছাড়াই `None` প্রদান করে।
    ///
    /// - যদি কোনও পরিসীমা দেওয়া থাকে, তবে এই ব্যাপ্তির সাথে সম্পর্কিত সাব্লাইস, বা সীমা ছাড়িয়ে থাকলে `None` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// সূচকের সীমা ছাড়িয়ে থাকলে সূচকের ধরণের উপর নির্ভর করে কোনও উপাদান বা সাব্লাইসকে পরিবর্তিত রেফারেন্স ([`get`] দেখুন) বা `None` প্রদান করে।
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// সীমা পরীক্ষা না করে কোনও উপাদান বা সাব্লাইসিসের রেফারেন্স প্রদান করে।
    ///
    /// নিরাপদ বিকল্পের জন্য দেখুন [`get`]।
    ///
    /// # Safety
    ///
    /// ফলাফলের রেফারেন্সটি ব্যবহার না করা সত্ত্বেও, এই পদ্ধতিটিকে একটি সীমানার বাইরে সূচক দিয়ে কল করা *[অপরিবর্তিত আচরণ]* is
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // নিরাপত্তা: কলারকে `get_unchecked` এর জন্য বেশিরভাগ সুরক্ষা প্রয়োজনীয়তা ধরে রাখতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &*index.get_unchecked(self) }
    }

    /// সীমা চেক না করেই কোনও উপাদান বা সাব্লাইসিসের পরিবর্তিত রেফারেন্স প্রদান করে।
    ///
    /// নিরাপদ বিকল্পের জন্য দেখুন [`get_mut`]।
    ///
    /// # Safety
    ///
    /// ফলাফলের রেফারেন্সটি ব্যবহার না করা সত্ত্বেও, এই পদ্ধতিটিকে একটি সীমানার বাইরে সূচক দিয়ে কল করা *[অপরিবর্তিত আচরণ]* is
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // সুরক্ষা: কলকারীকে অবশ্যই `get_unchecked_mut` এর সুরক্ষা প্রয়োজনীয়তাগুলি ধরে রাখতে হবে;
        // স্লাইসটি ডেরেফেরেন্সযোগ্য কারণ `self` একটি নিরাপদ রেফারেন্স।
        // প্রত্যাবর্তিত পয়েন্টারটি নিরাপদ কারণ `SliceIndex` এর ইমপ্লগুলি অবশ্যই এটির গ্যারান্টি দিতে হবে।
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// স্লাইসের বাফারে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে স্লাইসটি পয়েন্টারটি এই ফাংশনটি ফেরত পাঠিয়েছে, অন্যথায় এটি আবর্জনার দিকে নির্দেশ করবে।
    ///
    /// ফোনকারীকে অবশ্যই নিশ্চিত করতে হবে যে পয়েন্টার (non-transitively) নির্দেশিত মেমরিটি এই পয়েন্টার বা এর থেকে প্রাপ্ত কোনও পয়েন্টার ব্যবহার করে কখনই (কোনও `UnsafeCell` এর অভ্যন্তরের বাইরে) লিখিত হয় না।
    /// আপনার যদি স্লাইসের বিষয়বস্তুগুলিকে পরিবর্তিত করতে হয় তবে [`as_mut_ptr`] ব্যবহার করুন।
    ///
    /// এই স্লাইস দ্বারা রেফারেন্সযুক্ত ধারকটি পরিবর্তন করে এর বাফারটিকে পুনরায় স্থানান্তরিত করতে পারে, যার ফলে এটিতে কোনও পয়েন্টারও অবৈধ হয়ে যায়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// স্লাইসের বাফারে একটি অনিরাপদ পরিবর্তনযোগ্য পয়েন্টারটি ফেরত দেয়।
    ///
    /// কলকারীকে অবশ্যই নিশ্চিত করতে হবে যে স্লাইসটি পয়েন্টারটি এই ফাংশনটি ফেরত পাঠিয়েছে, অন্যথায় এটি আবর্জনার দিকে নির্দেশ করবে।
    ///
    /// এই স্লাইস দ্বারা রেফারেন্সযুক্ত ধারকটি পরিবর্তন করে এর বাফারটিকে পুনরায় স্থানান্তরিত করতে পারে, যার ফলে এটিতে কোনও পয়েন্টারও অবৈধ হয়ে যায়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// স্লাইস বিস্তৃত দুটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// ফিরে আসা পরিসীমাটি অর্ধ-খোলা, যার অর্থ শেষ পয়েন্টারটি *এক অতীত* স্লাইসের শেষ উপাদানটি নির্দেশ করে।
    /// এইভাবে, একটি খালি স্লাইস দুটি সমান পয়েন্টার দ্বারা প্রতিনিধিত্ব করা হয়, এবং দুটি পয়েন্টারের মধ্যে পার্থক্য স্লাইজের আকারকে উপস্থাপন করে।
    ///
    /// এই পয়েন্টারগুলি ব্যবহারের বিষয়ে সতর্কতার জন্য [`as_ptr`] দেখুন।শেষের পয়েন্টারটিতে অতিরিক্ত সতর্কতা প্রয়োজন, কারণ এটি স্লাইসে কোনও বৈধ উপাদানকে নির্দেশ করে না।
    ///
    /// এই ফাংশনটি বিদেশী ইন্টারফেসের সাথে কথোপকথনের জন্য দরকারী যা মেমরির বিভিন্ন উপাদানগুলির রেফারেন্স করতে দুটি পয়েন্টার ব্যবহার করে, যেমন সি ++ তে সাধারণ।
    ///
    ///
    /// কোনও উপাদানের পয়েন্টার এই স্লাইসের কোনও উপাদানকে বোঝায় কিনা তা পরীক্ষা করেও কার্যকর হতে পারে:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // সুরক্ষা: এখানে `add` নিরাপদ, কারণ:
        //
        //   - উভয় পয়েন্টার একই বস্তুর অংশ, যেমন সরাসরি বস্তুর অতীত নির্দেশ করাও গণনা করে।
        //
        //   - এখানে উল্লিখিত হিসাবে স্লাইসের আকারটি isize::MAX বাইটের চেয়ে বড় কখনই হয় না:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - জড়িতদের চারপাশে কোনও মোড়ানো নেই, কারণ স্লাইসগুলি ঠিকানার জায়গার শেষের সাথে আবৃত হয় না।
        //
        // pointer::add এর ডকুমেন্টেশন দেখুন।
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// স্লাইস বিস্তৃত দুটি অনিরাপদ পরিবর্তনযোগ্য পয়েন্টার ফেরত দেয়।
    ///
    /// ফিরে আসা পরিসীমাটি অর্ধ-খোলা, যার অর্থ শেষ পয়েন্টারটি *এক অতীত* স্লাইসের শেষ উপাদানটি নির্দেশ করে।
    /// এইভাবে, একটি খালি স্লাইস দুটি সমান পয়েন্টার দ্বারা প্রতিনিধিত্ব করা হয়, এবং দুটি পয়েন্টারের মধ্যে পার্থক্য স্লাইজের আকারকে উপস্থাপন করে।
    ///
    /// এই পয়েন্টারগুলি ব্যবহারের বিষয়ে সতর্কতার জন্য [`as_mut_ptr`] দেখুন।
    /// শেষের পয়েন্টারটিতে অতিরিক্ত সতর্কতা প্রয়োজন, কারণ এটি স্লাইসে কোনও বৈধ উপাদানকে নির্দেশ করে না।
    ///
    /// এই ফাংশনটি বিদেশী ইন্টারফেসের সাথে কথোপকথনের জন্য দরকারী যা মেমরির বিভিন্ন উপাদানগুলির রেফারেন্স করতে দুটি পয়েন্টার ব্যবহার করে, যেমন সি ++ তে সাধারণ।
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // নিরাপদ: এখানে `add` কেন নিরাপদ তা জন্য উপরে as_ptr_range() দেখুন।
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// স্লাইসে দুটি উপাদান অদলবদল করে।
    ///
    /// # Arguments
    ///
    /// * একটি, প্রথম উপাদান সূচক
    /// * খ, দ্বিতীয় উপাদান সূচক
    ///
    /// # Panics
    ///
    /// `a` বা `b` সীমার বাইরে থাকলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // একটি vector থেকে দুটি পরিবর্তনীয় ableণ নিতে পারবেন না, সুতরাং পরিবর্তে কাঁচা পয়েন্টার ব্যবহার করুন।
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // নিরাপদ: `pa` এবং `pb` নিরাপদ পরিবর্তনযোগ্য রেফারেন্স এবং রেফারেন্স থেকে তৈরি করা হয়েছে
        // স্লাইসে থাকা উপাদানগুলিতে এবং তাই বৈধ এবং প্রান্তিককরণের গ্যারান্টিযুক্ত।
        // নোট করুন যে `a` এবং `b` এর পিছনে থাকা উপাদানগুলির অ্যাক্সেস পরীক্ষা করা হয়েছে এবং সীমা ছাড়িয়ে গেলে panic হবে।
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// স্লাইসে উপাদানের ক্রমটি জায়গায় in
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // খুব ছোট ধরণের জন্য, সাধারণ পথে পড়া সমস্ত ব্যক্তি খুব খারাপভাবে সম্পাদন করে।
        // একটি বৃহত্তর অংশ লোড করে এবং একটি রেজিস্টারকে উল্টিয়ে আমরা দক্ষ অ-স্বাক্ষরিত load/store দেওয়া আরও ভাল করতে পারি।
        //

        // আদর্শভাবে এলএলভিএম আমাদের জন্য এটি করবে, কারণ স্বাক্ষরবিহীন পাঠাগুলি দক্ষ কিনা (উদাহরণস্বরূপ, বিভিন্ন এআরএম সংস্করণগুলির মধ্যে এটি পরিবর্তিত হয়) এবং সেরা খণ্ডের আকারটি কী হবে তা আমরা যা করি তার চেয়ে আমাদের এটি ভাল।
        // দুর্ভাগ্যক্রমে, LLVM 4.0 (2017-05) হিসাবে এটি কেবল লুপটিকে আনআরোলস করে, তাই আমাদের এটি নিজেরাই করা দরকার।
        // (হাইপোথিসিস: বিপরীতটি সমস্যাজনক কারণ পক্ষগুলি পৃথকভাবে সারিবদ্ধ করা যেতে পারে-যখন দৈর্ঘ্যটি বিজোড় হয়-তাই মধ্যবর্তী স্থানে সম্পূর্ণ সারিবদ্ধ সিমড ব্যবহার করার জন্য প্রাক-এবং পোস্টলিডস নির্গমন করার কোনও উপায় নেই))
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // কোনও ইউজিতে u8 গুলি বিপরীত করতে llvm.bswap আন্তঃ ব্যবহার করুন
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // নিরাপত্তা: এখানে চেক করার জন্য বেশ কয়েকটি জিনিস রয়েছে:
                //
                // - উল্লেখ্য যে উপরের সিএফজি চেকের কারণে `chunk` হয় 4 বা 8 হয়।সুতরাং `chunk - 1` ইতিবাচক।
                // - লুপ চেক গ্যারান্টি হিসাবে সূচক `i` এর সাথে সূচীকরণ ঠিক আছে
                //   `i + chunk - 1 < ln / 2`
                //   <=> এক্স 100 এক্স
                // - সূচক `ln - i - chunk = ln - (i + chunk)` এর সাথে সূচী ঠিক আছে:
                //   - `i + chunk > 0` তুচ্ছ সত্য।
                //   - লুপ চেক গ্যারান্টি দেয়:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, এভাবে বিয়োগফল প্রবাহিত হয় না।
                // - `read_unaligned` এবং `write_unaligned` কলগুলি ভাল:
                //   - `pa` সূচকগুলি `i` এর দিকে নির্দেশ করে যেখানে `i < ln / 2 - (chunk - 1)` (উপরে দেখুন) এবং `pb` সূচক `ln - i - chunk` এ নির্দেশ করে, তাই উভয়ই কমপক্ষে `self` এর অনেকগুলি বাইট `self` এর শেষ থেকে দূরে রয়েছে are
                //
                //   - যে কোনও আরম্ভ করা মেমরিটি বৈধ `usize`।
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // একটি u32 এ u16 গুলি বিপরীত করতে 16-টি ঘোরান Use
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // নিরাপদ: একটি আনইলাইনযুক্ত u32 যদি `i + 1 < ln` হয় `i` থেকে পড়তে পারেন
                // (এবং স্পষ্টতই `i < ln`), কারণ প্রতিটি উপাদান 2 বাইট এবং আমরা 4 পড়ছি।
                //
                // `i + chunk - 1 < ln / 2` # অবস্থা যখন
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // যেহেতু এটি 2 দ্বারা ভাগ করা দৈর্ঘ্যের চেয়ে কম, সুতরাং এটি অবশ্যই সীমানায় থাকতে হবে।
                //
                // এর অর্থ হ'ল `0 < i + chunk <= ln` শর্তটি সর্বদা শ্রদ্ধাশীল, `pb` পয়েন্টারটি নিরাপদে ব্যবহার করা যেতে পারে তা নিশ্চিত করে।
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // নিরাপত্তা: এক্স 100 এক্স স্লাইসের অর্ধ দৈর্ঘ্যের চেয়ে নিকৃষ্টতম
            // `i` এবং `ln - i - 1` অ্যাক্সেস করা নিরাপদ (`i` 0 থেকে শুরু হয় এবং `ln / 2 - 1` এর বেশি হবে না)।
            // ফলস্বরূপ পয়েন্টারগুলি `pa` এবং `pb` তাই বৈধ এবং প্রান্তিককরণ করা হয় এবং এগুলি থেকে পড়ে এবং লিখিত হতে পারে।
            //
            //
            unsafe {
                // সীমানা নিরাপদ অদলবদল এড়াতে নিরাপদ অদলবদল।
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// স্লাইসের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// এমন একটি পুনরাবৃত্তি প্রদান করে যা প্রতিটি মানকে সংশোধন করতে দেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` দৈর্ঘ্যের সমস্ত সংক্ষিপ্ত windows এর উপরে একটি পুনরাবৃত্তি প্রদান করে।
    /// windows ওভারল্যাপ
    /// যদি স্লাইসটি `size` এর চেয়ে কম হয় তবে পুনরাবৃত্তকারী কোনও মান দেয় না।
    ///
    /// # Panics
    ///
    /// `size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// যদি স্লাইসটি `size` এর চেয়ে কম হয়:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `chunk_size` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি টুকরো টুকরো হয় এবং ওভারল্যাপ হয় না।যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ খণ্ডটির দৈর্ঘ্য `chunk_size` হবে না।
    ///
    /// এই পুনরাবৃত্তির বৈকল্পিকের জন্য [`chunks_exact`] দেখুন যা সর্বদা সঠিকভাবে `chunk_size` উপাদানগুলির অংশ এবং একই পুনরুক্তির জন্য [`rchunks`] প্রদান করে তবে স্লাইসের শেষে শুরু হয়।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `chunk_size` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি পরিবর্তনীয় টুকরা হয় এবং ওভারল্যাপ হয় না।যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ খণ্ডটির দৈর্ঘ্য `chunk_size` হবে না।
    ///
    /// এই পুনরাবৃত্তির বৈকল্পিকের জন্য [`chunks_exact_mut`] দেখুন যা সর্বদা সঠিকভাবে `chunk_size` উপাদানগুলির অংশ এবং একই পুনরুক্তির জন্য [`rchunks_mut`] প্রদান করে তবে স্লাইসের শেষে শুরু হয়।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `chunk_size` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি টুকরো টুকরো হয় এবং ওভারল্যাপ হয় না।
    /// যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    ///
    /// প্রতিটি খণ্ডে ঠিক `chunk_size` উপাদান থাকার কারণে, সংকলক প্রায়শই [`chunks`] এর চেয়ে ফলাফলের কোডটি আরও ভাল করতে পারে।
    ///
    /// এই পুনরাবৃত্তির বৈকল্পিকের জন্য [`chunks`] দেখুন যা বাকীটিকে আরও ছোট ছোট অংশ হিসাবে এবং একই পুনরুক্তারের জন্য এক্স01 এক্স প্রদান করে তবে স্লাইসের শেষে শুরু হয়।
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `chunk_size` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি পরিবর্তনীয় টুকরা হয় এবং ওভারল্যাপ হয় না।
    /// যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `into_remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    ///
    /// প্রতিটি খণ্ডে ঠিক `chunk_size` উপাদান থাকার কারণে, সংকলক প্রায়শই [`chunks_mut`] এর চেয়ে ফলাফলের কোডটি আরও ভাল করতে পারে।
    ///
    /// এই পুনরাবৃত্তির বৈকল্পিকের জন্য [`chunks_mut`] দেখুন যা বাকীটিকে আরও ছোট ছোট অংশ হিসাবে এবং একই পুনরুক্তারের জন্য এক্স01 এক্স প্রদান করে তবে স্লাইসের শেষে শুরু হয়।
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// No N`-উপাদান অ্যারেগুলির এক টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো করে ধরে নিলাম যে আর কোনও অবশিষ্ট নেই।
    ///
    ///
    /// # Safety
    ///
    /// এটি তখনই বলা যেতে পারে
    /// - টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো।
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // নিরাপত্তা: 1-উপাদান খণ্ডগুলির আর কখনও অবশিষ্ট নেই
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // নিরাপত্তা: স্লাইস দৈর্ঘ্যের এক্স 100 এক্স 3 এর একাধিক
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // এগুলি নিরবচ্ছিন্ন হবে:
    /// // কিছু দিন: &[[_ _;5]]=এক্স 100 এক্স//স্লাইসের দৈর্ঘ্য 5 টি অংশের একক নয়:&[[_ _;0]]= slice.as_chunks_unchecked()//শূন্য দৈর্ঘ্যের খণ্ডগুলি কখনই অনুমোদিত নয়
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // নিরাপত্তা: আমাদের পূর্বশর্তটি ঠিক এটির জন্য প্রয়োজন
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // নিরাপত্তা: আমরা এতে `new_len * N` উপাদানগুলির একটি টুকরা castালাই
        // `new_len` এর এক টুকরো অনেকগুলি `N` উপাদানগুলির অংশ।
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// স্লাইসটির শুরুতে শুরু করে `N`-উপাদান অ্যারেগুলির একটি টুকরোতে স্লাইসটি বিভক্ত করুন এবং `N` এর চেয়ে কম দৈর্ঘ্যের দৈর্ঘ্যের বাকি অংশগুলি।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // নিরাপত্তা: আমরা ইতিমধ্যে শূন্যের জন্য আতঙ্কিত হয়েছি, এবং নির্মাণের মাধ্যমে নিশ্চিত হয়েছি
        // সাব্লাইসের দৈর্ঘ্য এন এর একাধিক
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// স্লাইসটির শেষে শুরু করে `N`-উপাদান অ্যারেগুলির একটি টুকরোতে স্লাইসটি বিভক্ত করুন এবং `N` এর চেয়ে কম দৈর্ঘ্যের দৈর্ঘ্য সহ একটি অবশিষ্ট স্লাইস।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // নিরাপত্তা: আমরা ইতিমধ্যে শূন্যের জন্য আতঙ্কিত হয়েছি, এবং নির্মাণের মাধ্যমে নিশ্চিত হয়েছি
        // সাব্লাইসের দৈর্ঘ্য এন এর একাধিক
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `N` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি অ্যারের উল্লেখ এবং ওভারল্যাপ হয় না।
    /// যদি `N` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    ///
    /// এই পদ্ধতিটি [`chunks_exact`] এর কনস্টেন্ট জেনেরিক সমতুল্য।
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// No N`-উপাদান অ্যারেগুলির এক টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো করে ধরে নিলাম যে আর কোনও অবশিষ্ট নেই।
    ///
    ///
    /// # Safety
    ///
    /// এটি তখনই বলা যেতে পারে
    /// - টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো টুকরো।
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // নিরাপত্তা: 1-উপাদান খণ্ডগুলির আর কখনও অবশিষ্ট নেই
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // নিরাপত্তা: স্লাইস দৈর্ঘ্যের এক্স 100 এক্স 3 এর একাধিক
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // এগুলি নিরবচ্ছিন্ন হবে:
    /// // কিছু দিন: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//স্লাইসের দৈর্ঘ্য 5 টি অংশের একক নয়:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//শূন্য দৈর্ঘ্যের খণ্ডগুলি কখনই অনুমোদিত নয়
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // নিরাপত্তা: আমাদের পূর্বশর্তটি ঠিক এটির জন্য প্রয়োজন
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // নিরাপত্তা: আমরা এতে `new_len * N` উপাদানগুলির একটি টুকরা castালাই
        // `new_len` এর এক টুকরো অনেকগুলি `N` উপাদানগুলির অংশ।
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// স্লাইসটির শুরুতে শুরু করে `N`-উপাদান অ্যারেগুলির একটি টুকরোতে স্লাইসটি বিভক্ত করুন এবং `N` এর চেয়ে কম দৈর্ঘ্যের দৈর্ঘ্যের বাকি অংশগুলি।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // নিরাপত্তা: আমরা ইতিমধ্যে শূন্যের জন্য আতঙ্কিত হয়েছি, এবং নির্মাণের মাধ্যমে নিশ্চিত হয়েছি
        // সাব্লাইসের দৈর্ঘ্য এন এর একাধিক
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// স্লাইসটির শেষে শুরু করে `N`-উপাদান অ্যারেগুলির একটি টুকরোতে স্লাইসটি বিভক্ত করুন এবং `N` এর চেয়ে কম দৈর্ঘ্যের দৈর্ঘ্য সহ একটি অবশিষ্ট স্লাইস।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // নিরাপত্তা: আমরা ইতিমধ্যে শূন্যের জন্য আতঙ্কিত হয়েছি, এবং নির্মাণের মাধ্যমে নিশ্চিত হয়েছি
        // সাব্লাইসের দৈর্ঘ্য এন এর একাধিক
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// স্লাইসের শুরুতে শুরু করে একসাথে স্লাইসের `N` উপাদানের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি পরিবর্তনীয় অ্যারে উল্লেখ এবং ওভারল্যাপ হয় না।
    /// যদি `N` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `into_remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    ///
    /// এই পদ্ধতিটি [`chunks_exact_mut`] এর কনস্টেন্ট জেনেরিক সমতুল্য।
    ///
    /// # Panics
    ///
    /// Panics যদি `N` হয় 0 তবে এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে সম্ভবত এই চেকটি একটি সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// স্লাইসের শুরুতে এক স্লাইসের `N` এলিমেন্টের windows ওভারল্যাপিংয়ের মাধ্যমে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    ///
    ///
    /// এটি [`windows`] এর কনস্টেন্ট জেনেরিক সমতুল্য।
    ///
    /// যদি `N` স্লাইজের আকারের চেয়ে বড় হয় তবে এটি কোনও windows প্রদান করবে না।
    ///
    /// # Panics
    ///
    /// `N` 0 হলে Panics।
    /// এই পদ্ধতিটি স্থিতিশীল হওয়ার আগে এই চেকটি সম্ভবত সংকলন সময়ের ত্রুটিতে পরিবর্তিত হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// স্লাইসের শেষে শুরু হয়ে একসাথে স্লাইসের `chunk_size` উপাদানগুলির উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি টুকরো টুকরো হয় এবং ওভারল্যাপ হয় না।যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ খণ্ডটির দৈর্ঘ্য `chunk_size` হবে না।
    ///
    /// এই পুনরাবৃত্তির একটি বৈকল্পিকের জন্য [`rchunks_exact`] দেখুন যা সর্বদা সঠিকভাবে `chunk_size` উপাদানগুলির অংশ এবং একই পুনরুক্তির জন্য [`chunks`] প্রদান করে তবে স্লাইসের শুরুতে শুরু হয়।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// স্লাইসের শেষে শুরু হয়ে একসাথে স্লাইসের `chunk_size` উপাদানগুলির উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি পরিবর্তনীয় টুকরা হয় এবং ওভারল্যাপ হয় না।যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ খণ্ডটির দৈর্ঘ্য `chunk_size` হবে না।
    ///
    /// এই পুনরাবৃত্তির একটি বৈকল্পিকের জন্য [`rchunks_exact_mut`] দেখুন যা সর্বদা সঠিকভাবে `chunk_size` উপাদানগুলির অংশ এবং একই পুনরুক্তির জন্য [`chunks_mut`] প্রদান করে তবে স্লাইসের শুরুতে শুরু হয়।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// স্লাইসের শেষে শুরু হয়ে একসাথে স্লাইসের `chunk_size` উপাদানগুলির উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি টুকরো টুকরো হয় এবং ওভারল্যাপ হয় না।
    /// যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    /// প্রতিটি খণ্ডে ঠিক `chunk_size` উপাদান থাকার কারণে, সংকলক প্রায়শই [`chunks`] এর চেয়ে ফলাফলের কোডটি আরও ভাল করতে পারে।
    ///
    /// এই পুনরাবৃত্তির একটি বৈকল্পিকের জন্য [`rchunks`] দেখুন যা বাকীটিকে আরও ছোট ছোট অংশ হিসাবে এবং একই পুনরুক্তারের জন্য [`chunks_exact`] প্রদান করে তবে স্লাইসের শুরুতে শুরু করে।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// স্লাইসের শেষে শুরু হয়ে একসাথে স্লাইসের `chunk_size` উপাদানগুলির উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// খণ্ডগুলি পরিবর্তনীয় টুকরা হয় এবং ওভারল্যাপ হয় না।
    /// যদি `chunk_size` স্লাইসের দৈর্ঘ্যকে ভাগ না করে, তবে শেষ পর্যন্ত এক্স01 এক্স উপাদান বাদ দেওয়া হবে এবং পুনরুক্তকারীর `into_remainder` ফাংশন থেকে পুনরুদ্ধার করা যাবে।
    ///
    /// প্রতিটি খণ্ডে ঠিক `chunk_size` উপাদান থাকার কারণে, সংকলক প্রায়শই [`chunks_mut`] এর চেয়ে ফলাফলের কোডটি আরও ভাল করতে পারে।
    ///
    /// এই পুনরাবৃত্তির একটি বৈকল্পিকের জন্য [`rchunks_mut`] দেখুন যা বাকীটিকে আরও ছোট ছোট অংশ হিসাবে এবং একই পুনরুক্তারের জন্য [`chunks_exact_mut`] প্রদান করে তবে স্লাইসের শুরুতে শুরু করে।
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 হলে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// স্লাইসকে পৃথক করার জন্য প্রিকেট ব্যবহার করে অ-ওভারল্যাপিং উপাদানের উত্পাদন করে স্লাইসের উপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    ///
    /// শিকারী দুটি নিজস্ব উপাদান অনুসরণ করে ডাকা হয়, এর অর্থ হ'ল প্রিডিকেটটি `slice[0]` এবং `slice[1]` এবং তারপরে `slice[1]` এবং `slice[2]` এবং আরও কিছুতে ডাকা হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// এই পদ্ধতিটি বাছাই করা সাবস্কাইলগুলি নিষ্কাশন করতে ব্যবহার করা যেতে পারে:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// স্লাইসের উপরে একটি পুনরাবৃত্তকারীকে পৃথক করতে প্রিকেট ব্যবহার করে উপাদানগুলির নন-ওভারল্যাপিং মিউটেবল রানের উত্পাদন করে।
    ///
    /// শিকারী দুটি নিজস্ব উপাদান অনুসরণ করে ডাকা হয়, এর অর্থ হ'ল প্রিডিকেটটি `slice[0]` এবং `slice[1]` এবং তারপরে `slice[1]` এবং `slice[2]` এবং আরও কিছুতে ডাকা হয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// এই পদ্ধতিটি বাছাই করা সাবস্কাইলগুলি নিষ্কাশন করতে ব্যবহার করা যেতে পারে:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// একটি সূচকে একটি টুকরোকে দুটি ভাগে ভাগ করে।
    ///
    /// প্রথমটিতে `[0, mid)` থেকে সমস্ত সূচক থাকবে (নিজেই সূচক `mid` বাদে) এবং দ্বিতীয়টিতে `[mid, len)` থেকে সমস্ত সূচক থাকবে (সূচিপত্র `len` নিজেই বাদে)।
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // নিরাপদ: `[ptr; mid]` এবং `[mid; len]` `self` এর ভিতরে রয়েছে, যা
        // `from_raw_parts_mut` এর প্রয়োজনীয়তা পূরণ করে।
        unsafe { self.split_at_unchecked(mid) }
    }

    /// একটি সূচকগুলিতে একটি পরিবর্তনীয় স্লাইস দুটিতে ভাগ করে।
    ///
    /// প্রথমটিতে `[0, mid)` থেকে সমস্ত সূচক থাকবে (নিজেই সূচক `mid` বাদে) এবং দ্বিতীয়টিতে `[mid, len)` থেকে সমস্ত সূচক থাকবে (সূচিপত্র `len` নিজেই বাদে)।
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` যদি Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // নিরাপদ: `[ptr; mid]` এবং `[mid; len]` `self` এর ভিতরে রয়েছে, যা
        // `from_raw_parts_mut` এর প্রয়োজনীয়তা পূরণ করে।
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// সীমানা যাচাই না করে একটি সূচকে দুটি সূচকে বিভক্ত করে।
    ///
    /// প্রথমটিতে `[0, mid)` থেকে সমস্ত সূচক থাকবে (নিজেই সূচক `mid` বাদে) এবং দ্বিতীয়টিতে `[mid, len)` থেকে সমস্ত সূচক থাকবে (সূচিপত্র `len` নিজেই বাদে)।
    ///
    ///
    /// নিরাপদ বিকল্পের জন্য দেখুন [`split_at`]।
    ///
    /// # Safety
    ///
    /// ফলাফলের রেফারেন্সটি ব্যবহার না করা সত্ত্বেও, এই পদ্ধতিটিকে একটি সীমানার বাইরে সূচক দিয়ে কল করা *[অপরিবর্তিত আচরণ]* isফোনকারীকে এটি `0 <= mid <= self.len()` নিশ্চিত করতে হবে।
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // নিরাপদ: কলারকে সেই `0 <= mid <= self.len()` পরীক্ষা করতে হবে
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// সীমানা যাচাই না করে একটি সূচকগুলিতে একটি পরিবর্তনীয় স্লাইসকে দুটিতে বিভক্ত করে।
    ///
    /// প্রথমটিতে `[0, mid)` থেকে সমস্ত সূচক থাকবে (নিজেই সূচক `mid` বাদে) এবং দ্বিতীয়টিতে `[mid, len)` থেকে সমস্ত সূচক থাকবে (সূচিপত্র `len` নিজেই বাদে)।
    ///
    ///
    /// নিরাপদ বিকল্পের জন্য দেখুন [`split_at_mut`]।
    ///
    /// # Safety
    ///
    /// ফলাফলের রেফারেন্সটি ব্যবহার না করা সত্ত্বেও, এই পদ্ধতিটিকে একটি সীমানার বাইরে সূচক দিয়ে কল করা *[অপরিবর্তিত আচরণ]* isফোনকারীকে এটি `0 <= mid <= self.len()` নিশ্চিত করতে হবে।
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // নিরাপদ: কলারকে সেই `0 <= mid <= self.len()` পরীক্ষা করতে হবে।
        //
        // `[ptr; mid]` এবং `[mid; len]` ওভারল্যাপিং হয় না, সুতরাং একটি পরিবর্তনীয় রেফারেন্স প্রদান ভাল is
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred`-এর সাথে মেলে এমন উপাদানগুলির দ্বারা পৃথক হওয়া সাবস্ক্রাইবগুলির উপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// যদি প্রথম উপাদানটি মিলে যায় তবে খালি স্লাইসটি প্রথম আইটেমটি হবে যা পুনরাবৃত্তিকারী দ্বারা ফিরে আসবে।
    /// একইভাবে, যদি স্লাইসের সর্বশেষ উপাদানটি মিলে যায় তবে খালি স্লাইসটি পুনরাবৃত্তকারী দ্বারা ফিরে আসা সর্বশেষ আইটেম হবে:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// দুটি মিলিত উপাদান সরাসরি সংলগ্ন হলে একটি ফাঁকা ফালি তাদের মধ্যে উপস্থিত থাকবে:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred`-এর সাথে মেলে এমন উপাদানগুলির দ্বারা পৃথক করা পরিবর্তনীয় সাবস্ক্রাইলে একটি পুনরাবৃত্তির ফেরত দেয়।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred`-এর সাথে মেলে এমন উপাদানগুলির দ্বারা পৃথক হওয়া সাবস্ক্রাইবগুলির উপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    /// মেলে থাকা উপাদানটি টার্মিনেটর হিসাবে পূর্ববর্তী সাবস্লাইসের শেষে থাকে।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// যদি স্লাইসের শেষ উপাদানটির সাথে মিলে যায়, তবে সেই উপাদানটি পূর্ববর্তী স্লাইসের টার্মিনেটর হিসাবে বিবেচিত হবে।
    ///
    /// এই স্লাইসটি আইট্রেটর দ্বারা ফিরিয়ে দেওয়া শেষ আইটেম হবে।
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred`-এর সাথে মেলে এমন উপাদানগুলির দ্বারা পৃথক করা পরিবর্তনীয় সাবস্ক্রাইলে একটি পুনরাবৃত্তির ফেরত দেয়।
    /// মেলে থাকা উপাদানটি টার্মিনেটর হিসাবে পূর্বের সাব্লিসে অন্তর্ভুক্ত।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// স্লাইস শেষে শুরু করে পিছনের দিকে কাজ করে `pred` এর সাথে মিল পাওয়া উপাদানগুলির দ্বারা পৃথক সাবস্ক্রাইজের উপরে একটি পুনরাবৃত্তির ফেরত দেয়।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` এর মতো, যদি প্রথম বা শেষ উপাদানটি মিলে যায় তবে খালি স্লাইসটি প্রথম (বা শেষ) আইট্রেটর দ্বারা ফিরে আসা আইটেম হবে।
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// স্লাইসের শেষে শুরু হয়ে পিছনের দিকে কাজ করে `pred` এর সাথে মিল রেখে এমন উপাদানগুলির দ্বারা বিভাজিত মিউটটেবল সাবস্ক্রাইলে একটি পুনরাবৃত্তির ফেরত দেয়।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` এর সাথে মেলে এমন উপাদান দ্বারা বিভাজিত সাবস্ক্রাইকের উপর একটি পুনরাবৃত্তিকে ফেরত দেয়, সর্বাধিক `n` আইটেমগুলিতে ফিরতে সীমাবদ্ধ।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// শেষ উপাদানটি ফিরে এসেছে, যদি থাকে তবে এই স্লাইসের বাকী অংশ থাকবে।
    ///
    /// # Examples
    ///
    /// একবারে 3 দ্বারা বিভাজ্য সংখ্যা দ্বারা স্লাইস বিভক্ত মুদ্রণ করুন (অর্থাত, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` এর সাথে মেলে এমন উপাদান দ্বারা বিভাজিত সাবস্ক্রাইকের উপর একটি পুনরাবৃত্তিকে ফেরত দেয়, সর্বাধিক `n` আইটেমগুলিতে ফিরতে সীমাবদ্ধ।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// শেষ উপাদানটি ফিরে এসেছে, যদি থাকে তবে এই স্লাইসের বাকী অংশ থাকবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// `pred` সর্বাধিক `n` আইটেমগুলিতে ফিরতে সীমাবদ্ধ এমন উপাদানগুলির দ্বারা পৃথক হওয়া সাবস্ক্রাইবগুলির উপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    /// এটি স্লাইস শেষে শুরু হয় এবং পিছনের দিকে কাজ করে।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// শেষ উপাদানটি ফিরে এসেছে, যদি থাকে তবে এই স্লাইসের বাকী অংশ থাকবে।
    ///
    /// # Examples
    ///
    /// শেষ থেকে শুরু করে একবারে স্লাইস বিভাজনটি মুদ্রণ করুন 3 দ্বারা বিভাজ্য সংখ্যা দ্বারা (অর্থাত্ `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// `pred` সর্বাধিক `n` আইটেমগুলিতে ফিরতে সীমাবদ্ধ এমন উপাদানগুলির দ্বারা পৃথক হওয়া সাবস্ক্রাইবগুলির উপরে একটি পুনরাবৃত্তিকে ফেরত দেয়।
    /// এটি স্লাইস শেষে শুরু হয় এবং পিছনের দিকে কাজ করে।
    /// মিলে যাওয়া উপাদানটি সাবস্কাইলে থাকে না।
    ///
    /// শেষ উপাদানটি ফিরে এসেছে, যদি থাকে তবে এই স্লাইসের বাকী অংশ থাকবে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// যদি স্লাইসে প্রদত্ত মান সহ কোনও উপাদান থাকে তবে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// আপনার যদি `&T` না থাকে তবে কেবলমাত্র `&U` এর মতো `T: Borrow<U>` থাকে (উদাঃ)
    /// Ring স্ট্রিং: ধার<str>`), আপনি `iter().any` ব্যবহার করতে পারেন:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` এর টুকরা
    /// assert!(v.iter().any(|e| e == "hello")); // এক্স 100 এক্স দিয়ে অনুসন্ধান করুন
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` স্লাইসের একটি উপসর্গ হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` একটি খালি টুকরা হলে সর্বদা `true` প্রদান করে:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` স্লাইসের প্রত্যয় হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` একটি খালি টুকরা হলে সর্বদা `true` প্রদান করে:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// উপসর্গটি মুছে ফেলা সহ একটি সাব্লাইস দেয়।
    ///
    /// যদি স্লাইসটি X01 এক্স দিয়ে শুরু হয়, `Some` এ আবৃত উপসর্গের পরে সাবস্ক্রাইসটি প্রদান করে।
    /// যদি `prefix` খালি থাকে তবে কেবল আসল টুকরোটি ফেরত দেয়।
    ///
    /// যদি স্লাইসটি `prefix` দিয়ে শুরু না হয়, এক্স 100 এক্স প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // স্লাইসপ্যাটার্ন আরও পরিশীলিত হয়ে উঠলে এই ফাংশনটির পুনর্লিখনের প্রয়োজন হবে।
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// প্রত্যয়টি মুছে ফেলা সহ একটি সাব্লাইস দেয়।
    ///
    /// যদি স্লাইসটি X01 এক্স দিয়ে শেষ হয়, `Some` এ আবৃত প্রত্যয়টির আগে সাব্লাইসটি প্রদান করে।
    /// যদি `suffix` খালি থাকে তবে কেবল আসল টুকরোটি ফেরত দেয়।
    ///
    /// যদি স্লাইসটি `suffix` দিয়ে শেষ না হয় তবে এক্স 100 এক্স প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // স্লাইসপ্যাটার্ন আরও পরিশীলিত হয়ে উঠলে এই ফাংশনটির পুনর্লিখনের প্রয়োজন হবে।
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// বাইনারি একটি নির্দিষ্ট উপাদানের জন্য এই বাছাই করা স্লাইসটি অনুসন্ধান করে।
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।
    /// যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    ///
    /// এক্স01 এক্স, এক্স02 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// চারটি উপাদানের একটি সিরিজ দেখায়।
    /// প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// আপনি যদি সাজানোর ক্রম বজায় রেখে একটি সাজানো vector এ কোনও আইটেম সন্নিবেশ করতে চান:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// বাইনারি একটি তুলনামূলক ফাংশন সহ এই সাজানো টুকরা অনুসন্ধান করে।
    ///
    /// তুলনাকারী ফাংশনটি অন্তর্নিহিত স্লাইসের ক্রমক্রমের সাথে সামঞ্জস্য করে একটি আদেশ কার্যকর করতে হবে, যাতে একটি আদেশ কোড ফেরত যায় যা তার যুক্তিটি `Less`, `Equal` বা `Greater` পছন্দসই লক্ষ্য কিনা তা নির্দেশ করে।
    ///
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    /// এক্স01 এক্স, এক্স02 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// চারটি উপাদানের একটি সিরিজ দেখায়।প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // সুরক্ষা: কলটি নিম্নলিখিত আক্রমণকারীদের দ্বারা সুরক্ষিত করা হয়েছে:
            // - `mid >= 0`
            // - `mid < size`: `mid` এক্স01 এক্স দ্বারা সীমাবদ্ধ।
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // আমরা ম্যাচের পরিবর্তে if/else নিয়ন্ত্রণ প্রবাহটি ব্যবহার করার কারণ হ'ল ম্যাচের পুনর্বিন্যাস তুলনা অপারেশন, যা পারফেক্ট সংবেদনশীল।
            //
            // এটি u8 এর জন্য x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// বাইনারি একটি চাবি নিষ্কাশন ফাংশন সহ এই সাজানো টুকরা অনুসন্ধান করে।
    ///
    /// ধরে নিন যে স্লাইসটি কী দ্বারা বাছাই করা হয়েছে, উদাহরণস্বরূপ একই কী নিষ্কাশন ফাংশনটি ব্যবহার করে [`sort_by_key`] দিয়ে with
    ///
    /// যদি মানটি পাওয়া যায় তবে [`Result::Ok`] ফেরত পাওয়া যায়, এতে মিলের উপাদানটির সূচক থাকে।
    /// যদি একাধিক ম্যাচ থাকে তবে ম্যাচের যে কোনও একটিরও ফেরত যেতে পারে।
    /// মানটি যদি খুঁজে পাওয়া যায় না তবে [`Result::Err`] ফেরত দেওয়া হবে, যেখানে সূচিযুক্ত সাজানো থাকে যেখানে সাজানো ক্রম বজায় রাখার সময় কোনও ম্যাচিং উপাদান যুক্ত করা যেতে পারে।
    ///
    ///
    /// এক্স01 এক্স, এক্স02 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// তাদের দ্বিতীয় উপাদানগুলির দ্বারা বাছাই করা জোড়াগুলির টুকরোতে চারটি উপাদানের একটি সিরিজ দেখায়।
    /// প্রথমটি পাওয়া যায়, একটি অনন্য নির্ধারিত অবস্থান সহ;দ্বিতীয় এবং তৃতীয়টি পাওয়া যায় না;চতুর্থটি `[1, 4]` এ যে কোনও অবস্থানের সাথে মেলে match
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` এ `slice::sort_by_key` রয়েছে হিসাবে Lint rustdoc::broken_intra_doc_links অনুমোদিত, এবং এটি `core` নির্মাণের সময় এখনও বিদ্যমান নেই।
    //
    // ডাউন স্ট্রিম crate: #74481 এর লিঙ্কগুলি।যেহেতু আদিমগুলি কেবল লিবিস্টডি এক্স01 এক্সে নথিভুক্ত থাকে, এটি কখনই অনুশীলনে ভাঙা লিঙ্কগুলিতে বাড়ে না।
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// স্লাইস বাছাই করে তবে সমান উপাদানের ক্রম সংরক্ষণ করতে পারে না।
    ///
    /// এই বাছাইটি অস্থির (যেমন, সমান উপাদানগুলির পুনঃক্রম করতে পারে), জায়গায় (যেমন বরাদ্দ দেয় না), এবং *ও*(*এন*\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে)।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম ওসন পিটার্স দ্বারা [pattern-defeating quicksort][pdqsort] এর উপর ভিত্তি করে তৈরি করা হয়েছে, যা র্যান্ডমাইজড কুইকোর্টের দ্রুত গড় কেসকে হিপসোর্টের দ্রুততম খারাপের সাথে একত্রিত করে, যখন নির্দিষ্ট নিদর্শনগুলির সাথে স্লাইসগুলিতে রৈখিক সময় অর্জন করে।
    /// এটি অবক্ষয়জনিত কেসগুলি এড়ানোর জন্য কিছুটা র‌্যান্ডমাইজেশন ব্যবহার করে তবে সর্বদা নির্দ্বিধামূলক আচরণ প্রদানের জন্য একটি স্থির seed ব্যবহার করে।
    ///
    /// এটি সাধারণত স্থিতিশীল বাছাইয়ের চেয়ে দ্রুততর হয়, কয়েকটি বিশেষ ক্ষেত্রে বাদে, উদাহরণস্বরূপ, যখন স্লাইসটি বেশ কয়েকটি কনটেনেটেড সাজানো ক্রমগুলি নিয়ে থাকে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// একটি তুলনামূলক ফাংশন দিয়ে স্লাইস সাজান, তবে সমান উপাদানের ক্রম সংরক্ষণ করতে পারে না।
    ///
    /// এই বাছাইটি অস্থির (যেমন, সমান উপাদানগুলির পুনঃক্রম করতে পারে), জায়গায় (যেমন বরাদ্দ দেয় না), এবং *ও*(*এন*\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে)।
    ///
    /// তুলক ফাংশন অবশ্যই স্লাইসের উপাদানগুলির জন্য মোট ক্রম সংজ্ঞায়িত করতে হবে।যদি অর্ডারিং মোটটি না হয় তবে উপাদানগুলির ক্রমটি অনির্দিষ্ট।একটি অর্ডার মোট অর্ডার হয় যদি তা হয় (সমস্ত `a`, `b` এবং `c` এর জন্য):
    ///
    /// * মোট এবং অ্যান্টিসিমমেট্রিক: `a < b`, `a == b` বা `a > b` এর মধ্যে একটি সত্য, এবং
    /// * ট্রানজিটিভ, `a < b` এবং `b < c` এক্স01 এক্সকে বোঝায়।এটি অবশ্যই `==` এবং `>` উভয়ের জন্যই রাখা উচিত।
    ///
    /// উদাহরণস্বরূপ, [`f64`] [`Ord`] বাস্তবায়িত করে না কারণ `NaN != NaN`, আমরা যখন স্লাইসটিতে একটি এক্স 100 এক্স না থাকে তখন আমরা `partial_cmp` টিকে আমাদের বাছাই ফাংশন হিসাবে ব্যবহার করতে পারি।
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম ওসন পিটার্স দ্বারা [pattern-defeating quicksort][pdqsort] এর উপর ভিত্তি করে তৈরি করা হয়েছে, যা র্যান্ডমাইজড কুইকোর্টের দ্রুত গড় কেসকে হিপসোর্টের দ্রুততম খারাপের সাথে একত্রিত করে, যখন নির্দিষ্ট নিদর্শনগুলির সাথে স্লাইসগুলিতে রৈখিক সময় অর্জন করে।
    /// এটি অবক্ষয়জনিত কেসগুলি এড়ানোর জন্য কিছুটা র‌্যান্ডমাইজেশন ব্যবহার করে তবে সর্বদা নির্দ্বিধামূলক আচরণ প্রদানের জন্য একটি স্থির seed ব্যবহার করে।
    ///
    /// এটি সাধারণত স্থিতিশীল বাছাইয়ের চেয়ে দ্রুততর হয়, কয়েকটি বিশেষ ক্ষেত্রে বাদে, উদাহরণস্বরূপ, যখন স্লাইসটি বেশ কয়েকটি কনটেনেটেড সাজানো ক্রমগুলি নিয়ে থাকে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // বিপরীত বাছাই
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// কী নিষ্কাশন ফাংশন দিয়ে স্লাইসটি সাজান তবে এটি সমান উপাদানের ক্রম সংরক্ষণ করতে পারে না।
    ///
    /// এই বাছাইটি অস্থির (যেমন সমান উপাদানগুলিকে পুনরায় অর্ডার করতে পারে), জায়গায় (যেমন বরাদ্দ দেয় না) এবং *ও*(এম\* * এন *\* এক্স00 এক্স সবচেয়ে খারাপ ক্ষেত্রে) যেখানে মূল ফাংশনটি *ও*(*মি*)।
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম ওসন পিটার্স দ্বারা [pattern-defeating quicksort][pdqsort] এর উপর ভিত্তি করে তৈরি করা হয়েছে, যা র্যান্ডমাইজড কুইকোর্টের দ্রুত গড় কেসকে হিপসোর্টের দ্রুততম খারাপের সাথে একত্রিত করে, যখন নির্দিষ্ট নিদর্শনগুলির সাথে স্লাইসগুলিতে রৈখিক সময় অর্জন করে।
    /// এটি অবক্ষয়জনিত কেসগুলি এড়ানোর জন্য কিছুটা র‌্যান্ডমাইজেশন ব্যবহার করে তবে সর্বদা নির্দ্বিধামূলক আচরণ প্রদানের জন্য একটি স্থির seed ব্যবহার করে।
    ///
    /// এটির মূল কলিং কৌশলটির কারণে, কী ফাংশন ব্যয়বহুল ক্ষেত্রে ক্ষেত্রে [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) এর চেয়ে ধীর হতে পারে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// স্লাইসটি পুনঃক্রম করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে position
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// তুলনামূলক ফাংশন দিয়ে স্লাইসটি পুনরায় অর্ডার করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে।
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// কোনও কী নিষ্কাশন ফাংশন দিয়ে স্লাইসটি পুনঃক্রম করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে।
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// স্লাইসটি পুনঃক্রম করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে position
    ///
    /// এই পুনর্নির্মাণের অতিরিক্ত সম্পত্তি রয়েছে যা `i < index` অবস্থানের যে কোনও মান কোনও অবস্থান `j > index` এ যে কোনও মানের থেকে কম বা সমান হবে।
    /// অতিরিক্তভাবে, এই পুনঃক্রমটি অস্থির (যেমন ie
    /// সমান উপাদানের যে কোনও সংখ্যার অবস্থান `index` পজিশনে শেষ হতে পারে), জায়গায় (যেমন
    /// বরাদ্দ দেয় না) এবং *ও*(*এন*) সবচেয়ে খারাপ ক্ষেত্রে।
    /// এই ফাংশনটি অন্যান্য লাইব্রেরিতে "kth element" নামেও পরিচিত।
    /// এটি নিম্নলিখিত মানগুলির একটি ট্রিপলটি ফেরত দেয়: প্রদত্ত সূচকের একের চেয়ে কম সমস্ত উপাদান, প্রদত্ত সূচকের মান এবং প্রদত্ত সূচকের একের চেয়ে বড় সমস্ত উপাদান।
    ///
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম [`sort_unstable`] এর জন্য ব্যবহৃত একই কুইকোর্টের অ্যালগোরিদমের কুইকসलेक्ट অংশের উপর ভিত্তি করে।
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` যখন Panics, এর অর্থ এটি সর্বদা খালি টুকরোগুলিতে panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // মাঝারি সন্ধান করুন
    /// v.select_nth_unstable(2);
    ///
    /// // আমরা কেবলমাত্র নিশ্চিত হয়েছি যে স্লাইসটি নির্দিষ্ট সূচকগুলির অনুসারে বাছাই করার পদ্ধতি অনুসারে নিম্নলিখিতগুলির মধ্যে একটি হবে।
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// তুলনামূলক ফাংশন দিয়ে স্লাইসটি পুনরায় অর্ডার করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে।
    ///
    /// এই পুনর্নির্মাণের অতিরিক্ত সম্পত্তি রয়েছে যা `i < index` অবস্থানের যে কোনও মান তুলনামূলক ফাংশনটি ব্যবহার করে কোনও অবস্থানের `j > index` এ কোনও মানের থেকে কম বা সমান হবে।
    /// অতিরিক্তভাবে, এই পুনঃক্রমটি অস্থির (যেমন কোনও সমান উপাদানগুলির সংখ্যা `index` পজিশনে শেষ হতে পারে), ইন-প্লেস (অর্থ বরাদ্দ দেয় না), এবং *ও*(*এন*) সবচেয়ে খারাপ ক্ষেত্রে।
    /// এই ফাংশনটি অন্যান্য গ্রন্থাগারে "kth element" নামেও পরিচিত।
    /// এটি নিম্নলিখিত মানগুলির একটি ট্রিপলটি প্রদান করে: প্রদত্ত সূচকের মানগুলির চেয়ে কম সমস্ত উপাদান, প্রদত্ত সূচকের মান এবং প্রদত্ত তুলনামূলক ফাংশনটি ব্যবহার করে প্রদত্ত সূচকে একের চেয়ে বড় সমস্ত উপাদান।
    ///
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম [`sort_unstable`] এর জন্য ব্যবহৃত একই কুইকোর্টের অ্যালগোরিদমের কুইকসलेक्ट অংশের উপর ভিত্তি করে।
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` যখন Panics, এর অর্থ এটি সর্বদা খালি টুকরোগুলিতে panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // মিডিয়ানটিকে সন্ধান করুন যেন স্লাইসটি সাজানো ক্রমে সাজানো হয়েছে।
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // আমরা কেবলমাত্র নিশ্চিত হয়েছি যে স্লাইসটি নির্দিষ্ট সূচকগুলির অনুসারে বাছাই করার পদ্ধতি অনুসারে নিম্নলিখিতগুলির মধ্যে একটি হবে।
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// কোনও কী নিষ্কাশন ফাংশন দিয়ে স্লাইসটি পুনঃক্রম করুন যাতে `index` এ উপাদানটি তার চূড়ান্ত বাছাই করা অবস্থানে থাকে।
    ///
    /// এই পুনর্নির্মাণের অতিরিক্ত সম্পত্তি রয়েছে যা `i < index` অবস্থানের যে কোনও মান কী এক্সট্রাকশন ফাংশন ব্যবহার করে `j > index` পজিশনে কোনও মানের চেয়ে কম বা সমান হবে।
    /// অতিরিক্তভাবে, এই পুনঃক্রমটি অস্থির (যেমন কোনও সমান উপাদানগুলির সংখ্যা `index` পজিশনে শেষ হতে পারে), ইন-প্লেস (অর্থ বরাদ্দ দেয় না), এবং *ও*(*এন*) সবচেয়ে খারাপ ক্ষেত্রে।
    /// এই ফাংশনটি অন্যান্য গ্রন্থাগারে "kth element" নামেও পরিচিত।
    /// এটি নিম্নলিখিত মানগুলির একটি ট্রিপলটি প্রদান করে: প্রদত্ত মূল সূচক ফাংশনটি ব্যবহার করে প্রদত্ত সূচকের মানগুলির চেয়ে কম সমস্ত উপাদান, প্রদত্ত সূচকের মান এবং প্রদত্ত সূচকে একের চেয়ে বড় সমস্ত উপাদান।
    ///
    ///
    /// # বর্তমান বাস্তবায়ন
    ///
    /// বর্তমান অ্যালগরিদম [`sort_unstable`] এর জন্য ব্যবহৃত একই কুইকোর্টের অ্যালগোরিদমের কুইকসलेक्ट অংশের উপর ভিত্তি করে।
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` যখন Panics, এর অর্থ এটি সর্বদা খালি টুকরোগুলিতে panics।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // মধ্যমাটি এমনভাবে ফিরিয়ে দিন যেন অ্যারে পরম মান অনুসারে বাছাই করা হয়েছিল।
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // আমরা কেবলমাত্র নিশ্চিত হয়েছি যে স্লাইসটি নির্দিষ্ট সূচকগুলির অনুসারে বাছাই করার পদ্ধতি অনুসারে নিম্নলিখিতগুলির মধ্যে একটি হবে।
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait বাস্তবায়ন অনুসারে একটানা সমস্ত পুনরাবৃত্ত উপাদানগুলি স্লাইসের শেষে সরিয়ে দেয়।
    ///
    ///
    /// দুটি টুকরা ফেরত দেয়।প্রথমটিতে কোনও ক্রমাগত পুনরাবৃত্তি উপাদান নেই।
    /// দ্বিতীয়টিতে কোনও নির্দিষ্ট ক্রমে সমস্ত নকল রয়েছে।
    ///
    /// যদি স্লাইসটি বাছাই করা হয় তবে প্রথম ফিরে আসা স্লাইসে কোনও নকল নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// প্রদত্ত সাম্যতার সম্পর্কটিকে সন্তুষ্ট করে টুকরো টুকরোটির শেষে পর পরের উপাদানগুলির ব্যতীত সমস্তগুলি সরানো হয়।
    ///
    /// দুটি টুকরা ফেরত দেয়।প্রথমটিতে কোনও ক্রমাগত পুনরাবৃত্তি উপাদান নেই।
    /// দ্বিতীয়টিতে কোনও নির্দিষ্ট ক্রমে সমস্ত নকল রয়েছে।
    ///
    /// এক্স 100 এক্স ফাংশনটি স্লাইস থেকে দুটি উপাদানের রেফারেন্স পাস করেছে এবং উপাদানগুলি সমান তুলনা করে কিনা তা নির্ধারণ করতে হবে।
    /// উপাদানগুলি স্লাইসে তাদের ক্রম থেকে বিপরীত ক্রমে উত্তীর্ণ হয়, সুতরাং `same_bucket(a, b)` যদি `true` ফেরত দেয় তবে `a` স্লাইসের শেষে সরানো হয়।
    ///
    ///
    /// যদি স্লাইসটি বাছাই করা হয় তবে প্রথম ফিরে আসা স্লাইসে কোনও নকল নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // যদিও আমাদের কাছে `self` এর একটি পরিবর্তনীয় রেফারেন্স রয়েছে, আমরা *যথেচ্ছ* পরিবর্তন করতে পারি না।`same_bucket` কলগুলি panic করতে পারে, সুতরাং আমাদের অবশ্যই নিশ্চিত করতে হবে যে স্লাইসটি সর্বদা একটি বৈধ অবস্থায় রয়েছে।
        //
        // আমরা যেভাবে এটি পরিচালনা করি তা হ'ল অদলবদল ব্যবহার করে;আমরা সমস্ত উপাদানগুলির সাথে পুনরাবৃত্তি করি, যেতে যেতে অদলবদল করি যাতে শেষে আমরা যে উপাদানগুলি রাখতে চাই তা সামনে হয় এবং আমরা প্রত্যাখ্যান করতে চাই তারা পিছনে থাকে।
        // তারপরে আমরা স্লাইসটি বিভক্ত করতে পারি।
        // এই অপারেশনটি এখনও `O(n)`।
        //
        // উদাহরণ: আমরা এই অবস্থায় শুরু করি, যেখানে `r` "পরবর্তী" প্রতিনিধিত্ব করে
        // "এবং `w` নেক্সট_ রাইটw উপস্থাপন করে read
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // এক্স [এক্স-এক্স] কে নিজের সাথে [ডাব্লু-১] তুলনা করা, এটি কোনও সদৃশ নয়, সুতরাং আমরা এক্স01 এক্স এবং এক্স0 2 এক্স (r==w হিসাবে কোনও প্রভাব ফেলব না) এবং তারপরে আর এবং ডাব্লু উভয়ই বৃদ্ধি করব:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // এক্স [এক্স-এক্স] কে নিজের সাথে [ডাব্লু-1] এর সাথে তুলনা করা, এই মানটি একটি সদৃশ, সুতরাং আমরা এক্স01 এক্স বৃদ্ধি করি তবে সমস্ত কিছু অপরিবর্তিত রাখি:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // এক্সের সাথে self[r] এর তুলনা করুন [w-1], এটি কোনও সদৃশ নয়, সুতরাং self[r] এবং self[w] এবং অগ্রিম আর এবং ডাবলু পরিবর্তন করুন:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // সদৃশ নয়, পুনরাবৃত্তি করুন:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // সদৃশ, স্লাইসের advance r. End।ডাব্লু এ বিভক্ত।
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // নিরাপদ: `while` শর্তটি `next_read` এবং `next_write` এর গ্যারান্টি দেয়
        // `len` এর চেয়ে কম, সুতরাং এটি `self` এর অভ্যন্তরে।
        // `prev_ptr_write` `ptr_write` এর আগে একটি উপাদানকে নির্দেশ করে, তবে `next_write` 1 থেকে শুরু হয়, তাই `prev_ptr_write` কখনও 0 এর চেয়ে কম হয় না এবং স্লাইসের ভিতরে থাকে।
        // এটি `ptr_read`, `prev_ptr_write` এবং `ptr_write`, এবং `ptr.add(next_read)`, `ptr.add(next_write - 1)` এবং `prev_ptr_write.offset(1)` ব্যবহারের জন্য প্রয়োজনীয়তা পূরণ করে।
        //
        //
        // `next_write` লুপ প্রতি একবারে একবারে বৃদ্ধি করা হয় যার অর্থ যখন কোনও অ্যালিপ অদলবদলের প্রয়োজন হয় তখন কোনও উপাদান এড়ানো যায় না।
        //
        // `ptr_read` এবং `prev_ptr_write` কখনও একই উপাদানটির দিকে নির্দেশ করে না।এটি `&mut *ptr_read`, `&mut* prev_ptr_write` নিরাপদ থাকার জন্য প্রয়োজনীয়।
        // ব্যাখ্যাটি কেবল সহজ যে `next_read >= next_write` সর্বদা সত্য, সুতরাং `next_read > next_write - 1` ও সত্য।
        //
        //
        //
        //
        //
        unsafe {
            // কাঁচা পয়েন্টার ব্যবহার করে বাউন্ড চেক এড়িয়ে চলুন।
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// একই কিতে স্থির হওয়া স্লাইসের শেষের দিকে পর পরের প্রথম উপাদানগুলি ছাড়াও সমস্ত সরান।
    ///
    ///
    /// দুটি টুকরা ফেরত দেয়।প্রথমটিতে কোনও ক্রমাগত পুনরাবৃত্তি উপাদান নেই।
    /// দ্বিতীয়টিতে কোনও নির্দিষ্ট ক্রমে সমস্ত নকল রয়েছে।
    ///
    /// যদি স্লাইসটি বাছাই করা হয় তবে প্রথম ফিরে আসা স্লাইসে কোনও নকল নেই।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// স্লাইসটি জায়গাটিতে এমনভাবে আবর্তিত করে যাতে স্লাইসের প্রথম `mid` উপাদানগুলি সর্বশেষে চলে যায় যখন শেষ `self.len() - mid` উপাদানগুলি সামনে যায়।
    /// `rotate_left` কল করার পরে, সূচী `mid` এর পূর্বে উপাদানটি স্লাইসে প্রথম উপাদান হয়ে উঠবে।
    ///
    /// # Panics
    ///
    /// যদি `mid` স্লাইসের দৈর্ঘ্যের চেয়ে বেশি হয় তবে এই ফাংশনটি panic করবে।দ্রষ্টব্য যে `mid == self.len()` _not_ panic করে এবং এটি কোনও অপ-রোটেশন আবর্তন।
    ///
    /// # Complexity
    ///
    /// রৈখিক লাগে (`self.len()`) সময়ে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// একটি সাব্লাইস ঘোরানো:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // নিরাপদ: এক্স01 এক্সের পরিসীমা তুচ্ছ
        // `ptr_rotate` দ্বারা প্রয়োজনীয়, পড়া এবং লেখার জন্য বৈধ।
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// স্লাইসটি জায়গাটিতে এমনভাবে আবর্তিত করে যাতে স্লাইসের প্রথম `self.len() - k` উপাদানগুলি সর্বশেষে চলে যায় যখন শেষ `k` উপাদানগুলি সামনে যায়।
    /// `rotate_right` কল করার পরে, সূচী `self.len() - k` এর পূর্বে উপাদানটি স্লাইসে প্রথম উপাদান হয়ে উঠবে।
    ///
    /// # Panics
    ///
    /// যদি `k` স্লাইসের দৈর্ঘ্যের চেয়ে বেশি হয় তবে এই ফাংশনটি panic করবে।দ্রষ্টব্য যে `k == self.len()` _not_ panic করে এবং এটি কোনও অপ-রোটেশন আবর্তন।
    ///
    /// # Complexity
    ///
    /// রৈখিক লাগে (`self.len()`) সময়ে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// একটি সাব্লাইস ঘোরান:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // নিরাপদ: এক্স01 এক্সের পরিসীমা তুচ্ছ
        // `ptr_rotate` দ্বারা প্রয়োজনীয়, পড়া এবং লেখার জন্য বৈধ।
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ক্লোন করে উপাদানগুলিতে `self` পূরণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// বারবার ক্লোজার কল করে ফিরে আসা উপাদানগুলির সাথে `self` পূরণ করুন।
    ///
    /// এই পদ্ধতিটি নতুন মান তৈরি করতে ক্লোজার ব্যবহার করে।আপনি যদি একটি প্রদত্ত মান [`Clone`] এর চেয়ে পছন্দ করেন তবে [`fill`] ব্যবহার করুন।
    /// যদি মানগুলি উত্পন্ন করতে আপনি [`Default`] trait ব্যবহার করতে চান তবে আপনি [`Default::default`] টি যুক্তি হিসাবে পাস করতে পারেন।
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` থেকে উপাদানগুলিকে `self` এ অনুলিপি করে।
    ///
    /// `src` দৈর্ঘ্য অবশ্যই `self` এর সমান হওয়া উচিত।
    ///
    /// যদি `T` `Copy` প্রয়োগ করে তবে এটি [`copy_from_slice`] ব্যবহার করার জন্য আরও পারফরম্যান্স হতে পারে।
    ///
    /// # Panics
    ///
    /// দুটি ফালিগুলির দৈর্ঘ্য পৃথক থাকলে এই ফাংশনটি panic করবে।
    ///
    /// # Examples
    ///
    /// এক স্লাইস থেকে অন্য উপাদানকে দুটি উপাদানকে ক্লোন করা:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // টুকরোগুলি একই দৈর্ঘ্য হতে হবে, আমরা উত্স স্লাইস চারটি উপাদান থেকে দুটি টুকরা।
    /// // এটি panic হবে যদি আমরা এটি না করি।
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// জেড 0 রিস্ট0 জেড বলবত করে যে কোনও নির্দিষ্ট সুযোগের কোনও নির্দিষ্ট অংশের ডেটার কোনও পরিবর্তনীয় রেফারেন্স ছাড়াই কেবলমাত্র একটি পরিবর্তনীয় রেফারেন্স থাকতে পারে।
    /// এর কারণে, একক টুকরোতে `clone_from_slice` ব্যবহার করার চেষ্টা করার ফলে একটি সংকলন ব্যর্থ হবে:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// এটির কাজ করার জন্য, আমরা একটি স্লাইস থেকে দুটি স্বতন্ত্র সাব-স্লাইস তৈরি করতে [`split_at_mut`] ব্যবহার করতে পারি:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// একটি মেমকি ব্যবহার করে `src` থেকে সমস্ত উপাদানকে `self` এ অনুলিপি করে।
    ///
    /// `src` দৈর্ঘ্য অবশ্যই `self` এর সমান হওয়া উচিত।
    ///
    /// যদি `T` `Copy` প্রয়োগ না করে তবে [`clone_from_slice`] ব্যবহার করুন।
    ///
    /// # Panics
    ///
    /// দুটি ফালিগুলির দৈর্ঘ্য পৃথক থাকলে এই ফাংশনটি panic করবে।
    ///
    /// # Examples
    ///
    /// একটি স্লাইস থেকে অন্য উপাদান দুটি অনুলিপি করা:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // টুকরোগুলি একই দৈর্ঘ্য হতে হবে, আমরা উত্স স্লাইস চারটি উপাদান থেকে দুটি টুকরা।
    /// // এটি panic হবে যদি আমরা এটি না করি।
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// জেড 0 রিস্ট0 জেড বলবত করে যে কোনও নির্দিষ্ট সুযোগের কোনও নির্দিষ্ট অংশের ডেটার কোনও পরিবর্তনীয় রেফারেন্স ছাড়াই কেবলমাত্র একটি পরিবর্তনীয় রেফারেন্স থাকতে পারে।
    /// এর কারণে, একক টুকরোতে `copy_from_slice` ব্যবহার করার চেষ্টা করার ফলে একটি সংকলন ব্যর্থ হবে:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// এটির কাজ করার জন্য, আমরা একটি স্লাইস থেকে দুটি স্বতন্ত্র সাব-স্লাইস তৈরি করতে [`split_at_mut`] ব্যবহার করতে পারি:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // কল সাইটটি ফুলে না যাওয়ার জন্য panic কোড পাথটি একটি শীতল ফাংশনে রাখা হয়েছিল।
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // নিরাপদ: `self` সংজ্ঞা অনুসারে `self.len()` উপাদানগুলির জন্য বৈধ, এবং `src` ছিল
        // একই দৈর্ঘ্য আছে কিনা তা পরীক্ষা করা হয়েছে।
        // স্লাইসগুলি ওভারল্যাপ করতে পারে না কারণ পরিবর্তনীয় উল্লেখগুলি একচেটিয়া।
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// মেমোমোভ ব্যবহার করে স্লাইসের এক অংশ থেকে উপাদানগুলির নিজের একটি অংশে অনুলিপি করে।
    ///
    /// `src` থেকে অনুলিপি করতে `self` এর মধ্যে ব্যাপ্তি।
    /// `dest` অনুলিপি করতে `self` এর মধ্যে সীমাটির সূচনা সূচক যা `src` এর সমান দৈর্ঘ্য হবে।
    /// দুটি রেঞ্জ ওভারল্যাপ হতে পারে।
    /// দুটি রেঞ্জের প্রান্তটি অবশ্যই `self.len()` এর চেয়ে কম বা সমান হতে হবে।
    ///
    /// # Panics
    ///
    /// এই ফাংশনটি panic করবে যদি উভয় ক্ষেত্রেই স্লাইসের প্রান্ত ছাড়িয়ে যায়, বা যদি `src` এর সমাপ্তি শুরুর আগে হয়।
    ///
    ///
    /// # Examples
    ///
    /// এক স্লাইসের মধ্যে চারটি বাইট অনুলিপি করা:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // নিরাপদ: এক্স00 এক্স এর শর্তাদি সমস্ত উপরে পরীক্ষা করা হয়েছে,
        // `ptr::add` এর জন্য যেমন আছে।
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` এর সাথে `self` এর সমস্ত উপাদানকে অদলবদল করে।
    ///
    /// `other` দৈর্ঘ্য অবশ্যই `self` এর সমান হওয়া উচিত।
    ///
    /// # Panics
    ///
    /// দুটি ফালিগুলির দৈর্ঘ্য পৃথক থাকলে এই ফাংশনটি panic করবে।
    ///
    /// # Example
    ///
    /// টুকরো জুড়ে দুটি উপাদান অদলবদল করা:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// জেড 0 রিস্ট0 জেড বলবত করে যে কোনও নির্দিষ্ট স্কোপে কেবলমাত্র ডেটার একটি নির্দিষ্ট অংশের জন্য কেবলমাত্র একটি পরিবর্তনীয় রেফারেন্স থাকতে পারে।
    ///
    /// এর কারণে, একক টুকরোতে `swap_with_slice` ব্যবহার করার চেষ্টা করার ফলে একটি সংকলন ব্যর্থ হবে:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// এটির কাজ করার জন্য, আমরা একটি স্লাইস থেকে দুটি স্বতন্ত্র মিউটেবল সাব-স্লাইস তৈরি করতে [`split_at_mut`] ব্যবহার করতে পারি:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // নিরাপদ: `self` সংজ্ঞা অনুসারে `self.len()` উপাদানগুলির জন্য বৈধ, এবং `src` ছিল
        // একই দৈর্ঘ্য আছে কিনা তা পরীক্ষা করা হয়েছে।
        // স্লাইসগুলি ওভারল্যাপ করতে পারে না কারণ পরিবর্তনীয় উল্লেখগুলি একচেটিয়া।
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` এর জন্য মাঝারি এবং পিছনের দিকের দৈর্ঘ্য গণনা করার কাজ।
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // আমরা `rest` সম্পর্কে যা করতে যাব তা হ'ল আমরা সর্বনিম্ন সংখ্যক `T puts এর মধ্যে কতগুলি` U`s রাখতে পারি put
        //
        // এবং এই জাতীয় প্রতিটি "multiple" এর জন্য আমাদের কতগুলি। T`s প্রয়োজন।
        //
        // উদাহরণস্বরূপ T=u8 U=u16 বিবেচনা করুন।তারপরে আমরা 1 টি 2 এস তে রাখতে পারি।সরল।
        // এখন, উদাহরণস্বরূপ একটি কেস বিবেচনা করুন যেখানে আকার_ের: :<T>=16, আকার_::::<U>24</u>
        // আমরা এক্স 3 এক্স স্লাইসে প্রতি 3 এস এর জায়গায় 2 আমাদের রাখতে পারি।
        // আরও কিছুটা জটিল।
        //
        // এটি গণনা করার সূত্রটি হ'ল:
        //
        // আমাদের=এক্স 100 এক্স/আকার_: :::<U>টিএস=এক্স01 এক্স/আকার_::</u><T>
        //
        // প্রসারিত এবং সরলীকৃত:
        //
        // আমাদের=আকার_: :<T>/এক্স01 এক্স টিএস=আকার_::::এক্স X <U>এক্স</u>
        //
        // ভাগ্যিস যেহেতু এগুলি সমস্ত ধ্রুবক-মূল্যায়ন করা হয় ... এখানে কার্য সম্পাদন গুরুত্বপূর্ণ নয়!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // পুনরুক্তি স্টিনের অ্যালগরিদমটি আমাদের এখনও এই `const fn` করা উচিত (এবং যদি আমরা করি তবে পুনরাবৃত্তির অ্যালগরিদমকে ফিরিয়ে নেওয়া উচিত) কারণ এই সমস্ত কনস্ট্যাভাল করার জন্য এলএলভিএমের উপর নির্ভর করা ঠিক আছে ... এটি আমাকে অস্বস্তিকর করে তোলে makes
            //
            //

            // নিরাপদ: `a` এবং `b` শূন্য-না মান হিসাবে চেক করা হয়।
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // বি থেকে 2 এর সমস্ত কারণগুলি সরান
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // নিরাপদ: এক্স 100 এক্স শূন্য নয় বলে চেক করা হয়েছে।
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // এই জ্ঞান দিয়ে সজ্জিত, আমরা খুঁজে পেতে পারি যে আমরা কতগুলি ফিট করতে পারি!
        let us_len = self.len() / ts * us;
        // এবং কতগুলি `T`s পিছনের টুকরোতে থাকবে!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// স্লাইসকে অন্য ধরণের স্লাইসে ট্রান্সমিট করুন, ধরণের প্রান্তিককরণ বজায় রাখা নিশ্চিত করে।
    ///
    /// এই পদ্ধতিটি স্লাইসটিকে তিনটি পৃথক টুকরোতে বিভক্ত করে: উপসর্গ, সঠিকভাবে এক নতুন প্রকারের মাঝারি টুকরোটি এবং প্রত্যয় টুকরাটি।
    /// পদ্ধতিটি কোনও প্রদত্ত প্রকার এবং ইনপুট স্লাইসের জন্য মাঝের স্লাইসকে সর্বোচ্চ দৈর্ঘ্যকে সম্ভব করে তুলতে পারে তবে কেবলমাত্র আপনার অ্যালগরিদমের কার্যকারিতা তার উপর নির্ভর করবে, তার সঠিকতা নয়।
    ///
    /// সমস্ত ইনপুট ডেটা উপসর্গ বা প্রত্যয় স্লাইস হিসাবে ফেরত দেওয়া অনুমোদিত is
    ///
    /// এই পদ্ধতির কোনও উদ্দেশ্য নেই যখন ইনপুট উপাদান `T` বা আউটপুট উপাদান `U` হয় শূন্য আকারের এবং কোনও কিছু ভাগ না করে মূল ফালিটি ফিরিয়ে দেবে।
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি মূলত ফিরে আসা মিডল স্লাইসের উপাদানগুলির সাথে সম্মত `transmute` X, সুতরাং `transmute::<T, U>` সম্পর্কিত সমস্ত সাধারণ ক্যাভ্যাটগুলি এখানেও প্রয়োগ হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // নোট করুন যে এই ফাংশনটির বেশিরভাগ স্থির-মূল্যায়ন করা হবে,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // জেডএসটি বিশেষভাবে হ্যান্ডেল করুন যা হ'ল-এগুলি একেবারেই হ্যান্ডেল করবেন না।
            return (self, &[], &[]);
        }

        // প্রথমত, প্রথম এবং দ্বিতীয় স্লাইসের মধ্যে আমরা কী বিন্দুতে বিভক্ত হই তা সন্ধান করুন।
        // এক্স 100 এক্স দিয়ে সহজ।
        let ptr = self.as_ptr();
        // নিরাপদ: বিস্তারিত সুরক্ষা মন্তব্যের জন্য `align_to_mut` পদ্ধতিটি দেখুন।
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // নিরাপদ: এখন `rest` অবশ্যই স্পষ্টভাবে প্রান্তীকৃত, সুতরাং `from_raw_parts` নীচে ঠিক আছে,
            // যেহেতু কলার গ্যারান্টি দেয় যে আমরা `T` কে `T` এ নিরাপদে স্থানান্তর করতে পারি।
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// স্লাইসকে অন্য ধরণের স্লাইসে ট্রান্সমিট করুন, ধরণের প্রান্তিককরণ বজায় রাখা নিশ্চিত করে।
    ///
    /// এই পদ্ধতিটি স্লাইসটিকে তিনটি পৃথক টুকরোতে বিভক্ত করে: উপসর্গ, সঠিকভাবে এক নতুন প্রকারের মাঝারি টুকরোটি এবং প্রত্যয় টুকরাটি।
    /// পদ্ধতিটি কোনও প্রদত্ত প্রকার এবং ইনপুট স্লাইসের জন্য মাঝের স্লাইসকে সর্বোচ্চ দৈর্ঘ্যকে সম্ভব করে তুলতে পারে তবে কেবলমাত্র আপনার অ্যালগরিদমের কার্যকারিতা তার উপর নির্ভর করবে, তার সঠিকতা নয়।
    ///
    /// সমস্ত ইনপুট ডেটা উপসর্গ বা প্রত্যয় স্লাইস হিসাবে ফেরত দেওয়া অনুমোদিত is
    ///
    /// এই পদ্ধতির কোনও উদ্দেশ্য নেই যখন ইনপুট উপাদান `T` বা আউটপুট উপাদান `U` হয় শূন্য আকারের এবং কোনও কিছু ভাগ না করে মূল ফালিটি ফিরিয়ে দেবে।
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি মূলত ফিরে আসা মিডল স্লাইসের উপাদানগুলির সাথে সম্মত `transmute` X, সুতরাং `transmute::<T, U>` সম্পর্কিত সমস্ত সাধারণ ক্যাভ্যাটগুলি এখানেও প্রয়োগ হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // নোট করুন যে এই ফাংশনটির বেশিরভাগ স্থির-মূল্যায়ন করা হবে,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // জেডএসটি বিশেষভাবে হ্যান্ডেল করুন যা হ'ল-এগুলি একেবারেই হ্যান্ডেল করবেন না।
            return (self, &mut [], &mut []);
        }

        // প্রথমত, প্রথম এবং দ্বিতীয় স্লাইসের মধ্যে আমরা কী বিন্দুতে বিভক্ত হই তা সন্ধান করুন।
        // এক্স 100 এক্স দিয়ে সহজ।
        let ptr = self.as_ptr();
        // নিরাপত্তা: এখানে আমরা নিশ্চিত করছি যে আমরা ইউ এর জন্য প্রান্তিকিত পয়েন্টার ব্যবহার করব
        // পদ্ধতি বাকি।এটি ইউ এর জন্য লক্ষ্যযুক্ত প্রান্তিককরণের সাথে&[T] এ পয়েন্টারটি পাস করার মাধ্যমে করা হয়
        // `crate::ptr::align_offset` এটি সঠিকভাবে প্রান্তিককরণ এবং বৈধ পয়েন্টার `ptr` (এটি `self` এর একটি রেফারেন্স থেকে আসে) এবং দুটি আকারের একটি আকারের (যেহেতু এটি ইউ এর জন্য প্রান্তিককরণ থেকে আসে) এর সুরক্ষার সীমাবদ্ধতাগুলি পূরণ করে ডাকা হয়।
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // আমরা এর পরে আর `rest` ব্যবহার করতে পারি না, এটির ওরফে `mut_ptr` অকার্যকর করে দেবে!নিরাপদ: `align_to` এর জন্য মন্তব্যগুলি দেখুন।
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// এই স্লাইসের উপাদানগুলি বাছাই করা হয়েছে কিনা তা পরীক্ষা করে দেখুন।
    ///
    /// এটি হ'ল প্রতিটি উপাদান `a` এবং এর নিম্নলিখিত উপাদান `b` এর জন্য, `a <= b` অবশ্যই রাখা উচিত।যদি স্লাইসটি একেবারে শূন্য বা একটি উপাদান দেয় তবে `true` ফিরে আসে is
    ///
    /// দ্রষ্টব্য যে `Self::Item` যদি কেবলমাত্র `PartialOrd` হয় তবে `Ord` নয়, উপরোক্ত সংজ্ঞাটি সূচিত করে যে এই ক্রিয়াকলাপটি যদি কোনও দুটি পরপর আইটেমের তুলনা না করে থাকে তবে এই ফাংশনটি `PartialOrd` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// এই স্লাইসের উপাদানগুলি প্রদত্ত তুলনামূলক ফাংশনটি ব্যবহার করে বাছাই করা হয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// `PartialOrd::partial_cmp` ব্যবহার করার পরিবর্তে, এই ফাংশনটি দুটি উপাদানের ক্রম নির্ধারণ করতে প্রদত্ত `compare` ফাংশনটি ব্যবহার করে।
    /// তা ছাড়া এটি [`is_sorted`] এর সমতুল্য;আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// এই স্লাইসের উপাদানগুলি প্রদত্ত কী নিষ্কাশন ফাংশনটি ব্যবহার করে বাছাই করা হয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// স্লাইসের উপাদানগুলি সরাসরি তুলনা করার পরিবর্তে, এই ফাংশনটি `f` দ্বারা নির্ধারিত উপাদানগুলির কীগুলির সাথে তুলনা করে।
    /// তা ছাড়া এটি [`is_sorted`] এর সমতুল্য;আরও তথ্যের জন্য এর ডকুমেন্টেশন দেখুন।
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// প্রদত্ত প্রিকিকেট (দ্বিতীয় পার্টিশনের প্রথম উপাদানটির সূচক) অনুসারে পার্টিশন পয়েন্টের সূচক ফেরত দেয়।
    ///
    /// স্লাইস প্রদত্ত ভবিষ্যদ্বাণী অনুসারে বিভাজন বলে মনে করা হয়।
    /// এর অর্থ হ'ল যে সমস্ত উপাদানগুলির জন্য ভবিষ্যদ্বাণীকটি সত্য প্রত্যাশা তা স্লাইসের শুরুতে এবং সমস্ত উপাদান যার জন্য ভবিষ্যদ্বাণীকটি মিথ্যা বলে প্রত্যাশিত হয় শেষে the
    ///
    /// উদাহরণস্বরূপ, [7, 15, 3, 5, 4, 12, 6] হ'ল প্রিডিকেট x% 2!=0 এর অধীনে একটি বিভাজনযুক্ত (সমস্ত বিজোড় সংখ্যা শুরুতে, সমস্ত এমনকি শেষ পর্যন্ত))
    ///
    /// যদি এই স্লাইসটি বিভাজনযুক্ত না হয় তবে প্রত্যাবর্তিত ফলাফল অনির্দিষ্ট এবং অর্থহীন, কারণ এই পদ্ধতিটি এক ধরণের বাইনারি অনুসন্ধান করে।
    ///
    /// এক্স01 এক্স, এক্স02 এক্স এবং এক্স 100 এক্সও দেখুন।
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // সুরক্ষা: যখন এক্স 100 এক্স, `left <= mid < right`.
            // সুতরাং `left` সর্বদা বৃদ্ধি পায় এবং `right` সর্বদা হ্রাস পায় এবং এর মধ্যে দুটিই নির্বাচিত হয় isউভয় ক্ষেত্রেই `left <= right` সন্তুষ্ট।অতএব যদি `left < right` একটি পদক্ষেপে থাকে তবে `left <= right` পরবর্তী পদক্ষেপে সন্তুষ্ট।
            //
            // সুতরাং যতক্ষণ না `left != right`, এক্স01 এক্স সন্তুষ্ট এবং যদি এই ক্ষেত্রে `0 <= mid < len` ও সন্তুষ্ট থাকে।
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: আমাদের তাদের স্পষ্টভাবে একই দৈর্ঘ্যে টুকরো টুকরো করা দরকার
        // অপ্টিমাইজারের পক্ষে এলিড সীমানা পরীক্ষা করা সহজ করে তুলতে।
        // তবে যেহেতু এটির উপর নির্ভর করা যায় না আমাদের টি: অনুলিপিটির জন্যও স্পষ্ট বিশেষীকরণ রয়েছে।
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// একটি খালি স্লাইস তৈরি করে।
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// একটি পরিবর্তনীয় খালি স্লাইস তৈরি করে।
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// স্লাইসগুলির প্যাটার্নগুলি, বর্তমানে কেবলমাত্র `strip_prefix` এবং `strip_suffix` দ্বারা ব্যবহৃত।
/// জেডফিউচার0 জেড পয়েন্টে, আমরা আশা করি `core::str::Pattern` (যা লেখার সময় `str` এর মধ্যে সীমাবদ্ধ ছিল) কে স্লাইস করে সাধারণ করা হবে এবং তারপরে এই জেড 0 ট্রাইট0 জেড প্রতিস্থাপন বা বিলুপ্ত করা হবে।
///
pub trait SlicePattern {
    /// স্লাইসের উপাদানটির ধরণটি মিলছে।
    type Item;

    /// বর্তমানে, `SlicePattern` এর গ্রাহকদের একটি ফালি প্রয়োজন need
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}