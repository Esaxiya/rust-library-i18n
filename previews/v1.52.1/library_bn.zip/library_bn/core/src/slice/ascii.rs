//! ASCII `[u8]` এ অপারেশন।

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// এই স্লাইসের সমস্ত বাইট ASCII সীমার মধ্যে রয়েছে কিনা তা পরীক্ষা করে দেখুন।
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// দুটি স্লাইস একটি ASCII কেস-সংবেদনশীল মিল match
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` হিসাবে একই, কিন্তু অস্থায়ী বরাদ্দ এবং অনুলিপি ছাড়াই।
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// এই স্লাইসটিকে তার ASCII আপার কেস ইন-প্লেসে রূপান্তর করে।
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন বড় মানের ফেরত দিতে, [`to_ascii_uppercase`] ব্যবহার করুন।
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// এই স্লাইসটিকে তার ASCII লোয়ার কেস ইন-প্লেসে রূপান্তর করে।
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন নিম্নতর মানটি ফেরত দিতে, [`to_ascii_lowercase`] ব্যবহার করুন।
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` শব্দটির কোনও বাইট যদি ননাসেই (>=128) হয় তবে `true` প্রদান করে।
/// `../str/mod.rs` থেকে স্নারফিড, যা utf8 বৈধতার জন্য অনুরূপ কিছু করে।
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// অপ্টিমাইজড এএসসিআইআই পরীক্ষা যা বাইট-এ-এ-টাইম অপারেশনগুলির পরিবর্তে (যখন সম্ভব হবে) ব্যবহারের সময়ে-সময়ে-সময়ে-ব্যবহার করবে।
///
/// আমরা এখানে যে অ্যালগরিদম ব্যবহার করি তা বেশ সহজ।যদি এক্স 100 এক্স খুব ছোট হয়, আমরা কেবল প্রতিটি বাইট পরীক্ষা করি এবং এটি দিয়ে সম্পন্ন করব।অন্যথায়:
///
/// - স্বাক্ষরবিহীন লোড সহ প্রথম শব্দটি পড়ুন।
/// - পয়েন্টারটি সারিবদ্ধ করুন, প্রান্তিককরণযুক্ত লোডগুলি শেষ না হওয়া পর্যন্ত পরবর্তী শব্দগুলি পড়ুন।
/// - আন-স্বাক্ষরযুক্ত লোড সহ `s` থেকে শেষ `usize` পড়ুন।
///
/// এই লোডগুলির মধ্যে যদি কোনও এমন কিছু উত্পাদন করে যার জন্য `contains_nonascii` (above) সত্য প্রত্যাবর্তন করে, তবে আমরা জানি উত্তরটি মিথ্যা।
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // আমরা যদি শব্দ-সময়ে-সময়ে প্রয়োগ থেকে কিছু না পাই তবে স্কেলার লুপে ফিরে আসি।
    //
    // আমরা এটি আর্কিটেকচারের জন্যও করি যেখানে `size_of::<usize>()` `usize` এর জন্য পর্যাপ্ত প্রান্তিককরণ নয়, কারণ এটি একটি অদ্ভুত edge কেস।
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // আমরা সর্বদা সর্বনাশযুক্ত প্রথম শব্দটি পড়ে থাকি যার অর্থ `align_offset`
    // 0, সারিবদ্ধ পড়ার জন্য আমরা আবার একই মানটি পড়তে চাই।
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // নিরাপত্তা: আমরা উপরে `len < USIZE_SIZE` যাচাই করেছি।
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // আমরা উপরে কিছুটা নিখুঁতভাবে পরীক্ষা করে দেখেছি।
    // দ্রষ্টব্য যে `offset_to_aligned` হয় হয় `align_offset` বা `USIZE_SIZE`, উভয়ই উপরে সুস্পষ্টভাবে পরীক্ষা করা হয়েছে।
    //
    debug_assert!(offset_to_aligned <= len);

    // নিরাপদ: word_ptr হ'ল (সঠিকভাবে সংযুক্ত) ustr ptr যা আমরা পড়তে ব্যবহার করি
    // স্লাইস মাঝারি অংশ।
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` লুপ এন্ড চেকগুলির জন্য ব্যবহৃত `word_ptr` এর বাইট সূচক।
    let mut byte_pos = offset_to_aligned;

    // পরানোইয়া প্রান্তিককরণ সম্পর্কে পরীক্ষা করে, যেহেতু আমরা আন-স্বাক্ষরযুক্ত লোডগুলি একগুচ্ছ করতে চলেছি।
    // বাস্তবে `align_offset` এ বাগ বাদ দিয়ে অসম্ভব হওয়া উচিত।
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // পরবর্তী প্রান্তিক শব্দ না হওয়া পর্যন্ত পরবর্তী শব্দের পাঠ করুন, লেজ চেকের পরে নিজেই শেষ প্রান্তিককরণ শব্দটি বাদ দিয়ে, লেজটি সর্বদা একটি অতিরিক্ত X0branch0Z `byte_pos == len` এর ক্ষেত্রে সর্বদা এক X01 এক্স থাকে তা নিশ্চিত করতে।
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // স্যানিটি পরীক্ষা করে দেখুন যে পাঠটি সীমানায় রয়েছে
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // এবং এটি `byte_pos` সম্পর্কে আমাদের অনুমানগুলি ধরে রাখে।
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // নিরাপত্তা: আমরা জানি `word_ptr` সঠিকভাবে প্রান্তিক করা হয়েছে (কারণ
        // `align_offset`), এবং আমরা জানি যে আমাদের কাছে `word_ptr` এবং শেষের মধ্যে পর্যাপ্ত বাইট রয়েছে
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // নিরাপত্তা: আমরা জানি যে `byte_pos <= len - USIZE_SIZE`, যার অর্থ
        // এই এক্স 100 এক্স এর পরে এক্স01 এক্স সর্বাধিক এক-অতীত-শেষ হবে।
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // প্রকৃতপক্ষে কেবলমাত্র একটি `usize` বাকি আছে তা নিশ্চিত করার জন্য স্যানিটি চেক করুন।
    // এটি আমাদের লুপের শর্ত দ্বারা গ্যারান্টিযুক্ত হওয়া উচিত।
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // নিরাপদ: এটি `len >= USIZE_SIZE` এর উপর নির্ভর করে, যা আমরা শুরুতে যাচাই করি।
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}