// আসল বাস্তবায়ন rust-memchr থেকে নেওয়া।
// কপিরাইট 2015 অ্যান্ড্রু গ্যালান্ট, bluss এবং নিকোলাস কোচ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// কাটা কাটা ব্যবহার করুন।
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `true` এক্সটিতে কোনও শূন্য বাইট থাকলে `true` প্রদান করে।
///
/// *ম্যাটার্স কম্পিউটেশনাল*, জে আরেন্ড্ট থেকে:
///
/// "ধারণাটি হ'ল প্রতিটি বাইট থেকে একটিকে বিয়োগ করা এবং তারপরে বাইটগুলি সন্ধান করা যেখানে orrowণটি সমস্ত উপায়ে সবচেয়ে গুরুত্বপূর্ণভাবে প্রচার করেছিল
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` এ বাইট `x` এর সাথে মেলে প্রথম সূচকটি প্রদান করে।
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ছোট টুকরা জন্য দ্রুত পথ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // একবারে দু'টি `usize` শব্দ পড়ে একক বাইট মানের জন্য স্ক্যান করুন।
    //
    // তিন ভাগে `text` বিভক্ত করুন
    // - প্রথম শব্দের পাঠ্যটিতে প্রান্তিক ঠিকানা আগে, স্বাক্ষরবিহীন প্রাথমিক অংশ
    // - শরীর, একবারে 2 শব্দ দ্বারা স্ক্যান
    // - শেষের অংশটি, <2 শব্দের আকার

    // একটি সারিবদ্ধ সীমানা অনুসন্ধান করুন
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // পাঠ্যের মূল অংশটি অনুসন্ধান করুন
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // নিরাপত্তা: ততক্ষণের পূর্বসূরিটি কমপক্ষে 2 * usize_bytes এর দূরত্বের গ্যারান্টি দেয়
        // অফসেট এবং স্লাইসের শেষের মধ্যে।
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // যদি কোনও ম্যাচিং বাইট থাকে তবে বিরতি দিন
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // বড লুপটি থামার পরে বিন্যাসটি সন্ধান করুন।
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` এ বাইট `x` এর সাথে শেষের সূচকটি প্রদান করে।
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // একবারে দু'টি `usize` শব্দ পড়ে একক বাইট মানের জন্য স্ক্যান করুন।
    //
    // তিন ভাগে `text` বিভক্ত করুন:
    // - পাঠ্যবিহীন লেজ, সর্বশেষ শব্দের শেষে পাঠ্য প্রান্তিক ঠিকানা,
    // - শরীর, একবারে 2 টি শব্দ দ্বারা স্ক্যান,
    // - প্রথম বাকী বাইটস, <2 শব্দের আকার।
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // আমরা এটি উপসর্গ এবং প্রত্যয়টির দৈর্ঘ্য পেতে কেবল কল করি।
        // মাঝখানে আমরা সবসময় একসাথে দুটি খণ্ড প্রক্রিয়া করি।
        // নিরাপদ: X001 দ্বারা পরিচালিত আকারের পার্থক্য বাদে `[u8]` কে `[usize]` এ রূপান্তর করা নিরাপদ।
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // পাঠ্যের মূল অংশটি অনুসন্ধান করুন, নিশ্চিত করুন যে আমরা মিনি_অ্যালাইন্ট_অফসেটটি অতিক্রম করব না।
    // অফসেট সর্বদা সারিবদ্ধ থাকে, সুতরাং কেবলমাত্র `>` পরীক্ষা করা যথেষ্ট এবং সম্ভাব্য ওভারফ্লো এড়ানো যায়।
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // সুরক্ষা: অফসেটটি লেন থেকে শুরু হবে, suffix.len(), যতক্ষণ না এর চেয়ে বেশি is
        // min_aligned_offset (prefix.len()) অবশিষ্ট দূরত্ব কমপক্ষে 2 * অংশ_বাইটস।
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ম্যাচিং বাইট থাকলে ব্রেক করুন।
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // বডি লুপটি থামার আগে বিন্যাসটি সন্ধান করুন।
    text[..offset].iter().rposition(|elt| *elt == x)
}