#![stable(feature = "duration_core", since = "1.25.0")]

//! অস্থায়ী পরিমাণ
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // উভয় ঘোষণা সমান
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// একটি টাইম স্প্যানের প্রতিনিধিত্ব করতে একটি `Duration` প্রকার, সাধারণত সিস্টেম টাইমআউটগুলির জন্য ব্যবহৃত হয়।
///
/// প্রতিটি এক্স 100 এক্স পুরো সংখ্যায় সেকেন্ড এবং ন্যানোসেকেন্ডগুলিতে প্রতিনিধিত্বমূলক একটি ভগ্নাংশ অংশ নিয়ে গঠিত।
/// যদি অন্তর্নিহিত সিস্টেম ন্যানোসেকেন্ড-স্তরের যথাযথতা সমর্থন করে না, তবে একটি সিস্টেমের সময়সীমা বেঁধে দেওয়া API গুলি সাধারণত ন্যানোসেকেন্ডের সংখ্যাকে বাড়িয়ে তুলবে।
///
/// [`সময়কাল] গুলি [`Add`], [`Sub`], এবং অন্যান্য [`ops`] traits সহ অনেকগুলি সাধারণ traits বাস্তবায়ন করে।এটি শূন্য দৈর্ঘ্যের `Duration` ফিরিয়ে [`Default`] প্রয়োগ করে।
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` মানগুলি বিন্যাস করা
///
/// `Duration` ইচ্ছাকৃতভাবে একটি `Display` ইমপ্লিট নেই, কারণ মানব পাঠযোগ্যতার জন্য বিভিন্ন সময়ের বিভিন্ন বিন্যাস করার বিভিন্ন উপায় রয়েছে।
/// `Duration` একটি `Debug` ইমপ্লিট সরবরাহ করে যা মানটির সম্পূর্ণ নির্ভুলতা দেখায়।
///
/// `Debug` আউটপুটটি মাইক্রোসেকেন্ডগুলির জন্য নন-এসএসআইআই এক্স01 এক্স প্রত্যয় ব্যবহার করে।
/// যদি আপনার প্রোগ্রামের আউটপুটটি এমন প্রসঙ্গে উপস্থিত হতে পারে যা পুরো ইউনিকোড সামঞ্জস্যের উপর নির্ভর করতে পারে না, আপনি নিজে `Duration` অবজেক্টগুলিকে ফর্ম্যাট করতে চাইতে পারেন বা এটি করতে crate ব্যবহার করতে পারেন।
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // সর্বদা 0 <=ন্যানোস <NANOS_PER_SEC
}

impl Duration {
    /// এক সেকেন্ড সময়কাল।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// এক মিলিসেকেন্ডের সময়কাল।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// একটি মাইক্রোসেকেন্ডের সময়কাল।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// এক ন্যানোসেকেন্ডের সময়কাল।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// শূন্য সময়কাল।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// সর্বাধিক সময়কাল।
    ///
    /// এটি 584,942,417,355 বছরের সময়কালের প্রায় সমান।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// সম্পূর্ণ সেকেন্ডের অতিরিক্ত সংখ্যা এবং অতিরিক্ত ন্যানোসেকেন্ডগুলি থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// ন্যানোসেকেন্ডের সংখ্যা যদি 1 বিলিয়ন (এক সেকেন্ডে ন্যানোসেকেন্ডের সংখ্যা) এর বেশি হয়, তবে এটি প্রদত্ত সেকেন্ডগুলিতে চলে যাবে।
    ///
    ///
    /// # Panics
    ///
    /// যদি ন্যানোসেকেন্ডগুলি থেকে বহন করা সেকেন্ডের কাউন্টারটি উপচে পড়ে তবে এই নির্মাতা panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// সম্পূর্ণ সেকেন্ডের নির্দিষ্ট নম্বর থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// নির্দিষ্ট সংখ্যক মিলিসেকেন্ড থেকে একটি নতুন `Duration` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// নির্দিষ্ট সংখ্যক মাইক্রোসেকেন্ডগুলি থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// ন্যানোসেকেন্ডের নির্দিষ্ট নম্বর থেকে একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// যদি এই `Duration` সময় ব্যয় না করে তবে সত্য হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// এই `Duration` দ্বারা অন্তর্ভুক্ত হওয়া _whole_ সেকেন্ডের সংখ্যাটি প্রদান করে।
    ///
    /// প্রত্যাবর্তিত মানটিতে পিরিয়ডের ভগ্নাংশ (nanosecond) অংশ অন্তর্ভুক্ত নয়, যা [`subsec_nanos`] ব্যবহার করে প্রাপ্ত হতে পারে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` দ্বারা উপস্থাপিত মোট সেকেন্ডের সংখ্যা নির্ধারণ করতে, [`subsec_nanos`] এর সাথে একত্রে `as_secs` ব্যবহার করুন:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// পুরো X মিলি সেকেন্ডে, এই `Duration` এর ভগ্নাংশটি প্রদান করে।
    ///
    /// এই পদ্ধতিটি **নয়** সময়কাল দৈর্ঘ্যটি মিলিসেকেন্ড দ্বারা প্রতিনিধিত্ব করে না return
    /// প্রত্যাবর্তিত সংখ্যা সর্বদা একটি সেকেন্ডের একটি ভগ্নাংশের অংশ উপস্থাপন করে (যেমন এটি এক হাজারেরও কম)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// পুরো মাইক্রোসেকেন্ডে এই `Duration` এর ভগ্নাংশের অংশ প্রদান করে।
    ///
    /// এই পদ্ধতিটি মাইক্রোসেকেন্ডস দ্বারা প্রতিনিধিত্ব করার সময় **নয়** সময়কালের দৈর্ঘ্য ফিরিয়ে দেয়।
    /// প্রত্যাবর্তিত সংখ্যা সর্বদা একটি সেকেন্ডের ভগ্নাংশের অংশ উপস্থাপন করে (অর্থাত এটি দশ মিলিয়নেরও কম)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ন্যানোসেকেন্ডে এই `Duration` এর ভগ্নাংশের অংশ প্রদান করে।
    ///
    /// ন্যানোসেকেন্ড দ্বারা প্রতিনিধিত্ব করার সময় এই পদ্ধতিটি **নয়** সময়কালের দৈর্ঘ্য ফিরিয়ে দেয়।
    /// প্রত্যাবর্তিত সংখ্যা সর্বদা একটি সেকেন্ডের ভগ্নাংশের অংশ উপস্থাপন করে (অর্থাত এটি এক বিলিয়ন এরও কম)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// এই `Duration` দ্বারা অন্তর্ভুক্ত মোট মিলিসেকেন্ডগুলির মোট সংখ্যা প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// এই `Duration` দ্বারা অন্তর্ভুক্ত মোট মাইক্রোসেকেন্ডগুলির মোট সংখ্যা প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// এই `Duration` দ্বারা অন্তর্ভুক্ত মোট ন্যানোসেকেন্ডের সংখ্যা প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// এক্স 100 এক্স সংযোজন চেক করা হয়েছে।
    /// ওভারফ্লো দেখা দিলে `self + other` গণনা করছে, এক্স01 এক্স ফিরে আসছে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// স্যাচুরেটিং এক্স 100 এক্স সংযোজন।
    /// ওভারফ্লো দেখা দিলে `self + other` গণনা করছে, এক্স01 এক্স ফিরে আসছে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// এক্স 100 এক্স বিয়োগফল চেক করা হয়েছে।
    /// এক্সট্যাক্স `self - other`, ফলাফলটি নেতিবাচক হলে বা ওভারফ্লো হয়েছে যদি [`None`] ফেরত।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// স্যাচুরেটিং এক্স 100 এক্স বিয়োগফল।
    /// এক্সট্যাক্স `self - other`, ফলাফলটি নেতিবাচক হলে বা ওভারফ্লো হয়েছে যদি [`Duration::ZERO`] ফেরত।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` গুণিত পরীক্ষা করা হয়েছে।
    /// ওভারফ্লো দেখা দিলে `self * other` গণনা করছে, এক্স01 এক্স ফিরে আসছে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // u64 হিসাবে ন্যানোসেকেন্ডগুলিকে গুণ করুন কারণ এটি সেভাবে উপচে পড়তে পারে না।
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// স্যাচুরেটিং এক্স 100 এক্স গুণ
    /// ওভারফ্লো দেখা দিলে `self * other` গণনা করছে, এক্স01 এক্স ফিরে আসছে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// এক্স 100 এক্স বিভাগ চেক করা হয়েছে।
    /// `self / other` গণনা করছে, `other == 0` হলে [`None`] ফেরত।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// এই `Duration` দ্বারা সেকেন্ডের সংখ্যাটি `f64` হিসাবে ফিরিয়ে দেয়।
    /// প্রত্যাবর্তিত মানটির মধ্যে সময়কালের ভগ্নাংশ (nanosecond) অংশ অন্তর্ভুক্ত থাকে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// এই `Duration` দ্বারা সেকেন্ডের সংখ্যাটি `f32` হিসাবে ফিরিয়ে দেয়।
    /// প্রত্যাবর্তিত মানটির মধ্যে সময়কালের ভগ্নাংশ (nanosecond) অংশ অন্তর্ভুক্ত থাকে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` হিসাবে চিহ্নিত সেকেন্ডের নির্দিষ্ট সংখ্যা থেকে একটি নতুন এক্স01 এক্স তৈরি করে।
    ///
    /// # Panics
    /// `secs` সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লোস না হলে এই কনস্ট্রাক্টর panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` হিসাবে চিহ্নিত সেকেন্ডের নির্দিষ্ট সংখ্যা থেকে একটি নতুন এক্স01 এক্স তৈরি করে।
    ///
    /// # Panics
    /// `secs` সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লোস না হলে এই কনস্ট্রাক্টর panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` দ্বারা গুণিত `Duration`।
    /// # Panics
    /// ফলাফল সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লো না হলে এই পদ্ধতিটি panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` দ্বারা গুণিত `Duration`।
    /// # Panics
    /// ফলাফল সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লো না হলে এই পদ্ধতিটি panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // নোট করুন যে রাউন্ডিং ত্রুটির কারণে ফলাফলটি 8.478 এবং 847800.0 থেকে কিছুটা আলাদা
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// এক্স 100 এক্স দ্বারা এক্স01 এক্স বিভক্ত করুন।
    /// # Panics
    /// ফলাফল সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লো না হলে এই পদ্ধতিটি panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // লক্ষ্য করুন যে কাটাটি গোলাকার নয়, ব্যবহৃত হয়েছে
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// এক্স 100 এক্স দ্বারা এক্স01 এক্স বিভক্ত করুন।
    /// # Panics
    /// ফলাফল সীমাবদ্ধ, নেতিবাচক বা `Duration` ওভারফ্লো না হলে এই পদ্ধতিটি panic করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // নোট করুন যে রাউন্ডিং ত্রুটির কারণে ফলাফলটি 0.859_872_611 থেকে কিছুটা আলাদা
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // লক্ষ্য করুন যে কাটাটি গোলাকার নয়, ব্যবহৃত হয়েছে
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` কে `Duration` দ্বারা বিভক্ত করুন এবং `f64` প্রদান করুন।
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` কে `Duration` দ্বারা বিভক্ত করুন এবং `f32` প্রদান করুন।
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// দশমিক স্বরলিপিতে একটি ভাসমান পয়েন্ট সংখ্যা ফর্ম্যাট করে।
        ///
        /// নম্বরটি `integer_part` এবং একটি ভগ্নাংশের অংশ হিসাবে দেওয়া হয়েছে।
        /// ভগ্নাংশের অংশটি `fractional_part / divisor`।
        /// সুতরাং `integer_part` =3, `fractional_part` =12 এবং `divisor` =100 `3.012` সংখ্যাটি উপস্থাপন করে।
        /// ট্রেলিং শূন্যগুলি বাদ দেওয়া হয়েছে।
        ///
        /// `divisor` 100_000_000 এর উপরে হওয়া উচিত নয়।
        /// এটি 10 টির শক্তিও হওয়া উচিত, অন্য সমস্ত কিছুই বোঝায় না।
        /// `fractional_part` `10 * divisor` এর চেয়ে কম হতে হবে!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ভগ্নাংশটি অস্থায়ী বাফারে এনকোড করুন।
            // বাফারটিতে কেবল 9 টি উপাদান রাখা দরকার, কারণ `fractional_part` 10 ^ 9 এর চেয়ে ছোট হতে হবে।
            //
            // নীচের কোডটি সরল করতে বাফারটি '0' অঙ্ক দিয়ে প্রিফিল্ড করা হয়েছে।
            let mut buf = [b'0'; 9];

            // পরের অঙ্কটি এই পজিশনে লেখা আছে
            let mut pos = 0;

            // শূন্য-শূন্য সংখ্যা বাকি থাকা অবস্থায় আমরা বাফারে অঙ্কগুলি লিখতে থাকি এবং আমরা এখনও পর্যাপ্ত সংখ্যা লিখি না।
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // বাফারে নতুন অঙ্ক লিখুন
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // যদি একটি যথার্থ <9 নির্দিষ্ট করা থাকে তবে কিছু শূন্য-অংক বাকি থাকতে পারে যা বাফারে লেখা হয়নি।
            // সেক্ষেত্রে আমাদের স্বাভাবিক ভাসমান পয়েন্ট সংখ্যা মুদ্রণের শব্দার্থের সাথে মেলে ধরে গোল করা উচিত।
            // তবে, গোল করার সময় আমাদের কেবল কাজ করা দরকার।
            // বাকীগুলির প্রথম সংখ্যাটি==5 হলে এটি ঘটে।
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // বাফারে থাকা সংখ্যাটি গোল কর।
                // আমরা বাফারটি পেরিয়ে পিছনের দিকে চলে যাই এবং ক্যারিটি ট্র্যাক করি।
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // যদি বাফারের অঙ্কটি '9' না হয় তবে আমাদের কেবল এটি বাড়ানো দরকার এবং তখনই থামতে পারি (যেহেতু আমাদের আর বহন করে না)।
                    // অন্যথায়, আমরা এটি '0' (overflow) এ সেট করে রেখেছি।
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // যদি এখনও আমাদের ক্যারি বিট সেট থাকে তবে এর অর্থ হ'ল আমরা পুরো বাফারটিকে '0' তে সেট করেছি এবং পূর্ণসংখ্যার অংশটি বাড়িয়ে তোলা দরকার।
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // বাফারের শেষটি নির্ধারণ করুন: যথার্থতা সেট করা থাকলে আমরা বাফার থেকে কেবলমাত্র বহু সংখ্যা ব্যবহার করি (9 কে ক্যাপড)।
            // যদি এটি সেট না করা থাকে তবে আমরা কেবল সর্বশেষ অ-শূন্য একটি পর্যন্ত সমস্ত অঙ্ক ব্যবহার করি।
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // যদি আমরা একটি একক ভগ্নাংশের অঙ্কটি নির্গমন না করে এবং যথার্থটি একটি শূন্য-বিন্দুতে সেট না করে থাকি তবে আমরা দশমিক পয়েন্টটি প্রিন্ট করি না।
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // নিরাপত্তা: আমরা কেবল বাফারে ASCII ডিজিট লিখছি এবং এটি ছিল
                // '0 এর সাহায্যে আরম্ভ করা হয়েছে, সুতরাং এতে বৈধ UTF8 রয়েছে।
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // যদি ব্যবহারকারী কোনও সূক্ষ্মতা> 9 এর জন্য অনুরোধ করে তবে আমরা 0 এর শেষে প্যাড করব।
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // অনুরোধ করা থাকলে লিডিং এক্স00 এক্স সাইন মুদ্রণ করুন
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}