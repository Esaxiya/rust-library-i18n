//! আদিম traits এবং প্রকারের মৌলিক বৈশিষ্ট্যের প্রতিনিধিত্বকারী প্রকারগুলি।
//!
//! Rust প্রকারগুলি তাদের অভ্যন্তরীণ বৈশিষ্ট্য অনুসারে বিভিন্ন দরকারী উপায়ে শ্রেণিবদ্ধ করা যেতে পারে।
//! এই শ্রেণিবিন্যাসগুলি traits হিসাবে প্রতিনিধিত্ব করা হয়।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// প্রকার যা থ্রেড সীমানা জুড়ে স্থানান্তর করা যায়।
///
/// এই trait স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয় যখন সংকলক এটি উপযুক্ত তা নির্ধারণ করে।
///
/// অ-`Send` প্রকারের একটি উদাহরণ হল রেফারেন্স-কাউন্টিং পয়েন্টার [`rc::Rc`][`Rc`]।
/// যদি দুটি থ্রেড [`Rc`] এর একই রেফারেন্স-গণনা মানকে ক্লোন করার চেষ্টা করে তবে তারা একই সাথে রেফারেন্স গণনাটি আপডেট করার চেষ্টা করতে পারে যা [undefined behavior][ub] কারণ [`Rc`] পারমাণবিক ক্রিয়াকলাপ ব্যবহার করে না।
///
/// এর কাজিন [`sync::Arc`][arc] পারমাণবিক অপারেশন (কিছুটা ওভারহেড সহ) ব্যবহার করে এবং এটি এক্স 100 এক্স is
///
/// আরও তথ্যের জন্য [the Nomicon](../../nomicon/send-and-sync.html) দেখুন।
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// সংকলনের সময় পরিচিত ধ্রুব আকারের প্রকারগুলি।
///
/// সমস্ত প্রকারের পরামিতিগুলির `Sized` এর অন্তর্নিহিত আবদ্ধ থাকে।এটি উপযুক্ত না হলে এই আবদ্ধটি সরাতে বিশেষ সিনট্যাক্স এক্স01 এক্স ব্যবহার করা যেতে পারে।
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // স্ট্রাক্ট FooUse(Foo<[i32]>);//ত্রুটি: আকারের [i32] এর জন্য প্রয়োগ করা হয় না
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// একটি ব্যতিক্রম হ'ল জেড 0 ট্রাইট0 জেড এর অন্তর্নিহিত `Self` প্রকার।
/// একটি trait এর অন্তর্নিহিত `Sized` আবদ্ধ নেই কারণ এটি [trait অবজেক্ট] এর সাথে বেমানান যেখানে সংজ্ঞা অনুসারে, trait সমস্ত সম্ভাব্য প্রয়োগকারীদের সাথে কাজ করা দরকার, এবং এটি কোনও আকার হতে পারে।
///
///
/// যদিও Rust আপনাকে `Sized` কে trait এ আবদ্ধ করতে দিবে, আপনি পরে এটি trait অবজেক্ট গঠনে ব্যবহার করতে পারবেন না:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // যাক y: &dyn বার= &Impl;//ত্রুটি: trait `Bar` একটি অবজেক্টে তৈরি করা যায় না
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ডিফল্টর জন্য, উদাহরণস্বরূপ, যার জন্য প্রয়োজন `[T]: !Default` মূল্যায়নযোগ্য be
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// প্রকার যা গতিশীল আকারের ধরণের "unsized" হতে পারে।
///
/// উদাহরণস্বরূপ, আকারের অ্যারে প্রকার `[i8; 2]` `Unsize<[i8]>` এবং `Unsize<dyn fmt::Debug>` প্রয়োগ করে।
///
/// এক্স 100 এক্স এর সমস্ত বাস্তবায়ন সংকলক স্বয়ংক্রিয়ভাবে সরবরাহ করে।
///
/// `Unsize` এর জন্য বাস্তবায়ন করা হয়:
///
/// - `[T; N]` এক্স 100 এক্স
/// - `T` এক্স 100 এক্স যখন এক্স 100 এক্স হয়
/// - `Foo<..., T, ...>` যদি `Unsize<Foo<..., U, ...>>` হয়:
///   - `T: Unsize<U>`
///   - ফু একটি স্ট্রাক্ট
///   - কেবলমাত্র `Foo` এর সর্বশেষ ক্ষেত্রের মধ্যে `T` এর সাথে জড়িত একটি প্রকার রয়েছে
///   - `T` অন্য কোনও ক্ষেত্রের ধরণের অংশ নয়
///   - `Bar<T>: Unsize<Bar<U>>`, যদি `Foo` এর শেষ ক্ষেত্রের টাইপ `Bar<T>` থাকে
///
/// `Unsize` [`ops::CoerceUnsized`] এক্স যেমন ধারার আকারের ধরণের ধারণাগুলি রাখতে [`Rc`] পাত্রে অনুমতি দেয় তা [`ops::CoerceUnsized`] এর সাথে ব্যবহার করা হয়।
/// আরও তথ্যের জন্য [DST coercion RFC][RFC982] এবং [the nomicon entry on coercion][nomicon-coerce] দেখুন।
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// প্যাটার্ন ম্যাচে ব্যবহৃত ধ্রুবকগুলির জন্য trait প্রয়োজনীয়।
///
/// `PartialEq` থেকে প্রাপ্ত যে কোনও প্রকারের টাইপ-প্যারামিটারগুলি `Eq` প্রয়োগ করে কিনা তা নির্বিশেষে * এই trait স্বয়ংক্রিয়ভাবে কার্যকর করে Z
///
/// যদি কোনও `const` আইটেমটিতে এমন কোনও ধরণের থাকে যা এই জেড 0 ট্রাইট0 জেড বাস্তবায়ন করে না, তবে সেই ধরণের হয় (1.) `PartialEq` প্রয়োগ করে না (যার অর্থ ধ্রুবক সেই তুলনামূলক পদ্ধতিটি সরবরাহ করবে না, যা কোড জেনারেশন উপলব্ধ is উপলব্ধ রয়েছে), বা (2.) এটি প্রয়োগ করে * * এক্স04 এক্স এর সংস্করণ (যা আমরা ধরে নিই যে কাঠামোগত-সাম্যতা তুলনার সাথে সামঞ্জস্য হয় না)।
///
///
/// উপরের দুটি দৃশ্যের যে কোনওটিতে আমরা একটি প্যাটার্ন ম্যাচে এই ধরণের ধ্রুবক ব্যবহার প্রত্যাখ্যান করি।
///
/// এছাড়াও [structural match RFC][RFC1445] এবং [issue 63438] দেখুন যা বৈশিষ্ট্য-ভিত্তিক ডিজাইন থেকে এই trait এ স্থানান্তরিত করতে উদ্বুদ্ধ করেছিল।
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// প্যাটার্ন ম্যাচে ব্যবহৃত ধ্রুবকগুলির জন্য trait প্রয়োজনীয়।
///
/// `Eq` থেকে প্রাপ্ত যে কোনও প্রকারের এই ধরণের প্যারামিটারগুলি `Eq` প্রয়োগ করে কিনা তা *নির্বিশেষে* এই trait স্বয়ংক্রিয়ভাবে প্রয়োগ করে।
///
/// আমাদের টাইপ সিস্টেমে সীমাবদ্ধতার আশেপাশে কাজ করার জন্য এটি একটি হ্যাক।
///
/// # Background
///
/// আমরা চাই যে প্যাটার্ন মিলগুলিতে ব্যবহৃত ধরণের কনসেটগুলিতে `#[derive(PartialEq, Eq)]` বৈশিষ্ট্য রয়েছে।
///
/// আরও আদর্শ বিশ্বে, আমরা প্রদত্ত প্রকারটি `StructuralPartialEq` trait *এবং*`Eq` trait উভয়ই প্রয়োগ করে তা পরীক্ষা করেই সেই প্রয়োজনীয়তাটি পরীক্ষা করতে পারি could
/// তবে, আপনার কাছে ADT থাকতে পারে যা *`derive(PartialEq, Eq)`* করে এবং এমন একটি ঘটনা হতে পারে যা আমরা সংকলকটি গ্রহণ করতে চাই এবং এখনও ধ্রুবকের ধরণটি `Eq` বাস্তবায়নে ব্যর্থ হয়।
///
/// যথা, এরকম একটি কেস:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (উপরের কোডটিতে সমস্যাটি হ'ল `Wrap<fn(&())>` `PartialEq` বা `Eq` প্রয়োগ করে না, কারণ '<' a> fn(&'a _)` does not implement those traits.) এর জন্য
///
/// অতএব, আমরা `StructuralPartialEq` এবং নিছক `Eq` এর জন্য নিষ্পাপ চেকের উপর নির্ভর করতে পারি না।
///
/// এটিকে কাজে লাগানোর জন্য হ্যাক হিসাবে, আমরা দুটি পৃথক জে0ট্রেটসজেড ব্যবহার করি দুটি এক্সেরএক্সএক্সএক্স এবং এক্স0১ এক্স এর মাধ্যমে ইনজেকশনের মাধ্যমে এবং উভয় স্ট্রাকচারাল ম্যাচ পরীক্ষার অংশ হিসাবে উপস্থিত রয়েছে কিনা তা পরীক্ষা করে দেখুন।
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// প্রকারের মানগুলি বিট অনুলিপি করে অনুলিপি করা যায়।
///
/// ডিফল্টরূপে, ভেরিয়েবল বাইন্ডিংগুলিতে 'মুভ সেমেন্টিকস' থাকে।অন্য কথায়:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` এ চলে গেছে এবং তাই এটি ব্যবহার করা যায় না
///
/// // মুদ্রণ! ("{: ?}", এক্স);//ত্রুটি: সরানো মান ব্যবহার
/// ```
///
/// যাইহোক, যদি কোনও প্রকার `Copy` প্রয়োগ করে তবে এর পরিবর্তে 'কপি শব্দার্থবিজ্ঞান' রয়েছে:
///
/// ```
/// // আমরা একটি `Copy` বাস্তবায়ন পেতে পারি।
/// // `Clone` এটি `Copy` এর একটি সুপাররেট হিসাবেও প্রয়োজনীয়।
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` এটি `x` এর একটি অনুলিপি
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// এটি লক্ষণীয় গুরুত্বপূর্ণ যে এই দুটি উদাহরণে কেবলমাত্র পার্থক্য হ'ল আপনাকে নিয়োগের পরে `x` অ্যাক্সেসের অনুমতি দেওয়া হচ্ছে কিনা।
/// ফণা অধীনে, একটি অনুলিপি এবং সরানো উভয়ই বিট মেমরিতে অনুলিপি করতে পারে, যদিও এটি কখনও কখনও অপ্টিমাইজ করা হয়।
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// আপনার ধরণের উপর `Copy` প্রয়োগ করার দুটি উপায় রয়েছে।`derive` ব্যবহার করা সবচেয়ে সহজ:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// আপনি `Copy` এবং `Clone` ম্যানুয়ালি প্রয়োগ করতে পারেন:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// উভয়ের মধ্যে একটি সামান্য পার্থক্য রয়েছে: `derive` কৌশলটি টাইপ পরামিতিগুলিতে আবদ্ধ একটি X01 এক্সও রাখবে, যা সর্বদা পছন্দসই নয়।
///
/// ## `Copy` এবং `Clone` এর মধ্যে পার্থক্য কী?
///
/// অনুলিপিগুলি সুস্পষ্টভাবে ঘটে থাকে, উদাহরণস্বরূপ কোনও অ্যাসাইনমেন্টের অংশ হিসাবে `y = x`।`Copy` এর আচরণ ওভারলোডযোগ্য নয়;এটি সর্বদা একটি সাধারণ বিট-বুদ্ধিযুক্ত অনুলিপি।
///
/// ক্লোনিং একটি স্পষ্ট ক্রিয়া, এক্স00 এক্স।[`Clone`] এর বাস্তবায়ন নিরাপদে মানগুলি নকল করতে প্রয়োজনীয় যে কোনও প্রকার-নির্দিষ্ট আচরণ সরবরাহ করতে পারে।
/// উদাহরণস্বরূপ, [`String`] এর জন্য [`Clone`] বাস্তবায়নের জন্য গাদাতে পয়েন্ট-টু স্ট্রিং বাফারটি অনুলিপি করা দরকার।
/// [`String`] মানগুলির একটি সাধারণ বিটওয়াইজ অনুলিপিটি কেবলমাত্র পয়েন্টারটি অনুলিপি করবে, যার ফলে লাইনটি নীচে ডাবল মুক্ত হবে।
/// এই কারণে, [`String`] এক্স02 এক্স তবে এক্স 100 এক্স নয়।
///
/// [`Clone`] `Copy` এর একটি সুপাররেট, সুতরাং যা `Copy` রয়েছে তা অবশ্যই [`Clone`] বাস্তবায়ন করতে হবে।
/// যদি কোনও প্রকারটি `Copy` হয় তবে এর [`Clone`] বাস্তবায়ন কেবলমাত্র `*self` ফেরত দরকার (উপরের উদাহরণটি দেখুন)।
///
/// ## আমার টাইপটি কখন `Copy` হতে পারে?
///
/// যদি এর সমস্ত উপাদানগুলি `Copy` প্রয়োগ করে তবে একটি প্রকার `Copy` প্রয়োগ করতে পারে।উদাহরণস্বরূপ, এই স্ট্রাক্টটি `Copy` হতে পারে:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// একটি কাঠামো `Copy`, এবং [`i32`] এক্স02 এক্স হতে পারে, সুতরাং `Point` এক্স 100 এক্স হওয়ার যোগ্য eligible
/// বিপরীতে, বিবেচনা করুন
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// কাঠামো `PointList` `Copy` বাস্তবায়ন করতে পারে না, কারণ [`Vec<T>`] এক্স01 এক্স নয়।আমরা যদি `Copy` বাস্তবায়ন আহরণের চেষ্টা করি তবে আমরা একটি ত্রুটি পেয়ে যাব:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// ভাগ করা রেফারেন্স `Copy` এক্সও এক্স01 এক্স, তাই কোনও প্রকারটি এক্স02 এক্স হতে পারে, এমনকি যখন এটি `T` প্রকারের শেয়ার্ড রেফারেন্স রাখে যা * XXX নয়।
/// নিম্নলিখিত স্ট্রাক্টটি বিবেচনা করুন, যা `Copy` বাস্তবায়ন করতে পারে, কারণ এটি কেবল আমাদের উপরের থেকে নন-কপি প্রকারের `PointList`-এর জন্য একটি *ভাগ করা রেফারেন্স* রাখে:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## কখন * আমার প্রকারটি `Copy` হতে পারে না?
///
/// কিছু প্রকার নিরাপদে অনুলিপি করা যায় না।উদাহরণস্বরূপ, `&mut T` অনুলিপি করা একটি aliised পরিবর্তনীয় রেফারেন্স তৈরি করবে।
/// এক্স ২০০ এক্স অনুলিপি করা [`স্ট্রিং`] এর বাফার পরিচালনার জন্য ডুপ্লিকেট দায়বদ্ধ হবে, যার ফলে দ্বিগুণ মুক্ত হবে।
///
/// পরবর্তী ক্ষেত্রে সাধারণকরণ, কোনও ধরণের [`Drop`] প্রয়োগ করা `Copy` হতে পারে না, কারণ এটি নিজস্ব এক্স02 এক্স বাইট ছাড়াও কিছু সংস্থান পরিচালনা করে।
///
/// যদি আপনি কোনও স্ট্রাক্ট বা এন-কপি ডেটাযুক্ত এনুমে `Copy` প্রয়োগ করার চেষ্টা করেন তবে আপনি ত্রুটি [E0204] পাবেন।
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## কখন * আমার টাইপটি `Copy` হওয়া উচিত?
///
/// সাধারণভাবে বলতে গেলে, আপনার ধরণের _can_ যদি `Copy` প্রয়োগ করে তবে এটি করা উচিত।
/// তবে মনে রাখবেন যে `Copy` বাস্তবায়ন করা আপনার ধরণের পাবলিক API এর অংশ part
/// যদি প্রকারটি future এ অ-কপি হয়ে উঠতে পারে তবে ব্রেকিং এপিআই পরিবর্তনটি এড়াতে এখনই `Copy` বাস্তবায়ন বাদ দেওয়া বুদ্ধিমানের কাজ হতে পারে।
///
/// ## অতিরিক্ত প্রয়োগকারী
///
/// [implementors listed below][impls] ছাড়াও, নিম্নলিখিত ধরণেরগুলি `Copy` প্রয়োগ করে:
///
/// * ফাংশন আইটেমের প্রকারগুলি (অর্থাত্ প্রতিটি ফাংশনের জন্য পৃথক ধরণের সংজ্ঞা দেওয়া হয়েছে)
/// * ফাংশন পয়েন্টার ধরণের (যেমন, `fn() -> i32`)
/// * অ্যারের ধরণগুলি, সমস্ত আকারের জন্য, যদি আইটেম টাইপটি `Copy` (যেমন, `[i32; 123456]`) প্রয়োগ করে
/// * টুপল প্রকার, যদি প্রতিটি উপাদান `Copy` প্রয়োগ করে (যেমন, `()`, `(i32, bool)`)
/// * বন্ধের ধরণগুলি, যদি তারা পরিবেশ থেকে কোনও মূল্য ক্যাপচার করে না বা যদি এই জাতীয় সমস্ত কৃত মানগুলি `Copy` নিজেরাই প্রয়োগ করে।
///   নোট করুন যে ভাগ করা রেফারেন্সের মাধ্যমে ক্যাপচার করা ভেরিয়েবলগুলি সর্বদা `Copy` প্রয়োগ করে (এমনকি যদি রেফারেন্স না করে) তবে পরিবর্তনীয় রেফারেন্স দ্বারা ক্যাপচার করা ভেরিয়েবলগুলি কখনই `Copy` প্রয়োগ করে না।
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) এটি এমন ধরণের অনুলিপি করতে দেয় যা `Copy` বাস্তবায়ন করে না কারণ অসন্তুষ্ট আজীবন সীমাবদ্ধতার কারণে (কেবলমাত্র `A<'static>: Copy` এবং `A<'_>: Clone` হলে `A<'_>` অনুলিপি করা)।
// আমাদের কাছে এখনই এই বৈশিষ্ট্যটি রয়েছে কারণ `Copy`-তে ইতিমধ্যে বেশ কয়েকটি বিদ্যমান বিশেষত্ব রয়েছে যা ইতিমধ্যে স্ট্যান্ডার্ড লাইব্রেরিতে রয়েছে এবং নিরাপদে এই আচরণটি নিরাপদে রাখার কোনও উপায় নেই।
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// যে ধরণের জন্য থ্রেডগুলির মধ্যে রেফারেন্স ভাগ করে নেওয়া নিরাপদ।
///
/// এই trait স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয় যখন সংকলক এটি উপযুক্ত তা নির্ধারণ করে।
///
/// সুনির্দিষ্ট সংজ্ঞাটি হ'ল: `T` প্রকারটি [`Sync`] হয় এবং কেবলমাত্র যদি `&T` এক্স 100 এক্স হয়।
/// অন্য কথায়, থ্রেডগুলির মধ্যে `&T` রেফারেন্সগুলি পাস করার সময় যদি [undefined behavior][ub] (ডেটা রেস সহ) কোনও সম্ভাবনা না থাকে।
///
/// যেমনটি প্রত্যাশা করা যায়, [`u8`] এবং [`f64`] এর মতো আদিম ধরণগুলি সমস্ত এক্স00 এক্স এবং তাই সাধারণ সমষ্টিগত ধরণেরগুলি যেমন টিপলস, স্ট্রাক্টস এবং এনামগুলি ধারণ করে।
/// প্রাথমিক [`Sync`] প্রকারের আরও উদাহরণগুলির মধ্যে রয়েছে "immutable" প্রকারের `&T` এবং সাধারণ উত্তরাধিকার সূত্রে পরিবর্তনশীল যেমন [`Box<T>`][box], [`Vec<T>`][vec] এবং বেশিরভাগ অন্যান্য সংগ্রহের ধরণের।
///
/// (জেনেরিক প্যারামিটারগুলি তাদের ধারক হওয়ার জন্য [`Sync`] হওয়ার জন্য [`Sync`] হওয়া দরকার))
///
/// সংজ্ঞাটির কিছুটা অবাক করা পরিণতি হ'ল `&mut T` হ'ল `Sync` (যদি `T` এক্স03 এক্স হয়) যদিও মনে হয় এটি অযৌক্তিক রূপান্তর সরবরাহ করতে পারে।
/// কৌশলটি হ'ল একটি ভাগ করা রেফারেন্সের পিছনে একটি পরিবর্তনীয় রেফারেন্স (যা `& &mut T`) কেবল পঠনযোগ্য হয়ে যায়, যেন এটি কোনও `& &T`।
/// অতএব ডেটা রেসের কোনও ঝুঁকি নেই।
///
/// `Sync` নয় এমন প্রকারগুলি হ'ল "interior mutability" একটি নন-থ্রেড-নিরাপদ ফর্মের মধ্যে রয়েছে, যেমন [`Cell`][cell] এবং [`RefCell`][refcell]।
/// এই ধরণেরগুলি অপরিবর্তনীয়, ভাগ করা রেফারেন্সের মাধ্যমে এমনকি তাদের সামগ্রীর পরিবর্তনের অনুমতি দেয়।
/// উদাহরণস্বরূপ [`Cell<T>`][cell]-এ `set` পদ্ধতিটি `&self` নেয়, সুতরাং এটির জন্য কেবল একটি ভাগ করা রেফারেন্স [`&Cell<T>`][cell] প্রয়োজন।
/// পদ্ধতিটি কোনও সিঙ্ক্রোনাইজেশন করে না, সুতরাং [`Cell`][cell] `Sync` হতে পারে না।
///
/// অ-সাইনসি` টাইপের আর একটি উদাহরণ হ'ল রেফারেন্স-কাউন্টিং পয়েন্টার [`Rc`][rc]।
/// কোনও রেফারেন্স [`&Rc<T>`][rc] দেওয়া, আপনি অ-পারমাণবিক উপায়ে রেফারেন্স গণনাগুলিকে সংশোধন করে একটি নতুন এক্স01 এক্স ক্লোন করতে পারেন।
///
/// ক্ষেত্রে যখন কারও জন্য থ্রেড-নিরাপদ অভ্যন্তরীণ পরিবর্তনের প্রয়োজন হয়, Rust [atomic data types] সরবরাহ করে, পাশাপাশি [`sync::Mutex`][mutex] এবং [`sync::RwLock`][rwlock] এর মাধ্যমে সুস্পষ্ট লকিং সরবরাহ করে।
/// এই ধরণেরগুলি নিশ্চিত করে যে কোনও রূপান্তর ডেটা দৌড়ের কারণ হতে পারে না, তাই প্রকারগুলি `Sync`।
/// তেমনি, [`sync::Arc`][arc] [`Rc`][rc] এর একটি থ্রেড-নিরাপদ অ্যানালগ সরবরাহ করে।
///
/// অভ্যন্তরীণ পরিবর্তনের সাথে যে কোনও ধরণের value(s) এর আশেপাশের [`cell::UnsafeCell`][unsafecell] মোড়ক ব্যবহার করা উচিত যা ভাগ করে নেওয়া রেফারেন্সের মাধ্যমে রূপান্তরিত হতে পারে।
/// এটি করতে ব্যর্থ হ'ল এক্স00 এক্স।
/// উদাহরণস্বরূপ, [`ট্রান্সমিট`][ট্রান্সমিট]-ইং `&T` থেকে এক্স01 এক্স অবৈধ।
///
/// `Sync` সম্পর্কে আরও তথ্যের জন্য [the Nomicon][nomicon-send-and-sync] দেখুন।
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): একবার বিটাতে `rustc_on_unimplemented` জমিগুলিতে নোট যুক্ত করার জন্য সমর্থন করুন এবং এটি প্রয়োজনীয় শৃঙ্খলে কোনও বন্ধ রয়েছে কিনা তা পরীক্ষা করার জন্য এটি বাড়িয়ে দেওয়া হয়েছে, এটিকে (#48534) হিসাবে প্রসারিত করুন:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// শূন্য আকারের প্রকারের জিনিসগুলিকে চিহ্নিত করতে ব্যবহৃত হয় যেগুলি "act like" তাদের একটি `T` রয়েছে।
///
/// আপনার টাইপের সাথে একটি এক্স01 এক্স ফিল্ড যুক্ত করা সংকলককে বলে যে আপনার টাইপটি এটি `T` প্রকারের মূল্য সঞ্চয় করে এমনভাবে কাজ করে যদিও এটি সত্যই না।
/// কিছু সুরক্ষা বৈশিষ্ট্য গণনা করার সময় এই তথ্য ব্যবহৃত হয়।
///
/// `PhantomData<T>` কীভাবে ব্যবহার করবেন সে সম্পর্কে আরও গভীরতার জন্য, দয়া করে [the Nomicon](../../nomicon/phantom-data.html) দেখুন।
///
/// # একটি ভয়াবহ নোট 👻👻👻
///
/// যদিও তাদের দুজনেরই ভীতিজনক নাম রয়েছে, এক্স00 এক্স এবং 'ফ্যান্টম টাইপস' সম্পর্কিত তবে অভিন্ন নয়।ফ্যান্টম টাইপ প্যারামিটার হ'ল একটি টাইপ প্যারামিটার যা কখনও ব্যবহৃত হয় না।
/// Rust এ, প্রায়শই এটি সংকলকটি অভিযোগ করার কারণ হয়ে যায় এবং সমাধানটি `PhantomData` এর মাধ্যমে একটি "dummy" ব্যবহার যুক্ত করা হয়।
///
/// # Examples
///
/// ## অব্যবহৃত জীবনকাল পরামিতি
///
/// সম্ভবত `PhantomData` এর ক্ষেত্রে সবচেয়ে সাধারণ ব্যবহারের ক্ষেত্রটি এমন একটি কাঠামো যা একটি অব্যবহৃত জীবনকাল পরামিতি থাকে, সাধারণত কিছু অনিরাপদ কোডের অংশ হিসাবে।
/// উদাহরণস্বরূপ, এখানে একটি স্ট্রাক্ট `Slice` রয়েছে যা টাইপ `*const T` এর দুটি পয়েন্টার রয়েছে, সম্ভবত কোথাও অ্যারেতে নির্দেশ করছে:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// উদ্দেশ্যটি হ'ল অন্তর্নিহিত ডেটা কেবলমাত্র আজীবন `'a` এর জন্য বৈধ, সুতরাং `Slice` এক্স00 এক্সকে আউটলাইভ করা উচিত নয়।
/// তবে কোডটিতে এই অভিপ্রায়টি প্রকাশ করা হয়নি, যেহেতু আজীবন `'a` এর কোনও ব্যবহার নেই এবং তাই এটি কোন ডেটাতে প্রযোজ্য তা পরিষ্কার নয়।
/// আমরা সংস্থাপককে *এইভাবে কাজ করতে বলার মাধ্যমে এটি সংশোধন করতে পারি যেন*`Slice` স্ট্রাক্টে একটি রেফারেন্স `&'a T` রয়েছে:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// এর পরিবর্তে এনেটেশন এক্স01 এক্সেরও প্রয়োজন, এটি নির্দেশ করে যে `T` এ থাকা কোনও রেফারেন্স আজীবন `'a` এর চেয়ে বেশি কার্যকর।
///
/// একটি `Slice` সূচনা করার সময় আপনি কেবল `phantom` ক্ষেত্রের জন্য `PhantomData` মান সরবরাহ করুন:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## অব্যবহৃত প্রকারের পরামিতি
///
/// এটি কখনও কখনও ঘটে থাকে যে আপনার অব্যবহৃত প্রকারের পরামিতি রয়েছে যা সূচিত করে যে কোনও কাঠামোর কী ধরণের ডেটা "tied" হয়, যদিও তথ্যটি স্ট্রাক্টের মধ্যেই পাওয়া যায় না।
/// এটি এখানে একটি উদাহরণ যেখানে [FFI] এর সাথে উত্থাপিত হয়।
/// বিদেশী ইন্টারফেস বিভিন্ন ধরণের Rust মানগুলিকে উল্লেখ করতে হ্যান্ডলগুলি টাইপ `*mut ()` ব্যবহার করে।
/// আমরা স্ট্রাক্ট `ExternalResource` এ ফ্যান্টম টাইপ প্যারামিটার ব্যবহার করে Rust টাইপটি ট্র্যাক করি যা একটি হ্যান্ডেল মোড়ানো।
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## মালিকানা এবং ড্রপ চেক
///
/// `PhantomData<T>` প্রকারের ক্ষেত্র যুক্ত করা ইঙ্গিত দেয় যে আপনার ধরণের `T` টাইপের ডেটা রয়েছে।এর পরিবর্তে বোঝা যাচ্ছে যে আপনার টাইপটি বাদ পড়লে এটি `T` টাইপের এক বা একাধিক উদাহরণ ফেলে যেতে পারে।
/// এটি Rust সংকলকের [drop check] বিশ্লেষণে বহন করে।
///
/// যদি আপনার স্ট্রাক্টটি আসলে `T` টাইপের ডেটা *নিজস্ব* না করে, তবে `PhantomData<&'a T>` (ideally) বা `PhantomData<*const T>` (যদি কোনও আজীবন প্রযোজ্য না হয়) এর মতো একটি রেফারেন্স টাইপ ব্যবহার করা ভাল, যাতে মালিকানা নির্দেশ না করে।
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// সংকলক-অভ্যন্তরীণ trait এনাম বৈষম্যগুলির ধরণের নির্দেশ করতে ব্যবহৃত হয়েছিল।
///
/// এই trait স্বয়ংক্রিয়ভাবে প্রতিটি ধরণের জন্য প্রয়োগ করা হয় এবং [`mem::Discriminant`]-এ কোনও গ্যারান্টি যোগ করে না।
/// `DiscriminantKind::Discriminant` এবং `mem::Discriminant` এর মধ্যে ট্রান্সমিট করা **অপরিজ্ঞাত আচরণ**।
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// বৈষম্যমূলক প্রকার, যা অবশ্যই `mem::Discriminant` দ্বারা প্রয়োজনীয় trait bounds সন্তুষ্ট করতে হবে।
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// সংকলক-অভ্যন্তরীণ trait কোনও ধরণের অভ্যন্তরীণভাবে কোনও `UnsafeCell` রয়েছে কিনা তা নির্ধারণ করতে ব্যবহৃত হয়, তবে কোনও দিকনির্দেশের মাধ্যমে নয়।
///
/// এটি প্রভাবিত করে, উদাহরণস্বরূপ, সেই ধরণের কোনও `static` কেবল পঠনযোগ্য স্ট্যাটিক মেমরিতে বা লিখনযোগ্য স্থিতিশীল মেমোরিতে রাখা আছে কিনা।
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// পিন করার পরে সুরক্ষিতভাবে সরানো যেতে পারে এমন প্রকারগুলি।
///
/// Rust নিজেই অস্থাবর প্রকারের কোনও ধারণা নেই এবং সর্বদা নিরাপদ থাকার জন্য চালগুলি (যেমন, অ্যাসাইনমেন্ট বা [`mem::replace`] এর মাধ্যমে) বিবেচনা করে।
///
/// প্রকারের সিস্টেমে চালনা রোধ করতে পরিবর্তে [`Pin`][Pin] প্রকারটি ব্যবহৃত হয়।[`Pin<P<T>>`][Pin] মোড়কে মোড়ানো পয়েন্টার `P<T>` এর বাইরে সরানো যায় না।
/// পিনিং সম্পর্কিত আরও তথ্যের জন্য [`pin` module] ডকুমেন্টেশন দেখুন।
///
/// `T`-এর জন্য `Unpin` trait প্রয়োগ করা টাইপ পিন করার সীমাবদ্ধতাগুলি সরিয়ে দেয়, এরপরে [`mem::replace`] এক্স এর মতো ফাংশনগুলির সাথে [`Pin<P<T>>`][Pin] এর বাইরে `T` সরানোর অনুমতি দেয়।
///
///
/// `Unpin` পিনবিহীন ডেটার জন্য কোনও ফল নেই।
/// বিশেষত, [`mem::replace`] আনন্দের সাথে `!Unpin` ডেটা সরায় (এটি কোনও এক্স 100 এক্সের জন্য কাজ করে, কেবলমাত্র এক্স03 এক্স যখন নয়)।
/// তবে আপনি [`Pin<P<T>>`][Pin] এর ভিতরে মোড়ানো ডেটাতে [`mem::replace`] ব্যবহার করতে পারবেন না কারণ এর জন্য আপনার প্রয়োজনীয় `&mut T` পেতে পারেন না এবং * ** যা এই সিস্টেমকে কাজ করে।
///
/// সুতরাং এটি উদাহরণস্বরূপ, কেবলমাত্র `Unpin` প্রয়োগকারী ধরণের ক্ষেত্রে করা যেতে পারে:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` কল করতে আমাদের একটি পরিবর্তনীয় রেফারেন্স প্রয়োজন।
/// // আমরা (implicitly) দ্বারা `Pin::deref_mut` কে আহ্বান করে এই জাতীয় একটি রেফারেন্স পেতে পারি, তবে এটি কেবলমাত্র সম্ভব কারণ `String` `Unpin` প্রয়োগ করে।
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// এই trait প্রায় প্রতিটি ধরণের জন্য স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয়।
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// এমন একটি চিহ্নিতকারী যা `Unpin` প্রয়োগ করে না।
///
/// যদি কোনও ধরণের একটি `PhantomPinned` থাকে, তবে এটি ডিফল্টভাবে `Unpin` প্রয়োগ করবে না।
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// আদিম ধরণের জন্য `Copy` এর বাস্তবায়ন।
///
/// Rust এ বর্ণনা করা যায় না এমন বাস্তবায়নগুলি `rustc_trait_selection` এ `traits::SelectionContext::copy_clone_conditions()` এ প্রয়োগ করা হয়।
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// ভাগ করা রেফারেন্সগুলি অনুলিপি করা যায়, তবে পরিবর্তনযোগ্য রেফারেন্সগুলি *পারি না*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}