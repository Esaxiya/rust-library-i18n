//! পারমাণবিক প্রকার
//!
//! পারমাণবিক প্রকারগুলি থ্রেডগুলির মধ্যে আদিম ভাগ করা-মেমরি যোগাযোগ সরবরাহ করে এবং এটি অন্যান্য সমবর্তী প্রকারের বিল্ডিং ব্লক।
//!
//! এই মডিউলটি [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ইত্যাদি সহ কয়েকটি নির্বাচিত আদিম ধরণের পারমাণবিক সংস্করণগুলি সংজ্ঞায়িত করে
//! পারমাণবিক প্রকারগুলি অপারেশনগুলি উপস্থাপন করে যা সঠিকভাবে ব্যবহৃত হলে থ্রেডগুলির মধ্যে আপডেটগুলি সিঙ্ক্রোনাইজ করে।
//!
//! প্রতিটি পদ্ধতিতে একটি [`Ordering`] লাগে যা সেই অপারেশনের জন্য মেমরির বাধার শক্তির প্রতিনিধিত্ব করে।এই ক্রমগুলি [C++20 atomic orderings][1] এর মতো।আরও তথ্যের জন্য [nomicon][2] দেখুন।
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! পারমাণবিক ভেরিয়েবলগুলি থ্রেডগুলির মধ্যে ভাগ করে নেওয়া নিরাপদ (তারা [`Sync`] বাস্তবায়িত করে) তবে তারা নিজেরাই জেড 0 রিস্ট0 জেড এর [threading model](../../../std/thread/index.html#the-threading-model) ভাগ করে নেওয়ার জন্য প্রক্রিয়া সরবরাহ করে না।
//!
//! পারমাণবিক পরিবর্তনশীল ভাগ করে নেওয়ার সর্বাধিক সাধারণ উপায় হল এটি একটি এক্স 100 এক্স (একটি পরমাণু-রেফারেন্স-গণনা করা ভাগ করা পয়েন্টার) এ রাখা।
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! পারমাণবিক প্রকারগুলি স্ট্যাটিক ভেরিয়েবলগুলিতে সঞ্চয় করা হতে পারে, এক্স 100 এক্সের মতো ধ্রুবক আরম্ভকারীদের ব্যবহার করে আরম্ভ করা।পারমাণবিক স্ট্যাটিক্স প্রায়শই অলস গ্লোবাল আরম্ভের জন্য ব্যবহৃত হয়।
//!
//! # Portability
//!
//! এই মডিউলে সমস্ত পারমাণবিক প্রকারেরগুলি উপলব্ধ থাকলে [lock-free] হওয়ার গ্যারান্টিযুক্ত।এর অর্থ তারা অভ্যন্তরীণভাবে একটি বিশ্বব্যাপী মিটেক্স অর্জন করে না।পারমাণবিক ধরণের এবং অপারেশনগুলি অপেক্ষা-মুক্ত থাকার গ্যারান্টিযুক্ত নয়।
//! এর অর্থ এই যে `fetch_or` এর মতো অপারেশনগুলি তুলনা-ও-সোয়াপ লুপের সাথে প্রয়োগ করা যেতে পারে।
//!
//! পারমাণবিক ক্রিয়াকলাপ বৃহত আকারের পরমাণু সহ নির্দেশ স্তরে প্রয়োগ করা যেতে পারে।উদাহরণস্বরূপ কিছু প্ল্যাটফর্ম `AtomicI8` বাস্তবায়নের জন্য 4-বাইট পরমাণু নির্দেশাবলী ব্যবহার করে।
//! নোট করুন যে এই অনুকরণটি কোডের নির্ভুলতার উপর প্রভাব ফেলবে না, এটি সচেতন হওয়ার মতো কিছু।
//!
//! এই মডিউলটিতে পারমাণবিক প্রকারগুলি সমস্ত প্ল্যাটফর্মগুলিতে উপলভ্য নয়।এখানে পারমাণবিক ধরণের সমস্ত বিস্তৃত, তবে সাধারণত বিদ্যমান উপর নির্ভর করা যেতে পারে।কিছু উল্লেখযোগ্য ব্যতিক্রমগুলি হ'ল:
//!
//! * PowerPC এবং 32-বিট পয়েন্টারযুক্ত MIPS প্ল্যাটফর্মগুলিতে `AtomicU64` বা `AtomicI64` ধরণের নেই।
//! * ARM `armv5te` এর মতো প্ল্যাটফর্মগুলি যা Linux এর জন্য নয় কেবল এক্স04 এক্স এবং এক্স05 এক্স ক্রিয়াকলাপ সরবরাহ করে এবং `swap`, `fetch_add` ইত্যাদির তুলনা এবং অদলবদ (CAS) ক্রিয়াকলাপ সমর্থন করে না etc.
//! Linux এ অতিরিক্তভাবে, এই সিএএস অপারেশনগুলি [operating system support] এর মাধ্যমে প্রয়োগ করা হয়, যা পারফরম্যান্সের শাস্তি পেতে পারে।
//! * ARM `thumbv6m` সহ লক্ষ্যমাত্রাগুলি কেবল এক্স03 এক্স এবং এক্স04 এক্স ক্রিয়াকলাপ সরবরাহ করে এবং এক্স 100 এক্স, এক্স01 এক্স ইত্যাদির তুলনা এবং অদলবদল (CAS) ক্রিয়াকলাপ সমর্থন করে না etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! নোট করুন যে জেডফিউচার0 জেড প্ল্যাটফর্মগুলি যুক্ত হতে পারে যা কিছু পারমাণবিক ক্রিয়াকলাপের সমর্থনও রাখে না notসর্বাধিক বহনযোগ্য কোড কোন পারমাণবিক প্রকারটি ব্যবহার করা হয় সে সম্পর্কে যত্নবান হতে চাইবে।
//! `AtomicUsize` এবং এক্স 100 এক্স সাধারণত সর্বাধিক পোর্টেবল হয় তবে তারপরেও সেগুলি সর্বত্র পাওয়া যায় না।
//! রেফারেন্সের জন্য, `std` লাইব্রেরিতে পয়েন্টার আকারের পরমাণুগুলির প্রয়োজন, যদিও `core` না।
//!
//! পারমাণবিকতার সাথে কোডে শর্তসাপেক্ষে সংকলন করতে বর্তমানে আপনাকে প্রাথমিকভাবে `#[cfg(target_arch)]` ব্যবহার করতে হবে।অস্থির `#[cfg(target_has_atomic)]` রয়েছে যা জেডফিউচার0 জেডে স্থিতিশীল হতে পারে।
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! একটি সাধারণ স্পিনলক:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // অন্য থ্রেডটি লকটি প্রকাশের জন্য অপেক্ষা করুন
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! লাইভ থ্রেডগুলির একটি বিশ্বব্যাপী গণনা রাখুন:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// একটি বুলিয়ান টাইপ যা থ্রেডগুলির মধ্যে নিরাপদে ভাগ করা যায়।
///
/// এই ধরণের [`bool`] এর মতো মেমরির উপস্থাপনা রয়েছে।
///
/// **দ্রষ্টব্য**: এই ধরণেরটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এর পারমাণবিক লোড এবং স্টোরগুলিকে সমর্থন করে।
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` এ আরম্ভ করা একটি `AtomicBool` তৈরি করে।
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// প্রেরণ সুস্পষ্টভাবে অ্যাটমিকবুলের জন্য প্রয়োগ করা হয়েছে।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// একটি কাঁচা পয়েন্টার টাইপ যা থ্রেডগুলির মধ্যে নিরাপদে ভাগ করা যায়।
///
/// এই ধরণের `*mut T` এর মতো মেমরির উপস্থাপনা রয়েছে।
///
/// **দ্রষ্টব্য**: এই ধরণটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পারমাণবিক লোড এবং পয়েন্টারগুলির সঞ্চয়কে সমর্থন করে।
/// এর আকার লক্ষ্য পয়েন্টারের আকারের উপর নির্ভর করে।
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// একটি নাল `AtomicPtr<T>` তৈরি করে।
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// পারমাণবিক মেমরি ক্রম
///
/// মেমোরি অর্ডারগুলি পারমাণবিক ক্রিয়াকলাপ মেমরিটিকে সিঙ্ক্রোনাইজ করার উপায় নির্দিষ্ট করে।
/// এর দুর্বলতম [`Ordering::Relaxed`]-এ কেবল অপারেশনের মাধ্যমে সরাসরি স্পর্শ করা স্মৃতি সিঙ্ক্রোনাইজ করা হয়।
/// অন্যদিকে, [`Ordering::SeqCst`] ক্রিয়াকলাপের একটি স্টোর-লোড জুটি অতিরিক্ত সমস্ত থ্রেড জুড়ে এই জাতীয় ক্রিয়াকলাপের মোট ক্রম সংরক্ষণ করার সময় অন্যান্য মেমরিটিকে সিঙ্ক্রোনাইজ করে।
///
///
/// Rust এর মেমরি ক্রমগুলি [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order)।
///
/// আরও তথ্যের জন্য [nomicon] দেখুন।
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// কোনও অর্ডারের সীমাবদ্ধতা নেই, কেবলমাত্র পারমাণবিক ক্রিয়াকলাপ।
    ///
    /// C ++ 20 এ [`memory_order_relaxed`] এর সাথে সম্পর্কিত।
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// কোনও স্টোরের সাথে মিলিত হয়ে গেলে, পূর্ববর্তী সমস্ত ক্রিয়াকলাপগুলি [`Acquire`] (বা আরও শক্তিশালী) অর্ডার দিয়ে এই মানটির কোনও লোড দেওয়ার আগেই অর্ডার হয়ে যায়।
    ///
    /// বিশেষত, সমস্ত পূর্ববর্তী লেখাগুলি সমস্ত থ্রেডগুলিতে দৃশ্যমান হয়ে থাকে যা এই মানটির একটি [`Acquire`] (বা আরও শক্তিশালী) লোড সম্পাদন করে।
    ///
    /// লক্ষ্য করুন যে লোড এবং স্টোরগুলি একত্রিত করে এমন ক্রিয়াকলাপের জন্য এই ক্রমটি ব্যবহার করার ফলে একটি [`Relaxed`] লোড অপারেশন হয়!
    ///
    /// এই অর্ডারিং কেবল এমন ক্রিয়াকলাপগুলির জন্য প্রযোজ্য যা কোনও স্টোর সম্পাদন করতে পারে।
    ///
    /// C ++ 20 এ [`memory_order_release`] এর সাথে সম্পর্কিত।
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// কোনও লোডের সাথে মিলিত হওয়ার সময়, লোড করা মানটি যদি [`Release`] (বা আরও শক্তিশালী) ক্রম দিয়ে স্টোর অপারেশন দ্বারা লিখিত হয়, তবে পরবর্তী সমস্ত ক্রিয়াকলাপ সেই স্টোরের পরে অর্ডার হয়ে যায়।
    /// বিশেষত, পরবর্তী সমস্ত লোড স্টোরের আগে লিখিত ডেটা দেখতে পাবে।
    ///
    /// লক্ষ্য করুন যে লোড এবং স্টোরগুলিকে একত্রিত করে এমন ক্রিয়াকলাপের জন্য এই ক্রমটি ব্যবহার করার ফলে একটি [`Relaxed`] স্টোর অপারেশন হয়!
    ///
    /// এই অর্ডারিং কেবল এমন ক্রিয়াকলাপগুলির জন্য প্রযোজ্য যা কোনও বোঝা সম্পাদন করতে পারে।
    ///
    /// C ++ 20 এ [`memory_order_acquire`] এর সাথে সম্পর্কিত।
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// একসাথে [`Acquire`] এবং [`Release`] উভয়েরই প্রভাব রয়েছে:
    /// ভারের জন্য এটি [`Acquire`] ক্রম ব্যবহার করে।স্টোরগুলির জন্য এটি [`Release`] ক্রম ব্যবহার করে।
    ///
    /// লক্ষ্য করুন যে `compare_and_swap` এর ক্ষেত্রে, এটি সম্ভব যে অপারেশনটি কোনও স্টোর সম্পাদন না করে শেষ হয় এবং তাই এটির কেবলমাত্র [`Acquire`] ক্রম রয়েছে।
    ///
    /// তবে, `AcqRel` কখনই X01 এক্স অ্যাক্সেসগুলি সম্পাদন করবে না।
    ///
    /// এই অর্ডারিং কেবলমাত্র সেই অপারেশনের জন্য প্রযোজ্য যা লোড এবং স্টোর উভয়কেই একত্রিত করে।
    ///
    /// C ++ 20 এ [`memory_order_acq_rel`] এর সাথে সম্পর্কিত।
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`অ্যাকুইয়ার`]//[`রিলিজ`]/[q অ্যাকিউরেলি](যথাক্রমে লোড, স্টোর এবং লোড-স্টোর অপারেশনের জন্য) অতিরিক্ত গ্যারান্টি সহ যে সমস্ত থ্রেড একই ক্রমে সমস্ত ধারাবাহিকভাবে সামঞ্জস্যপূর্ণ ক্রিয়াকলাপটি দেখে ।
    ///
    ///
    /// C ++ 20 এ [`memory_order_seq_cst`] এর সাথে সম্পর্কিত।
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// একটি [`AtomicBool`] `false` এ আরম্ভ করা।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// একটি নতুন এক্স 100 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// অন্তর্নিহিত [`bool`] এ পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// এটি নিরাপদ কারণ পরিবর্তনীয় রেফারেন্স গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সাথে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // সুরক্ষা: পরিবর্তনীয় রেফারেন্স অনন্য মালিকানার গ্যারান্টি দেয়।
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// একটি `&mut bool` এ পারমাণবিক অ্যাক্সেস পান।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // সুরক্ষা: পরিবর্তনীয় রেফারেন্সটি অনন্য মালিকানার গ্যারান্টি দেয় এবং
        // এক্স 100 এক্স এবং এক্স01 এক্স উভয়ের সারিবদ্ধকরণ 1।
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// পারমাণবিক গ্রহণ করে এবং এতে থাকা মানটি প্রদান করে।
    ///
    /// এটি নিরাপদ কারণ মান দ্বারা `self` পাস করা গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সঙ্গে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool থেকে একটি মান লোড করে।
    ///
    /// `load` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// সম্ভাব্য মানগুলি হল [`SeqCst`], [`Acquire`] এবং [`Relaxed`]।
    ///
    /// # Panics
    ///
    /// `order` যদি [`Release`] বা [`AcqRel`] হয় তবে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // সুরক্ষা: যে কোনও তথ্য দৌড়কে পারমাণবিক অভ্যন্তরীণ এবং কাঁচা দ্বারা প্রতিরোধ করা হয়
        // প্রবেশ করানো পয়েন্টারটি বৈধ কারণ আমরা এটি একটি রেফারেন্স থেকে পেয়েছি।
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool এ একটি মান সঞ্চয় করে।
    ///
    /// `store` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// সম্ভাব্য মানগুলি হল [`SeqCst`], [`Release`] এবং [`Relaxed`]।
    ///
    /// # Panics
    ///
    /// `order` যদি [`Acquire`] বা [`AcqRel`] হয় তবে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // সুরক্ষা: যে কোনও তথ্য দৌড়কে পারমাণবিক অভ্যন্তরীণ এবং কাঁচা দ্বারা প্রতিরোধ করা হয়
        // প্রবেশ করানো পয়েন্টারটি বৈধ কারণ আমরা এটি একটি রেফারেন্স থেকে পেয়েছি।
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// পূর্ববর্তী মানটি ফিরিয়ে bool এ একটি মান সঞ্চয় করে।
    ///
    /// `swap` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে [`bool`] এ একটি মান সঞ্চয় করে।
    ///
    /// রিটার্ন মান সর্বদা পূর্ববর্তী মান।এটি যদি `current` এর সমান হয় তবে মানটি আপডেট করা হয়েছিল।
    ///
    /// `compare_and_swap` এছাড়াও একটি [`Ordering`] আর্গুমেন্ট নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// লক্ষ করুন যে [`AcqRel`] ব্যবহার করার সময়ও, অপারেশনটি ব্যর্থ হতে পারে এবং তাই কেবল একটি `Acquire` লোড সঞ্চালন করতে পারে, তবে এক্স02 এক্স শব্দার্থতত্ত্ব নেই।
    /// [`Acquire`] ব্যবহার করে স্টোরটি এই অপারেশনের অংশ হয়ে যায় [`Relaxed`] যদি এটি ঘটে থাকে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] করে তোলে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # `compare_exchange` এবং `compare_exchange_weak` এ স্থানান্তরিত হচ্ছে
    ///
    /// `compare_and_swap` মেমরি ক্রমগুলির জন্য নিম্নলিখিত ম্যাপিংয়ের সাথে `compare_exchange` এর সমতুল্য:
    ///
    /// আসল |সাফল্য |ব্যর্থতা
    /// -------- | ------- | -------
    /// স্বচ্ছন্দ |স্বচ্ছন্দ |স্বাচ্ছন্দ্য অর্জন |অর্জন |রিলিজ অর্জন |মুক্তি |রিলাক্সড অ্যাকিউরেল |AcqRel |সিকসিস্ট অর্জন করুন |সিকসিস্ট |সিকসিস্ট
    ///
    /// `compare_exchange_weak` তুলনা সফল হওয়ার পরেও তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যা তুলনামূলক এবং অদলবদলটি একটি লুপে ব্যবহার করার সময় সংকলকটি আরও ভাল সমাবেশ কোড তৈরি করতে দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে [`bool`] এ একটি মান সঞ্চয় করে।
    ///
    /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
    /// সাফল্যে এই মানটি `current` এর সমান হওয়ার গ্যারান্টিযুক্ত।
    ///
    /// `compare_exchange` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
    ///
    /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে [`bool`] এ একটি মান সঞ্চয় করে।
    ///
    /// এক্স 100 এক্স এর বিপরীতে, তুলনা সফল হওয়ার পরেও এই ফাংশনটিকে তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যার ফলে কিছু প্ল্যাটফর্মগুলিতে আরও দক্ষ কোড তৈরি হতে পারে can
    ///
    /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
    ///
    /// `compare_exchange_weak` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
    /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// একটি বুলিয়ান মান সহ লজিকাল এক্স00 এক্স।
    ///
    /// বর্তমান মান এবং যুক্তি `val` এর উপর একটি যৌক্তিক "and" অপারেশন করে এবং ফলাফলটিতে নতুন মান সেট করে।
    ///
    /// পূর্ববর্তী মান প্রদান করে।
    ///
    /// `fetch_and` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// একটি বুলিয়ান মান সহ লজিকাল এক্স00 এক্স।
    ///
    /// বর্তমান মান এবং যুক্তি `val` এর উপর একটি যৌক্তিক "nand" অপারেশন করে এবং ফলাফলটিতে নতুন মান সেট করে।
    ///
    /// পূর্ববর্তী মান প্রদান করে।
    ///
    /// `fetch_nand` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // আমরা এখানে পারমাণবিক_নন্দ ব্যবহার করতে পারি না কারণ এটি একটি অবৈধ মান সহ bool হতে পারে।
        // এটি ঘটে কারণ পারমাণবিক অপারেশনটি অভ্যন্তরীণভাবে একটি 8-বিট পূর্ণসংখ্যার সাথে সম্পন্ন হয়, যা উপরের 7 বিট সেট করে।
        //
        // সুতরাং আমরা কেবল এর পরিবর্তে fetch_xor বা অদলবদল ব্যবহার করি।
        if val {
            // ! (x এবং সত্য)== !x আমাদের অবশ্যই bool উল্টাতে হবে।
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x এবং মিথ্যা)==সত্য আমাদের অবশ্যই bool সত্যে সেট করতে হবে।
            //
            self.swap(true, order)
        }
    }

    /// একটি বুলিয়ান মান সহ লজিকাল এক্স00 এক্স।
    ///
    /// বর্তমান মান এবং যুক্তি `val` এর উপর একটি যৌক্তিক "or" অপারেশন করে এবং ফলাফলটিতে নতুন মান সেট করে।
    ///
    /// পূর্ববর্তী মান প্রদান করে।
    ///
    /// `fetch_or` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// একটি বুলিয়ান মান সহ লজিকাল এক্স00 এক্স।
    ///
    /// বর্তমান মান এবং যুক্তি `val` এর উপর একটি যৌক্তিক "xor" অপারেশন করে এবং ফলাফলটিতে নতুন মান সেট করে।
    ///
    /// পূর্ববর্তী মান প্রদান করে।
    ///
    /// `fetch_xor` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// অন্তর্নিহিত [`bool`] এ পরিবর্তনীয় পয়েন্টারটি ফেরত দেয়।
    ///
    /// ফলস্বরূপ পূর্ণসংখ্যায় অ-পরমাণু পাঠ এবং লেখালেখি করা একটি ডেটা রেস হতে পারে।
    /// এই পদ্ধতিটি এফএফআইয়ের জন্য বেশিরভাগ ক্ষেত্রে কার্যকর, যেখানে ফাংশন স্বাক্ষরটি `&AtomicBool` এর পরিবর্তে `*mut bool` ব্যবহার করতে পারে।
    ///
    /// এই পারমাণবিকের সাথে ভাগ করা রেফারেন্স থেকে একটি `*mut` পয়েন্টার ফিরিয়ে দেওয়া নিরাপদ কারণ পারমাণবিক ধরণের অভ্যন্তরীণ পরিবর্তনের সাথে কাজ করে।
    /// পারমাণবিক সমস্ত পরিবর্তন একটি ভাগ করা রেফারেন্সের মাধ্যমে মান পরিবর্তন করে এবং যতক্ষণ না তারা পারমাণবিক ক্রিয়াকলাপ ব্যবহার করে ততক্ষণ নিরাপদে তা করতে পারে।
    /// প্রত্যাবর্তিত কাঁচা পয়েন্টারটির যে কোনও ব্যবহারের জন্য একটি `unsafe` ব্লক প্রয়োজন এবং এখনও একই বিধিনিষেধ বহাল রাখতে হবে: এটির ক্রিয়াকলাপগুলি অবশ্যই পারমাণবিক হতে হবে।
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// মানটি নিয়ে আসে এবং এটিতে একটি ফাংশন প্রয়োগ করে যা একটি alচ্ছিক নতুন মান দেয়।যদি ফাংশনটি `Some(_)`, অন্যথায় `Err(previous_value)` প্রদান করে তবে `Ok(previous_value)` এর একটি `Result` প্রদান করে।
    ///
    /// Note: যদি এই সময়ের মধ্যে অন্য থ্রেড থেকে মান পরিবর্তন করা হয় তবে এটি ফাংশনটিকে একাধিকবার কল করতে পারে, যতক্ষণ না ফাংশনটি `Some(_)` প্রদান করে, তবে ফাংশনটি কেবলমাত্র একবার সঞ্চিত মানটিতে প্রয়োগ করা হবে।
    ///
    ///
    /// `fetch_update` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// প্রথমটি যখন অপারেশন শেষ পর্যন্ত সফল হয় তার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে যখন দ্বিতীয়টি বোঝার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// এগুলি যথাক্রমে [`AtomicBool::compare_exchange`] এর সাফল্য এবং ব্যর্থতার সাথে মিল রয়েছে correspond
    ///
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে চূড়ান্ত সফল বোঝা [`Relaxed`] তৈরি করে।
    /// এক্স02 এক্স লোড অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা `u8` এ পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// একটি নতুন এক্স 100 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// অন্তর্নিহিত পয়েন্টারটিতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// এটি নিরাপদ কারণ পরিবর্তনীয় রেফারেন্স গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সাথে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// একটি পয়েন্টারে পারমাণবিক অ্যাক্সেস পান।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - পরিবর্তনীয় রেফারেন্স অনন্য মালিকানার গ্যারান্টি দেয়।
        //  - উপরে0 যাচাই করা হিসাবে, rust দ্বারা সমর্থিত সমস্ত প্ল্যাটফর্মগুলিতে `*mut T` এবং `Self` এর সারিবদ্ধতা একই।
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// পারমাণবিক গ্রহণ করে এবং এতে থাকা মানটি প্রদান করে।
    ///
    /// এটি নিরাপদ কারণ মান দ্বারা `self` পাস করা গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সঙ্গে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// পয়েন্টার থেকে একটি মান লোড।
    ///
    /// `load` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// সম্ভাব্য মানগুলি হল [`SeqCst`], [`Acquire`] এবং [`Relaxed`]।
    ///
    /// # Panics
    ///
    /// `order` যদি [`Release`] বা [`AcqRel`] হয় তবে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// পয়েন্টারে একটি মান সঞ্চয় করে।
    ///
    /// `store` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// সম্ভাব্য মানগুলি হল [`SeqCst`], [`Release`] এবং [`Relaxed`]।
    ///
    /// # Panics
    ///
    /// `order` যদি [`Acquire`] বা [`AcqRel`] হয় তবে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// পূর্বের মানটি ফেরত দিয়ে পয়েন্টারে একটি মান সঞ্চয় করে।
    ///
    /// `swap` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
    /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
    ///
    ///
    /// **Note:** এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পয়েন্টারগুলিতে পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে পয়েন্টারে একটি মান সঞ্চয় করে।
    ///
    /// রিটার্ন মান সর্বদা পূর্ববর্তী মান।এটি যদি `current` এর সমান হয় তবে মানটি আপডেট করা হয়েছিল।
    ///
    /// `compare_and_swap` এছাড়াও একটি [`Ordering`] আর্গুমেন্ট নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
    /// লক্ষ করুন যে [`AcqRel`] ব্যবহার করার সময়ও, অপারেশনটি ব্যর্থ হতে পারে এবং তাই কেবল একটি `Acquire` লোড সঞ্চালন করতে পারে, তবে এক্স02 এক্স শব্দার্থতত্ত্ব নেই।
    /// [`Acquire`] ব্যবহার করে স্টোরটি এই অপারেশনের অংশ হয়ে যায় [`Relaxed`] যদি এটি ঘটে থাকে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] করে তোলে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পয়েন্টারগুলিতে পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # `compare_exchange` এবং `compare_exchange_weak` এ স্থানান্তরিত হচ্ছে
    ///
    /// `compare_and_swap` মেমরি ক্রমগুলির জন্য নিম্নলিখিত ম্যাপিংয়ের সাথে `compare_exchange` এর সমতুল্য:
    ///
    /// আসল |সাফল্য |ব্যর্থতা
    /// -------- | ------- | -------
    /// স্বচ্ছন্দ |স্বচ্ছন্দ |স্বাচ্ছন্দ্য অর্জন |অর্জন |রিলিজ অর্জন |মুক্তি |রিলাক্সড অ্যাকিউরেল |AcqRel |সিকসিস্ট অর্জন করুন |সিকসিস্ট |সিকসিস্ট
    ///
    /// `compare_exchange_weak` তুলনা সফল হওয়ার পরেও তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যা তুলনামূলক এবং অদলবদলটি একটি লুপে ব্যবহার করার সময় সংকলকটি আরও ভাল সমাবেশ কোড তৈরি করতে দেয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে পয়েন্টারে একটি মান সঞ্চয় করে।
    ///
    /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
    /// সাফল্যে এই মানটি `current` এর সমান হওয়ার গ্যারান্টিযুক্ত।
    ///
    /// `compare_exchange` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
    ///
    /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পয়েন্টারগুলিতে পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// যদি বর্তমান মান `current` মানের সমান হয় তবে পয়েন্টারে একটি মান সঞ্চয় করে।
    ///
    /// এক্স 100 এক্স এর বিপরীতে, তুলনা সফল হওয়ার পরেও এই ফাংশনটিকে তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যার ফলস্বরূপ কিছু প্ল্যাটফর্মগুলিতে আরও কার্যকর কোড তৈরি হতে পারে।
    ///
    /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
    ///
    /// `compare_exchange_weak` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
    /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পয়েন্টারগুলিতে পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // নিরাপত্তা: এই অভ্যন্তরীণটি অনিরাপদ কারণ এটি একটি কাঁচা পয়েন্টারটিতে কাজ করে
        // তবে আমরা নিশ্চিতভাবেই জানি যে পয়েন্টারটি বৈধ কিনা (আমরা কেবলমাত্র এটি রেফারেন্স অনুসারে একটি `UnsafeCell` থেকে পেয়েছি) এবং পারমাণবিক ক্রিয়াকলাপটি আমাদের `UnsafeCell` সামগ্রীগুলি নিরাপদে রূপান্তর করতে দেয়।
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// মানটি নিয়ে আসে এবং এটিতে একটি ফাংশন প্রয়োগ করে যা একটি alচ্ছিক নতুন মান দেয়।যদি ফাংশনটি `Some(_)`, অন্যথায় `Err(previous_value)` প্রদান করে তবে `Ok(previous_value)` এর একটি `Result` প্রদান করে।
    ///
    /// Note: যদি এই সময়ের মধ্যে অন্য থ্রেড থেকে মান পরিবর্তন করা হয় তবে এটি ফাংশনটিকে একাধিকবার কল করতে পারে, যতক্ষণ না ফাংশনটি `Some(_)` প্রদান করে, তবে ফাংশনটি কেবলমাত্র একবার সঞ্চিত মানটিতে প্রয়োগ করা হবে।
    ///
    ///
    /// `fetch_update` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
    /// প্রথমটি যখন অপারেশন শেষ পর্যন্ত সফল হয় তার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে যখন দ্বিতীয়টি বোঝার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে।
    /// এগুলি যথাক্রমে [`AtomicPtr::compare_exchange`] এর সাফল্য এবং ব্যর্থতার সাথে মিল রয়েছে correspond
    ///
    /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে চূড়ান্ত সফল বোঝা [`Relaxed`] তৈরি করে।
    /// এক্স02 এক্স লোড অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
    ///
    /// **Note:** এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পয়েন্টারগুলিতে পারমাণবিক ক্রিয়াকলাপ সমর্থন করে।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` কে `AtomicBool` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // এই ম্যাক্রোটি কিছু আর্কিটেকচারে অব্যবহৃত হয়ে পড়েছে।
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// একটি পূর্ণসংখ্যা টাইপ যা থ্রেডগুলির মধ্যে নিরাপদে ভাগ করা যায়।
        ///
        /// এই ধরণের অন্তর্নিহিত পূর্ণসংখ্যার প্রকারের মতো মেমরির উপস্থাপনা রয়েছে, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// পারমাণবিক ধরণের এবং অ-পারমাণবিক ধরণের মধ্যে পার্থক্য এবং এই ধরণের বহনযোগ্যতা সম্পর্কে আরও তথ্যের জন্য, দয়া করে [module-level documentation] দেখুন।
        ///
        ///
        /// **Note:** এই ধরণের কেবল প্ল্যাটফর্মগুলিতে উপলভ্য যা পারমাণবিক লোড এবং [of এর স্টোরগুলিকে সমর্থন করে `
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// একটি পারমাণবিক পূর্ণসংখ্যা `0` এ আরম্ভ হয়।
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // প্রেরণ সুস্পষ্টভাবে কার্যকর করা হয়েছে।
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// একটি নতুন পারমাণবিক পূর্ণসংখ্যা তৈরি করে।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// অন্তর্নিহিত পূর্ণসংখ্যার একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
            ///
            /// এটি নিরাপদ কারণ পরিবর্তনীয় রেফারেন্স গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সাথে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// কিছু মিট করা যাক_ 123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (কিছু_শব্দ, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - পরিবর্তনীয় রেফারেন্স অনন্য মালিকানার গ্যারান্টি দেয়।
                //  - `$int_type` এবং `Self` এর প্রান্তিককরণ একই, $cfg_align দ্বারা প্রতিশ্রুতি দেওয়া এবং উপরে যাচাই করা হয়েছে।
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// পারমাণবিক গ্রহণ করে এবং এতে থাকা মানটি প্রদান করে।
            ///
            /// এটি নিরাপদ কারণ মান দ্বারা `self` পাস করা গ্যারান্টি দেয় যে অন্য কোনও থ্রেড একই সঙ্গে পারমাণবিক ডেটা অ্যাক্সেস করছে না।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// পারমাণবিক পূর্ণসংখ্যা থেকে একটি মান লোড করে।
            ///
            /// `load` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
            /// সম্ভাব্য মানগুলি হল [`SeqCst`], [`Acquire`] এবং [`Relaxed`]।
            ///
            /// # Panics
            ///
            /// `order` যদি [`Release`] বা [`AcqRel`] হয় তবে Panics।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// পারমাণবিক পূর্ণসংখ্যার মধ্যে একটি মান সঞ্চয় করে।
            ///
            /// `store` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
            ///  সম্ভাব্য মানগুলি হল [`SeqCst`], [`Release`] এবং [`Relaxed`]।
            ///
            /// # Panics
            ///
            /// `order` যদি [`Acquire`] বা [`AcqRel`] হয় তবে Panics।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// পূর্বের মানটি ফেরত দিয়ে পারমাণবিক পূর্ণসংখ্যায় একটি মান সঞ্চয় করে।
            ///
            /// `swap` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// যদি বর্তমান মানটি `current` মানের সমান হয় তবে পারমাণবিক পূর্ণসংখ্যায় একটি মান সঞ্চয় করে।
            ///
            /// রিটার্ন মান সর্বদা পূর্ববর্তী মান।এটি যদি `current` এর সমান হয় তবে মানটি আপডেট করা হয়েছিল।
            ///
            /// `compare_and_swap` এছাড়াও একটি [`Ordering`] আর্গুমেন্ট নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।
            /// লক্ষ করুন যে [`AcqRel`] ব্যবহার করার সময়ও, অপারেশনটি ব্যর্থ হতে পারে এবং তাই কেবল একটি `Acquire` লোড সঞ্চালন করতে পারে, তবে এক্স02 এক্স শব্দার্থতত্ত্ব নেই।
            ///
            /// [`Acquire`] ব্যবহার করে স্টোরটি এই অপারেশনের অংশ হয়ে যায় [`Relaxed`] যদি এটি ঘটে থাকে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] করে তোলে।
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` এবং `compare_exchange_weak` এ স্থানান্তরিত হচ্ছে
            ///
            /// `compare_and_swap` মেমরি ক্রমগুলির জন্য নিম্নলিখিত ম্যাপিংয়ের সাথে `compare_exchange` এর সমতুল্য:
            ///
            /// আসল |সাফল্য |ব্যর্থতা
            /// -------- | ------- | -------
            /// স্বচ্ছন্দ |স্বচ্ছন্দ |স্বাচ্ছন্দ্য অর্জন |অর্জন |রিলিজ অর্জন |মুক্তি |রিলাক্সড অ্যাকিউরেল |AcqRel |সিকসিস্ট অর্জন করুন |সিকসিস্ট |সিকসিস্ট
            ///
            /// `compare_exchange_weak` তুলনা সফল হওয়ার পরেও তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যা তুলনামূলক এবং অদলবদলটি একটি লুপে ব্যবহার করার সময় সংকলকটি আরও ভাল সমাবেশ কোড তৈরি করতে দেয়।
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// যদি বর্তমান মানটি `current` মানের সমান হয় তবে পারমাণবিক পূর্ণসংখ্যায় একটি মান সঞ্চয় করে।
            ///
            /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
            /// সাফল্যে এই মানটি `current` এর সমান হওয়ার গ্যারান্টিযুক্ত।
            ///
            /// `compare_exchange` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
            /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
            /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
            /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
            ///
            /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// যদি বর্তমান মানটি `current` মানের সমান হয় তবে পারমাণবিক পূর্ণসংখ্যায় একটি মান সঞ্চয় করে।
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// তুলনা সফল হওয়ার পরেও এই ফাংশনটিকে তাত্পর্যপূর্ণভাবে ব্যর্থ হওয়ার অনুমতি দেওয়া হয়েছে, যার ফলস্বরূপ কিছু প্ল্যাটফর্মগুলিতে আরও কার্যকর কোড তৈরি হতে পারে।
            /// রিটার্ন মানটি এমন একটি ফলাফল যা নতুন মানটি লেখা হয়েছিল এবং পূর্ববর্তী মানটি ছিল কিনা তা নির্দেশ করে।
            ///
            /// `compare_exchange_weak` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
            /// `success` এক্স-00 এক্সের সাথে তুলনা সফল হলে স্থানান্তরিত রিড-মডিফাই-রাইটিং অপারেশনের প্রয়োজনীয় ক্রমটি বর্ণনা করে।
            /// `failure` তুলনা ব্যর্থ হলে সঞ্চালিত লোড অপারেশনের জন্য প্রয়োজনীয় ক্রমটির বর্ণনা দেয়।
            /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে সফল লোডকে [`Relaxed`] তৈরি করে।
            ///
            /// ব্যর্থতার অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// চলুন মিট পুরানো= val.load(Ordering::Relaxed);
            /// লুপ {নতুন নতুন=পুরানো * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } match ম্যাচ করুন
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// পূর্ববর্তী মানটি ফেরত দিয়ে বর্তমান মান যুক্ত করে।
            ///
            /// এই অপারেশনটি ওভারফ্লোতে প্রায় আবৃত।
            ///
            /// `fetch_add` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// পূর্ববর্তী মানটি ফেরত দিয়ে বর্তমান মান থেকে বিয়োগ করে।
            ///
            /// এই অপারেশনটি ওভারফ্লোতে প্রায় আবৃত।
            ///
            /// `fetch_sub` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// বর্তমান মান সহ বিটওয়াস এক্স00 এক্স।
            ///
            /// বর্তমান মান এবং আর্গুমেন্ট `val` এর উপরে কিছুদূর থেকে "and" অপারেশন সম্পাদন করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_and` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// বর্তমান মান সহ বিটওয়াস এক্স00 এক্স।
            ///
            /// বর্তমান মান এবং আর্গুমেন্ট `val` এর উপরে কিছুদূর থেকে "nand" অপারেশন সম্পাদন করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_nand` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// বর্তমান মান সহ বিটওয়াস এক্স00 এক্স।
            ///
            /// বর্তমান মান এবং আর্গুমেন্ট `val` এর উপরে কিছুদূর থেকে "or" অপারেশন সম্পাদন করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_or` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// বর্তমান মান সহ বিটওয়াস এক্স00 এক্স।
            ///
            /// বর্তমান মান এবং আর্গুমেন্ট `val` এর উপরে কিছুদূর থেকে "xor" অপারেশন সম্পাদন করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_xor` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// মানটি নিয়ে আসে এবং এটিতে একটি ফাংশন প্রয়োগ করে যা একটি alচ্ছিক নতুন মান দেয়।যদি ফাংশনটি `Some(_)`, অন্যথায় `Err(previous_value)` প্রদান করে তবে `Ok(previous_value)` এর একটি `Result` প্রদান করে।
            ///
            /// Note: যদি এই সময়ের মধ্যে অন্য থ্রেড থেকে মান পরিবর্তন করা হয় তবে এটি ফাংশনটিকে একাধিকবার কল করতে পারে, যতক্ষণ না ফাংশনটি `Some(_)` প্রদান করে, তবে ফাংশনটি কেবলমাত্র একবার সঞ্চিত মানটিতে প্রয়োগ করা হবে।
            ///
            ///
            /// `fetch_update` এই ক্রিয়াকলাপের মেমরি ক্রম বর্ণনা করতে দুটি এক্স00 এক্স আর্গুমেন্ট নেয়।
            /// প্রথমটি যখন অপারেশন শেষ পর্যন্ত সফল হয় তার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে যখন দ্বিতীয়টি বোঝার জন্য প্রয়োজনীয় ক্রমটি বর্ণনা করে।এগুলির সাফল্য এবং ব্যর্থতার অর্ডারের সাথে সামঞ্জস্য
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// সাফল্যের ক্রম হিসাবে [`Acquire`] ব্যবহার করা দোকানটিকে এই ক্রিয়াকলাপটিকে [`Relaxed`] করে তোলে এবং [`Release`] ব্যবহার করে চূড়ান্ত সফল বোঝা [`Relaxed`] তৈরি করে।
            /// এক্স02 এক্স লোড অর্ডারিংটি কেবলমাত্র [`SeqCst`], [`Acquire`] বা [`Relaxed`] হতে পারে এবং সাফল্যের আদেশের তুলনায় সমান বা দুর্বল হতে হবে।
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (অর্ডারিং: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (অর্ডারিং: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// বর্তমান মান সহ সর্বাধিক।
            ///
            /// সর্বাধিক বর্তমান মান এবং যুক্তি `val` সন্ধান করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_max` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// চলুন বার=42;
            /// সর্বোচ্চ_ফু=foo.fetch_max (বার, Ordering::SeqCst).max(bar);
            /// জোর দেওয়া! (সর্বোচ্চ_ফু==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// বর্তমান মান সহ সর্বনিম্ন।
            ///
            /// বর্তমান মান এবং যুক্তি `val` এর সর্বনিম্ন সন্ধান করে এবং ফলাফলটিতে নতুন মান সেট করে।
            ///
            /// পূর্ববর্তী মান প্রদান করে।
            ///
            /// `fetch_min` একটি [`Ordering`] যুক্তি নেয় যা এই অপারেশনের মেমরির ক্রম বর্ণনা করে।সমস্ত ক্রম মোড সম্ভব।
            /// দ্রষ্টব্য যে [`Acquire`] ব্যবহার করে দোকানটি এই ক্রিয়াকলাপটিকে [`Relaxed`] তৈরি করে এবং [`Release`] ব্যবহার করে লোড অংশটি [`Relaxed`] তৈরি করে।
            ///
            ///
            /// **দ্রষ্টব্য**: এই পদ্ধতিটি কেবলমাত্র প্ল্যাটফর্মগুলিতে উপলব্ধ যা পরমাণু ক্রিয়াকলাপ সমর্থন করে support
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// চলুন বার=12;
            /// মিনিট_ফু=foo.fetch_min (বার, Ordering::SeqCst).min(bar);
            /// assert_eq! (মিনিট_ফু, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // নিরাপদ: ডেটা রেসগুলি পারমাণবিক অভ্যন্তরীণ দ্বারা প্রতিরোধ করা হয়।
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// অন্তর্নিহিত পূর্ণসংখ্যায় একটি পরিবর্তনীয় পয়েন্টার ফেরত দেয়।
            ///
            /// ফলস্বরূপ পূর্ণসংখ্যায় অ-পরমাণু পাঠ এবং লেখালেখি করা একটি ডেটা রেস হতে পারে।
            /// এই পদ্ধতিটি বেশিরভাগ এফএফআইয়ের জন্য দরকারী, যেখানে ফাংশনের স্বাক্ষর ব্যবহার করতে পারে
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// এই পারমাণবিকের সাথে ভাগ করা রেফারেন্স থেকে একটি `*mut` পয়েন্টার ফিরিয়ে দেওয়া নিরাপদ কারণ পারমাণবিক ধরণের অভ্যন্তরীণ পরিবর্তনের সাথে কাজ করে।
            /// পারমাণবিক সমস্ত পরিবর্তন একটি ভাগ করা রেফারেন্সের মাধ্যমে মান পরিবর্তন করে এবং যতক্ষণ না তারা পারমাণবিক ক্রিয়াকলাপ ব্যবহার করে ততক্ষণ নিরাপদে তা করতে পারে।
            /// প্রত্যাবর্তিত কাঁচা পয়েন্টারটির যে কোনও ব্যবহারের জন্য একটি `unsafe` ব্লক প্রয়োজন এবং এখনও একই বিধিনিষেধ বহাল রাখতে হবে: এটির ক্রিয়াকলাপগুলি অবশ্যই পারমাণবিক হতে হবে।
            ///
            ///
            /// # Examples
            ///
            /// আপনি (extern-declaration) উপেক্ষা করুন
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// বাহ্যিক "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // সুরক্ষা: যতক্ষণ না `my_atomic_op` পারমাণবিক হয় ততক্ষণ নিরাপদ।
            /// অনিরাপদ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_store` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_load` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_swap` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// পূর্ববর্তী মানটি (যেমন __ sync_fetch_and_add) প্রদান করে।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_add` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// পূর্ববর্তী মানটি দেয় (যেমন __ sync_fetch_and_sub)।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_sub` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_compare_exchange` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_compare_exchange_weak` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_and` এর সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_nand` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_or` এর সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_xor` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// সর্বোচ্চ মান প্রদান করে (স্বাক্ষরিত তুলনা)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_max` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ন্যূনতম মান ফেরত দেয় (স্বাক্ষরিত তুলনা)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_min` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// সর্বাধিক মান প্রদান করে (স্বাক্ষরযুক্ত তুলনা)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_umax` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ন্যূনতম মান (স্বাক্ষরবিহীন তুলনা) প্রদান করে
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // সুরক্ষা: কলকারীকে অবশ্যই `atomic_umin` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// একটি পারমাণবিক বেড়া।
///
/// নির্দিষ্ট অর্ডারের উপর নির্ভর করে একটি বেড়া সংকলক এবং সিপিইউকে চারপাশে নির্দিষ্ট ধরণের মেমরি ক্রিয়াকলাপ পুনরুদ্ধার করতে বাধা দেয়।
/// এটি এর সাথে পারমাণবিক ক্রিয়াকলাপ বা অন্যান্য থ্রেডের বেড়াগুলির মধ্যে সংযোগ স্থাপন করে।
///
/// একটি বেড়া 'A' যার (কমপক্ষে) [`Release`] ক্রমান্বিত শব্দার্থ রয়েছে, একটি বেড়া 'B' এর সাথে কমপক্ষে [`Acquire`] শব্দার্থবিজ্ঞানের সাথে সিঙ্ক্রোনাইজ করে, যদি এবং কেবল অপারেশন এক্স এবং ওয়াই উপস্থিত থাকে তবে উভয়ই কিছু পরমাণু অবজেক্ট 'M' এ অপারেটিং করে যেমন A এর আগে ক্রমযুক্ত হয় এক্স, ওয়াই বি এবং এম এর পরিবর্তন পর্যবেক্ষণ করার আগে সিঙ্ক্রোনাইজ করা হয় is
/// এটি এ এবং বি এর মধ্যে পূর্বের নির্ভরতা সরবরাহ করে provides
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] বা [`Acquire`] শব্দার্থবিজ্ঞানের সাথে পারমাণবিক ক্রিয়াকলাপগুলি একটি বেড়া দিয়ে সিঙ্ক্রোনাইজ করতে পারে।
///
/// X0 [`Acquire`] এবং [`Release`] উভয় শব্দার্থক ব্যতীত [`SeqCst`] অর্ডারযুক্ত একটি বেড়া অন্যান্য [`SeqCst`] ক্রিয়াকলাপ এবং/অথবা বেড়াগুলির গ্লোবাল প্রোগ্রাম ক্রমে অংশ নেয়।
///
/// [`Acquire`], [`Release`], [`AcqRel`] এবং [`SeqCst`] ক্রম গ্রহণ করে।
///
/// # Panics
///
/// `order` যদি [`Relaxed`] হয় তবে Panics।
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // স্পিনলকের উপর ভিত্তি করে একটি পারস্পরিক বর্জন আদিম।
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // পুরানো মানটি `false` না হওয়া পর্যন্ত অপেক্ষা করুন।
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // এই বেড়াটি `unlock` এ স্টোর সহ সিঙ্ক্রোনাইজ করে।
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // সুরক্ষা: পারমাণবিক বেড়া ব্যবহার করা নিরাপদ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// একটি সংকলক মেমরি বেড়া।
///
/// `compiler_fence` কোনও মেশিন কোড নির্গত করে না, তবে কম্পাইলারকে পুনরায় অর্ডার করার মেমরির ধরণগুলি সীমাবদ্ধ করে।বিশেষত, প্রদত্ত [`Ordering`] শব্দার্থবিজ্ঞানের উপর নির্ভর করে, সংকলকটি `compiler_fence`-এ কলটির অন্যদিকে ডাকের আগে বা পরে পড়া পাঠানো বা লিখতে নিষেধ করা যেতে পারে।মনে রাখবেন যে এটি **নয়***হার্ডওয়্যারকে* এ জাতীয় পুনঃ-ক্রম করতে বাধা দেয়।
///
/// এটি একক থ্রেডেড, এক্সিকিউশন প্রসঙ্গে কোনও সমস্যা নয়, তবে যখন অন্য থ্রেডগুলি একই সময়ে মেমরিটি সংশোধন করতে পারে, তখন [`fence`] এর মতো শক্তিশালী সিঙ্ক্রোনাইজেশন আদিমগুলির প্রয়োজন হয়।
///
/// পুনঃ-ক্রমটি বিভিন্ন অর্ডারিং শব্দার্থক দ্বারা প্রতিরোধ করা হয়:
///
///  - [`SeqCst`] এর সাহায্যে, এই বিন্দু জুড়ে পঠন এবং লেখার কোনও পুনরায় অর্ডার করার অনুমতি নেই।
///  - [`Release`] এর সাহায্যে পূর্ববর্তী পড়া এবং লেখাগুলি পরবর্তী লেখাগুলি সরানো যায় না।
///  - [`Acquire`] এর সাথে, পরবর্তী পাঠগুলি এবং লেখাগুলি পূর্ববর্তী পাঠগুলির আগে সরিয়ে নেওয়া যায় না।
///  - [`AcqRel`] এর সাহায্যে উপরোক্ত দুটি বিধিই প্রয়োগ করা হয়েছে।
///
/// `compiler_fence` সাধারণত * থ্রেডকে নিজের সাথে রেসিং করা থেকে বিরত রাখতে শুধুমাত্র কার্যকর।এটি, যদি কোনও প্রদত্ত থ্রেড কোডের এক টুকরা কার্যকর করে, এবং তারপরে বাধাগ্রস্ত হয় এবং অন্য কোথাও কোড চালানো শুরু করে (একই থ্রেডে থাকা অবস্থায় এবং ধারণাটি এখনও একই মূল অংশে থাকে)।Traditionalতিহ্যবাহী প্রোগ্রামগুলিতে, এটি কেবল তখনই ঘটতে পারে যখন কোনও সিগন্যাল হ্যান্ডলার নিবন্ধিত হয়।
/// আরও নিম্ন-স্তরের কোডে, বাধা পরিচালনা করার সময়, প্রাক-উত্সাহ সহ সবুজ থ্রেড প্রয়োগ করার সময়ও এ জাতীয় পরিস্থিতি দেখা দিতে পারে etc.
/// কৌতূহলী পাঠকরা [memory barriers] এক্স কার্নেলের [memory barriers] আলোচনাটি পড়তে উত্সাহিত হন।
///
/// # Panics
///
/// `order` যদি [`Relaxed`] হয় তবে Panics।
///
/// # Examples
///
/// `compiler_fence` ব্যতীত নিম্নলিখিত কোডটিতে `assert_eq!` * একক থ্রেডে সব কিছু সত্ত্বেও, সফল হওয়ার গ্যারান্টিযুক্ত নয়।
/// কেন তা দেখতে, মনে রাখবেন যে সংকলকগুলি `IMPORTANT_VARIABLE` এবং `IS_READ` এ স্টোরগুলি অদলবদল করতে পারছে কারণ তারা উভয়ই `Ordering::Relaxed`।যদি এটি হয় এবং এক্স05 এক্স আপডেট হওয়ার ঠিক পরে সিগন্যাল হ্যান্ডলারটি আহ্বান করা হয়, তবে সিগন্যাল হ্যান্ডলারটি `IS_READY=1` দেখতে পাবে, তবে `IMPORTANT_VARIABLE=0`।
/// এই পরিস্থিতিতে একটি `compiler_fence` প্রতিকার ব্যবহার করে।
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // আগের লেখাগুলি এই বিন্দু অতিক্রম করা থেকে আটকাতে
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // সুরক্ষা: পারমাণবিক বেড়া ব্যবহার করা নিরাপদ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// প্রসেসরের সিগন্যাল দেয় যে এটি একটি ব্যস্ত-অপেক্ষা স্পিন-লুপের ভিতরে ("স্পিন লক")।
///
/// এই ফাংশনটি [`hint::spin_loop`] এর পক্ষে অবমূল্যায়ন করা হয়েছে।
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}