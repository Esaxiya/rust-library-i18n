//! এই মডিউলটি `Any` trait প্রয়োগ করে, যা রানটাইম প্রতিবিম্বের মাধ্যমে কোনও এক্স01 এক্স প্রকারের গতিশীল টাইপিং সক্ষম করে।
//!
//! `Any` নিজেই একটি `TypeId` পেতে ব্যবহার করা যেতে পারে এবং যখন trait অবজেক্ট হিসাবে ব্যবহৃত হয় তখন আরও বৈশিষ্ট্য রয়েছে।
//! `&dyn Any` হিসাবে (ধার নেওয়া trait অবজেক্ট), এতে রয়েছে `is` এবং `downcast_ref` পদ্ধতি, অন্তর্ভুক্ত মানটি একটি নির্দিষ্ট ধরণের কিনা তা পরীক্ষা করে দেখার জন্য এবং একটি ধরণের হিসাবে অভ্যন্তরীণ মানটির একটি রেফারেন্স পেতে।
//! `&mut dyn Any` হিসাবে, অভ্যন্তরীণ মানের একটি পরিবর্তনীয় রেফারেন্স পাওয়ার জন্য, `downcast_mut` পদ্ধতিও রয়েছে।
//! `Box<dyn Any>` `downcast` পদ্ধতি যুক্ত করে, যা একটি `Box<T>` এ রূপান্তরিত করার চেষ্টা করে।
//! সম্পূর্ণ বিবরণের জন্য [`Box`] ডকুমেন্টেশন দেখুন।
//!
//! নোট করুন যে `&dyn Any` মান নির্দিষ্ট কংক্রিটের ধরণের কিনা তা পরীক্ষার মধ্যে সীমাবদ্ধ এবং কোনও প্রকার একটি trait প্রয়োগ করে কিনা তা পরীক্ষা করতে ব্যবহার করা যাবে না।
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # স্মার্ট পয়েন্টার এবং এক্স 100 এক্স
//!
//! `Any` কে trait অবজেক্ট হিসাবে ব্যবহার করার সময় এক ধরণের আচরণের কথা মনে রাখা, বিশেষত `Box<dyn Any>` বা `Arc<dyn Any>` এর মতো ধরণের সাথে, কেবলমাত্র মানকে `.type_id()` কল করা *ধারক* এর `TypeId` উত্পাদন করে, অন্তর্নিহিত trait অবজেক্টটি নয়।
//!
//! এর পরিবর্তে স্মার্ট পয়েন্টারটিকে `&dyn Any` এ রূপান্তর করে এড়ানো যায়, যা বস্তুর `TypeId` প্রদান করবে।
//! উদাহরণ স্বরূপ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // আপনি এটি চান সম্ভবত:
//! let actual_id = (&*boxed).type_id();
//! // ... এই তুলনায়:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! এমন একটি পরিস্থিতি বিবেচনা করুন যেখানে আমরা কোনও ফাংশনে প্রদত্ত একটি মান লগ আউট করতে চাই।
//! আমরা প্রয়োগের ডিবাগের উপর যে মূল্য নিয়ে কাজ করছি তা আমরা জানি তবে আমরা এর কংক্রিটের প্রকারটি জানি না।আমরা নির্দিষ্ট ধরণেরগুলিতে বিশেষ চিকিত্সা দিতে চাই: এই ক্ষেত্রে স্ট্রিং মানগুলির দৈর্ঘ্যের পূর্বে প্রিন্টিং আউট করে।
//! সংকলনের সময় আমরা আমাদের মূল্যের কংক্রিট প্রকারটি জানি না, সুতরাং পরিবর্তে আমাদের রানটাইম প্রতিবিম্বটি ব্যবহার করা দরকার।
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ডিবাগ প্রয়োগ করে এমন যে কোনও ধরণের লগার ফাংশন।
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // আমাদের মানকে একটি `String` এ রূপান্তর করার চেষ্টা করুন।
//!     // যদি সফল হয় তবে আমরা স্ট্রিংয়ের দৈর্ঘ্যের পাশাপাশি এর মানও আউটপুট করতে চাই।
//!     // যদি তা না হয় তবে এটি অন্যরকম: কেবল অযৌক্তিকভাবে এটি মুদ্রণ করুন।
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // এই ফাংশনটি এর সাথে কাজ করার আগে এর পরামিতিটি লগ আউট করতে চায়।
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... অন্য কিছু কাজ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// যে কোনও trait
///////////////////////////////////////////////////////////////////////////////

/// গতিশীল টাইপ অনুকরণ করার জন্য একটি trait।
///
/// বেশিরভাগ ধরণের এক্স00 এক্স প্রয়োগ করে implementযাইহোক, কোনও প্রকারের মধ্যে একটি অ-স্ট্যাটিক` রেফারেন্স রয়েছে।
/// আরও তথ্যের জন্য [module-level documentation][mod] দেখুন।
///
/// [mod]: crate::any
// এই trait অনিরাপদ নয়, যদিও আমরা অনিরাপদ কোডে (যেমন, `downcast`) এর একমাত্র ইমপ্লের এক্স01 এক্স ফাংশনের নির্দিষ্টকরণের উপর নির্ভর করি।সাধারণত, এটি একটি সমস্যা হতে পারে, তবে যেহেতু `Any` এর একমাত্র ইমপ্লিটটি একটি কম্বল বাস্তবায়ন, অন্য কোনও কোড `Any` প্রয়োগ করতে পারে না।
//
// আমরা এই trait টিকে অনিরাপদভাবে বানাতে পারি-এটি বিরতি সৃষ্টি করে না, যেহেতু আমরা সমস্ত বাস্তবায়ন নিয়ন্ত্রণ করি-তবে আমরা উভয়ই সত্যই প্রয়োজনীয় নয় এবং এটি অনিরাপদ traits এবং অনিরাপদ পদ্ধতির পার্থক্য সম্পর্কে বিভ্রান্ত করতে পারি (যেমন, এক্স00 এক্স কল করা এখনও নিরাপদ থাকবে, তবে আমরা সম্ভবত ডকুমেন্টেশনে ইঙ্গিত করতে চাই।
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` এর `TypeId` পায়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// যে কোনও trait বস্তুর জন্য এক্সটেনশন পদ্ধতি।
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// নিশ্চিত করুন যে উদাহরণস্বরূপ, কোনও থ্রেডে যোগদানের ফলাফল মুদ্রিত হতে পারে এবং তাই এটি `unwrap` এর সাথে ব্যবহার করা যেতে পারে।
// প্রেরণ আপকাস্টিংয়ের সাথে কাজ করলে অবশেষে আর প্রয়োজন হবে না।
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// বক্সযুক্ত প্রকারটি `T` এর সমান হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // এই ফাংশনটি দিয়ে ধরণের প্রকারের `TypeId` পান।
        let t = TypeId::of::<T>();

        // trait অবজেক্ট (`self`) এ টাইপের `TypeId` পান।
        let concrete = self.type_id();

        // উভয় `টাইপআইডি'র সাথে সমতার তুলনা করুন।
        t == concrete
    }

    /// `T` টাইপ হলে বাক্সযুক্ত মানটির জন্য কিছু রেফারেন্স, বা এটি যদি না হয় তবে `None` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // নিরাপত্তা: আমরা সঠিক ধরণের দিকে ইশারা করছি কিনা তা সবেমাত্র যাচাই করা হয়েছে এবং আমরা নির্ভর করতে পারি
            // যা মেমরির সুরক্ষার জন্য যাচাই করে কারণ আমরা সকল প্রকারের জন্য যে কোনওটিকে প্রয়োগ করেছি;অন্য ইমপ্লের অস্তিত্ব থাকতে পারে না কারণ তারা আমাদের ইমপ্লের সাথে বিরোধ করে।
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// `T` টাইপ হলে বাক্সযুক্ত মানটির জন্য কিছু পরিবর্তনীয় রেফারেন্স প্রদান করে বা এটি যদি `None` না হয় Return
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // নিরাপত্তা: আমরা সঠিক ধরণের দিকে ইশারা করছি কিনা তা সবেমাত্র যাচাই করা হয়েছে এবং আমরা নির্ভর করতে পারি
            // যা মেমরির সুরক্ষার জন্য যাচাই করে কারণ আমরা সকল প্রকারের জন্য যে কোনওটিকে প্রয়োগ করেছি;অন্য ইমপ্লের অস্তিত্ব থাকতে পারে না কারণ তারা আমাদের ইমপ্লের সাথে বিরোধ করে।
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` প্রকারে সংজ্ঞায়িত পদ্ধতির দিকে এগিয়ে For
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// টাইপআইডি এবং এর পদ্ধতিগুলি
///////////////////////////////////////////////////////////////////////////////

/// একটি এক্স00 এক্স কোনও ধরণের জন্য বিশ্বব্যাপী অনন্য সনাক্তকারীকে উপস্থাপন করে।
///
/// প্রতিটি এক্স 100 এক্স একটি অস্বচ্ছ অবজেক্ট যা ভিতরে কী আছে তা পরিদর্শন করার অনুমতি দেয় না তবে ক্লোনিং, তুলনা, মুদ্রণ এবং দেখানোর মতো মৌলিক ক্রিয়াকলাপকে অনুমতি দেয়।
///
///
/// একটি `TypeId` বর্তমানে কেবলমাত্র টাইপগুলির জন্য উপলভ্য যা `'static` হিসাবে সাবলীল, তবে এই সীমাবদ্ধতাটি future এ সরিয়ে দেওয়া যেতে পারে।
///
/// `TypeId` `Hash`, `PartialOrd` এবং `Ord` প্রয়োগ করে, হ্যাশগুলি এবং ক্রমটি Rust রিলিজের মধ্যে পরিবর্তিত হবে তা লক্ষণীয়।
/// আপনার কোডের ভিতরে তাদের উপর নির্ভর করার বিষয়ে সাবধান!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// এই জেনেরিক ফাংশনটি যার সাথে ইনস্ট্যান্ট করা হয়েছে তার `TypeId` প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// স্ট্রিং স্লাইস হিসাবে কোনও প্রকারের নাম দেয়।
///
/// # Note
///
/// এটি ডায়াগনস্টিক ব্যবহারের জন্য তৈরি।
/// স্ট্রিংটির সঠিক বিষয়বস্তু এবং ফর্ম্যাটটি নির্দিষ্ট করা হয়নি, অন্য ধরণের সেরা-প্রচেষ্টা বর্ণনা ছাড়া।
/// উদাহরণস্বরূপ, `type_name::<Option<String>>()` যে স্ট্রিংগুলি ফিরে আসতে পারে তার মধ্যে রয়েছে `"Option<String>"` এবং `"std::option::Option<std::string::String>"`।
///
///
/// প্রত্যাবর্তিত স্ট্রিংটি কোনও ধরণের অনন্য শনাক্তকারী হিসাবে বিবেচনা করা উচিত নয় কারণ একাধিক প্রকার একই ধরণের নামের সাথে ম্যাপ করতে পারে।
/// একইভাবে, কোনও ধরণের সমস্ত অংশ প্রত্যাবর্তিত স্ট্রিংয়ে উপস্থিত হবে এমন কোনও গ্যারান্টি নেই: উদাহরণস্বরূপ, আজীবন স্পেসিফায়ার বর্তমানে অন্তর্ভুক্ত নয়।
/// এছাড়াও, সংকলকটির সংস্করণগুলির মধ্যে আউটপুট পরিবর্তন হতে পারে।
///
/// বর্তমান বাস্তবায়ন সংকলক ডায়াগনস্টিকস এবং ডিবাগিনফো হিসাবে একই অবকাঠামো ব্যবহার করে, তবে এটির নিশ্চয়তা নেই।
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// স্ট্রিং স্লাইস হিসাবে পয়েন্ট-টু মানের প্রকারের নাম দেয়।
/// এটি `type_name::<T>()` এর সমান, তবে যেখানে ভেরিয়েবলের ধরণ সহজে পাওয়া যায় না সেখানে ব্যবহার করা যেতে পারে।
///
/// # Note
///
/// এটি ডায়াগনস্টিক ব্যবহারের জন্য তৈরি।স্ট্রিংয়ের সঠিক বিষয়বস্তু এবং ফর্ম্যাটটি নির্দিষ্ট করা হয়নি, অন্য ধরণের সেরা-প্রচেষ্টা বর্ণনা ছাড়া।
/// উদাহরণস্বরূপ, `type_name_of_val::<Option<String>>(None)` এক্স03 এক্স বা এক্স01 এক্স ফিরিয়ে দিতে পারে তবে এক্স 100 এক্স নয়।
///
/// এছাড়াও, সংকলকটির সংস্করণগুলির মধ্যে আউটপুট পরিবর্তন হতে পারে।
///
/// এই ফাংশনটি trait অবজেক্টগুলিকে সমাধান করে না, যার অর্থ `type_name_of_val(&7u32 as &dyn Debug)` এক্স01 এক্স ফিরে আসতে পারে তবে `"u32"` নয়।
///
/// প্রকারের নামটি কোনও প্রকারের একটি অনন্য সনাক্তকারী হিসাবে বিবেচনা করা উচিত নয়;
/// একাধিক প্রকার একই ধরণের নাম ভাগ করতে পারে।
///
/// বর্তমান বাস্তবায়ন সংকলক ডায়াগনস্টিকস এবং ডিবাগিনফো হিসাবে একই অবকাঠামো ব্যবহার করে, তবে এটির নিশ্চয়তা নেই।
///
/// # Examples
///
/// ডিফল্ট পূর্ণসংখ্যা এবং ভাসমান ধরণের মুদ্রণ করে।
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}