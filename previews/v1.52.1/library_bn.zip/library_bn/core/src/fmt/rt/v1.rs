//! এটি ifmt দ্বারা ব্যবহৃত অভ্যন্তরীণ মডিউল!রানটাইমএই কাঠামোগুলি স্ট্যাটিক অ্যারেগুলিকে সময়ের পূর্বে ফর্ম্যাট স্ট্রিংগুলিতে নির্গত হয়।
//!
//! এই সংজ্ঞাগুলি তাদের `ct` সমতুল্যের সমান, তবে এগুলির থেকে পৃথক হওয়া যায় যে এগুলি স্থিরভাবে বরাদ্দ করা যেতে পারে এবং রানটাইমের জন্য কিছুটা অনুকূলিত করা যায়
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ফরম্যাটিং নির্দেশের অংশ হিসাবে অনুরোধ করা যায় এমন সম্ভাব্য প্রান্তিককরণ।
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি বাম-সারিবদ্ধ হওয়া উচিত।
    Left,
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি ডান-প্রান্তিক হওয়া উচিত।
    Right,
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি কেন্দ্র-প্রান্তিক হওয়া উচিত।
    Center,
    /// কোনও প্রান্তিককরণের অনুরোধ করা হয়নি।
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) এবং [precision](https://doc.rust-lang.org/std/fmt/#precision) নির্দিষ্টকারী দ্বারা ব্যবহৃত।
#[derive(Copy, Clone)]
pub enum Count {
    /// আক্ষরিক সংখ্যার সাথে নির্দিষ্ট, মান সঞ্চয় করে stores
    Is(usize),
    /// `$` এবং `*` সিনট্যাক্স ব্যবহার করে নির্দিষ্ট করা, সূচকটি `args` এ সঞ্চয় করে
    Param(usize),
    /// উল্লিখিত না
    Implied,
}