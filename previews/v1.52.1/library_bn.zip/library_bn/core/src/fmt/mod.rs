//! ফর্ম্যাট এবং স্ট্রিং স্ট্রিংয়ের জন্য ইউটিলিটিস।

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// সম্ভাব্য প্রান্তিককরণগুলি `Formatter::align` দ্বারা ফিরে এসেছে
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি বাম-সারিবদ্ধ হওয়া উচিত।
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি ডান-প্রান্তিক হওয়া উচিত।
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ইঙ্গিত দেয় যে সামগ্রীগুলি কেন্দ্র-প্রান্তিক হওয়া উচিত।
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ধরণটি ফর্ম্যাটার পদ্ধতিতে ফিরে আসে।
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// কোনও ত্রুটির ধরণ যা কোনও বার্তাটিকে একটি স্ট্রিমে ফর্ম্যাট করে ফিরে আসে।
///
/// এই ধরণের কোনও ত্রুটি ঘটেছে তা বাদ দিয়ে অন্য কোনও ত্রুটি সংক্রমণকে সমর্থন করে না।
/// যে কোনও অতিরিক্ত তথ্য অন্য কোনও উপায়ে সঞ্চারিত করার ব্যবস্থা করতে হবে।
///
/// একটি গুরুত্বপূর্ণ বিষয় মনে রাখতে হবে তা হল `fmt::Error` টাইপটি [`std::io::Error`] বা [`std::error::Error`] এর সাথে বিভ্রান্ত হওয়া উচিত নয়, যা আপনার সুযোগও থাকতে পারে।
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// ইউনিকোড-গ্রহণযোগ্য বাফার বা স্ট্রিমগুলিতে লেখার বা ফর্ম্যাট করার জন্য একটি জেড 0 ট্রাইট0 জেড।
///
/// এই trait কেবলমাত্র ইউটিএফ-8 - এনকোডড ডেটা গ্রহণ করে এবং এটি [flushable] নয়।
/// আপনি যদি কেবল ইউনিকোড গ্রহণ করতে চান এবং আপনার ফ্লাশিংয়ের প্রয়োজন না হয়, আপনার এই trait বাস্তবায়ন করা উচিত;
/// অন্যথায় আপনার [`std::io::Write`] বাস্তবায়ন করা উচিত।
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// এই লেখকটিতে একটি স্ট্রিং স্লাইস লিখে, লেখাটি সফল হয়েছে কিনা তা ফেরত।
    ///
    /// পুরো স্ট্রিং স্লাইস সফলভাবে লেখা থাকলে এই পদ্ধতিটি সফল হতে পারে এবং সমস্ত ডেটা লিখিত না হওয়া বা ত্রুটি না হওয়া পর্যন্ত এই পদ্ধতিটি ফিরে আসবে না।
    ///
    ///
    /// # Errors
    ///
    /// এই ফাংশনটি ত্রুটিতে [`Error`] এর উদাহরণ ফিরিয়ে দেবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// এই লেখকটিতে একটি এক্স00 এক্স লিখেছেন, লেখাটি সফল হয়েছে কিনা তা ফেরত।
    ///
    /// একটি একক [`char`] একাধিক বাইট হিসাবে এনকোড করা হতে পারে।
    /// পুরো বাইট সিকোয়েন্সটি সফলভাবে লেখা থাকলে এই পদ্ধতিটি সফল হতে পারে এবং সমস্ত ডেটা লিখিত না হওয়া বা ত্রুটি না হওয়া পর্যন্ত এই পদ্ধতিটি ফিরে আসবে না।
    ///
    ///
    /// # Errors
    ///
    /// এই ফাংশনটি ত্রুটিতে [`Error`] এর উদাহরণ ফিরিয়ে দেবে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// এই trait এর প্রয়োগকারীদের সাথে [`write!`] ম্যাক্রো ব্যবহারের জন্য আঠালো।
    ///
    /// এই পদ্ধতিটি সাধারণত ম্যানুয়ালি আহ্বান করা উচিত নয়, বরং [`write!`] ম্যাক্রোর মাধ্যমে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// বিন্যাসকরণের জন্য কনফিগারেশন।
///
/// একটি এক্স00 এক্স বিন্যাস সম্পর্কিত বিভিন্ন বিকল্প উপস্থাপন করে।
/// ব্যবহারকারীরা সরাসরি `ফর্ম্যাটরগুলি নির্মাণ করে না;একটির পরিবর্তিত রেফারেন্সটি [`Debug`] এবং [`Display`] এর মতো সমস্ত0 traits এর `fmt` পদ্ধতিতে পাস করা হয়েছে is
///
///
/// একটি `Formatter` এর সাথে কথোপকথনের জন্য, আপনি বিন্যাস সম্পর্কিত বিভিন্ন বিকল্প পরিবর্তন করতে বিভিন্ন পদ্ধতি কল করবেন।
/// উদাহরণস্বরূপ, দয়া করে নীচে `Formatter` এ সংজ্ঞায়িত পদ্ধতিগুলির ডকুমেন্টেশন দেখুন।
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// আর্গুমেন্টটি মূলত `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` এর সমতুল্য একটি অপ্টিমাইজড আংশিক প্রয়োগ ফর্ম্যাটিং ফাংশন।

extern "C" {
    type Opaque;
}

/// এই কাঠামোটি জেনেরিক "argument" প্রতিনিধিত্ব করে যা ক্রিয়াকলাপের এক্সপ্রিন্টফ পরিবার গ্রহণ করে।এতে প্রদত্ত মানটিকে ফর্ম্যাট করার জন্য একটি ফাংশন রয়েছে।
/// সংকলনের সময় এটি নিশ্চিত করা হয় যে ফাংশন এবং মানটির সঠিক ধরণ রয়েছে এবং তারপরে এই স্ট্রাক্টকে এক প্রকারে আর্গুমেন্টকে আকাঙ্ক্ষিত করতে ব্যবহৃত হয়।
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// এটি ফর্ম্যাটিং অবকাঠামোতে indices/counts এর সাথে যুক্ত ফাংশন পয়েন্টারের জন্য একক স্থিতিশীল মানের গ্যারান্টি দেয়।
//
// মনে রাখবেন যে এরূপ হিসাবে সংজ্ঞায়িত কোনও ফাংশনটি সঠিক হবে না কারণ ফাংশন সর্বদা LLVM IR-র সাথে বর্তমান নামকরণের সাথে নামবিহীন_ডিডিআর ট্যাগ করা থাকে, সুতরাং তাদের ঠিকানাটি এলএলভিএমের কাছে গুরুত্বপূর্ণ হিসাবে বিবেচিত হয় না এবং যেমন_উসাইজ কাস্টের ভুল সংকলন করা যেতে পারে।
//
// অনুশীলনে, আমরা কখনই অ-ব্যবহারযোগ্য ডেটা (বিন্যাসের যুক্তিগুলির স্থিতিশীল প্রজন্মের বিষয় হিসাবে) যুক্তকে as_usize বলি না, সুতরাং এটি কেবল একটি অতিরিক্ত চেক।
//
// আমরা প্রাথমিকভাবে এটি নিশ্চিত করতে চাই যে `USIZE_MARKER` এ ফাংশন পয়েন্টারটির একটিমাত্র *কেবল* ফাংশনের সাথে সম্পর্কিত যা `&usize` কে তাদের প্রথম যুক্তি হিসাবে গ্রহণ করে।
// এখানে পঠিত_ভোলাটাইল নিশ্চিত করে যে আমরা পাসের রেফারেন্স থেকে কোনও ইউজইয়ে নিরাপদে প্রস্তুত করতে পারি এবং এই ঠিকানাটি কোনও অ-ইউজাইজ গ্রহণের ফাংশনটিকে নির্দেশ করে না।
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // সুরক্ষা: পিটিআর একটি রেফারেন্স
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // সুরক্ষা: `mem::transmute(x)` নিরাপদ কারণ
        //     1. `&'b T` এটি `'b` দিয়ে উদ্ভূত আজীবন রাখে (যাতে সীমাহীন জীবনকাল না হয়)
        //     2.
        //     `&'b T` এবং `&'b Opaque` এর সমান মেমরি লেআউট রয়েছে (যখন `T` `Sized`, এটি এখানে রয়েছে) `mem::transmute(f)` নিরাপদ থেকে `fn(&T, &mut Formatter<'_>) -> Result` এবং `fn(&Opaque, &mut Formatter<'_>) -> Result` একই এবিআই রয়েছে (যতক্ষণ `T` `Sized` হয়)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // নিরাপদ: `formatter` ফিল্ডটি কেবলমাত্র USIZE_MARKER এ সেট করা আছে যদি
            // মানটি একটি ব্যবহারযোগ্য, তাই এটি নিরাপদ
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ফরম্যাট_আরগসের v1 ফর্ম্যাটে ফ্ল্যাগগুলি উপলব্ধ
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () ম্যাক্রো ব্যবহার করার সময়, এই ফাংশনটি আর্গুমেন্ট কাঠামো তৈরি করতে ব্যবহৃত হয়।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// এই ফাংশনটি নন-স্ট্যান্ডার্ড বিন্যাসের পরামিতিগুলি নির্দিষ্ট করতে ব্যবহৃত হয়।
    /// একটি বৈধ আর্গুমেন্ট কাঠামো তৈরি করতে `pieces` অ্যারে অবশ্যই কমপক্ষে `fmt` দীর্ঘ হওয়া উচিত।
    /// এছাড়াও, `fmt` এর মধ্যে যে কোনও `Count` যা `CountIsParam` বা `CountIsNextParam` হয় তা `argumentusize` দিয়ে তৈরি একটি যুক্তির দিকে নির্দেশ করতে হবে।
    ///
    /// যাইহোক, এটি করতে ব্যর্থ হওয়া অকার্যকর কারণ নয়, তবে অবৈধ উপেক্ষা করবে।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// বিন্যাসিত পাঠ্যের দৈর্ঘ্য অনুমান করে।
    ///
    /// এটি `format!` ব্যবহার করার সময় প্রাথমিক `String` ক্ষমতা সেট করার জন্য ব্যবহার করার উদ্দেশ্যে is
    /// Note: এটি নিম্ন বা উপরের সীমানা নয়।
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // যদি বিন্যাসের স্ট্রিংটি একটি আর্গুমেন্ট দিয়ে শুরু হয়, তবে টুকরোটির দৈর্ঘ্য উল্লেখযোগ্য না হলে কোনও কিছুর পূর্বরূপণ করবেন না।
            //
            //
            0
        } else {
            // কিছু যুক্তি রয়েছে, সুতরাং কোনও অতিরিক্ত ধাক্কা স্ট্রিংটিকে পুনর্বিবেচিত করবে।
            //
            // এটি এড়াতে, আমরা এখানে ক্ষমতা "pre-doubling" করছি
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// এই কাঠামোটি কোনও ফর্ম্যাট স্ট্রিং এবং এর আর্গুমেন্টের নিরাপদে প্রাকম্পম্পাইল সংস্করণ উপস্থাপন করে।
/// এটি রানটাইমের সময় উত্পন্ন করা যায় না কারণ এটি নিরাপদে করা যায় না, সুতরাং কোনও কনস্ট্রাক্টর দেওয়া হয়নি এবং ক্ষেত্রগুলি পরিবর্তন রোধ করার জন্য ব্যক্তিগত।
///
///
/// [`format_args!`] ম্যাক্রো নিরাপদে এই কাঠামোর একটি উদাহরণ তৈরি করবে।
/// ম্যাক্রো সংকলন সময়ে বিন্যাসের স্ট্রিংকে বৈধতা দেয় তাই [`write()`] এবং [`format()`] ফাংশনগুলির ব্যবহার নিরাপদে সম্পাদন করা যায়।
///
/// আপনি `Arguments<'a>` ব্যবহার করতে পারেন যা [`format_args!`] `Debug` এবং `Display` প্রসঙ্গে নীচে দেখেছে returns
/// উদাহরণটি একই জিনিসকে `Debug` এবং `Display` ফর্ম্যাটটিও দেখায়: `format_args!` এ ইন্টারপোলটেড ফর্ম্যাট স্ট্রিং।
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // মুদ্রণের জন্য স্ট্রিং টুকরা ফর্ম্যাট করুন।
    pieces: &'a [&'static str],

    // স্থানধারক চশমা, বা `None` যদি সমস্ত চশমা ডিফল্ট হয় ("{}{}" হিসাবে)।
    fmt: Option<&'a [rt::v1::Argument]>,

    // স্ট্রল টুকরা দিয়ে আন্তঃবাহিত হওয়ার জন্য ইন্টারপোলেশনটির জন্য গতিশীল আর্গুমেন্ট।
    // (প্রতিটি যুক্তি তার আগে স্ট্রিং টুকরা দিয়ে থাকে))
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ফর্ম্যাট করার স্ট্রিংটি পান, যদি এতে বিন্যাস করার কোনও আর্গুমেন্ট না থাকে।
    ///
    /// এটি সবচেয়ে তুচ্ছ ক্ষেত্রে বরাদ্দ এড়াতে ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` কোনও প্রোগ্রামার-মুখোমুখি, ডিবাগিং প্রসঙ্গে আউটপুটটিকে ফর্ম্যাট করা উচিত।
///
/// সাধারণভাবে বলতে গেলে, আপনার কেবলমাত্র একটি `Debug` বাস্তবায়ন `derive` হওয়া উচিত।
///
/// বিকল্প ফর্ম্যাট নির্দিষ্টকরণকারী `#?` এর সাথে ব্যবহার করা হলে আউটপুটটি বেশ মুদ্রিত-
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// এই ক্ষেত্রটি `#[derive]` এর সাথে `#[derive]` ব্যবহার করা যেতে পারে যদি সমস্ত ক্ষেত্রগুলি `Debug` প্রয়োগ করে।
/// যখন স্ট্রাক্টগুলির জন্য `উদ্ভূত হয়, এটি `struct` এর নাম ব্যবহার করবে, তারপরে `{`, তারপরে প্রতিটি ক্ষেত্রের নাম এবং `Debug` মানের একটি কমা-বিচ্ছিন্ন তালিকা, তারপরে `}`।
/// `Enum`s এর জন্য, এটি বৈকল্পিকের নামটি ব্যবহার করবে এবং যদি প্রযোজ্য হয় তবে `(`, তারপরে ক্ষেত্রগুলির `Debug` মান, তারপরে `)`।
///
/// # Stability
///
/// উত্সযুক্ত `Debug` ফর্ম্যাটগুলি স্থিতিশীল নয় এবং তাই future Rust সংস্করণে পরিবর্তন হতে পারে।
/// অতিরিক্তভাবে, স্ট্যান্ডার্ড লাইব্রেরি দ্বারা সরবরাহিত ধরণের `Debug` বাস্তবায়ন (b libstd`, `libcore`, `liballoc`, ইত্যাদি) স্থিতিশীল নয় এবং এটি future Rust সংস্করণেও পরিবর্তন হতে পারে।
///
///
/// # Examples
///
/// একটি প্রয়োগ কার্যকর করা:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ম্যানুয়ালি বাস্তবায়ন:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] এর মতো ম্যানুয়াল বাস্তবায়নগুলিতে আপনাকে সহায়তা করার জন্য [`Formatter`] স্ট্রাক্টটিতে বেশ কয়েকটি সহায়ক পদ্ধতি রয়েছে।
///
/// `Debug` এক্স 100 এক্স বা এক্স01 এক্স-এ ডিবাগ নির্মাতা এপিআই ব্যবহার করে বাস্তবায়ন বিকল্প পতাকা ব্যবহার করে প্রিন্ট-প্রিন্টিং সমর্থন করে: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// এক্স 100 এক্স সহ সুন্দর-মুদ্রণ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` ছাড়াই preolve থেকে ম্যাক্রো `Debug` পুনরায় রপ্তানি করতে মডিউল পৃথক করুন।
pub(crate) mod macros {
    /// trait `Debug` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// খালি বিন্যাসের জন্য trait ফর্ম্যাট করুন, `{}`.
///
/// `Display` [`Debug`] এর অনুরূপ, তবে `Display` ব্যবহারকারীর মুখোমুখি আউটপুট জন্য, এবং তাই প্রাপ্ত করা যায় না।
///
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// কোনও প্রকারে `Display` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait এর আউটপুটটি base-8 এ একটি সংখ্যা হিসাবে ফর্ম্যাট করা উচিত।
///
/// আদিম স্বাক্ষরিত পূর্ণসংখ্যাগুলির জন্য (`i8` থেকে `i128`, এবং `isize`), নেতিবাচক মানগুলি দুটির পরিপূরক উপস্থাপনা হিসাবে ফর্ম্যাট হয়।
///
///
/// বিকল্প পতাকা, `#`, আউটপুটটির সামনে একটি `0o` যুক্ত করে।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42; // 42 অষ্টালে '52' হয়
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// কোনও প্রকারে `Octal` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // আই 32 এর বাস্তবায়নের জন্য প্রতিনিধি দিন
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait এর আউটপুটটিকে বাইনারি হিসাবে একটি সংখ্যা হিসাবে ফর্ম্যাট করা উচিত।
///
/// আদিম স্বাক্ষরিত পূর্ণসংখ্যাগুলির জন্য ([`i8`] থেকে [`i128`], এবং [`isize`]), নেতিবাচক মানগুলি দুটির পরিপূরক উপস্থাপনা হিসাবে ফর্ম্যাট হয়।
///
///
/// বিকল্প পতাকা, `#`, আউটপুটটির সামনে একটি `0b` যুক্ত করে।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42; // বাইনারি মধ্যে 42 হ'ল '101010'
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// কোনও প্রকারে `Binary` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // আই 32 এর বাস্তবায়নের জন্য প্রতিনিধি দিন
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait এর আউটপুটটিকে হেক্সাডেসিমালে একটি সংখ্যা হিসাবে ফর্ম্যাট করা উচিত, `a` এর মাধ্যমে নিম্ন ক্ষেত্রে `a` এর মাধ্যমে output
///
/// আদিম স্বাক্ষরিত পূর্ণসংখ্যাগুলির জন্য (`i8` থেকে `i128`, এবং `isize`), নেতিবাচক মানগুলি দুটির পরিপূরক উপস্থাপনা হিসাবে ফর্ম্যাট হয়।
///
///
/// বিকল্প পতাকা, `#`, আউটপুটটির সামনে একটি `0x` যুক্ত করে।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42; // হেক্সে 42 হ'ল এক্স 100 এক্স
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// কোনও প্রকারে `LowerHex` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // আই 32 এর বাস্তবায়নের জন্য প্রতিনিধি দিন
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait এর আউটপুটটিকে `A` এর মাধ্যমে `A` এর মাধ্যমে হেক্সাডেসিমাল হিসাবে একটি আউটপুট ফর্ম্যাট করা উচিত।
///
/// আদিম স্বাক্ষরিত পূর্ণসংখ্যাগুলির জন্য (`i8` থেকে `i128`, এবং `isize`), নেতিবাচক মানগুলি দুটির পরিপূরক উপস্থাপনা হিসাবে ফর্ম্যাট হয়।
///
///
/// বিকল্প পতাকা, `#`, আউটপুটটির সামনে একটি `0x` যুক্ত করে।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42; // হেক্সে 42 হ'ল এক্স 100 এক্স
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// কোনও প্রকারে `UpperHex` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // আই 32 এর বাস্তবায়নের জন্য প্রতিনিধি দিন
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait এর আউটপুটটিকে একটি মেমরি অবস্থান হিসাবে ফর্ম্যাট করা উচিত।
/// এটি সাধারণত হেক্সাডেসিমাল হিসাবে উপস্থাপিত হয়।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // এটি '0x7f06092ac6d0' এর মতো কিছু উত্পাদন করে
/// ```
///
/// কোনও প্রকারে `Pointer` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` এ রূপান্তর করতে `as` ব্যবহার করুন, এটি পয়েন্টার প্রয়োগ করে, যা আমরা ব্যবহার করতে পারি
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait এর আউটপুটটিকে নিম্ন-কেস `e` এর সাথে বৈজ্ঞানিক স্বরলিপিতে ফর্ম্যাট করা উচিত।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42.0; // 42.0 বৈজ্ঞানিক স্বরলিপি মধ্যে '4.2e1' হয়
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// কোনও প্রকারে `LowerExp` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 এর বাস্তবায়নের জন্য প্রতিনিধি
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait এর আউটপুট কেস `E` দিয়ে বৈজ্ঞানিক স্বরলিপিতে এর আউটপুট ফর্ম্যাট করা উচিত।
///
/// বিন্যাস সম্পর্কিত আরও তথ্যের জন্য, [the module-level documentation][module] দেখুন।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// এক্স 100 এক্স সহ বেসিক ব্যবহার:
///
/// ```
/// let x = 42.0; // 42.0 বৈজ্ঞানিক স্বরলিপি মধ্যে '4.2E1' হয়
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// কোনও প্রকারে `UpperExp` প্রয়োগ করা হচ্ছে:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 এর বাস্তবায়নের জন্য প্রতিনিধি
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// প্রদত্ত ফরম্যাটর ব্যবহার করে মানটিকে ফর্ম্যাট করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ফাংশনটি একটি আউটপুট স্ট্রিম গ্রহণ করে এবং একটি `Arguments` স্ট্রাক্ট যা `format_args!` ম্যাক্রোর সাথে পূর্বনির্ধারিত হতে পারে।
///
///
/// আর্গুমেন্ট সরবরাহ করা আউটপুট স্ট্রিমের মধ্যে নির্দিষ্ট ফর্ম্যাট স্ট্রিং অনুযায়ী ফর্ম্যাট করা হবে।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// দয়া করে মনে রাখবেন যে [`write!`] ব্যবহার করা ভাল preউদাহরণ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // আমরা সমস্ত আর্গুমেন্টের জন্য ডিফল্ট ফর্ম্যাটিং প্যারামিটার ব্যবহার করতে পারি।
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // প্রতিটি অনুমানের একটি যুক্তিযুক্ত যুক্ত থাকে যা তার আগে একটি স্ট্রিং পিস থাকে।
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // সুরক্ষা: আরগ এবং এক্স 100 এক্স একই যুক্তি থেকে আসে,
                // যা সূচকগুলি সর্বদা সীমার মধ্যে থাকে তার গ্যারান্টি দেয়।
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // এখানে কেবল একটি পেছনের স্ট্রিং পিস থাকতে পারে।
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // নিরাপত্তা: আরগ এবং আর্গুমেন্টগুলি একই যুক্তি থেকে আসে,
    // যা সূচকগুলি সর্বদা সীমার মধ্যে থাকে তার গ্যারান্টি দেয়।
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // সঠিক যুক্তিটি বের করুন
    debug_assert!(arg.position < args.len());
    // নিরাপত্তা: আরগ এবং আর্গুমেন্টগুলি একই যুক্তি থেকে আসে,
    // যা এর সূচকটি সর্বদা সীমানার মধ্যে থাকে তার গ্যারান্টি দেয়।
    let value = unsafe { args.get_unchecked(arg.position) };

    // তাহলে আসলে কিছু মুদ্রণ করুন
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // নিরাপদ: সিএনটি এবং আরোগুলি একই আর্গুমেন্ট থেকে আসে,
            // যা এই সূচকের গ্যারান্টি দেয় সর্বদা সীমার মধ্যে থাকে।
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// কিছু শেষ হওয়ার পরে প্যাডিং।এক্স 100 এক্স দ্বারা ফিরে এসেছে।
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// এই পোস্ট প্যাডিং লিখুন।
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // আমরা এটি পরিবর্তন করতে চাই
            buf: wrap(self.buf),

            // এবং এগুলি সংরক্ষণ করুন
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // প্যাডিং এবং ফর্ম্যাটিং আর্গুমেন্টগুলির প্রক্রিয়াকরণের জন্য ব্যবহৃত সহায়ক পদ্ধতিগুলি যা traits সমস্ত ফর্ম্যাটিং ব্যবহার করতে পারে।
    //

    /// একটি পূর্ণসংখ্যার জন্য সঠিক প্যাডিং সম্পাদন করে যা ইতিমধ্যে একটি স্ট্রের মধ্যে নির্গত হয়েছে।
    /// স্ট্রিমটিতে * পূর্ণসংখ্যার জন্য চিহ্ন থাকতে হবে না, যা এই পদ্ধতিতে যুক্ত হবে।
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, মূল পূর্ণসংখ্যা হয় ধনাত্মক বা শূন্য কিনা।
    /// * উপসর্গ, যদি '#' অক্ষর (Alternate) সরবরাহ করা হয় তবে এটি সংখ্যার সামনে রাখার উপসর্গ।
    ///
    /// * বুফ, বাইট অ্যারে যে সংখ্যাটি ফর্ম্যাট করা হয়েছে
    ///
    /// এই ফাংশনটি সঠিকভাবে প্রদত্ত ফ্ল্যাগগুলির পাশাপাশি সর্বনিম্ন প্রস্থের জন্য অ্যাকাউন্ট করবে।
    /// এটি নির্ভুলতার বিষয়টি বিবেচনায় নেবে না।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // সংখ্যা আউটপুট থেকে আমাদের "-" অপসারণ করতে হবে।
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // সাইনটি উপস্থিত থাকলে এবং তারপরে অনুরোধ করা হলে উপসর্গটি লিখে দেয়
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` ক্ষেত্রটি এই মুহুর্তে একটি `min-width` প্যারামিটারের বেশি।
        match self.width {
            // যদি কোনও ন্যূনতম দৈর্ঘ্যের প্রয়োজনীয়তা না থাকে তবে আমরা কেবল বাইটগুলি লিখতে পারি।
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // আমরা ন্যূনতম প্রস্থের বেশি কিনা তা পরীক্ষা করে দেখুন, তা হলে আমরা কেবল বাইটগুলিও লিখতে পারি।
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ভরাট অক্ষর শূন্য হলে সাইন এবং উপসর্গ প্যাডিংয়ের আগে চলে যায়
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // অন্যথায়, সাইন এবং উপসর্গ প্যাডিংয়ের পরে চলে যায়
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// এই ফাংশনটি একটি স্ট্রিং স্লাইস নেয় এবং নির্দিষ্ট প্রাসঙ্গিক পতাকাঙ্কিত পতাকাগুলি প্রয়োগ করার পরে এটি অভ্যন্তরীণ বাফারে প্রেরণ করে।
    /// জেনেরিক স্ট্রিংগুলির জন্য স্বীকৃত পতাকাগুলি হ'ল:
    ///
    /// * প্রস্থ, কি নির্গত হবে তার সর্বনিম্ন প্রস্থ
    /// * fill/align - যদি স্ট্রিংটি প্যাড করা দরকার হয় তবে কী নির্গত হয় এবং কোথায় তা নির্গত হয়
    /// * যথার্থতা, নির্গত সর্বাধিক দৈর্ঘ্য, স্ট্রিংটি যদি এই দৈর্ঘ্যের চেয়ে দীর্ঘ হয় তবে কাটা হবে
    ///
    /// উল্লেখযোগ্যভাবে এই ফাংশনটি `flag` পরামিতি উপেক্ষা করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // সামনে একটি দ্রুত পথ আছে তা নিশ্চিত করুন
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` ক্ষেত্রটি স্ট্রিং ফর্ম্যাট করার জন্য একটি `max-width` হিসাবে ব্যাখ্যা করা যেতে পারে।
        //
        let s = if let Some(max) = self.precision {
            // আমাদের স্ট্রিং যদি যথার্থতার চেয়ে দীর্ঘ হয় তবে আমাদের অবশ্যই কাটা উচিত।
            // তবে অন্যান্য পতাকাগুলি যেমন `fill`, `width` এবং `align` অবশ্যই বরাবরের মতো কাজ করবে।
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // এখানে এলএলভিএম প্রমাণ করতে পারে না যে `..i` panic `&s[..i]` করবে না, তবে আমরা জানি যে এটি panic করতে পারে না।
                // `unsafe` এড়াতে `get` + `unwrap_or` ব্যবহার করুন এবং অন্যথায় এখানে কোনও panic-সম্পর্কিত কোড নির্গত করবেন না।
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` ক্ষেত্রটি এই মুহুর্তে একটি `min-width` প্যারামিটারের বেশি।
        match self.width {
            // যদি আমরা সর্বোচ্চ দৈর্ঘ্যের নীচে থাকি এবং ন্যূনতম দৈর্ঘ্যের কোনও প্রয়োজনীয়তা না থাকে তবে আমরা কেবল স্ট্রিংটি নির্গত করতে পারি
            //
            None => self.buf.write_str(s),
            // যদি আমরা সর্বাধিক প্রস্থের নিচে থাকি তবে আমরা ন্যূনতম প্রস্থের উপরে রয়েছি কিনা তা পরীক্ষা করুন, যদি এটি স্ট্রিং নির্গমন করার মতোই সহজ।
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // যদি আমরা সর্বাধিক এবং সর্বনিম্ন প্রস্থ উভয়েরই অধীনে থাকি তবে নির্দিষ্ট স্ট্রিং + কিছু প্রান্তিককরণের সাথে সর্বনিম্ন প্রস্থটি পূরণ করুন।
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// প্রাক-প্যাডিং লিখুন এবং অলিখিত পোস্ট-প্যাডিংটি ফিরিয়ে দিন।
    /// প্যাড প্যাডিং যে জিনিসটি প্যাড করা হচ্ছে তার পরে লিখিত রয়েছে তা নিশ্চিত করার জন্য কলকারীরা দায়বদ্ধ।
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ফর্ম্যাট অংশগুলি নেয় এবং প্যাডিং প্রয়োগ করে।
    /// ধরে নেওয়া হয়েছে যে কলার ইতিমধ্যে প্রয়োজনীয় নির্ভুলতার সাথে অংশগুলি রেন্ডার করেছে, যাতে `self.precision` উপেক্ষা করা যায়।
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // সাইন-সচেতন শূন্য প্যাডিংয়ের জন্য, আমরা প্রথমে সাইনটি রেন্ডার করি এবং আচরণ করি যেন আমাদের প্রথম থেকেই কোনও চিহ্ন নেই।
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // একটি চিহ্ন সবসময় প্রথম যায়
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // বিন্যাসিত অংশগুলি থেকে সাইনটি সরিয়ে ফেলুন
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // বাকি অংশগুলি সাধারণ প্যাডিং প্রক্রিয়াটির মধ্য দিয়ে যায়।
            let len = formatted.len();
            let ret = if width <= len {
                // কোন প্যাডিং নেই
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // এটি সাধারণ ঘটনা এবং আমরা একটি শর্টকাট নিই
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // নিরাপদ: এটি `flt2dec::Part::Num` এবং `flt2dec::Part::Copy` এর জন্য ব্যবহৃত হয়।
            // এটি `flt2dec::Part::Num` এর জন্য ব্যবহার করা নিরাপদ যেহেতু প্রতিটি চর `c` `b'0'` এবং `b'9'` এর মধ্যে, যার অর্থ `s` বৈধ UTF-8।
            // এটি `flt2dec::Part::Copy(buf)` এর ব্যবহারে অনুশীলনে সম্ভবত নিরাপদ যেহেতু `buf` সরল ASCII হওয়া উচিত তবে এটি কোনও প্রকাশ্য কার্যকারিতা হওয়ায় কারও পক্ষে `buf` এর খারাপ মান পাস করা সম্ভব।
            //
            // FIXME: এর ফলে ইউবি হতে পারে কিনা তা নির্ধারণ করুন।
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 শূন্য
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// এই ফর্ম্যাটারের অন্তর্ভুক্ত অন্তর্নিহিত বাফারে কিছু ডেটা লিখে Writ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // এটি সমান:
    ///         // লিখুন! (বিন্যাসক, এক্স00 এক্স)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// এই দৃষ্টান্তটির জন্য কিছু ফর্ম্যাট করা তথ্য লিখে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// বিন্যাসের জন্য পতাকা
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// যখনই প্রান্তিককরণ থাকে তখন 'fill' হিসাবে অক্ষর ব্যবহৃত হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // আমরা ">" এর সাথে ডানদিকে প্রান্তিককরণ সেট করেছি।
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// প্রান্তিককরণের কোন ফর্মটি অনুরোধ করা হয়েছে তা চিহ্নিত করে পতাকাটি।
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// আউটপুট হওয়া উচিত ptionচ্ছিকভাবে পূর্ণসংখ্যার প্রস্থ specified
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // আমরা যদি কোনও প্রস্থ পেয়েছি, আমরা এটি ব্যবহার করি
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // অন্যথায় আমরা বিশেষ কিছু করি না
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// সংখ্যার ধরণের জন্য ptionচ্ছিকভাবে নির্দিষ্ট নির্ভুলতা।
    /// বিকল্পভাবে, স্ট্রিং ধরণের জন্য সর্বাধিক প্রস্থ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // যদি আমরা একটি নির্ভুলতা পেয়ে থাকি তবে আমরা এটি ব্যবহার করি।
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // অন্যথায় আমরা ডিফল্ট।
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` পতাকা নির্দিষ্ট করা হয়েছে কিনা তা নির্ধারণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` পতাকা নির্দিষ্ট করা হয়েছে কিনা তা নির্ধারণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // আপনি একটি বিয়োগ চিহ্ন চান?এক আছে!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` পতাকা নির্দিষ্ট করা হয়েছে কিনা তা নির্ধারণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` পতাকা নির্দিষ্ট করা হয়েছে কিনা তা নির্ধারণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // আমরা ফর্ম্যাটারের বিকল্পগুলি উপেক্ষা করি।
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: এই দুটি ফ্ল্যাগের জন্য আমরা কী পাবলিক এপিআই চাই তা স্থির করুন।
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// স্ট্রাক্টগুলির জন্য [`fmt::Debug`] বাস্তবায়ন তৈরিতে সহায়তার জন্য ডিজাইন করা একটি [`DebugStruct`] বিল্ডার তৈরি করে।
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// টিউপল স্ট্রাক্টগুলির জন্য `fmt::Debug` বাস্তবায়ন তৈরিতে সহায়তার জন্য ডিজাইন করা একটি `DebugTuple` বিল্ডার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// তালিকার মতো কাঠামোর জন্য `fmt::Debug` বাস্তবায়ন তৈরিতে সহায়তার জন্য ডিজাইন করা একটি `DebugList` বিল্ডার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// সেট-মতো কাঠামোর জন্য `fmt::Debug` বাস্তবায়ন তৈরিতে সহায়তার জন্য ডিজাইন করা একটি `DebugSet` বিল্ডার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// এই আরও জটিল উদাহরণে, আমরা ম্যাচের অস্ত্রগুলির তালিকা তৈরি করতে [`format_args!`] এবং `.debug_set()` ব্যবহার করি:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// মানচিত্রের মতো কাঠামোর জন্য `fmt::Debug` বাস্তবায়ন তৈরিতে সহায়তার জন্য ডিজাইন করা একটি `DebugMap` বিল্ডার তৈরি করে।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// মূল বিন্যাসকরণ traits এর বাস্তবায়ন

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // চরটি যদি পালানোর দরকার হয় তবে এতক্ষণ ব্যাকলগটি ফ্লাশ করুন এবং লিখুন, অন্যথায় এড়িয়ে যান
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // বিকল্প পতাকাটি ইতিমধ্যে লোয়ারহেক্স দ্বারা বিশেষ হিসাবে বিবেচিত হয়েছে-এটি 0x সহ উপসর্গ করা উচিত কিনা তা বোঝায়।
        // আমরা এটি শূন্য প্রসারিত হবে কি না তা নিয়ে কাজ করার জন্য ব্যবহার করি এবং তারপরে নিঃশর্তভাবে উপসর্গটি পেতে এটি সেট করি।
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// বিভিন্ন মূল ধরণের জন্য Display/Debug এর বাস্তবায়ন

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // রেফসেল পারস্পরিকভাবে ধার করা হয়েছে তাই আমরা এখানে এর মানটি দেখতে পারি না।
                // পরিবর্তে একটি স্থানধারক দেখান।
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// আপনি যদি পরীক্ষাগুলি এখানে উপস্থিত হওয়ার প্রত্যাশা করেন, তবে পরিবর্তে core/tests/fmt.rs ফাইলটি দেখুন, এখানে সমস্ত rt::Piece কাঠামো তৈরি করা অনেক সহজ it's
//
// বরাদ্দ প্রয়োজন তাদের জন্য crate বরাদ্দেও পরীক্ষা রয়েছে।