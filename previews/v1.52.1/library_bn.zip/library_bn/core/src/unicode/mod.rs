#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) এর যে সংস্করণটি `char` এবং `str` পদ্ধতির ইউনিকোড অংশগুলি ভিত্তিক।
///
/// ইউনিকোডের নতুন সংস্করণগুলি নিয়মিত প্রকাশিত হয় এবং পরবর্তীকালে ইউনিকোডের উপর নির্ভর করে স্ট্যান্ডার্ড লাইব্রেরিতে সমস্ত পদ্ধতি আপডেট করা হয়।
/// তাই কিছু এক্স 100 এক্স এবং এক্স01 এক্স পদ্ধতির আচরণ এবং এই ধ্রুবকের মান সময়ের সাথে সাথে পরিবর্তন ঘটে।
/// এটি *একটি* ব্রেকিং পরিবর্তন হিসাবে বিবেচিত হয় না।
///
/// সংস্করণ নম্বরকরণ স্কিমটি [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) এ ব্যাখ্যা করা হয়েছে।
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc ব্যবহারের জন্য, libstd এ পুনরায় রফতানি করা হবে না।
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;