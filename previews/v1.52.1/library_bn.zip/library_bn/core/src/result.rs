//! `Result` প্রকারের সাথে পরিচালনা করতে ত্রুটি।
//!
//! [`Result<T, E>`][`Result`] ফিরে আসা এবং ত্রুটি প্রচারের জন্য ব্যবহৃত প্রকার।
//! এটি সাফল্যের প্রতিনিধিত্ব করে এবং একটি মান এবং X01 এক্স সহ ভেরিয়েন্টস, এক্স 100 এক্স সহ একটি এনাম, ত্রুটি উপস্থাপন করে এবং ত্রুটির মান রাখে।
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! ত্রুটিগুলি প্রত্যাশিত এবং পুনরুদ্ধারযোগ্য হওয়ার ক্ষেত্রে ফাংশনগুলি [`Result`] প্রদান করে।`std` crate-এ, [`Result`] সর্বাধিক সুস্পষ্টভাবে এক্স 100 এক্স এর জন্য ব্যবহৃত হয়।
//!
//! [`Result`] ফেরত একটি সাধারণ ফাংশন সংজ্ঞায়িত করা যেতে পারে এবং এর মতো ব্যবহার করা যেতে পারে:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`ফলাফল`] এর সাথে প্যাটার্নের মিলটি সহজ ক্ষেত্রে সহজ এবং সোজা, তবে এক্স00 এক্স কিছু সুবিধাজনক পদ্ধতি নিয়ে আসে যা এটির সাথে কাজ করা আরও সুসংহত করে তোলে।
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` এবং `is_err` পদ্ধতিগুলি তারা যা বলে তা করে।
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` এক্স 100 এক্স গ্রহণ করে এবং অন্য উত্পাদন করে।
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // গণনা চালিয়ে যেতে `and_then` ব্যবহার করুন।
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // ত্রুটিটি পরিচালনা করতে `or_else` ব্যবহার করুন।
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ফলাফলটি গ্রহণ করুন এবং সামগ্রীগুলি `unwrap` এর সাথে ফিরিয়ে দিন।
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # ফলাফল অবশ্যই ব্যবহার করা উচিত
//!
//! ত্রুটিগুলি চিহ্নিত করতে রিটার্ন মানগুলি ব্যবহার করার একটি সাধারণ সমস্যা হ'ল রিটার্ন মানটিকে উপেক্ষা করা সহজ, এইভাবে ত্রুটিটি পরিচালনা করতে ব্যর্থ।
//! [`Result`] `#[must_use]` অ্যাট্রিবিউট দ্বারা টীকাযুক্ত করা হয়, ফলাফলের মানটিকে অগ্রাহ্য করা হলে সংকলকটি একটি সতর্কতা জারি করে।
//! এটি এক্স00 এক্সকে এমন ফাংশনগুলির সাথে বিশেষভাবে দরকারী করে তোলে যা ত্রুটির মুখোমুখি হতে পারে তবে অন্যথায় কার্যকর মানটি দেয় না।
//!
//! [`Write`] trait দ্বারা I/O প্রকারের জন্য সংজ্ঞায়িত [`write_all`] পদ্ধতিটি বিবেচনা করুন:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] এর আসল সংজ্ঞাটি [`io::Result`] ব্যবহার করে, যা [`ফলাফল`] for এর প্রতিশব্দ মাত্র<T, `[`io: :Error`]`>।*
//!
//! এই পদ্ধতিতে কোনও মান উৎপন্ন হয় না তবে লেখাটি ব্যর্থ হতে পারে।ত্রুটি কেস পরিচালনা করার জন্য এটি গুরুত্বপূর্ণ, এবং * * এই জাতীয় কিছু লিখবেন না:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // যদি `write_all` ত্রুটি হয়, তবে আমরা কখনই জানতে পারি না, কারণ ফেরতের মানটিকে অগ্রাহ্য করা হয়।
//! //
//! file.write_all(b"important message");
//! ```
//!
//! আপনি যদি Rust তে *লিখেন*, সংকলক আপনাকে একটি সতর্কতা দেবে (ডিফল্টরূপে, `unused_must_use` lint দ্বারা নিয়ন্ত্রিত)।
//!
//! পরিবর্তে, আপনি যদি ত্রুটিটি পরিচালনা করতে না চান তবে [`expect`] এর সাহায্যে সাফল্যের জোরে জোড় জোড়ে জোড়ে জোড়ে জোড়ে জোড়ে জোড়ে জোড়ে জোড়ালো
//! এটি panic করবে যদি লিখন ব্যর্থ হয় তবে একটি সামান্য কার্যকর বার্তা সরবরাহ করে যে কেন:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! আপনি সহজেই সাফল্য জোর:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! অথবা কল স্ট্যাক আপ ত্রুটি প্রচার করুন [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # প্রশ্ন চিহ্ন অপারেটর, `?`
//!
//! কোড লেখার সময় এমন অনেক ফাংশনকে কল করে যা [`Result`] প্রকারটি ফেরত দেয়, ত্রুটি পরিচালনা করা বিরক্তিকর হতে পারে।
//! প্রশ্ন চিহ্ন অপারেটর, এক্স00 এক্স, কল স্ট্যাক পর্যন্ত ত্রুটি প্রচারের কিছু বয়লারপ্লেট লুকায়।
//!
//! এটি এটি প্রতিস্থাপন করে:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // ত্রুটি উপর তাড়াতাড়ি ফিরে
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! এর সাথে:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // ত্রুটি উপর তাড়াতাড়ি ফিরে
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *এটা অনেক সুন্দর!*
//!
//! এক্স01 এক্স দিয়ে এক্সপ্রেশন শেষ করার ফলে আন-র্যাপড সাফল্য ([`Ok`]) মান হবে, ফলাফলটি [`Err`] না হলে, ক্ষেত্রে [`Err`] এনকোলেসিং ফাংশন থেকে তাড়াতাড়ি ফিরে না আসা।
//!
//!
//! [`?`] কেবলমাত্র এমন ফাংশনগুলিতে ব্যবহার করা যেতে পারে যা এটি সরবরাহ করে [`Err`] এর প্রাথমিক রিটার্নের কারণে [`Result`] ফেরত দেয়।
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` এমন এক ধরণের যা সাফল্য ([`Ok`]) বা ব্যর্থতা ([`Err`]) প্রতিনিধিত্ব করে।
///
/// বিশদের জন্য এক্স 100 এক্স দেখুন।
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// সাফল্যের মান ধারণ করে
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// ত্রুটির মান ধারণ করে
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// প্রকারের প্রয়োগ
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // থাকা মানগুলি জিজ্ঞাসা করা হচ্ছে
    /////////////////////////////////////////////////////////////////////////

    /// ফলাফল [`Ok`] হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ফলাফল [`Err`] হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// ফলাফলটি প্রদত্ত মান সমেত একটি [`Ok`] মান হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// ফলাফলটি প্রদত্ত মান সমেত একটি [`Err`] মান হলে `true` প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // প্রতিটি বৈকল্পিক জন্য অ্যাডাপ্টার
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` থেকে [`Option<T>`] এ রূপান্তর করে।
    ///
    /// `self` কে [`Option<T>`] এ রূপান্তর করে `self` গ্রহণ করে এবং যদি কোনও ত্রুটি ত্যাগ করে arding
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` থেকে [`Option<E>`] এ রূপান্তর করে।
    ///
    /// `self` কে [`Option<E>`] এ রূপান্তর করে `self` গ্রহণ করে এবং সাফল্যের মানটিকে যদি ছাড়িয়ে যায় তবে তা ছাড়িয়ে দেয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // রেফারেন্স সহ কাজ করার জন্য অ্যাডাপ্টার
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` থেকে `Result<&T, &E>` এ রূপান্তর করে।
    ///
    /// আসলটি জায়গায় রেখে মূলটিতে একটি রেফারেন্স যুক্ত একটি নতুন এক্স00 এক্স উত্পাদন করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` থেকে `Result<&mut T, &mut E>` এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ধারণকৃত মানগুলি রূপান্তরকরণ
    /////////////////////////////////////////////////////////////////////////

    /// একটি [`Ok`] মানটি অচ্ছুত রেখে একটি অন্তর্ভুক্ত [`Ok`] মানের একটি ফাংশন প্রয়োগ করে একটি `Result<T, E>` থেকে `Result<U, E>` মানচিত্র করুন।
    ///
    ///
    /// এই ফাংশনটি দুটি ফাংশনের ফলাফল রচনা করতে ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// দুটি দিয়ে গুণিত স্ট্রিংয়ের প্রতিটি লাইনে সংখ্যা মুদ্রণ করুন।
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// থাকা মানটিতে (যদি [`Ok`]) একটি ফাংশন প্রয়োগ করে বা সরবরাহিত ডিফল্ট (যদি [`Err`] হয়) প্রদান করে।
    ///
    /// `map_or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`map_or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// এতে থাকা [`Ok`] মানটিতে একটি ফাংশন প্রয়োগ করে অথবা একটি থাকা [`Err`] মানটিতে ফ্যালব্যাক ফাংশন প্রয়োগ করে একটি এক্স 100 এক্স থেকে এক্স01 এক্স মানচিত্র করুন।
    ///
    ///
    /// এই ফাংশনটি একটি ত্রুটি পরিচালনা করার সময় একটি সফল ফলাফল আনপ্যাক করতে ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// একটি [`Err`] মানটি অচ্ছুত রেখে একটি অন্তর্ভুক্ত [`Err`] মানের একটি ফাংশন প্রয়োগ করে একটি `Result<T, E>` থেকে `Result<T, F>` মানচিত্র করুন।
    ///
    ///
    /// এই ফাংশনটি একটি ত্রুটি পরিচালনা করার সময় একটি সফল ফলাফলের মধ্য দিয়ে যেতে ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator নির্মাণকারী
    /////////////////////////////////////////////////////////////////////////

    /// সম্ভবত অন্তর্ভুক্ত মানের উপর একটি পুনরাবৃত্তির ফেরত দেয়।
    ///
    /// ফলাফলটি [`Result::Ok`] হলে পুনরাবৃত্তি একটি মান দেয় otherwise
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// সম্ভাব্য সংখ্যার মানের পরিবর্তে একটি পরিবর্তনীয় পুনরাবৃত্তি প্রদান করে।
    ///
    /// ফলাফলটি [`Result::Ok`] হলে পুনরাবৃত্তি একটি মান দেয় otherwise
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // উত্সাহী এবং অলস মানগুলিতে বুলিয়ান ক্রিয়াকলাপ
    /////////////////////////////////////////////////////////////////////////

    /// ফলাফলটি [`Ok`] হলে `res` প্রদান করে, অন্যথায় `self` এর [`Err`] মান প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// ফলাফলটি [`Ok`] হলে `op` কল করে, অন্যথায় `self` এর [`Err`] মান প্রদান করে।
    ///
    ///
    /// এই ফাংশনটি `Result` মানগুলির উপর ভিত্তি করে নিয়ন্ত্রণ প্রবাহের জন্য ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// ফলাফলটি [`Err`] হলে `res` প্রদান করে, অন্যথায় `self` এর [`Ok`] মান প্রদান করে।
    ///
    /// `or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// ফলাফলটি [`Err`] হলে `op` কল করে, অন্যথায় `self` এর [`Ok`] মান প্রদান করে।
    ///
    ///
    /// এই ফাংশনটি ফলাফলের মানগুলির ভিত্তিতে নিয়ন্ত্রণ প্রবাহের জন্য ব্যবহার করা যেতে পারে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// এতে থাকা [`Ok`] মান বা প্রদত্ত ডিফল্টটি প্রদান করে।
    ///
    /// `unwrap_or` এ দেওয়া আর্গুমেন্টগুলি আগ্রহের সাথে মূল্যায়ন করা হয়;যদি আপনি কোনও ফাংশন কলের ফলাফলটি পাস করে থাকেন তবে এটি [`unwrap_or_else`] ব্যবহার করার পরামর্শ দেওয়া হচ্ছে, যা অলসভাবে মূল্যায়ন করা হয়।
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// অন্তর্ভুক্ত থাকা [`Ok`] মানটি ফেরত দেয় বা একটি বন্ধ হওয়া থেকে এটি গণনা করে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// `self` মানটি ব্যবহার করে, এতে থাকা [`Ok`] মানটি দেয়, মানটি কোনও [`Err`] নয় তা পরীক্ষা করে না।
    ///
    ///
    /// # Safety
    ///
    /// [`Err`] এ এই পদ্ধতিটি কল করা হ'ল *[অপরিবর্তিত আচরণ]*।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // নির্ধারিত আচরণ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে।
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// `self` মানটি ব্যবহার করে, এতে থাকা [`Err`] মানটি দেয়, মানটি কোনও [`Ok`] নয় তা পরীক্ষা করে না।
    ///
    ///
    /// # Safety
    ///
    /// [`Ok`] এ এই পদ্ধতিটি কল করা হ'ল *[অপরিবর্তিত আচরণ]*।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // নির্ধারিত আচরণ!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে।
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` অংশের বিষয়বস্তু অনুলিপি করে একটি এক্স 100 এক্সকে একটি এক্স01 এক্সে মানচিত্র করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` অংশের বিষয়বস্তু অনুলিপি করে একটি এক্স 100 এক্সকে একটি এক্স01 এক্সে মানচিত্র করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` অংশের বিষয়বস্তু ক্লোন করে একটি `Result<&T, E>` কে `Result<T, E>` মানচিত্র করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` অংশের বিষয়বস্তু ক্লোন করে একটি `Result<&mut T, E>` কে `Result<&mut T, E>` এ মানচিত্র করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Ok`] মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি [`Err`] হয় তবে একটি panic বার্তা এবং [`Err`] এর সামগ্রী সহ একটি panic বার্তা থাকে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Ok`] মান প্রদান করে।
    ///
    /// এই ফাংশনটি panic হতে পারে, এর ব্যবহারটি সাধারণত নিরুৎসাহিত করা হয়।
    /// পরিবর্তে, প্যাটার্ন মিলটি ব্যবহার করতে এবং স্পষ্টভাবে [`Err`] কেসটিকে পরিচালনা করতে পছন্দ করুন বা এক্স01 এক্স, এক্স02 এক্স, বা এক্স 100 এক্সকে কল করুন।
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি একটি [`Err`] হয় তবে [`এরে] এর মান দ্বারা সরবরাহিত একটি জেড 0 প্যানিক0 জেড বার্তা রয়েছে।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Err`] মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি [`Ok`] হয় তবে একটি panic বার্তা এবং [`Ok`] এর সামগ্রী সহ একটি panic বার্তা থাকে।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` মানটি ব্যবহার করে অন্তর্ভুক্ত থাকা [`Err`] মান প্রদান করে।
    ///
    /// # Panics
    ///
    /// Panics যদি মানটি একটি [`Ok`] হয় তবে [`Ok`] এর মান দ্বারা সরবরাহিত একটি কাস্টম panic বার্তা রয়েছে।
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// থাকা [`Ok`] মান বা একটি ডিফল্ট প্রদান করে
    ///
    /// `self` টি আর্গুমেন্ট গ্রহণ করে তারপরে, যদি [`Ok`] থাকে তবে থাকা মানটি ফেরত দেয়, অন্যথায় যদি [`Err`] হয় তবে এই ধরণের জন্য ডিফল্ট মান প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// একটি স্ট্রিংকে পূর্ণসংখ্যায় রূপান্তরিত করে, খারাপভাবে গঠিত স্ট্রিংগুলিকে 0 (পূর্ণসংখ্যার জন্য ডিফল্ট মান) তে পরিণত করে।
    /// [`parse`] [`FromStr`] প্রয়োগ করে অন্য কোনও ধরণের স্ট্রিং রূপান্তর করে, ত্রুটিতে একটি [`Err`] প্রদান করে।
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// এতে থাকা [`Ok`] মানটি প্রদান করে তবে panics কখনই নয়।
    ///
    /// [`unwrap`] এর বিপরীতে, এই পদ্ধতিটি এর জন্য বাস্তবায়িত ফলাফলের ধরণের ক্ষেত্রে কখনই panic হিসাবে পরিচিত।
    /// সুতরাং, এটি `unwrap` এর পরিবর্তে একটি রক্ষণাবেক্ষণযোগ্য সুরক্ষা হিসাবে ব্যবহার করা যেতে পারে যা `Result` এর ত্রুটির ধরণটি পরে ঘটতে পারে এমন একটি ত্রুটিতে পরিবর্তিত হলে সংকলন করতে ব্যর্থ হবে।
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (বা `&Result<T, E>`) থেকে `Result<&<T as Deref>::Target, &E>` এ রূপান্তর করে।
    ///
    /// [`Deref`](crate::ops::Deref) এর মাধ্যমে মূল [`Result`] এর [`Ok`] বৈকল্পিক Coerces এবং নতুন [`Result`] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (বা `&mut Result<T, E>`) থেকে `Result<&mut <T as DerefMut>::Target, &mut E>` এ রূপান্তর করে।
    ///
    /// [`DerefMut`](crate::ops::DerefMut) এর মাধ্যমে মূল [`Result`] এর [`Ok`] বৈকল্পিক Coerces এবং নতুন [`Result`] প্রদান করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` এর একটি `Result` কে `Result` এর `Option` রূপান্তর করে।
    ///
    /// `Ok(None)` `None` এ ম্যাপ করা হবে।
    /// `Ok(Some(_))` এবং `Err(_)` কে `Some(Ok(_))` এবং `Some(Err(_))` এ ম্যাপ করা হবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` থেকে `Result<T, E>` এ রূপান্তর করে
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// সমতলকরণ একবারে বাসা বাঁধার এক স্তরকে সরিয়ে দেয়:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` হলে [`Ok`] মান এবং `self` যদি `Err` এক্স হয় তবে [`Err`] মান প্রদান করে।
    ///
    /// অন্য কথায়, এই ফাংশনটি `Ok` বা `Err` কিনা তা নির্বিশেষে কোনও `Result<T, T>` এর মান (`T`) প্রদান করে।
    ///
    /// এটি [`Atomic*::compare_exchange`], বা [`slice::binary_search`] এর মতো এপিআইয়ের সাথে একত্রে কার্যকর হতে পারে তবে কেবলমাত্র সেই ক্ষেত্রে যেখানে ফলাফলটি `Ok` ছিল কিনা তা আপনার যত্ন নেই।
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// পদ্ধতিগুলির কোড আকার হ্রাস করার জন্য এটি একটি পৃথক ফাংশন
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait বাস্তবায়ন
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// সম্ভবত ধারণিত মানটির চেয়ে গ্রাসকারী পুনরুক্তি ফেরত দেয়।
    ///
    /// ফলাফলটি [`Result::Ok`] হলে পুনরাবৃত্তি একটি মান দেয় otherwise
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// রেজাল্ট ইটারেটর
/////////////////////////////////////////////////////////////////////////////

/// একটি [`Result`] এর [`Ok`] বৈকল্পিকের রেফারেন্সের উপর একটি পুনরাবৃত্তি।
///
/// ফলাফলটি [`Ok`] হলে পুনরাবৃত্তি একটি মান দেয় otherwise
///
/// এক্স 100 এক্স দ্বারা নির্মিত।
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] এর [`Ok`] বৈকল্পিকের পরিবর্তনীয় রেফারেন্সের উপর একটি পুনরাবৃত্তি।
///
/// এক্স 100 এক্স দ্বারা নির্মিত।
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// একটি [`Result`] এর [`Ok`] ভেরিয়েন্টের মানের উপরে একটি পুনরাবৃত্তি।
///
/// ফলাফলটি [`Ok`] হলে পুনরাবৃত্তি একটি মান দেয় otherwise
///
/// এই কাঠামোটি X0 [`into_iter`] দ্বারা [`Result`] ([`IntoIterator`] trait দ্বারা সরবরাহিত) দ্বারা তৈরি করা হয়েছে।
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` এ প্রতিটি উপাদান নেয়: এটি যদি `Err` হয় তবে আর কোনও উপাদান নেওয়া হবে না এবং `Err` ফেরত দেওয়া হবে।
    /// কোনও `Err` না হওয়া উচিত, প্রতিটি এক্স01 এক্সের মান সহ একটি ধারক ফিরে আসে।
    ///
    /// এখানে একটি উদাহরণ যা একটি vector প্রতিটি সংখ্যার বৃদ্ধি করে, ওভারফ্লো পরীক্ষা করে:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// এখানে আরেকটি উদাহরণ যা অন্য একটি পূর্ণসংখ্যার তালিকা থেকে একটিকে বিয়োগ করার চেষ্টা করে, এবার আন্ডারফ্লো পরীক্ষা করছে:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// পূর্ববর্তী উদাহরণে এখানে একটি পার্থক্য রয়েছে যা দেখায় যে প্রথম `Err` এর পরে আর কোনও উপাদান `iter` থেকে নেওয়া হয় না।
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// যেহেতু তৃতীয় উপাদানটি একটি জলের তলদেশ সৃষ্টি করেছিল, তাই আর কোনও উপাদান নেওয়া হয়নি, সুতরাং `shared` এর চূড়ান্ত মান 16 (= `3 + 2 + 1`), 16 নয়।
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): এই পারফরম্যান্স বাগটি বন্ধ হয়ে গেলে এটি Iterator::scan এর সাথে প্রতিস্থাপন করা যেতে পারে।
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}