#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! অন্তর্নির্মিত প্রকারের লেআউটের জন্য কাঠামো সংজ্ঞা রয়েছে।
//!
//! এগুলি সরাসরি কাঁচা উপস্থাপনাগুলি ম্যানিপুলেট করার জন্য অনিরাপদ কোডে ট্রান্সমুটের লক্ষ্য হিসাবে ব্যবহার করা যেতে পারে।
//!
//!
//! তাদের সংজ্ঞাটি সর্বদা `rustc_middle::ty::layout` এ সংজ্ঞায়িত ABI এর সাথে মিলে যায়।
//!

/// `&dyn SomeTrait` এর মতো একটি trait অবজেক্টের উপস্থাপনা।
///
/// এই কাঠামোর `&dyn SomeTrait` এবং `Box<dyn AnotherTrait>` এর মতো ধরণের লেআউট রয়েছে।
///
/// `TraitObject` লেআউটগুলির সাথে ম্যাচ করার গ্যারান্টিযুক্ত তবে এটি trait অবজেক্টের ধরণের নয় (যেমন, ক্ষেত্রগুলি কোনও `&dyn SomeTrait` এ সরাসরি অ্যাক্সেসযোগ্য নয়) বা এটি লেআউটও নিয়ন্ত্রণ করে না (সংজ্ঞাটি পরিবর্তন করলে কোনও `&dyn SomeTrait` এর বিন্যাস পরিবর্তন হবে না)।
///
/// এটি কেবল অনিরাপদ কোড দ্বারা ব্যবহারের জন্য ডিজাইন করা হয়েছে যাতে নিম্ন-স্তরের বিশদটি পরিচালনা করতে হবে।
///
/// সমস্ত trait অবজেক্টকে জেনারালিভাবে উল্লেখ করার কোনও উপায় নেই, সুতরাং এই ধরণের মান তৈরি করার একমাত্র উপায় হ'ল [`std::mem::transmute`][transmute] এর মতো ফাংশনগুলি।
/// একইভাবে, `TraitObject` মান থেকে সত্য trait অবজেক্ট তৈরির একমাত্র উপায় হ'ল `transmute`।
///
/// [transmute]: crate::intrinsics::transmute
///
/// জেড ট্র্যাটিটজেড অবজেক্টটি মেলানো নয় এমন প্রকারের সাথে সংশ্লেষিত করা - এমন এক যেখানে ভিটিবেল সেই মানের ধরণের সাথে মেলে না যেখানে ডেটা পয়েন্টার পয়েন্ট করে und অপরিবর্তিত আচরণের পক্ষে সম্ভাবনা রয়েছে।
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // একটি উদাহরণ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // সংকলকটিকে একটি trait অবজেক্ট তৈরি করতে দিন
/// let object: &dyn Foo = &value;
///
/// // কাঁচা উপস্থাপনা তাকান
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ডেটা পয়েন্টারটি `value` এর ঠিকানা
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` থেকে `i32` vtable ব্যবহার করতে সতর্ক হয়ে, একটি আলাদা এক্স01 এক্সকে নির্দেশ করে একটি নতুন অবজেক্ট তৈরি করুন
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // এটি ঠিক এমনভাবে কাজ করা উচিত যাতে আমরা `other_value` এর বাইরে একটি trait অবজেক্ট তৈরি করেছি
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}