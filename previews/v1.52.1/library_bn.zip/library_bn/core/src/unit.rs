use crate::iter::FromIterator;

/// একটি পুনরাবৃত্তকারী থেকে সমস্ত ইউনিট আইটেমগুলিকে একটিতে সঙ্কুচিত করে।
///
/// এক্স-এক্স এক্স সংগ্রহ করার মতো উচ্চ-স্তরের বিমূর্তির সাথে একত্রিত হলে এটি আরও কার্যকর হয় যেখানে আপনি কেবল ত্রুটিগুলির যত্ন নেন:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}