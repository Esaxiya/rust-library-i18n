//! UTF-8 এবং UTF-16 ডিকোডিং পুনরাবৃত্তি

use crate::fmt;

use super::from_u32_unchecked;

/// একটি পুনরুক্তি যা UTF-16 এনকোডড কোড পয়েন্টগুলি odes u16` এর একটি পুনরুক্তি থেকে পয়েন্ট করে points
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// UTF-16 কোড পয়েন্টগুলি ডিকোড করার সময় একটি ত্রুটি ফিরে পাওয়া যায়।
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// `iter`-এ এক্স01 এক্স এনকোডড কোড পয়েন্টগুলির উপর একটি পুনরাবৃত্তকারী তৈরি করে, p এরারস হিসাবে অপরিশোধিত সারোগেটগুলি ফিরিয়ে দেয়।
///
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::char::decode_utf16;
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
///         .collect::<Vec<_>>(),
///     vec![
///         Ok('𝄞'),
///         Ok('m'), Ok('u'), Ok('s'),
///         Err(0xDD1E),
///         Ok('i'), Ok('c'),
///         Err(0xD834)
///     ]
/// );
/// ```
///
/// ক্ষতিকারক ডিকোডারটি `Err` ফলাফলগুলি প্রতিস্থাপনের অক্ষর দ্বারা প্রতিস্থাপনের মাধ্যমে প্রাপ্ত করা যেতে পারে:
///
/// ```
/// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
///        .collect::<String>(),
///     "𝄞mus�ic�"
/// );
/// ```
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[inline]
pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if u < 0xD800 || 0xDFFF < u {
            // সুরক্ষা: কোনও সারোগেট নয়
            Some(Ok(unsafe { from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // একটি পেছনের সারোগেট
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // ট্রেলিং সারোগেট নয় তাই আমরা কোনও বৈধ সারোগেট জুটি নই, সুতরাং পরের বার u2 পুনরায় কোডে ফিরে যেতে।
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // ঠিক আছে, সুতরাং এটি ডিকোড করা যাক।
            let c = (((u - 0xD800) as u32) << 10 | (u2 - 0xDC00) as u32) + 0x1_0000;
            // নিরাপত্তা: আমরা পরীক্ষা করেছিলাম যে এটি একটি আইনী ইউনিকোড মান
            Some(Ok(unsafe { from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();
        // আমরা পুরোপুরি বৈধ সারোগেট (চার্জ প্রতি 2 টি উপাদান), বা সম্পূর্ণ অ-সারোগেট (চারকে প্রতি 1 উপাদান) হতে পারি
        //
        (low / 2, high)
    }
}

impl DecodeUtf16Error {
    /// এই ত্রুটিজনিত কারণে অযৌক্তিক সারোগেট প্রদান করে।
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}