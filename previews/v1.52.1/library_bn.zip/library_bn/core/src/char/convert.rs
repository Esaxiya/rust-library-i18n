//! চরিত্র রূপান্তর।

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` কে `char` এ রূপান্তর করে।
///
/// মনে রাখবেন যে সমস্ত [`char`] গুলি বৈধ [`u32`] গুলি, এবং এর সাথে একটিতে কাস্ট করা যেতে পারে
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// তবে, বিপরীতটি সত্য নয়: সমস্ত বৈধ [`u32`] গুলি বৈধ [`চর`] গুলি নয়।
/// `from_u32()` এক্সপুট এক্স [`char`] এর জন্য যদি ইনপুটটি বৈধ মান না হয় তবে `None` প্রদান করবে।
///
/// এই ফাংশনটির অনিরাপদ সংস্করণে যা এই চেকগুলিকে উপেক্ষা করে, দেখুন [`from_u32_unchecked`]।
///
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ইনপুটটি বৈধ [`char`] না হলে `None` রিটার্নিং:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// বৈধতা উপেক্ষা করে একটি `u32` কে `char` এ রূপান্তর করে।
///
/// মনে রাখবেন যে সমস্ত [`char`] গুলি বৈধ [`u32`] গুলি, এবং এর সাথে একটিতে কাস্ট করা যেতে পারে
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// তবে, বিপরীতটি সত্য নয়: সমস্ত বৈধ [`u32`] গুলি বৈধ [`চর`] গুলি নয়।
/// `from_u32_unchecked()` এটি উপেক্ষা করবে এবং অন্ধভাবে [`char`] এ কাস্ট করবে, সম্ভবত একটি অবৈধ তৈরি করবে।
///
///
/// # Safety
///
/// এই ফাংশনটি অনিরাপদ, কারণ এটি অবৈধ `char` মান তৈরি করতে পারে।
///
/// এই ফাংশনের নিরাপদ সংস্করণের জন্য, [`from_u32`] ফাংশনটি দেখুন।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `i` একটি বৈধ চর মান।
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] কে [`u32`] এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] কে [`u64`] এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // চরটি কোড পয়েন্টের মান হিসাবে কাস্ট করা হয়, তারপরে শূন্য-প্রসারিত হয়ে 64৪ বিটে প্রসারিত হয়।
        // এক্স 100 এক্স দেখুন
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] কে [`u128`] এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // চরটি কোড পয়েন্টের মান হিসাবে কাস্ট করা হয়, তারপরে শূন্য-প্রসারিত 128 বিটে।
        // এক্স 100 এক্স দেখুন
        c as u128
    }
}

/// 0x00 এ একটি বাইট মানচিত্র করুন ..=0xFF একটি `char` এর কোড পয়েন্টের সমান মান আছে, ইউ +0000 ..=ইউ + 00 এফ এফ।
///
/// ইউনিকোড এমনভাবে ডিজাইন করা হয়েছে যে এটি আইএএনএ-কে আইএসও-8859-1 কল করে এমন অক্ষর এনকোডিংয়ের সাথে কার্যকরভাবে বাইটগুলি ডিকোড করে।
/// এই এনকোডিংটি ASCII এর সাথে সামঞ্জস্যপূর্ণ।
///
/// দ্রষ্টব্য যে এটি ISO/IEC 8859-1 ওরফে থেকে আলাদা
/// আইএসও 8859-1 (একটি কম হাইফেন সহ), যা কিছু এক্স 100 এক্স, বাইট মানগুলিকে ছেড়ে দেয় যা কোনও বর্ণকে বরাদ্দ করা হয় না।
/// আইএসও-8859-1 (আইএএনএ এক) তাদের C0 এবং C1 নিয়ন্ত্রণ কোডগুলিতে নিয়োগ দেয়।
///
/// মনে রাখবেন যে এটি উইন্ডোজ-১২২২ ওরফে থেকেও আলাদা different
/// কোড পৃষ্ঠা 1252, যা একটি সুপারসেট ISO/IEC 8859-1 যা কিছু বিরামচিহ্ন এবং বিভিন্ন লাতিন অক্ষরে কিছু (সমস্ত না!) ফাঁকা বরাদ্দ করে।
///
/// জিনিসগুলিকে আরও বিভ্রান্ত করার জন্য, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, এবং `windows-1252` উইন্ডোজ-1222 এর একটি সুপারসেটের জন্য সমস্ত এলিয়াস যা সম্পর্কিত শূন্যস্থানগুলি C0 এবং C1 নিয়ন্ত্রণ কোড সহ পূরণ করে।
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] কে [`char`] এ রূপান্তর করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// একটি ত্রুটি যা চরকে বিশ্লেষণ করার সময় ফেরত দেওয়া যেতে পারে।
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // নিরাপদ: এটি একটি আইনী ইউনিকোড মান পরীক্ষা করেছে
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 থেকে চরে রূপান্তর ব্যর্থ হলে ত্রুটির ধরণটি ফিরে আসে।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// প্রদত্ত রেডিক্সের একটি অঙ্ককে একটি `char` এ রূপান্তর করে।
///
/// এখানে একটি 'radix' কখনও কখনও 'base' ও বলা হয়।
/// দুইটির একটি রেডিক্স একটি বাইনারি সংখ্যা, দশটির দশমিক, দশমিক এবং একটি ষোড়শ, হেক্সাডেসিমাল এর একটি মূলকে নির্দেশ করে কিছু সাধারণ মান দেয়।
///
/// নির্বিচারে রেডিসিকে সমর্থন করা হয়।
///
/// `from_digit()` প্রদত্ত রেডিক্সে যদি ইনপুটটি অঙ্ক না হয় তবে `None` প্রদান করবে।
///
/// # Panics
///
/// জেড 0 প্যানিক্স0 জেড যদি 36 এর চেয়ে বড় রেডিক্স দেওয়া হয়।
///
/// # Examples
///
/// বেসিক ব্যবহার:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // দশমিক 11 বেস 16 এ একক অঙ্ক
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ইনপুটটি কোনও অঙ্ক না হলে এক্স 100 এক্স রিটার্ন করা:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// একটি বড় রেডিক্স পাস করা, একটি panic এর কারণ:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}