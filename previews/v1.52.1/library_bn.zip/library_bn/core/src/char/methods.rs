//! ইমপ্লের চর {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// এক্সএক্সএক্সের সর্বোচ্চ বৈধ কোড পয়েন্ট থাকতে পারে।
    ///
    /// একটি `char` একটি [Unicode Scalar Value], যার অর্থ এটি একটি [Code Point], তবে নির্দিষ্ট সীমার মধ্যে কেবলমাত্র।
    /// `MAX` একটি বৈধ [Unicode Scalar Value] এর মধ্যে সর্বোচ্চ বৈধ কোড পয়েন্ট।
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` ইউনিকোডে ডিকোডিংয়ের ত্রুটি উপস্থাপন করতে () ব্যবহৃত হয়।
    ///
    /// এটি ঘটতে পারে, উদাহরণস্বরূপ, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-এ যখন খারাপ-গঠিত UTF-8 বাইট দেওয়ার সময়।
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) এর যে সংস্করণটি `char` এবং `str` পদ্ধতির ইউনিকোড অংশগুলি ভিত্তিক।
    ///
    /// ইউনিকোডের নতুন সংস্করণগুলি নিয়মিত প্রকাশিত হয় এবং পরবর্তীকালে ইউনিকোডের উপর নির্ভর করে স্ট্যান্ডার্ড লাইব্রেরিতে সমস্ত পদ্ধতি আপডেট করা হয়।
    /// তাই কিছু এক্স 100 এক্স এবং এক্স01 এক্স পদ্ধতির আচরণ এবং এই ধ্রুবকের মান সময়ের সাথে সাথে পরিবর্তন ঘটে।
    /// এটি *একটি* ব্রেকিং পরিবর্তন হিসাবে বিবেচিত হয় না।
    ///
    /// সংস্করণ নম্বরকরণ স্কিমটি [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) এ ব্যাখ্যা করা হয়েছে।
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter`-এ এক্স01 এক্স এনকোডড কোড পয়েন্টগুলির উপর একটি পুনরাবৃত্তকারী তৈরি করে, p এরারস হিসাবে অপরিশোধিত সারোগেটগুলি ফিরিয়ে দেয়।
    ///
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ক্ষতিকারক ডিকোডারটি `Err` ফলাফলগুলি প্রতিস্থাপনের অক্ষর দ্বারা প্রতিস্থাপনের মাধ্যমে প্রাপ্ত করা যেতে পারে:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` কে `char` এ রূপান্তর করে।
    ///
    /// মনে রাখবেন যে সমস্ত চার্জ বৈধ [`u32`] এর, এবং এর সাথে একটিতে কাস্ট করা যেতে পারে
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// তবে, বিপরীতটি সত্য নয়: সমস্ত বৈধ [`u32`] গুলি বৈধ` চার্জ নয়।
    /// `from_u32()` এক্সপুট এক্স `char` এর জন্য যদি ইনপুটটি বৈধ মান না হয় তবে `None` প্রদান করবে।
    ///
    /// এই ফাংশনটির অনিরাপদ সংস্করণে যা এই চেকগুলিকে উপেক্ষা করে, দেখুন [`from_u32_unchecked`]।
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ইনপুটটি বৈধ `char` না হলে `None` রিটার্নিং:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// বৈধতা উপেক্ষা করে একটি `u32` কে `char` এ রূপান্তর করে।
    ///
    /// মনে রাখবেন যে সমস্ত চার্জ বৈধ [`u32`] এর, এবং এর সাথে একটিতে কাস্ট করা যেতে পারে
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// তবে, বিপরীতটি সত্য নয়: সমস্ত বৈধ [`u32`] গুলি বৈধ` চার্জ নয়।
    /// `from_u32_unchecked()` এটি উপেক্ষা করবে এবং অন্ধভাবে `char` এ কাস্ট করবে, সম্ভবত একটি অবৈধ তৈরি করবে।
    ///
    ///
    /// # Safety
    ///
    /// এই ফাংশনটি অনিরাপদ, কারণ এটি অবৈধ `char` মান তৈরি করতে পারে।
    ///
    /// এই ফাংশনের নিরাপদ সংস্করণের জন্য, [`from_u32`] ফাংশনটি দেখুন।
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // সুরক্ষা: সুরক্ষা চুক্তি অবশ্যই ফোনকারীকে বহাল রাখতে হবে।
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// প্রদত্ত রেডিক্সের একটি অঙ্ককে একটি `char` এ রূপান্তর করে।
    ///
    /// এখানে একটি 'radix' কখনও কখনও 'base' ও বলা হয়।
    /// দুইটির একটি রেডিক্স একটি বাইনারি সংখ্যা, দশটির দশমিক, দশমিক এবং একটি ষোড়শ, হেক্সাডেসিমাল এর একটি মূলকে নির্দেশ করে কিছু সাধারণ মান দেয়।
    ///
    /// নির্বিচারে রেডিসিকে সমর্থন করা হয়।
    ///
    /// `from_digit()` প্রদত্ত রেডিক্সে যদি ইনপুটটি অঙ্ক না হয় তবে `None` প্রদান করবে।
    ///
    /// # Panics
    ///
    /// জেড 0 প্যানিক্স0 জেড যদি 36 এর চেয়ে বড় রেডিক্স দেওয়া হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // দশমিক 11 বেস 16 এ একক অঙ্ক
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ইনপুটটি কোনও অঙ্ক না হলে এক্স 100 এক্স রিটার্ন করা:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// একটি বড় রেডিক্স পাস করা, একটি panic এর কারণ:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// প্রদত্ত রেডিক্সে একটি `char` একটি সংখ্যা কিনা তা পরীক্ষা করে।
    ///
    /// এখানে একটি 'radix' কখনও কখনও 'base' ও বলা হয়।
    /// দুইটির একটি রেডিক্স একটি বাইনারি সংখ্যা, দশটির দশমিক, দশমিক এবং একটি ষোড়শ, হেক্সাডেসিমাল এর একটি মূলকে নির্দেশ করে কিছু সাধারণ মান দেয়।
    ///
    /// নির্বিচারে রেডিসিকে সমর্থন করা হয়।
    ///
    /// [`is_numeric()`] এর তুলনায়, এই ফাংশনটি কেবলমাত্র `0-9`, `a-z` এবং `A-Z` অক্ষরগুলি স্বীকৃতি দেয়।
    ///
    /// 'Digit' শুধুমাত্র নিম্নলিখিত অক্ষর হিসাবে সংজ্ঞায়িত করা হয়:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' এর আরও বিস্তৃত বোঝার জন্য, [`is_numeric()`] দেখুন।
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// জেড 0 প্যানিক্স0 জেড যদি 36 এর চেয়ে বড় রেডিক্স দেওয়া হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// একটি বড় রেডিক্স পাস করা, একটি panic এর কারণ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// প্রদত্ত র‌্যাডিক্সে একটি এক্স00 এক্সকে একটি অঙ্কে রূপান্তর করে।
    ///
    /// এখানে একটি 'radix' কখনও কখনও 'base' ও বলা হয়।
    /// দুইটির একটি রেডিক্স একটি বাইনারি সংখ্যা, দশটির দশমিক, দশমিক এবং একটি ষোড়শ, হেক্সাডেসিমাল এর একটি মূলকে নির্দেশ করে কিছু সাধারণ মান দেয়।
    ///
    /// নির্বিচারে রেডিসিকে সমর্থন করা হয়।
    ///
    /// 'Digit' শুধুমাত্র নিম্নলিখিত অক্ষর হিসাবে সংজ্ঞায়িত করা হয়:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// যদি `char` প্রদত্ত রেডিক্সের একটি অঙ্কের উল্লেখ না করে তবে `None` প্রদান করে।
    ///
    /// # Panics
    ///
    /// জেড 0 প্যানিক্স0 জেড যদি 36 এর চেয়ে বড় রেডিক্স দেওয়া হয়।
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ব্যর্থতায় অ-অঙ্কের ফলাফল পাস করা:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// একটি বড় রেডিক্স পাস করা, একটি panic এর কারণ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` ধ্রুবক এবং 10 বা এর চেয়ে কম ক্ষেত্রে যেগুলির ক্ষেত্রে এক্সিকিউশন গতির উন্নতি করতে কোডটি এখানে বিভক্ত হয়েছে
        //
        let val = if likely(radix <= 10) {
            // যদি একটি অঙ্ক না হয় তবে মূল্যের চেয়ে বড় একটি সংখ্যা তৈরি করা হবে।
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// এমন একটি পুনরাবৃত্তি প্রদান করে যা character চার্জ হিসাবে একটি চরিত্রের হেক্সাডেসিমাল ইউনিকোড পলায়ন লাভ করে।
    ///
    /// এটি `\u{NNNNNN}` ফর্মের Rust সিনট্যাক্সের অক্ষরগুলি থেকে মুক্তি পাবে যেখানে `NNNNNN` হেক্সাডেসিমাল উপস্থাপনা।
    ///
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // বা-আইং 1 নিশ্চিত করে যে সি==0 এর জন্য কোড গণনা করে যে একটি অঙ্ক মুদ্রিত করা উচিত এবং (যা একই) পাতাল (31, 32) এড়ানো যায়
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // সর্বাধিক উল্লেখযোগ্য হেক্স অঙ্কের সূচক
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` এর একটি বর্ধিত সংস্করণ যা optionচ্ছিকভাবে প্রসারিত গ্রাফেম কোডপয়েন্টগুলিকে ছাড়ার অনুমতি দেয়।
    /// এটি আমাদের যখন স্ট্রিংয়ের শুরুতে হয় তখন আরও ভাল চিহ্নগুলির মতো অক্ষরগুলিকে ফর্ম্যাট করতে দেয়।
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// এমন একটি পুনরাবৃত্তি প্রদান করে যা একটি চরিত্রের। চার্জ হিসাবে আক্ষরিক অব্যাহতি কোড দেয়।
    ///
    /// এটি `str` বা `char` এর `Debug` বাস্তবায়নের অনুরূপ অক্ষরগুলি থেকে মুক্তি পাবে।
    ///
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// এমন একটি পুনরাবৃত্তি প্রদান করে যা একটি চরিত্রের। চার্জ হিসাবে আক্ষরিক অব্যাহতি কোড দেয়।
    ///
    /// জেড 0 সি ++ 0 জেড 11 এবং অনুরূপ সি-পারিবারিক ভাষা সহ বিভিন্ন ভাষায় বৈধ যে আক্ষরিক উত্পাদন করার দিকে পক্ষপাতিত্বের সাথে ডিফল্টটি বেছে নেওয়া হয়।
    /// সঠিক বিধিগুলি হ'ল:
    ///
    /// * ট্যাবটি `\t` হিসাবে পালানো হয়েছে।
    /// * এক্সপ্রেস এক্স 100 এক্স হিসাবে পালানো যায়।
    /// * লাইন ফিড `\n` হিসাবে পালানো হয়েছে।
    /// * একক উদ্ধৃতিটি `\'` হিসাবে পালানো হয়েছে।
    /// * ডাবল উদ্ধৃতিটি `\"` হিসাবে পালানো হয়েছে।
    /// * ব্যাকস্ল্যাশ `\\` হিসাবে পালানো হয়েছে।
    /// * 'প্রিন্টযোগ্য এএসসিআইআই' রেঞ্জের কোনও অক্ষর `0x20` .. `0x7e` সহ অন্তর্ভুক্ত নয়।
    /// * অন্যান্য সমস্ত অক্ষরকে হেক্সাডেসিমাল ইউনিকোড পলায়ন দেওয়া হয়;এক্স 100 এক্স দেখুন।
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 এ এনকোড করা থাকলে এই `char` এর বয়েটের সংখ্যাটি প্রদান করে।
    ///
    /// বাইটের এই সংখ্যাটি সর্বদা 1 এবং 4 এর মধ্যে থাকে lusive
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` ধরণের গ্যারান্টি দেয় যে এর লিখিত সামগ্রীগুলি UTF-8, এবং তাই আমরা প্রতিটি কোড পয়েন্টকে `&str` বনাম `char` বনাম হিসাবে প্রতিনিধিত্ব করা হলে এটি যে দৈর্ঘ্যটি গ্রহণ করবে তা তুলনা করতে পারি:
    ///
    ///
    /// ```
    /// // চর হিসাবে
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // উভয়কে তিন বাইট হিসাবে উপস্থাপন করা যেতে পারে
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // একটি &str হিসাবে, এই দুটি UTF-8 এ এনকোড করা আছে
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // আমরা দেখতে পাচ্ছি যে তারা মোট ছয় বাইট নেয় ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ঠিক &str এর মতো
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 এ এনকোড করা থাকলে এই `char` এর জন্য 16-বিট কোড ইউনিটের সংখ্যাটি দেয়।
    ///
    ///
    /// এই ধারণার আরও ব্যাখ্যার জন্য [`len_utf8()`] এর জন্য ডকুমেন্টেশন দেখুন।
    /// এই ফাংশনটি একটি আয়না, তবে UTF-8 এর পরিবর্তে UTF-8 এর জন্য।
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// প্রদত্ত বাইট বাফারটিতে এই চরিত্রটিকে UTF-8 হিসাবে এনকোড করে এবং তারপরে এনকোড করা অক্ষরযুক্ত বাফারের সাব্লাইস ফিরে আসে।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি বাফার যথেষ্ট পরিমাণে বড় না হয়।
    /// চারটি দৈর্ঘ্যের একটি বাফার কোনও `char` এনকোড করার জন্য যথেষ্ট বড়।
    ///
    /// # Examples
    ///
    /// এই উভয় উদাহরণে, 'ß' এনকোড করতে দুটি বাইট নেয়।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// খুব ছোট একটি বাফার:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // নিরাপদ: `char` কোনও সারোগেট নয়, সুতরাং এটি কার্যকর UTF-8।
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// প্রদত্ত `u16` বাফারে এই চরিত্রটিকে UTF-16 হিসাবে এনকোড করে এবং তারপরে এনকোডযুক্ত অক্ষরযুক্ত বাফারের সাব্লাইস ফিরে আসে।
    ///
    ///
    /// # Panics
    ///
    /// Panics যদি বাফার যথেষ্ট পরিমাণে বড় না হয়।
    /// দৈর্ঘ্যের 2 টি বাফার কোনও এক্স 100 এক্সকে এনকোড করার জন্য যথেষ্ট বড়।
    ///
    /// # Examples
    ///
    /// এই উভয় উদাহরণে, '𝕊' এনকোড করতে দুটি takes u16` নেয়।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// খুব ছোট একটি বাফার:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// যদি এই `char` এর `Alphabetic` সম্পত্তি থাকে তবে `true` প্রদান করে।
    ///
    /// `Alphabetic` [Unicode Standard] এর অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) এ বর্ণিত হয়েছে এবং [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] এ নির্দিষ্ট করা হয়েছে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // প্রেম অনেক জিনিস, কিন্তু এটি বর্ণমালা নয়
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// যদি এই `char` এর `Lowercase` সম্পত্তি থাকে তবে `true` প্রদান করে।
    ///
    /// `Lowercase` [Unicode Standard] এর অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) এ বর্ণিত হয়েছে এবং [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] এ নির্দিষ্ট করা হয়েছে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // বিভিন্ন চীনা স্ক্রিপ্ট এবং বিরামচিহ্নগুলির ক্ষেত্রে কেস নেই এবং তাই:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// যদি এই `char` এর `Uppercase` সম্পত্তি থাকে তবে `true` প্রদান করে।
    ///
    /// `Uppercase` [Unicode Standard] এর অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) এ বর্ণিত হয়েছে এবং [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] এ নির্দিষ্ট করা হয়েছে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // বিভিন্ন চীনা স্ক্রিপ্ট এবং বিরামচিহ্নগুলির ক্ষেত্রে কেস নেই এবং তাই:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// যদি এই `char` এর `White_Space` সম্পত্তি থাকে তবে `true` প্রদান করে।
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] এ নির্দিষ্ট করা আছে।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // একটি বিরতিহীন স্থান
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` প্রদান করে যদি এই `char` [`is_alphabetic()`] বা [`is_numeric()`] এর মধ্যে সন্তুষ্ট হয়।
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// যদি এই `char` নিয়ন্ত্রণ কোডের জন্য সাধারণ বিভাগ থাকে তবে `true` প্রদান করে।
    ///
    /// কন্ট্রোল কোডগুলি (`Cc` এর সাধারণ বিভাগের সাথে কোড পয়েন্ট) [Unicode Standard] এর অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) এ বর্ণিত হয়েছে এবং [Unicode Character Database][ucd] [`UnicodeData.txt`] এ নির্দিষ্ট করা হয়েছে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// // U + 009C, STRING শর্তাবলী
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// যদি এই `char` এর `Grapheme_Extend` সম্পত্তি থাকে তবে `true` প্রদান করে।
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] এ বর্ণিত এবং [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] এ নির্দিষ্ট করা হয়েছে।
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// এই `char` সংখ্যার জন্য একটি সাধারণ বিভাগে থাকলে `true` প্রদান করে।
    ///
    /// সংখ্যার জন্য সাধারণ বিভাগগুলি (দশমিক অঙ্কের জন্য `Nd`, বর্ণের মতো সংখ্যার অক্ষরের জন্য `Nl` এবং অন্যান্য সংখ্যার অক্ষরের জন্য `No`) নির্দিষ্ট করা হয় [Unicode Character Database][ucd] [`UnicodeData.txt`] in
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// বেসিক ব্যবহার:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// এক বা একাধিক হিসাবে এই `char` এর ছোট হাতের ম্যাপিং দেয় এমন একটি পুনরাবৃত্তি ফেরত দেয়
    /// `char`s.
    ///
    /// এই `char` এর যদি ছোট হাতের ম্যাপিং না থাকে তবে পুনরাবৃত্তিটি একই `char` দেয়।
    ///
    /// যদি এই `char`-এ [Unicode Character Database][ucd] [`UnicodeData.txt`] প্রদত্ত এক থেকে এক লোকেসके ম্যাপিং থাকে তবে পুনরাবৃত্তিটি `char` দেয়।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// এই `char` এর জন্য যদি বিশেষ বিবেচনার প্রয়োজন হয় (যেমন একাধিক `চার্জ) তবে পুনরুক্তিটি [`SpecialCasing.txt`] দ্বারা প্রদত্ত` চার্ট (গুলি) দেয়।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// এই অপারেশনটি সেলাই ছাড়াই নিঃশর্ত ম্যাপিং করে।অর্থাৎ রূপান্তরটি প্রসঙ্গ এবং ভাষা থেকে স্বতন্ত্র।
    ///
    /// এক্স00 এক্স-এ, অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) সাধারণভাবে কেস ম্যাপিং নিয়ে আলোচনা করে এবং অধ্যায় 3 এক্স01 এক্স কেস রূপান্তর করার জন্য ডিফল্ট অ্যালগরিদম নিয়ে আলোচনা করে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // কখনও কখনও ফলাফল একাধিক চরিত্রের হয়:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // যে অক্ষরগুলি বড় হাতের এবং ছোট হাতের না উভয়ই তাদের মধ্যে রূপান্তর করে।
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// এক বা একাধিক হিসাবে এই `char` এর বড় আকারের ম্যাপিং দেয় এমন একটি পুনরাবৃত্তি ফেরত দেয়
    /// `char`s.
    ///
    /// যদি এই `char` এর বড় হাতের ম্যাপিং না থাকে তবে পুনরুক্তিটি একই `char` লাভ করে।
    ///
    /// যদি এই `char`-এ [Unicode Character Database][ucd] [`UnicodeData.txt`] প্রদত্ত এক-এক-এক বৃহত আকারের ম্যাপিং থাকে, তবে পুনরাবৃত্তিটি `char` দেয়।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// এই `char` এর জন্য যদি বিশেষ বিবেচনার প্রয়োজন হয় (যেমন একাধিক `চার্জ) তবে পুনরুক্তিটি [`SpecialCasing.txt`] দ্বারা প্রদত্ত` চার্ট (গুলি) দেয়।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// এই অপারেশনটি সেলাই ছাড়াই নিঃশর্ত ম্যাপিং করে।অর্থাৎ রূপান্তরটি প্রসঙ্গ এবং ভাষা থেকে স্বতন্ত্র।
    ///
    /// এক্স00 এক্স-এ, অধ্যায় 4 (চরিত্রের বৈশিষ্ট্য) সাধারণভাবে কেস ম্যাপিং নিয়ে আলোচনা করে এবং অধ্যায় 3 এক্স01 এক্স কেস রূপান্তর করার জন্য ডিফল্ট অ্যালগরিদম নিয়ে আলোচনা করে।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// পুনরুক্তিকারী হিসাবে:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` সরাসরি ব্যবহার:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// উভয় সমান:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ব্যবহার:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // কখনও কখনও ফলাফল একাধিক চরিত্রের হয়:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // যে অক্ষরগুলি বড় হাতের এবং ছোট হাতের না উভয়ই তাদের মধ্যে রূপান্তর করে।
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # লোকালে নোট
    ///
    /// তুর্কি ভাষায়, লাতিনে 'i' এর সমতুল্য দুটির পরিবর্তে পাঁচটি ফর্ম রয়েছে:
    ///
    /// * 'Dotless': আমি/ı, কখনও কখনও লেখা ï
    /// * 'Dotted': İ/i
    ///
    /// লক্ষ করুন যে লোয়ারকেস ডটেড এক্স00 এক্স ল্যাটিনের সমান।অতএব:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// এখানে `upper_i` এর মানটি পাঠ্যের ভাষার উপর নির্ভর করে: আমরা যদি `en-US` এ থাকি তবে এটি `"I"` হওয়া উচিত, তবে আমরা যদি `tr_TR` এ থাকি তবে এটি `"İ"` হওয়া উচিত।
    /// `to_uppercase()` এটিকে আমলে নেয় না এবং তাই:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// বিভিন্ন ভাষা জুড়ে।
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// মান ASCII সীমার মধ্যে রয়েছে কিনা তা পরীক্ষা করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// এর ASCII উচ্চতর ক্ষেত্রে সমমানের মানটির একটি অনুলিপি তৈরি করে।
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি বড়হাতে, [`make_ascii_uppercase()`] ব্যবহার করুন।
    ///
    /// অ-এসসিআইআই অক্ষর ছাড়াও ASCII অক্ষরগুলি বড় করতে, [`to_uppercase()`] ব্যবহার করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// তার ASCII লোয়ার কেস সমতুল্য মানটির একটি অনুলিপি তৈরি করে।
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// স্থানটিতে মানটি ছোট করতে, [`make_ascii_lowercase()`] ব্যবহার করুন।
    ///
    /// অ-এসসিআইআই অক্ষর ছাড়াও ASCII অক্ষরগুলি ছোট করতে, [`to_lowercase()`] ব্যবহার করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// দুটি মান একটি ASCII কেস-সংবেদনশীল মিল Che
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` এর সমান।
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// এই ধরণেরটিকে তার ASCII আপার ক্ষেত্রে সমতুল্য রূপান্তর করে।
    ///
    /// 'a' থেকে 'z'-তে ASCII অক্ষরগুলি 'A' থেকে 'Z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন বড় মানের ফেরত দিতে, [`to_ascii_uppercase()`] ব্যবহার করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// এই ধরণের স্থান হিসাবে এটির ASCII লোয়ার কেস সমতুল্যে রূপান্তর করে।
    ///
    /// 'A' থেকে 'Z'-তে ASCII অক্ষরগুলি 'a' থেকে 'z' তে ম্যাপ করা হয়েছে, তবে অ-ASCII অক্ষর অপরিবর্তিত রয়েছে।
    ///
    /// বিদ্যমান মানটি পরিবর্তন না করে একটি নতুন নিম্নতর মানটি ফেরত দিতে, [`to_ascii_lowercase()`] ব্যবহার করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// মানটি ASCII বর্ণমালা অক্ষর কিনা তা পরীক্ষা করে:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', বা
    /// - U + 0061 'a' ..=U + 007A 'z'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// মানটি ASCII বড় হাতের অক্ষর কিনা তা পরীক্ষা করে দেখুন:
    /// U + 0041 'A' ..=ইউ + 005A এক্স 100 এক্স।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// মানটি ASCII ছোট হাতের অক্ষর কিনা তা পরীক্ষা করে:
    /// U + 0061 'a' ..=U + 007A 'z'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// মানটি একটি ASCII অক্ষরযুক্ত অক্ষর কিনা তা পরীক্ষা করে:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', বা
    /// - U + 0061 'a' ..=U + 007A 'z', বা
    /// - ইউ + 0030 এক্স01 এক্স ..=ইউ + 0039 এক্স 100 এক্স।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// মানটি ASCII দশমিক সংখ্যা কিনা তা পরীক্ষা করে:
    /// ইউ + 0030 এক্স01 এক্স ..=ইউ + 0039 এক্স 100 এক্স।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// মানটি ASCII হেক্সাডেসিমাল ডিজিট কিনা তা পরীক্ষা করে:
    ///
    /// - ইউ + 0030 এক্স01 এক্স ..=ইউ + 0039 এক্স 100 এক্স, বা
    /// - U + 0041 'A' ..=ইউ + 0046 'F', বা
    /// - U + 0061 'a' ..=ইউ + 0066 'f'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// মানটি ASCII বিরামচিহ্নের অক্ষর কিনা তা পরীক্ষা করে:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, বা
    /// - ইউ + 003 এ ..=ইউ + 0040 এক্স 100 এক্স, বা
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, বা
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// মানটি ASCII গ্রাফিক চরিত্র কিনা তা পরীক্ষা করে:
    /// U + 0021 '!' ..=U + 007E '~'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// মানটি ASCII সাদা স্থানের অক্ষর কিনা তা পরীক্ষা করে দেখুন:
    /// U + 0020 স্পেস, U + 0009 হরিজনাল ট্যাব, U + 000A লাইন ফিড, ইউ + 000 সি ফর্ম ফিড, বা ইউ + 000 ডি ক্যারিজেস ফিরে আসবে।
    ///
    /// Rust হোয়াটডাব্লুজি ইনফ্রা স্ট্যান্ডার্ডের এক্স00 এক্স ব্যবহার করে।বিস্তৃত ব্যবহারে আরও কয়েকটি সংজ্ঞা রয়েছে।
    /// উদাহরণস্বরূপ, [the POSIX locale][pct]-এ U + 000B ভার্টিকাল ট্যাব পাশাপাশি উপরের সমস্ত অক্ষর অন্তর্ভুক্ত রয়েছে তবে - একেবারে একই স্পেসিফিকেশন থেকে - [বোর্ন জেড শেল0 জেড-এ এক্স01 এক্সের জন্য ডিফল্ট নিয়ম][বিএফএস] কেবল * স্পেস, হারিজেন্টাল ট্যাব এবং হোয়াইটস্পেস হিসাবে লাইন ফিড।
    ///
    ///
    /// আপনি যদি এমন কোনও প্রোগ্রাম লিখছেন যা কোনও বিদ্যমান ফাইল ফর্ম্যাটটি প্রক্রিয়া করবে, তবে এই ফাংশনটি ব্যবহার করার আগে হোয়াইটস্পেসের সেই বিন্যাসটির সংজ্ঞাটি কি তা পরীক্ষা করে দেখুন।
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// মানটি ASCII নিয়ন্ত্রণ অক্ষর কিনা তা পরীক্ষা করে:
    /// U +0000 NUL ..=U + 001F UNIT SEPARATOR, বা U + 007F মুছে ফেলুন।
    /// নোট করুন যে বেশিরভাগ ASCII শ্বেতস্পেস অক্ষরগুলি নিয়ন্ত্রণের অক্ষর, তবে স্পেস নয়।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// প্রদত্ত বাইট বাফারে UTF-8 হিসাবে একটি কাঁচা u32 মান এনকোড করে এবং তারপরে এনকোডযুক্ত অক্ষরযুক্ত বাফারের সাব্লাইস ফিরে আসে।
///
///
/// `char::encode_utf8` এর বিপরীতে, এই পদ্ধতিটি সারোগেট রেঞ্জে কোডপয়েন্টগুলিও পরিচালনা করে।
/// (সারোগেট পরিসরে একটি `char` তৈরির বিষয়টি ইউবি)) ফলাফলটি বৈধ [generalized UTF-8] তবে বৈধ UTF-8 নয়।
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics যদি বাফার যথেষ্ট পরিমাণে বড় না হয়।
/// চারটি দৈর্ঘ্যের একটি বাফার কোনও `char` এনকোড করার জন্য যথেষ্ট বড়।
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// প্রদত্ত `u16` বাফারে UTF-16 হিসাবে একটি কাঁচা u32 মান এনকোড করে এবং তারপরে এনকোডযুক্ত অক্ষরযুক্ত বাফারের সাব্লাইস ফিরে আসে।
///
///
/// `char::encode_utf16` এর বিপরীতে, এই পদ্ধতিটি সারোগেট রেঞ্জে কোডপয়েন্টগুলিও পরিচালনা করে।
/// (সারোগেট রেঞ্জে একটি এক্স 100 এক্স তৈরি করা হয় ইউবি))
///
/// # Panics
///
/// Panics যদি বাফার যথেষ্ট পরিমাণে বড় না হয়।
/// দৈর্ঘ্যের 2 টি বাফার কোনও এক্স 100 এক্সকে এনকোড করার জন্য যথেষ্ট বড়।
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // নিরাপদ: প্রতিটি বাহুতে লিখিত পরিমাণে যথেষ্ট পরিমাণ বিট রয়েছে কিনা তা যাচাই করে
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // বিএমপি পড়ে যায় falls
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // পরিপূরক বিমানগুলি সার্গেটগুলিতে বিভক্ত হয়।
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}