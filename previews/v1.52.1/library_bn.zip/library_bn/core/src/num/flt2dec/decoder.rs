//! পৃথক অংশ এবং ত্রুটি ব্যাপ্তির মধ্যে একটি ভাসমান-পয়েন্টের মান ডিকোড করে।

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ডিকোডযুক্ত স্বাক্ষরিত সসীম মান, যেমন:
///
/// - মূল মানটি `mant * 2^exp` এর সমান।
///
/// - `(mant - minus)*2^exp` থেকে `(mant + plus)* 2^exp` এর যে কোনও সংখ্যা আসল মানের সাথে গোল করবে।
/// এক্স এক্স 1 এক্স এক্স 100 এক্স কেবল তখনই পরিসীমা অন্তর্ভুক্ত।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// স্কেলড ম্যান্টিসা।
    pub mant: u64,
    /// নিম্ন ত্রুটির ব্যাপ্তি।
    pub minus: u64,
    /// উপরের ত্রুটির ব্যাপ্তি।
    pub plus: u64,
    /// বেস 2 তে ভাগ করা এক্সপোনেন্ট।
    pub exp: i16,
    /// ত্রুটির পরিসীমা অন্তর্ভুক্ত থাকাতে সত্য।
    ///
    /// আইইইই 754-তে, এটি সত্য যখন মূল ম্যান্ডিসা সমান ছিল।
    pub inclusive: bool,
}

/// ডিকোডযুক্ত স্বাক্ষরিত মান।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ইনফিনিটিগুলি, হয় ইতিবাচক বা নেতিবাচক।
    Infinite,
    /// জিরো, হয় ধনাত্মক বা নেতিবাচক।
    Zero,
    /// আরও ডিকোডেড ক্ষেত্র সহ সীমাবদ্ধ নম্বর।
    Finite(Decoded),
}

/// একটি ভাসমান পয়েন্ট টাইপ যা `ডিকোডেড করা যেতে পারে।
pub trait DecodableFloat: RawFloat + Copy {
    /// সর্বনিম্ন ধনাত্মক স্বাভাবিক মান।
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// প্রদত্ত ভাসমান পয়েন্ট সংখ্যা থেকে একটি চিহ্ন (সত্যই নেতিবাচক হলে) এবং `FullDecoded` মান প্রদান করে।
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // প্রতিবেশী: (ম্যান্ট, ২, এক্সপ্রেস)-(ম্যান্ট, এক্সপ্রেস)-(ম্যান্ট + ২, এক্সপ্রেস)
            // Float::integer_decode সর্বদা ক্ষতিকারককে সংরক্ষণ করে, তাই ম্যান্টিসাটি নিম্নমানের জন্য মাপা হয়।
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // প্রতিবেশী: (ম্যাকমান্ট, এক্সপ্রেস, ১)-(মিনিমরম্যান্ট, এক্সপ্রেস)-(মাইনরম্যান্ট + ১, এক্সপ্রেস)
                // যেখানে সর্বোচ্চ=ক্ষুদ্রতর * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // প্রতিবেশী: (ম্যান্ট, ১, এক্সপ্রেস)-(ম্যান্ট, এক্সপ্রেস)-(ম্যান্ট + ১, এক্সপ্রেস)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}