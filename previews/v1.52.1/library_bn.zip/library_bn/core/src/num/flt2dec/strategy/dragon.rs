//! "দ্রুত এবং নির্ভুলভাবে প্রিন্টিং ফ্লোটিং-পয়েন্ট নম্বর" এর চিত্র 3 এর প্রায় সরাসরি (তবে কিছুটা অপ্টিমাইজড) জেড 0 রিস্ট0 জেড অনুবাদ [^ 1]।
//!
//!
//! [^1]: Burger, আরজি এবং ডাইবিভিগ, আরকে 1996
//!   দ্রুত এবং নির্ভুলভাবে।সিগপ্ল্যান না।31, 5 (মে। 1996), 108-116।

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) এর জন্য `ডিজিটের প্রাক্ক্যালকুলেটেড অ্যারে
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// এক্স01 এক্স কেবল তখনই ব্যবহারযোগ্য;`scaleN` টি `scale.mul_small(N)` হওয়া উচিত
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ড্রাগনের জন্য সবচেয়ে সংক্ষিপ্ত মোড বাস্তবায়ন।
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // বিন্যাসে `v` নম্বরটি পরিচিত:
    // - `mant * 2^exp` এর সমান;
    // - আসল প্রকারে `(mant - 2 *minus)* 2^exp` এর আগে;এবং
    // - মূল ধরণের `(mant + 2 *plus)* 2^exp` অনুসরণ করে।
    //
    // স্পষ্টতই, `minus` এবং `plus` শূন্য হতে পারে না।(ইনফিনিটিটির জন্য, আমরা সীমার বাইরে মানগুলি ব্যবহার করি)) এছাড়াও আমরা ধরে নিই যে কমপক্ষে একটি ডিজিট উত্পন্ন হয়েছে, অর্থাৎ, X01 এক্সও শূন্য হতে পারে না।
    //
    // এর অর্থ এটিও হ'ল `low = (mant - minus)*2^exp` এবং `high = (mant + plus)* 2^exp` এর মধ্যে যে কোনও সংখ্যা এই সঠিক ভাসমান পয়েন্ট সংখ্যাটিতে মানচিত্র তৈরি করবে, মূল ম্যান্টিসা যখন সমান ছিল (যেমন, `!mant_was_odd`) তখন অন্তর্ভুক্ত সীমানা সহ।
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` এক্স 100 এক্স
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` সন্তুষ্টকারী মূল ইনপুটগুলি থেকে `k_0` অনুমান করুন।
    // আঁটসাঁট `k` সন্তুষ্টিজনক `10^(k-1) < high <= 10^k` পরে গণনা করা হয়।
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // এক্স00 এক্সকে ভগ্নাংশ আকারে রূপান্তর করুন যাতে:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` কে `10^k` দ্বারা বিভক্ত করুন।এখন এক্স 100 এক্স
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (বা `>=`) হলে ফিক্সআপ।
    // আমরা আসলে `scale` পরিবর্তন করছি না, যেহেতু পরিবর্তে আমরা প্রাথমিক গুণটিকে এড়িয়ে যেতে পারি।
    // এখন এক্স00 এক্স এবং আমরা অঙ্কগুলি তৈরি করতে প্রস্তুত।
    //
    // দ্রষ্টব্য যে `d[0]` * শূন্য হতে পারে, যখন `scale - plus < mant < scale`।
    // এই ক্ষেত্রে রাউন্ডিং-আপ শর্তটি (নিচে `up`) অবিলম্বে ট্রিগার করা হবে।
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 দ্বারা `scale` স্কেলিংয়ের সমতুল্য
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // অঙ্ক প্রজন্মের জন্য ক্যাশে `(2, 4, 8) * scale`।
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // আক্রমণকারীরা, যেখানে `d[0..n-1]` এখনও অবধি উত্পন্ন অঙ্কগুলি:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (এভাবে `mant / scale < 10`) যেখানে `d[i..j]` হল `d [i] * 10 ^ (জি) + এর জন্য একটি শর্টহ্যান্ড ...
        // + ডি [জে-১] * 10 + এক্স 100 এক্স।

        // একটি অঙ্ক তৈরি করুন: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // এটি পরিবর্তিত ড্রাগন অ্যালগরিদমের একটি সরলীকৃত বর্ণনা।
        // সুবিধার্থে অনেক মধ্যবর্তী ডেরাইভেশন এবং সম্পূর্ণতা যুক্তি বাদ দেওয়া হয়।
        //
        // পরিবর্তিত আক্রমণকারীদের সাথে শুরু করুন, যেমনটি আমরা `n` আপডেট করেছি:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ধরে নিন যে `d[0..n-1]` `low` এবং `high` এর মধ্যে সংক্ষিপ্ততম প্রতিনিধিত্ব, অর্থাত, `d[0..n-1]` নিম্নলিখিত দুটিকেই সন্তুষ্ট করে তবে `d[0..n-2]` তা দেয় না:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (দ্বিপাক্ষিকতা: `v` পর্যন্ত গোলগুলি অঙ্ক);এবং
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (শেষ সংখ্যাটি সঠিক)
        //
        // দ্বিতীয় শর্তটি `2 * mant <= scale` এ সরল করে।
        // `mant`, `low` এবং `high` এর ক্ষেত্রে আক্রমণকারীদের সমাধান করা প্রথম শর্তের একটি সহজ সংস্করণ দেয়: `-plus < mant < minus`.
        // `-plus < 0 <= mant` সাল থেকে, `mant < minus` এবং `2 * mant <= scale` হলে আমাদের সঠিক সংক্ষিপ্ততম উপস্থাপনা থাকে।
        // (মূল ম্যান্টিসা সমান হলে প্রাক্তনটি `mant <= minus` হয়))
        //
        // যখন দ্বিতীয়টি (`2 * ম্যান্ট> স্কেল`) ধরে না, তখন আমাদের শেষ সংখ্যাটি বাড়ানো দরকার।
        // এই শর্তটি পুনরুদ্ধার করার জন্য এটি যথেষ্ট: আমরা ইতিমধ্যে জানি যে ডিজিট প্রজন্মটি `0 <= v / 10^(k-n) - d[0..n-1] < 1` এর গ্যারান্টি দেয়।
        // এই ক্ষেত্রে, প্রথম শর্তটি `-plus < mant - scale < minus` হয়ে যায়।
        // প্রজন্মের পরে `mant < scale` থেকে, আমাদের এক্স 100 এক্স রয়েছে।
        // (আবার, মূল ম্যান্টিসা সমান হলে এটি `scale <= mant + plus` হয়ে যায়))
        //
        // সংক্ষেপে:
        // - `mant < minus` (বা `<=`) হলে এক্স 100 এক্স (যেমন ডিজিটগুলি রাখুন) থামান এবং বৃত্তাকার করুন।
        // - `scale < mant + plus` (বা `<=`) যখন এক্স 100 এক্স (শেষ সংখ্যাটি বাড়ান) থামান এবং বৃত্তাকার করুন।
        // - অন্যথায় উত্পাদন চালিয়ে যান।
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // আমাদের সংক্ষিপ্ত প্রতিনিধিত্ব আছে, বৃত্তাকারে এগিয়ে যান

        // আক্রমণকারীদের পুনরুদ্ধার।
        // এটি অ্যালগরিদমকে সর্বদা শেষ করে দেয়: `minus` এবং `plus` সর্বদা বৃদ্ধি পায় তবে `mant` কে ক্লিপড মডুলো `scale` এবং `scale` স্থির করা হয়।
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // রাউন্ডিং তখন ঘটে যখন i) কেবল রাউন্ডিং-আপ শর্তটি ট্রিগার করা হয়েছিল, বা ii) উভয় শর্তটি ট্রিগার করা হয়েছিল এবং টাই ব্রেকিংকে রাউন্ডিং পছন্দ করে।
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // যদি বৃত্তাকার আপ দৈর্ঘ্য পরিবর্তন করে, ঘনিষ্ঠ এছাড়াও পরিবর্তন করা উচিত।
        // দেখে মনে হচ্ছে এই শর্তটি সন্তুষ্ট করা খুব কঠিন (সম্ভবত অসম্ভব) তবে আমরা এখানে কেবল নিরাপদ এবং ধারাবাহিকভাবে আছি।
        //
        // নিরাপত্তা: আমরা উপরের সেই স্মৃতিটিকে আরম্ভ করেছি।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // নিরাপত্তা: আমরা উপরের সেই স্মৃতিটিকে আরম্ভ করেছি।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ড্রাগনের জন্য সঠিক এবং স্থির মোড বাস্তবায়ন।
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` সন্তুষ্টকারী মূল ইনপুটগুলি থেকে `k_0` অনুমান করুন।
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` কে `10^k` দ্বারা বিভক্ত করুন।এখন এক্স 100 এক্স
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ফিক্সআপ যখন `mant + plus >= scale`, যেখানে `plus / scale = 10^-buf.len() / 2`।
    // স্থির আকারের bignum রাখতে, আমরা আসলে `mant + floor(plus) >= scale` ব্যবহার করি।
    // আমরা আসলে `scale` পরিবর্তন করছি না, যেহেতু পরিবর্তে আমরা প্রাথমিক গুণটিকে এড়িয়ে যেতে পারি।
    // আবার সংক্ষিপ্ত অ্যালগরিদম দিয়ে, `d[0]` শূন্য হতে পারে তবে শেষ পর্যন্ত গোল হয়ে যাবে।
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 দ্বারা `scale` স্কেলিংয়ের সমতুল্য
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // যদি আমরা শেষ-অঙ্কের সীমাবদ্ধতা নিয়ে কাজ করি তবে ডাবল রাউন্ডিং এড়াতে আমাদের সত্যিকারের রেন্ডারিংয়ের আগে বাফারটি ছোট করতে হবে।
    //
    // নোট করুন যে রাউন্ডিংয়ের সময় আমাদের আবার বাফারটি বড় করতে হবে!
    let mut len = if k < limit {
        // ওফ, আমরা *এক* ডিজিটও উত্পাদন করতে পারি না।
        // এটি সম্ভব যখন বলা হয়, আমরা এক্স 100 এক্স এর মতো কিছু পেয়েছি এবং এটি 10 এর দিকে গোল করা হচ্ছে।
        // আমরা একটি খালি বাফারটি ফিরিয়ে দিই, পরে রাউন্ডিং-আপ কেস ব্যতীত যা `k == limit` হয় এবং ঠিক এক অঙ্ক তৈরি করতে হয়।
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // অঙ্ক প্রজন্মের জন্য ক্যাশে `(2, 4, 8) * scale`।
        // (এটি ব্যয়বহুল হতে পারে, সুতরাং বাফার খালি থাকলে এগুলি গণনা করবেন না))
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // নিম্নলিখিত সংখ্যাগুলি সমস্ত শূন্য, আমরা এখানে থামি * বৃত্তাকার সঞ্চালনের চেষ্টা করবেন না!পরিবর্তে, বাকী অঙ্কগুলি পূরণ করুন।
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // নিরাপত্তা: আমরা উপরের সেই স্মৃতিটিকে আরম্ভ করেছি।
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // নিম্নলিখিত অঙ্কগুলি হু হু হু হু করে 5000 এর আগে যদি আমরা মাঝখানে থামি তবে গোল করা, পূর্বের অঙ্কটি পরীক্ষা করে দেখুন এবং সমান দিকে গোল করার চেষ্টা করুন (অর্থাত্ পূর্ববর্তী সংখ্যাটি সমান হলে বৃত্তাকার এড়ানো)।
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // নিরাপদ: `buf[len-1]` আরম্ভ করা হয়েছে।
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // যদি বৃত্তাকার আপ দৈর্ঘ্য পরিবর্তন করে, ঘনিষ্ঠ এছাড়াও পরিবর্তন করা উচিত।
        // তবে আমাদের কাছে একটি নির্দিষ্ট সংখ্যার অঙ্কের জন্য অনুরোধ করা হয়েছে, সুতরাং বাফারটি পরিবর্তন করবেন না ...
        // নিরাপত্তা: আমরা উপরের সেই স্মৃতিটিকে আরম্ভ করেছি।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... যদি না আমাদের পরিবর্তে স্থির নির্ভুলতার জন্য অনুরোধ করা হয়।
            // আমাদের এটিও খতিয়ে দেখা উচিত, যদি আসল বাফারটি খালি থাকে তবে এক্সটেক্স (জেড0ডিজিজেড কেস) কেবলমাত্র অতিরিক্ত সংখ্যা যুক্ত করা যেতে পারে।
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // নিরাপত্তা: আমরা উপরের সেই স্মৃতিটিকে আরম্ভ করেছি।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}