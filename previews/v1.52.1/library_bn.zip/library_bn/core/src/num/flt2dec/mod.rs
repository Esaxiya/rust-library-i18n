/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// যদিও এটি ব্যাপকভাবে নথিভুক্ত করা হয়েছে, এটি নীতিগতভাবে ব্যক্তিগত যা কেবল পরীক্ষার জন্য প্রকাশ্য।
// আমাদের প্রকাশ করবেন না।
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ডিজিট-প্রজন্মের অ্যালগরিদম।
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// সংক্ষিপ্ততম মোডের জন্য প্রয়োজনীয় বাফারের সর্বনিম্ন আকার।
///
/// এটি প্রাপ্ত করা কিছুটা তুচ্ছ নয়, তবে এটি সংক্ষিপ্ত ফলাফলের সাথে অ্যালগরিদম ফর্ম্যাট করা থেকে উল্লেখযোগ্য দশমিক অঙ্কের সর্বাধিক সংখ্যা।
///
/// সঠিক সূত্রটি `ceil(# bits in mantissa * log_10 2 + 1)`।
pub const MAX_SIG_DIGITS: usize = 17;

/// যখন `d` দশমিক অঙ্ক থাকে, শেষ সংখ্যাটি বাড়ান এবং বহন প্রচার করুন।
/// যখন দৈর্ঘ্য পরিবর্তিত হয় তখন পরবর্তী অঙ্কটি দেয়।
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] হ'ল সমস্ত নাইন
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 বর্ধিত ঘনিষ্টর সাথে 1000..000 এর দিকে ঘুরবে
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // একটি খালি বাফার রাউন্ড আপ (কিছুটা অদ্ভুত তবে যুক্তিসঙ্গত)
            Some(b'1')
        }
    }
}

/// ফর্ম্যাট অংশ।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// শূন্য অঙ্কের সংখ্যা দেওয়া।
    Zero(usize),
    /// 5 অঙ্ক পর্যন্ত আক্ষরিক সংখ্যা।
    Num(u16),
    /// প্রদত্ত বাইটগুলির একটি ভারব্যাটিম কপি।
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// প্রদত্ত অংশের সঠিক বাইট দৈর্ঘ্য প্রদান করে।
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// সরবরাহিত বাফারটিতে একটি অংশ লিখে।
    /// বাফার পর্যাপ্ত না হলে লিখিত বাইটের সংখ্যা বা `None` প্রদান করে।
    /// (এটি এখনও বাফারে আংশিক লিখিত বাইটগুলি ছেড়ে যেতে পারে; এটির উপর নির্ভর করবেন না))
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// এক বা একাধিক অংশ সমন্বিত ফর্ম্যাট ফলাফল।
/// এটি বাইট বাফারে লিখিত বা বরাদ্দ স্ট্রিংয়ে রূপান্তরিত হতে পারে।
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` বা `"+"`, কোনও চিহ্নকে উপস্থাপন করে একটি বাইট স্লাইস।
    pub sign: &'static str,
    /// ফর্ম্যাট অংশগুলি একটি চিহ্ন এবং alচ্ছিক শূন্য প্যাডিংয়ের পরে রেন্ডার করা।
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// সম্মিলিত বিন্যাসিত ফলাফলের সঠিক বাইট দৈর্ঘ্য প্রদান করে।
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// সরবরাহিত বাফারে সমস্ত ফর্ম্যাট অংশগুলি লিখে রাখে।
    /// বাফার পর্যাপ্ত না হলে লিখিত বাইটের সংখ্যা বা `None` প্রদান করে।
    /// (এটি এখনও বাফারে আংশিক লিখিত বাইটগুলি ছেড়ে যেতে পারে; এটির উপর নির্ভর করবেন না))
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// ফরম্যাটগুলি দশমিক সংখ্যা `0.<...buf...> * 10^exp` দেওয়া দশমিক আকারে অন্তত প্রদত্ত ভগ্নাংশের সংখ্যার সাথে।
///
/// ফলাফল সরবরাহকৃত অংশগুলির অ্যারেতে সংরক্ষণ করা হয় এবং লিখিত অংশগুলির একটি স্লাইস ফিরে আসে।
///
/// `frac_digits` `buf`-তে প্রকৃত ভগ্নাংশের সংখ্যার চেয়ে কম হতে পারে;
/// এটি উপেক্ষা করা হবে এবং পূর্ণ অঙ্ক মুদ্রণ করা হবে।এটি কেবল রেন্ডারড ডিজিটের পরে অতিরিক্ত শূন্যগুলি মুদ্রণ করতে ব্যবহৃত হয়।
/// সুতরাং 0 এর `frac_digits` এর অর্থ এটি কেবল প্রদত্ত অঙ্কগুলি এবং অন্য কিছু মুদ্রণ করবে।
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // যদি শেষ অঙ্কের অবস্থানের উপর কোনও বিধিনিষেধ থাকে তবে `buf` ভার্চুয়াল শূন্যের সাথে বাম-প্যাডযুক্ত বলে ধরে নেওয়া হয়।
    // ভার্চুয়াল শূন্যগুলির সংখ্যা, `nzeroes`, `max(0, exp + frac_digits - buf.len())` এর সমান, যাতে শেষ অঙ্কের এক্স03 এক্সের অবস্থানটি `-frac_digits` এর চেয়ে বেশি না থাকে:
    //
    //
    //                       |<-virtual->|
    //       | <<<বুফ----> | |শূন্য |এক্সপ্রেস
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ Exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` অতিরিক্ত প্রবাহ এড়াতে প্রতিটি ক্ষেত্রে পৃথকভাবে গণনা করা হয়।
    //

    if exp <= 0 {
        // দশমিক বিন্দু রেন্ডারড ডিজিটের আগে: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // সুরক্ষা: আমরা সবেমাত্র `..4` উপাদানগুলি শুরু করেছি।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // সুরক্ষা: আমরা সবেমাত্র `..3` উপাদানগুলি শুরু করেছি।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // দশমিক বিন্দু রেন্ডারড ডিজিটের অভ্যন্তরে: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // সুরক্ষা: আমরা সবেমাত্র `..4` উপাদানগুলি শুরু করেছি।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // সুরক্ষা: আমরা সবেমাত্র `..3` উপাদানগুলি শুরু করেছি।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // দশমিক পয়েন্টটি রেন্ডারড ডিজিটগুলির পরে: [1234][____0000] বা [1234][__][.][__]।
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // সুরক্ষা: আমরা সবেমাত্র `..4` উপাদানগুলি শুরু করেছি।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // সুরক্ষা: আমরা সবেমাত্র `..2` উপাদানগুলি শুরু করেছি।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// প্রদত্ত দশমিক অঙ্কগুলি `0.<...buf...> * 10^exp` কে কমপক্ষে প্রদত্ত উল্লেখযোগ্য সংখ্যার সংখ্যার সাথে তাত্পর্যপূর্ণ ফর্মটিতে ফর্ম্যাট করে।
///
/// যখন `upper` এক্স01 এক্স হয়, এক্সপোনেন্টটি এক্স02 এক্স দ্বারা উপস্থাপিত হবে;অন্যথায় এটি `e`।
/// ফলাফল সরবরাহকৃত অংশগুলির অ্যারেতে সংরক্ষণ করা হয় এবং লিখিত অংশগুলির একটি স্লাইস ফিরে আসে।
///
/// `min_digits` `buf`-তে প্রকৃত উল্লেখযোগ্য সংখ্যার চেয়ে কম হতে পারে;
/// এটি উপেক্ষা করা হবে এবং পূর্ণ অঙ্ক মুদ্রণ করা হবে।এটি কেবল রেন্ডারড ডিজিটের পরে অতিরিক্ত শূন্যগুলি মুদ্রণ করতে ব্যবহৃত হয়।
/// সুতরাং, `min_digits == 0` এর অর্থ হল যে এটি কেবল প্রদত্ত অঙ্কগুলি এবং অন্য কিছু মুদ্রণ করবে।
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 এক্স 10 ^ এক্সপ্রেস=এক্স 100 এক্স x 10 ^ (এক্সপ্রেস-1)
    let exp = exp as i32 - 1; // এক্সপ এক্স এক্স থাকা অবস্থায় আন্ডারফ্লো এড়ান
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // সুরক্ষা: আমরা সবেমাত্র `..n + 2` উপাদানগুলি শুরু করেছি।
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// স্বাক্ষরকরণ বিকল্পগুলি সাইন করুন।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// কেবলমাত্র নেতিবাচক অ-শূন্য মানের জন্য `-` মুদ্রণ করে।
    Minus, // -inf এক্স 100 এক্স 0 0 1 ইনফ ন্যান
    /// কেবলমাত্র কোনও নেতিবাচক মানগুলির জন্য `-` প্রিন্ট করে (নেতিবাচক শূন্য সহ)।
    MinusRaw, // -inf -1 -0 0 1 ইনফ ন্যান
    /// নেতিবাচক অ-শূন্য মানগুলির জন্য `-` বা অন্যথায় `+` মুদ্রণ করে।
    MinusPlus, // -inf -1 +0 +0 +1 + ইনফ ন্যান
    /// কোনও নেতিবাচক মানগুলির জন্য `-` প্রিন্ট করে (নেতিবাচক শূন্য সহ), বা অন্যথায় `+`।
    MinusPlusRaw, // -inf -1 -0 +0 +1 + ইনফ ন্যান
}

/// ফর্ম্যাটেড হওয়ার জন্য চিহ্নটির সাথে সম্পর্কিত স্ট্যাটিক বাইট স্ট্রিংটি প্রদান করে।
/// এটি `""`, `"+"` বা `"-"` হতে পারে।
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// প্রদত্ত ভাসমান পয়েন্ট সংখ্যাটি দশমিক আকারে কমপক্ষে প্রদত্ত ভগ্নাংশের সংখ্যার সাথে ফর্ম্যাট করে।
/// স্ক্র্যাচ হিসাবে দেওয়া বাইট বাফারটি ব্যবহার করার সময় ফলাফল সরবরাহকৃত অংশগুলিতে অ্যারে সংরক্ষণ করা হয়।
/// `upper` বর্তমানে অব্যবহৃত তবে জরিমানা-সীমাবদ্ধ মানগুলি, অর্থাৎ, `inf` এবং `nan` এর ক্ষেত্রে পরিবর্তন করার জেডফিউচার0 জেড সিদ্ধান্তের জন্য ছেড়ে গেছে।
///
/// রেন্ডার করা প্রথম অংশটি সর্বদা একটি `Part::Sign` (কোনও চিহ্ন প্রদর্শিত না হলে খালি স্ট্রিং হতে পারে)।
///
/// `format_shortest` অন্তর্নিহিত অঙ্ক-প্রজন্মের ফাংশন হওয়া উচিত।
/// এটি শুরু করা বাফারের অংশটি ফিরিয়ে আনতে হবে।
/// আপনি সম্ভবত এটির জন্য `strategy::grisu::format_shortest` চাইবেন।
///
/// `frac_digits` `v`-তে প্রকৃত ভগ্নাংশের সংখ্যার চেয়ে কম হতে পারে;
/// এটি উপেক্ষা করা হবে এবং পূর্ণ অঙ্ক মুদ্রণ করা হবে।এটি কেবল রেন্ডারড ডিজিটের পরে অতিরিক্ত শূন্যগুলি মুদ্রণ করতে ব্যবহৃত হয়।
/// সুতরাং 0 এর `frac_digits` এর অর্থ এটি কেবল প্রদত্ত অঙ্কগুলি এবং অন্য কিছু মুদ্রণ করবে।
///
/// বাইট বাফারটি কমপক্ষে `MAX_SIG_DIGITS` বাইট দীর্ঘ হওয়া উচিত।
/// `frac_digits = 10` এর সাথে `[+][0.][0000][2][0000]` এর মতো খারাপ পরিস্থিতির কারণে কমপক্ষে 4 টি অংশ পাওয়া উচিত।
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..2` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// প্রদত্ত ভাসমান পয়েন্ট সংখ্যাটি দশমিক ফর্ম বা সূচকীয় ফর্মটিতে ফর্ম্যাট করে ফলাফল ফলাফলের উপর নির্ভর করে।
/// স্ক্র্যাচ হিসাবে দেওয়া বাইট বাফারটি ব্যবহার করার সময় ফলাফল সরবরাহকৃত অংশগুলিতে অ্যারে সংরক্ষণ করা হয়।
/// `upper` সীমাবদ্ধ না হওয়া মানগুলির (`inf` এবং `nan`) ক্ষেত্রে বা এক্সপোনেন্ট উপসর্গের (`e` বা `E`) কেস নির্ধারণ করতে ব্যবহৃত হয়।
/// রেন্ডার করা প্রথম অংশটি সর্বদা একটি `Part::Sign` (কোনও চিহ্ন প্রদর্শিত না হলে খালি স্ট্রিং হতে পারে)।
///
/// `format_shortest` অন্তর্নিহিত অঙ্ক-প্রজন্মের ফাংশন হওয়া উচিত।
/// এটি শুরু করা বাফারের অংশটি ফিরিয়ে আনতে হবে।
/// আপনি সম্ভবত এটির জন্য `strategy::grisu::format_shortest` চাইবেন।
///
/// `dec_bounds` একটি টিউপল এক্স0 2 এক্স এমন যে কেবলমাত্র `10^lo <= V < 10^hi` হলে সংখ্যাটি দশমিক হিসাবে ফর্ম্যাট হয়।
/// মনে রাখবেন যে এটি আসল `v` এর পরিবর্তে *আপাত*`V`!সুতরাং সূচকীয় ফর্মের কোনও মুদ্রিত এক্সপোঞ্জেন্ট কোনও বিভ্রান্তি এড়িয়ে এই সীমাতে থাকতে পারে না।
///
///
/// বাইট বাফারটি কমপক্ষে `MAX_SIG_DIGITS` বাইট দীর্ঘ হওয়া উচিত।
/// কমপক্ষে 6 টি অংশ পাওয়া উচিত, `[+][1][.][2345][e][-][6]` এর মতো সবচেয়ে খারাপ পরিস্থিতির কারণে।
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// প্রদত্ত ডিকোডড এক্সপোঞ্জ্যান্ট থেকে গণনা করা সর্বাধিক বাফার আকারের পরিবর্তে অপরিশোধিত অনুমান (উপরের গণ্ডি) প্রদান করে।
///
/// সঠিক সীমাটি হ'ল:
///
/// - যখন `exp < 0`, সর্বাধিক দৈর্ঘ্য `ceil(log_10 (5^-exp * (2^64 - 1)))` হয়।
/// - যখন `exp >= 0`, সর্বাধিক দৈর্ঘ্য `ceil(log_10 (2^exp * (2^64 - 1)))` হয়।
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` এর চেয়ে কম, যা `20 + (1 + exp* log_10 x)` এর চেয়ে কম হয়।
/// আমরা `log_10 2 < 5/16` এবং `log_10 5 < 12/16` তথ্যগুলি ব্যবহার করি যা আমাদের উদ্দেশ্যে যথেষ্ট।
///
/// আমাদের কেন এটা দরকার?শেষ অঙ্কের সীমাবদ্ধতা না থাকলে `format_exact` ফাংশন পুরো বাফারটি পূরণ করবে, তবে অনুরোধ করা অঙ্কগুলির সংখ্যা হাস্যকরভাবে বড় বলে (সম্ভবত, 30,000 সংখ্যা)।
///
/// বাফারের সিংহভাগই জিরো দিয়ে পূর্ণ হবে, সুতরাং আমরা সমস্ত বাফার আগে বরাদ্দ করতে চাই না।
/// ফলস্বরূপ, প্রদত্ত যে কোনও যুক্তির জন্য,
/// এক্স 600 এক্সের জন্য 826 বাইটের বাফার পর্যাপ্ত হওয়া উচিত।এটি সবচেয়ে খারাপ ক্ষেত্রে প্রকৃত সংখ্যার সাথে তুলনা করুন: 770 বাইট (যখন এক্স01 এক্স)।
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// উল্লেখযোগ্য সংখ্যার ঠিক প্রদত্ত সংখ্যার সাথে সূচকগুলি সূচকীয় ফর্মটিতে ভাসমান পয়েন্ট নম্বর প্রদান করে mats
/// স্ক্র্যাচ হিসাবে দেওয়া বাইট বাফারটি ব্যবহার করার সময় ফলাফল সরবরাহকৃত অংশগুলিতে অ্যারে সংরক্ষণ করা হয়।
/// `upper` এক্সপোনেন্ট উপসর্গ (`e` বা `E`) কেস নির্ধারণ করতে ব্যবহৃত হয়।
/// রেন্ডার করা প্রথম অংশটি সর্বদা একটি `Part::Sign` (কোনও চিহ্ন প্রদর্শিত না হলে খালি স্ট্রিং হতে পারে)।
///
/// `format_exact` অন্তর্নিহিত অঙ্ক-প্রজন্মের ফাংশন হওয়া উচিত।
/// এটি শুরু করা বাফারের অংশটি ফিরিয়ে আনতে হবে।
/// আপনি সম্ভবত এটির জন্য `strategy::grisu::format_exact` চাইবেন।
///
/// বাইট বাফারটি কমপক্ষে `ndigits` বাইট দীর্ঘ হওয়া উচিত যদি না `ndigits` এত বড় হয় যে কেবলমাত্র নির্দিষ্ট সংখ্যার অঙ্কটি লিখিত থাকে।
/// (এক্স0১ এক্স এর টিপিং পয়েন্টটি প্রায় 800, সুতরাং 1000 বাইটের পরিমাণ যথেষ্ট হওয়া উচিত)) এক্স00 এক্স এর মতো খারাপ অবস্থার কারণে কমপক্ষে 6 টি অংশ পাওয়া উচিত।
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..3` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// ভাসমান সংখ্যার ঠিক প্রদত্ত সংখ্যার সাথে দশমিক আকারে ভাসমান পয়েন্ট সংখ্যা প্রদত্ত ফর্ম্যাটগুলি।
/// স্ক্র্যাচ হিসাবে দেওয়া বাইট বাফারটি ব্যবহার করার সময় ফলাফল সরবরাহকৃত অংশগুলিতে অ্যারে সংরক্ষণ করা হয়।
/// `upper` বর্তমানে অব্যবহৃত তবে জরিমানা-সীমাবদ্ধ মানগুলি, অর্থাৎ, `inf` এবং `nan` এর ক্ষেত্রে পরিবর্তন করার জেডফিউচার0 জেড সিদ্ধান্তের জন্য ছেড়ে গেছে।
/// রেন্ডার করা প্রথম অংশটি সর্বদা একটি `Part::Sign` (কোনও চিহ্ন প্রদর্শিত না হলে খালি স্ট্রিং হতে পারে)।
///
/// `format_exact` অন্তর্নিহিত অঙ্ক-প্রজন্মের ফাংশন হওয়া উচিত।
/// এটি শুরু করা বাফারের অংশটি ফিরিয়ে আনতে হবে।
/// আপনি সম্ভবত এটির জন্য `strategy::grisu::format_exact` চাইবেন।
///
/// এক্স 100 এক্স এত বড় না হলে আউটপুটটির জন্য বাইট বাফারটি পর্যাপ্ত পরিমাণে হওয়া উচিত যা কেবলমাত্র নির্দিষ্ট সংখ্যার অঙ্কটিই লেখা থাকে।
/// (`f64` এর টিপিং পয়েন্টটি প্রায় 800 টি এবং 1000 বাইটের পরিমাণ যথেষ্ট হওয়া উচিত)) `frac_digits = 10` এর সাথে `[+][0.][0000][2][0000]` এর মতো খারাপ পরিস্থিতির কারণে কমপক্ষে 4 টি অংশ পাওয়া উচিত।
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..2` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // এটি সম্ভবত সম্ভব যে `frac_digits` হাস্যকর আকারে বড়।
            // `format_exact` এই ক্ষেত্রে ডিজিটার রেন্ডারিংয়ের প্রারম্ভিকতা শেষ হবে, কারণ আমরা `maxlen` দ্বারা কঠোরভাবে সীমাবদ্ধ।
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // বিধিনিষেধটি পূরণ করা যায়নি, সুতরাং এটি `exp` এর মত শূন্যের মতো রেন্ডার করা উচিত।
                // এটি কেবলমাত্র চূড়ান্ত রাউন্ড-আপের পরে এই নিষেধাজ্ঞা মেটেছে এমন ক্ষেত্রে অন্তর্ভুক্ত নয়;এটি `exp = limit + 1` এর নিয়মিত কেস।
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // সুরক্ষা: আমরা সবেমাত্র `..2` উপাদানগুলি শুরু করেছি।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // সুরক্ষা: আমরা সবেমাত্র `..1` উপাদানগুলি শুরু করেছি।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}