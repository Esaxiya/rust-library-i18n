//! এক্স 100 এক্স এর সংজ্ঞা

use crate::fmt;
use crate::ops::{Add, AddAssign, BitAnd, BitAndAssign, BitOr, BitOrAssign};
use crate::ops::{BitXor, BitXorAssign, Div, DivAssign};
use crate::ops::{Mul, MulAssign, Neg, Not, Rem, RemAssign};
use crate::ops::{Shl, ShlAssign, Shr, ShrAssign, Sub, SubAssign};

/// `T` এ ইচ্ছাকৃতভাবে মোড়িত পাটিগণিত সরবরাহ করে।
///
/// `u32` মানগুলিতে `+` এর মতো ক্রিয়াকলাপগুলি কখনই ওভারফ্লো হয় না, এবং কিছু ডিবাগ কনফিগারেশনে ওভারফ্লো সনাক্ত হয় এবং এর ফলাফল panic হয় in
/// বেশিরভাগ গাণিতিক এই বিভাগে আসে, কিছু কোড স্পষ্টভাবে প্রত্যাশা করে এবং মডুলার গাণিতিকের উপর নির্ভর করে (যেমন, হ্যাশিং)।
///
/// মোড়ক গাণিতিকটি হয় `wrapping_add` এর মতো পদ্ধতির মাধ্যমে বা `Wrapping<T>` টাইপের মাধ্যমে অর্জন করা যেতে পারে, যা বলে যে অন্তর্নিহিত মানের সমস্ত মানক গাণিতিক ক্রিয়াকলাপ মোড়ানো শব্দার্থবিজ্ঞানের উদ্দেশ্যে করা হয়।
///
///
/// অন্তর্নিহিত মানটি `Wrapping` টিপলের `.0` সূচকের মাধ্যমে পুনরুদ্ধার করা যেতে পারে।
///
/// # Examples
///
/// ```
/// use std::num::Wrapping;
///
/// let zero = Wrapping(0u32);
/// let one = Wrapping(1u32);
///
/// assert_eq!(u32::MAX, (zero - one).0);
/// ```
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(PartialEq, Eq, PartialOrd, Ord, Clone, Copy, Default, Hash)]
#[repr(transparent)]
pub struct Wrapping<T>(#[stable(feature = "rust1", since = "1.0.0")] pub T);

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_display", since = "1.10.0")]
impl<T: fmt::Display> fmt::Display for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::Binary> fmt::Binary for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::Octal> fmt::Octal for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::LowerHex> fmt::LowerHex for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::UpperHex> fmt::UpperHex for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[allow(unused_macros)]
macro_rules! sh_impl_signed {
    ($t:ident, $f:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shl<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shl(self, other: $f) -> Wrapping<$t> {
                if other < 0 {
                    Wrapping(self.0.wrapping_shr((-other & self::shift_max::$t as $f) as u32))
                } else {
                    Wrapping(self.0.wrapping_shl((other & self::shift_max::$t as $f) as u32))
                }
            }
        }
        forward_ref_binop! { impl Shl, shl for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShlAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shl_assign(&mut self, other: $f) {
                *self = *self << other;
            }
        }
        forward_ref_op_assign! { impl ShlAssign, shl_assign for Wrapping<$t>, $f }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shr<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shr(self, other: $f) -> Wrapping<$t> {
                if other < 0 {
                    Wrapping(self.0.wrapping_shl((-other & self::shift_max::$t as $f) as u32))
                } else {
                    Wrapping(self.0.wrapping_shr((other & self::shift_max::$t as $f) as u32))
                }
            }
        }
        forward_ref_binop! { impl Shr, shr for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShrAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Wrapping<$t>, $f }
    };
}

macro_rules! sh_impl_unsigned {
    ($t:ident, $f:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shl<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shl(self, other: $f) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_shl((other & self::shift_max::$t as $f) as u32))
            }
        }
        forward_ref_binop! { impl Shl, shl for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShlAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shl_assign(&mut self, other: $f) {
                *self = *self << other;
            }
        }
        forward_ref_op_assign! { impl ShlAssign, shl_assign for Wrapping<$t>, $f }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shr<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shr(self, other: $f) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_shr((other & self::shift_max::$t as $f) as u32))
            }
        }
        forward_ref_binop! { impl Shr, shr for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShrAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Wrapping<$t>, $f }
    };
}

// FIXME (#23545): বাকি ইমপ্লিটগুলি অসম্পূর্ণ করুন
macro_rules! sh_impl_all {
    ($($t:ident)*) => ($(
        // sh_impl_ স্বাক্ষরিত!{ $t, u8 } sh_impl_ স্বাক্ষরিত!{ $t, u16 } sh_impl_ স্বাক্ষরিত!{ $t, u32 } sh_impl_ স্বাক্ষরিত!{ $t, u64 } sh_impl_ স্বাক্ষরিত! { $t, u128 }
        //
        //
        //
        //
        sh_impl_unsigned! { $t, usize }

        // sh_impl_ সাইনড!{ $t, i8 } sh_impl_ স্বাক্ষরিত!{ $t, i16 } sh_impl_ স্বাক্ষরিত!{ $t, i32 } sh_impl_ স্বাক্ষরিত!{ $t, i64 } sh_impl_ স্বাক্ষরিত!{ $t, i128 } sh_impl_ স্বাক্ষরিত! { $t, isize }
        //
        //
        //
        //
        //
    )*)
}

sh_impl_all! { u8 u16 u32 u64 u128 usize i8 i16 i32 i64 i128 isize }

// FIXME(30524): ইমপ্লান্ট অপ<T>মোড়ানো জন্য<T>, ইমপ্লিট OpAssign<T>মোড়ানো জন্য<T>
macro_rules! wrapping_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn add(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_add(other.0))
            }
        }
        forward_ref_binop! { impl Add, add for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for Wrapping<$t> {
            #[inline]
            fn add_assign(&mut self, other: Wrapping<$t>) {
                *self = *self + other;
            }
        }
        forward_ref_op_assign! { impl AddAssign, add_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn sub(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_sub(other.0))
            }
        }
        forward_ref_binop! { impl Sub, sub for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for Wrapping<$t> {
            #[inline]
            fn sub_assign(&mut self, other: Wrapping<$t>) {
                *self = *self - other;
            }
        }
        forward_ref_op_assign! { impl SubAssign, sub_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn mul(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_mul(other.0))
            }
        }
        forward_ref_binop! { impl Mul, mul for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for Wrapping<$t> {
            #[inline]
            fn mul_assign(&mut self, other: Wrapping<$t>) {
                *self = *self * other;
            }
        }
        forward_ref_op_assign! { impl MulAssign, mul_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_div", since = "1.3.0")]
        impl Div for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn div(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_div(other.0))
            }
        }
        forward_ref_binop! { impl Div, div for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for Wrapping<$t> {
            #[inline]
            fn div_assign(&mut self, other: Wrapping<$t>) {
                *self = *self / other;
            }
        }
        forward_ref_op_assign! { impl DivAssign, div_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_impls", since = "1.7.0")]
        impl Rem for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn rem(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_rem(other.0))
            }
        }
        forward_ref_binop! { impl Rem, rem for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for Wrapping<$t> {
            #[inline]
            fn rem_assign(&mut self, other: Wrapping<$t>) {
                *self = *self % other;
            }
        }
        forward_ref_op_assign! { impl RemAssign, rem_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Not for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn not(self) -> Wrapping<$t> {
                Wrapping(!self.0)
            }
        }
        forward_ref_unop! { impl Not, not for Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitXor for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitxor(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 ^ other.0)
            }
        }
        forward_ref_binop! { impl BitXor, bitxor for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitXorAssign for Wrapping<$t> {
            #[inline]
            fn bitxor_assign(&mut self, other: Wrapping<$t>) {
                *self = *self ^ other;
            }
        }
        forward_ref_op_assign! { impl BitXorAssign, bitxor_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitOr for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitor(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 | other.0)
            }
        }
        forward_ref_binop! { impl BitOr, bitor for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitOrAssign for Wrapping<$t> {
            #[inline]
            fn bitor_assign(&mut self, other: Wrapping<$t>) {
                *self = *self | other;
            }
        }
        forward_ref_op_assign! { impl BitOrAssign, bitor_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitAnd for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitand(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 & other.0)
            }
        }
        forward_ref_binop! { impl BitAnd, bitand for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitAndAssign for Wrapping<$t> {
            #[inline]
            fn bitand_assign(&mut self, other: Wrapping<$t>) {
                *self = *self & other;
            }
        }
        forward_ref_op_assign! { impl BitAndAssign, bitand_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_neg", since = "1.10.0")]
        impl Neg for Wrapping<$t> {
            type Output = Self;
            #[inline]
            fn neg(self) -> Self {
                Wrapping(0) - self
            }
        }
        forward_ref_unop! { impl Neg, neg for Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

    )*)
}

wrapping_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// এই পূর্ণসংখ্যার ধরণের দ্বারা প্রতিনিধিত্ব করা যায় এমন সবচেয়ে ছোট মানটি ফেরৎ দেয়।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert_eq!(<Wrapping<", stringify!($t), ">>::MIN, Wrapping(", stringify!($t), "::MIN));")]
            /// ```
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const MIN: Self = Self(<$t>::MIN);

            /// এই পূর্ণসংখ্যার ধরণের দ্বারা প্রতিনিধিত্ব করা যায় এমন বৃহত্তম মানটি ফেরৎ দেয়।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert_eq!(<Wrapping<", stringify!($t), ">>::MAX, Wrapping(", stringify!($t), "::MAX));")]
            /// ```
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const MAX: Self = Self(<$t>::MAX);

            /// `self` এর বাইনারি উপস্থাপনায় যেকোনটির সংখ্যা প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0b01001100", stringify!($t), ");")]
            /// assert_eq!(n.count_ones(), 3);
            /// ```
            #[inline]
            #[doc(alias = "popcount")]
            #[doc(alias = "popcnt")]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn count_ones(self) -> u32 {
                self.0.count_ones()
            }

            /// `self` এর বাইনারি উপস্থাপনায় শূন্যের সংখ্যা প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert_eq!(Wrapping(!0", stringify!($t), ").count_zeros(), 0);")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn count_zeros(self) -> u32 {
                self.0.count_zeros()
            }

            /// `self` এর বাইনারি উপস্থাপনায় পিছনে জিরোগুলির সংখ্যা প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0b0101000", stringify!($t), ");")]
            /// assert_eq!(n.trailing_zeros(), 3);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn trailing_zeros(self) -> u32 {
                self.0.trailing_zeros()
            }

            /// বিটগুলি নির্দিষ্ট পরিমাণে, `n` দ্বারা বামে স্থানান্তরিত করে, কাটা বিটগুলি ফলস্বরূপ পূর্ণসংখ্যার শেষের দিকে মুড়ে।
            ///
            ///
            /// দয়া করে মনে রাখবেন যে এটি `<<` শিফটিং অপারেটরের মতো একই অপারেশন নয়!
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i64> = Wrapping(0x0123456789ABCDEF);
            /// let m: Wrapping<i64> = Wrapping(-0x76543210FEDCBA99);
            ///
            /// assert_eq!(n.rotate_left(32), m);
            /// ```
            ///
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn rotate_left(self, n: u32) -> Self {
                Wrapping(self.0.rotate_left(n))
            }

            /// বিটগুলি ডান দিকে নির্দিষ্ট পরিমাণে, `n` দ্বারা পরিবর্তিত করে ফলাফলকে পূর্ণসংখ্যার শুরুর দিকে কাটা বিটগুলি আবৃত করে।
            ///
            ///
            /// দয়া করে মনে রাখবেন যে এটি `>>` শিফটিং অপারেটরের মতো একই অপারেশন নয়!
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i64> = Wrapping(0x0123456789ABCDEF);
            /// let m: Wrapping<i64> = Wrapping(-0xFEDCBA987654322);
            ///
            /// assert_eq!(n.rotate_right(4), m);
            /// ```
            ///
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn rotate_right(self, n: u32) -> Self {
                Wrapping(self.0.rotate_right(n))
            }

            /// পূর্ণসংখ্যার বাইট ক্রমটিকে বিপরীত করে।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i16> = Wrapping(0b0000000_01010101);
            /// assert_eq!(n, Wrapping(85));
            ///
            /// let m = n.swap_bytes();
            ///
            /// assert_eq!(m, Wrapping(0b01010101_00000000));
            /// assert_eq!(m, Wrapping(21760));
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn swap_bytes(self) -> Self {
                Wrapping(self.0.swap_bytes())
            }

            /// পূর্ণসংখ্যার বিট প্যাটার্নকে বিপরীত করে।
            ///
            /// # Examples
            ///
            /// দয়া করে নোট করুন যে এই উদাহরণটি পূর্ণসংখ্যার প্রকারের মধ্যে ভাগ করা আছে।
            /// যা এখানে `i16` কেন ব্যবহৃত হয় তা ব্যাখ্যা করে।
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// use std::num::Wrapping;
            ///
            /// let n = Wrapping(0b0000000_01010101i16);
            /// assert_eq!(n, Wrapping(85));
            ///
            /// let m = n.reverse_bits();
            ///
            /// assert_eq!(m.0 as u16, 0b10101010_00000000);
            /// assert_eq!(m, Wrapping(-22016));
            /// ```
            #[stable(feature = "reverse_bits", since = "1.37.0")]
            #[rustc_const_stable(feature = "const_reverse_bits", since = "1.37.0")]
            #[inline]
            #[must_use]
            pub const fn reverse_bits(self) -> Self {
                Wrapping(self.0.reverse_bits())
            }

            /// বড় ইন্ডিয়ান থেকে একটি পূর্ণসংখ্যাকে লক্ষ্যটির শেষের দিকে রূপান্তর করে।
            ///
            ///
            /// বড় এন্ডিয়ান এ এটি কোনও অপশন নেই।
            /// সামান্য এডিয়ানে বাইটগুলি অদলবদল করা হয়।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// যদি সিএফজি! (টার্গেট_েন্ডিয়ান=এক্স 100 এক্স){
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_be(n), n)")]
            /// } অন্য {
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_be(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn from_be(x: Self) -> Self {
                Wrapping(<$t>::from_be(x.0))
            }

            /// সামান্য এডিয়ান থেকে কোনও সংখ্যাকে লক্ষ্যের শেষের দিকে রূপান্তর করে।
            ///
            ///
            /// সামান্য এডিয়ান এ এটি একটি অপ্স নেই।
            /// বড় এডিয়ানগুলিতে বাইটগুলি অদলবদল করা হয়।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// যদি সিএফজি! (টার্গেট_েন্ডিয়ান=এক্স 100 এক্স){
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_le(n), n)")]
            /// } অন্য {
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_le(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn from_le(x: Self) -> Self {
                Wrapping(<$t>::from_le(x.0))
            }

            /// এক্স এর 100 টি লক্ষ্যটির শেষ থেকে বড় এডিয়ানে রূপান্তর করে।
            ///
            ///
            /// বড় এন্ডিয়ান এ এটি কোনও অপশন নেই।
            /// সামান্য এডিয়ানে বাইটগুলি অদলবদল করা হয়।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// যদি সিএফজি! (টার্গেট_েন্ডিয়ান=এক্স 100 এক্স){
            ///     assert_eq!(n.to_be(), n)
            /// অন্য { assert_eq!(n.to_be(), n.swap_bytes()) }
            ///
            /// ```
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn to_be(self) -> Self {
                Wrapping(self.0.to_be())
            }

            /// এক্স এর 100 টি লক্ষ্যমাত্রার শেষ থেকে সামান্য এন্ডিয়ান রূপান্তর করে।
            ///
            ///
            /// সামান্য এডিয়ান এ এটি একটি অপ্স নেই।
            /// বড় এডিয়ানগুলিতে বাইটগুলি অদলবদল করা হয়।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// যদি সিএফজি! (টার্গেট_েন্ডিয়ান=এক্স 100 এক্স){
            ///     assert_eq!(n.to_le(), n)
            /// অন্য { assert_eq!(n.to_le(), n.swap_bytes()) }
            ///
            /// ```
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn to_le(self) -> Self {
                Wrapping(self.0.to_le())
            }

            /// স্কোয়ারিং দ্বারা এক্সফোনেনটিশন ব্যবহার করে `exp` এর শক্তিতে নিজেকে উত্থাপন করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert_eq!(Wrapping(3", stringify!($t), ").pow(4), Wrapping(81));")]
            /// ```
            ///
            /// Results that are too large are wrapped:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            ///
            /// assert_eq!(Wrapping(3i8).pow(5), Wrapping(-13));
            /// assert_eq!(Wrapping(3i8).pow(6), Wrapping(-39));
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn pow(self, exp: u32) -> Self {
                Wrapping(self.0.wrapping_pow(exp))
            }
        }
    )*)
}

wrapping_int_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl_signed {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// `self` এর বাইনারি উপস্থাপনায় শীর্ষস্থানীয় শূন্যগুলির সংখ্যা প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(", stringify!($t), "::MAX) >> 2;")]
            /// assert_eq!(n.leading_zeros(), 3);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// প্রকারের সীমানায় মোড়ানো, `self` এর পরম মানের গণনা করে।
            ///
            /// কেবলমাত্র যখন এই জাতীয় মোড়ক ঘটতে পারে তখনই যখন কেউ ধরণের জন্য নেতিবাচক সর্বনিম্ন মানের জন্য নিখুঁত মান গ্রহণ করে তবে এটি ধনাত্মক মান যা টাইপটিতে প্রতিনিধিত্ব করতে খুব বড়।
            /// যেমন একটি ক্ষেত্রে, এই ফাংশন নিজেই `MIN` প্রদান করে।
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            ///
            ///
            ///
            #[doc = concat!("assert_eq!(Wrapping(100", stringify!($t), ").abs(), Wrapping(100));")]
            #[doc = concat!("assert_eq!(Wrapping(-100", stringify!($t), ").abs(), Wrapping(100));")]
            #[doc = concat!("assert_eq!(Wrapping(", stringify!($t), "::MIN).abs(), Wrapping(", stringify!($t), "::MIN));")]
            /// assert_eq!(Wrapping(-128i8).abs().0 as u8, 128u8);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn abs(self) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_abs())
            }

            /// `self` এর প্রতিনিধিত্বকারী সাইনটি প্রদান করে।
            ///
            ///
            ///  - `0` যদি সংখ্যাটি শূন্য হয়
            ///  - `1` যদি সংখ্যাটি ইতিবাচক হয়
            ///  - `-1` যদি সংখ্যাটি নেতিবাচক হয়
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert_eq!(Wrapping(10", stringify!($t), ").signum(), Wrapping(1));")]
            #[doc = concat!("assert_eq!(Wrapping(0", stringify!($t), ").signum(), Wrapping(0));")]
            #[doc = concat!("assert_eq!(Wrapping(-10", stringify!($t), ").signum(), Wrapping(-1));")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn signum(self) -> Wrapping<$t> {
                Wrapping(self.0.signum())
            }

            /// `self` ইতিবাচক হলে `true` এবং সংখ্যাটি শূন্য বা negativeণাত্মক হলে `false` প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            ///
            #[doc = concat!("assert!(Wrapping(10", stringify!($t), ").is_positive());")]
            #[doc = concat!("assert!(!Wrapping(-10", stringify!($t), ").is_positive());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn is_positive(self) -> bool {
                self.0.is_positive()
            }

            /// `self` নেতিবাচক হলে `true` এবং সংখ্যাটি শূন্য বা ধনাত্মক হলে `false` প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            ///
            #[doc = concat!("assert!(Wrapping(-10", stringify!($t), ").is_negative());")]
            #[doc = concat!("assert!(!Wrapping(10", stringify!($t), ").is_negative());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn is_negative(self) -> bool {
                self.0.is_negative()
            }
        }
    )*)
}

wrapping_int_impl_signed! { isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl_unsigned {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// `self` এর বাইনারি উপস্থাপনায় শীর্ষস্থানীয় শূন্যগুলির সংখ্যা প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("let n = Wrapping(", stringify!($t), "::MAX) >> 2;")]
            /// assert_eq!(n.leading_zeros(), 2);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// যদি কিছু `k` এর জন্য `self == 2^k` হয় এবং যদি `true` প্রদান করে।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            #[doc = concat!("assert!(Wrapping(16", stringify!($t), ").is_power_of_two());")]
            #[doc = concat!("assert!(!Wrapping(10", stringify!($t), ").is_power_of_two());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn is_power_of_two(self) -> bool {
                self.0.is_power_of_two()
            }

            /// `self` এর চেয়ে বড় বা তার সমান দুটি এর ক্ষুদ্রতম পাওয়ারটি দেয়।
            ///
            /// যখন রিটার্নের মান ওভারফ্লো হয় (যেমন, `uN` টাইপের জন্য `self > (1 << (N-1))`), এক্সফ্ল্যাক্সে ওভারফ্লো হয়।
            ///
            ///
            /// # Examples
            ///
            /// বেসিক ব্যবহার:
            ///
            /// ```
            /// #![feature(wrapping_next_power_of_two)]
            /// এক্স 100 এক্স ব্যবহার করুন;
            ///
            #[doc = concat!("assert_eq!(Wrapping(2", stringify!($t), ").next_power_of_two(), Wrapping(2));")]
            #[doc = concat!("assert_eq!(Wrapping(3", stringify!($t), ").next_power_of_two(), Wrapping(4));")]
            #[doc = concat!("assert_eq!(Wrapping(200_u8).next_power_of_two(), Wrapping(0));")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                       reason = "needs decision on wrapping behaviour")]
            pub fn next_power_of_two(self) -> Self {
                Wrapping(self.0.wrapping_next_power_of_two())
            }
        }
    )*)
}

wrapping_int_impl_unsigned! { usize u8 u16 u32 u64 u128 }

mod shift_max {
    #![allow(non_upper_case_globals)]

    #[cfg(target_pointer_width = "16")]
    mod platform {
        pub const usize: u32 = super::u16;
        pub const isize: u32 = super::i16;
    }

    #[cfg(target_pointer_width = "32")]
    mod platform {
        pub const usize: u32 = super::u32;
        pub const isize: u32 = super::i32;
    }

    #[cfg(target_pointer_width = "64")]
    mod platform {
        pub const usize: u32 = super::u64;
        pub const isize: u32 = super::i64;
    }

    pub const i8: u32 = (1 << 3) - 1;
    pub const i16: u32 = (1 << 4) - 1;
    pub const i32: u32 = (1 << 5) - 1;
    pub const i64: u32 = (1 << 6) - 1;
    pub const i128: u32 = (1 << 7) - 1;
    pub use self::platform::isize;

    pub const u8: u32 = i8;
    pub const u16: u32 = i16;
    pub const u32: u32 = i32;
    pub const u64: u32 = i64;
    pub const u128: u32 = i128;
    pub use self::platform::usize;
}