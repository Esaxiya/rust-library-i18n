//! ইতিবাচক আইইইই 754 ফ্লোটে বিট ফিডলিং।নেতিবাচক সংখ্যাগুলি হ্যান্ডেল করার দরকার নেই।
//! সাধারণ ভাসমান পয়েন্ট সংখ্যাগুলির (ফ্র্যাক, এক্সপ্রেস) হিসাবে প্রচলিত উপস্থাপনা থাকে যেমন মান 2 <sup>এক্সপ</sup> * (1 + এক্স00 এক্স যেখানে এন বিটের সংখ্যা হয়)।
//!
//! উচ্চারণগুলি কিছুটা পৃথক এবং অদ্ভুত, তবে একই নীতিটি প্রযোজ্য।
//!
//! এখানে, তবে আমরা এগুলি (সিগ, কে) এফ পজিটিভ সহ উপস্থাপন করি যেমন মান চ *
//! 2 <sup>ই</sup> ।এক্স 100 এক্সকে স্পষ্ট করে তোলার পাশাপাশি এটি তথাকথিত মান্টিসা শিফট দ্বারা এক্সপোনেন্টকে পরিবর্তন করে।
//!
//! অন্যভাবে বলুন, সাধারণত ভাসাগুলি (1) হিসাবে লেখা হয় তবে এখানে সেগুলি (2) হিসাবে লেখা হয়:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! আমরা (1) কে **ভগ্নাংশের উপস্থাপনা** এবং (1) কে **অবিচ্ছেদ্য উপস্থাপনা** বলি।
//!
//! এই মডিউলে অনেকগুলি ফাংশন কেবলমাত্র সাধারণ সংখ্যাগুলি পরিচালনা করে।ডিক 2ফ্ল্ট রুটিনগুলি রক্ষণশীলভাবে খুব অল্প এবং খুব বড় সংখ্যার জন্য সর্বজনীন-সঠিক ধীর পাথ (অ্যালগোরিদম এম) গ্রহণ করে।
//! এই অ্যালগরিদমের জন্য কেবলমাত্র next_float() দরকার যা সাবমনোরালস এবং জিরোগুলি পরিচালনা করে।
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` এবং `f64` এর মূলত সমস্ত রূপান্তর কোডটি অনুলিপি করা এড়াতে একজন সহায়ক trait।
///
/// কেন এটি প্রয়োজনীয় তা জন্য পিতামাতা মডিউলটির ডক মন্তব্য দেখুন।
///
/// **কখনও কখনও** অন্য ধরণের জন্য প্রয়োগ করা উচিত নয় বা ডিকফ্ল্ট মডিউলের বাইরে ব্যবহার করা উচিত।
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` এবং `from_bits` দ্বারা ব্যবহৃত প্রকার।
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// একটি পূর্ণসংখ্যার কাঁচা ট্রান্সমুটেশন সম্পাদন করে।
    fn to_bits(self) -> Self::Bits;

    /// একটি পূর্ণসংখ্যা থেকে একটি কাঁচা ট্রান্সমিটেশন সম্পাদন করে।
    fn from_bits(v: Self::Bits) -> Self;

    /// এই সংখ্যাটি যে বিভাগে আসে সেই বিভাগটি দেয়।
    fn classify(self) -> FpCategory;

    /// মান্টিসা, সূচক এবং পূর্ণসংখ্যা হিসাবে সাইন দেয়।
    fn integer_decode(self) -> (u64, i16, i8);

    /// ভাসা ডিকোড।
    fn unpack(self) -> Unpacked;

    /// একটি ছোট পূর্ণসংখ্যা থেকে অক্ষর যা সঠিকভাবে উপস্থাপন করা যায়।
    /// Panic যদি পূর্ণসংখ্যাকে প্রতিনিধিত্ব করা না যায় তবে এই মডিউলের অন্যান্য কোডটি কখনই এটি না হওয়ার নিশ্চিত করে।
    fn from_int(x: u64) -> Self;

    /// প্রাক-গণিত টেবিল থেকে 10 <sup>ই</sup> মান পাবে।
    /// `e >= CEIL_LOG5_OF_MAX_SIG` এর জন্য Panics।
    fn short_fast_pow10(e: usize) -> Self;

    /// নাম কি বলে।
    /// আন্তঃজাগল জাগ্রাল করা এবং LLVM ধ্রুবক এটিকে ভাঁজ করে রাখার চেয়ে হার্ড কোডের থেকে সহজ।
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ওভারফ্লো বা শূন্য বা উত্পাদন করতে পারে না এমন ইনপুটগুলির দশমিক অঙ্কগুলিতে আবদ্ধ একটি রক্ষণশীল bound
    /// subnormals।সম্ভবত সর্বাধিক স্বাভাবিক মানের দশমিক সূচক, সুতরাং নাম।
    const MAX_NORMAL_DIGITS: usize;

    /// যখন সর্বাধিক উল্লেখযোগ্য দশমিক ডিজিটের চেয়ে এর চেয়ে বেশি স্থানের মান থাকে তবে সংখ্যাটি অবশ্যই অসীমের দিকে গোল হয়।
    ///
    const INF_CUTOFF: i64;

    /// যখন সর্বাধিক উল্লেখযোগ্য দশমিক ডিজিটের তুলনায় স্থানের মান কম হয়, সংখ্যাটি অবশ্যই শূন্যকে গোল করা হয়।
    ///
    const ZERO_CUTOFF: i64;

    /// ঘাটে বিটের সংখ্যা।
    const EXP_BITS: u8;

    /// *লুকানো বিট সহ* তাত্পর্যপূর্ণ বিটের সংখ্যা।
    const SIG_BITS: u8;

    /// * লুকানো বিট বাদ দিয়ে তাত্পর্যপূর্ণ বিটের সংখ্যা।
    const EXPLICIT_SIG_BITS: u8;

    /// ভগ্নাংশের উপস্থাপনায় সর্বাধিক আইনী ব্যাক্তি।
    const MAX_EXP: i16;

    /// সংক্ষিপ্তসারগুলি বাদ দিয়ে ভগ্নাংশের প্রতিনিধিত্বের সর্বনিম্ন আইনী কাফের।
    const MIN_EXP: i16;

    /// `MAX_EXP` অবিচ্ছেদ্য প্রতিনিধিত্বের জন্য, শিফট প্রয়োগ সহ।
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` এনকোড করা (অর্থাত্ অফসেট পক্ষপাত সহ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` অবিচ্ছেদ্য প্রতিনিধিত্বের জন্য, শিফট প্রয়োগ সহ।
    const MIN_EXP_INT: i16;

    /// অবিচ্ছেদ্য উপস্থাপনায় সর্বাধিক স্বাভাবিকীকরণযোগ্য তাত্পর্য।
    const MAX_SIG: u64;

    /// অবিচ্ছেদ্য উপস্থাপনায় সর্বনিম্ন স্বাভাবিকীকরণযোগ্য তাত্পর্য।
    const MIN_SIG: u64;
}

// বেশিরভাগ ক্ষেত্রে #34344 এর জন্য একটি কার্যনির্বাহী।
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// মান্টিসা, সূচক এবং পূর্ণসংখ্যা হিসাবে সাইন দেয়।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // এক্সপোনেন্ট বায়াস + ম্যান্টিসা শিফট
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe অনিশ্চিত যে সমস্ত প্ল্যাটফর্মে `as` সঠিকভাবে রাউন্ড করে।
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// মান্টিসা, সূচক এবং পূর্ণসংখ্যা হিসাবে সাইন দেয়।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // এক্সপোনেন্ট বায়াস + ম্যান্টিসা শিফট
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe অনিশ্চিত যে সমস্ত প্ল্যাটফর্মে `as` সঠিকভাবে রাউন্ড করে।
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// একটি এক্স00 এক্সকে নিকটতম মেশিন ফ্লোটের ধরণে রূপান্তর করে।
/// অস্বাভাবিক ফলাফল পরিচালনা করে না।
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f bit৪ বিট, তাই xe এর মান্টিসা শিফট has৩
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// অর্ধ-টু-সমান দিয়ে T::SIG_BITS বিটের 64৪-বিটের তাৎপর্যকে বৃত্তাকার করুন।
/// এক্সপোনেন্ট ওভারফ্লো পরিচালনা করে না।
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // মান্টিস শিফট সামঞ্জস্য করুন
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// সাধারণ সংখ্যাগুলির জন্য `RawFloat::unpack()` এর বিপরীত।
/// Panics যদি তাত্পর্যপূর্ণ বা সংখ্যক সাধারণ সংখ্যাগুলির জন্য বৈধ না হয়।
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // লুকানো বিটটি সরান
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // এক্সপোনেন্ট বায়াস এবং ম্যান্টিসা শিফ্টের জন্য এক্সপোজেন্টকে সামঞ্জস্য করুন
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") এ সাইন বিট ছেড়ে দিন, আমাদের সংখ্যাগুলি সব ধনাত্মক
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// একটি subnormal গঠন।0 এর একটি ম্যান্টিসার অনুমোদিত এবং শূন্য গঠন করে।
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // এনকোডেড এক্সপোঞ্জেনটি 0, সাইন বিট 0 হয়, তাই আমাদের কেবল বিটগুলি পুনরায় ব্যাখ্যা করতে হবে।
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// একটি এফপি সহ আনুমানিক একটি বিগনাম।হাফ-টু-ইভেন সহ এক্স 100 এক্স ইউএলপি-র মধ্যে গোলাকার।
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // আমরা সূচি `start` এর আগে সমস্ত বিট কেটে ফেলেছি, অর্থাৎ আমরা কার্যকরভাবে `start` পরিমাণে ডান-শিফট করে ফেলেছি, সুতরাং এটিও আমাদের প্রয়োজন হয় onent
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // কাটা বিটগুলির উপর নির্ভর করে রাউন্ড এক্স00 এক্স।
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// যুক্তির চেয়ে কঠোরভাবে বৃহত্তম ভাসমান পয়েন্ট সংখ্যাটি সন্ধান করে।
/// সাবমনরমালস, শূন্য বা এক্সপোনেন্ট আন্ডারফ্লো পরিচালনা করে না।
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// আর্গুমেন্টের চেয়ে সর্বাধিকতম বৃহত্তম ভাসমান পয়েন্ট সংখ্যাটি সন্ধান করুন।
// এই অপারেশনটি স্যাচুরেটিং, অর্থাত্, next_float(inf) ==ইনফ।
// এই মডিউলটির বেশিরভাগ কোডের বিপরীতে, এই ফাংশনটি শূন্য, subnormals এবং অসম্পূর্ণতাগুলি পরিচালনা করে।
// তবে, এখানে অন্যান্য কোডগুলির মতো এটি এনএএন এবং নেতিবাচক সংখ্যার সাথে কাজ করে না।
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // এটি সত্য বলে মনে হয় খুব ভাল, তবে এটি কার্যকর হয়।
        // 0.0 সমস্ত শূন্য শব্দ হিসাবে এনকোড করা হয়।উচ্চারণগুলি 0x000 মি ... মি যেখানে ম্যান্টিসা হয়।
        // বিশেষত, ক্ষুদ্রতম অস্বাভাবিক 0x0 ... 01 এবং বৃহত্তম 0x000F ... এফ হয়।
        // ক্ষুদ্রতম সাধারণ সংখ্যা 0x0010 ... 0, সুতরাং এই কোণার কেসটিও কাজ করে।
        // যদি ইনক্রিমেন্টটি ম্যান্টিসাকে উপচে ফেলে, ক্যারি বিটটি আমরা যেমন চাই তেমন বাড়িয়ে তোলে এবং ম্যান্টিসার বিটগুলি শূন্য হয়ে যায়।
        // গোপন বিট কনভেনশনের কারণে এটিও আমরা যা চাই ঠিক তাই!
        // শেষ অবধি, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY।
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}