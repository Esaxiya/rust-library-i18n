//! দশমিক স্ট্রিংগুলি আইইইই 754 বাইনারি ভাসমান পয়েন্ট সংখ্যাগুলিতে রূপান্তর করা।
//!
//! # সমস্যা বিবৃতি
//!
//! আমাদের দশমিক স্ট্রিং যেমন `12.34e56` দেওয়া হয়।
//! এই স্ট্রিংটিতে অবিচ্ছেদ্য (`12`), ভগ্নাংশ (`34`) এবং এক্সপোনেন্ট (`56`) অংশ রয়েছে।সমস্ত অংশ optionচ্ছিক এবং অনুপস্থিত যখন শূন্য হিসাবে ব্যাখ্যা করা হয়।
//!
//! আমরা আইইইই 754 ফ্লোটিং পয়েন্ট নম্বরটি সন্ধান করি যা দশমিক স্ট্রিংয়ের সঠিক মানের নিকটে থাকে।
//! এটি সুপরিচিত যে অনেকগুলি দশমিক স্ট্রিংয়ের বেস দুটিতে সমাপ্তি উপস্থাপনা নেই, তাই আমরা শেষ স্থানে (অন্য কথায়, পাশাপাশি সম্ভব) 0.5 ইউনিট ঘুরে দেখি।
//! টাইটস, টানা দুই ফ্লোটের মাঝামাঝি দশমিক মানগুলি অর্ধ-সম-কৌশল দ্বারা সমাধান করা হয়, যাকে ব্যাংকারের বৃত্তাকার হিসাবেও পরিচিত।
//!
//! বলা বাহুল্য, বাস্তবায়ন জটিলতার দিক থেকে এবং সিপিইউ চক্রের ক্ষেত্রেও এটি বেশ শক্ত।
//!
//! # Implementation
//!
//! প্রথমত, আমরা লক্ষণগুলি উপেক্ষা করি।বা পরিবর্তে, আমরা রূপান্তর প্রক্রিয়াটির একেবারে শুরুতে এটিকে সরিয়ে ফেলি এবং একে একে একে একে একে একে একে একে একেবারে শেষে পুনরায় প্রয়োগ করি।
//! আইআইইই ফ্লোটগুলি শূন্যের কাছাকাছি প্রতিসাম্যযুক্ত হওয়ায় এটি প্রথম বিটটিকে সহজেই ফ্লপ করে।
//!
//! তারপরে আমরা দশমিক পয়েন্টটি এক্সপোনেন্টটি সামঞ্জস্য করে সরিয়ে ফেলি: ধারণাগতভাবে, `12.34e56` এক্স01 এক্সে পরিণত হয়, যা আমরা ধনাত্মক পূর্ণসংখ্যার এক্স03 এক্স এবং একটি পূর্ণসংখ্যা `e = 54` দিয়ে বর্ণনা করি।
//! `(f, e)` উপস্থাপনাটি পার্সিং পর্যায়ে প্রায় সমস্ত কোড ব্যবহার করে।
//!
//! তারপরে আমরা মেশিন-আকারের পূর্ণসংখ্যার এবং ছোট, স্থির আকারের ভাসমান পয়েন্ট সংখ্যাগুলি (প্রথম `f32`/`f64`, তারপরে bit৪ বিটের হিস্ট্যানডযুক্ত, X01 এক্স) ব্যবহার করে প্রগতিশীলভাবে আরও সাধারণ এবং ব্যয়বহুল বিশেষ কেসের একটি দীর্ঘ শৃঙ্খলা চেষ্টা করি।
//!
//! যখন এই সমস্ত ব্যর্থ হয়, আমরা বুলেটটি কামড়ে ফেলি এবং একটি সাধারণ কিন্তু খুব ধীর গতির অ্যালগরিদম অবলম্বন করি যাতে `f * 10^e` কে সম্পূর্ণরূপে গণনা করা এবং সেরা আনুমানিকতার জন্য পুনরাবৃত্ত অনুসন্ধান করা হয়।
//!
//! প্রাথমিকভাবে, এই মডিউল এবং এর শিশুরা বর্ণিত অ্যালগরিদমগুলি প্রয়োগ করে:
//! "How to Read Floating Point Numbers Accurately" উইলিয়াম ডি দ্বারা
//! ক্লিঞ্জার, অনলাইনে উপলব্ধ: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! এছাড়াও, অসংখ্য সহায়ক ফাংশন রয়েছে যা কাগজে ব্যবহৃত হয় তবে জেড 0 রিস্ট0 জেডে পাওয়া যায় না (বা কমপক্ষে মূলত)।
//! আমাদের সংস্করণ ওভারফ্লো এবং আন্ডারফ্লো হ্যান্ডেল করার প্রয়োজনীয়তা এবং অতি সাধারণ সংখ্যা হ্যান্ডেল করার ইচ্ছা দ্বারা অতিরিক্ত জটিল।
//! বেলারিফোন এবং অ্যালগরিদম আরের ওভারফ্লো, subnormals এবং আন্ডারফ্লোতে সমস্যা রয়েছে।
//! ইনপুটগুলি সমালোচনামূলক অঞ্চলে যাওয়ার আগে আমরা রক্ষণশীলভাবে আলগোরিদম এম (কাগজের ৮ নং বিভাগে বর্ণিত সংশোধনী সহ) স্যুইচ করি।
//!
//! আরেকটি দিক যার দিকে নজর দেওয়া দরকার তা হ'ল `RawFloat`` trait যার মাধ্যমে প্রায় সমস্ত ফাংশন প্যারামিট্রাইজ করা হয়।কেউ ভাবতে পারেন যে এটি X01 এক্স পার্স করা এবং ফলাফলটি `f32` এ ফেলে দেওয়ার পক্ষে যথেষ্ট।
//! দুর্ভাগ্যক্রমে এটি যে পৃথিবীতে আমরা বাস করি না, এবং বেস বা আধা থেকে সম-বৃত্তাকার ব্যবহারের সাথে এর কোনও যোগসূত্র নেই।
//!
//! উদাহরণস্বরূপ দুটি ধরণের `d2` এবং `d4` দুটি দশমিক সংখ্যা এবং চারটি দশমিক অঙ্ক সহ দশমিক প্রকারের প্রতিনিধিত্ব করুন এবং "0.01499" টিকে ইনপুট হিসাবে গ্রহণ করুন।হাফ-আপ রাউন্ডিং ব্যবহার করা যাক।
//! দুটি দশমিক সংখ্যায় সরাসরি যাওয়া `0.01` দেয়, তবে আমরা যদি প্রথমে চারটি সংখ্যায় গোল করি তবে আমরা এক্স02 এক্স পেয়ে যা, পরে এটি `0.02` পর্যন্ত গোল হয়।
//! একই নীতিটি অন্যান্য ক্রিয়াকলাপগুলিতেও প্রযোজ্য, আপনি যদি 0.5 ইউএলপি নির্ভুলতা চান তবে আপনাকে একবারে সমস্ত সঙ্কুচিত বিট বিবেচনা করে *সবকিছু* সম্পূর্ণ নির্ভুলতা এবং বৃত্তাকার * করতে হবে।
//!
//! FIXME: যদিও কিছু কোড ডুপ্লিকেশন প্রয়োজনীয়, সম্ভবত কোডের কিছু অংশ যেমন কম কোড নকল করা হয়েছে প্রায় কাছাকাছি পরিবর্তন হতে পারে।
//! অ্যালগরিদমের বড় অংশগুলি ফ্লোট টাইপের আউটপুট থেকে স্বতন্ত্র বা কেবল কয়েকটি ধ্রুবক অ্যাক্সেসের প্রয়োজন হয়, যা পরামিতি হিসাবে পাস হতে পারে।
//!
//! # Other
//!
//! রূপান্তরটি *panic* কখনই করা উচিত নয়।
//! কোডটিতে জোর দেওয়া এবং সুস্পষ্ট panics রয়েছে তবে সেগুলি কখনই ট্রিগার করা উচিত নয় এবং কেবলমাত্র অভ্যন্তরীণ স্যানিটি চেক হিসাবে পরিবেশন করা উচিত।যে কোনও panics একটি বাগ হিসাবে বিবেচনা করা উচিত।
//!
//! ইউনিট পরীক্ষা আছে তবে তারা নির্ভুলভাবে নির্ভুলতা নিশ্চিত করতে অপর্যাপ্ত, তারা কেবলমাত্র সম্ভাব্য ত্রুটির একটি অল্প শতাংশকে কভার করে।
//! `src/etc/test-float-parse` ডিরেক্টরিতে Python স্ক্রিপ্ট হিসাবে আরও বিস্তৃত পরীক্ষাগুলি অবস্থিত।
//!
//! পূর্ণসংখ্যার ওভারফ্লোতে একটি নোট: এই ফাইলের অনেকগুলি অংশ দশমিক এক্সপোশন `e` দিয়ে পাটিগণিত সম্পাদন করে।
//! প্রাথমিকভাবে, আমরা দশমিক পয়েন্টটি চারদিকে স্থানান্তরিত করি: প্রথম দশমিক অঙ্কের আগে শেষ দশমিক অঙ্কের পরে এবং আরও কিছু onযদি অযত্নে করা হয় তবে এটি উপচে পড়তে পারে।
//! পর্যাপ্ত পরিমাণ ক্ষুদ্র ব্যয়কারীকে কেবলমাত্র হাত দেওয়ার জন্য আমরা পার্সিং সাবমডিউলের উপর নির্ভর করি, যেখানে "sufficient" এর অর্থ "such that the exponent +/- the number of decimal digits fits into a 64 bit integer"।
//! বৃহত্তর উদ্দীপক গ্রহণ করা হয়, তবে আমরা তাদের সাথে পাটিগণিত করি না, তারা তত্ক্ষণাত্ {positive,negative} {zero,infinity} রূপান্তরিত হয়।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// এই দু'জনের নিজস্ব পরীক্ষা রয়েছে।
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// বেস 10 তে একটি স্ট্রিংকে একটি ফ্লোটে রূপান্তর করে।
            /// একটি alচ্ছিক দশমিক ব্যয়কারী গ্রহণ করে।
            ///
            /// এই ফাংশন যেমন স্ট্রিং গ্রহণ করে
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', বা সমতুল্য, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', বা, সমতুল্য, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// শীর্ষস্থানীয় এবং পশ্চাদ্বর্তী সাদা স্থান একটি ত্রুটি উপস্থাপন করে।
            ///
            /// # Grammar
            ///
            /// নিম্নলিখিত [EBNF] ব্যাকরণ মেনে চলা সমস্ত স্ট্রিংগুলির ফলস্বরূপ [`Ok`] ফিরে আসবে:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # জানা বাগ
            ///
            /// কিছু পরিস্থিতিতে, কিছু স্ট্রিং যা বৈধ ফ্লোট তৈরি করতে হবে তার পরিবর্তে ত্রুটি ফিরে আসে।
            /// বিশদ জানতে এক্স00 এক্স দেখুন।
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, একটি স্ট্রিং
            ///
            /// # ফেরত মূল্য
            ///
            /// `Err(ParseFloatError)` যদি স্ট্রিংটি কোনও বৈধ সংখ্যা উপস্থাপন না করে।
            /// অন্যথায়, `Ok(n)` যেখানে `n` হল `src` দ্বারা প্রতিনিধিত্ব করা ভাসমান-পয়েন্ট নম্বর।
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// একটি ত্রুটি যা ফ্লোট বিশ্লেষণ করার সময় ফিরে পাওয়া যায়।
///
/// এই ত্রুটিটি [`f32`] এবং [`f64`] এর জন্য [`FromStr`] প্রয়োগের জন্য ত্রুটি ধরণের হিসাবে ব্যবহৃত হয়।
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// দশমিক স্ট্রিংটি বাকীটিকে পরীক্ষা করে না দেখে বা বৈধতা না দিয়ে সাইন এবং বাক্সে বিভক্ত করে।
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // যদি স্ট্রিংটি অবৈধ হয়, আমরা কখনই সাইনটি ব্যবহার করি না, সুতরাং আমাদের এখানে বৈধতা দেওয়ার দরকার নেই।
        _ => (Sign::Positive, s),
    }
}

/// দশমিক স্ট্রিংকে একটি ভাসমান পয়েন্ট সংখ্যায় রূপান্তর করে।
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// দশমিক-থেকে-ফ্লোট রূপান্তরটির মূল ওয়ার্কহর্স: সমস্ত প্রিপ্রোসেসিং অর্কেস্টেট করুন এবং কোন অ্যালগরিদমকে আসল রূপান্তর করা উচিত তা নির্ধারণ করুন।
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift দশমিক বিন্দু বাইরে।
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 1280 বিটের মধ্যে সীমাবদ্ধ যা প্রায় 385 দশমিক অঙ্কে অনুবাদ করে।
    // যদি আমরা এটি অতিক্রম করি তবে আমরা ক্রাশ করব, সুতরাং খুব কাছে যাওয়ার আগে আমরা ত্রুটিটি ঘুচিয়ে ফেললাম (10 ^ 10 এর মধ্যে)।
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // এখন প্রকাশক অবশ্যই 16 বিটে ফিট করে যা মূল অ্যালগরিদম জুড়ে ব্যবহৃত হয়।
    let e = e as i16;
    // FIXME এই সীমাগুলি বরং রক্ষণশীল।
    // বেল্রোফোনের ব্যর্থতা মোডগুলির আরও সতর্কতার সাথে বিশ্লেষণ আরও বেশি ক্ষেত্রে এটির গতি বাড়ানোর জন্য ব্যবহার করতে পারে।
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// লিখিত হিসাবে, এটি খারাপভাবে অনুকূল করে (দেখুন #27130, যদিও এটি কোডের একটি পুরানো সংস্করণ বোঝায়)।
// `inline(always)` এটির জন্য একটি কর্মসূচী is
// সামগ্রিকভাবে মাত্র দুটি কল সাইট রয়েছে এবং এটি কোডের আকারকে আরও খারাপ করে না।

/// সম্ভাব্য যেখানে স্ট্রাইপ শূন্য, এমনকি এটির জন্য যখন ঘাঁটি পরিবর্তন করা দরকার
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // এই শূন্যগুলি ছাঁটাই কিছু পরিবর্তন করে না তবে দ্রুত পথ (<15 ডিজিট) সক্ষম করতে পারে।
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // ০.০ ... x এবং x ... 0.0 ফর্মের সংখ্যা সরল করুন, সেই অনুসারে এক্সপোনেন্টটি সামঞ্জস্য করুন।
    // এটি সর্বদা একটি বিজয় নাও হতে পারে (সম্ভবত কিছু সংখ্যক দ্রুত গতিপথ থেকে সরিয়ে দেয়) তবে এটি অন্যান্য অংশগুলিকে উল্লেখযোগ্যভাবে সরল করে (উল্লেখযোগ্যভাবে, মানটির দৈর্ঘ্যটি প্রায়)।
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// প্রদত্ত দশমিকের উপরে কাজ করার সময় অ্যালগোরিদম আর এবং অ্যালগরিদম এম যে বৃহত্তম মানকে গণনা করবে তার বৃহত্তম (log10) আকারের উপর দ্রুত-নোংরা উপরের আবদ্ধটি প্রদান করে।
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // আমাদের এখানে ওভারফ্লো সম্পর্কে খুব বেশি চিন্তা করার দরকার নেই trivial_cases() এবং পার্সারকে ধন্যবাদ, যা আমাদের জন্য সবচেয়ে চরম ইনপুটগুলি ফিল্টার করে।
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // ক্ষেত্রে e>=0, উভয় আলগরিদমগুলি `f * 10^e` সম্পর্কে গণনা করুন।
        // অ্যালগরিদম আর এটির সাথে কিছু জটিল গণনা করতে এগিয়ে চলেছে তবে আমরা এটিকে উপেক্ষা করতে পারি upperর্ধ্বসীমার জন্য কারণ এটি পূর্বে ভগ্নাংশও হ্রাস করে, তাই আমাদের সেখানে প্রচুর পরিমাণে বাফার রয়েছে।
        //
        f_len + (e as u64)
    } else {
        // যদি ই <0, অ্যালগরিদম আর মোটামুটি একই জিনিস করে তবে অ্যালগোরিদম এম পৃথক:
        // এটি একটি ধনাত্মক সংখ্যা কে সন্ধান করার চেষ্টা করে যে `f << k / 10^e` একটি সীমান্তের তাত্পর্যপূর্ণ।
        // এর ফলশ্রুতিতে প্রায় `2^53 *f* 10^e` <`10^17 *f* 10^e`।
        // এটির ট্রিগার করা একটি ইনপুট হ'ল 0.33 ... 33 (375 x 3)।
        f_len + e.unsigned_abs() + 17
    }
}

/// দশমিক অঙ্কগুলি না দেখেও সুস্পষ্ট ওভারফ্লো এবং আন্ডারফ্লোগুলি সনাক্ত করে।
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // শূন্য ছিল কিন্তু তারা simplify() দ্বারা ছিনিয়ে নেওয়া হয়েছিল
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // এটি ceil(log10(the real value)) এর অপরিশোধিত অনুমান।
    // আমাদের এখানে ওভারফ্লো সম্পর্কে খুব বেশি চিন্তা করার দরকার নেই কারণ ইনপুট দৈর্ঘ্য ক্ষুদ্রতর (কমপক্ষে 2 ^ 64 এর তুলনায়) এবং পার্সার ইতিমধ্যে এক্সপোশনগুলি পরিচালনা করে যার পরম মান 10 ^ 18 এর চেয়ে বেশি (যা এখনও 10 ^ 19 সংক্ষিপ্ত) 2 ^ 64 এর)।
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}