//! ফর্মের দশমিক স্ট্রিংকে বৈধকরণ এবং সংক্ষেপণ:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! অন্য কথায়, দুটি ব্যতিক্রম সহ স্ট্যান্ডার্ড ফ্লোটিং-পয়েন্ট সিনট্যাক্স: কোনও চিহ্ন নেই এবং এক্স02 এক্স এবং এক্স01 এক্সের কোনও পরিচালনা নেই।এগুলি (super::dec2flt) এর ড্রাইভার ফাংশন দ্বারা পরিচালিত হয়।
//!
//! বৈধ ইনপুটগুলি সনাক্ত করা তুলনামূলকভাবে সহজ হলেও এই মডিউলটিকে অজস্র অবৈধ বৈচিত্রগুলিও প্রত্যাখ্যান করতে হবে, কখনই জেডপ্যানিক0 জেড নয়, এবং অন্যান্য মডিউলগুলি ঘুরে panic (বা ওভারফ্লো) না করে নির্ভর করে এমন অনেকগুলি পরীক্ষা করতে হবে।
//!
//! বিষয়টিকে আরও খারাপ করে তোলার জন্য, ইনপুটটির মাধ্যমে যা ঘটে তা একক পাসে ঘটে।
//! সুতরাং, কোনও কিছু সংশোধন করার সময় সতর্কতা অবলম্বন করুন এবং অন্যান্য মডিউলগুলির সাথে ডাবল-চেক করুন।
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// দশমিক স্ট্রিংয়ের আকর্ষণীয় অংশ।
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// দশমিক প্রকাশক, 18 দশমিক কম সংখ্যার চেয়ে কম গ্যারান্টিযুক্ত।
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ইনপুট স্ট্রিংটি একটি বৈধ ভাসমান পয়েন্ট সংখ্যা কিনা তা পরীক্ষা করে এবং যদি তাই হয় তবে অবিচ্ছেদ্য অংশ, ভগ্নাংশ এবং এর মধ্যে সূচকটি সনাক্ত করুন।
/// লক্ষণগুলি পরিচালনা করে না।
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' এর আগে কোনও সংখ্যা নেই
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // আমাদের বিন্দুটির আগে বা পরে কমপক্ষে একক অঙ্ক প্রয়োজন।
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ভগ্নাংশের পরে ট্র্যাকিং জাঙ্ক
            }
        }
        _ => Invalid, // প্রথম অঙ্কের স্ট্রিংয়ের পরে ট্র্যাকিং জাঙ্ক
    }
}

/// প্রথম অ-অঙ্কের অক্ষর পর্যন্ত দশমিক অঙ্ক ছড়িয়ে দেয়।
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// উদ্দীপক নিষ্কাশন এবং ত্রুটি পরীক্ষা করা।
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ঘুষের পরে ট্র্যাকিং জাঙ্ক
    }
    if number.is_empty() {
        return Invalid; // খালি খালি
    }
    // এই মুহুর্তে, আমাদের কাছে অবশ্যই সংখ্যার একটি বৈধ স্ট্রিং রয়েছে।এটি একটি এক্স 100 এক্স লাগাতে খুব দীর্ঘ হতে পারে তবে এটি যদি বিশাল হয় তবে ইনপুটটি অবশ্যই শূন্য বা অনন্ত।
    // যেহেতু দশমিক অঙ্কের প্রতিটি শূন্যটি কেবলমাত্র +/-1 দ্বারা প্রকাশককে সামঞ্জস্য করে, এক্সপ্রেস=10 ^ 18 এ সীমাবদ্ধ হওয়ার কাছাকাছি হয়ে যাওয়ার জন্য ইনপুটটি 17 এক্সবাট এক্স 100 এক্স জিরো হতে হবে।
    //
    // এটি হ'ল আমাদের ব্যবহার করা প্রয়োজন এমন কোনও ব্যবহারের কেস নয়।
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}