//! কেবল অভ্যন্তরীণ ব্যবহারের জন্য প্রসারিত নির্ভুলতা "soft float"।

// এই মডিউলটি কেবল dec2flt এবং flt2dec এর জন্য, এবং কেবলমাত্র কার্টেসেটের কারণে সর্বজনীন।
// এটি কখনও স্থিতিশীল করার উদ্দেশ্যে নয়।
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// `f * 2^e` উপস্থাপন করে একটি কাস্টম-৪-বিট ভাসমান পয়েন্ট টাইপ।
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// পূর্ণসংখ্যার ম্যান্টিসা।
    pub f: u64,
    /// বেস 2 তে প্রকাশক।
    pub e: i16,
}

impl Fp {
    /// নিজের এবং `other` এর একটি সঠিকভাবে গোলাকার পণ্য ফেরত দেয়।
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// নিজেকে স্বাভাবিক করে তোলে যাতে ফলশ্রুতিতে থাকা ম্যান্টিশা কমপক্ষে `2^63` হয়।
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// ভাগ করে নেওয়া ব্যাক্তি হিসাবে নিজেকে সাধারণ করে তোলে।
    /// এটি কেবলমাত্র ক্ষয়কারীকে হ্রাস করতে পারে (এবং এভাবে ম্যান্টিসার বৃদ্ধি করতে পারে)।
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}