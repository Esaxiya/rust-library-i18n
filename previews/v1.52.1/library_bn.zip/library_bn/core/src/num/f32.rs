//! `f32` একক-নির্ভুলতা ভাসমান পয়েন্ট ধরণের জন্য নির্দিষ্ট ধ্রুবকগুলি।
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` সাব-মডিউলটিতে গাণিতিকভাবে উল্লেখযোগ্য সংখ্যা সরবরাহ করা হয়েছে।
//!
//! এই মডিউলে সরাসরি সংজ্ঞায়িত ধ্রুবকগুলির জন্য (`consts` উপ-মডিউলটিতে সংজ্ঞায়িত থেকে পৃথক হিসাবে), নতুন কোডের পরিবর্তে সরাসরি এক্স01 এক্স টাইপ করা সংযুক্ত কনস্ট্যান্ট ব্যবহার করা উচিত।
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` এর অভ্যন্তরীণ উপস্থাপনার মূলগুলি বা বেস।
/// পরিবর্তে [`f32::RADIX`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // উদ্দেশ্যে উপায়
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// বেস 2 তে উল্লেখযোগ্য অঙ্কের সংখ্যা।
/// পরিবর্তে [`f32::MANTISSA_DIGITS`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // উদ্দেশ্যে উপায়
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// বেস 10 তে উল্লেখযোগ্য অঙ্কের আনুমানিক সংখ্যা।
/// পরিবর্তে [`f32::DIGITS`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // উদ্দেশ্যে উপায়
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` এর জন্য মান।
/// পরিবর্তে [`f32::EPSILON`] ব্যবহার করুন।
///
/// এটি `1.0` এবং পরবর্তী বৃহত্তর উপস্থাপনযোগ্য সংখ্যার মধ্যে পার্থক্য।
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // উদ্দেশ্যে উপায়
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ক্ষুদ্রতম সসীম `f32` মান।
/// পরিবর্তে [`f32::MIN`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // উদ্দেশ্যে উপায়
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// ক্ষুদ্রতম ধনাত্মক সাধারণ `f32` মান।
/// পরিবর্তে [`f32::MIN_POSITIVE`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // উদ্দেশ্যে উপায়
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// সর্বাধিক সীমাবদ্ধ `f32` মান।
/// পরিবর্তে [`f32::MAX`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // উদ্দেশ্যে উপায়
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 এক্সপোনেন্টের ন্যূনতম সম্ভাব্য সাধারণ পাওয়ারের চেয়ে এক বেশি।
/// পরিবর্তে [`f32::MIN_EXP`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // উদ্দেশ্যে উপায়
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// সর্বোচ্চ 2 সম্ভাব্য শক্তি power
/// পরিবর্তে [`f32::MAX_EXP`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // উদ্দেশ্যে উপায়
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// নূন্যতম সম্ভব 10 সাধারণের শক্তি।
/// পরিবর্তে [`f32::MIN_10_EXP`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // উদ্দেশ্যে উপায়
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// সর্বোচ্চ দশটি সম্ভাব্য শক্তি exp
/// পরিবর্তে [`f32::MAX_10_EXP`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // উদ্দেশ্যে উপায়
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// একটি নম্বর (NaN) নয়।
/// পরিবর্তে [`f32::NAN`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // উদ্দেশ্যে উপায়
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// ইনফিনিটি এক্স 100 এক্স।
/// পরিবর্তে [`f32::INFINITY`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // উদ্দেশ্যে উপায়
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// নেতিবাচক অনন্ত (−∞)।
/// পরিবর্তে [`f32::NEG_INFINITY`] ব্যবহার করুন।
///
/// # Examples
///
/// ```rust
/// // অবহেলিত উপায়ে
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // উদ্দেশ্যে উপায়
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// বেসিক গাণিতিক ধ্রুবক।
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath থেকে গাণিতিক ধ্রুবক সঙ্গে প্রতিস্থাপন।

    /// আর্কিমিডিসের ধ্রুবক (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// সম্পূর্ণ বৃত্ত ধ্রুবক (τ)
    ///
    /// সমান 2π।
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// এলারের নম্বর (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` এর অভ্যন্তরীণ উপস্থাপনার মূলগুলি বা বেস।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// বেস 2 তে উল্লেখযোগ্য অঙ্কের সংখ্যা।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// বেস 10 তে উল্লেখযোগ্য অঙ্কের আনুমানিক সংখ্যা।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` এর জন্য মান।
    ///
    /// এটি `1.0` এবং পরবর্তী বৃহত্তর উপস্থাপনযোগ্য সংখ্যার মধ্যে পার্থক্য।
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ক্ষুদ্রতম সসীম `f32` মান।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// ক্ষুদ্রতম ধনাত্মক সাধারণ `f32` মান।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// সর্বাধিক সীমাবদ্ধ `f32` মান।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 এক্সপোনেন্টের ন্যূনতম সম্ভাব্য সাধারণ পাওয়ারের চেয়ে এক বেশি।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// সর্বোচ্চ 2 সম্ভাব্য শক্তি power
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// নূন্যতম সম্ভব 10 সাধারণের শক্তি।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// সর্বোচ্চ দশটি সম্ভাব্য শক্তি exp
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// একটি নম্বর (NaN) নয়।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// ইনফিনিটি এক্স 100 এক্স।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// নেতিবাচক অনন্ত (−∞)।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// এই মানটি `NaN` হলে `true` প্রদান করে।
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` বহনযোগ্যতা সম্পর্কে উদ্বেগের কারণে লাইবকোরে প্রকাশ্যে অনুপলব্ধ, সুতরাং অভ্যন্তরীণভাবে এই প্রয়োগটি ব্যক্তিগত ব্যবহারের জন্য।
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// যদি এই মানটি ধনাত্মক অনন্ত বা negativeণাত্মক অসীম এবং অন্যথায় `false` হয় তবে `true` প্রদান করে।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// যদি এই সংখ্যাটি অসীম বা `NaN` না হয় তবে এক্স01 এক্স প্রদান করে।
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // আলাদাভাবে NaN হ্যান্ডেল করার দরকার নেই: যদি স্ব NaN হয় তবে তুলনাটি ঠিক তেমন পছন্দ মতো নয়।
        //
        self.abs_private() < Self::INFINITY
    }

    /// সংখ্যাটি [subnormal] হলে `true` প্রদান করে।
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` এবং `min` এর মধ্যে মানগুলি হ'ল সাবমনরমাল।
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// সংখ্যাটি যদি শূন্য, অসীম, এক্স01 এক্স, বা এক্স 100 এক্স না হয় তবে এক্স0 2 এক্স প্রদান করে।
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` এবং `min` এর মধ্যে মানগুলি হ'ল সাবমনরমাল।
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// সংখ্যার ফ্লোটিং পয়েন্ট বিভাগটি প্রদান করে।
    /// যদি কেবলমাত্র একটি সম্পত্তি পরীক্ষা করা হয়, তবে তার পরিবর্তে নির্দিষ্ট শিকারী ব্যবহার করা সাধারণত দ্রুত হয়।
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `self` এর ইতিবাচক সাইন থাকলে `+0.0` এক্স, ইতিবাচক সাইন বিট এবং ধনাত্মক অনন্ত সহ with NaN` সহ `true` প্রদান করে।
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// যদি `self` এর নেতিবাচক সাইন থাকে তবে `-0.0`, X নেতিবাচক সাইন বিট এবং negativeণাত্মক অসীম সহ `NaN` সহ `true` প্রদান করে।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // আইইইই 7575৫ বলেছেন: এক্স Xণাত্মক চিহ্ন থাকলে কেবলমাত্র isSignMinus(x) সত্য।
        // isSignMinus জেরো এবং NaN-তেও প্রযোজ্য।
        self.to_bits() & 0x8000_0000 != 0
    }

    /// একটি সংখ্যার পারস্পরিক (inverse) নেয়, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// রেডিয়েনগুলি ডিগ্রীতে রূপান্তর করে।
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // আরও নির্ভুলতার জন্য ধ্রুবক ব্যবহার করুন।
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ডিগ্রিগুলিকে রেডিয়ানে রূপান্তর করে।
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// দুটি সংখ্যার সর্বাধিক প্রদান করে।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// আর্গুমেন্টগুলির মধ্যে একটি যদি NaN হয় তবে অন্য যুক্তিটি ফিরে আসে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// দুটি সংখ্যার সর্বনিম্ন ফিরিয়ে দেয়।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// আর্গুমেন্টগুলির মধ্যে একটি যদি NaN হয় তবে অন্য যুক্তিটি ফিরে আসে।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// শূন্যের দিকে গোল হয় এবং মানটি সীমাবদ্ধ এবং এই ধরণের সাথে মানানসই ধরে নিয়ে কোনও আদিম পূর্ণসংখ্যার ধরণে রূপান্তর করে।
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// মান অবশ্যই:
    ///
    /// * `NaN` না
    /// * অসীম হতে হবে না
    /// * এর ভগ্নাংশের অংশ কেটে দেওয়ার পরে, `Int` রিটার্ন টাইপটিতে উপস্থাপন করুন
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // সুরক্ষা: কলকারীকে অবশ্যই `FloatToInt::to_int_unchecked` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` এ কাঁচা ট্রান্সমুটেশন।
    ///
    /// এটি বর্তমানে সমস্ত প্ল্যাটফর্মে `transmute::<f32, u32>(self)` এর মতো।
    ///
    /// এই অপারেশনটির বহনযোগ্যতার বিষয়ে কিছু আলোচনার জন্য এক্স00 এক্স দেখুন (প্রায় কোনও সমস্যা নেই)।
    ///
    /// মনে রাখবেন যে এই ফাংশনটি `as` ingালাই থেকে পৃথক, যা বিটওয়াইজ মানটি নয়,*সংখ্যাগত* মান সংরক্ষণ করার চেষ্টা করে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() কাস্টিং হচ্ছে না!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // নিরাপদ: `u32` একটি সাধারণ পুরানো ডেটাটাইপ যাতে আমরা সর্বদা এটিতে ট্রান্সমিট করতে পারি
        unsafe { mem::transmute(self) }
    }

    /// `u32` থেকে কাঁচা ট্রান্সমুটেশন।
    ///
    /// এটি বর্তমানে সমস্ত প্ল্যাটফর্মে `transmute::<u32, f32>(v)` এর মতো।
    /// দেখা যাচ্ছে এটি দুটি কারণে অবিশ্বাস্যভাবে পোর্টেবল:
    ///
    /// * সমস্ত সমর্থিত প্ল্যাটফর্মগুলিতে ফ্লোट्स এবং ইনটসের সমান সমাপ্তি রয়েছে।
    /// * আইইইই-754 খুব স্পষ্টভাবে ফ্লোটগুলির বিট লেআউটটি নির্দিষ্ট করে।
    ///
    /// তবে একটি সতর্কতা রয়েছে: আইইইই-754 এর 2008 সংস্করণের আগে, কীভাবে এনএএন সিগন্যালিং বিটটি ব্যাখ্যা করা যায় তা নির্দিষ্টভাবে নির্দিষ্ট করা হয়নি।
    /// বেশিরভাগ প্ল্যাটফর্মগুলি (উল্লেখযোগ্যভাবে x86 এবং এআরএম) এমন ব্যাখ্যাটি বেছে নিয়েছিল যা শেষ পর্যন্ত ২০০৮ সালে প্রমিত করা হয়েছিল, তবে কিছু কিছু (উল্লেখযোগ্যভাবে এমআইপিএস) করেনি।
    /// ফলস্বরূপ, MIPS-এ থাকা সমস্ত সিগন্যালিং এনএন x86 এ শান্ত NaNs এবং তদ্বিপরীত।
    ///
    /// সিগন্যালিং-নেস ক্রস-প্ল্যাটফর্ম সংরক্ষণের চেষ্টা করার পরিবর্তে, এই বাস্তবায়নটি সঠিক বিট সংরক্ষণের পক্ষে।
    /// এর অর্থ হ'ল এনএএন-তে এনকোড থাকা কোনও পে-লোডগুলি সংরক্ষণ করা হবে এমনকি যদি এই পদ্ধতির ফলাফলটি একটি x86 মেশিন থেকে একটি এক্স01 এক্সে নেটওয়ার্কের মাধ্যমে প্রেরণ করা হয়।
    ///
    ///
    /// যদি এই পদ্ধতির ফলাফলগুলি কেবল একই আর্কিটেকচার দ্বারা চালিত হয় যা তাদের উত্পাদন করে, তবে কোনও বহনযোগ্যতার উদ্বেগ নেই।
    ///
    /// যদি ইনপুটটি NaN হয় না, তবে কোনও বহনযোগ্যতার উদ্বেগ নেই।
    ///
    /// যদি আপনি সিগন্যালিংনেস (খুব সম্ভবত) সম্পর্কে চিন্তা না করেন তবে কোনও বহনযোগ্যতার উদ্বেগ নেই।
    ///
    /// মনে রাখবেন যে এই ফাংশনটি `as` ingালাই থেকে পৃথক, যা বিটওয়াইজ মানটি নয়,*সংখ্যাগত* মান সংরক্ষণ করার চেষ্টা করে।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // নিরাপদ: `u32` একটি সাধারণ পুরানো ডেটাটাইপ যাতে আমরা সর্বদা এটি থেকে ট্রান্সমিট করতে পারি
        // এটি প্রমাণ করে যে sNaN এর সাথে সুরক্ষার সমস্যাগুলি চাপিয়ে দেওয়া হয়েছিল!হুররে!
        unsafe { mem::transmute(v) }
    }

    /// বিগ-এন্ডিয়ান (network) বাইট ক্রমে বাইট অ্যারে হিসাবে এই ভাসমান পয়েন্ট সংখ্যাটির মেমরি প্রতিনিধিত্ব করুন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// এই ভাসমান পয়েন্ট সংখ্যাটির স্মৃতি উপস্থাপনাটি ছোট-এডিয়ান বাইট ক্রমে বাইট অ্যারে হিসাবে ফিরিয়ে দিন।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// দেশীয় বাইট ক্রমে একটি বাইট অ্যারে হিসাবে এই ভাসমান পয়েন্ট নম্বরটির স্মৃতি উপস্থাপনাটি ফিরিয়ে দিন।
    ///
    /// টার্গেট প্ল্যাটফর্মের নেটিভ এন্ডিয়নেস যেমন ব্যবহার করা হয়, পোর্টেবল কোডের পরিবর্তে যথাযথ হিসাবে [`to_be_bytes`] বা [`to_le_bytes`] ব্যবহার করা উচিত।
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// দেশীয় বাইট ক্রমে একটি বাইট অ্যারে হিসাবে এই ভাসমান পয়েন্ট নম্বরটির স্মৃতি উপস্থাপনাটি ফিরিয়ে দিন।
    ///
    ///
    /// [`to_ne_bytes`] যখনই সম্ভব এটির চেয়ে বেশি পছন্দ করা উচিত।
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // নিরাপদ: `f32` একটি সাধারণ পুরানো ডেটাটাইপ যাতে আমরা সর্বদা এটিতে ট্রান্সমিট করতে পারি
        unsafe { &*(self as *const Self as *const _) }
    }

    /// বড় এন্ডিয়ানতে বাইট অ্যারে হিসাবে এর প্রতিনিধিত্ব থেকে একটি ভাসমান পয়েন্ট মান তৈরি করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// সামান্য এন্ডিয়ানতে বাইট অ্যারে হিসাবে এর প্রতিনিধিত্ব থেকে একটি ভাসমান পয়েন্ট মান তৈরি করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// নেটিভ এন্ডিয়ানতে বাইট অ্যারে হিসাবে এর প্রতিনিধিত্ব থেকে একটি ভাসমান পয়েন্ট মান তৈরি করুন।
    ///
    /// লক্ষ্য প্ল্যাটফর্মের নেটিভ এন্ডিয়নেস যেমন ব্যবহার করা হয়, পোর্টেবল কোড সম্ভবত এর পরিবর্তে উপযুক্ত হিসাবে [`from_be_bytes`] বা [`from_le_bytes`] ব্যবহার করতে চায়।
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// স্ব এবং অন্যান্য মানগুলির মধ্যে অর্ডার প্রদান করে।
    /// ভাসমান পয়েন্ট সংখ্যাগুলির মধ্যে স্ট্যান্ডার্ড আংশিক তুলনার বিপরীতে, এই তুলনাটি সর্বদা আইইইই 754 (২০০৮ পুনর্বিবেচনা) ভাসমান পয়েন্ট স্ট্যান্ডার্ডে সংজ্ঞায়িত মোট অর্ডার প্রিকেট অনুসারে একটি অর্ডার তৈরি করে।
    /// মানগুলি নিম্নলিখিত ক্রমে অর্ডার করা হয়:
    /// - নেতিবাচক শান্ত NaN
    /// - নেতিবাচক সিগন্যালিং এনএএন
    /// - নেতিবাচক অনন্ত
    /// - নেতিবাচক সংখ্যা
    /// - নেতিবাচক subnormal সংখ্যা
    /// - নেতিবাচক শূন্য
    /// - ধনাত্মক শূন্য
    /// - ধনাত্মক অস্বাভাবিক সংখ্যা
    /// - ধনাত্মক সংখ্যা
    /// - ইতিবাচক অনন্ত
    /// - ইতিবাচক সংকেত NaN
    /// - ইতিবাচক শান্ত NAN
    ///
    /// মনে রাখবেন যে এই ফাংশনটি সর্বদা `f32` এর [`PartialOrd`] এবং [`PartialEq`] বাস্তবায়নের সাথে সম্মত হয় না।বিশেষত, তারা নেতিবাচক এবং ধনাত্মক শূন্যকে সমান হিসাবে বিবেচনা করে, যখন `total_cmp` তা করে না।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // নেতিবাচক ক্ষেত্রে, দুটি এর পরিপূরক পূর্ণসংখ্যার অনুরূপ লেআউট অর্জন করতে চিহ্ন ছাড়া সমস্ত বিটগুলি ফ্লিপ করুন
        //
        // কেন এই কাজ করে?আইইইই 754 ফ্লোটে তিনটি ক্ষেত্র রয়েছে:
        // সাইন বিট, সূচক এবং ম্যান্টিসা।সামগ্রিকভাবে ক্ষতিকারক এবং ম্যান্টিসার ক্ষেত্রগুলির সেটে এমন সম্পত্তি রয়েছে যে তাদের বিটওয়াইস ক্রমটি এমন সংখ্যার দৈর্ঘ্যের সমান যেখানে প্রস্থকে সংজ্ঞায়িত করা হয়েছে।
        // परिमाणটি সাধারণত NaN মানগুলিতে সংজ্ঞায়িত হয় না, তবে আইইইই 754 মোট অর্ডার বিটওয়াইস ক্রম অনুসরণ করতে NaN মানগুলিও সংজ্ঞায়িত করে।এটি ডক মন্তব্যে ব্যাখ্যা করা অর্ডারের দিকে নিয়ে যায়।
        // তবে, মাত্রার প্রতিনিধিত্ব নেতিবাচক এবং ধনাত্মক সংখ্যার জন্য একই-কেবল সাইন বিট ভিন্ন।
        // স্বাক্ষরিত পূর্ণসংখ্যার হিসাবে সহজেই ফ্লোটগুলি তুলনা করতে আমাদের নেতিবাচক সংখ্যার ক্ষেত্রে এক্সপোশন এবং ম্যান্টিসার বিটগুলি ফ্লিপ করতে হবে।
        // আমরা কার্যকরভাবে নম্বরগুলিকে "two's complement" আকারে রূপান্তর করি।
        //
        // ফ্লিপিং করতে, আমরা এর বিরুদ্ধে একটি মুখোশ এবং এক্সওআর তৈরি করি।
        // আমরা শাখাবিহীনভাবে নেতিবাচক স্বাক্ষরিত মানগুলি থেকে একটি "all-ones except for the sign bit" মাস্ক গণনা করি: ডান স্থানান্তর সাইনটি পূর্ণসংখ্যার প্রসারিত করে, তাই আমরা সাইন বিট সহ মুখোশটি এক্স01 এক্স করি এবং তারপরে আরও একটি শূন্য বিট ঠেলে সাইনডে রূপান্তর করি।
        //
        // ধনাত্মক মানগুলিতে, মুখোশটি সমস্ত শূন্য, সুতরাং এটি কোনও অপশন নেই।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// একটি মান নির্দিষ্ট সময় অন্তর সীমাবদ্ধ করুন যদি না এটি না হয়।
    ///
    /// `self` `max` এর চেয়ে বেশি হলে `max` এবং `self` যদি `min` এর চেয়ে কম হয় তবে `max` প্রদান করে।
    /// অন্যথায় এটি `self` প্রদান করে।
    ///
    /// মনে রাখবেন যে এই ফাংশনটি NaN প্রদান করে যদি প্রাথমিক মানটিও NaN ছিল।
    ///
    /// # Panics
    ///
    /// জেড 0 প্যানিক্স0 জেড যদি এক্স 100 এক্স, এক্স01 এক্স নাএন, বা এক্স02 এক্স নাএন হয়।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}