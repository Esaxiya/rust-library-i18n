//! কাস্টম স্বেচ্ছাচারিতা-নির্ভুলতা নম্বর (bignum) বাস্তবায়ন।
//!
//! এটি স্ট্যাক মেমরির ব্যয় করে গাদা বরাদ্দ এড়াতে ডিজাইন করা হয়েছে।
//! সর্বাধিক ব্যবহৃত বিগনাম টাইপ, এক্স00 এক্স, 32 × 40=1,280 বিট দ্বারা সীমাবদ্ধ এবং স্ট্যাক মেমরির সর্বাধিক 160 বাইট লাগবে।
//! সমস্ত সম্ভাব্য সসীম `f64` মানগুলিকে রাউন্ড-ট্রিপিংয়ের জন্য এটি যথেষ্ট পরিমাণে।
//!
//! নীতিগতভাবে বিভিন্ন ইনপুটগুলির জন্য একাধিক বিগনাম ধরণের থাকা সম্ভব, কিন্তু কোড ফুলে যাওয়া এড়াতে আমরা এটি করি না।
//!
//! প্রতিটি বিগনাম এখনও প্রকৃত ব্যবহারের জন্য ট্র্যাক করা হয়, তাই এটি সাধারণত কিছু যায় আসে না।
//!

// এই মডিউলটি কেবল dec2flt এবং flt2dec এর জন্য, এবং কেবলমাত্র কার্টেসেটের কারণে সর্বজনীন।
// এটি কখনও স্থিতিশীল করার উদ্দেশ্যে নয়।
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// বাইনগুম দ্বারা প্রয়োজনীয় পাটিগণিত অপারেশন।
pub trait FullOps: Sized {
    /// `(carry', v')` এমন `carry' * 2^W + v' = self + other + carry` প্রদান করে, যেখানে `Self` এক্সের বিট সংখ্যা `W`।
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` এমন `carry'*2^W + v' = self* other + carry` প্রদান করে, যেখানে `Self` এক্সের বিট সংখ্যা `W`।
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` এমন `carry'*2^W + v' = self* other + other2 + carry` প্রদান করে, যেখানে `Self` এক্সের বিট সংখ্যা `W`।
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` যেমন `borrow *2^W + self = quo* other + rem` এবং `0 <= rem < other` প্রদান করে, যেখানে `Self` এক্সের বিট সংখ্যা `W`।
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // এটি উপচে পড়তে পারে না;আউটপুটটি `0` এবং `2 * 2^nbits - 1` এর মধ্যে।
                    // FIXME: এলএলভিএম এটিকে এডিসি বা অনুরূপে অনুকূলিত করবে?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // এটি উপচে পড়তে পারে না;
                    // আউটপুটটি `0` এবং `2^nbits * (2^nbits - 1)` এর মধ্যে।
                    // FIXME: এলএলভিএম এটিকে এডিসি বা অনুরূপে অনুকূলিত করবে?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // এটি উপচে পড়তে পারে না;
                    // আউটপুটটি `0` এবং `2^nbits * (2^nbits - 1)` এর মধ্যে।
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // এটি উপচে পড়তে পারে না;আউটপুটটি `0` এবং `other * (2^nbits - 1)` এর মধ্যে।
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // এটি সক্ষম করার জন্য আরএফসি এক্স00 এক্স দেখুন।
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// সংখ্যাগুলিতে প্রতিনিধিত্বযোগ্য 5 টির শক্তির সারণী।বিশেষত, বৃহত্তম {u8, u16, u32} মান যা পাঁচটির একটি পাওয়ার এবং এটির সাথে সম্পর্কিত ব্যয়কারী।
/// এক্স 100 এক্স ব্যবহৃত হয়।
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// স্ট্যাক-বরাদ্দ করা সালিশ-নির্ভুলতা (নির্দিষ্ট সীমা পর্যন্ত) পূর্ণসংখ্যা।
        ///
        /// এটি প্রদত্ত প্রকারের ("digit") এর একটি স্থির-আকারের অ্যারে দ্বারা ব্যাকড হয়।
        /// অ্যারে খুব বড় না হলেও (সাধারণত কয়েকশো বাইট) অযত্নে অনুলিপি করলে পারফরম্যান্স হিট হতে পারে।
        ///
        /// সুতরাং এটি উদ্দেশ্যমূলকভাবে `Copy` নয়।
        ///
        /// অতিরিক্ত প্রবাহের ক্ষেত্রে বিগনুমস জেডপ্যানিক0 জেড-এ সমস্ত ক্রিয়াকলাপ উপলব্ধ।
        /// কলার বড় পর্যাপ্ত বিগনাম ধরণের ব্যবহারের জন্য দায়বদ্ধ।
        pub struct $name {
            /// ব্যবহারের ক্ষেত্রে সর্বাধিক "digit" এ অফসেট।
            /// এটি হ্রাস পায় না, সুতরাং গণনা ক্রম সম্পর্কে সচেতন হন।
            /// `base[size..]` শূন্য হওয়া উচিত।
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` প্রতিনিধিত্ব করে যেখানে `W` অঙ্কের ধরণের বিটের সংখ্যা।
            base: [$ty; $n],
        }

        impl $name {
            /// এক অঙ্ক থেকে একটি বিগনাম তৈরি করে।
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` মান থেকে একটি বিগনাম তৈরি করে।
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// অভ্যন্তরীণ অঙ্কগুলি স্লাইস `[a, b, c, ...]` হিসাবে এমনটি ফেরৎ দেয় যে সংখ্যাটির মানটি `a + b *2^W + c* 2^(2W) + ...` যেখানে `W` অঙ্কের ধরণের বিটের সংখ্যা।
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// বিট 0 সর্বনিম্ন তাৎপর্যপূর্ণ যেখানে `i`-th বিট প্রদান করে।
            /// অন্য কথায়, ওজন `2^i` এর বিট।
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// বিগনাম শূন্য হলে `true` প্রদান করে।
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// এই মানটি উপস্থাপনের জন্য প্রয়োজনীয় বিটের সংখ্যা প্রদান করে।
            /// নোট করুন যে শূন্যের জন্য 0 বিট প্রয়োজন।
            pub fn bit_length(&self) -> usize {
                // শূন্যের মধ্যে সবচেয়ে উল্লেখযোগ্য সংখ্যাগুলি এড়িয়ে যান।
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // এখানে শূন্য নয় এমন কোনও সংখ্যা নেই, অর্থাৎ সংখ্যাটি শূন্য।
                    return 0;
                }
                // এটি leading_zeros() এবং বিট শিফটগুলির সাহায্যে অনুকূলিত হতে পারে, তবে এটি সম্ভবত ঝামেলার উপযুক্ত নয়।
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// নিজের মধ্যে `other` যুক্ত করে এবং তার নিজস্ব পরিবর্তনীয় রেফারেন্স দেয়।
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// নিজের থেকে `other` বিয়োগ করে এবং নিজস্ব পরিবর্তনীয় রেফারেন্স প্রদান করে।
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// অঙ্কের আকারের `other` দ্বারা নিজেকে গুণ করে এবং নিজস্ব পরিবর্তনীয় রেফারেন্স দেয়।
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// নিজেকে `2^bits` দ্বারা গুণিত করে এবং তার নিজস্ব পরিবর্তনীয় রেফারেন্স দেয়।
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` বিট দ্বারা শিফট
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` বিট দ্বারা শিফট
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. সংখ্যা] শূন্য, শিফট করার দরকার নেই
                }

                self.size = sz;
                self
            }

            /// নিজেকে `5^e` দ্বারা গুণিত করে এবং তার নিজস্ব পরিবর্তনীয় রেফারেন্স দেয়।
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 on n তে ঠিক এন ট্রেলিং জিরো রয়েছে এবং কেবলমাত্র প্রাসঙ্গিক অঙ্কের মাপ দুটি ক্রমাগত শক্তি, তাই এটি টেবিলের জন্য উপযুক্ত উপযুক্ত সূচক।
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // যতক্ষণ সম্ভব বৃহত্তম একক অঙ্কের পাওয়ারের সাথে গুণ করুন ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... তারপরে বাকীটি শেষ করুন।
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (যেখানে `W` অঙ্কের ধরণের বিটের সংখ্যা) দ্বারা বর্ণিত একটি সংখ্যা দ্বারা নিজেকে গুণ করে এবং তার নিজস্ব পরিবর্তনীয় রেফারেন্স প্রদান করে।
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // অভ্যন্তরীণ রুটিন।aa.len() <= bb.len() হলে সেরা কাজ করে।
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// নিজেকে একটি ডিজিটাল আকারের `other` দ্বারা ভাগ করে এবং তার নিজস্ব পরিবর্তনীয় রেফারেন্স *এবং* বাকীটি প্রদান করে।
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// নিজেকে অন্য বিগাইনাম দিয়ে ভাগ করুন, ভাগফলের সাথে `q` ও বাকীটির সাথে `r` ওভাররাইট করুন।
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // বোকা ধীর base-2 দীর্ঘ বিভাগ থেকে নেওয়া
                // https://en.wikipedia.org/wiki/Division_algorithm
                // দীর্ঘ বিভাগের জন্য FIXME বৃহত্তর বেস ($ty) ব্যবহার করে।
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // বিট `i` কিউ থেকে 1 সেট করুন।
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` এর জন্য ডিজিটের ধরণ।
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// এই এক শুধুমাত্র পরীক্ষার জন্য ব্যবহৃত হয়।
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}