//! 64-বিট স্বাক্ষরিত পূর্ণসংখ্যার ধরণের জন্য ধ্রুবক।
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! নতুন কোডের সাথে সরাসরি সম্পর্কিত ধরণের সাথে সম্পর্কিত ধ্রুবকগুলি ব্যবহার করা উচিত।

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }