//! 32-বিট স্বাক্ষরবিহীন পূর্ণসংখ্যার ধরণের জন্য ধ্রুবক।
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! নতুন কোডের সাথে সরাসরি সম্পর্কিত ধরণের সাথে সম্পর্কিত ধ্রুবকগুলি ব্যবহার করা উচিত।

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }