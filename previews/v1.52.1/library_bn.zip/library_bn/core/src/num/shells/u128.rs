//! 128-বিট স্বাক্ষরবিহীন পূর্ণসংখ্যার ধরণের জন্য ধ্রুবক।
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! নতুন কোডের সাথে সরাসরি সম্পর্কিত ধরণের সাথে সম্পর্কিত ধ্রুবকগুলি ব্যবহার করা উচিত।

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }