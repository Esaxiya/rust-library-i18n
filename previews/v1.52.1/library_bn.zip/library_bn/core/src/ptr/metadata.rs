#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// যে কোনও পয়েন্ট-টু টাইপের পয়েন্টার মেটাডেটা প্রকার সরবরাহ করে।
///
/// # পয়েন্টার মেটাডেটা
///
/// Rust এ কাঁচা পয়েন্টার ধরণের এবং রেফারেন্সের ধরণগুলি দুটি অংশের তৈরি হিসাবে ভাবা যেতে পারে:
/// একটি ডেটা পয়েন্টার যা মানটির মেমরি ঠিকানা এবং কিছু মেটাডেটা ধারণ করে।
///
/// স্ট্যাটিকালি আকারের ধরণের (যা `Sized` traits বাস্তবায়ন করে) পাশাপাশি `extern` প্রকারের জন্য, পয়েন্টারগুলি "পাতলা" বলা হয়: মেটাডেটা শূন্য আকারের এবং এর প্রকারটি `()` is
///
///
/// [dynamically-sized types][dst] এর পয়েন্টারগুলিকে "প্রশস্ত" বা "চর্বি" বলা হয়, তাদের শূন্য-আকারের মেটাডেটা রয়েছে:
///
/// * স্ট্রাক্টগুলির জন্য যাদের শেষ ক্ষেত্রটি ডিএসটি, মেটাডাটা হ'ল শেষ ক্ষেত্রের মেটাডেটা
/// * `str` প্রকারের জন্য, মেটাডেটা হ'ল `usize` হিসাবে বাইটের দৈর্ঘ্য
/// * এক্স01 এক্সের মতো স্লাইস ধরণের জন্য, এক্সডেক্স হিসাবে আইটেমগুলির দৈর্ঘ্য মেটাডেটা
/// * `dyn SomeTrait` এর মতো trait অবজেক্টের জন্য, মেটাডেটা [`DynMetadata<Self>`][DynMetadata] (যেমন `DynMetadata<dyn SomeTrait>`)
///
/// জেডফিউচার0 জেডে, জেড 0 রিস্ট0 জেড ভাষা নতুন ধরণের ধরণের আকার পেতে পারে যার পয়েন্টার মেটাডেটা আলাদা।
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// এই trait এর বিন্দুটি এর `Metadata` সম্পর্কিত প্রকার, যা উপরে বর্ণিত হিসাবে `()` বা `usize` বা `DynMetadata<_>`।
/// এটি প্রতিটি ধরণের জন্য স্বয়ংক্রিয়ভাবে প্রয়োগ করা হয়।
/// এটিকে জেনেরিক প্রসঙ্গে প্রয়োগ করা হবে বলে মনে করা যেতে পারে, এমনকি কোনও নির্দিষ্ট সীমা ছাড়াই।
///
/// # Usage
///
/// কাঁচা পয়েন্টারগুলি তাদের [`to_raw_parts`] পদ্ধতিতে ডেটা ঠিকানা এবং মেটাডেটা উপাদানগুলিতে বিভক্ত হতে পারে।
///
/// বিকল্পভাবে, একা মেটাটাটা [`metadata`] ফাংশন দিয়ে বের করা যেতে পারে।
/// একটি রেফারেন্স [`metadata`] এ প্রেরণ করা যেতে পারে এবং সুস্পষ্টভাবে জোর করা হয়।
///
/// একটি (possibly-wide) পয়েন্টারটি [`from_raw_parts`] বা [`from_raw_parts_mut`] এর সাথে তার ঠিকানা এবং মেটাডেটা থেকে একসাথে ফিরে যেতে পারে।
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` এর পয়েন্টার এবং রেফারেন্সগুলিতে মেটাডেটার জন্য প্রকার।
    #[lang = "metadata_type"]
    // NOTE: trait bounds কে `static_assert_expected_bounds_for_metadata` এ রাখুন
    //
    // `library/core/src/ptr/metadata.rs` এর সাথে এখানে সিঙ্ক সহ:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// এই trait ওরফে প্রয়োগকারী প্রকারের পয়েন্টারগুলি "পাতলা"।
///
/// এটিতে স্ট্যাটিকালি-`আকারযুক্ত` প্রকার এবং `extern` প্রকার অন্তর্ভুক্ত রয়েছে।
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait এলিয়াসগুলি ভাষায় স্থিতিশীল হওয়ার আগে এটি স্থিতিশীল করবেন না?
pub trait Thin = Pointee<Metadata = ()>;

/// একটি পয়েন্টারের মেটাডেটা উপাদানটি বের করুন।
///
/// `*mut T`, `&T`, বা `&mut T` প্রকারের মানগুলি সরাসরি এই ফাংশনে প্রেরণ করা যেতে পারে কারণ তারা স্পষ্টভাবে `* const T` এ জোর করে।
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // সুরক্ষা: * কনস্ট টি থেকে এক্স 100 এক্স ইউনিয়ন থেকে মান অ্যাক্সেস করা নিরাপদ
    // এবং পিটিআরসি কম্পোনেন্টস<T>একই মেমরি লেআউট আছে।
    // কেবলমাত্র std এই গ্যারান্টিটি তৈরি করতে পারে।
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ডেটা ঠিকানা এবং মেটাডেটা থেকে একটি (possibly-wide) কাঁচা পয়েন্টার ফর্ম করে।
///
/// এই ফাংশনটি নিরাপদ তবে প্রত্যাবর্তনকৃত পয়েন্টারটি ডিটারনেন্সের জন্য অগত্যা নিরাপদ নয়।
/// স্লাইসগুলির জন্য, সুরক্ষা প্রয়োজনীয়তার জন্য [`slice::from_raw_parts`] এর ডকুমেন্টেশন দেখুন।
/// trait অবজেক্টের জন্য, মেটাডেটা অবশ্যই পয়েন্টার থেকে একই অন্তর্নিহিত উত্থাপিত ধরণের কাছে আসতে হবে।
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // সুরক্ষা: * কনস্ট টি থেকে এক্স 100 এক্স ইউনিয়ন থেকে মান অ্যাক্সেস করা নিরাপদ
    // এবং পিটিআরসি কম্পোনেন্টস<T>একই মেমরি লেআউট আছে।
    // কেবলমাত্র std এই গ্যারান্টিটি তৈরি করতে পারে।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// কোনও কাঁচা `*mut` পয়েন্টারটি কোনও কাঁচা `* const` পয়েন্টারের বিপরীতে ফিরে আসা ব্যতীত [`from_raw_parts`] এর মতো একই কার্যকারিতা সম্পাদন করে।
///
///
/// আরও তথ্যের জন্য [`from_raw_parts`] এর ডকুমেন্টেশন দেখুন।
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // সুরক্ষা: * কনস্ট টি থেকে এক্স 100 এক্স ইউনিয়ন থেকে মান অ্যাক্সেস করা নিরাপদ
    // এবং পিটিআরসি কম্পোনেন্টস<T>একই মেমরি লেআউট আছে।
    // কেবলমাত্র std এই গ্যারান্টিটি তৈরি করতে পারে।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// এক্স00 এক্স সীমাবদ্ধতা এড়াতে ম্যানুয়াল ইমপ্লের প্রয়োজন।
impl<T: ?Sized> Copy for PtrComponents<T> {}

// এক্স00 এক্স সীমাবদ্ধতা এড়াতে ম্যানুয়াল ইমপ্লের প্রয়োজন।
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait বস্তুর ধরণের মেটাডেটা।
///
/// এটি একটি ভেটেবল (ভার্চুয়াল কল টেবিল) এর পয়েন্টার যা একটি trait অবজেক্টের মধ্যে সঞ্চিত কংক্রিটের প্রকারের হস্তক্ষেপের জন্য প্রয়োজনীয় সমস্ত তথ্য উপস্থাপন করে।
/// Vtable উল্লেখযোগ্যভাবে এটি রয়েছে:
///
/// * টাইপ আকার
/// * প্রান্তিককরণ টাইপ করুন
/// * প্রকারের `drop_in_place` ইমপ্লিটের পয়েন্টার (প্লেইন-পুরাতন-ডেটার জন্য কোনও বিকল্প হতে পারে)
/// * ধরণের trait বাস্তবায়নের জন্য সমস্ত পদ্ধতির দিকে ইঙ্গিত করে
///
/// মনে রাখবেন যে প্রথম তিনটি বিশেষ কারণ এগুলি যে কোনও trait অবজেক্ট বরাদ্দ করা, ফেলে রাখা এবং ডিলোকট করার জন্য প্রয়োজনীয়।
///
/// এই কাঠামোর নাম টাইপ প্যারামিটার দিয়ে দেওয়া সম্ভব যা `dyn` trait অবজেক্ট নয় (উদাহরণস্বরূপ `DynMetadata<u64>`) তবে সেই কাঠামোর কোনও অর্থবহ মান পাওয়া যায় না।
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// সমস্ত vtables এর সাধারণ উপসর্গ।এটি trait পদ্ধতিগুলির জন্য ফাংশন পয়েন্টারগুলির পরে রয়েছে।
///
/// এক্স 100 এক্স ইত্যাদির ব্যক্তিগত প্রয়োগের বিশদ
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// এই ভ্যাটেবলের সাথে সম্পর্কিত ধরণের আকার প্রদান করে।
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// এই vtable এর সাথে সম্পর্কিত ধরণের প্রান্তিককরণ প্রদান করে।
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// আকার এবং প্রান্তিককরণ একসাথে একটি `Layout` হিসাবে ফিরিয়ে দেয়
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // সুরক্ষা: সংকলকটি একটি কংক্রিট Rust টাইপের জন্য এই ভিটিবেলটি নির্গত করে
        // একটি বৈধ বিন্যাস আছে বলে জানা যায়।`Layout::for_value` এর মতো একই যুক্তি।
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// এক্স00 এক্স সীমানা এড়াতে ম্যানুয়াল ইমপ্লের দরকার।

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}