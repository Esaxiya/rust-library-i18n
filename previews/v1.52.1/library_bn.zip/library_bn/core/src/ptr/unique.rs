use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// একটি কাঁচা নন-নাল `*mut T` এর চারপাশে একটি মোড়ক যা নির্দেশ করে যে এই মোড়কের মালিক তার মালিকের মালিক।
/// `Box<T>`, `Vec<T>`, `String`, এবং `HashMap<K, V>` এর মতো বিমূর্ততা তৈরির জন্য দরকারী।
///
/// `*mut T` এর বিপরীতে, `Unique<T>` "as if" আচরণ করে এটি `T` এর উদাহরণ ছিল।
/// `T` যদি `Send`/`Sync` হয় তবে এটি `Send`/`Sync` প্রয়োগ করে।
/// এটি `T` এর উদাহরণ আশা করতে পারে এমন ধরণের শক্তিশালী আলিয়াজিং গ্যারান্টিগুলিও বোঝায়:
/// পয়েন্টারের ভিন্নতা তার নিজস্ব অনন্যের অনন্য পথ ছাড়া পরিবর্তন করা উচিত নয়।
///
/// আপনার উদ্দেশ্যে `Unique` ব্যবহার করা সঠিক কিনা তা সম্পর্কে আপনি যদি অনিশ্চিত থাকেন তবে `NonNull` ব্যবহার করার বিষয়টি বিবেচনা করুন, যার মধ্যে দুর্বল শব্দার্থবিজ্ঞান রয়েছে।
///
///
/// `*mut T` এর বিপরীতে, পয়েন্টারটি অবশ্যই সর্বদা শূন্য হওয়া উচিত, এমনকি যদি পয়েন্টারটি কখনও অবহেলিত না হয়।
/// এটি তাই যাতে এনামরা এই নিষিদ্ধ মানটিকে বৈষম্যমূলক হিসাবে ব্যবহার করতে পারে-এক্স0১ এক্স এর আকারটি এক্স ২০০ এক্স এর সমান।
/// যাইহোক পয়েন্টারটি ডিগ্রিফারেন্স না থাকলে এখনও ঝুঁকতে পারে।
///
/// `*mut T` এর বিপরীতে, `Unique<T>` `T` এর চেয়ে বেশি সমবায়।
/// এটি যেকোন প্রকারের জন্য সর্বদা সঠিক হওয়া উচিত যা ইউনিকের এলিয়াসিং প্রয়োজনীয়তাগুলি সমর্থন করে।
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: এই চিহ্নিতকারীটির বৈকল্পিকতার জন্য কোনও পরিণতি নেই তবে এটি প্রয়োজনীয়
    // ড্রপ বোঝার জন্য যে আমরা যুক্তিযুক্তভাবে একটি `T` এর মালিক।
    //
    // বিস্তারিত জানার জন্য, দেখুন:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` এক্স02 এক্স হলে পয়েন্টারগুলি `Send` হয় কারণ তারা যে ডেটা রেফারেন্স করে সেগুলি আনুমানিকভাবে করা হয়।
/// নোট করুন যে এই এলিয়াসিং আক্রমণকারী টাইপ সিস্টেমের দ্বারা ক্ষমতাহীন;`Unique` ব্যবহার করে বিমূর্তিটি অবশ্যই এটি প্রয়োগ করে।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` এক্স02 এক্স হলে পয়েন্টারগুলি `Sync` হয় কারণ তারা যে ডেটা রেফারেন্স করে সেগুলি আনুমানিকভাবে করা হয়।
/// নোট করুন যে এই এলিয়াসিং আক্রমণকারী টাইপ সিস্টেমের দ্বারা ক্ষমতাহীন;`Unique` ব্যবহার করে বিমূর্তিটি অবশ্যই এটি প্রয়োগ করে।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ঝাঁকুনির মতো একটি নতুন এক্স 100 এক্স তৈরি করে তবে সুসংযুক্ত।
    ///
    /// `Vec::new` এর মতো অলসভাবে বরাদ্দকারী প্রারম্ভিককরণের জন্য এটি দরকারী।
    ///
    /// নোট করুন যে পয়েন্টার মানটি সম্ভাব্যভাবে একটি `T` এর জন্য একটি বৈধ পয়েন্টার উপস্থাপন করতে পারে যার অর্থ এটি অবশ্যই "not yet initialized" সেন্ডিনেল মান হিসাবে ব্যবহার করা উচিত নয়।
    /// যে ধরণের অলসভাবে বরাদ্দ করা হয় সেগুলি অবশ্যই অন্য কোনও উপায়ে সূচনা ট্র্যাক করতে হবে।
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // নিরাপদ: mem::align_of() একটি বৈধ, নন-নাল পয়েন্টার দেয়।দ্য
        // new_unchecked() কল করার শর্তগুলি এভাবে সম্মানিত হয়।
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// একটি নতুন এক্স 100 এক্স তৈরি করে।
    ///
    /// # Safety
    ///
    /// `ptr` অবশ্যই নন-নাল হতে হবে
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `ptr` নন-নাল।
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` অকার্যকর হলে একটি নতুন এক্স 100 এক্স তৈরি করে।
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // নিরাপদ: পয়েন্টারটি ইতিমধ্যে চেক করা হয়েছে এবং নাল নয়।
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// অন্তর্নিহিত `*mut` পয়েন্টার অর্জন করে।
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// বিষয়বস্তু Dereferences।
    ///
    /// ফলস্বরূপ আজীবন আত্মায় আবদ্ধ তাই এটি "as if" এর আচরণ করে এটি আসলে টি এর একটি উদাহরণ ছিল যা ধার করা হচ্ছে।
    /// যদি দীর্ঘ (unbound) আজীবন প্রয়োজন হয়, এক্স00 এক্স ব্যবহার করুন।
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // একটি রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &*self.as_ptr() }
    }

    /// পারস্পরিকভাবে বিষয়বস্তু dereferences।
    ///
    /// ফলস্বরূপ আজীবন আত্মায় আবদ্ধ তাই এটি "as if" এর আচরণ করে এটি আসলে টি এর একটি উদাহরণ ছিল যা ধার করা হচ্ছে।
    /// যদি দীর্ঘ (unbound) আজীবন প্রয়োজন হয়, এক্স00 এক্স ব্যবহার করুন।
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // পরিবর্তনীয় রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &mut *self.as_ptr() }
    }

    /// অন্য টাইপের পয়েন্টারে কাস্ট করুন।
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // সুরক্ষা: এক্স 100 এক্স একটি নতুন অনন্য এবং প্রয়োজনীয়তা তৈরি করে
        // নাল হতে না দেওয়া প্রদত্ত পয়েন্টার।
        // যেহেতু আমরা পয়েন্টার হিসাবে স্বতঃস্ফূর্ত হয়ে যাচ্ছি তাই এটি নালার হতে পারে না।
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // নিরাপত্তা: একটি পরিবর্তনীয় রেফারেন্স নালার হতে পারে না
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}