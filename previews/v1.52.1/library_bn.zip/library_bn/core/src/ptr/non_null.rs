use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` তবে অ শূন্য এবং কোভেরিয়েন্ট
///
/// কাঁচা পয়েন্টার ব্যবহার করে ডেটা স্ট্রাকচার তৈরি করার সময় এটি ব্যবহার করা প্রায়শই সঠিক জিনিস, তবে অতিরিক্ত বৈশিষ্ট্যের কারণে এটি ব্যবহার করা শেষ পর্যন্ত আরও বিপজ্জনক।আপনি যদি `NonNull<T>` ব্যবহার করবেন কিনা তা নিশ্চিত না হন তবে কেবল `*mut T` ব্যবহার করুন!
///
/// `*mut T` এর বিপরীতে, পয়েন্টারটি সর্বদা নন-নਾਲ হওয়া উচিত, এমনকি যদি পয়েন্টারটি কখনও অবহেলিত না হয়।এটি তাই যাতে এনামরা এই নিষিদ্ধ মানটিকে বৈষম্যমূলক হিসাবে ব্যবহার করতে পারে-এক্স02 এক্স এর আকারটি `* mut T` এর সমান।
/// যাইহোক পয়েন্টারটি ডিগ্রিফারেন্স না থাকলে এখনও ঝুঁকতে পারে।
///
/// `*mut T` এর বিপরীতে, `NonNull<T>` কে `T` এর চেয়ে বেশি সমবায় হিসাবে বেছে নেওয়া হয়েছিল।এটি কোভেরিয়েন্ট প্রকারগুলি তৈরি করার সময় এক্স03 এক্স ব্যবহার করা সম্ভব করে তোলে, তবে যদি এমন কোনও ধরণের ব্যবহার করা যায় যা প্রকৃতপক্ষে কোভেরিয়েন্ট না হয় তবে তা অবিশ্বাস্যতার ঝুঁকি প্রবর্তন করে।
/// (বিপরীত পছন্দটি `*mut T` এর জন্য তৈরি করা হয়েছিল যদিও প্রযুক্তিগতভাবে অসম্পূর্ণতা কেবল অনিরাপদ ফাংশনগুলি কল করেই হতে পারে))
///
/// `Box`, `Rc`, `Arc`, `Vec`, এবং `LinkedList` এর মতো সর্বাধিক সুরক্ষিত বিমূর্ততার জন্য কোভারিয়েন্স সঠিক।এটি কেস কারণ তারা একটি সর্বজনীন এপিআই সরবরাহ করে যা Rust এর সাধারণ ভাগ করা XOR পরিবর্তনীয় নিয়ম অনুসরণ করে।
///
/// যদি আপনার প্রকারটি নিরাপদে সমবায় হতে পারে না তবে আপনাকে অবশ্যই নিশ্চিত করতে হবে যে এটিতে চালান সরবরাহের জন্য কোনও অতিরিক্ত ক্ষেত্র রয়েছে।প্রায়শই এই ক্ষেত্রটি `PhantomData<Cell<T>>` বা `PhantomData<&'a mut T>` এর মতো একটি [`PhantomData`] প্রকারের হবে।
///
/// লক্ষ করুন যে `NonNull<T>` এর `&T` এর জন্য একটি `From` উদাহরণ রয়েছে।যাইহোক, এটি এই সত্যটিকে পরিবর্তন করে না যে কোনও (ক এর থেকে প্রাপ্ত পয়েন্টার) ভাগ করে নেওয়া রেফারেন্সের মাধ্যমে অপরিবর্তিত হওয়া কোনও পূর্বনির্ধারিত আচরণ নয় যদি না কোনও [`UnsafeCell<T>`] এর মধ্যে রূপান্তর ঘটে।একটি ভাগ করা রেফারেন্স থেকে একটি পরিবর্তনীয় রেফারেন্স তৈরি করতে একই যায়।
///
/// কোনও এক্স 100 এক্স ছাড়াই এই এক্স 0 এক্স এক্স ব্যবহার করার সময়, `as_mut` কখনই ডাকা হয় না এবং `as_ptr` কখনও রূপান্তর হিসাবে ব্যবহৃত হয় না তা নিশ্চিত করা আপনার দায়িত্ব।
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` পয়েন্টারগুলি `Send` নয় কারণ তারা যে ডেটা রেফারেন্স করে সেগুলি অন্যের মতো করা যেতে পারে।
// NB, এই অভিব্যক্তি অপ্রয়োজনীয়, তবে আরও ভাল ত্রুটি বার্তা সরবরাহ করা উচিত।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` পয়েন্টারগুলি `Sync` নয় কারণ তারা যে ডেটা রেফারেন্স করে সেগুলি অন্যের মতো করা যেতে পারে।
// NB, এই অভিব্যক্তি অপ্রয়োজনীয়, তবে আরও ভাল ত্রুটি বার্তা সরবরাহ করা উচিত।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ঝাঁকুনির মতো একটি নতুন এক্স 100 এক্স তৈরি করে তবে সুসংযুক্ত।
    ///
    /// `Vec::new` এর মতো অলসভাবে বরাদ্দকারী প্রারম্ভিককরণের জন্য এটি দরকারী।
    ///
    /// নোট করুন যে পয়েন্টার মানটি সম্ভাব্যভাবে একটি `T` এর জন্য একটি বৈধ পয়েন্টার উপস্থাপন করতে পারে যার অর্থ এটি অবশ্যই "not yet initialized" সেন্ডিনেল মান হিসাবে ব্যবহার করা উচিত নয়।
    /// যে ধরণের অলসভাবে বরাদ্দ করা হয় সেগুলি অবশ্যই অন্য কোনও উপায়ে সূচনা ট্র্যাক করতে হবে।
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // নিরাপদ: mem::align_of() একটি শূন্য-নাগাদ ইউএসাইজ প্রদান করে যা পরে নিক্ষিপ্ত হয়
        // একটি * মিট টি।
        // সুতরাং, `ptr` নাল নয় এবং new_unchecked() কল করার শর্তাদি সম্মানিত।
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// মানটিতে একটি ভাগ করা রেফারেন্স দেয়।[`as_ref`] এর বিপরীতে, এর জন্য মানটি আরম্ভ করার প্রয়োজন হয় না।
    ///
    /// পরিবর্তনীয় পাল্টা অংশের জন্য দেখুন [`as_uninit_mut`]।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * পয়েন্টারটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।
    ///
    /// * এটি [the module documentation] এ সংজ্ঞায়িত অর্থে "dereferencable" হওয়া উচিত।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি নির্দেশ করে যে মেমরিটি নির্দেশ করে তা অবশ্যই পরিবর্তিত হবে না (`UnsafeCell` এর ভিতরে ব্যতীত)।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // একটি রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &*self.cast().as_ptr() }
    }

    /// মানটির জন্য একটি অনন্য রেফারেন্স দেয়।[`as_mut`] এর বিপরীতে, এর জন্য মানটি আরম্ভ করার প্রয়োজন হয় না।
    ///
    /// ভাগ করা অংশগুলির জন্য দেখুন [`as_uninit_ref`]।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * পয়েন্টারটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।
    ///
    /// * এটি [the module documentation] এ সংজ্ঞায়িত অর্থে "dereferencable" হওয়া উচিত।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি যে পয়েন্টারটিকে নির্দেশ করে সেটি অবশ্যই অন্য কোনও পয়েন্টারের মাধ্যমে অ্যাক্সেস করা (পড়া বা লিখিত) হওয়া উচিত নয়।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // একটি রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// একটি নতুন এক্স 100 এক্স তৈরি করে।
    ///
    /// # Safety
    ///
    /// `ptr` অবশ্যই নন-নাল হতে হবে
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `ptr` নন-নাল।
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` অকার্যকর হলে একটি নতুন এক্স 100 এক্স তৈরি করে।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // নিরাপদ: পয়েন্টারটি ইতিমধ্যে চেক করা হয়েছে এবং নাল নয়
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// X0XX পয়েন্টারটি কোনও কাঁচা `*const` পয়েন্টারের বিপরীতে, X0XX পয়েন্টার ফিরিয়ে দেওয়া ব্যতীত [`std::ptr::from_raw_parts`] এর মতো একই কার্যকারিতা সম্পাদন করে।
    ///
    ///
    /// আরও তথ্যের জন্য [`std::ptr::from_raw_parts`] এর ডকুমেন্টেশন দেখুন।
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // নিরাপদ: এক্স 100 এক্স এর ফলাফল অকার্যকর কারণ `data_address` হয়।
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// এর মধ্যে একটি (সম্ভবত প্রশস্ত) পয়েন্টারটি দ্রবীভূত করা হল ঠিকানা এবং মেটাডেটা উপাদান।
    ///
    /// পয়েন্টারটি পরে [`NonNull::from_raw_parts`] এর সাথে পুনর্গঠন করা যেতে পারে।
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// অন্তর্নিহিত `*mut` পয়েন্টার অর্জন করে।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// মানটির সাথে একটি ভাগ করা রেফারেন্স প্রদান করে।যদি মানটি আনইনটিয়ালাইজড করা যায় তবে এর পরিবর্তে [`as_uninit_ref`] ব্যবহার করা উচিত।
    ///
    /// পরিবর্তনীয় পাল্টা অংশের জন্য দেখুন [`as_mut`]।
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * পয়েন্টারটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।
    ///
    /// * এটি [the module documentation] এ সংজ্ঞায়িত অর্থে "dereferencable" হওয়া উচিত।
    ///
    /// * পয়েন্টারটি অবশ্যই `T` এর একটি প্রাথমিক সূচনায় নির্দেশ করতে হবে।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি নির্দেশ করে যে মেমরিটি নির্দেশ করে তা অবশ্যই পরিবর্তিত হবে না (`UnsafeCell` এর ভিতরে ব্যতীত)।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    /// (আরম্ভ করার বিষয়ে অংশটি এখনও পুরোপুরি সিদ্ধান্ত নেওয়া হয়নি, তবে এটি না হওয়া পর্যন্ত একমাত্র নিরাপদ পদ্ধতির বিষয়টি নিশ্চিত করা যে সেগুলি সত্যই আরম্ভ করা হয়েছে))
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // একটি রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &*self.as_ptr() }
    }

    /// মানটির জন্য একটি অনন্য রেফারেন্স প্রদান করে।যদি মানটি আনইনটিয়ালাইজড করা যায় তবে এর পরিবর্তে [`as_uninit_mut`] ব্যবহার করা উচিত।
    ///
    /// ভাগ করা অংশগুলির জন্য দেখুন [`as_ref`]।
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * পয়েন্টারটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।
    ///
    /// * এটি [the module documentation] এ সংজ্ঞায়িত অর্থে "dereferencable" হওয়া উচিত।
    ///
    /// * পয়েন্টারটি অবশ্যই `T` এর একটি প্রাথমিক সূচনায় নির্দেশ করতে হবে।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি যে পয়েন্টারটিকে নির্দেশ করে সেটি অবশ্যই অন্য কোনও পয়েন্টারের মাধ্যমে অ্যাক্সেস করা (পড়া বা লিখিত) হওয়া উচিত নয়।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    /// (আরম্ভ করার বিষয়ে অংশটি এখনও পুরোপুরি সিদ্ধান্ত নেওয়া হয়নি, তবে এটি না হওয়া পর্যন্ত একমাত্র নিরাপদ পদ্ধতির বিষয়টি নিশ্চিত করা যে সেগুলি সত্যই আরম্ভ করা হয়েছে))
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // নিরাপত্তা: কলকারীকে অবশ্যই গ্যারান্টি দিতে হবে যে `self` সমস্তগুলি পূরণ করে
        // পরিবর্তনীয় রেফারেন্সের জন্য প্রয়োজনীয়তা।
        unsafe { &mut *self.as_ptr() }
    }

    /// অন্য টাইপের পয়েন্টারে কাস্ট করুন।
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // নিরাপদ: `self` একটি `NonNull` পয়েন্টার যা অযথা অকার্যকর
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// পাতলা পয়েন্টার এবং দৈর্ঘ্য থেকে একটি নন-নাল কাঁচা স্লাইস তৈরি করে।
    ///
    /// `len` আর্গুমেন্টটি **উপাদানগুলির** সংখ্যা, বাইটের সংখ্যা নয়।
    ///
    /// এই ফাংশনটি নিরাপদ, তবে প্রত্যাবর্তনের মানটিকে অনিরাপদ is
    /// স্লাইস সুরক্ষা প্রয়োজনীয়তার জন্য [`slice::from_raw_parts`] এর ডকুমেন্টেশন দেখুন।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // প্রথম উপাদানটিতে পয়েন্টার দিয়ে শুরু করার সময় স্লাইস পয়েন্টার তৈরি করুন
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (দ্রষ্টব্য যে এই উদাহরণটি কৃত্রিমভাবে এই পদ্ধতির ব্যবহার প্রদর্শন করে তবে `স্লাইস= NonNull::from(&x[..]);` would be a better way to write code like this.) দেওয়া যাক
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // নিরাপদ: `data` একটি `NonNull` পয়েন্টার যা অযথা অকার্যকর
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// একটি নন-নাল কাঁচা স্লাইসের দৈর্ঘ্য প্রদান করে।
    ///
    /// প্রত্যাবর্তিত মানটি **উপাদানগুলির** সংখ্যা, বাইটের সংখ্যা নয়।
    ///
    /// এই ফাংশনটি নিরাপদ, এমনকি যখন নন-নাল কাঁচা স্লাইসটি একটি স্লাইস হিসাবে চিহ্নিত করা যায় না কারণ পয়েন্টারের কোনও বৈধ ঠিকানা নেই।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// স্লাইসের বাফারে একটি নন-নাল পয়েন্টার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // নিরাপত্তা: আমরা জানি যে `self` নন-নাল।
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// স্লাইসের বাফারে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// সম্ভবত অবিচ্ছিন্ন মানগুলির একটি স্লাইসে একটি ভাগ করা রেফারেন্স প্রদান করে।[`as_ref`] এর বিপরীতে, এর জন্য মানটি আরম্ভ করার প্রয়োজন হয় না।
    ///
    /// পরিবর্তনীয় কাউন্টার পার্টের জন্য দেখুন [`as_uninit_slice_mut`]।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` অনেকগুলি বাইট পড়ার জন্য পয়েন্টারটি অবশ্যই [valid] হওয়া উচিত এবং এটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।এর অর্থ বিশেষভাবে:
    ///
    ///     * এই স্লাইসের পুরো মেমরির ব্যাপ্তি অবশ্যই একটি বরাদ্দকৃত বস্তুর মধ্যে থাকা আবশ্যক!
    ///       স্লাইসগুলি একাধিক বরাদ্দ হওয়া অবজেক্টগুলিতে কখনও ছড়িয়ে যায় না।
    ///
    ///     * পয়েন্টারটি শূন্য দৈর্ঘ্যের টুকরোগুলির জন্যও সারিবদ্ধ হতে হবে।
    ///     এর একটি কারণ হ'ল এনাম লেআউট অপ্টিমাইজেশানগুলি রেফারেন্সগুলিতে নির্ভর করতে পারে (কোনও দৈর্ঘ্যের টুকরোগুলি সহ) প্রান্তিককরণ এবং অন্যান্য ডেটা থেকে আলাদা করার জন্য নন-নাল।
    ///
    ///     আপনি [`NonNull::dangling()`] ব্যবহার করে শূন্য-দৈর্ঘ্যের টুকরোগুলির জন্য `data` হিসাবে ব্যবহারযোগ্য এমন পয়েন্টারটি পেতে পারেন।
    ///
    /// * স্লাইসের মোট আকারের `ptr.len() * mem::size_of::<T>()` অবশ্যই `isize::MAX` এর চেয়ে বড় হওয়া উচিত।
    ///   [`pointer::offset`] এর সুরক্ষা ডকুমেন্টেশন দেখুন।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি নির্দেশ করে যে মেমরিটি নির্দেশ করে তা অবশ্যই পরিবর্তিত হবে না (`UnsafeCell` এর ভিতরে ব্যতীত)।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    ///
    /// এক্স 100 এক্সও দেখুন।
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // সুরক্ষা: কলকারীকে অবশ্যই `as_uninit_slice` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// সম্ভবত অবিচ্ছিন্ন মানগুলির একটি স্লাইসে একটি অনন্য রেফারেন্স প্রদান করে।[`as_mut`] এর বিপরীতে, এর জন্য মানটি আরম্ভ করার প্রয়োজন হয় না।
    ///
    /// ভাগ করা অংশগুলির জন্য দেখুন [`as_uninit_slice`]।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// এই পদ্ধতিটি কল করার সময়, আপনাকে নীচের সমস্তগুলি সত্য কিনা তা নিশ্চিত করতে হবে:
    ///
    /// * পয়েন্টারটি `ptr.len() * mem::size_of::<T>()` অনেকগুলি বাইটে পড়ার জন্য এবং লিখার জন্য অবশ্যই [valid] হওয়া উচিত এবং এটি অবশ্যই সঠিকভাবে প্রান্তিক করা উচিত।এর অর্থ বিশেষভাবে:
    ///
    ///     * এই স্লাইসের পুরো মেমরির ব্যাপ্তি অবশ্যই একটি বরাদ্দকৃত বস্তুর মধ্যে থাকা আবশ্যক!
    ///       স্লাইসগুলি একাধিক বরাদ্দ হওয়া অবজেক্টগুলিতে কখনও ছড়িয়ে যায় না।
    ///
    ///     * পয়েন্টারটি শূন্য দৈর্ঘ্যের টুকরোগুলির জন্যও সারিবদ্ধ হতে হবে।
    ///     এর একটি কারণ হ'ল এনাম লেআউট অপ্টিমাইজেশানগুলি রেফারেন্সগুলিতে নির্ভর করতে পারে (কোনও দৈর্ঘ্যের টুকরোগুলি সহ) প্রান্তিককরণ এবং অন্যান্য ডেটা থেকে আলাদা করার জন্য নন-নাল।
    ///
    ///     আপনি [`NonNull::dangling()`] ব্যবহার করে শূন্য-দৈর্ঘ্যের টুকরোগুলির জন্য `data` হিসাবে ব্যবহারযোগ্য এমন পয়েন্টারটি পেতে পারেন।
    ///
    /// * স্লাইসের মোট আকারের `ptr.len() * mem::size_of::<T>()` অবশ্যই `isize::MAX` এর চেয়ে বড় হওয়া উচিত।
    ///   [`pointer::offset`] এর সুরক্ষা ডকুমেন্টেশন দেখুন।
    ///
    /// * আপনাকে অবশ্যই জেড 0 রুস্ট0 জেড এর এলিয়জিং নিয়মগুলি প্রয়োগ করতে হবে, যেহেতু প্রত্যাবর্তিত জীবনকাল `'a` নির্বিচারে বেছে নেওয়া হয়েছে এবং অগত্যা তথ্যের প্রকৃত জীবনকালকে প্রতিফলিত করে না।
    ///   বিশেষত, এই জীবদ্দশার সময়কালের জন্য, পয়েন্টারটি যে পয়েন্টারটিকে নির্দেশ করে সেটি অবশ্যই অন্য কোনও পয়েন্টারের মাধ্যমে অ্যাক্সেস করা (পড়া বা লিখিত) হওয়া উচিত নয়।
    ///
    /// এই পদ্ধতির ফলাফল অব্যবহৃত হলেও এটি প্রযোজ্য!
    ///
    /// এক্স 100 এক্সও দেখুন।
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // এটি নিরাপদ কারণ `memory` অনেকগুলি বাইট `memory.len()` পড়ার জন্য বৈধ এবং প্রবন্ধে।
    /// // নোট করুন যে `memory.as_mut()` কল করার অনুমতি নেই এখানে কারণ বিষয়বস্তুটি অবিচ্ছিন্ন করা যেতে পারে।
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // সুরক্ষা: কলকারীকে অবশ্যই `as_uninit_slice_mut` এর জন্য সুরক্ষা চুক্তিটি সমর্থন করতে হবে।
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// সীমা পরীক্ষা না করে কোনও উপাদান বা সাব্লাইসে কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// এই পদ্ধতিটি একটি সীমার বাইরে থাকা সূচকের সাথে কল করা বা যখন `self` ড্রিফারেন্সযোগ্য না হয় *[অপরিজ্ঞাত আচরণ]* এমনকি ফলাফল প্রাপ্ত পয়েন্টারটি ব্যবহার না করা হলেও।
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // সুরক্ষা: কলারটি নিশ্চিত করে যে `self` ডেরিফ্রেসেবল এবং এক্স01 এক্স অন্তঃসীমা।
        // ফলস্বরূপ, ফলস্বরূপ পয়েন্টারটি নুল হতে পারে না।
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // নিরাপত্তা: একটি স্বতন্ত্র পয়েন্টারটি বাতিল হতে পারে না, সুতরাং শর্তগুলির জন্য
        // new_unchecked() সম্মানিত হয়।
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // নিরাপত্তা: একটি পরিবর্তনীয় রেফারেন্স নালার হতে পারে না।
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // নিরাপত্তা: একটি রেফারেন্স নਾਲ হতে পারে না, সুতরাং শর্তাবলীর জন্য
        // new_unchecked() সম্মানিত হয়।
        unsafe { NonNull { pointer: reference as *const T } }
    }
}