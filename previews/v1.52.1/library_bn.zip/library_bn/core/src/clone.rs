//! `Clone` trait এমন ধরণের জন্য যা 'স্পষ্টভাবে অনুলিপি করা যায় না'
//!
//! জেড 0 রিস্ট0 জেডে, কিছু সাধারণ প্রকারগুলি হ'ল এক্স00 এক্স এবং যখন আপনি তাদের অর্পণ করেন বা তর্ক হিসাবে তাদের পাস করেন, রিসিভার একটি অনুলিপি পাবেন, মূল মানটি রেখে leaving
//! এই ধরণেরগুলিকে অনুলিপি করার জন্য বরাদ্দ প্রয়োজন হয় না এবং চূড়ান্তকরণকারী নেই (যেমন, তারা মালিকানাধীন বাক্সগুলি ধারণ করে না বা [`Drop`] বাস্তবায়ন করে না), তাই সংকলক তাদের সস্তা এবং অনুলিপি নিরাপদ বলে বিবেচনা করে।
//!
//! অন্যান্য ধরণের জন্য অনুলিপিগুলি অবশ্যই স্পষ্টভাবে তৈরি করতে হবে, [`Clone`] trait বাস্তবায়নের মাধ্যমে এবং [`clone`] পদ্ধতিতে কল করে।
//!
//! [`clone`]: Clone::clone
//!
//! বুনিয়াদি ব্যবহারের উদাহরণ:
//!
//! ```
//! let s = String::new(); // স্ট্রিং টাইপ ক্লোন প্রয়োগ করে
//! let copy = s.clone(); // যাতে আমরা এটি ক্লোন করতে পারি
//! ```
//!
//! ক্লোন জেড 0 ট্রাইট0 জেড সহজেই প্রয়োগ করতে, আপনি `#[derive(Clone)]` ও ব্যবহার করতে পারেন।উদাহরণ:
//!
//! ```
//! #[derive(Clone)] // আমরা মরফিয়াস স্ট্রাক্টে ক্লোন জেড 0 ট্রাইট0 জেড যুক্ত করি
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // এবং এখন আমরা এটি ক্লোন করতে পারি!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// কোনও বস্তুকে স্পষ্টভাবে সদৃশ করার দক্ষতার জন্য একটি সাধারণ trait।
///
/// এক্স0 x এক্স থেকে এক্স 100 এক্স থেকে পৃথক এবং অন্তর্নিহিত অত্যন্ত ব্যয়বহুল, যখন `Clone` সর্বদা সুস্পষ্ট এবং ব্যয়বহুল বা নাও হতে পারে।
/// এই বৈশিষ্ট্যগুলি প্রয়োগ করতে, Rust আপনাকে [`Copy`] রিম্পিমেন্ট করার অনুমতি দেয় না, তবে আপনি `Clone` পুনরায় সংশোধন করতে এবং স্বেচ্ছাসেবী কোড চালাতে পারেন।
///
/// `Clone` [`Copy`] এর চেয়ে বেশি সাধারণ, আপনি [`Copy`] কেও স্বয়ংক্রিয়ভাবে `Clone` হতে পারবেন।
///
/// ## Derivable
///
/// সমস্ত Z ক্ষেত্র যদি `Clone` হয় তবে এই trait `#[derive]` এর সাথে ব্যবহার করা যেতে পারে।[`Clone`]-এর কার্যকর উপকরণ প্রতিটি ক্ষেত্রে [`clone`] কল করে X
///
/// [`clone`]: Clone::clone
///
/// জেনেরিক কাঠামোর জন্য, `#[derive]` জেনেরিক পরামিতিগুলিতে সীমাবদ্ধ `Clone` যুক্ত করে `Clone` বাস্তবায়িত করে।
///
/// ```
/// // `derive` ক্লোন রিডিং প্রয়োগ করে<T>যখন টি ক্লোন হয়।
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## আমি কীভাবে এক্স 100 এক্স প্রয়োগ করতে পারি?
///
/// [`Copy`] প্রকারের `Clone` এর একটি তুচ্ছ বাস্তবায়ন হওয়া উচিত।আরও আনুষ্ঠানিকভাবে:
/// যদি `T: Copy`, `x: T`, এবং `y: &T` হয়, তবে `let x = y.clone();` `let x = *y;` এর সমতুল্য।
/// ম্যানুয়াল বাস্তবায়নগুলি এই আক্রমণকারীকে ধরে রাখতে সাবধান হওয়া উচিত;তবে মেমরির সুরক্ষা নিশ্চিত করার জন্য অনিরাপদ কোড অবশ্যই তার উপর নির্ভর করবে না।
///
/// একটি উদাহরণ একটি জেনেরিক কাঠামো যা একটি ফাংশন পয়েন্টার ধারণ করে।এই ক্ষেত্রে, `Clone` এর বাস্তবায়ন `ব্যয়যুক্ত হতে পারে না, তবে এটি হিসাবে প্রয়োগ করা যেতে পারে:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## অতিরিক্ত প্রয়োগকারী
///
/// [implementors listed below][impls] ছাড়াও, নিম্নলিখিত ধরণেরগুলি `Clone` প্রয়োগ করে:
///
/// * ফাংশন আইটেমের প্রকারগুলি (অর্থাত্ প্রতিটি ফাংশনের জন্য পৃথক ধরণের সংজ্ঞা দেওয়া হয়েছে)
/// * ফাংশন পয়েন্টার ধরণের (যেমন, `fn() -> i32`)
/// * অ্যারের ধরণগুলি, সমস্ত আকারের জন্য, যদি আইটেম টাইপটি `Clone` (যেমন, `[i32; 123456]`) প্রয়োগ করে
/// * টুপল প্রকার, যদি প্রতিটি উপাদান `Clone` প্রয়োগ করে (যেমন, `()`, `(i32, bool)`)
/// * বন্ধের ধরণগুলি, যদি তারা পরিবেশ থেকে কোনও মূল্য ক্যাপচার করে না বা যদি এই জাতীয় সমস্ত কৃত মানগুলি `Clone` নিজেরাই প্রয়োগ করে।
///   নোট করুন যে ভাগ করা রেফারেন্সের মাধ্যমে ক্যাপচার করা ভেরিয়েবলগুলি সর্বদা `Clone` প্রয়োগ করে (এমনকি যদি রেফারেন্স না করে) তবে পরিবর্তনীয় রেফারেন্স দ্বারা ক্যাপচার করা ভেরিয়েবলগুলি কখনই `Clone` প্রয়োগ করে না।
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// মানটির একটি অনুলিপি প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ক্লোন প্রয়োগ করে
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` থেকে অনুলিপি-কার্য সম্পাদন করে।
    ///
    /// `a.clone_from(&b)` কার্যক্ষমতায় `a = b.clone()` এর সমতুল্য, তবে অপ্রয়োজনীয় বরাদ্দ এড়াতে `a` এর রিসোর্সগুলি পুনরায় ব্যবহার করতে ওভাররাইড করা যেতে পারে।
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` এর ইমপ্লিট তৈরি ডেরিভ ম্যাক্রো।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): এই স্ট্রাক্টগুলি সম্পূর্ণরূপে#[ডেরিভ] দ্বারা ব্যবহৃত হয় যে এক ধরণের প্রতিটি উপাদান ক্লোন বা অনুলিপি প্রয়োগ করে sert
//
//
// এই স্ট্রাইকগুলি কখনই ব্যবহারকারীর কোডে উপস্থিত না হয়।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// আদিম ধরণের জন্য `Clone` এর বাস্তবায়ন।
///
/// Rust এ বর্ণনা করা যায় না এমন বাস্তবায়নগুলি `rustc_trait_selection` এ `traits::SelectionContext::copy_clone_conditions()` এ প্রয়োগ করা হয়।
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ভাগ করা রেফারেন্সগুলি ক্লোন করা যায়, তবে পরিবর্তনযোগ্য রেফারেন্সগুলি *পারবেন না*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ভাগ করা রেফারেন্সগুলি ক্লোন করা যায়, তবে পরিবর্তনযোগ্য রেফারেন্সগুলি *পারবেন না*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}