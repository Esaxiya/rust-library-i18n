//! # Rust কোর লাইব্রেরি
//!
//! জেড 0 রিস্ট0 জেড কোর লাইব্রেরি হ'ল এক্স00 এক্স এর নির্ভরতা-মুক্ত [^ ফ্রি] ভিত্তি।
//! এটি ভাষা এবং এর গ্রন্থাগারগুলির মধ্যে পোর্টেবল আঠালো, সমস্ত জেড 0 রিস্ট0জেড কোডের অভ্যন্তরীণ এবং আদিম বিল্ডিং ব্লকগুলি সংজ্ঞায়িত করে।
//!
//! এটি কোনও আপস্ট্রিম লাইব্রেরি, কোনও সিস্টেম লাইব্রেরি এবং কোনও লিবিসি-র সাথে লিঙ্ক করে না।
//!
//! [^free]: Strictly কথা বলছি, কিছু চিহ্ন আছে যা প্রয়োজন তবে
//!          এগুলি সর্বদা প্রয়োজনীয় হয় না।
//!
//! মূল লাইব্রেরিটি হ'ল ন্যূনতম *: এটি গাদা বরাদ্দ সম্পর্কেও সচেতন নয় বা এটি সম্মতি বা I/O সরবরাহ করে না।
//! এই জিনিসগুলির জন্য প্ল্যাটফর্মের একীকরণ প্রয়োজন এবং এই লাইব্রেরিটি প্ল্যাটফর্ম-অজোনস্টিক।
//!
//! # মূল গ্রন্থাগারটি কীভাবে ব্যবহার করবেন
//!
//! দয়া করে মনে রাখবেন যে এই সমস্ত বিবরণ বর্তমানে স্থিতিশীল বলে বিবেচিত হচ্ছে না।
//!
//!
//!
// FIXME: ইন্টারফেস স্থির হয়ে গেলে আমাকে আরও বিশদে পূর্ণ করুন
//! এই গ্রন্থাগারটি কয়েকটি বিদ্যমান প্রতীক অনুমানের উপর নির্মিত:
//!
//! * `memcpy`, `memcmp`, `memset`, এগুলি মূল মেমরি রুটিন যা প্রায়শই এলএলভিএম দ্বারা উত্পাদিত হয়।
//! অতিরিক্তভাবে, এই লাইব্রেরি এই ফাংশনগুলিতে সুস্পষ্ট কল করতে পারে।
//! তাদের স্বাক্ষরগুলি সি তে পাওয়া যায় এমনই are
//!   এই ফাংশনগুলি প্রায়শই সিস্টেম libc দ্বারা সরবরাহ করা হয়, তবে এটি [compiler-builtins crate](https://crates.io/crates/compiler_builtins) দ্বারা সরবরাহ করা যেতে পারে।
//!
//!
//! * `rust_begin_panic` - এই ফাংশনটিতে চারটি আর্গুমেন্ট, একটি `fmt::Arguments`, একটি `&'static str` এবং দুটি takes u32` লাগে।
//! এই চারটি আর্গুমেন্ট panic বার্তা, যে ফাইলটিতে panic আহ্বান করা হয়েছিল এবং ফাইলটির অভ্যন্তরে লাইন এবং কলাম নির্দেশ করে।
//! এই জেড0 স্প্যানিক0 জেড ফাংশনটি সংজ্ঞায়িত করা এই মূল গ্রন্থাগারের গ্রাহকদের উপর নির্ভর করে;এটি কখনও ফিরে না প্রয়োজন।
//! এটির জন্য `panic_impl` নামের একটি `lang` গুণাবলী প্রয়োজন।
//!
//! * `rust_eh_personality` - সংকলক এর ব্যর্থতা পদ্ধতি দ্বারা ব্যবহৃত হয়।
//! এটি প্রায়শই GCC এর ব্যক্তিত্বের ফাংশনে ম্যাপ করা হয় তবে crates যা panic ট্রিগার করে না তা নিশ্চিত করা যায় যে এই ফাংশনটি কখনই ডাকা হয় না।
//! `lang` গুণকে `eh_personality` বলা হয়।
//!
//!
//!

// যেহেতু লাইবকোর অনেকগুলি মৌলিক ল্যাং আইটেম সংজ্ঞায়িত করে, উদ্ভট সমস্যাগুলি এড়াতে সমস্ত পরীক্ষাগুলি পৃথক জেড 0 ক্রেট 0 জেড, লাইবকোরেস্টে থাকে।
//
// এখানে আমরা স্পষ্টভাবে#[সিএফজি]-পরীক্ষার সময় পুরো crate এর বাইরে।
// যদি আমরা এটি না করি, উত্পন্ন পরীক্ষামূলক আর্টিক্ট এবং লিঙ্কযুক্ত লিবেস্টেস্ট (যা ট্রান্সজিটিভলি লাইবকোর অন্তর্ভুক্ত) উভয়ই একই রকম ল্যাং আইটেম সংজ্ঞায়িত করবে এবং এর ফলে E0152 "found duplicate lang item" ত্রুটি ঘটবে।
//
// বিশদ জন্য এক্স 100 এক্স আলোচনা দেখুন।
//
// এই সিএফজি ডক পরীক্ষার উপর প্রভাব ফেলবে না।
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // এক্স 100 এক্স দেখুন
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: পাবলিক হওয়ার দরকার নেই
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// সরাসরি লাইবকরে `core_arch` crate এ টানুন।`core_arch` এর সামগ্রীগুলি একটি পৃথক ভাণ্ডারে রয়েছে: rust-lang/stdarch.
//
// `core_arch` লাইবকোরের উপর নির্ভর করে তবে এই মডিউলটির বিষয়বস্তু এমনভাবে সেট আপ করা হয়েছে যে এখানে সরাসরি এটি টানতে এমন কাজ করে যে crate এই crate টিকে তার লাইবকোর হিসাবে ব্যবহার করে।
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: এই টীকাটি ক্লাশিং_এক্সটার্ন_ ডিক্লেয়ারেশন হওয়ার পরে rust-lang/stdarch এ সরানো উচিত
// একীভূতএটি বর্তমানে তা করতে পারে না কারণ বুটস্ট্র্যাপ ব্যর্থ হয়েছে কারণ lint এখনও সংজ্ঞায়িত করা হয়নি।
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;