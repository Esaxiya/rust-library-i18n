//! ভাগযোগ্য পরিবর্তনশীল পাত্রে।
//!
//! Rust মেমরির সুরক্ষা এই নিয়মের উপর ভিত্তি করে: একটি বস্তু `T` দেওয়া, কেবল নিম্নলিখিতগুলির একটি থাকা সম্ভব:
//!
//! - অবজেক্টের একাধিক অপরিবর্তনীয় রেফারেন্স রয়েছে (এটি **এলিয়াসিং** নামেও পরিচিত)।
//! - অবজেক্টের কাছে একটি পরিবর্তনীয় রেফারেন্স (`&mut T`) থাকা (এটি **রূপান্তর** নামেও পরিচিত)।
//!
//! এটি Rust সংকলক দ্বারা প্রয়োগ করা হয়।তবে এমন পরিস্থিতি রয়েছে যেখানে এই নিয়মটি যথেষ্ট নমনীয় নয়।কখনও কখনও এটি একটি বস্তুর একাধিক উল্লেখ থাকতে পারে এবং এখনও এটি রূপান্তর করতে হবে।
//!
//! ভাগ করে নেওয়া যায় এমন পরিবর্তনীয় পাত্রে আলিয়াসিংয়ের উপস্থিতিতে এমনকি নিয়ন্ত্রিত উপায়ে পরিবর্তনের অনুমতি দেওয়ার জন্য উপস্থিত থাকে।এক্স 100 এক্স এবং এক্স0 এক্স এক্স উভয়ই একক থ্রেডযুক্ত পদ্ধতিতে এটি করার অনুমতি দেয়।
//! তবে `Cell<T>` বা `RefCell<T>` উভয়ই থ্রেড নিরাপদ নয় (তারা [`Sync`] প্রয়োগ করে না)।
//! আপনার যদি একাধিক থ্রেডের মধ্যে অ্যালিজিং এবং মিউটেশন করতে হয় তবে এটি [`Mutex<T>`], [`RwLock<T>`] বা [`atomic`] ধরণের ব্যবহার সম্ভব।
//!
//! `Cell<T>` এবং `RefCell<T>` প্রকারের মানগুলি ভাগ করা রেফারেন্সের মাধ্যমে পরিবর্তিত হতে পারে (যেমন
//! সাধারণ `&T` প্রকারের), যেখানে বেশিরভাগ Rust প্রকারগুলি কেবল অনন্য (`&মিউটেশন টি`) রেফারেন্সের মাধ্যমে পরিবর্তিত হতে পারে।
//! আমরা বলি যে `Cell<T>` এবং `RefCell<T>` 'ইন্টিরিওর মিউটিবিলিটি' সরবরাহ করে, সাধারণ জেড 0 রিস্ট0 জেড ধরণের বিপরীতে যা 'উত্তরাধিকারসূত্রে পরিবর্তিত পরিবর্তন' প্রদর্শন করে।
//!
//! কোষের ধরণ দুটি স্বাদে আসে: এক্স02 এক্স এবং এক্স01 এক্স।`Cell<T>` `Cell<T>` এর মধ্যে এবং বাইরে মানগুলি সরিয়ে অভ্যন্তর পরিবর্তনের প্রয়োগ করে।
//! মানগুলির পরিবর্তে রেফারেন্সগুলি ব্যবহার করতে, কাউকে অবশ্যই `RefCell<T>` প্রকারটি ব্যবহার করতে হবে, পরিবর্তনের আগে একটি রাইটিং লক অর্জন করতে হবে।`Cell<T>` বর্তমান অভ্যন্তরীণ মানটি পুনরুদ্ধার এবং পরিবর্তন করার জন্য পদ্ধতি সরবরাহ করে:
//!
//!  - [`Copy`] প্রয়োগ করে এমন ধরণের ক্ষেত্রে, [`get`](Cell::get) পদ্ধতিটি বর্তমান অভ্যন্তরের মানটি পুনরুদ্ধার করে।
//!  - [`Default`] প্রয়োগ করে এমন ধরণের ক্ষেত্রে, [`take`](Cell::take) পদ্ধতিটি বর্তমান অভ্যন্তরের মানকে [`Default::default()`] এর সাথে প্রতিস্থাপন করে এবং প্রতিস্থাপিত মানটি প্রদান করে।
//!  - সকল প্রকারের জন্য, [`replace`](Cell::replace) পদ্ধতিটি বর্তমান অভ্যন্তরীণ মানটি প্রতিস্থাপন করে এবং প্রতিস্থাপিত মানটি প্রদান করে এবং [`into_inner`](Cell::into_inner) পদ্ধতিটি এক্স0 2 এক্স গ্রাস করে এবং অভ্যন্তরের মানটি প্রদান করে।
//!  অতিরিক্তভাবে, [`set`](Cell::set) পদ্ধতিটি প্রতিস্থাপিত মানটি ফেলে দিয়ে অভ্যন্তরের মান প্রতিস্থাপন করে।
//!
//! `RefCell<T>` 'ডাইনামিক orrowণ' বাস্তবায়নের জন্য জেড 0 রিস্ট0 জেড এর জীবনকাল ব্যবহার করে, এমন একটি প্রক্রিয়া যার মাধ্যমে কেউ অভ্যন্তরীণ মানটিতে অস্থায়ী, একচেটিয়া, পরিবর্তনীয় অ্যাক্সেস দাবি করতে পারে।
//! `রেফসেল এর জন্য ধার<T>Z গুলি Rust এর স্থানীয় রেফারেন্স প্রকারের তুলনায় 'রানটাইমে' ট্র্যাক করা হয় যা সংকলনের সময় সম্পূর্ণরূপে স্ট্যাটিকভাবে ট্র্যাক করা হয়।
//! যেহেতু `RefCell<T>` orrowণগুলি গতিশীল, ইতিমধ্যে পারস্পরিকভাবে aণ নেওয়া একটি মূল্য toণ নেওয়ার চেষ্টা করা সম্ভব;এটি যখন ঘটে তখন এটি panic থ্রেডে আসে।
//!
//! # ইন্টিরিওর মিউটিবিলিটি কখন নির্বাচন করবেন
//!
//! অধিক সাধারণ উত্তরাধিকারসূত্রে পরিবর্তিত পরিবর্তন, যেখানে মানটির পরিবর্তনের জন্য কারও কাছে অনন্য অ্যাক্সেস থাকতে হবে, এমন একটি মূল ভাষা উপাদান যা Rust কে পয়েন্টার আলিয়াসিং সম্পর্কে দৃ reason়ভাবে যুক্তিতে যুক্ত করতে সক্ষম করে, স্থিরিকভাবে ক্র্যাশ বাগগুলি প্রতিরোধ করে।
//! তার কারণ হিসাবে, উত্তরাধিকারসূত্রে পরিবর্তিত পরিবর্তনকে অগ্রাধিকার দেওয়া হয় এবং অভ্যন্তরীণ পরিবর্তনগুলি একটি শেষ অবলম্বন।
//! যেহেতু কোষের প্রকারগুলি রূপান্তর সক্ষম করে যেখানে এটি অন্যথায় নিষিদ্ধ করা হবে, এমন কিছু অনুষ্ঠান রয়েছে যখন অভ্যন্তরীণ পরিবর্তনগুলি যথাযথ হতে পারে, বা এমনকি *অবশ্যই* ব্যবহার করা উচিত eg
//!
//! * অপরিবর্তনীয় কোনও কিছুর পরিবর্তনের 'inside' উপস্থাপন করা হচ্ছে
//! * যৌক্তিক-অপরিবর্তনীয় পদ্ধতিগুলির প্রয়োগের বিশদ।
//! * [`Clone`] এর রূপান্তর কার্যকর করা হচ্ছে।
//!
//! ## অপরিবর্তনীয় কোনও কিছুর পরিবর্তনের 'inside' উপস্থাপন করা হচ্ছে
//!
//! [`Rc<T>`] এবং [`Arc<T>`] সহ অনেকগুলি ভাগ করা স্মার্ট পয়েন্টার প্রকারগুলি এমন পাত্রে সরবরাহ করে যা ক্লোন এবং একাধিক পক্ষের মধ্যে ভাগ করা যায়।
//! যেহেতু অন্তর্ভুক্ত মানগুলি গুণিত-বহিরাগত হতে পারে, সেগুলি কেবল এক্স 100 এক্স নয়, কেবল এক্স01 এক্স দিয়ে ধার করা যেতে পারে।
//! কোষ ব্যতীত এই স্মার্ট পয়েন্টারগুলির ভিতরে ডেটাটি মোটেও পরিবর্তন করা অসম্ভব।
//!
//! পরিবর্তনের পুনঃপ্রবর্তন করতে ভাগ করে নেওয়া পয়েন্টার ধরণের ভিতরে একটি `RefCell<T>` লাগানো খুব সাধারণ:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // গতিশীল orrowণের সুযোগ সীমাবদ্ধ করতে একটি নতুন ব্লক তৈরি করুন
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // মনে রাখবেন যে আমরা যদি ক্যাশের পূর্ববর্তী orrowণটি সুযোগের বাইরে না ফেলে থাকি তবে পরবর্তী orrowণটি ডায়নামিক থ্রেড panic এর কারণ হতে পারে।
//!     //
//!     // এটি `RefCell` ব্যবহারের সবচেয়ে বড় বিপদ।
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! মনে রাখবেন যে এই উদাহরণটি `Arc<T>` ব্যবহার করে `Rc<T>` ব্যবহার করে।`রেফসেল<T>গুলি একক থ্রেডযুক্ত দৃশ্যের জন্য।যদি আপনার একাধিক-থ্রেড পরিস্থিতিতে ভাগ করে নেওয়া মিউটিবিলিটির প্রয়োজন হয় তবে [`RwLock<T>`] বা [`Mutex<T>`] ব্যবহার করার বিষয়টি বিবেচনা করুন।
//!
//! ## যৌক্তিক-অপরিবর্তনীয় পদ্ধতিগুলির প্রয়োগের বিশদ
//!
//! মাঝেমধ্যে এক্সআইএক্সএক্স হতে চলেছে এমন কোনও এপিআইতে প্রকাশ না করাই বাঞ্ছনীয়।
//! এটি কারণ হতে পারে কারণ লজিকালি অপারেশনটি অপরিবর্তনীয় তবে উদাহরণস্বরূপ, ক্যাচিং বাস্তবায়নকে রূপান্তর করতে বাধ্য করে;অথবা যেহেতু আপনার অবশ্যই জেড0ট্রাইট0 জেড পদ্ধতিটি `&self` নেওয়ার জন্য সংজ্ঞায়িত করা হয়েছে তা বাস্তবায়নের জন্য অবশ্যই মিউটেশন নিয়োগ করতে হবে।
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ব্যয়বহুল গণনা এখানে যায়
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` এর রূপান্তর কার্যকর করা হচ্ছে
//!
//! এটি কেবল পূর্বের একটি বিশেষ, তবে সাধারণ: অপরিবর্তনীয় বলে মনে হচ্ছে এমন ক্রিয়াকলাপগুলির জন্য আবশ্যকতা লুকানো।
//! [`clone`](Clone::clone) পদ্ধতিটি উত্সের মানটি পরিবর্তন করবে না এবং `&mut self` নয়, `&self` গ্রহণের ঘোষণা দেওয়া হয়েছে।
//! সুতরাং, `clone` পদ্ধতিতে যে কোনও রূপান্তর ঘটে তা অবশ্যই কোষের ধরণের ব্যবহার করা উচিত।
//! উদাহরণস্বরূপ, [`Rc<T>`] একটি `Cell<T>` এর মধ্যে এর রেফারেন্স গণনাগুলি বজায় রাখে।
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// একটি পরিবর্তনীয় মেমরি অবস্থান।
///
/// # Examples
///
/// এই উদাহরণে, আপনি দেখতে পাচ্ছেন যে `Cell<T>` একটি পরিবর্তনযোগ্য কাঠামোর অভ্যন্তরে রূপান্তর সক্ষম করে।
/// অন্য কথায়, এটি "interior mutability" সক্ষম করে।
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ত্রুটি: এক্স 100 এক্স পরিবর্তনযোগ্য
/// // my_struct.regular_field =নতুন_মূল্য;
///
/// // কাজগুলি: যদিও `my_struct` পরিবর্তনযোগ্য, `special_field` একটি `Cell`,
/// // যা সর্বদা পরিবর্তিত হতে পারে
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// টি-এর জন্য `Default` মান সহ একটি `Cell<T>` তৈরি করে
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// প্রদত্ত মান সমেত একটি নতুন `Cell` তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// অন্তর্ভুক্ত মান সেট করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// দুটি কক্ষের মান অদলবদল করে।
    /// `std::mem::swap` এর সাথে পার্থক্য হ'ল এই ফাংশনটির জন্য `&mut` রেফারেন্সের প্রয়োজন হয় না।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // নিরাপদ: পৃথক থ্রেড থেকে ডাকা হলেও এটি ঝুঁকিপূর্ণ হতে পারে, তবে `Cell`
        // এক্স 100 এক্স তাই এটি হবে না।
        // এটি কোনও পয়েন্টারকেও অকার্যকর করবে না যেহেতু `Cell` নিশ্চিত করে তোলে যে অন্য কোনও কিছুই এই `সেলসের কোনওটিতেই পয়েন্ট করা হবে না।
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` এর সাথে থাকা মানটি প্রতিস্থাপন করে এবং পুরানো অন্তর্ভুক্ত মানটি প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // সুরক্ষা: এটি পৃথক থ্রেড থেকে ডেকে এলে ডেটা দৌড়ের কারণ হতে পারে,
        // তবে `Cell` এক্স01 এক্স তাই এটি হবে না।
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// মান আনপ্রেস করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// থাকা মানটির একটি অনুলিপি প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // সুরক্ষা: এটি পৃথক থ্রেড থেকে ডেকে এলে ডেটা দৌড়ের কারণ হতে পারে,
        // তবে `Cell` এক্স01 এক্স তাই এটি হবে না।
        unsafe { *self.value.get() }
    }

    /// একটি ফাংশন ব্যবহার করে থাকা মান আপডেট করে এবং নতুন মানটি প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// এই ঘরের অন্তর্নিহিত ডেটাতে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// অন্তর্নিহিত ডেটাতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// এই কলটি `Cell` কে পারস্পরিকভাবে ধার করেছে (সংকলন-সময়ে) যা গ্যারান্টি দেয় যে আমাদের একমাত্র রেফারেন্স রয়েছে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// একটি `&mut T` থেকে একটি `&Cell<T>` প্রদান করে
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // সুরক্ষা: এক্স 100 এক্স অনন্য অ্যাক্সেস নিশ্চিত করে।
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` এর জায়গায় রেখে কক্ষের মান নেয়।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// একটি `&Cell<[T]>` থেকে একটি `&[Cell<T>]` প্রদান করে
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // নিরাপদ: `Cell<T>` এর `T` এর মতো মেমরি লেআউট রয়েছে।
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// পরিবর্তনীয়ভাবে পরীক্ষা করা locationণ সংক্রান্ত বিধিগুলির সাথে একটি পরিবর্তনীয় মেমরি অবস্থান
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// এক্স 100 এক্স দ্বারা একটি ত্রুটি ফিরে এসেছে।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// এক্স 100 এক্স দ্বারা একটি ত্রুটি ফিরে এসেছে।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// ধনাত্মক মানগুলি `Ref` সক্রিয় সংখ্যার প্রতিনিধিত্ব করে।Gণাত্মক মানগুলি `RefMut` সক্রিয় সংখ্যার প্রতিনিধিত্ব করে।
// একাধিক `রেফমেটস কেবল তখনই সক্রিয় হয়ে উঠতে পারে যদি তারা কোনও `RefCell` (যেমন, একটি স্লাইজের বিভিন্ন ব্যাপ্তি) এর স্বতন্ত্র, ননওভারল্যাপিং উপাদানগুলি উল্লেখ করে।
//
// `Ref` এবং `RefMut` উভয় আকারের শব্দ, এবং তাই সম্ভবত `usize` রেঞ্জের অর্ধেক উপচে পড়ার পক্ষে পর্যাপ্ত `রেফস বা` রেফমেটস কখনও থাকবে না।
// সুতরাং, একটি `BorrowFlag` সম্ভবত কখনও উপচে পড়া বা আন্ডারফ্লো হবে না।
// তবে এটি কোনও গ্যারান্টি নয়, কারণ একটি প্যাথলজিকাল প্রোগ্রাম বারবার তৈরি করতে পারে এবং তারপরে mem::forget `Ref`s বা`RefMut`s।
// সুতরাং, অনর্থকতা এড়াতে সমস্ত কোডকে স্পষ্টভাবে ওভারফ্লো এবং আন্ডারফ্লো পরীক্ষা করা উচিত, বা অন্তত প্রবাহ বা ভূগর্ভে ঘটে যাওয়া ইভেন্টে অন্তত সঠিকভাবে আচরণ করা উচিত (উদাহরণস্বরূপ, BorrowRef::new দেখুন)।
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// এক্স 100 এক্সযুক্ত একটি নতুন এক্স01 এক্স তৈরি করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// মোড়ানো মানটি ফিরিয়ে `RefCell` গ্রহণ করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // যেহেতু এই ফাংশনটি `self` (`RefCell`) দ্বারা মান গ্রহণ করে, সংকলকটি স্থিরভাবে যাচাই করে যে এটি বর্তমানে ধার করা হয়নি।
        //
        self.value.into_inner()
    }

    /// মুছে যাওয়া মানকে একটি নতুনের সাথে প্রতিস্থাপন করে, পুরানো মানটি ফিরিয়ে দেয়, কোনও একটিকেই ডিনিটাইজেশন না করে।
    ///
    ///
    /// এই ফাংশনটি [`std::mem::replace`](../mem/fn.replace.html) এর সাথে সম্পর্কিত।
    ///
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে ধার করা থাকলে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// মুদ্রিত মানকে `f` থেকে নতুন একটি গণনা করে প্রতিস্থাপন করে, পুরানো মানটি কোনওটিকেই ডিনিটাইজেশন না করে ফিরিয়ে দেয়।
    ///
    ///
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে ধার করা থাকলে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// কোনও একটিকে ডিনিটাইজাল না করেই,`other` এর মোড়কযুক্ত মানটি `self` এর মোড়ক মানকে অদলবদল করে।
    ///
    ///
    /// এই ফাংশনটি [`std::mem::swap`](../mem/fn.swap.html) এর সাথে সম্পর্কিত।
    ///
    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// অনিবার্যভাবে মোড়ানো মানটি ধার করে।
    ///
    /// ফিরে আসা `Ref` সুযোগ ছাড়ার আগ পর্যন্ত untilণ স্থায়ী হয়।
    /// একাধিক অপরিবর্তনীয় orrowণ একই সাথে নেওয়া যেতে পারে।
    ///
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে পারস্পরিকভাবে ধার করা থাকলে।
    /// নন-প্যানিকিং ভেরিয়েন্টের জন্য, [`try_borrow`](#method.try_borrow) ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic এর উদাহরণ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// অপ্রত্যাশিতভাবে মোড়ানো মানটি ধার করা হয়, মানটি বর্তমানে পারস্পরিকভাবে ধার করা থাকলে একটি ত্রুটি প্রদান করে।
    ///
    ///
    /// ফিরে আসা `Ref` সুযোগ ছাড়ার আগ পর্যন্ত untilণ স্থায়ী হয়।
    /// একাধিক অপরিবর্তনীয় orrowণ একই সাথে নেওয়া যেতে পারে।
    ///
    /// এটি [`borrow`](#method.borrow) এর নন-প্যানিকিং বৈকল্পিক।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // নিরাপদ: এক্স00 এক্স নিশ্চিত করে যে কেবলমাত্র স্থাবর অ্যাক্সেস রয়েছে
            // ধার করা যখন মান।
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// পারস্পরিকভাবে মোড়ানো মানটি ধার করে।
    ///
    /// ধারটি ফিরে আসা `RefMut` বা এখান থেকে প্রাপ্ত সমস্ত `রেফমেটস অবধি স্কোপ না হওয়া পর্যন্ত স্থায়ী হয়।
    ///
    /// এই orrowণ সক্রিয় থাকাকালীন মান ধার করা যায় না।
    ///
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে ধার করা থাকলে।
    /// নন-প্যানিকিং ভেরিয়েন্টের জন্য, [`try_borrow_mut`](#method.try_borrow_mut) ব্যবহার করুন।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic এর উদাহরণ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// পারস্পরিকভাবে মোড়ানো মানটি ধার নেয়, মানটি বর্তমানে ধার করা থাকলে একটি ত্রুটি ফেরায়।
    ///
    ///
    /// ধারটি ফিরে আসা `RefMut` বা এখান থেকে প্রাপ্ত সমস্ত `রেফমেটস অবধি স্কোপ না হওয়া পর্যন্ত স্থায়ী হয়।
    /// এই orrowণ সক্রিয় থাকাকালীন মান ধার করা যায় না।
    ///
    /// এটি [`borrow_mut`](#method.borrow_mut) এর নন-প্যানিকিং বৈকল্পিক।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // নিরাপদ: এক্স00 এক্স অনন্য অ্যাক্সেসের গ্যারান্টি দেয়।
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// এই ঘরের অন্তর্নিহিত ডেটাতে একটি কাঁচা পয়েন্টার প্রদান করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// অন্তর্নিহিত ডেটাতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// এই কলটি `RefCell` কে পারস্পরিকভাবে (সংকলন-সময়ে) ধার করেছে তাই ডায়নামিক চেকগুলির প্রয়োজন নেই।
    ///
    /// তবে সাবধান থাকুন: এই পদ্ধতিটি `self` কে পরিবর্তনযোগ্য হতে পারে বলে প্রত্যাশা করে, যা কোনও এক্স 100 এক্স ব্যবহার করার সময় সাধারণত হয় না।
    ///
    /// `self` পরিবর্তনযোগ্য না হলে পরিবর্তে [`borrow_mut`] পদ্ধতিটি দেখুন।
    ///
    /// এছাড়াও, দয়া করে সচেতন হন যে এই পদ্ধতিটি কেবলমাত্র বিশেষ পরিস্থিতিতে এবং সাধারণত আপনি চান তা নয় is
    /// সন্দেহের ক্ষেত্রে এর পরিবর্তে [`borrow_mut`] ব্যবহার করুন।
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// এক্স 100 এক্স এর stateণ স্থিতিতে ফাঁস গার্ডদের প্রভাব পূর্বাবস্থায় ফেরাবেন।
    ///
    /// এই কলটি [`get_mut`] এর মতো তবে আরও বিশেষায়িত।
    /// কোনও orrowণ গ্রহণের অস্তিত্ব না তা নিশ্চিত করার জন্য এটি `RefCell` mutণ নেয় এবং তারপরে রাষ্ট্রের ট্র্যাকিং ভাগ করে নেওয়া orrowণ পুনরায় সেট করে।
    /// কিছু প্রজন্মের `Ref` বা `RefMut` orrowণ ফাঁস হয়ে গেলে এটি প্রাসঙ্গিক।
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// অপ্রত্যাশিতভাবে মোড়ানো মানটি ধার করা হয়, মানটি বর্তমানে পারস্পরিকভাবে ধার করা থাকলে একটি ত্রুটি প্রদান করে।
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` এর বিপরীতে, এই পদ্ধতিটি অনিরাপদ কারণ এটি কোনও `Ref` ফেরত দেয় না, ফলে flagণগ্রহিত পতাকাটি ছোঁয়া থাকে।
    /// এই পদ্ধতির দ্বারা প্রদত্ত রেফারেন্সটি জীবিত থাকাকালীন `RefCell` orrowণ নেওয়া অনির্ধারিত আচরণ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // নিরাপত্তা: আমরা পরীক্ষা করে দেখি যে এখন কেউ সক্রিয়ভাবে লিখছেন না, তবে তা
            // ফিরে আসা রেফারেন্স আর ব্যবহার না করা অবধি কেউ লেখেন না তা নিশ্চিত করার জন্য কলারের দায়িত্ব responsibility
            // এছাড়াও, `self.value.get()` `self` এর মালিকানাধীন মানটিকে বোঝায় এবং এভাবে `self` এর আজীবন বৈধ হওয়ার গ্যারান্টিযুক্ত।
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()` এর জায়গায় রেখে, মোড়ানো মানটি নেয়।
    ///
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে ধার করা থাকলে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics মানটি বর্তমানে পারস্পরিকভাবে ধার করা থাকলে।
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// টি এর জন্য `Default` মান সহ একটি `RefCell<T>` তৈরি করে
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// যদি `RefCell` এর মান বর্তমানে ধার করা হয় তবে Panics।
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Bণ বৃদ্ধির ফলে এই ক্ষেত্রে অ-পঠন মান (<=0) হতে পারে:
            // 1. এটি ছিল <0, অর্থাত্ লেখার areণ রয়েছে, তাই জেড 0 রাস্ত0 জেড এর রেফারেন্স আলিয়াজিং বিধিগুলির কারণে আমরা একটি পড়ার orrowণের অনুমতি দিতে পারি না
            // 2.
            // এটি ছিল isize::MAX (orrowণ গ্রহণের সর্বাধিক পরিমাণ) এবং এটি এক্স01 এক্স (লেখার orrowণের সর্বাধিক পরিমাণ) এ প্রবাহিত হয়েছিল তাই আমরা অতিরিক্ত পড়ার allowণের অনুমতি দিতে পারি না কারণ আইসাইজ এতগুলি পড়ার orrowণকে উপস্থাপন করতে পারে না (এটি কেবল তখনই ঘটতে পারে যদি আপনি সামান্য পরিমাণে `রেফের চেয়ে বেশি mem::forget করেন, এটি ভাল অনুশীলন নয়)
            //
            //
            //
            //
            None
        } else {
            // Orrowণ বৃদ্ধির ফলে এই ক্ষেত্রে পড়ার মান (> 0) হতে পারে:
            // 1. এটি ছিল=0, অর্থাত্ এটি edণ নেওয়া হয়নি, এবং আমরা প্রথম পড়ার orrowণ নিচ্ছি
            // 2. এটি ছিল> 0 এবং <isize::MAX, অর্থাত্
            // পড়ার জন্য ধার ছিল, এবং আইসাইজ আরও একটি পড়ার representণ প্রতিনিধিত্ব করতে যথেষ্ট বড়
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // যেহেতু এই রেফ বিদ্যমান, আমরা জানি যে ধার ধারনাটি একটি পড়ার orrowণ।
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // লেখার orrowণে উপচে পড়া থেকে orrowণ কাউন্টারকে আটকে দিন।
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` বাক্সে একটি মানের edণ নেওয়া রেফারেন্সকে মোড়ানো।
/// একটি `RefCell<T>` থেকে স্থায়ীভাবে ধার করা মানের জন্য একটি মোড়কের ধরণ।
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// একটি এক্স 100 এক্স অনুলিপি করে।
    ///
    /// `RefCell` ইতিমধ্যে স্থায়ীভাবে ধার করা হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `Ref::clone(...)` হিসাবে ব্যবহার করা দরকার।
    /// একটি `Clone` বাস্তবায়ন বা কোনও পদ্ধতি কোনও `RefCell` এর সামগ্রীগুলি ক্লোন করতে `r.borrow().clone()` এর ব্যাপক ব্যবহারে হস্তক্ষেপ করবে।
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// ধার করা ডেটার উপাদানগুলির জন্য একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// `RefCell` ইতিমধ্যে স্থায়ীভাবে ধার করা হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `Ref::map(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ধার করা ডেটার anচ্ছিক উপাদানগুলির জন্য একটি নতুন এক্স00 এক্স তৈরি করে।
    /// যদি ক্লোজারটি `None` প্রদান করে তবে মূল গার্ডটি `Err(..)` হিসাবে ফিরে আসবে।
    ///
    /// `RefCell` ইতিমধ্যে স্থায়ীভাবে ধার করা হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `Ref::filter_map(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ধার করা ডেটার বিভিন্ন উপাদানগুলির জন্য এক `Ref` কে একাধিক `রেফারিতে বিভক্ত করে।
    ///
    /// `RefCell` ইতিমধ্যে স্থায়ীভাবে ধার করা হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `Ref::map_split(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// অন্তর্নিহিত ডেটাতে একটি রেফারেন্সে রূপান্তর করুন।
    ///
    /// অন্তর্নিহিত `RefCell` আর কখনও পারস্পরিকভাবে againণ নেওয়া যাবে না এবং সর্বদা ইতোমধ্যে স্থায়ীভাবে ধার করা উপস্থিত হবে।
    ///
    /// অবিচ্ছিন্ন রেফারেন্সের চেয়ে আরও বেশি ফুটো করা ভাল ধারণা নয়।
    /// `RefCell` স্থিতিস্থাপকভাবে আবার ধার করা যেতে পারে যদি কেবলমাত্র একটি সংখ্যক ছোট ফাঁস দেখা দেয়।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `Ref::leak(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // এই রেফটিকে ভুলে আমরা নিশ্চিত করেছিলাম যে রেফসেলের eণ কাউন্টারটি আজীবন `'b` এর মধ্যে পুনরায় ব্যবহার করা যায় না।
        // রেফারেন্স ট্র্যাকিংয়ের স্থিতি পুনরায় সেট করার জন্য ধার করা রেফসিলের অনন্য রেফারেন্সের প্রয়োজন হবে।
        // মূল ঘরটি থেকে আর কোনও পরিবর্তনীয় রেফারেন্স তৈরি করা যায় না।
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// ধার করা ডেটাগুলির একটি উপাদান যেমন একটি এনুম বৈকল্পিকের জন্য একটি নতুন এক্স00 এক্স তৈরি করে।
    ///
    /// `RefCell` ইতিমধ্যে পারস্পরিক orrowণ নেওয়া হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `RefMut::map(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): orrowণ-চেক ঠিক করুন
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ধার করা ডেটার anচ্ছিক উপাদানগুলির জন্য একটি নতুন এক্স00 এক্স তৈরি করে।
    /// যদি ক্লোজারটি `None` প্রদান করে তবে মূল গার্ডটি `Err(..)` হিসাবে ফিরে আসবে।
    ///
    /// `RefCell` ইতিমধ্যে পারস্পরিক orrowণ নেওয়া হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `RefMut::filter_map(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): orrowণ-চেক ঠিক করুন
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // নিরাপত্তা: ফাংশন সময়কালের জন্য একচেটিয়া রেফারেন্স ধরে রাখে
        // `orig` এর মাধ্যমে তার কলটির, এবং পয়েন্টারটি কেবলমাত্র ফাংশন কলের অভ্যন্তরে ডি-রেফারেন্সড হয় না the
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // নিরাপদ: উপরের মত।
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ধার করা তথ্যের বিভিন্ন উপাদানগুলির জন্য এক `RefMut` একাধিক `রেফমেটসগুলিতে বিভক্ত করে।
    ///
    /// অন্তর্নিহিত `RefCell` উভয় প্রত্যাবর্তন `রেফমেটসের সুযোগের বাইরে চলে যাওয়া অবধি পারস্পরিক bণ নেওয়া থাকবে।
    ///
    /// `RefCell` ইতিমধ্যে পারস্পরিক orrowণ নেওয়া হয়েছে, সুতরাং এটি ব্যর্থ হতে পারে না।
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `RefMut::map_split(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// অন্তর্নিহিত ডেটাতে পরিবর্তনীয় রেফারেন্সে রূপান্তর করুন।
    ///
    /// অন্তর্নিহিত `RefCell` আবার orrowণ নেওয়া যাবে না এবং সর্বদা ইতোমধ্যে পারস্পরিকভাবে ধার করা উপস্থিত হবে, প্রত্যাবর্তিত রেফারেন্সটি কেবলমাত্র অভ্যন্তর হিসাবে তৈরি করে।
    ///
    ///
    /// এটি একটি সম্পর্কিত ফাংশন যা `RefMut::leak(...)` হিসাবে ব্যবহার করা দরকার।
    /// কোনও পদ্ধতি `Deref` এর মাধ্যমে ব্যবহৃত `RefCell` এর সামগ্রীগুলিতে একই নামের পদ্ধতিগুলিতে হস্তক্ষেপ করবে।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // এই বোরআরফমটকে ভুলে গিয়ে আমরা নিশ্চিত করেছি যে রেফসেল-এ .ণ কাউন্টার আজীবন `'b` এর মধ্যে পুনরায় ব্যবহার করা যাবে না।
        // রেফারেন্স ট্র্যাকিংয়ের স্থিতি পুনরায় সেট করার জন্য ধার করা রেফসিলের অনন্য রেফারেন্সের প্রয়োজন হবে।
        // সেই জীবদ্দশায় মূল কক্ষ থেকে আর কোনও রেফারেন্স তৈরি করা যায় না, বর্তমান orrowণকে অবশিষ্ট আজীবনের একমাত্র রেফারেন্স করে তোলে।
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: এক্স 100 এক্সের বিপরীতে, প্রাথমিকটি তৈরি করতে নতুনকে ডাকা হয়
        // পরিবর্তনীয় রেফারেন্স এবং সুতরাং বর্তমানে কোনও বিদ্যমান রেফারেন্স থাকতে হবে।
        // সুতরাং, ক্লোন ক্রমবর্ধমান পরিবর্তনীয় পুনঃনির্ধারণের সময়, আমরা এখানে কেবল স্পষ্টভাবে কেবল ইউএসএসইড থেকে ইউএসএসইডে যাওয়ার অনুমতি দিই, ১।
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ক্লোনস একটি এক্স 100 এক্স।
    //
    // এটি কেবলমাত্র বৈধ যদি প্রতিটি `BorrowRefMut` মূল অবজেক্টের একটি স্বতন্ত্র, ননওভারল্যাপিংয়ের পরিসরের পরিবর্তিত রেফারেন্স ট্র্যাক করতে ব্যবহৃত হয়।
    //
    // এটি কোনও ক্লোন ইমপ্লিতে নেই যাতে কোডটি এটিকে স্পষ্টভাবে কল না করে।
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Counterণদানের কাউন্টারটিকে প্রবাহিত থেকে আটকাবেন from
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// একটি `RefCell<T>` থেকে পারস্পরিকভাবে ধার করা মানের জন্য একটি মোড়কের ধরণ।
///
/// আরও জন্য [module-level documentation](self) দেখুন।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// জেড 0 রিস্ট0 জেডে অভ্যন্তরীণ পরিবর্তনের জন্য মূল আদিম।
///
/// আপনার যদি একটি রেফারেন্স `&T` থাকে, তবে সাধারণত Rust এ সংকলক জ্ঞানের উপর ভিত্তি করে অপ্টিমাইজেশানগুলি সম্পাদন করে যা `&T` স্থায়ী ডেটাতে নির্দেশ করে।উদাহরণস্বরূপ একটি উপাত্তের মাধ্যমে বা একটি `&T` কে একটি এক্স01 এক্সে রূপান্তরিত করে সেই ডেটাটি রূপান্তর করা অনির্ধারিত আচরণ হিসাবে বিবেচিত হয়।
/// `UnsafeCell<T>` এক্স01 এক্সের অপরিবর্তনীয় গ্যারান্টিটি অপ্ট-আউট: একটি ভাগ করা রেফারেন্স `&UnsafeCell<T>` এমন ডেটাতে নির্দেশ করতে পারে যা রূপান্তরিত হচ্ছে।একে "interior mutability" বলা হয়।
///
/// অন্যান্য সমস্ত ধরণের যা `Cell<T>` এবং `RefCell<T>` এর মতো অভ্যন্তরীণ পরিবর্তনের অনুমতি দেয়, তাদের ডেটা মোড়ানোর জন্য অভ্যন্তরীণভাবে `UnsafeCell` ব্যবহার করে।
///
/// মনে রাখবেন যে ভাগ করা রেফারেন্সগুলির জন্য কেবলমাত্র অপরিবর্তনীয় গ্যারান্টিটি `UnsafeCell` দ্বারা প্রভাবিত হয়।পরিবর্তনীয় রেফারেন্সগুলির স্বতন্ত্রতা গ্যারান্টিটি প্রভাবিত নয়।এলিয়াসিং এক্স02 এক্স পাওয়ার *কোনও* আইনী উপায় নেই, এমনকি `UnsafeCell<T>` এর সাথেও নয়।
///
/// এক্স01 এক্স এপিআই নিজেই প্রযুক্তিগতভাবে খুব সহজ: এক্স 100 এক্স আপনাকে এর সামগ্রীতে একটি কাঁচা পয়েন্টার `*mut T` দেয়।সেই কাঁচা পয়েন্টারটি সঠিকভাবে ব্যবহার করতে বিমূর্ততা ডিজাইনার হিসাবে এটি _you_ অবধি।
///
/// [`.get()`]: `UnsafeCell::get`
///
/// সুনির্দিষ্ট Rust আলিয়াজিং বিধিগুলি কিছুটা প্রবাহে রয়েছে তবে মূল বিষয়গুলি বিতর্কিত নয়:
///
/// - আপনি যদি আজীবন `'a` (কোনও `&T` বা `&mut T` রেফারেন্স) সহ নিরাপদ রেফারেন্স তৈরি করেন যা নিরাপদ কোড দ্বারা অ্যাক্সেসযোগ্য (উদাহরণস্বরূপ, আপনি এটি ফিরিয়ে দিয়েছেন), তবে আপনাকে অবশ্যই সেই তথ্যটি কোনওভাবেই অ্যাক্সেস করতে হবে না যা বাকী অংশের জন্য সেই রেফারেন্সের সাথে বিরোধী ts `'a` এর।
/// উদাহরণস্বরূপ, এর অর্থ এই যে আপনি যদি `*mut T` কে `UnsafeCell<T>` থেকে নিয়ে `&T` X এ ফেলে দেন তবে রেফারেন্সটির আজীবনের মেয়াদ শেষ না হওয়া অবধি `T` এর ডেটা অবশ্যই অপরিবর্তিত থাকতে হবে (অবশ্যই `T` এর মধ্যে পাওয়া কোনও `UnsafeCell` ডেটা অবশ্যই)।
/// একইভাবে, আপনি যদি কোনও `&mut T` রেফারেন্স তৈরি করেন যা নিরাপদ কোডে প্রকাশিত হয়, তবে আপনাকে অবশ্যই রেফারেন্সের মেয়াদ শেষ না হওয়া পর্যন্ত `UnsafeCell` এর মধ্যে থাকা ডেটা অ্যাক্সেস করতে হবে না।
///
/// - সর্বদা, আপনাকে অবশ্যই ডেটা রেস এড়িয়ে চলতে হবে।যদি একাধিক থ্রেডে একই `UnsafeCell` এ অ্যাক্সেস থাকে তবে অন্য যে কোনও অ্যাক্সেসের সাথে (বা অ্যাটমিক্স ব্যবহার করতে পারেন) এর আগে কোনও লেখকের অবশ্যই একটি যথাযথ ঘটতে হবে।
///
/// যথাযথ ডিজাইনে সহায়তা করার জন্য, নিম্নোক্ত দৃশ্যগুলি স্পষ্টভাবে একক থ্রেডযুক্ত কোডের জন্য আইনী ঘোষণা করা হয়েছে:
///
/// 1. একটি `&T` রেফারেন্সটি নিরাপদ কোডে প্রকাশ করা যেতে পারে এবং সেখানে এটি অন্যান্য `&T` রেফারেন্সের সাথে সহাবস্থান করতে পারে, তবে কোনও `&mut T` এর সাথে নয় not
///
/// 2. কোনও এক্স 100 এক্স রেফারেন্স নিরাপদ কোডে প্রকাশিত হতে পারে তবে এর সাথে অন্য কোনও এক্স01 এক্স বা এক্স02 এক্স সহ-উপস্থিত নেই।একটি এক্স0৩ এক্স অবশ্যই সর্বদা অনন্য থাকতে হবে।
///
/// দ্রষ্টব্য যে কোনও `&UnsafeCell<T>` এর সামগ্রীগুলি পরিবর্তন করতে (অন্য `&UnsafeCell<T>` রেফারেন্স ওরফে সেলটি থাকা সত্ত্বেও) ঠিক আছে (আপনি যদি উপরোক্ত আক্রমণকারীদের অন্য কোনও উপায়ে প্রয়োগ করেন) তবে একাধিক `&mut UnsafeCell<T>` এলিয়াস থাকা এখনও অপরিজ্ঞাত আচরণ।
/// অর্থাৎ, `UnsafeCell` একটি মোড়ক যা একটি _shared_ accesses (_i.e._ রেফারেন্সের মাধ্যমে _shared_ accesses (_i.e._ এর সাথে একটি বিশেষ ইন্টারঅ্যাকশন করার জন্য ডিজাইন করা হয়েছে);_exclusive_ accesses (_e.g._ এর সাথে `&mut UnsafeCell<_>` এর মাধ্যমে লেনদেন করার সময় কোনও ম্যাজিক নেই)) `&mut` orrowণের সময়কালের জন্য কক্ষ বা মোড়কযুক্ত মান দুটিই আলাদা করা যাবে না।
///
/// এটি [`.get_mut()`] অ্যাক্সেসর দ্বারা প্রদর্শিত হয়েছে, যা একটি _safe_ getter যা একটি `&mut T` দেয়।
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// এখানে সেল একাধিক রেফারেন্স থাকা সত্ত্বেও কীভাবে `UnsafeCell<_>` এর বিষয়বস্তুগুলিকে সাবলীল রূপান্তর করা যায় তার একটি উদাহরণ এখানে দেওয়া হয়েছে:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // একই `x` এ একাধিক/সমবর্তী/ভাগ করা রেফারেন্স পান।
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // নিরাপদ: এই সুযোগের মধ্যে `x` এর বিষয়বস্তুর সাথে অন্য কোনও উল্লেখ নেই,
///     // সুতরাং আমাদের কার্যকরভাবে অনন্য।
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ধার-+
///     *p1_exclusive += 27; // |
/// } // <---------- এই বিন্দু অতিক্রম করতে পারে না -------------------+
///
/// unsafe {
///     // সুরক্ষা: এই সুযোগের মধ্যে কেউ `x` এর সামগ্রীতে একচেটিয়া অ্যাক্সেসের আশা করে না,
///     // যাতে আমরা একসাথে একাধিক ভাগ অ্যাক্সেস পেতে পারি।
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// নিম্নলিখিত উদাহরণটি `UnsafeCell<T>` এক্সক্লুসিভ অ্যাক্সেস তার `T` এক্সক্লুসিভ অ্যাক্সেস বোঝায় যে সত্যটি প্রদর্শন করে:
///
/// ```rust
/// #![forbid(unsafe_code)] // একচেটিয়া অ্যাক্সেস সহ,
///                         // `UnsafeCell` হ'ল একটি স্বচ্ছ নো-ওপ মোড়ক, সুতরাং এখানে `unsafe` দরকার নেই।
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` এর একটি সংকলন-সময়-পরীক্ষিত অনন্য রেফারেন্স পান Get
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // একচেটিয়া রেফারেন্স সহ, আমরা নিখরচায় সামগ্রীগুলি পরিবর্তন করতে পারি ate
/// *p_unique.get_mut() = 0;
/// // বা, সমতুল্য:
/// x = UnsafeCell::new(0);
///
/// // যখন আমরা মানটির মালিক হই, আমরা নিখরচায় সামগ্রীগুলি বের করতে পারি।
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` এর একটি নতুন উদাহরণ তৈরি করে যা নির্দিষ্ট মানটি মোড়বে।
    ///
    ///
    /// পদ্ধতির মাধ্যমে অভ্যন্তরীণ মানটিতে সমস্ত অ্যাক্সেস `unsafe` X
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// মান আনপ্রেস করে।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// মোড়ানো মানটিতে একটি পরিবর্তনীয় পয়েন্টার পায়।
    ///
    /// এটি কোনও ধরণের পয়েন্টারে কাস্ট করা যেতে পারে।
    /// এক্স01 এক্সে কাস্টিংয়ের সময় অ্যাক্সেসটি অনন্য (কোনও সক্রিয় রেফারেন্স, পরিবর্তনীয় বা না) তা নিশ্চিত করুন এবং `&T` এ কাস্ট করার সময় কোনও রূপান্তর বা মিউটেটেবল এলিয়াস চলছে না তা নিশ্চিত করুন
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] এর কারণে আমরা কেবলমাত্র `UnsafeCell<T>` থেকে `T` এ পয়েন্টারটি কাস্ট করতে পারি।
        // এটি লিবিস্টডির বিশেষ স্থিতিটি ব্যবহার করে, ব্যবহারকারীর কোডের কোনও গ্যারান্টি নেই যে এটি কম্পাইলারের জেড0 ফিউচার0 জেড সংস্করণে কাজ করবে!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// অন্তর্নিহিত ডেটাতে একটি পরিবর্তনীয় রেফারেন্স প্রদান করে।
    ///
    /// এই কলটি `UnsafeCell` পারস্পরিকভাবে ধার করেছে (সংকলন সময়ে) যা গ্যারান্টি দেয় যে আমাদের একমাত্র রেফারেন্স রয়েছে possess
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// মোড়ানো মানটিতে একটি পরিবর্তনীয় পয়েন্টার পায়।
    /// [`get`] এর পার্থক্য হ'ল এই ফাংশনটি একটি কাঁচা পয়েন্টার গ্রহণ করে, যা অস্থায়ী রেফারেন্সগুলি তৈরি এড়াতে কার্যকর।
    ///
    /// ফলাফলটি কোনও ধরণের পয়েন্টারে ফেলে দেওয়া যেতে পারে।
    /// এক্স01 এক্সে কাস্টিংয়ের সময় অ্যাক্সেসটি অনন্য (কোনও সক্রিয় রেফারেন্স, পরিবর্তনীয় বা না) নিশ্চিত করুন এবং এক্স00 এক্সে কাস্টিংয়ের সময় কোনও মিউটেশন বা মিউটটেবল এলিয়াস চলছে না তা নিশ্চিত করুন।
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` এর ধীরে ধীরে প্রারম্ভিককরণের জন্য `raw_get` প্রয়োজন, কারণ `get` কল করার জন্য অস্বীকারহীন ডেটাতে একটি রেফারেন্স তৈরি করা প্রয়োজন:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] এর কারণে আমরা কেবলমাত্র `UnsafeCell<T>` থেকে `T` এ পয়েন্টারটি কাস্ট করতে পারি।
        // এটি লিবিস্টডির বিশেষ স্থিতিটি ব্যবহার করে, ব্যবহারকারীর কোডের কোনও গ্যারান্টি নেই যে এটি কম্পাইলারের জেড0 ফিউচার0 জেড সংস্করণে কাজ করবে!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// টি-এর জন্য `Default` মান সহ একটি `UnsafeCell` তৈরি করে
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}