//! ধরণের মধ্যে রূপান্তরের জন্য Traits।
//!
//! এই মডিউলের traits এক ধরণের থেকে অন্য ধরণের রূপান্তর করার একটি উপায় সরবরাহ করে।
//! প্রতিটি trait আলাদা উদ্দেশ্যে কাজ করে:
//!
//! - সস্তা রেফারেন্স থেকে রেফারেন্স রূপান্তরগুলির জন্য [`AsRef`] trait বাস্তবায়ন করুন
//! - সস্তার মিউটেবল-টু-মিউটেবল রূপান্তরগুলির জন্য [`AsMut`] trait বাস্তবায়ন করুন
//! - মান-থেকে-মান রূপান্তর গ্রহণের জন্য [`From`] trait প্রয়োগ করুন
//! - বর্তমান crate এর বাইরে ধরণের মান থেকে মূল্য রূপান্তর গ্রহণের জন্য [`Into`] trait প্রয়োগ করুন
//! - [`TryFrom`] এবং [`TryInto`] traits [`From`] এবং [`Into`] এর মতো আচরণ করে, তবে রূপান্তরটি ব্যর্থ হতে পারে তবে প্রয়োগ করা উচিত।
//!
//! এই মডিউলের traits প্রায়শই জেনেরিক ফাংশনগুলির জন্য trait bounds হিসাবে ব্যবহৃত হয় যেমন একাধিক ধরণের আর্গুমেন্ট সমর্থিত।উদাহরণস্বরূপ প্রতিটি trait এর ডকুমেন্টেশন দেখুন।
//!
//! লাইব্রেরির লেখক হিসাবে, আপনার সর্বদা [`Into<U>`][`Into`] বা [`TryInto<U>`][`TryInto`] এর পরিবর্তে [`From<T>`][`From`] বা [`TryFrom<T>`][`TryFrom`] প্রয়োগ করা পছন্দ করা উচিত, কারণ [`From`] এবং [`TryFrom`] বৃহত্তর নমনীয়তা সরবরাহ করে এবং প্রমিত লাইব্রেরিতে একটি কম্বল বাস্তবায়নের জন্য সমানভাবে [`Into`] বা [`TryInto`] বাস্তবায়ন প্রস্তাব করে।
//! Rust 1.41 এর আগে কোনও সংস্করণ লক্ষ্য করার সময়, বর্তমান crate এর বাইরে কোনও ধরণের রূপান্তর করার সময় সরাসরি [`Into`] বা [`TryInto`] প্রয়োগ করা প্রয়োজন।
//!
//! # জেনেরিক বাস্তবায়ন
//!
//! - [`AsRef`] অভ্যন্তরীণ প্রকারটি যদি কোনও রেফারেন্স হয় তবে [`AsMut`] অটো-ডিসিফারেন্স
//! - [`From`]`এর <U>জন্য [`ইন্ট`]` বোঝায় `</u><T><U>ইউ এর জন্য</u>
//! - [`ট্রাইফ্রোম`]`এর <U>জন্য [`ট্রায়িন্টো] lies বোঝায়`</u><T><U>ইউ এর জন্য</u>
//! - [`From`] এবং এক্স 100 এক্স রিফ্লেক্সিভ, যার অর্থ সমস্ত প্রকারগুলি নিজেরাই `into` করতে পারে এবং নিজেরাই `from` করতে পারে
//!
//! ব্যবহারের উদাহরণগুলির জন্য প্রতিটি trait দেখুন।
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// পরিচয় ফাংশন।
///
/// এই ফাংশনটি সম্পর্কে দুটি বিষয় লক্ষ্য করা গুরুত্বপূর্ণ:
///
/// - এটি সর্বদা `|x| x` এর মতো বন্ধের সমতুল্য নয়, যেহেতু বন্ধটি `x` কে অন্য ধরণের আকারে বাধ্য করতে পারে।
///
/// - এটি ইনপুট এক্স00 এক্সকে ফাংশনে স্থানান্তরিত করে।
///
/// যদিও কোনও ফাংশনটি আশ্চর্যজনক বলে মনে হতে পারে যা কেবল ইনপুটটি ফিরিয়ে দেয়, কিছু আকর্ষণীয় ব্যবহার রয়েছে।
///
///
/// # Examples
///
/// অন্যান্য, আকর্ষণীয়, ক্রিয়াকলাপগুলির ক্রমানুসারে কিছুই না করার জন্য `identity` ব্যবহার করা:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // আসুন ভান করি যে একটি যুক্ত করা একটি আকর্ষণীয় ফাংশন।
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// শর্তসাপেক্ষে `identity` কে "do nothing" বেস কেস হিসাবে ব্যবহার করা:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // আরও আকর্ষণীয় জিনিস করুন ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` এর পুনরাবৃত্তির `Some` ভেরিয়েন্টগুলি রাখতে `identity` ব্যবহার করে:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// সস্তা রেফারেন্স থেকে রেফারেন্স রূপান্তর করতে ব্যবহৃত হয়েছিল।
///
/// এই trait [`AsMut`] এর অনুরূপ যা পরিবর্তনীয় রেফারেন্সগুলির মধ্যে রূপান্তর করার জন্য ব্যবহৃত হয়।
/// আপনার যদি ব্যয়বহুল রূপান্তর করতে হয় তবে `&T` টাইপ সহ [`From`] প্রয়োগ করা বা একটি কাস্টম ফাংশন লিখাই ভাল।
///
/// `AsRef` [`Borrow`] এর মতো একই স্বাক্ষর রয়েছে তবে কয়েকটি দিক থেকে [`Borrow`] আলাদা:
///
/// - `AsRef` এর বিপরীতে, [`Borrow`] এর যে কোনও এক্স01 এক্সের জন্য একটি কম্বল ইমপ্লি রয়েছে এবং এটি কোনও রেফারেন্স বা মান গ্রহণ করতে ব্যবহৃত হতে পারে।
/// - [`Borrow`] এছাড়াও নেওয়া দরকার যে ধার নেওয়া মূল্যের জন্য [`Hash`], [`Eq`] এবং [`Ord`] এর মালিকানাধীন মানের সমান।
/// এই কারণে, আপনি যদি কোনও কাঠামোর একক ক্ষেত্র orrowণ নিতে চান তবে আপনি `AsRef` বাস্তবায়ন করতে পারবেন, তবে [`Borrow`] নয়।
///
/// **Note: এই trait অবশ্যই ব্যর্থ হবে না **।যদি রূপান্তর ব্যর্থ হতে পারে তবে একটি উত্সর্গীকৃত পদ্ধতি ব্যবহার করুন যা একটি [`Option<T>`] বা একটি [`Result<T, E>`] প্রদান করে।
///
/// # জেনেরিক বাস্তবায়ন
///
/// - `AsRef` অভ্যন্তরীণ প্রকারটি যদি কোনও রেফারেন্স বা কোনও পরিবর্তনীয় রেফারেন্স হয় তবে অটো-ডিসিফারেন্স (যেমন: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ব্যবহার করে আমরা বিভিন্ন ধরণের আর্গুমেন্ট গ্রহণ করতে পারি যতক্ষণ না তারা নির্দিষ্ট ধরণের `T` এ রূপান্তরিত হতে পারে accept
///
/// উদাহরণস্বরূপ: একটি জেনেরিক ফাংশন তৈরি করে যা একটি `AsRef<str>` নেয় আমরা প্রকাশ করি যে আমরা সমস্ত রেফারেন্সকে [`&str`] এ আর্গুমেন্ট হিসাবে রূপান্তর করতে পারি তা গ্রহণ করতে চাই।
/// [`String`] এবং [`&str`] উভয়ই `AsRef<str>` প্রয়োগ করে আমরা উভয়কে ইনপুট আর্গুমেন্ট হিসাবে গ্রহণ করতে পারি accept
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// রূপান্তর সম্পাদন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// একটি সস্তা পরিবর্তনযোগ্য-থেকে-পরিবর্তনযোগ্য রেফারেন্স রূপান্তর করতে ব্যবহৃত হয়েছিল।
///
/// এই trait [`AsRef`] এর অনুরূপ তবে পরিবর্তনীয় রেফারেন্সগুলির মধ্যে রূপান্তর করার জন্য ব্যবহৃত হয়।
/// আপনার যদি ব্যয়বহুল রূপান্তর করতে হয় তবে `&mut T` টাইপ সহ [`From`] প্রয়োগ করা বা একটি কাস্টম ফাংশন লিখাই ভাল।
///
/// **Note: এই trait অবশ্যই ব্যর্থ হবে না **।যদি রূপান্তর ব্যর্থ হতে পারে তবে একটি উত্সর্গীকৃত পদ্ধতি ব্যবহার করুন যা একটি [`Option<T>`] বা একটি [`Result<T, E>`] প্রদান করে।
///
/// # জেনেরিক বাস্তবায়ন
///
/// - `AsMut` অভ্যন্তরীণ প্রকারটি যদি পারস্পরিক পরিবর্তনযোগ্য রেফারেন্স হয় তবে অটো-ডিসিফারেন্সগুলি (যেমন: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// জেনেরিক ফাংশনের জন্য `AsMut` কে trait bound হিসাবে ব্যবহার করে আমরা সমস্ত পরিবর্তনীয় রেফারেন্স গ্রহণ করতে পারি যা `&mut T` টাইপে রূপান্তরিত হতে পারে।
/// কারণ [`Box<T>`] `AsMut<T>` প্রয়োগ করে আমরা একটি ফাংশন `add_one` লিখতে পারি যা `&mut u64` এ রূপান্তরিত হতে পারে এমন সমস্ত আর্গুমেন্ট নেয়।
/// [`Box<T>`] `AsMut<T>` প্রয়োগ করে, `add_one` এছাড়াও `&mut Box<u64>` প্রকারের আর্গুমেন্ট গ্রহণ করে:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// রূপান্তর সম্পাদন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// একটি মান থেকে মান রূপান্তর যা ইনপুট মানটি গ্রাস করে।[`From`] এর বিপরীত।
///
/// [`Into`] বাস্তবায়ন এড়াতে হবে এবং এর পরিবর্তে [`From`] প্রয়োগ করা উচিত।
/// এক্স00 এক্স প্রয়োগ করা স্বয়ংক্রিয়ভাবে স্ট্যান্ডার্ড লাইব্রেরিতে কম্বল বাস্তবায়নের জন্য [`Into`] একটি বাস্তবায়ন সরবরাহ করে।
///
/// জেনেরিক ফাংশনে trait bounds উল্লেখ করার সময় [`Into`] এর ওপরে [`Into`] ব্যবহার করতে পছন্দ করুন যাতে কেবলমাত্র [`Into`] প্রয়োগ করা যায় এমন ধরণেরগুলিও ব্যবহার করা যায় তা নিশ্চিত করে।
///
/// **Note: এই trait অবশ্যই ব্যর্থ হবে না **।যদি রূপান্তরটি ব্যর্থ হতে পারে তবে [`TryInto`] ব্যবহার করুন।
///
/// # জেনেরিক বাস্তবায়ন
///
/// - [`থেকে`]`<T>U` এর জন্য `Into<U> for T` বোঝায়
/// - [`Into`] প্রতিচ্ছবি, যার অর্থ `Into<T> for T` বাস্তবায়িত হয়েছে
///
/// # Rust এর পুরানো সংস্করণগুলিতে বাহ্যিক ধরণের রূপান্তরগুলির জন্য [`Into`] প্রয়োগ করা
///
/// Rust 1.41 এর আগে, গন্তব্য প্রকারটি যদি বর্তমান জেড 0crate0Z এর অংশ না হয় তবে আপনি সরাসরি [`From`] প্রয়োগ করতে পারবেন না।
/// উদাহরণস্বরূপ, এই কোডটি নিন:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// এটি ভাষার পুরানো সংস্করণগুলিতে সংকলন করতে ব্যর্থ হবে কারণ Rust এর অনাথ বিধিগুলি আরও কিছুটা কঠোর হতে পারে।
/// এটি বাইপাস করতে, আপনি সরাসরি [`Into`] বাস্তবায়ন করতে পারেন:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// এটি বুঝতে গুরুত্বপূর্ণ যে [`Into`] একটি [`From`] বাস্তবায়ন সরবরাহ করে না ([`From`] [`Into`] এর সাথে যেমন করে)।
/// সুতরাং, আপনার সর্বদা [`From`] বাস্তবায়নের চেষ্টা করা উচিত এবং যদি [`From`] বাস্তবায়িত না করা যায় তবে [`Into`] এ ফিরে আসুন।
///
/// # Examples
///
/// [`String`] প্রয়োগসমূহ [`ইন্টু]` <`[` ভেক]] `<` [`u8`]`>>`:
///
/// আমরা যে জেনেরিক ফাংশনটি নির্দিষ্ট ধরণের `T` এ রূপান্তর করতে পারি তার সমস্ত যুক্তি নিতে চাই তা প্রকাশ করার জন্য, আমরা [`অন্তর]` এর একটি trait bound ব্যবহার করতে পারি<T>।
///
/// উদাহরণস্বরূপ: ফাংশন `is_hello` সমস্ত যুক্তি গ্রহণ করে যা একটি [`ভিসি]` <`[` u8`]`>`এ রূপান্তর করতে পারে`
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// রূপান্তর সম্পাদন করে।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ইনপুট মানটি গ্রহণ করার সময় মান থেকে মান রূপান্তর করতে ব্যবহৃত হয়।এটি [`Into`] এর পারস্পরিক কাজ।
///
/// [`Into`] এর চেয়ে বেশি `From` X প্রয়োগ করা পছন্দ করা উচিত কারণ `From` প্রয়োগ করা স্বয়ংক্রিয়ভাবে [`Into`] বাস্তবায়নের সাথে স্ট্যান্ডার্ড লাইব্রেরিতে কম্বল বাস্তবায়নের জন্য উপলব্ধ করে।
///
///
/// Rust 1.41 এর পূর্বে কোনও সংস্করণ লক্ষ্য করে এবং বর্তমান জেড 0 ক্রেট 0 জেডের বাইরে কোনও ধরণের রূপান্তরিত করার সময় কেবলমাত্র [`Into`] প্রয়োগ করুন।
/// `From` Rust এর এতিম নিয়মের কারণে পূর্ববর্তী সংস্করণগুলিতে এই ধরণের রূপান্তর করতে সক্ষম ছিল না।
/// আরও তথ্যের জন্য [`Into`] দেখুন।
///
/// জেনেরিক ফাংশনে trait bounds উল্লেখ করার সময় `From` ব্যবহার করে [`Into`] ব্যবহারকে পছন্দ করুন।
/// এইভাবে, প্রকারগুলি যেগুলি সরাসরি [`Into`] বাস্তবায়িত করে সেগুলি আর্গুমেন্ট হিসাবেও ব্যবহার করা যেতে পারে।
///
/// এক্স01 এক্স ত্রুটি পরিচালনা করার সময়ও খুব দরকারী।ব্যর্থ করতে সক্ষম এমন কোনও ফাংশন নির্মাণ করার সময়, রিটার্ন টাইপটি সাধারণত `Result<T, E>` ফর্মের হয়ে থাকে।
/// `From` trait একাধিক ত্রুটি প্রকারের encapsulate যে একক ত্রুটি টাইপ ফাংশন ফাংশন অনুমতি দিয়ে ত্রুটি পরিচালনা পরিচালনা সহজতর করে।আরও তথ্যের জন্য "Examples" বিভাগ এবং [the book][book] দেখুন।
///
/// **Note: এই trait অবশ্যই ব্যর্থ হবে না **।যদি রূপান্তরটি ব্যর্থ হতে পারে তবে [`TryFrom`] ব্যবহার করুন।
///
/// # জেনেরিক বাস্তবায়ন
///
/// - `From<T> for U` T`এর <U>জন্য</u> [`In``] <U>imp বোঝায়`</u>
/// - `From` প্রতিচ্ছবি, যার অর্থ `From<T> for T` বাস্তবায়িত হয়েছে
///
/// # Examples
///
/// [`String`] এক্স 100 এক্স প্রয়োগ করে:
///
/// একটি `&str` থেকে একটি স্ট্রিংয়ে স্পষ্ট রূপান্তরটি এইভাবে করা হয়েছে:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ত্রুটি পরিচালনার সময় এটি আপনার নিজের ত্রুটি ধরণের জন্য প্রায়শই `From` প্রয়োগ করা কার্যকর।
/// অন্তর্নিহিত ত্রুটি প্রকারকে আমাদের নিজস্ব কাস্টম ত্রুটি টাইপকে রূপান্তর করে অন্তর্নিহিত ত্রুটি প্রকারগুলিকে রূপান্তর করে আমরা অন্তর্নিহিত কারণগুলির তথ্য না হারিয়ে একক ত্রুটি প্রকারটি ফিরিয়ে দিতে পারি।
/// '?' অপারেটরটি স্বয়ংক্রিয়ভাবে অন্তর্নিহিত ত্রুটি ধরণেরটি `Into<CliError>::into` কল করে আমাদের কাস্টম ত্রুটি প্রকারে রূপান্তর করে যা `From` বাস্তবায়নের সময় স্বয়ংক্রিয়ভাবে সরবরাহ করা হয়।
/// সংকলকটি তখন অনুমান করে যে `Into` এর বাস্তবায়নটি ব্যবহার করা উচিত।
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// রূপান্তর সম্পাদন করে।
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// একটি চেষ্টা করা রূপান্তর যা `self` গ্রাস করে, যা ব্যয়বহুল বা নাও হতে পারে।
///
/// গ্রন্থাগারের লেখকরা সাধারণত এই trait সরাসরি প্রয়োগ করা উচিত নয়, তবে এটি [`TryFrom`] trait বাস্তবায়ন করা উচিত, যা আরও বেশি নমনীয়তা সরবরাহ করে এবং বিনামূল্যে লাইব্রেরিতে কম্বল বাস্তবায়নের জন্য ধন্যবাদ একটি সমতুল্য `TryInto` বাস্তবায়ন সরবরাহ করে।
/// এটি সম্পর্কে আরও তথ্যের জন্য, [`Into`] এর জন্য ডকুমেন্টেশন দেখুন।
///
/// # এক্স 100 এক্স প্রয়োগ করা হচ্ছে
///
/// এটি [`Into`] বাস্তবায়ন হিসাবে একই বিধিনিষেধ এবং যুক্তি ভোগ করে, বিশদ জন্য এখানে দেখুন।
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// রূপান্তর ত্রুটির ঘটনায় টাইপটি ফিরে আসল।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// রূপান্তর সম্পাদন করে।
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// সাধারণ এবং নিরাপদ প্রকার রূপান্তর যা কিছু পরিস্থিতিতে নিয়ন্ত্রিত উপায়ে ব্যর্থ হতে পারে।এটি [`TryInto`] এর পারস্পরিক কাজ।
///
/// আপনি যখন এমন ধরণের রূপান্তর করছেন যা তুচ্ছভাবে সফল হতে পারে তবে বিশেষ হ্যান্ডলিংয়ের প্রয়োজনও পড়তে পারে এটি কার্যকর।
/// উদাহরণস্বরূপ, [`From`] trait ব্যবহার করে একটি [`i64`] কে [`i32`] রূপান্তর করার কোনও উপায় নেই, কারণ একটি [`i64`] এর এমন কোনও মান থাকতে পারে যা একটি [`i32`] প্রতিনিধিত্ব করতে পারে না এবং তাই রূপান্তরটি ডেটা হারাতে পারে।
///
/// এটি [`i64`] কে [`i32`] (মূলত [`i64`] এর মান মডুলো [`i32::MAX`] প্রদান করে) বা কেবল [`i32::MAX`] ফিরিয়ে দিয়ে বা অন্য কোনও পদ্ধতি দ্বারা পরিচালিত হতে পারে।
/// [`From`] trait নিখুঁত রূপান্তরগুলির জন্য তৈরি, সুতরাং `TryFrom` trait প্রোগ্রামারকে অবহিত করে যখন কোনও ধরণের রূপান্তর খারাপ হতে পারে এবং কীভাবে এটি পরিচালনা করবেন তা সিদ্ধান্ত নিতে দেয়।
///
/// # জেনেরিক বাস্তবায়ন
///
/// - `TryFrom<T> for U` T`এর <U>জন্য</u> [`TryInto`] <U>imp বোঝায়`</u>
/// - [`try_from`] রিফ্লেক্সিভ, যার অর্থ `TryFrom<T> for T` বাস্তবায়িত হয়েছে এবং ব্যর্থ হতে পারে না-`T` টাইপের মানতে `T::try_from()` কল করার জন্য সম্পর্কিত `Error` প্রকারটি হল [`Infallible`] is
/// যখন [`!`] প্রকারটি [`Infallible`] স্থিতিশীল করা হয় এবং [`!`] সমতুল্য হয়।
///
/// `TryFrom<T>` নিম্নলিখিত হিসাবে প্রয়োগ করা যেতে পারে:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// বর্ণিত হিসাবে, [`i32`] বাস্তবায়ন করে `ট্রাইফর্ম <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // নিঃশব্দে `big_number` কে ছাঁটাই করে, সত্যের পরে ছাঁটাই সনাক্তকরণ এবং পরিচালনা করা প্রয়োজন।
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // একটি ত্রুটি ফিরিয়ে দেয় কারণ `big_number` একটি এক্স 100 এক্সে ফিট করার জন্য খুব বড়।
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // এক্স 100 এক্স প্রদান করে।
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// রূপান্তর ত্রুটির ঘটনায় টাইপটি ফিরে আসল।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// রূপান্তর সম্পাদন করে।
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// জেনেরিক আইএমপিএল
////////////////////////////////////////////////////////////////////////////////

// উপরের লিফট হিসাবে&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// হিসাবে &mut উপরের লিফট
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut এর জন্য উপরের ইমপ্লিকে নিম্নলিখিত আরও সাধারণের সাথে প্রতিস্থাপন করুন:
// // যেমনটি ডেরেফের উপরে উঠেছে
// impl <D: ?Sized + Deref<Target: AsRef<U>>, ইউ:? <U>আকারযুক্ত> ডিফোন এক্স00 এক্স-> এক্স01 এক্স As</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut এর উপরে উত্তোলন করে
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): নিম্নলিখিত আরও সাধারণের সাথে এক্স01 এক্সের জন্য উপরের ইমপ্লিটটি প্রতিস্থাপন করুন:
// // AsMut DerefMut-এর উপরে তুলে দেয়
// impl <D: ?Sized + Deref<Target: AsMut<U>>, ইউ:? <U>আকারযুক্ত> এসফট এক্স ফ্যাক্স এক্স00 এক্স-> এক্স01 এক্স ইউ for</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// অন্তর্নিহিত থেকে
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// থেকে (এবং এইভাবে) প্রতিবিম্বিত হয়
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **স্থায়িত্ব নোট:** এই ইমপেলটি এখনও বিদ্যমান নেই, তবে আমরা এটি future এ যুক্ত করতে "reserving space" are
/// বিশদ জানতে এক্স00 এক্স দেখুন।
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): পরিবর্তে একটি মূলত ঠিক করুন।
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ট্রাইফ্রোম বোঝায় ট্রায়ইন্টো
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// অবিচ্ছিন্ন রূপান্তরগুলি নির্বাসিত ত্রুটির ধরণের সাথে মিথ্যা রূপান্তরগুলির সমার্থক সমান।
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// আইএমপিএল কনক্রিট করুন
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// কোন ভুল ত্রুটি ভুল টাইপ
////////////////////////////////////////////////////////////////////////////////

/// ত্রুটিগুলির জন্য ত্রুটির ধরণ যা কখনও ঘটতে পারে না।
///
/// যেহেতু এই এনামের কোনও বৈকল্প নেই, এই ধরণের কোনও মান আসলেই থাকতে পারে না।
/// এটি জেনেরিক এপিআইগুলির জন্য কার্যকর হতে পারে যা [`Result`] ব্যবহার করে এবং ত্রুটি ধরণের প্যারামিটারাইজ করে, ফলাফলটি সর্বদা [`Ok`] থাকে তা বোঝাতে।
///
/// উদাহরণস্বরূপ, [`TryFrom`] trait (রূপান্তর যা একটি [`Result`] রিটার্ন করে) এমন সমস্ত ধরণের যেখানে একটি বিপরীত [`Into`] বাস্তবায়ন বিদ্যমান সেখানে একটি কম্বল বাস্তবায়ন রয়েছে।
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # জেডফিউচার0 জেড সামঞ্জস্য
///
/// এই এনামের [the `!`“never”type][never] এর মতো একই ভূমিকা রয়েছে যা Rust এর এই সংস্করণে অস্থির।
/// যখন `!` স্থিতিশীল হয়, তখন আমরা `Infallible` কে এটির জন্য টাইপ উপন্যাস করার পরিকল্পনা করি:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …এবং অবশেষে `Infallible` অবমূল্যায়ন করুন।
///
/// তবে একটি ক্ষেত্রে রয়েছে যে এক্স0 এক্স এক্স পূর্ণাঙ্গ ধরণের হিসাবে স্থিতিশীল হওয়ার আগে `!` সিনট্যাক্স ব্যবহার করা যেতে পারে: কোনও ফাংশনের রিটার্ন টাইপের অবস্থানে।
/// বিশেষত, এটি দুটি পৃথক ফাংশন পয়েন্টার ধরণের জন্য সম্ভব বাস্তবায়ন:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` একটি এনাম হওয়ার সাথে সাথে, এই কোডটি বৈধ।
/// তবে, যখন `Infallible` never type-এর একটি উপাধিতে পরিণত হবে, তখন দু'জনকেই ওভারল্যাপ করতে শুরু করবে এবং তাই ভাষার trait সংহতি বিধিমালা দ্বারা বঞ্চিত হবে।
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}