# `rustc-std-workspace-core` crate

crate ena ke crate e se nang letho ebile e se na letho e itšetlehileng feela ka `libcore` ebe e khutlisetsa litaba tsohle tsa eona ka hare.
crate ke crux ea ho matlafatsa laeborari e tloaelehileng ho itšetleha ka crates ho tloha crates.io

Crates ho crates.io hore laeborari e tloaelehileng e latela tlhoko ea ho itšetleha ka `rustc-std-workspace-core` crate ho tloha crates.io, e se nang letho.

Re sebelisa `[patch]` ho e fetisetsa ho crate sebakeng sena sa polokelo.
Ka lebaka leo, crates ho crates.io e tla hula edge e itšetlehileng ka `libcore`, mofuta o hlalositsoeng polokelong ena.
Seo se lokela ho hula likarolo tsohle tsa ts'epahalo ho netefatsa hore Cargo e aha crates ka katleho!

Hlokomela hore crates ho crates.io e hloka ho itšetleha ka crate ena e nang le lebitso `core` hore ntho e ngoe le e ngoe e sebetse hantle.Ho etsa seo ba ka se sebelisang:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ka ts'ebeliso ea senotlolo sa `package` crate e rehelloa lebitso la `core`, ho bolelang hore e tla shebahala

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ha Cargo e kopa moqapi, e khotsofatsa taelo e hlakileng ea `extern crate core` e kenngoeng ke motlatsi.




