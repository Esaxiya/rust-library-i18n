// rsbegin.o le rsend.o ke tsona tse bitsoang "compiler runtime startup objects".
// Li na le khoutu e hlokahalang ho qala ka nepo nako ea ho bokella.
//
// Ha setšoantšo se ka sebelisoang kapa sa dylib se hokahantsoe, likhoutu tsohle tsa mosebelisi le lilaebrari ke "sandwiched" lipakeng tsa lifaele tsena tse peli, ka hona khoutu kapa data e tsoang ho rsbegin.o e ba tsa pele likarolong tse fapaneng tsa setšoantšo, athe khoutu le data e tsoang ho rsend.o e ba tsa ho qetela.
// Phello ena e ka sebelisoa ho beha matšoao qalong kapa qetellong ea karolo, hape le ho kenya lihlooho kapa lihlooho tse hlokahalang.
//
// Hlokomela hore ntlha ea mantlha ea ho kena mojuleng e fumaneha ho ntho ea ho qalisa nako ea C ea runtime (eo hangata e bitsoang `crtX.o`), e ntan'o ts'oara likhatiso tsa ho qala tsa likarolo tse ling tsa nako ea ho matha (e ngolisitsoeng ka karolo e 'ngoe e khethehileng ea setšoantšo).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Matšoao a qalang a karolo ea lesela la ho phutholoha la foreimi
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Qala sebaka sa ho boloka libuka tse ka hare tsa unwinder.
    // Sena se hlalosoa e le `struct object` ho $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Sokolla lintlha tsa registration/deregistration.
    // Bona litokomane tsa libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ngodisa leseli la ho phomola qalong ea module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ngodisa ho tima
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Ngoliso e tloaelehileng ea XGUMX ea MinGW
    pub mod mingw_init {
        // Lintho tsa ho qala tsa MinGW (crt0.o/dllcrt0.o) li tla kopa lihahi tsa lefats'e ka likarolo tsa .ctors le .dtors ho qala le ho tsoa.
        // Tabeng ea li-DLL, sena se etsoa ha DLL e laoloa le ho laolloa.
        //
        // Linker e tla hlophisa likarolo, tse netefatsang hore li-callback tsa rona li fumaneha qetellong ea lenane.
        // Kaha lihahi li tsamaisoa ka tatellano e fapaneng, sena se tiisa hore li-callback tsa rona ke tsa pele le tsa hoqetela tse bolailoeng.
        //
        //

        #[link_section = ".ctors.65535"] // lingaka. *: C ho qala litšitiso
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ho emisa ho khutlela morao
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}