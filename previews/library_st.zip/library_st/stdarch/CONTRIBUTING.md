# E kenya letsoho ho stdarch

`stdarch` crate e ikemiselitse ho amohela menehelo!Pele o kanna oa batla ho sheba polokelo le ho etsa bonnete ba hore liteko lia u fella:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Moo `<your-target-arch>` e habiloeng habeli joalo ka ha e sebelisitsoe ke `rustup`, mohlala, `x86_x64-unknown-linux-gnu` (ntle le `nightly-` e fetileng kapa e ts'oanang).
Hape hopola hore polokelo ena e hloka mocha oa bosiu oa Rust!
Liteko tse kaholimo li hlile li hloka hore rust ea bosiu e be ea mantlha tsamaisong ea hau, ho beha ts'ebeliso ea `rustup default nightly` (le `rustup default stable` ho e khutlisa).

Haeba efe kapa efe ea mehato e kaholimo e sa sebetse, [please let us know][new]!

Ka mor'a moo u ka thusa [find an issue][issues] ho thusa, re khethile ba seng bakae ka li-tag tsa [`help wanted`][help] le [`impl-period`][impl] tse ka sebelisang thuso e itseng haholo. 
O ka khahloa haholo ke [#40][vendor], o kenya ts'ebetsong tsohle tse ka hare ho barekisi ho x86.Makasine eo e na le litlhahiso tse ntle mabapi le hore na u qalelle kae!

Haeba u na le lipotso tse akaretsang ikutloe u lokolohile ho [join us on gitter][gitter] 'me u botse ho potoloha!Ikutloe u lokolohile ho botsa@BurntSushi kapa@alexcrichton ka lipotso.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Mokhoa oa ho ngola mehlala ea li-intrinsics tsa stdarch

Ho na le likarolo tse 'maloa tse lokelang ho fuoa matla bakeng sa tlhaho e fanoeng hore e sebetse hantle' me mohlala o tlameha ho tsamaisoa ke `cargo test --doc` ha karolo e tšehelitsoe ke CPU.

Ka lebaka leo, `fn main` ea kamehla e hlahisoang ke `rustdoc` e ke ke ea sebetsa (maemong a mangata).
Nahana ka ho sebelisa tse latelang e le tataiso ho netefatsa hore mohlala oa hau o sebetsa kamoo ho neng ho lebelletsoe.

```rust
/// # // Re hloka cfg_target_feature ho netefatsa hore mohlala ke oa feela
/// # // e tsamaisoa ke `cargo test --doc` ha CPU e ts'ehetsa tšobotsi eo
/// # #![feature(cfg_target_feature)]
/// # // Re hloka sepheo sa sepheo hore se sebetse ka hare
/// # #![feature(target_feature)]
/// #
/// # // rustdoc ka boiketsetso e sebelisa `extern crate stdarch`, empa re hloka file ea
/// # // `#[macro_use]`
/// # # [macro_use] kantle crate stdarch;
/// #
/// # // Mosebetsi oa nnete oa mantlha
/// # fn main() {
/// #     // Sebelisa sena feela haeba `<target feature>` e tšehetsoa
/// #     haeba cfg_feature_enabled! ("<target feature>"){
/// #         // Theha mosebetsi oa `worker` o tla sebetsoa feela haeba sepheo se shebiloe
/// #         // e ts'ehetsoa le ho netefatsa hore `target_feature` e nolofalitsoe bakeng sa mosebeletsi oa hau
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         e sa bolokehang fn worker() {
/// // Ngola mohlala oa hau mona.Lintlha tsa tlhaho tse ikhethileng li tla sebetsa mona!Tsamaea!
///
/// #         }
///
/// #         e sa sireletsehang { worker(); }
/// #     }
/// # }
```

Haeba tse ling tsa syntax e kaholimo li sa shebahale li tloaelehile, karolo ea [Documentation as tests] ea [Rust Book] e hlalosa poleloana ea `rustdoc` hantle.
Joalo ka mehla, ikutloe u lokolohile ho [join us on gitter][gitter] 'me u re botse hore na u na le likhathatso,' me rea u leboha ka ho thusa ho ntlafatsa litokomane tsa `stdarch`!

# Litaelo tse ling tsa liteko

Ka kakaretso ho khothaletsoa hore o sebelise `ci/run.sh` ho etsa liteko.
Leha ho le joalo sena se kanna sa se u sebetse, mohlala, haeba u ho Windows.

Maemong ao o ka khutlela ho `cargo +nightly test` le `cargo +nightly test --release -p core_arch` bakeng sa ho leka tlhahiso ea khoutu.
Hlokomela hore tsena li hloka hore lithulusi tsa lisebelisoa tsa bosiu li kenngoe le hore `rustc` e tsebe ka sepheo sa hau se tharo le CPU ea eona.
Haholo-holo o hloka ho seta phapang ea tikoloho ea `TARGET` kamoo u neng u ka rata `ci/run.sh`.
Ntle le moo o hloka ho beha `RUSTCFLAGS` (hloka `C`) ho bonts'a likarolo tsa sepheo, mohlala `RUSTCFLAGS="-C -target-features=+avx2"`.
U ka beha `-C -target-cpu=native` haeba u "just" e ntse e tsoela pele khahlano le CPU ea hau ea hajoale.

Lemosoa hore ha u sebelisa litaelo tse ling tse fapaneng, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], mohlala
liteko tsa tlhahiso ea lithupelo li kanna tsa hloleha hobane moqapi o li bitsitse ka tsela e fapaneng, mohlala
e kanna ea hlahisa `vaesenc` sebakeng sa litaelo tsa `aesenc` leha ba itshwere ka tsela e ts'oanang.
Hape, litaelo tsena li etsa liteko tse fokolang ho feta kamoo ho neng ho ka etsoa hangata, kahoo u se ke oa makala hore qetellong ha u hula likopo liphoso li ka hlaha bakeng sa liteko tse sa koaeloang mona.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






