`core::arch` - Meetso e ikhethileng ea laeborari ea Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Mojule oa `core::arch` o sebelisa li-intrinsics tse itšetlehileng ka boqapi (mohlala, SIMD).

# Usage 

`core::arch` e fumaneha e le karolo ea `libcore` mme e romelloa hape ke `libstd`.Khetha ho e sebelisa ka `core::arch` kapa `std::arch` ho feta ka crate ena.
Likarolo tse sa tsitsang hangata li fumaneha ka Rust ea bosiu ka `feature(stdsimd)`.

Ho sebelisa `core::arch` ka crate ena ho hloka Rust bosiu, 'me e ka (' me ea) roba khafetsa.Maemo feela ao u lokelang ho nahana ho a sebelisa ka crate ena ke:

* haeba o hloka ho ikopanya le `core::arch` ka boeena, mohlala, likarolo tse ikhethileng tsa sepheo li lumelletsoe tse sa lumelloeng bakeng sa `libcore`/`libstd`.
Note: haeba o hloka ho e hlophisa bocha bakeng sa sepheo se sa tloaelehang, ka kopo khetha ho sebelisa `xargo` le ho hlophisa bocha `libcore`/`libstd` ka nepo ho fapana le ho sebelisa crate.
  
* ho sebelisa likarolo tse ling tse ka 'nang tsa se ke tsa fumaneha le kamora likarolo tse sa tsitsang tsa Rust.Re leka ho fokotsa tsena.
Haeba u hloka ho sebelisa tse ling tsa likarolo tsena, ka kopo bula bothata e le hore re ka li pepesa Rust bosiu 'me u ka li sebelisa ho tloha moo.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` e ajoa haholoholo tlasa lipehelo tsa laesense ea MIT le laesense ea Apache (Version 2.0), 'me likarolo tse ling li koahetsoe ke laesense e kang ea BSD.

Bona LICENSE-APACHE, le LICENSE-MIT bakeng sa lintlha.

# Contribution

Ntle le haeba o bolela ka ho hlaka, monehelo ofe kapa ofe o rometsoeng ka boomo hore o kenyeletsoe ho `core_arch` ke uena, joalo ka ha ho hlalositsoe ho laesense ea Apache-2.0, e tla ba le laesense e habeli joalo kaholimo, ntle le lipehelo kapa lipehelo tse ling.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












