use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Re ne re tloaetse ho joetsa litlhaloso tsa rona tsa `#[assert_instr]` hore lisebelisoa tsohle tsa simd li teng ho leka codegen ea tsona, hobane tse ling li koaletsoe ka morao ho `-Ctarget-feature=+unimplemented-simd128` e se nang se lekanang le `#[target_feature]` hajoale.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}