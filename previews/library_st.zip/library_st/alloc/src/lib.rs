//! # Kabo ea mantlha ea Rust le pokello ea libuka
//!
//! Laeborari ena e fana ka litlhahiso tse bohlale le likoleke bakeng sa ho laola boleng bo abuoeng ke qubu.
//!
//! Laeborari ena, joalo ka libcore, ka tloaelo ha e hloke ho sebelisoa ka kotloloho kaha litaba tsa eona li romelloa kantle ho [`std` crate](../std/index.html).
//! Crates tse sebelisang boleng ba `#![no_std]` leha ho le joalo hangata ha li itšetlehe ka `std`, ka hona ba tla sebelisa crate ho fapana.
//!
//! ## Litekanyetso tsa mabokose
//!
//! Mofuta oa [`Box`] ke mofuta oa sesupa-bohlale.Ho ka ba le mong a le mong feela oa [`Box`], 'me mong'a lona a ka nka qeto ea ho fetola litaba, tse lulang qubu eo.
//!
//! Mofuta ona o ka romelloa har'a likhoele ka nepo kaha boholo ba boleng ba `Box` bo ts'oana le ba sesupa.
//! Meetso ea data e kang ea sefate hangata e ahoa ka mabokose hobane node e ngoe le e ngoe hangata e na le mong a le mong, motsoali.
//!
//! ## Litšupiso tse baloang ke litšupiso
//!
//! Mofuta oa [`Rc`] ke mofuta oa pointer o sa baloang o sa reroang o reretsoeng ho arolelana memori kahare ho khoele.
//! Pointer ea [`Rc`] e thatela mofuta, `T`, mme e lumella feela phihlello ho `&T`, e leng moelelo o arolelanoeng.
//!
//! Mofuta ona o na le thuso ha phetoho e futsitsoeng (joalo ka ho sebelisa [`Box`]) e sitisa ts'ebeliso, mme hangata e kopanngoa le mefuta ea [`Cell`] kapa [`RefCell`] molemong oa ho lumella phetoho.
//!
//!
//! ## Litlhahiso tse baloang tsa atomically
//!
//! Mofuta oa [`Arc`] ke threadsafe e lekanang le mofuta oa [`Rc`].E fana ka ts'ebetso e ts'oanang ea [`Rc`], ntle le haeba e hloka hore mofuta oa `T` o ka arolelanoa.
//! Ho feta moo, [`Arc<T>`][`Arc`] ka boeona e ka romelloa ha [`Rc<T>`][`Rc`] eona e sa romelloe.
//!
//! Mofuta ona o lumella phihlello e arolelanoeng ea tlhaiso-leseling e fumanehang, 'me hangata e kopantsoe le litlhahiso tsa khokahano tse kang limmete ho lumella phetoho ea lisebelisoa tse arolelanoeng
//!
//! ## Collections
//!
//! Ts'ebetsong ea likarolo tsa data tse akaretsang tsa sepheo li hlalosoa laeboraring ena.Li romelloa hape ka [standard collections library](../std/collections/index.html).
//!
//! ## Likarolo tsa qubu
//!
//! Mojule oa [`alloc`](alloc/index.html) o hlalosa sebopeho sa maemo a tlase ho seabi sa lefats'e sa kamehla.Ha e sebetsane le API ea libc.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Ha e le hantle, ena ke kokoana-hloko ea rustdoc: rustdoc e bona litokomane tse li-block tsa `#[lang = slice_alloc]` ke tsa `&[T]`, e nang le litokomane tse sebelisang tšobotsi ena ho `core`, 'me ea halefa hore karolo ea heke ha e lumelloe.
// Ka nepo, e ne e ke ke ea sheba heke ea likarolo bakeng sa li-docs tse tsoang ho tse ling tsa crates, empa kaha sena se ka hlaha feela bakeng sa lintho tsa lang, ha ho bonahale eka ho lokisoa.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Lumella ho leka laeborari ena

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Module e nang le li-macro tsa kahare tse sebelisoang ke li-module tse ling (e hloka ho kenyelletsoa pele ho li-module tse ling).
#[macro_use]
mod macros;

// Liqubu li fane ka maano a kabo ea boemo bo tlase

pub mod alloc;

// Mefuta ea khale e sebelisang liqubu tse kaholimo

// U hloka ho hlalosa maemo ho tloha `boxed.rs` ho qoba ho qopitsa li-lang ha u haha tekong ea cfg;empa hape e hloka ho lumella khoutu ho ba le liphatlalatso tsa `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}