//! Lisebelisoa tsa ho fomata le ho hatisa `String`s.
//!
//! Mojule ona o na le ts'ehetso ea nako ea ho matha bakeng sa katoloso ea syntax ea [`format!`].
//! Macro ena e kengoa tšebetsong moqoqong ho hlahisa mehala ho module ena molemong oa ho hlophisa likhang ka nako ea ho matha hore e be likhoele.
//!
//! # Usage
//!
//! [`format!`] macro e reretsoe ho tloaelana le ba tsoang mesebetsing ea C's `printf`/`fprintf` kapa Python's `str.format`.
//!
//! Mehlala e meng ea katoloso ea [`format!`] ke:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ka linoto tse etellang pele
//! ```
//!
//! Ho tsoa ho tsena, u ka bona hore khang ea pele ke mohala oa fomate.Ho hlokoa ke moqapi hore ena e be khoele ea sebele;e ke ke ea fetoha e fetoloang (molemong oa ho etsa tlhahlobo e nepahetseng).
//! Moqapi o tla hlophisa mohala oa fomate mme a tsebe hore na lenane la likhang tse fanoeng le loketse ho fetisetsoa khoeleng ena ea fomate.
//!
//! Ho fetolela boleng bo le bong ho le khoele, sebelisa mokhoa oa [`to_string`].Sena se tla sebelisa sebopeho sa [`Display`] trait.
//!
//! ## Likarolo tsa maemo
//!
//! Khang ka 'ngoe ea ho fomata e lumelloa ho hlakisa hore na e bua ka boleng bofe ba boleng,' me haeba e sa lumelloe ho nahanoa hore ke "the next argument".
//! Ka mohlala, mohala oa fomati `{} {} {}` o ne o tla nka mekhahlelo e meraro, 'me e ne e tla hlophisoa ka tatellano e tšoanang le eo ba e fuoeng.
//! Mofuta oa fomati `{2} {1} {0}`, leha ho le joalo, o ka hlophisa likhang ka tatellano e fapaneng.
//!
//! Lintho li ka qhekella hanyane hang ha o qala ho kopanya mefuta e 'meli ea li-specifiers tsa maemo.Mohlalosi oa "next argument" a ka nkuoa e le iterator ka lebaka la ngangisano.
//! Nako le nako ha ho bonoa sebui sa "next argument", iterator e ea hatela pele.Sena se lebisa ho boitšoaro bo kang bona:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator ea kahare ka lebaka la ngangisano ha e so tsoele pele ka nako ea ha `{}` ea pele e bonoa, ka hona e hatisa ngangisano ea pele.Ha a fihla `{}` ea bobeli, iterator e fetetse pele ho ngangisano ea bobeli.
//! Ha e le hantle, mekhahlelo e hlalosang khang ea bona ka ho hlaka ha e ame mekhahlelo e sa boleleng khang ho latela likhakanyo tsa maemo.
//!
//! Mohala oa fomate o hlokahala ho sebelisa likhang tsohle tsa ona, ho seng joalo ke phoso ea nako ea ho bokella.U kanna oa bua ka khang e tšoanang makhetlo a fetang le le leng ka mohala oa fomate.
//!
//! ## E rehiloe mekhahlelo
//!
//! Rust ka boeona ha e na Python-e lekanang le likarolo tse boletsoeng molemong oa tšebetso, empa [`format!`] macro ke katoloso ea syntax ee lumellang hore e sebelise mekhahlelo e rehiloeng.
//! Meeli e boletsoeng e thathamisitsoe qetellong ea lenane la likhang mme e na le syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Ka mohlala, lipolelo tse latelang tsa [`format!`] li sebelisa khang e bitsoang:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ha ho na thuso ho beha maemo a fapaneng (a se nang mabitso) kamora likhang tse nang le mabitso.Joalo ka mekhahlelo ea maemo, ha ho nepahale ho fana ka mekhahlelo e sa sebelisoang ke mohala oa fomate.
//!
//! # Ho fomata Paramente
//!
//! Khang ka 'ngoe e hlophisitsoeng e ka fetoloa ka mekhahlelo e mengata ea ho fomata (e tsamaellanang le `format_spec` ho [the syntax](#syntax)). Meeli ena e ama mohala oa se emeloang.
//!
//! ## Width
//!
//! ```
//! // Tsena tsohle li hatisa "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ena ke paramethara ea "minimum width" eo sebopeho se lokelang ho se nka.
//! Haeba khoele ea boleng e sa tlatse litlhaku tsena tse ngata, joale padding e boletsoeng ke fill/alignment e tla sebelisoa ho nka sebaka se hlokahalang (sheba ka tlase).
//!
//! Boleng ba bophara bo ka boela ba fanoa e le [`usize`] lenaneng la lipehelo ka ho eketsa postfix `$`, e bontšang hore khang ea bobeli ke [`usize`] e hlalosang bophara.
//!
//! Ho bua ka ngangisano le syntax ea dollar ha ho ame khaontara ea "next argument", ka hona hangata ke mohopolo o motle ho bua ka likhang ka boemo, kapa ho sebelisa mabaka a boletsoeng.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Sebopeho le tlamo ea boikhethelo e fanoa ka mokhoa o tloaelehileng hammoho le [`width`](#width) parameter.E tlameha ho hlalosoa pele ho `width`, hang kamora `:`.
//! Sena se bontša hore haeba boleng bo hlophisitsoeng bo le nyane ho `width` ho tla hatisoa litlhaku tse ling ho potoloha.
//! Ho tlatsa ho tla ka mefuta e latelang bakeng sa likarolo tse fapaneng:
//!
//! * `[fill]<` - khang e hokahane ka letsohong le letšehali likholomong tsa `width`
//! * `[fill]^` - ngangisano e hokahane kahare likholomong tsa `width`
//! * `[fill]>` - khang e hokahane hantle ho likholomo tsa `width`
//!
//! [fill/alignment](#fillalignment) ea mantlha bakeng sa bao e seng lipalo ke sebaka mme se hokahantsoe ka letsohong le letšehali.Ho sa feleng bakeng sa lifomate tsa linomoro le hona ke sebopeho sa sebaka empa se hokahane hantle.
//! Haeba folakha ea `0` (bona ka tlase) e boletsoe bakeng sa lipalo, joale sebopeho se tlatsitsoeng ke `0`.
//!
//! Hlokomela hore tatellano e kanna ea se keng ea kengoa ts'ebetsong ke mefuta e meng.Haholo-holo, ha e sebelisoe ka kakaretso bakeng sa `Debug` trait.
//! Mokhoa o motle oa ho netefatsa hore ho kentsoe padding ke ho fomata kenyelletso ea hau, ebe o pata khoele ena e hlahisoang ho fumana tlhahiso ea hau:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Lumela Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Tsena kaofela ke lifolakha tse fetolang boits'oaro ba fomate.
//!
//! * `+` - Sena se etselitsoe mefuta ea linomoro mme se bontša hore lets'oao le lokela ho lula le hatisoa.Matšoao a matle ha a hatisoe ka boiketsetso, 'me letšoao le fosahetseng le hatisoa feela ke `Signed` trait.
//! Folakha ena e supa hore letšoao le nepahetseng (`+` kapa `-`) le lokela ho lula le hatisoa.
//! * `-` - Hajoale ha e sebelisoe
//! * `#` - Folakha ena e bonts'a mofuta oa "alternate" oa khatiso o lokela ho sebelisoa.Mefuta e meng ke ena:
//!     * `#?` - hatisa hantle fomate ea [`Debug`]
//!     * `#x` - E etella pele ngangisano ka `0x`
//!     * `#X` - E etella pele ngangisano ka `0x`
//!     * `#b` - E etella pele ngangisano ka `0b`
//!     * `#o` - E etella pele ngangisano ka `0o`
//! * `0` - Sena se sebelisetsoa ho bonts'a lifomate tse felletseng tsa hore padding ho `width` e lokela ho etsoa ka sebopeho sa `0` hape le ho ba le temoso.
//! Sebopeho se kang `{:08}` se ka hlahisa `00000001` bakeng sa palo e kholo ea `1`, ha sebopeho se tšoanang se ka hlahisa `-0000001` bakeng sa palo e felletseng ea `-1`.
//! Hlokomela hore mofuta o fosahetseng o na le zero e le 'ngoe ho feta mofuta o nepahetseng.
//!         Hlokomela hore zeros tsa padding li lula li beoa kamora lets'oao (haeba le teng) le pele ho lipalo.Ha e sebelisoa hammoho le folakha ea `#`, ho sebetsa molao o ts'oanang: li-zero tsa padding li kentsoe kamora sehlomathiso empa pele ho lipalo.
//!         Selelekela se kenyelelitsoe ho bophara bo felletseng.
//!
//! ## Precision
//!
//! Bakeng sa mefuta eo e seng ea linomoro, sena se ka nkuoa e le "maximum width".
//! Haeba khoele e hlahisoang e le telele ho feta bophara bona, e se e khutsufalitsoe ho litlhaku tsena tse ngata le hore boleng bo fokotsehileng bo hlahisoa ka `fill`, `alignment` le `width` e nepahetseng haeba maemo ao a behiloe.
//!
//! Bakeng sa mefuta ea bohlokoa, sena se hlokomolohuoa.
//!
//! Bakeng sa mefuta ea lintlha tse phaphametseng, sena se bonts'a hore na ho tlameha ho hatisoa linomoro tse kae kamora ntlha ea decimal.
//!
//! Ho na le mekhoa e meraro e ka khonehang ea ho hlakisa `precision` eo u e batlang:
//!
//! 1. Kakaretso ea `.N`:
//!
//!    palo e felletseng ea `N` ka boeona ke ho nepahala.
//!
//! 2. Kakaretso kapa lebitso le lateloa ke letšoao la dollar `.N$`:
//!
//!    sebelisa fomate *ngangisano*`N` (e tlamehang ho ba `usize`) joalo ka ho nepahala.
//!
//! 3. Linaleli `.*`:
//!
//!    `.*` e bolela hore `{...}` ena e amahanngoa le lipehelo tsa fomate tsa * tse peli ho fapana le e le 'ngoe: kenyelletso ea pele e ts'oara ts'ebetso ea `usize`,' me ea bobeli e ts'oere boleng ba ho e hatisa.
//!    Hlokomela hore ketsahalong ena, haeba motho a sebelisa mohala oa fomate `{<arg>:<spec>.*}`, karolo ea `<arg>` e bua ka boleng ba** ho hatisoa, mme `precision` e tlameha ho kena ho kenyelletso e tlileng `<arg>`.
//!
//! Ka mohlala, tse latelang li letsetsa bohle ho hatisa ntho e tšoanang `Hello x is 0.01000`:
//!
//! ```
//! // Lumela {arg 0 ("x")} ke {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Lumela {arg 1 ("x")} ke {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Lumela {arg 0 ("x")} ke {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Lumela {next arg ("x")} ke {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Lumela {next arg ("x")} ke {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Lumela {next arg ("x")} ke {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Le ha tsena:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! hatisa lintho tse tharo tse fapaneng haholo:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Lipuong tse ling tsa mananeo, boits'oaro ba mesebetsi ea ho fomata ka likhoele bo ipapisitse le maemo a sistimi ea ts'ebetso.
//! Mesebetsi ea sebopeho e fanoeng ke laeborari e tloaelehileng ea Rust ha e na mohopolo oa sebaka mme e tla hlahisa litholoana tse tšoanang ho litsamaiso tsohle ho sa tsotelehe phetolo ea mosebelisi.
//!
//! Mohlala, khoutu e latelang e tla lula e hatisa `1.5` leha sebaka sa sistimi se sebelisa sekhetho sa decimal ntle le letheba.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Litlhaku tsa sebele `{` le `}` li kanna tsa kenyelletsoa khoeleng ka ho li etella pele ka sebopeho se tšoanang.Mohlala, sebapali sa `{` se balehile ka `{{` mme `}` e phonyohile ka `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ho akaretsa, mona u ka fumana sebōpeho-puo se felletseng sa likhoele tsa fomate.
//! Poleloana ea puo e sebelisitsoeng e sebelisitsoe ho tsoa lipuong tse ling, ka hona ha ea lokela ho ba mojaki haholo.Likhang li hlophisitsoe ka syntax ea Python, ho bolelang hore likhang li lika-likelitsoe ke `{}` sebakeng sa C-joaloka `%`.
//! Sebopeho sa puo ea 'mino oa sebopeho ke:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Lenaneong le kaholimo, `text` e kanna ea se na litlhaku tsa `'{'` kapa `'}'`.
//!
//! # Ho hlophisa traits
//!
//! Ha o kopa hore khang e hlophisoe ka mofuta o itseng, o hlile o kopa hore ngangisano e ipehe ho trait e itseng.
//! Sena se lumella mefuta e mengata ea 'nete hore e hlophisoe ka `{:x}` (joalo ka [`i8`] hammoho le [`isize`]).'Mapa oa hajoale oa mefuta ho traits ke:
//!
//! * *ha ho letho* ⇒ [`Display`]
//! * `?` 00 [`Debug`]
//! * `x?` ⇒ [`Debug`] e nang le linomoro tse nyenyane tsa hexadecimal
//! * `X?` 00 [`Debug`] e nang le linomoro tse kholo tsa hexadecimal
//! * `o` 00 [`Octal`]
//! * `x` 00 [`LowerHex`]
//! * `X` 00 [`UpperHex`]
//! * `p` 00 [`Pointer`]
//! * `b` 00 [`Binary`]
//! * `e` 00 [`LowerExp`]
//! * `E` 00 [`UpperExp`]
//!
//! Seo se bolelang ke hore mofuta ofe kapa ofe oa ngangisano o sebelisang [`fmt::Binary`][`Binary`] trait o ka hlophisoa ka `{:b}`.Ts'ebetsong ho fanoa ka tsena traits bakeng sa mefuta e mengata ea khale le laeborari e tloaelehileng.
//!
//! Haeba ho se mofuta o boletsoeng (joalo ka `{}` kapa `{:6}`), sebopeho sa trait se sebelisitsoeng ke [`Display`] trait.
//!
//! Ha o kenya tšebetsong mofuta oa trait oa mofuta oa hau, o tla tlameha ho kenya tšebetsong mokhoa oa ho saena:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mofuta wa rona wa moetlo
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Mofuta oa hau o tla fetisoa e le `self` ka litšupiso, ebe ts'ebetso e lokela ho hlahisa tlhahiso ho `f.buf`.Ho latela mofuta o mong le o mong oa ts'ebetso ea trait ho latela ka nepo lipehelo tse kopiloeng tsa fomate.
//! Litekanyetso tsa mekhahlelo ena li tla thathamisoa masimong a [`Formatter`] struct.Bakeng sa ho thusa ka sena, sebopeho sa [`Formatter`] se boetse se fana ka mekhoa ea bathusi.
//!
//! Ntle le moo, boleng ba ho khutlisa ts'ebetso ena ke [`fmt::Result`] e leng mofuta oa alias oa [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Ts'ebetsong ea ts'ebetso e lokela ho netefatsa hore li jala liphoso ho tloha ho [`Formatter`] (mohlala, ha u letsetsa [`write!`]).
//! Leha ho le joalo, ha baa lokela ho khutlisa liphoso hampe.
//! Ka mantsoe a mang, ts'ebetsong ea ho fomata e tlameha ebile e ka khutlisa phoso feela haeba [`Formatter`] e kenelletseng e khutlisa phoso.
//! Lebaka ke hobane, ho fapana le se saenelo ea tšebetso e ka se hlahisang, ho fomata ka likhoele ke ts'ebetso e sa foseng.
//! Mosebetsi ona o khutlisa sephetho hobane ho ngolla molatsoana o ka tlase ho ka se atlehe mme ho tlameha ho fana ka mokhoa oa ho jala taba ea hore phoso e etsahetse morao ho stack.
//!
//! Mohlala oa ho kenya tšebetsong fomate traits o ka shebahala joalo ka:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Boleng ba `f` bo sebelisa `Write` trait, ke sona se ngotsoeng!macro e lebelletse.
//!         // Hlokomela hore fomate ena e hlokomoloha lifolakha tse fapaneng tse fuoeng likhoele tsa fomate.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Li-traits tse fapaneng li lumella mefuta e fapaneng ea tlhahiso ea mofuta.
//! // Moelelo oa mofuta ona ke ho hatisa boholo ba vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hlompha lifolakha tsa ho fomata ka ho sebelisa mokhoa oa mothusi `pad_integral` nthong ea Formatter.
//!         // Bona mokhoa oa tokomane bakeng sa lintlha, 'me mosebetsi `pad` o ka sebelisoa ho roala likhoele.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` khahlanong le `fmt::Debug`
//!
//! Ts'ebetso tsena tse peli tsa traits li na le merero e fapaneng:
//!
//! - [`fmt::Display`][`Display`] ts'ebetsong e tiisa hore mofuta o ka emeloa ka botšepehi joalo ka khoele ea UTF-8 ka linako tsohle.Ha ho lebelloe hore ** mefuta eohle e sebelise [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] ts'ebetsong e lokela ho kengoa ts'ebetsong bakeng sa mefuta eohle ea ** ea sechaba.
//!   Liphetho li tla emela boemo ba kahare ka botshepehi kamoo ho ka khonehang.
//!   Morero oa [`Debug`] trait ke ho tsamaisa khoutu ea Rust.Maemong a mangata, ho sebelisa `#[derive(Debug)]` ho lekane ebile hoa khothaletsoa.
//!
//! Mehlala e meng ea lihlahisoa tse tsoang ho traits ka bobeli:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Li-macro tse amanang
//!
//! Ho na le li-macro tse ngata tse amanang lelapeng la [`format!`].Tse ntseng li sebelisoa hona joale ke:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Sena le [`writeln!`] ke li-macro tse peli tse sebelisetsoang ho ntšetsa khoele ea fomate molatsoaneng o boletsoeng.Sena se sebelisetsoa ho thibela likabo tsa lipakeng tsa likhoele tsa fomate mme ho fapana le moo ngola mongolo ka kotloloho.
//! Tlas'a hood, ts'ebetso ena e hlile e hohella ts'ebetso ea [`write_fmt`] e hlalositsoeng ho [`std::io::Write`] trait.
//! Mohlala oa tšebeliso ke:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Sena le [`println!`] li ntša tlhahiso ea tsona ho stdout.Ka mokhoa o ts'oanang le [`write!`] macro, sepheo sa macro ana ke ho qoba likabo tse mahareng ha ho hatisoa tlhahiso.Mohlala oa tšebeliso ke:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Li-macro tsa [`eprint!`] le [`eprintln!`] li ts'oana le [`print!`] le [`println!`], ka ho latellana, ntle le ha li hlahisa tlhahiso ea tsona ho stderr.
//!
//! ### `format_args!`
//!
//! Ena ke macro e makatsang e sebelisetsoang ho feta ka mokhoa o sireletsehileng ho potoloha ntho e sa hlakang e hlalosang mohala oa fomate.Ntho ena ha e hloke likabelo tsa qubu ho theha, mme e supa feela tlhaiso-leseling ka pokothong.
//! Tlas'a ntlo, li-macro tsohle tse amanang li kenngwa tšebetsong ho latela sena.
//! Qalong, mohlala o mong oa tšebeliso ke:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Sephetho sa [`format_args!`] macro ke boleng ba mofuta oa [`fmt::Arguments`].
//! Sebopeho sena se ka fetisetsoa mesebetsing ea [`write`] le [`format`] kahare ho module ena ho sebetsana le mohala oa fomate.
//! Morero oa sena se seholo ke ho thibela le ho feta likabo tsa lipakeng ha ho sebetsoa ka likhoele tsa fomate.
//!
//! Mohlala, laeborari ea ho rema lifate e ka sebelisa syntax e tloaelehileng ea sebopeho, empa e ne e tla feta kahare mohahong ona ho fihlela ho fumanoe hore na tlhahiso e lokela ho ea kae.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Mosebetsi oa `format` o nka [`Arguments`] sebopeho ebe o khutlisa khoele e hlophisitsoeng e hlahisitsoeng.
///
///
/// Mohlala oa [`Arguments`] o ka etsoa ka [`format_args!`] macro.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Ka kopo hlokomela hore ho ka ba molemo ho sebelisa [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}