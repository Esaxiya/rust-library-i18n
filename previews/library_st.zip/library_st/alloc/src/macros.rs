/// E theha [`Vec`] e nang le likhang.
///
/// `vec!` e lumella `Vec`s ho hlalosoa ka syntax e tšoanang le lipolelo tse ngata.
/// Ho na le mefuta e 'meli ea macro ena:
///
/// - Theha [`Vec`] e nang le lenane le fuoeng la likarolo:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Theha [`Vec`] ho tsoa nthong le boholo bo fanoeng:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Hlokomela hore ho fapana le lipolelo tse fapaneng, syntax ena e ts'ehetsa likarolo tsohle tse sebelisang [`Clone`] mme palo ea likarolo ha ea tlameha ho lula e le teng.
///
/// Sena se tla sebelisa `clone` ho pheta polelo, ka hona motho o lokela ho ba hlokolosi ha a sebelisa sena ka mefuta e nang le ts'ebetsong e sa emeng ea `Clone`.
/// Mohlala, `vec![Rc::new(1);5] `e tla theha vector ea litšupiso tse hlano ho boleng bo lekanang ba mabokose, eseng litšupiso tse hlano tse supang linomoro tse ikemetseng tse nang le mabokose.
///
///
/// Hape, hlokomela hore `vec![expr; 0]` e lumelletsoe, 'me e hlahisa vector e se nang letho.
/// Sena se ntse se tla hlahloba `expr`, leha ho le joalo, 'me hanghang se theole boleng bo hlahang, ka hona, hlokomela litlamorao.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ka cfg(test) mokhoa oa tlhaho oa `[T]::into_vec`, o hlokehang bakeng sa tlhaloso ena e kholo, ha o fumanehe.
// Sebakeng seo sebelisa `slice::into_vec` function e fumanehang feela ka cfg(test) NB bona module ea slice::hack ho slice.rs bakeng sa tlhaiso-leseling e batsi
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// E theha `String` e sebelisa ho kenyelletsa lipolelo tsa nako ea ho matha.
///
/// Khang ea pele `format!` e e fumanang ke mohala oa fomate.Sena e tlameha ho ba khoele ea sebele.Matla a khoele ea ho fomata a fumaneha ka har'a li-`{}` s.
///
/// Mekhahlelo e meng e fetiselitsoeng ho `format!` e nka sebaka sa `{}` s ka har'a mohala oa ho fomata ka tatellano e fanoeng ntle le haeba ho sebelisitsoe mekhahlelo ea maemo;bona [`std::fmt`] bakeng sa tlhaiso-leseling e batsi.
///
///
/// Ts'ebeliso e tloaelehileng bakeng sa `format!` ke concatenation le ho kenyelletsa likhoele.
/// Kopano e ts'oanang e sebelisoa le [`print!`] le [`write!`] macros, ho latela sebaka se reretsoeng khoele.
///
/// Ho fetolela boleng bo le bong ho le khoele, sebelisa mokhoa oa [`to_string`].Sena se tla sebelisa sebopeho sa [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics haeba ho hlophisoa ha trait ho khutlisa phoso.
/// Sena se bontša ts'ebetso e fosahetseng ho tloha ha `fmt::Write for String` e sa khutlise phoso ka boeona.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Qobella node ea AST ho polelo ho ntlafatsa li-diagnostics maemong a paterone.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}